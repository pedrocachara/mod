using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu;

public class Saving
{
	private float frame;

	public bool Active()
	{
		return frame > 0f;
	}

	public void Update()
	{
		frame -= FMan.realTime;
	}

	public void Draw(SpriteBatch sprite, int threedee, bool center, float alpha, float _frame)
	{
		float alpha2 = 1f;
		if (frame > 2.9f)
		{
			alpha2 = (3f - frame) * 10f;
		}
		if (frame < 0.5f)
		{
			alpha2 = frame * 2f;
		}
		if (alpha >= 0f)
		{
			alpha2 = alpha;
		}
		if (_frame >= 0f)
		{
			frame = _frame;
		}
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X++;
			break;
		case 1:
			vector.X--;
			break;
		}
		float num = 120f;
		Vector2 vector2 = new Vector2(ScrollManager.screenSize.X, 0f) + new Vector2(0f - num, num);
		if (center)
		{
			vector2 = ScrollManager.screenSize / 2f;
		}
		sprite.Draw(Game1.spritesTex, vector2 + vector, new Rectangle(832, 192, 64, 64), new Color(1f, 1f, 1f, alpha2), 0f - frame, new Vector2(32f, 32f), 2f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, vector2 + vector, new Rectangle(1088, 928, 64, 64), new Color(1f, 1f, 1f, alpha2), 0f, new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
	}

	internal void Init()
	{
		frame = 3f;
	}

	internal void Kill()
	{
		frame = -1f;
	}
}
