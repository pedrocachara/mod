using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu;

public class InkBlot
{
	public Vector2 loc;

	public float speed;

	public float size;

	public int idx;

	public bool bright;

	public float rot;

	public void Update()
	{
		loc.X -= speed * FMan.frameTime;
		rot += FMan.frameTime / 12f;
		if (loc.X < -100f)
		{
			loc.X = ScrollManager.screenSize.X + 100f;
			loc.Y = Rand.GetRandomFloat(0f, ScrollManager.screenSize.Y);
			idx = Rand.GetRandomInt(0, 6);
			size = Rand.GetRandomFloat(2f, 5f);
			speed = Rand.GetRandomFloat(1f, 5f);
			bright = Rand.CointToss(0.5f);
		}
	}

	public InkBlot()
	{
		loc = Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, 0f, ScrollManager.screenSize.Y);
		idx = Rand.GetRandomInt(0, 6);
		size = Rand.GetRandomFloat(2f, 5f);
		speed = Rand.GetRandomFloat(1f, 5f);
		bright = Rand.CointToss(0.5f);
	}

	public void Draw(SpriteBatch sprite)
	{
		sprite.Draw(Game1.spritesTex, loc, new Rectangle(384 + idx * 64, 320, 64, 64), bright ? new Color(0.4f, 0.4f, 0.4f, 0.2f) : new Color(0f, 0f, 0f, 0.2f), rot, new Vector2(32f, 32f), size, SpriteEffects.None, 1f);
	}
}
