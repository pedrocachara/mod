using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;
using Yuki_Win.guidestuff;
using Yuki_Win.hud;

namespace Yuki_Win.menu;

public class Upsell
{
	public enum VideoPhase
	{
		NotYetStarted,
		Playing,
		Done
	}

	private float transOutFrame;

	private float frame;

	public RenderTarget2D videoTarg;

	public bool quitOnExit;

	private Video video;

	private VideoPlayer player;

	private Texture2D videoTexture;

	public bool isInited;

	public VideoPhase videoPhase;

	public bool IsPlaying()
	{
		if (player.State == MediaState.Playing || player.State == MediaState.Paused)
		{
			return true;
		}
		return false;
	}

	public void Stop()
	{
		if (player.State == MediaState.Playing || player.State == MediaState.Paused)
		{
			player.Stop();
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		if (isInited && player.State != MediaState.Stopped)
		{
			SpriteTools.BeginAlpha();
			sprite.Draw(player.GetTexture(), new Rectangle(0, 0, 1280, 720), Color.White);
			sprite.End();
		}
	}

	public Upsell(ContentManager Content)
	{
		video = Content.Load<Video>("vids/trailer240");
		player = new VideoPlayer();
		isInited = true;
	}

	public void Play()
	{
		Play(quitOnExit: false);
	}

	public void Play(bool quitOnExit)
	{
		this.quitOnExit = quitOnExit;
		player.Play(video);
		frame = 0f;
		if (GameState.state != GameState.State.Upsell)
		{
			Game1.sceneMgr.Read("scene/data/tv.zcx", blocking: true);
			GameState.state = GameState.State.Upsell;
			Game1.sceneMgr.curScene = 0;
			Game1.sceneMgr.video.time = 0f;
			transOutFrame = -1f;
		}
	}

	public void Update()
	{
		Game1.sceneMgr.Update();
		Game1.menuMgr.buy.Update();
		frame += FMan.realTime;
		if (transOutFrame > 0f)
		{
			transOutFrame -= FMan.frameTime * 0.5f;
			if (transOutFrame <= 0f)
			{
				EndIt();
			}
			return;
		}
		if (Game1.sceneMgr.video.time > 59f && transOutFrame <= 0f)
		{
			transOutFrame = 1f;
		}
		if (frame > 10f && !Game1.netSession.IsClient())
		{
			int owner = Game1.mainPlayer[0];
			if (flibitPort.GetInputDigital(owner, flibitPort.InputAction.JumpAccept))
			{
				transOutFrame = 1f;
			}
			if (flibitPort.GetInputDigital(owner, flibitPort.InputAction.Attack))
			{
				transOutFrame = 1f;
				GuideStuff.ShowUpsell(owner);
				quitOnExit = false;
			}
			if (quitOnExit && flibitPort.GetInputDigital(owner, flibitPort.InputAction.StrongSaw))
			{
				transOutFrame = 1f;
				quitOnExit = false;
			}
		}
	}

	public void EndIt()
	{
		Stop();
		GameState.state = GameState.State.Menu;
		Game1.menuMgr.MenuReset();
		if (quitOnExit)
		{
			Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Quit;
			Game1.menuMgr.transFrame = 1f;
			Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
		}
	}

	public void Draw(GraphicsDeviceManager g, SpriteBatch sprite, int threedee)
	{
		_ = g.GraphicsDevice;
		g.GraphicsDevice.SetRenderTarget(videoTarg);
		SpriteTools.BeginAlpha();
		sprite.Draw(player.GetTexture(), new Rectangle(0, 0, 320, 240), Color.White);
		sprite.End();
		if (transOutFrame < 0f)
		{
			float num = frame;
			if (num > 1f)
			{
				num = 1f;
			}
			try
			{
				Game1.sceneMgr.video.scenes[0].r = num;
				Game1.sceneMgr.video.scenes[0].g = num;
				Game1.sceneMgr.video.scenes[0].b = num;
			}
			catch
			{
			}
		}
		else
		{
			try
			{
				Game1.sceneMgr.video.scenes[0].r = transOutFrame;
				Game1.sceneMgr.video.scenes[0].g = transOutFrame;
				Game1.sceneMgr.video.scenes[0].b = transOutFrame;
			}
			catch
			{
			}
		}
		if (transOutFrame < 0f)
		{
			float num2 = frame * 0.5f;
			if (num2 > 1f)
			{
				num2 = 1f;
			}
			try
			{
				Game1.sceneMgr.video.scenes[0].r = num2;
				Game1.sceneMgr.video.scenes[0].g = num2;
				Game1.sceneMgr.video.scenes[0].b = num2;
			}
			catch
			{
			}
		}
		else
		{
			try
			{
				Game1.sceneMgr.video.scenes[0].r = transOutFrame;
				Game1.sceneMgr.video.scenes[0].g = transOutFrame;
				Game1.sceneMgr.video.scenes[0].b = transOutFrame;
			}
			catch
			{
			}
		}
		Game1.sceneMgr.Draw(g, sprite, threedee, overlay: false);
		SpriteTools.BeginAlpha();
		float num3 = 0f;
		if (frame < 3f)
		{
			num3 = 0f;
		}
		else if (frame < 4f)
		{
			num3 = frame - 3f;
		}
		else if (frame < 57f)
		{
			num3 = 1f;
		}
		else
		{
			num3 = ((!(frame < 59f)) ? 0f : ((59f - frame) * 0.5f));
		}
		Game1.menuMgr.buy.Draw(sprite, num3);
		if (frame > 10f && transOutFrame < 0f)
		{
			if (quitOnExit)
			{
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.ReturnToGameLibrary, 0, 1f);
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.Y, BottomRightMessage.Msg.ReturnToGame, 2, 1f);
			}
			else
			{
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Continue, 0, 1f);
			}
			BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.X, BottomRightMessage.Msg.Buy, 1, 1f);
		}
		sprite.End();
	}

	public void Draw(GraphicsDeviceManager dev, SpriteBatch sprite)
	{
		Draw(dev, sprite, -1);
	}
}
