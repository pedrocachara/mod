using System;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu;

public class Buy
{
	private const int ROWS = 5;

	private const float ROWSIZE = 40f;

	public float frame;

	private StringBuilder[] buyStr;

	private float[] buyA;

	private float rFrame;

	public Buy()
	{
		buyA = new float[15];
		buyStr = new StringBuilder[16]
		{
			new StringBuilder(YukiText.buy_msg_0),
			new StringBuilder(YukiText.buy_msg_1),
			new StringBuilder(YukiText.buy_msg_2),
			new StringBuilder(YukiText.buy_msg_3),
			new StringBuilder(YukiText.buy_msg_4),
			new StringBuilder(YukiText.buy_msg_5),
			new StringBuilder(YukiText.buy_msg_6),
			new StringBuilder(YukiText.buy_msg_7),
			new StringBuilder(YukiText.buy_msg_8),
			new StringBuilder(YukiText.buy_msg_9),
			new StringBuilder(YukiText.buy_msg_10),
			new StringBuilder(YukiText.buy_msg_11),
			new StringBuilder(YukiText.buy_msg_12),
			new StringBuilder(YukiText.buy_msg_13),
			new StringBuilder(YukiText.buy_msg_14),
			new StringBuilder(YukiText.buy_msg_15)
		};
	}

	public void Update()
	{
		frame += FMan.frameTime * 100f;
		if (frame > 1280f)
		{
			frame -= 1280f;
		}
		rFrame += FMan.frameTime * 0.2f;
		if (rFrame > 6.28f)
		{
			rFrame -= 6.28f;
		}
		if (Game1.sceneMgr.video.time > 5f)
		{
			float num = Game1.sceneMgr.video.time - 5f;
			num *= 0.35f;
			for (int i = 0; i < 15; i++)
			{
				bool flag = false;
				if (num > (float)i)
				{
					int num2 = (int)(num - (float)i);
					if (num2 % 15 < 5)
					{
						flag = true;
					}
				}
				if (flag)
				{
					if (buyA[i] < 1f)
					{
						buyA[i] += FMan.frameTime * 0.25f;
					}
				}
				else if (buyA[i] > 0f)
				{
					buyA[i] -= FMan.frameTime * 0.25f;
				}
			}
		}
		else
		{
			for (int j = 0; j < buyA.Length; j++)
			{
				buyA[j] = 0f;
			}
		}
	}

	public void Draw(SpriteBatch sprite, float alpha)
	{
		float x = 1180f;
		float num = 100f;
		for (int i = 0; i < 2; i++)
		{
			float num2 = ((i == 1) ? 1f : 0f);
			Text.DrawCText(sprite, new Vector2(x, num) + new Vector2(-3f, -3f) * i, buyStr[0], new Color(1f * num2, 0.9f * num2, 0.8f * num2, alpha), 0.9f, 2, blur: true);
			for (int j = 1; j < buyStr.Length; j++)
			{
				int num3 = j - 1;
				if (buyA[num3] >= 0f)
				{
					Text.DrawCText(sprite, new Vector2(x, num + 32f + (float)((j - 1) % 5 + 1) * 40f) + new Vector2(-3f, -3f) * i + new Vector2((float)Math.Cos((float)j + rFrame), (float)Math.Sin((float)j + rFrame)) * new Vector2(7f, 4f), buyStr[j], new Color(num2, num2, num2, buyA[num3] * alpha * ((i == 0) ? 0.4f : 1f)), 0.8f, 2, blur: true);
				}
			}
		}
	}
}
