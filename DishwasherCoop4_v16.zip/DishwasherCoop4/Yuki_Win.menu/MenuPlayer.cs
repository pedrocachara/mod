using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Yuki_Win.debug;

namespace Yuki_Win.menu;

public class MenuPlayer
{
	public GamePadState oldgs;

	public int idx;

	public bool active;

	public bool keyDown;

	public bool keyUp;

	public bool keyHeldUp;

	public bool keyHeldDown;

	public bool keyLeft;

	public bool keyRight;

	public bool keyAccept;

	public bool keyCancel;

	public bool keyStart;

	public bool keyYOption;

	public bool keyUnlock;

	public bool keyRS;

	public bool keyLS;

	public bool keyRT;

	public bool keyLT;

	public Vector2 rVec;

	private Vector2 oldLS;

	private float oldTR;

	private float oldTL;

	private float repeatFrame;

	private float pageUpFrame;

	private float pageDownFrame;

	public bool newPage;

	public bool GetSkipUp()
	{
		return keyLT;
	}

	public bool GetSkipDown()
	{
		return keyRT;
	}

	public bool GetPageUp()
	{
		if (pageUpFrame > 0f)
		{
			return true;
		}
		return false;
	}

	public bool GetPageDown()
	{
		if (pageDownFrame > 0f)
		{
			return true;
		}
		return false;
	}

	public MenuPlayer(int idx)
	{
		this.idx = idx;
	}

	public void Update()
	{
		keyDown = false;
		keyUp = false;
		keyHeldDown = false;
		keyHeldUp = false;
		keyLeft = false;
		keyRight = false;
		keyAccept = false;
		keyCancel = false;
		keyStart = false;
		keyYOption = false;
		keyUnlock = false;
		keyRT = false;
		keyLT = false;
		keyLS = false;
		keyRS = false;
		if (pageUpFrame > 0f)
		{
			pageUpFrame -= FMan.realTime;
		}
		if (pageDownFrame > 0f)
		{
			pageDownFrame -= FMan.realTime;
		}
		flibitPort.GetInputDPad(idx, out keyUp, out keyDown, out keyLeft, out keyRight);
		Vector2 inputStick = flibitPort.GetInputStick(idx, flibitPort.InputAction.Move);
		float inputAnalog = flibitPort.GetInputAnalog(idx, flibitPort.InputAction.Magic);
		float inputAnalog2 = flibitPort.GetInputAnalog(idx, flibitPort.InputAction.Gun);
		if (inputStick.Y < -0.3f && oldLS.Y >= -0.3f)
		{
			keyDown = true;
		}
		if (inputStick.Y > 0.3f && oldLS.Y <= 0.3f)
		{
			keyUp = true;
		}
		if (inputStick.X < -0.3f && oldLS.X >= -0.3f)
		{
			keyLeft = true;
		}
		if (inputStick.X > 0.3f && oldLS.X <= 0.3f)
		{
			keyRight = true;
		}
		if (inputAnalog2 > 0.3f && oldTR <= 0.3f)
		{
			keyRT = true;
			pageDownFrame = 0.15f;
			newPage = true;
		}
		if (inputAnalog > 0.3f && oldTL <= 0.3f)
		{
			keyLT = true;
			pageUpFrame = 0.15f;
			newPage = true;
		}
		flibitPort.GetDPadUpDown(idx, out keyHeldUp, out keyHeldDown);
		if (inputStick.Y < -0.3f)
		{
			keyHeldDown = true;
		}
		if (inputStick.Y > 0.3f)
		{
			keyHeldUp = true;
		}
		if (keyHeldUp || keyHeldDown)
		{
			repeatFrame += FMan.realTime;
			if (repeatFrame > 0.5f)
			{
				repeatFrame -= 0.1f;
				if (keyHeldUp)
				{
					keyUp = true;
				}
				if (keyHeldDown)
				{
					keyDown = true;
				}
			}
		}
		else
		{
			repeatFrame = 0f;
		}
		rVec = flibitPort.GetInputStick(idx, flibitPort.InputAction.WarpRoll);
		if (flibitPort.GetInputClicked(idx, flibitPort.InputAction.SwitchWeapons))
		{
			keyRS = true;
		}
		if (flibitPort.GetInputClicked(idx, flibitPort.InputAction.SwitchLoadouts))
		{
			keyLS = true;
		}
		if (flibitPort.GetInputClicked(idx, flibitPort.InputAction.JumpAccept))
		{
			keyAccept = true;
		}
		if (flibitPort.GetInputClicked(idx, flibitPort.InputAction.GrabCancel))
		{
			keyCancel = true;
		}
		if (flibitPort.GetInputClicked(idx, flibitPort.InputAction.StrongSaw))
		{
			keyYOption = true;
		}
		if (flibitPort.GetInputClicked(idx, flibitPort.InputAction.Attack))
		{
			keyUnlock = true;
		}
		if (flibitPort.GetInputClicked(idx, flibitPort.InputAction.PauseConfirm))
		{
			keyStart = true;
		}
		if (DebugManager.playMode == DebugManager.PlayMode.Step)
		{
			keyStart = false;
		}
		oldLS = inputStick;
		oldTL = inputAnalog;
		oldTR = inputAnalog2;
	}
}
