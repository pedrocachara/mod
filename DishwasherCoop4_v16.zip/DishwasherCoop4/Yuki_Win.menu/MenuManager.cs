using System.Collections.Generic;
using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.achievements.achievables;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.gameRender;
using Yuki_Win.guidestuff;
using Yuki_Win.hud;
using Yuki_Win.maps;
using Yuki_Win.menu.levels;
using Yuki_Win.menu.levels.controls;
using Yuki_Win.menu.msgs;

namespace Yuki_Win.menu;

public class MenuManager
{
	public enum LevelTitle
	{
		MainMenu,
		QuitYouSure,
		SinglePlayer,
		Difficulty,
		PauseMenu,
		EndGameYouSure,
		MovesList,
		YouAreDead,
		DeadEndGameYouSure,
		DeadRestartLevelYouSure,
		CoopLevels,
		CoopDifficulty,
		Multiplayer,
		Debug,
		ArcadeLevels,
		MultiplayerType,
		ArcadeYouAreDead,
		ArcadeDeadEndGameYouSure,
		CampaignPlayer,
		YukiCampaign,
		DishCampaign,
		CoopCampaign,
		PressStart,
		PAXMain,
		PAXDifficulty,
		Controls,
		PAXControls,
		PAXEnd,
		SelectPlayers,
		LeaderBoardType,
		LeaderBoardLevels,
		MenuLeaderBoard,
		BuyLev,
		HowToPlay,
		HelpAndOptions,
		XBLA,
		Lobby,
		ListGames,
		Searching,
		HostLobby,
		RemotePauseMenu,
		DishChallenge,
		DishDishChallenge,
		YukiDishChallenge,
		CustomMatch,
		QuickSearching,
		ClientQuitYouSure,
		LeaderboardSpeedrunYuki,
		LeaderboardSpeedrunDish,
		PracticePlayer,
		Settings,
		EndGameJoinInvitedYouSure,
		HostQuitYouSure,
		Credits,
		PAXArcade,
		PAX2Main,
		LevelOnePlayer,
		MouseControls
	}

	private struct Blip
	{
		public Vector2 loc;

		public Vector2 traj;

		public float frame;
	}

	public enum TransitionMode
	{
		None,
		In,
		Out
	}

	public enum TransitionGoal
	{
		None,
		YukiCampaign,
		DishCampaign,
		Arcade,
		ResetMenu,
		EndGame,
		Continue,
		RestartLevel,
		Quit,
		CoopCampaign,
		DishChallenge,
		Lobby,
		HostLobby,
		DishPractice,
		YukiPractice,
		Upsell,
		LevelOnePlayer,
		UpsellNoQuit
	}

	public Dictionary<int, MenuLevel> levels;

	public Map map;

	public MenuPlayer[] menuPlayer;

	private Effect menuEffect;

	private EffectPass pass;

	public Vector2 curScroll;

	public Buy buy;

	private InkBlot[] inkBlot;

	public float swimFrame;

	public Vector2 scrollGoalOffsetAdd;

	public Vector2 scrollGoalOffset;

	private float scrollGoalOffsetFrame;

	public Vector2 glow;

	public bool blockInput;

	public bool pauseMode;

	public bool remotePause;

	public float frame;

	public float startScreenAlpha;

	public float mainScreenAlpha;

	public MenuLevel.SceneLoc sceneLoc;

	public int[] secretqueue;

	public MessageMgr messageMgr;

	public Achievable achievable;

	public int owner;

	private Blip[] blip;

	private Saving saving;

	public TransitionMode transMode;

	public float transFrame;

	public TransitionGoal transGoal;

	public int transGoalLevel;

	private Environ environ;

	public ControlsStrings controlsStrings;

	public StringBuilder connectingStr = new StringBuilder(YukiText.connecting);

	public int GetOwner()
	{
		if (pauseMode)
		{
			return owner;
		}
		return 0;
	}

	public void BumpInk(Vector2 dif)
	{
		for (int i = 0; i < inkBlot.Length; i++)
		{
			inkBlot[i].loc -= dif * 1.3f;
			if (inkBlot[i].loc.X > ScrollManager.screenSize.X + 100f)
			{
				inkBlot[i].loc.X -= ScrollManager.screenSize.X + 200f;
			}
			if (inkBlot[i].loc.Y > ScrollManager.screenSize.Y + 100f)
			{
				inkBlot[i].loc.Y -= ScrollManager.screenSize.Y + 200f;
			}
			if (inkBlot[i].loc.X < -100f)
			{
				inkBlot[i].loc.X += ScrollManager.screenSize.X + 200f;
			}
			if (inkBlot[i].loc.Y < -100f)
			{
				inkBlot[i].loc.Y += ScrollManager.screenSize.Y + 200f;
			}
		}
	}

	public void SetSaving()
	{
		saving.Init();
	}

	public MenuManager(ContentManager Content)
	{
		Game1.loader.DebugPrint("Initing Menu Manager");
		secretqueue = new int[16];
		messageMgr = new MessageMgr();
		controlsStrings = new ControlsStrings();
		buy = new Buy();
		saving = new Saving();
		achievable = new Achievable();
		Reset();
		Game1.loader.DebugPrint("Reset");
		blip = new Blip[120];
		for (int i = 0; i < blip.Length; i++)
		{
			blip[i].frame = (float)i / (float)blip.Length;
			blip[i].loc = new Vector2(-100f, -100f);
		}
		menuPlayer = new MenuPlayer[4];
		for (int j = 0; j < menuPlayer.Length; j++)
		{
			menuPlayer[j] = new MenuPlayer(j);
		}
		menuEffect = Content.Load<Effect>("fx/menu");
		Game1.loader.DebugPrint("Effect loaded");
		for (int k = 0; k < levels.Count; k++)
		{
			levels[k].active = false;
		}
		levels[22].active = true;
		curScroll = levels[22].mapScrollGoal;
		glow = levels[22].glowGoal;
		inkBlot = new InkBlot[128];
		for (int l = 0; l < inkBlot.Length; l++)
		{
			inkBlot[l] = new InkBlot();
		}
		Game1.loader.DebugPrint("Ink blots inited");
		transMode = TransitionMode.In;
		transFrame = 1f;
		environ = new Environ();
		Game1.loader.DebugPrint("Environ created");
		ResetScene(0);
		Game1.loader.DebugPrint("Complete Menu Manager");
	}

	public void ResetScene(int scene)
	{
		Game1.sceneMgr.Read("scene/data/screen_all.zcx", blocking: true);
		Game1.sceneMgr.curScene = scene;
		Game1.sceneMgr.video.time = 0f;
		startScreenAlpha = 0f;
		mainScreenAlpha = 0f;
	}

	public void Reset()
	{
		levels = new Dictionary<int, MenuLevel>();
		levels.Add(0, new MainMenu());
		levels.Add(1, new QuitYouSure());
		levels.Add(2, new SinglePlayer());
		levels.Add(3, new Difficulty());
		levels.Add(4, new PauseMenu());
		levels.Add(5, new EndGameYouSure());
		levels.Add(6, new MovesList());
		levels.Add(7, new YouAreDead());
		levels.Add(8, new DeadEndGameYouSure());
		levels.Add(9, new DeadRestartLevelYouSure());
		levels.Add(10, new CoopLevels());
		levels.Add(11, new CoopDifficulty());
		levels.Add(12, new Multiplayer());
		levels.Add(13, new DebugLev());
		levels.Add(14, new ArcadeLevels());
		levels.Add(15, new MultiplayerType());
		levels.Add(18, new CampaignPlayer());
		levels.Add(19, new YukiCampaign());
		levels.Add(20, new DishCampaign());
		levels.Add(21, new CoopCampaign());
		levels.Add(22, new PressStart());
		levels.Add(23, new PAXMain());
		levels.Add(24, new PAXDifficulty());
		levels.Add(25, new Controls());
		levels.Add(26, new PAXControls());
		levels.Add(27, new PAXEnd());
		levels.Add(28, new SelectPlayers());
		levels.Add(33, new HowToPlay());
		levels.Add(34, new HelpAndOptions());
		levels.Add(41, new DishChallenge());
		levels.Add(42, new DishDishChallenge());
		levels.Add(43, new YukiDishChallenge());
		levels.Add(44, new CustomMatch());
		levels.Add(45, new QuickSearching());
		levels.Add(29, new LeaderboardType());
		levels.Add(30, new LeaderboardLevels());
		levels.Add(31, new MenuLeaderboard());
		levels.Add(32, new BuyLev());
		levels.Add(50, new Settings());
		levels.Add(56, new LevelOnePlayer());
		levels.Add(35, new XBLA());
		levels.Add(37, new ListGames());
		levels.Add(38, new Searching());
		levels.Add(36, new Lobby());
		levels.Add(39, new HostLobby());
		levels.Add(40, new RemotePause());
		levels.Add(46, new ClientQuitYouSure());
		levels.Add(48, new LeaderboardSpeedrunDish());
		levels.Add(47, new LeaderboardSpeedrunYuki());
		levels.Add(49, new PracticePlayer());
		levels.Add(51, new EndGameJoinInvitedYouSure());
		levels.Add(52, new HostQuitYouSure());
		levels.Add(53, new Credits());
		levels.Add(55, new PAX2Main());
		levels.Add(54, new PAXArcade());
		levels.Add(57, new MouseControls());
		levels.Add(16, new ArcadeYouAreDead());
		levels.Add(17, new ArcadeDeadEndGameYouSure());
		levels[0].active = true;
		levels[3].selected = 2;
		levels[11].selected = 2;
		levels[24].selected = 2;
	}

	public void DemoReset()
	{
		GameState.state = GameState.State.Menu;
		DeactivateAllLevels();
		if (GameState.paxDemoMode || GameState.longDemoMode)
		{
			levels[27].active = true;
		}
		else
		{
			levels[0].active = true;
		}
		ResetScene(1);
		transMode = TransitionMode.In;
		transFrame = 1f;
		pauseMode = false;
	}

	public void EndLevelOne()
	{
		GameState.state = GameState.State.Menu;
		DeactivateAllLevels();
		levels[56].active = true;
		ResetScene(1);
		transMode = TransitionMode.In;
		transFrame = 1f;
		pauseMode = false;
	}

	public void EndDishChallenge()
	{
		GameState.state = GameState.State.Menu;
		DeactivateAllLevels();
		levels[41].active = true;
		ResetScene(1);
		transMode = TransitionMode.In;
		transFrame = 1f;
		pauseMode = false;
	}

	private void UpdateSecretQueue()
	{
		if (flibitPort.GetInputClicked(0, flibitPort.InputAction.Attack))
		{
			AddQueue(0);
		}
		if (flibitPort.GetInputClicked(0, flibitPort.InputAction.StrongSaw))
		{
			AddQueue(1);
		}
		if (flibitPort.GetInputClicked(0, flibitPort.InputAction.SwitchLoadouts))
		{
			AddQueue(2);
		}
		if (flibitPort.GetInputClicked(0, flibitPort.InputAction.SwitchWeapons))
		{
			AddQueue(3);
		}
	}

	private void AddQueue(int b)
	{
		for (int num = secretqueue.Length - 2; num >= 0; num--)
		{
			secretqueue[num + 1] = secretqueue[num];
		}
		secretqueue[0] = b;
		if (secretqueue[6] == 3 && secretqueue[5] == 3 && secretqueue[4] == 2 && secretqueue[3] == 2 && secretqueue[2] == 0 && secretqueue[1] == 1 && secretqueue[0] == 0)
		{
			DeactivateAllLevels();
			levels[0].active = true;
		}
		if (secretqueue[6] == 2 && secretqueue[5] == 2 && secretqueue[4] == 3 && secretqueue[3] == 3 && secretqueue[2] == 1 && secretqueue[1] == 0 && secretqueue[0] == 1)
		{
			DeactivateAllLevels();
			levels[55].active = true;
		}
		if (secretqueue[10] == 1 && secretqueue[9] == 1 && secretqueue[8] == 3 && secretqueue[7] == 2 && secretqueue[6] == 1 && secretqueue[5] == 1 && secretqueue[4] == 3 && secretqueue[3] == 2 && secretqueue[2] == 1 && secretqueue[1] == 1 && secretqueue[0] == 1)
		{
			DeactivateAllLevels();
			levels[13].active = true;
		}
		if (secretqueue[8] == 1 && secretqueue[7] == 2 && secretqueue[6] == 3 && secretqueue[5] == 1 && secretqueue[4] == 2 && secretqueue[3] == 3 && secretqueue[2] == 1 && secretqueue[1] == 2 && secretqueue[0] == 1)
		{
			GameState.paxDemoMode = true;
			GameState.longDemoMode = false;
			messageMgr.AddMsg("ok!", new string[1] { "demo mode initialized!" }, clear: true, weak: true);
		}
		if (secretqueue[8] == 1 && secretqueue[7] == 3 && secretqueue[6] == 2 && secretqueue[5] == 1 && secretqueue[4] == 3 && secretqueue[3] == 2 && secretqueue[2] == 1 && secretqueue[1] == 3 && secretqueue[0] == 1)
		{
			GameState.longDemoMode = true;
			GameState.paxDemoMode = false;
			messageMgr.AddMsg("ok!", new string[1] { "demo 2 mode initialized!" }, clear: true, weak: true);
		}
	}

	public bool GetMessageActive()
	{
		return messageMgr.GetActive();
	}

	public void UpdateMessages()
	{
		messageMgr.Update(menuPlayer);
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			menuPlayer[i].Update();
		}
	}

	public void DrawMessages(SpriteBatch sprite)
	{
		messageMgr.Draw(sprite);
	}

	public void DrawAchievable(SpriteBatch sprite)
	{
		achievable.Draw(sprite);
	}

	public bool SavingActive()
	{
		return saving.Active();
	}

	public void UpdateSaving()
	{
		saving.Update();
	}

	public void DrawSaving(SpriteBatch sprite)
	{
		DrawSaving(sprite, center: false, -1f, -1f);
	}

	public void DrawSaving(SpriteBatch sprite, bool center, float a, float frame)
	{
		SpriteTools.BeginAlpha();
		saving.Draw(sprite, 0, center, a, frame);
		SpriteTools.End();
	}

	public void Update()
	{
		swimFrame += FMan.frameTime * 0.2f;
		frame += FMan.frameTime * 0.2f;
		if (frame > 6.28f)
		{
			frame -= 6.28f;
		}
		if (!pauseMode)
		{
			UpdateSecretQueue();
			if (GameState.state == GameState.State.Upsell)
			{
				return;
			}
		}
		for (int i = 0; i < blip.Length; i++)
		{
			blip[i].frame -= FMan.frameTime;
			if (blip[i].frame > 0f)
			{
				blip[i].loc += blip[i].traj * FMan.frameTime;
			}
		}
		for (int j = 0; j < menuPlayer.Length; j++)
		{
			menuPlayer[j].Update();
		}
		menuPlayer[Game1.mainPlayer[0]].active = true;
		if (pauseMode && owner == 1)
		{
			menuPlayer[Game1.mainPlayer[1]].active = true;
			menuPlayer[Game1.mainPlayer[0]].active = false;
		}
		if (levels[31].active || levels[29].active || levels[30].active || levels[48].active || levels[47].active || levels[35].active || levels[44].active || levels[38].active || levels[45].active)
		{
			for (int k = 0; k < menuPlayer.Length; k++)
			{
				if (!menuPlayer[k].active)
				{
					continue;
				}
				SignedInGamer signedInGamer = Gamer.SignedInGamers[(PlayerIndex)k];
				if (signedInGamer != null && !signedInGamer.IsSignedInToLive)
				{
					if (pauseMode)
					{
						SetLevel(LevelTitle.PauseMenu);
						messageMgr.AddMsg(YukiText.notConnectToXboxLive, new string[2]
						{
							YukiText.returningtoPause1,
							YukiText.returningtoPause2
						});
					}
					else
					{
						SetLevel(LevelTitle.MainMenu);
						messageMgr.AddMsg(YukiText.notConnectToXboxLive, new string[2]
						{
							YukiText.returningToMain1,
							YukiText.returningToMain2
						});
					}
					Game1.netSession.Dispose();
				}
			}
		}
		if (levels[28].active && levels[28].alpha > 0.9f)
		{
			for (int l = 0; l < 4; l++)
			{
				if ((flibitPort.GetInputDigital(l, flibitPort.InputAction.JumpAccept) || flibitPort.GetInputDigital(l, flibitPort.InputAction.PauseConfirm)) && Game1.mainPlayer[0] != l && Game1.mainPlayer[1] != l && Game1.mainPlayer[2] != l && Game1.mainPlayer[3] != l)
				{
					for (int slot = 1; slot < 4; slot++)
					{
						if (Game1.mainPlayer[slot] == -1)
						{
							Game1.mainPlayer[slot] = l;
							Game1.gamePlayerMgr.gamePlayer[slot].nameStr = null;
							Sound.PlaySnd(Sound.Category.FX, "sword1");
							break;
						}
					}
				}
			}
			_ = Game1.mainPlayer[1];
			_ = -1;
			for (int cs = 0; cs < 4; cs++)
			{
				int pad = Game1.mainPlayer[cs];
				if (pad < 0)
				{
					continue;
				}
				int dir = 0;
				if (menuPlayer[pad].keyLeft)
				{
					dir = -1;
				}
				else if (menuPlayer[pad].keyRight)
				{
					dir = 1;
				}
				if (dir != 0)
				{
					Game1.slotChar[cs] = (Game1.slotChar[cs] + dir + 4) % 4;
					Sound.PlaySnd(Sound.Category.FX, "sword1");
				}
			}
		}
		blockInput = false;
		if (Game1.netSession.IsClient() && !pauseMode)
		{
			blockInput = true;
			if (levels[46].active || levels[36].active)
			{
				blockInput = false;
			}
		}
		foreach (MenuLevel value in levels.Values)
		{
			value.Update();
		}
		for (int m = 0; m < inkBlot.Length; m++)
		{
			inkBlot[m].Update();
		}
		scrollGoalOffsetFrame -= FMan.realTime;
		if (scrollGoalOffsetFrame < 0f)
		{
			scrollGoalOffsetFrame = Rand.GetRandomFloat(0.5f, 2f);
			scrollGoalOffset = Rand.GetRandomVec2(-20f, 20f, -20f, 20f);
		}
		if (pauseMode)
		{
			if (transMode == TransitionMode.None)
			{
				if (owner == 1)
				{
					menuPlayer[Game1.mainPlayer[0]].active = false;
					menuPlayer[Game1.mainPlayer[1]].active = true;
				}
				if (GetStart() && ((!Game1.netSession.IsHost() && !Game1.netSession.IsClient()) || !remotePause))
				{
					Game1.menuMgr.UnPause();
				}
			}
		}
		else
		{
			float num = 1f;
			if (levels[22].active)
			{
				if (mainScreenAlpha > 0f)
				{
					mainScreenAlpha -= FMan.frameTime;
					if (mainScreenAlpha <= 0f)
					{
						Game1.sceneMgr.curScene = 0;
					}
					num *= mainScreenAlpha;
				}
				else
				{
					if (startScreenAlpha < 1f)
					{
						startScreenAlpha += FMan.frameTime;
					}
					num *= startScreenAlpha;
				}
			}
			else
			{
				if (Game1.sceneMgr.curScene == 0)
				{
					startScreenAlpha = 0.01f;
				}
				if (startScreenAlpha > 0f)
				{
					startScreenAlpha -= FMan.frameTime;
					if (startScreenAlpha <= 0f)
					{
						Game1.sceneMgr.curScene = 1;
					}
					num *= startScreenAlpha;
				}
				else
				{
					if (mainScreenAlpha < 1f)
					{
						mainScreenAlpha += FMan.frameTime;
					}
					num *= mainScreenAlpha;
				}
			}
			if (GameState.state != GameState.State.Playing)
			{
				Game1.sceneMgr.Update(num);
				Vector2 scroll = ScrollManager.scroll;
				float zoom = ScrollManager.zoom;
				ScrollManager.scroll = curScroll + scrollGoalOffsetAdd + menuPlayer[Game1.mainPlayer[0]].rVec * new Vector2(40f, -40f);
				ScrollManager.zoom = 1f;
				environ.Update(Game1.gameMap);
				ScrollManager.scroll = scroll;
				ScrollManager.zoom = zoom;
			}
		}
		if (transMode == TransitionMode.None)
		{
			return;
		}
		transFrame -= FMan.realTime;
		if (pauseMode)
		{
			transFrame -= FMan.realTime * 4f;
		}
		if (!Game1.loader.complete && transMode == TransitionMode.Out && transFrame <= 0.1f)
		{
			transFrame = 0.1f;
		}
		if (!(transFrame <= 0f))
		{
			return;
		}
		if (transMode == TransitionMode.Out)
		{
			switch (transGoal)
			{
			case TransitionGoal.Quit:
				Game1.mustExit = true;
				break;
			case TransitionGoal.YukiCampaign:
				Game1.levelMgr.NewLevel(transGoalLevel, 0, newGame: true);
				transMode = TransitionMode.None;
				GuideStuff.CheckLiveStart();
				break;
			case TransitionGoal.DishCampaign:
				Game1.levelMgr.NewLevel(transGoalLevel, 1, newGame: true);
				transMode = TransitionMode.None;
				GuideStuff.CheckLiveStart();
				break;
			case TransitionGoal.CoopCampaign:
				Game1.arcade.arcadeMode = Arcade.ArcadeMode.Off;
				Game1.levelMgr.NewLevel(transGoalLevel, 2, newGame: true);
				transMode = TransitionMode.None;
				GuideStuff.CheckLiveStart();
				break;
			case TransitionGoal.Arcade:
				Game1.levelMgr.NewLevel(transGoalLevel, 3, newGame: true);
				transMode = TransitionMode.None;
				GuideStuff.CheckLiveStart();
				break;
			case TransitionGoal.DishPractice:
				Game1.levelMgr.NewLevel(0, 6, newGame: true);
				transMode = TransitionMode.None;
				break;
			case TransitionGoal.YukiPractice:
				Game1.levelMgr.NewLevel(0, 5, newGame: true);
				transMode = TransitionMode.None;
				break;
			case TransitionGoal.DishChallenge:
				Game1.levelMgr.NewLevel(0, 4, newGame: true);
				transMode = TransitionMode.None;
				GuideStuff.CheckLiveStart();
				break;
			case TransitionGoal.ResetMenu:
				Game1.PvpStop();
				DeactivateAllLevels();
				if (GameState.paxDemoMode || GameState.longDemoMode)
				{
					levels[55].active = true;
				}
				else
				{
					levels[0].active = true;
				}
				ResetScene(1);
				transMode = TransitionMode.In;
				transFrame = 1f;
				Game1.storageMgr.storage[0].Read(1);
				pauseMode = false;
				break;
			case TransitionGoal.Lobby:
				GameState.state = GameState.State.Menu;
				DeactivateAllLevels();
				levels[36].active = true;
				ResetScene(1);
				transMode = TransitionMode.In;
				transFrame = 1f;
				pauseMode = false;
				break;
			case TransitionGoal.HostLobby:
				GameState.state = GameState.State.Menu;
				DeactivateAllLevels();
				levels[39].active = true;
				ResetScene(1);
				transMode = TransitionMode.In;
				transFrame = 1f;
				pauseMode = false;
				if (Game1.netSession.IsHost())
				{
					try
					{
						Game1.netSession.session.EndGame();
						break;
					}
					catch
					{
						break;
					}
				}
				break;
			case TransitionGoal.EndGame:
				GameState.state = GameState.State.Menu;
				DeactivateAllLevels();
				if (GameState.paxDemoMode || GameState.longDemoMode)
				{
					levels[55].active = true;
				}
				else
				{
					levels[0].active = true;
				}
				ResetScene(1);
				Game1.storageMgr.storage[0].Read(1);
				transMode = TransitionMode.In;
				transFrame = 1f;
				pauseMode = false;
				break;
			case TransitionGoal.RestartLevel:
				Game1.levelMgr.NewLevel(Game1.levelMgr.currentLevel, Game1.levelMgr.currentTrack);
				transMode = TransitionMode.None;
				break;
			case TransitionGoal.Continue:
				Game1.levelMgr.Continue();
				transMode = TransitionMode.None;
				break;
			default:
				transMode = TransitionMode.None;
				break;
			}
		}
		else
		{
			transMode = TransitionMode.None;
		}
	}

	public void UnPause()
	{
		UnPause(netInduced: false);
	}

	public void UnPause(bool netInduced)
	{
		GameState.state = GameState.State.Playing;
		Game1.transMgr.pauseResumeFrame = 1f;
		ScrollManager.zoom++;
		if (!netInduced && (Game1.netSession.IsHost() || Game1.netSession.IsClient()))
		{
			Game1.netSession.netGame.SendUnPause(Game1.netSession.session);
		}
		if (Game1.soloMgr.active)
		{
			Game1.soloMgr.Resume();
		}
		pauseMode = false;
	}

	public void MenuReset()
	{
		DeactivateAllLevels();
		if (GameState.paxDemoMode || GameState.longDemoMode)
		{
			levels[55].active = true;
		}
		else
		{
			levels[0].active = true;
		}
		ResetScene(1);
		transMode = TransitionMode.In;
		transFrame = 1f;
		pauseMode = false;
	}

	public void DeactivateAllLevels()
	{
		foreach (MenuLevel value in levels.Values)
		{
			value.active = false;
			value.alpha = 0f;
		}
	}

	public void SetLevel(LevelTitle goal)
	{
		foreach (MenuLevel value in levels.Values)
		{
			value.active = false;
			value.alpha = 0f;
		}
		levels[(int)goal].active = true;
		levels[(int)goal].alpha = 1f;
	}

	public void DrawBack(SpriteBatch sprite)
	{
		Vector2 scroll = ScrollManager.scroll;
		float zoom = ScrollManager.zoom;
		ScrollManager.scroll = curScroll + scrollGoalOffsetAdd + menuPlayer[Game1.mainPlayer[0]].rVec * new Vector2(40f, -40f);
		ScrollManager.zoom = 1f;
		SpriteTools.BeginAlpha();
		sprite.Draw(Game1.bgTex[0], new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
		Vector2 vector = new Vector2((float)map.xSize * 64f, (float)map.ySize * 64f);
		vector = ScrollManager.scroll / vector;
		vector -= new Vector2(0.5f, 0.5f);
		vector *= 128f;
		Game1.gameMap.haze = false;
		Game1.gameMap.fog = false;
		Game1.gameMap.drips = false;
		Game1.gameMap.glows = false;
		Game1.gameMap.rain = false;
		Game1.gameMap.strobe = false;
		Game1.gameMap.theme.theme = Themes.ThemeType.Marble;
		environ.Draw(sprite, Game1.gameMap);
		sprite.End();
		map.Draw(sprite, 0, 5, green: false, Game1.gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
		ScrollManager.scroll = scroll;
		ScrollManager.zoom = zoom;
		SpriteTools.BeginAlpha();
		for (int i = 0; i < inkBlot.Length; i++)
		{
			inkBlot[i].Draw(sprite);
		}
		foreach (MenuLevel value in levels.Values)
		{
			if (value.alpha > 0f)
			{
				value.DrawHeading(sprite);
			}
		}
		SpriteTools.End();
	}

	public bool GetDrawable()
	{
		for (int i = 0; i < levels.Count; i++)
		{
			if (levels[i].active || levels[i].alpha > 0f)
			{
				return true;
			}
		}
		return false;
	}

	public void Draw(GraphicsDeviceManager graphics, SpriteBatch sprite)
	{
		Draw(graphics, sprite, -1);
	}

	public void Draw(GraphicsDeviceManager graphics, SpriteBatch sprite, int threedee)
	{
		if (GameState.state != GameState.State.Playing)
		{
			Game1.gameMap.theme.UpdateColors();
			if (pauseMode)
			{
				graphics.GraphicsDevice.SetRenderTarget(Game1.menuTarg);
				graphics.GraphicsDevice.Clear(Color.Black);
				if (pauseMode)
				{
					Vector2 scroll = ScrollManager.scroll;
					float zoom = ScrollManager.zoom;
					ScrollManager.scroll = Game1.character[0].charUpdate.loc + new Vector2(50f, -50f) + scrollGoalOffsetAdd / 10f;
					ScrollManager.zoom = 6f;
					if (transMode == TransitionMode.In)
					{
						ScrollManager.zoom += transFrame;
					}
					GameRender.DrawNoShaders(graphics, Game1.character, Game1.gameMap, sprite, Game1.spriteMan, Game1.spritesTex);
					ScrollManager.zoom = zoom;
					ScrollManager.scroll = scroll;
				}
				else
				{
					DrawBack(sprite);
				}
				graphics.GraphicsDevice.SetRenderTarget(Game1.mainTarg);
				graphics.GraphicsDevice.Clear(new Color(0.9f, 0.8f, 0.7f, 1f));
				if (pauseMode)
				{
					menuEffect.Parameters["add"].SetValue(0.09f);
					menuEffect.Parameters["fac"].SetValue(3f);
					menuEffect.Parameters["glowX"].SetValue(0f);
					menuEffect.Parameters["glowY"].SetValue(1f);
				}
				else
				{
					menuEffect.Parameters["add"].SetValue(0.15f);
					menuEffect.Parameters["fac"].SetValue(3f);
					menuEffect.Parameters["glowX"].SetValue(glow.X);
					menuEffect.Parameters["glowY"].SetValue(glow.Y);
				}
				graphics.GraphicsDevice.Textures[1] = Game1.hatchText;
				SpriteTools.BeginAlpha(menuEffect);
				sprite.Draw(Game1.menuTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
				SpriteTools.End();
				graphics.GraphicsDevice.Textures[1] = null;
				graphics.GraphicsDevice.SetRenderTarget(Game1.threshTarg);
				SpriteTools.BeginOpaque();
				sprite.Draw(Game1.mainTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
				SpriteTools.End();
				switch (threedee)
				{
				case -1:
					graphics.GraphicsDevice.SetRenderTarget(null);
					break;
				case 0:
				case 1:
					graphics.GraphicsDevice.SetRenderTarget(Game1.threeDeeTarg[threedee]);
					break;
				}
				graphics.GraphicsDevice.Clear(new Color(0f, 0f, 0f, 1f));
				SpriteTools.BeginAlpha();
				sprite.Draw(Game1.mainTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, 0.7f));
				SpriteTools.End();
				SpriteTools.BeginAdditive();
				for (int i = 0; i < 4; i++)
				{
					sprite.Draw(Game1.threshTarg, new Rectangle(i * -8, i * -4, (int)ScrollManager.screenSize.X + i * 16, (int)ScrollManager.screenSize.Y + i * 9), new Color(0.98f, 0.99f, 1f, 0.15f));
				}
				SpriteTools.End();
			}
			else if (GameState.state != GameState.State.Playing && !(levels[20].alpha > 0.5f) && !(levels[19].alpha > 0.5f) && !(levels[21].alpha > 0.5f))
			{
				Game1.sceneMgr.Draw(graphics, sprite, threedee, overlay: false);
			}
		}
		SpriteTools.BeginAlpha();
		if ((levels[2].active || levels[12].active) && !Game1.loader.complete)
		{
			if (levels[2].active)
			{
				levels[2].alpha = 0f;
			}
			if (levels[12].active)
			{
				levels[12].alpha = 0f;
			}
		}
		foreach (MenuLevel value in levels.Values)
		{
			value.Draw(sprite, threedee);
		}
		if (transMode != TransitionMode.None)
		{
			float num = transFrame;
			if (transMode == TransitionMode.Out)
			{
				num = 1f - num;
			}
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, num));
		}
		else if (!messageMgr.GetActive())
		{
			if (!levels[22].active)
			{
				if (levels[31].active)
				{
					Game1.leaderBoard.DrawBottomRightButtons(sprite);
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.ViewGamercard, 1, 1f);
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Back, 0, 1f);
				}
				else if (levels[56].active)
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Continue, 0, 1f);
				}
				else if (levels[32].active)
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.X, BottomRightMessage.Msg.UnlockFullGame, 1, 1f);
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Cancel, 0, 1f);
				}
				else if (levels[6].active)
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Back, 1, 1f);
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.LT, BottomRightMessage.Msg.PreviousWeapon, 2, 1f);
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.RT, BottomRightMessage.Msg.NextWeapon, 0, 1f);
				}
				else if (levels[53].active)
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Back, 0, 1f);
				}
				else if (levels[7].active)
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Accept, 0, 1f);
				}
				else if (levels[27].active)
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Continue, 0, 1f);
				}
				else if (levels[39].active)
				{
					if (levels[39].selected < 2)
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.ViewGamercard, 1, 1f);
					}
					else
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Accept, 1, 1f);
					}
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Exit, 0, 1f);
				}
				else if (levels[36].active)
				{
					if (levels[36].selected < 2)
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.ViewGamercard, 1, 1f);
					}
					else
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Accept, 1, 1f);
					}
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Exit, 0, 1f);
				}
				else if (levels[33].active)
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Back, 0, 1f);
				}
				else if (levels[46].active)
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Accept, 1, 1f);
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Back, 0, 1f);
				}
				else if (Game1.netSession.IsClient())
				{
					if (pauseMode)
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Accept, 1, 1f);
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Back, 0, 1f);
					}
					else
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Exit, 0, 1f);
					}
				}
				else
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Accept, 1, 1f);
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Back, 0, 1f);
				}
			}
			if (!levels[22].active && !levels[32].active && GuideStuff.GetTrial())
			{
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.X, BottomRightMessage.Msg.UnlockFullGame, 3, 1f);
			}
		}
		for (int j = 0; j < blip.Length; j++)
		{
			if (blip[j].frame > 0f && blip[j].frame < 1f)
			{
				float num2 = 1f;
				if (blip[j].frame > 0.75f)
				{
					num2 = (1f - blip[j].frame) * 4f;
				}
				sprite.Draw(Game1.spritesTex, blip[j].loc, new Rectangle(832, 192, 64, 64), new Color(1f, 0f, 0f, blip[j].frame * 0.3f), 0f - blip[j].frame, new Vector2(32f, 32f), 0.3f * num2, SpriteEffects.None, 1f);
			}
		}
		sprite.End();
	}

	public void EnablePlayerTwo()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			menuPlayer[i].active = false;
		}
		menuPlayer[Game1.mainPlayer[0]].active = true;
		for (int slot = 1; slot < 4; slot++)
		{
			if (Game1.mainPlayer[slot] > -1)
			{
				try
				{
					menuPlayer[Game1.mainPlayer[slot]].active = true;
				}
				catch
				{
				}
			}
		}
	}

	public void EnablePlayerOne()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			menuPlayer[i].active = false;
		}
		menuPlayer[Game1.mainPlayer[0]].active = true;
	}

	public bool GetUp(MenuLevel lev)
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (!menuPlayer[i].active)
			{
				continue;
			}
			if (menuPlayer[i].keyUp)
			{
				Sound.PlaySnd(Sound.Category.FX, "throw");
				return true;
			}
			if ((lev.scrolling || lev.leaderboard) && menuPlayer[i].GetPageUp())
			{
				if (menuPlayer[i].newPage)
				{
					menuPlayer[i].newPage = false;
					Sound.PlaySnd(Sound.Category.FX, "throw");
				}
				return true;
			}
		}
		return false;
	}

	public bool GetHeldUp()
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyHeldUp)
			{
				return true;
			}
		}
		return false;
	}

	public bool GetHeldDown()
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyHeldDown)
			{
				return true;
			}
		}
		return false;
	}

	public bool GetStart()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyStart)
			{
				return true;
			}
		}
		return false;
	}

	public bool GetDown(MenuLevel lev)
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (!menuPlayer[i].active)
			{
				continue;
			}
			if (menuPlayer[i].keyDown)
			{
				Sound.PlaySnd(Sound.Category.FX, "swing");
				return true;
			}
			if ((lev.scrolling || lev.leaderboard) && menuPlayer[i].GetPageDown())
			{
				if (menuPlayer[i].newPage)
				{
					menuPlayer[i].newPage = false;
					Sound.PlaySnd(Sound.Category.FX, "swing");
				}
				return true;
			}
		}
		return false;
	}

	public bool GetYOption()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyYOption)
			{
				return true;
			}
		}
		return false;
	}

	public bool GetLS()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyLS)
			{
				return true;
			}
		}
		return false;
	}

	public bool GetRS()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyRS)
			{
				return true;
			}
		}
		return false;
	}

	public bool GetLeft()
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyLeft)
			{
				return true;
			}
		}
		return false;
	}

	public bool GetRight()
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyRight)
			{
				return true;
			}
		}
		return false;
	}

	public int GetUnlock()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyUnlock)
			{
				return i;
			}
		}
		return -1;
	}

	public bool GetAccept()
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && (menuPlayer[i].keyAccept || (!pauseMode && menuPlayer[i].keyStart)))
			{
				return true;
			}
		}
		return false;
	}

	public bool GetCancel()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].keyCancel)
			{
				return true;
			}
		}
		return false;
	}

	internal void EnableAll()
	{
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			menuPlayer[i].active = true;
		}
	}

	internal void NetGameQuitYouSure(LevelTitle levelTitle)
	{
		levels[(int)levelTitle].active = false;
		ClientQuitYouSure clientQuitYouSure = (ClientQuitYouSure)levels[46];
		clientQuitYouSure.backLev = (int)levelTitle;
		clientQuitYouSure.active = true;
	}

	internal void UpdateBlips(Vector2 blipVec, float size)
	{
		int num = 0;
		for (int i = 0; i < blip.Length; i++)
		{
			if (blip[i].frame <= 0f)
			{
				blip[i].frame = 1f;
				blip[i].loc = blipVec + Rand.GetRandomVec2((0f - size) / 2f, size / 2f, 4f, 32f);
				blip[i].traj = Rand.GetRandomVec2(-10f, 10f, -30f, 0f);
				num++;
				if (num >= 2)
				{
					break;
				}
			}
		}
	}

	internal void Pause(int ID)
	{
		GameState.state = GameState.State.Menu;
		pauseMode = true;
		remotePause = false;
		transMode = TransitionMode.In;
		transFrame = 1f;
		for (int i = 0; i < Game1.menuMgr.levels[4].item.Length; i++)
		{
			levels[4].item[i].alpha = 0f;
		}
		SetLevel(LevelTitle.PauseMenu);
		owner = 0;
		if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
		{
			Game1.netSession.netGame.SendPause(Game1.netSession.session);
		}
		else if (ID == 1)
		{
			owner = 1;
		}
		if (Game1.soloMgr.active)
		{
			Game1.soloMgr.Pause();
		}
	}

	internal int GetPlayers()
	{
		for (int i = 0; i < levels.Count; i++)
		{
			if (levels[i].active && levels[i].coopLev)
			{
				return 2;
			}
		}
		return 1;
	}

	internal void KillSaving()
	{
		saving.Kill();
	}

	internal bool GetSkipUp()
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].GetSkipUp())
			{
				return true;
			}
		}
		return false;
	}

	internal bool GetSkipDown()
	{
		if (blockInput)
		{
			return false;
		}
		for (int i = 0; i < menuPlayer.Length; i++)
		{
			if (menuPlayer[i].active && menuPlayer[i].GetSkipDown())
			{
				return true;
			}
		}
		return false;
	}
}
