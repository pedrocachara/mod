using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;

namespace Yuki_Win.menu;

public class MenuVideo
{
	public enum VideoPhase
	{
		NotYetStarted,
		Playing,
		Done
	}

	private Video video;

	private VideoPlayer player;

	private Texture2D videoTexture;

	public bool isInited;

	public VideoPhase videoPhase;

	public void Init(ContentManager Content)
	{
		video = Content.Load<Video>("vids/trailer240");
		player = new VideoPlayer();
		isInited = true;
	}

	public void Play()
	{
		player.Play(video);
	}

	public bool IsPlaying()
	{
		if (player.State == MediaState.Playing || player.State == MediaState.Paused)
		{
			return true;
		}
		return false;
	}

	public void Stop()
	{
		if (player.State == MediaState.Playing || player.State == MediaState.Paused)
		{
			player.Stop();
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		if (isInited && player.State != MediaState.Stopped)
		{
			SpriteTools.BeginAlpha();
			sprite.Draw(player.GetTexture(), new Rectangle(0, 0, 1280, 720), Color.White);
			SpriteTools.End();
		}
	}
}
