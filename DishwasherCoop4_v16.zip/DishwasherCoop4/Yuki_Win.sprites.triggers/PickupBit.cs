using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.triggers;

public class PickupBit : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.r = Rand.GetRandomFloat(0f, 6.28f);
		p.g = Rand.GetRandomFloat(-4f, 4f);
		p.alpha = true;
		p.frame = Rand.GetRandomFloat(0.1f, 0.25f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.traj = default;
		p.r += p.g * FMan.frameTime;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(704, 0, 160, 64), new Color(1f, 1f, 1f, p.frame * 0.75f), p.r, new Vector2(80f, 32f), (p.frame + 0.15f) * ScrollManager.cannedDepth[0] * 2f, SpriteEffects.None, 1f);
	}
}
