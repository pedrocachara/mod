using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.triggers;

public class Pickup : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.flags = flags;
		p.owner = owner;
		p.alpha = true;
		p.frame = 1f;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.frameTime;
		if (p.frame < 1f)
		{
			p.frame = 1f;
		}
		spriteMan.AddSprite(48, p.loc + new Vector2(0f, -40f), default, 0f, 0, 0);
		if (!(p.frame <= 1f))
		{
			return;
		}
		for (int i = 0; i < 2; i++)
		{
			if (!p.exists || (!Game1.character[i].GetMeta().isYuki && !Game1.character[i].GetMeta().isDish))
			{
				continue;
			}
			float num = 40f;
			float num2 = 90f;
			Vector2 loc = Game1.character[i].charUpdate.loc;
			if (loc.X > p.loc.X - num && loc.X < p.loc.X + num && loc.Y < p.loc.Y + 30f && loc.Y > p.loc.Y - num2)
			{
				if (p.owner > -1)
				{
					Game1.hud.DoPickups(p.flags, p.owner);
				}
				else
				{
					Game1.hud.DoPickups(p.flags);
				}
				Game1.gameMap.CurMap().scriptMgr.SetFlag("pickup");
				p.exists = false;
			}
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc + new Vector2(0f, -40f), 1f), new Rectangle(320, 0, 128, 128), new Color(0.4f, 0.4f, 1f, 1f), 0f, new Vector2(64f, 64f), Rand.GetRandomFloat(0.35f, 0.5f) * ScrollManager.cannedDepth[0] * 0.3f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc + new Vector2(0f, -40f), 1f), new Rectangle(320, 0, 128, 128), new Color(0.4f, 0.4f, 1f, 0.3f), 0f, new Vector2(64f, 64f), Rand.GetRandomFloat(0.35f, 0.5f) * ScrollManager.cannedDepth[0] * 0.7f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(320, 0, 128, 128), new Color(0.4f, 0.4f, 1f, 0.3f), 0f, new Vector2(64f, 64f), Rand.GetRandomFloat(0.5f, 1f) * new Vector2(2f, 0.8f) * ScrollManager.cannedDepth[0] * 0.3f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(320, 0, 128, 128), new Color(0.4f, 0.4f, 1f, 0.3f), 0f, new Vector2(64f, 64f), Rand.GetRandomFloat(0.5f, 1f) * new Vector2(2f, 0.8f) * ScrollManager.cannedDepth[0] * 0.15f, SpriteEffects.None, 1f);
		PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc + new Vector2(0f, -40f), 1f), 0.4f, 0.4f, 1f, 2f, 0.3f, 0f);
	}
}
