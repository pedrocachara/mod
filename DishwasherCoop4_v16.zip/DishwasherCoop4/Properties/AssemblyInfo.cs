using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("The Dishwasher - Vampire Smile")]
[assembly: AssemblyProduct("The Dishwasher - Vampire Smile")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright ©  2008")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTrademark("")]
[assembly: Guid("78023b9e-e56a-4c06-8fbe-32b48539a7dd")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
