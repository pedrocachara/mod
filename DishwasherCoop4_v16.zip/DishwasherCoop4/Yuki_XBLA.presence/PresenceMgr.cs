using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win;
using Yuki_Win.arcade;

namespace Yuki_XBLA.presence;

public class PresenceMgr
{
	private const string IDLE = "Idle";

	private const string MAIN_MENU = "Main Menu";

	private const string PREGAME_LOBBY = "In Lobby";

	private const string PRACTICE = "Practice Room";

	private const string DISH_CHALLENGE = "Dish Challenge";

	private const string YUKI_CAMPAIGN = "Yuki: ";

	private const string DISH_CAMPAIGN = "Dishwasher: ";

	private const string SOLO_ARCADE = "Solo Arcade: ";

	private const string COOP_ARCADE = "Co-op Arcade: ";

	private const string COOP_ARCADE_LIVE = "Online Co-op Arcade: ";

	private const string COOP_CAMPAIGN = "Co-op Campaign: ";

	private const string COOP_CAMPAIGN_LIVE = "Online Co-op Campaign: ";

	private static readonly string[] gameLevels = new string[13]
	{
		"Iffenhause Space Prison", "Lunar Wastes", "Omodo Crash", "Omodo's Execution", "The Pit", "Sunken Armory", "Hell Chambers", "Grim Tower", "Land Cruiser Stadium", "Forstadt Lobby",
		"Aqua Marina", "Justice Summit", "The Stagnant Nightmare"
	};

	private float updateFrame;

	public void Update()
	{
		updateFrame += FMan.frameTime;
		if (!(updateFrame > 1f))
		{
			return;
		}
		updateFrame--;
		for (int i = 0; i < Gamer.SignedInGamers.Count; i++)
		{
			if (Gamer.SignedInGamers[i].IsGuest)
			{
				continue;
			}
			int players = Game1.GetPlayers(local: true);
			bool flag = false;
			for (int j = 0; j < players; j++)
			{
				if (Gamer.SignedInGamers[i].PlayerIndex != (PlayerIndex)Game1.mainPlayer[j])
				{
					continue;
				}
				flag = true;
				if (GameState.state == GameState.State.Menu && !Game1.menuMgr.pauseMode)
				{
					if (Game1.menuMgr.levels[39].active || Game1.menuMgr.levels[36].active)
					{
						Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("In Lobby");
					}
					else
					{
						Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Main Menu");
					}
				}
				else if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
				{
					if (Game1.arcade.players == 1)
					{
						Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Solo Arcade: Level " + (Game1.levelMgr.currentLevel + 1));
					}
					else if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
					{
						Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Online Co-op Arcade: Level " + (Game1.levelMgr.currentLevel + 1));
					}
					else
					{
						Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Co-op Arcade: Level " + (Game1.levelMgr.currentLevel + 1));
					}
				}
				else if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.DishChallenge)
				{
					Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Dish Challenge");
				}
				else if (Game1.levelMgr.currentTrack == 0)
				{
					Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Yuki: " + gameLevels[Game1.levelMgr.currentLevel]);
				}
				else if (Game1.levelMgr.currentTrack == 1)
				{
					Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Dishwasher: " + gameLevels[Game1.levelMgr.currentLevel + 1]);
				}
				else if (Game1.levelMgr.currentTrack == 5 || Game1.levelMgr.currentTrack == 6)
				{
					Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Practice Room");
				}
				else if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
				{
					Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Online Co-op Campaign: " + gameLevels[Game1.levelMgr.currentLevel + 1]);
				}
				else
				{
					Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Co-op Campaign: " + gameLevels[Game1.levelMgr.currentLevel + 1]);
				}
			}
			if (!flag)
			{
				Gamer.SignedInGamers[i].Presence.SetPresenceModeStringEXT("Idle");
			}
		}
	}
}
