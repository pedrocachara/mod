using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.player;
using Yuki_Win.player.inventory;

namespace Yuki_Win.hud.pickups;

public class Pickups
{
	public float frame = -1f;

	public InvCatalog.InvItemName pickupToRemoveIfDeath;

	public InvCatalog.InvItemName item;

	public InvCatalog.InvItemName coopItem;

	public bool guitar;

	private float[] guitarPercentage = new float[2] { -1f, -1f };

	private bool used;

	private StringBuilder[] guitarString;

	private StringBuilder[] guitarPercString;

	public Pickups()
	{
		guitarString = new StringBuilder[8]
		{
			new StringBuilder(YukiText.solo_rockFail),
			new StringBuilder(YukiText.solo_skillDeficient),
			new StringBuilder(YukiText.solo_heavyMental),
			new StringBuilder(YukiText.solo_spuriousStrings),
			new StringBuilder(YukiText.solo_poisonousPotential),
			new StringBuilder(YukiText.solo_ninjaRiffer),
			new StringBuilder(YukiText.solo_sonicSamurai),
			new StringBuilder(YukiText.solo_perfect)
		};
		guitarPercString = new StringBuilder[101];
		for (int i = 0; i < guitarPercString.Length; i++)
		{
			guitarPercString[i] = new StringBuilder(i + "%");
		}
	}

	private int idxFromGuitarScore(float score)
	{
		float num = score * 100f;
		if (num < 60f)
		{
			return 0;
		}
		if (num < 70f)
		{
			return 1;
		}
		if (num < 80f)
		{
			return 2;
		}
		if (num < 85f)
		{
			return 3;
		}
		if (num < 90f)
		{
			return 4;
		}
		if (num < 95f)
		{
			return 5;
		}
		if (num < 100f)
		{
			return 6;
		}
		if (num >= 100f)
		{
			return 7;
		}
		return 0;
	}

	public void DoPickup(string name, bool used)
	{
		DoPickup(Game1.invCatalog.GetNameFromName(name), used, netInduced: false);
	}

	public void DoPickup(int name)
	{
		DoPickup((InvCatalog.InvItemName)name, used: false, netInduced: false);
	}

	public void DoPickup(InvCatalog.InvItemName name, bool used, bool netInduced)
	{
		if (Game1.netSession.IsHost())
		{
			Game1.netSession.netGame.SendPickup(Game1.netSession.session, (int)name, used);
		}
		if (Game1.netSession.IsClient() && !netInduced)
		{
			return;
		}
		item = name;
		coopItem = InvCatalog.InvItemName.None;
		this.used = used;
		frame = 0f;
		Sound.PlaySnd(Sound.Category.FX, used ? "slam" : "bell");
		guitar = false;
		for (int i = 0; i < 2; i++)
		{
			if (used)
			{
				Game1.hud.invMgr.UseItem(i, name);
			}
			else if (Game1.invCatalog.catalog[(int)name].section != Inv.InvTabSection.Progression && name != InvCatalog.InvItemName.PsychoPick && name != InvCatalog.InvItemName.None && name != InvCatalog.InvItemName.Dummy)
			{
				Game1.hud.invMgr.AddItem(i, name, 1);
				pickupToRemoveIfDeath = name;
			}
		}
	}

	public void DoPickup(int name, int coopName, bool netInduced)
	{
		if (Game1.netSession.IsHost())
		{
			Game1.netSession.netGame.SendCoopPickup(Game1.netSession.session, name, coopName);
		}
		if (!Game1.netSession.IsClient() || netInduced)
		{
			item = (InvCatalog.InvItemName)name;
			coopItem = (InvCatalog.InvItemName)coopName;
			used = false;
			frame = 0f;
			Sound.PlaySnd(Sound.Category.FX, used ? "slam" : "bell");
			guitar = false;
		}
	}

	public void DoGuitar(float perc)
	{
		DoGuitar(perc, -1f);
	}

	public void DoGuitar(float perc1, float perc2)
	{
		guitarPercentage[0] = perc1;
		guitarPercentage[1] = perc2;
		guitar = true;
		frame = 0f;
		Sound.PlaySnd(Sound.Category.FX, "slam");
	}

	public void Die()
	{
		if (pickupToRemoveIfDeath != InvCatalog.InvItemName.None)
		{
			for (int i = 0; i < 2; i++)
			{
				Game1.hud.invMgr.UseItem(i, pickupToRemoveIfDeath);
			}
			pickupToRemoveIfDeath = InvCatalog.InvItemName.None;
		}
	}

	public void ResetDeath()
	{
		pickupToRemoveIfDeath = InvCatalog.InvItemName.None;
	}

	public void Update()
	{
		if (frame < 0f)
		{
			return;
		}
		frame += FMan.frameTime;
		if (!(frame > 4f))
		{
			return;
		}
		if (Game1.gameMap.CurMap().scriptMgr.wait > 0f && Game1.gameMap.CurMap().scriptMgr.wait <= 1f)
		{
			Game1.gameMap.CurMap().scriptMgr.wait = 0f;
		}
		frame = -1f;
		if (guitar)
		{
			if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
			{
				MakeGuitarGoldFarm(bow: true, guitarPercentage[0]);
				MakeGuitarGoldFarm(bow: false, guitarPercentage[0]);
			}
			else if (guitarPercentage[1] > -1f)
			{
				MakeGuitarGoldFarm(bow: true, guitarPercentage[0]);
				MakeGuitarGoldFarm(bow: false, guitarPercentage[1]);
			}
			else if (Game1.levelMgr.currentTrack == 1)
			{
				MakeGuitarGoldFarm(bow: false, guitarPercentage[0]);
			}
			else
			{
				MakeGuitarGoldFarm(bow: true, guitarPercentage[0]);
			}
		}
	}

	private void MakeGuitarGoldFarm(bool bow, float size)
	{
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (Game1.character[i].exists)
			{
				if (Game1.character[i].GetMeta().isGuitar && !bow)
				{
					MakeGoldFarm(i, size);
				}
				if (Game1.character[i].GetMeta().isViolin && bow)
				{
					MakeGoldFarm(i, size);
				}
			}
		}
	}

	private void MakeGoldFarm(int i, float size)
	{
		Game1.spriteMan.AddSprite(68, Game1.character[i].charUpdate.loc + new Vector2(0f, -40f), default, size * 100f, 0, 0);
	}

	private bool TryAddPick(int idx)
	{
		if (guitarPercentage[idx] >= 0.6f)
		{
			Game1.gamePlayerMgr.gamePlayer[idx].picks++;
			return true;
		}
		return false;
	}

	public bool IsActive()
	{
		return frame >= 0f;
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		if (guitar)
		{
			DrawGuitar(sprite, threedee);
		}
		else if (coopItem == InvCatalog.InvItemName.None)
		{
			SingleDraw(sprite, threedee);
		}
		else
		{
			DoubleDraw(sprite, threedee);
		}
	}

	private void DrawGuitar(SpriteBatch sprite, int threedee)
	{
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		if (frame < 0f)
		{
			return;
		}
		float num = 0f;
		if (frame < 0.5f)
		{
			num = frame * 2f;
		}
		else
		{
			num = ((!(frame < 3.5f)) ? ((4f - frame) * 2f) : 1f);
		}
		sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, num * 0.5f));
		float num2 = 1f;
		if (frame < 0.5f)
		{
			num2 = (0.5f - frame) * 10f + 1f;
		}
		else
		{
			num2 = ((!(frame < 3.5f)) ? ((4f - frame) * 2f) : 1f);
		}
		num2 *= 3f;
		int num3 = idxFromGuitarScore(guitarPercentage[0]);
		for (int i = 0; i < 5; i++)
		{
			_ = Game1.invCatalog.catalog[(int)item].name.Length;
			float jStringSpace = Text.GetJStringSpace(Game1.invCatalog.catalog[(int)item].name, 8f);
			float num4 = 1f;
			if (jStringSpace < 1500f)
			{
				num4 = 1500f / jStringSpace;
			}
			Text.DrawJText(sprite, new Vector2((i % 2 == 0) ? (-100f - frame * 20f) : (1380f + frame * 20f), i * (int)(200f * num4) - 50) + vector * 0.7f, guitarString[num3], new Color(1f, 1f, 1f, num * 0.08f), 8f * num4, (i % 2 != 0) ? 2 : 0);
		}
		if (guitarPercentage[1] > -1f)
		{
			for (int j = 0; j < 2; j++)
			{
				for (int k = 0; k < 2; k++)
				{
					float num5 = ((k == 0) ? 0f : 1f);
					Vector2 vector2 = new Vector2(-300f, 0f);
					if (j == 1)
					{
						vector2 += new Vector2(600f, 100f);
					}
					Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 200f) - new Vector2(15f, 15f) * k - new Vector2(0f, num2 * 20f) + vector2 + vector, guitarPercString[(int)(guitarPercentage[j] * 100f)], new Color(num5, num5, num5, num * ((k == 0) ? 0.5f : 1f)), (8f + num2 * 2f) / 2f, 1);
					Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 380f) - new Vector2(15f, 15f) * k + vector2 + vector, guitarString[idxFromGuitarScore(guitarPercentage[j])], new Color(num5, num5, num5, num * ((k == 0) ? 0.5f : 1f)), (1f + num2 * 1f) / 2f, 1);
				}
			}
		}
		else
		{
			for (int l = 0; l < 2; l++)
			{
				float num6 = ((l == 0) ? 0f : 1f);
				Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 200f) - new Vector2(15f, 15f) * l - new Vector2(0f, num2 * 20f) + vector, guitarPercString[(int)(guitarPercentage[0] * 100f)], new Color(num6, num6, num6, num * ((l == 0) ? 0.5f : 1f)), (10f + num2 * 2f) / 2f, 1);
				Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 420f) - new Vector2(15f, 15f) * l + vector, guitarString[num3], new Color(num6, num6, num6, num * ((l == 0) ? 0.5f : 1f)), (3f + num2 * 2f) / 2f, 1);
			}
		}
	}

	public void SingleDraw(SpriteBatch sprite, int threedee)
	{
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		if (frame < 0f)
		{
			return;
		}
		float num = 0f;
		if (frame < 0.5f)
		{
			num = frame * 2f;
		}
		else
		{
			num = ((!(frame < 3.5f)) ? ((4f - frame) * 2f) : 1f);
		}
		sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, num * 0.5f));
		int idx = Game1.invCatalog.catalog[(int)item].idx;
		idx = (int)item;
		float num2 = 1f;
		if (frame < 0.5f)
		{
			num2 = (0.5f - frame) * 10f + 1f;
		}
		else
		{
			num2 = ((!(frame < 3.5f)) ? ((4f - frame) * 2f) : 1f);
		}
		num2 *= 3f;
		for (int i = 0; i < 5; i++)
		{
			_ = Game1.invCatalog.catalog[(int)item].name.Length;
			float jStringSpace = Text.GetJStringSpace(Game1.invCatalog.catalog[(int)item].name, 8f);
			float num3 = 1f;
			if (jStringSpace < 1500f)
			{
				num3 = 1500f / jStringSpace;
			}
			Text.DrawJText(sprite, new Vector2((i % 2 == 0) ? (-100f - frame * 20f) : (ScrollManager.screenSize.X + 100f + frame * 20f), i * (int)(200f * num3) - 50) + vector * 0.7f, Game1.invCatalog.catalog[(int)item].name, new Color(1f, 1f, 1f, num * 0.08f), 8f * num3, (i % 2 != 0) ? 2 : 0);
		}
		sprite.Draw(Game1.itemsTex, ScrollManager.screenSize / 2f + vector * 0.9f, Game1.invCatalog.GetInvitemRect((InvCatalog.InvItemName)idx), new Color(0f, 0f, 0f, num * 0.2f), -0.5f, new Vector2(64f, 64f) * 2f, (14f + num2 * 2f) / 2f / 2f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.itemsTex, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y / 2f - 60f) + new Vector2(15f, 15f) + vector, Game1.invCatalog.GetInvitemRect((InvCatalog.InvItemName)idx), new Color(0f, 0f, 0f, num * 0.4f), 0f, new Vector2(64f, 64f) * 2f, num2 / 2f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.itemsTex, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y / 2f - 60f) + vector, Game1.invCatalog.GetInvitemRect((InvCatalog.InvItemName)idx), new Color(1f, 1f, 1f, num), 0f, new Vector2(64f, 64f) * 2f, num2 / 2f, SpriteEffects.None, 1f);
		if (num > 0.5f)
		{
			Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y - 220f) + new Vector2(3f, 3f) + vector, used ? Game1.invCatalog.catalog[(int)item].usedStr : Game1.invCatalog.catalog[(int)item].gotStr, new Color(0f, 0f, 0f, num - 0.5f), 1.3f, 1);
			Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y - 220f) + vector, used ? Game1.invCatalog.catalog[(int)item].usedStr : Game1.invCatalog.catalog[(int)item].gotStr, new Color(1f, 1f, 1f, num * 2f - 1f), 1.3f, 1);
		}
	}

	public void DoubleDraw(SpriteBatch sprite, int threedee)
	{
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		if (frame < 0f)
		{
			return;
		}
		float num = 0f;
		if (frame < 0.5f)
		{
			num = frame * 2f;
		}
		else
		{
			num = ((!(frame < 3.5f)) ? ((4f - frame) * 2f) : 1f);
		}
		sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, num * 0.5f));
		int idx = Game1.invCatalog.catalog[(int)item].idx;
		idx = (int)item;
		float num2 = 1f;
		if (frame < 0.5f)
		{
			num2 = (0.5f - frame) * 10f + 1f;
		}
		else
		{
			num2 = ((!(frame < 3.5f)) ? ((4f - frame) * 2f) : 1f);
		}
		num2 *= 3f;
		for (int i = 0; i < 5; i++)
		{
			_ = Game1.invCatalog.catalog[(int)item].name.Length;
			float jStringSpace = Text.GetJStringSpace(Game1.invCatalog.catalog[(int)item].name, 8f);
			float num3 = 1f;
			if (jStringSpace < 1500f)
			{
				num3 = 1500f / jStringSpace;
			}
			Text.DrawJText(sprite, new Vector2((i % 2 == 0) ? (-100f - frame * 20f) : (ScrollManager.screenSize.X + 100f + frame * 20f), i * (int)(200f * num3) - 50) + vector * 0.7f, Game1.invCatalog.catalog[(int)item].name, new Color(1f, 1f, 1f, num * 0.08f), 8f * num3, (i % 2 != 0) ? 2 : 0);
		}
		for (int j = 0; j < 2; j++)
		{
			if ((j != 0 || item != InvCatalog.InvItemName.Dummy) && (j != 1 || coopItem != InvCatalog.InvItemName.Dummy))
			{
				try
				{
					idx = ((j == 0) ? Game1.invCatalog.catalog[(int)item].idx : Game1.invCatalog.catalog[(int)coopItem].idx);
					sprite.Draw(Game1.itemsTex, new Vector2(ScrollManager.screenSize.X * (float)(j + 1) * 0.33f, ScrollManager.screenSize.Y / 2f) + vector * 0.9f, Game1.invCatalog.GetInvitemRect((InvCatalog.InvItemName)idx), new Color(0f, 0f, 0f, num * 0.2f), -0.5f, new Vector2(64f, 64f) * 2f, (14f + num2 * 2f) / 2f / 2f, SpriteEffects.None, 1f);
				}
				catch
				{
				}
			}
		}
		for (int k = 0; k < 2; k++)
		{
			if ((k != 0 || item != InvCatalog.InvItemName.Dummy) && (k != 1 || coopItem != InvCatalog.InvItemName.Dummy))
			{
				idx = ((k == 0) ? Game1.invCatalog.catalog[(int)item].idx : Game1.invCatalog.catalog[(int)coopItem].idx);
				sprite.Draw(Game1.itemsTex, new Vector2(ScrollManager.screenSize.X * (float)(k + 1) * 0.33f, ScrollManager.screenSize.Y / 2f - 60f) + new Vector2(15f, 15f) + vector, Game1.invCatalog.GetInvitemRect((k == 0) ? item : coopItem), new Color(0f, 0f, 0f, num * 0.4f), 0f, new Vector2(64f, 64f) * 2f, num2 / 2f, SpriteEffects.None, 1f);
				sprite.Draw(Game1.itemsTex, new Vector2(ScrollManager.screenSize.X * (float)(k + 1) * 0.33f, ScrollManager.screenSize.Y / 2f - 60f) + vector, Game1.invCatalog.GetInvitemRect((k == 0) ? item : coopItem), new Color(1f, 1f, 1f, num), 0f, new Vector2(64f, 64f) * 2f, num2 / 2f, SpriteEffects.None, 1f);
			}
		}
		if (!(num > 0.5f))
		{
			return;
		}
		for (int l = 0; l < 2; l++)
		{
			if ((l != 0 || item != InvCatalog.InvItemName.Dummy) && (l != 1 || coopItem != InvCatalog.InvItemName.Dummy))
			{
				Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y - 220f + (float)l * 50f) + new Vector2(3f, 3f) + vector, used ? Game1.invCatalog.catalog[(int)((l == 0) ? item : coopItem)].usedStr : Game1.invCatalog.catalog[(int)((l == 0) ? item : coopItem)].gotStr, new Color(0f, 0f, 0f, num - 0.5f), 1.3f, 1);
				Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y - 220f + (float)l * 50f) + vector, used ? Game1.invCatalog.catalog[(int)((l == 0) ? item : coopItem)].usedStr : Game1.invCatalog.catalog[(int)((l == 0) ? item : coopItem)].gotStr, new Color(1f, 1f, 1f, num * 2f - 1f), 1.3f, 1);
			}
		}
	}
}
