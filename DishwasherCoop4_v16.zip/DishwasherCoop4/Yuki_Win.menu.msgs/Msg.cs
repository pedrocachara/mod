using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.hud;

namespace Yuki_Win.menu.msgs;

public class Msg
{
	public const int RETRY_STORAGE_NONE = 0;

	public const int RETRY_STORAGE_ENDLEVEL = 1;

	public const int RETRY_STORAGE_OVERALL = 2;

	public const int RETRY_STORAGE_WRITE = 3;

	public const int RETRY_ACHIEVOS = 4;

	public const int CHECK_FOR_DISCONNECT_NONE = 0;

	public const int CHECK_FOR_DISCONNECT_GAME_ENDED = 1;

	public const int CHECK_FOR_DISCONNECT_CANTCREATE = 2;

	public StringBuilder title;

	public StringBuilder[] message;

	public float alpha;

	public bool active;

	public bool weak;

	public int canRetryStorage;

	public int checkForDisconnect;

	public float initFrame;

	public float autoTimeOut;

	public int altControllerControl = -1;

	public void Update()
	{
		if (active)
		{
			if (alpha < 1f)
			{
				alpha += FMan.frameTime * 10f;
			}
		}
		else if (alpha > 0f)
		{
			alpha -= FMan.frameTime * 10f;
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		if (initFrame > 0f)
		{
			sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f, new Rectangle(832, 192, 64, 64), new Color(1f, 1f, 1f, alpha), Game1.menuMgr.messageMgr.rotation, new Vector2(32f, 32f), 0.9f, SpriteEffects.None, 1f);
			return;
		}
		sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f, new Rectangle(832, 192, 64, 64), new Color(1f, 1f, 1f, alpha * 0.35f), Game1.menuMgr.messageMgr.rotation, new Vector2(32f, 32f), 5f, SpriteEffects.None, 1f);
		DrawQuadrants(sprite);
		Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y * 0.27f), title, new Color(1f, 0.9f, 0.8f, alpha), 1f, 1);
		for (int i = 0; i < message.Length; i++)
		{
			Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y * 0.41f + (float)i * 30f), message[i], new Color(1f, 1f, 1f, alpha), 1f, 1);
		}
		if (alpha >= 1f)
		{
			switch (canRetryStorage)
			{
			case 4:
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.Close, 1, 1f);
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.Y, BottomRightMessage.Msg.Retry, 0, 1f);
				break;
			case 1:
			case 2:
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.ContinueWithoutSaving, 0, 1f);
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.Y, BottomRightMessage.Msg.SelectStorageDevice, 1, 1f);
				break;
			case 0:
			case 3:
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Close, 0, 1f);
				break;
			}
		}
	}

	private void DrawQuadrants(SpriteBatch sprite)
	{
	}
}
