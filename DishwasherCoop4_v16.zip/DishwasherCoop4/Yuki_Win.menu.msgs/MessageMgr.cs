using System.Collections.Generic;
using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.guidestuff;

namespace Yuki_Win.menu.msgs;

public class MessageMgr
{
	private List<Msg> messageList;

	private float alpha;

	public float rotation;

	public MessageMgr()
	{
		messageList = new List<Msg>();
	}

	public void AddMsg(string title, string[] msg)
	{
		AddMsg(title, msg, clear: false, weak: false, 0, 0, -1);
	}

	public void AddMsg(string title, string[] msg, bool clear, bool weak)
	{
		AddMsg(title, msg, clear, weak, 0, 0, -1);
	}

	public void AddMsg(string title, string[] msg, bool clear, bool weak, int checkForDisconnect)
	{
		AddMsg(title, msg, clear, weak, checkForDisconnect, 0, -1);
	}

	public void AddMsg(string title, string[] msg, bool clear, bool weak, int checkForDisconnect, int canRetryStorage)
	{
		AddMsg(title, msg, clear, weak, checkForDisconnect, canRetryStorage, -1);
	}

	public void AddMsg(string title, string[] msg, bool clear, bool weak, int checkForDisconnect, int canRetryStorage, int altControl)
	{
		if (clear)
		{
			messageList.Clear();
		}
		Msg msg2 = new Msg();
		msg2.title = new StringBuilder(title);
		msg2.message = new StringBuilder[msg.Length];
		if (weak)
		{
			msg2.weak = true;
		}
		msg2.checkForDisconnect = checkForDisconnect;
		msg2.canRetryStorage = canRetryStorage;
		msg2.initFrame = 2f;
		msg2.autoTimeOut = 0f;
		msg2.altControllerControl = altControl;
		for (int i = 0; i < msg.Length; i++)
		{
			msg2.message[i] = new StringBuilder(msg[i]);
		}
		if (messageList.Count <= 0)
		{
			msg2.active = true;
		}
		else if (messageList[0].title.ToString() == title)
		{
			return;
		}
		messageList.Add(msg2);
		Sound.PlaySnd(Sound.Category.FX, "sword1");
	}

	public bool GetActive()
	{
		if (GameState.state == GameState.State.Credits || GameState.state == GameState.State.Upsell)
		{
			return false;
		}
		if (messageList.Count > 0)
		{
			return true;
		}
		return false;
	}

	public void Update(MenuPlayer[] menuPlayer)
	{
		if (GameState.state == GameState.State.Credits || GameState.state == GameState.State.Upsell)
		{
			return;
		}
		if (messageList.Count > 0)
		{
			rotation += FMan.realTime;
			if (rotation > 6.28f)
			{
				rotation -= 6.28f;
			}
			if (alpha < 1f)
			{
				alpha += FMan.frameTime * 10f;
			}
			messageList[0].Update();
			messageList[0].autoTimeOut += FMan.realTime;
			if (messageList[0].weak && messageList.Count > 1)
			{
				messageList[0].active = false;
				messageList[0].alpha = 0f;
			}
			if (messageList[0].initFrame > 0f)
			{
				messageList[0].initFrame -= FMan.realTime;
			}
			if (messageList[0].checkForDisconnect > 0)
			{
				for (int i = 0; i < menuPlayer.Length; i++)
				{
					if (!menuPlayer[i].active)
					{
						continue;
					}
					SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(i);
					if (signedInGamerAtIndex != null && !signedInGamerAtIndex.IsSignedInToLive)
					{
						switch (messageList[0].checkForDisconnect)
						{
						case 1:
							messageList[0].title = new StringBuilder(YukiText.gameEnded);
							messageList[0].message = new StringBuilder[4]
							{
								new StringBuilder(YukiText.disconnectedFromXboxLive),
								new StringBuilder(""),
								new StringBuilder(YukiText.returningToMultiplayer1),
								new StringBuilder(YukiText.returningToMultiplayer2)
							};
							break;
						case 2:
							messageList[0].title = new StringBuilder(YukiText.cantHost);
							messageList[0].message = new StringBuilder[5]
							{
								new StringBuilder(YukiText.checkXboxLiveTry1),
								new StringBuilder(YukiText.checkXboxLiveTry2),
								new StringBuilder(""),
								new StringBuilder(YukiText.returningToMain1),
								new StringBuilder(YukiText.returningToMain2)
							};
							break;
						}
					}
				}
			}
			if (messageList[0].active && messageList[0].alpha >= 1f)
			{
				if (messageList[0].initFrame <= 0f)
				{
					if (Game1.menuMgr.pauseMode)
					{
						for (int j = 0; j < menuPlayer.Length; j++)
						{
							Game1.menuMgr.menuPlayer[j].active = false;
						}
						Game1.menuMgr.menuPlayer[Game1.mainPlayer[Game1.menuMgr.owner]].active = true;
					}
					else
					{
						Game1.menuMgr.menuPlayer[Game1.mainPlayer[0]].active = true;
					}
					for (int k = 0; k < menuPlayer.Length; k++)
					{
						if (!menuPlayer[k].active && !Game1.menuMgr.levels[22].active && k != messageList[0].altControllerControl)
						{
							continue;
						}
						if (messageList[0].canRetryStorage > 0)
						{
							if (messageList[0].canRetryStorage == 4)
							{
								if (menuPlayer[k].keyCancel)
								{
									messageList[0].active = false;
									Sound.PlaySnd(Sound.Category.FX, "block");
								}
								else if (menuPlayer[k].keyYOption)
								{
									messageList[0].active = false;
									Sound.PlaySnd(Sound.Category.FX, "block");
									Game1.achievementMgr.RetryAllAchievements();
								}
							}
							else if (messageList[0].canRetryStorage == 1)
							{
								if (!menuPlayer[k].keyAccept)
								{
									if (menuPlayer[k].keyCancel)
									{
										messageList[0].active = false;
										Sound.PlaySnd(Sound.Category.FX, "block");
										Game1.hud.RetryEndLevelNoSave();
									}
									else if (menuPlayer[k].keyYOption)
									{
										messageList[0].active = false;
										Sound.PlaySnd(Sound.Category.FX, "block");
									}
								}
							}
							else if (messageList[0].canRetryStorage == 2)
							{
								if (!menuPlayer[k].keyAccept)
								{
									if (menuPlayer[k].keyCancel)
									{
										messageList[0].active = false;
										Sound.PlaySnd(Sound.Category.FX, "block");
									}
									else if (menuPlayer[k].keyYOption)
									{
										messageList[0].active = false;
										Sound.PlaySnd(Sound.Category.FX, "block");
									}
								}
							}
							else if (messageList[0].canRetryStorage == 3 && menuPlayer[k].keyAccept)
							{
								messageList[0].active = false;
								Sound.PlaySnd(Sound.Category.FX, "block");
							}
						}
						else if (menuPlayer[k].keyAccept)
						{
							messageList[0].active = false;
							Sound.PlaySnd(Sound.Category.FX, "block");
						}
						else if (flibitPort.IsUserConnected(k) && flibitPort.GetInputDigital(k, flibitPort.InputAction.JumpAccept))
						{
							messageList[0].active = true;
						}
					}
				}
			}
			else if (messageList[0].alpha <= 0f)
			{
				messageList.Remove(messageList[0]);
				if (messageList.Count > 0)
				{
					messageList[0].active = true;
					messageList[0].initFrame = 0.1f;
				}
			}
		}
		if (messageList.Count == 1 && !messageList[0].active)
		{
			alpha = messageList[0].alpha;
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		if (messageList.Count <= 0)
		{
			return;
		}
		sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, alpha * 0.9f));
		sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f, new Rectangle(832, 192, 64, 64), new Color(1f, 1f, 1f, alpha * 0.25f), 0f - Game1.menuMgr.messageMgr.rotation, new Vector2(32f, 32f), 6f, SpriteEffects.FlipHorizontally, 1f);
		for (int i = 0; i < messageList.Count; i++)
		{
			if (messageList[i].alpha > 0f)
			{
				messageList[i].Draw(sprite);
			}
		}
	}

	internal void ResetFrame()
	{
		if (messageList.Count > 0 && messageList[0].initFrame < 0.5f)
		{
			messageList[0].initFrame = 0.5f;
		}
	}

	internal void Kill()
	{
		messageList.Clear();
	}
}
