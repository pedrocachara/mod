using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.freakingLasers;

internal class LaserSrc : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.owner = owner;
		p.alpha = true;
		p.frame = 0.3f;
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(256, 0, 64, 64), new Color(new Vector4(1f, 0.2f, 0.1f, 1f * p.frame * 1f)), 0f, new Vector2(32f, 32f), p.size * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
	}
}
