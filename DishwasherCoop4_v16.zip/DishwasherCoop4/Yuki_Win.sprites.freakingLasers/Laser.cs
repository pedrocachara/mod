using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;

namespace Yuki_Win.sprites.freakingLasers;

internal class Laser : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.owner = owner;
		p.hitter = true;
		p.alpha = true;
		p.frame = 0.3f;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.frame = -1f;
		}
		else if (Game1.gameMap.CurMap().TestCol(p.loc + p.traj * 0.02f))
		{
			p.frame = -1f;
		}
		if (p.frame < 0f)
		{
			Vector2 vector = p.loc - p.traj * FMan.frameTime;
			for (int i = 0; i < 10; i++)
			{
				spriteMan.AddSprite(102, vector + p.traj * 0.03f, -p.traj * Rand.GetRandomFloat(0f, 0.2f) + Rand.GetRandomVec2(-30f, 30f, -30f, 30f), 0.1f, 0, 0);
			}
			Sound.PlaySnd(Sound.Category.FX, "plasmahit");
		}
		p.rotation = Trig.GetAngle(default, p.traj);
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float x = 1f;
		if (p.frame > 0.2f)
		{
			x = (0.3f - p.frame) * 10f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(448, 32, 128, 32), new Color(new Vector4(1f, 0.2f, 0.1f, 1f)), p.rotation, new Vector2(64f, 16f) * Rand.GetRandomFloat(0.5f, 1f), new Vector2(x, Rand.GetRandomFloat(0f, 0.25f)) * ScrollManager.cannedDepth[0] * 0.8f, SpriteEffects.None, 1f);
	}
}
