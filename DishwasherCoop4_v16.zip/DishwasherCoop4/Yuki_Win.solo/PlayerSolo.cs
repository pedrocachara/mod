using director;
using GuitarEdit.guitar;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.player;

namespace Yuki_Win.solo;

public class PlayerSolo
{
	public enum NodeStatus
	{
		New,
		Hit,
		Missed
	}

	private const string ROCK1 = "rock1";

	private const string ROCK2 = "rock2";

	private const string ROCK3 = "rock3";

	private const string ROCK4 = "rock4";

	private const string ROCK1PICK = "rock1pick";

	private const string ROCK2PICK = "rock2pick";

	private const string ROCK3PICK = "rock3pick";

	private const string ROCK4PICK = "rock4pick";

	private const string ROCK1BOW = "rock1bow";

	private const string ROCK2BOW = "rock2bow";

	private const string ROCK3BOW = "rock3bow";

	private const string ROCK4BOW = "rock4bow";

	private const string ROCK1BOW2 = "rock1bow2";

	private const string ROCK2BOW2 = "rock2bow2";

	private const string ROCK3BOW2 = "rock3bow2";

	private const string ROCK4BOW2 = "rock4bow2";

	private const string ROCK1TO2 = "rock1to2";

	private const string ROCK2TO3 = "rock2to3";

	private const string ROCK3TO4 = "rock3to4";

	private const string ROCK4TO3 = "rock4to3";

	private const string ROCK3TO2 = "rock3to2";

	private const string ROCK2TO1 = "rock2to1";

	private const string ROCKIN = "rockin";

	private const string ROCKOUT = "rockout";

	private const int GUITAR_A = 0;

	private const int GUITAR_B = 1;

	private const int GUITAR_Y = 2;

	private const int GUITAR_X = 3;

	public bool active;

	public NodeStatus[] nodeStatus = new NodeStatus[512];

	private bool successAudio;

	public int hitCount;

	public int missedCount;

	public int ID;

	public static string SOLO_BG = "solo_bg";

	public static string SOLO_FG = "solo_fg";

	public static string SOLO_VG = "solo_vg";

	private GuitarSprite[] guitarSprite;

	private bool bowStroke;

	public int difficulty;

	public int guitarControllerIdx;

	public PlayerSolo(int ID)
	{
		nodeStatus = new NodeStatus[512];
		guitarSprite = new GuitarSprite[64];
		for (int i = 0; i < guitarSprite.Length; i++)
		{
			guitarSprite[i] = new GuitarSprite();
		}
		this.ID = ID;
	}

	public void Reset()
	{
		for (int i = 0; i < nodeStatus.Length; i++)
		{
			nodeStatus[i] = NodeStatus.New;
		}
		for (int j = 0; j < guitarSprite.Length; j++)
		{
			guitarSprite[j].frame = 0f;
		}
		hitCount = 0;
		missedCount = 0;
		successAudio = true;
		guitarControllerIdx = -1;
	}

	internal void Finish()
	{
	}

	internal void EndSolo(GuitarMgr gMgr)
	{
		Character character = Game1.character[ID];
		switch (character.charAnim.animName)
		{
		case "rock1":
		case "rock2":
		case "rock3":
		case "rock4":
			character.charAnim.SetAnim("rockout", character.charUpdate);
			break;
		}
	}

	internal void Update(GuitarMgr gMgr, Node.Event pose)
	{
		float currentTime = gMgr.currentTime;
		Character character = Game1.character[ID];
		if (guitarControllerIdx < 0)
		{
			int num = -1;
			int num2 = -1;
			if (Game1.soloMgr.playerSolo[((ID < 2) ? (1 - ID) : (ID - 2))].active)
			{
				if (Game1.soloMgr.playerSolo[((ID < 2) ? (1 - ID) : (ID - 2))].guitarControllerIdx > -1)
				{
					num = Game1.soloMgr.playerSolo[((ID < 2) ? (1 - ID) : (ID - 2))].guitarControllerIdx;
				}
				num2 = Game1.mainPlayer[((ID < 2) ? (1 - ID) : (ID - 2))];
			}
			for (int i = 0; i < 4; i++)
			{
				bool flag = false;
				if (i == num)
				{
					flag = true;
				}
				if (i == num2)
				{
					flag = true;
				}
				if (Game1.netSession.IsClient())
				{
					if (i == Game1.mainPlayer[0])
					{
						flag = true;
					}
				}
				else if (i == Game1.mainPlayer[ID])
				{
					flag = true;
				}
			}
		}
		character.charUpdate.FixNetLoc();
		switch (pose)
		{
		case Node.Event.Pose1:
			switch (character.charAnim.animName)
			{
			case "rock2":
			case "rock2pick":
			case "rock2bow":
			case "rock2bow2":
				character.charAnim.SetAnim("rock2to1", character.charUpdate);
				break;
			case "rock3":
			case "rock3pick":
			case "rock3bow":
			case "rock3bow2":
				character.charAnim.SetAnim("rock3to2", character.charUpdate);
				break;
			case "rock4":
			case "rock4pick":
			case "rock4bow":
			case "rock4bow2":
				character.charAnim.SetAnim("rock4to3", character.charUpdate);
				break;
			}
			break;
		case Node.Event.Pose2:
			switch (character.charAnim.animName)
			{
			case "rock1":
			case "rock1pick":
			case "rock1bow":
			case "rock1bow2":
				character.charAnim.SetAnim("rock1to2", character.charUpdate);
				break;
			case "rock3":
			case "rock3pick":
			case "rock3bow":
			case "rock3bow2":
				character.charAnim.SetAnim("rock3to2", character.charUpdate);
				break;
			case "rock4":
			case "rock4pick":
			case "rock4bow":
			case "rock4bow2":
				character.charAnim.SetAnim("rock4to3", character.charUpdate);
				break;
			}
			break;
		case Node.Event.Pose3:
			switch (character.charAnim.animName)
			{
			case "rock1":
			case "rock1pick":
			case "rock1bow":
			case "rock1bow2":
				character.charAnim.SetAnim("rock1to2", character.charUpdate);
				break;
			case "rock2":
			case "rock2pick":
			case "rock2bow":
			case "rock2bow2":
				character.charAnim.SetAnim("rock2to3", character.charUpdate);
				break;
			case "rock4":
			case "rock4pick":
			case "rock4bow":
			case "rock4bow2":
				character.charAnim.SetAnim("rock4to3", character.charUpdate);
				break;
			}
			break;
		case Node.Event.Pose4:
			switch (character.charAnim.animName)
			{
			case "rock1":
			case "rock1pick":
			case "rock1bow":
			case "rock1bow2":
				character.charAnim.SetAnim("rock1to2", character.charUpdate);
				break;
			case "rock2":
			case "rock2pick":
			case "rock2bow":
			case "rock2bow2":
				character.charAnim.SetAnim("rock2to3", character.charUpdate);
				break;
			case "rock3":
			case "rock3pick":
			case "rock3bow":
			case "rock3bow2":
				character.charAnim.SetAnim("rock3to4", character.charUpdate);
				break;
			}
			break;
		}
		if ((!Game1.netSession.IsHost() || ID != 1) && (!Game1.netSession.IsClient() || ID != 0) && !(currentTime < 1f))
		{
			bool isYuki = Game1.character[ID].GetMeta().isYuki;
			int soloPad = ((Game1.GetPlayers() > 2 && !Game1.netSession.IsClient() && !Game1.netSession.IsHost() && Game1.mainPlayer[ID] > -1) ? Game1.mainPlayer[ID] : 0);
			if (Game1.netSession.IsClient())
			{
				_ = Game1.mainPlayer[0];
			}
			else
			{
				_ = Game1.mainPlayer[ID];
			}
			if (flibitPort.GetInputClicked(soloPad, flibitPort.InputAction.JumpAccept))
			{
				PlayNote(Node.Event.A, gMgr, isYuki);
			}
			if (flibitPort.GetInputClicked(soloPad, flibitPort.InputAction.GrabCancel))
			{
				PlayNote(Node.Event.B, gMgr, isYuki);
			}
			if (flibitPort.GetInputClicked(soloPad, flibitPort.InputAction.Attack))
			{
				PlayNote(Node.Event.X, gMgr, isYuki);
			}
			if (flibitPort.GetInputClicked(soloPad, flibitPort.InputAction.StrongSaw))
			{
				PlayNote(Node.Event.Y, gMgr, isYuki);
			}
			for (int j = 0; j < guitarSprite.Length; j++)
			{
				if (guitarSprite[j].frame > 0f)
				{
					guitarSprite[j].Update();
				}
			}
			float num3 = gMgr.currentTime / 30f * (float)gMgr.bpm;
			num3 -= 1.2f;
			int num4 = RowFromDifficulty();
			for (int k = 0; k < gMgr.nodeRow[num4].nodeCount; k++)
			{
				Node node = gMgr.nodeRow[num4].node[k];
				NodeStatus nodeStatus = this.nodeStatus[k];
				if (nodeStatus == NodeStatus.New && node.beats < (int)num3)
				{
					this.nodeStatus[k] = NodeStatus.Missed;
					missedCount++;
					successAudio = false;
				}
			}
		}
		if (Game1.netSession.IsHost() && ID == 1)
		{
			successAudio = true;
		}
		if (Game1.netSession.IsClient() && ID == 0)
		{
			successAudio = true;
		}
		switch (Game1.levelMgr.currentTrack)
		{
		case 1:
			SetDish(successAudio, 1f);
			break;
		case 0:
			SetYuki(successAudio, 1f);
			break;
		case 2:
			if (ID == 0)
			{
				SetYuki(successAudio, 0.5f);
			}
			else
			{
				SetDish(successAudio, 0.5f);
			}
			break;
		}
	}

	private void SetDish(bool successAudio, float vol)
	{
		if (successAudio)
		{
			Sound.GetEngine().GetCategory(SOLO_FG).SetVolume(vol);
		}
		else
		{
			Sound.GetEngine().GetCategory(SOLO_FG).SetVolume(0f);
		}
	}

	private void SetYuki(bool successAudio, float vol)
	{
		if (successAudio)
		{
			Sound.GetEngine().GetCategory(SOLO_VG).SetVolume(vol);
		}
		else
		{
			Sound.GetEngine().GetCategory(SOLO_VG).SetVolume(0f);
		}
	}

	public void Init()
	{
		Game1.character[ID].charAnim.SetAnim("rockin", Game1.character[ID].charUpdate);
		Reset();
		active = true;
		switch (GameSettings.difficulty)
		{
		case 0:
		case 1:
			difficulty = 0;
			break;
		case 2:
			difficulty = 1;
			break;
		case 3:
		case 4:
		case 5:
			difficulty = 2;
			break;
		}
	}

	private void PlayNote(Node.Event note, GuitarMgr gMgr, bool bow)
	{
		if (bow)
		{
			switch (Game1.character[ID].charAnim.animName)
			{
			case "rock1":
			case "rock1bow":
			case "rock1bow2":
				Game1.character[ID].charAnim.SetAnim(bowStroke ? "rock1bow2" : "rock1bow", Game1.character[ID].charUpdate, overRide: true);
				break;
			case "rock2":
			case "rock2bow":
			case "rock2bow2":
				Game1.character[ID].charAnim.SetAnim(bowStroke ? "rock2bow2" : "rock2bow", Game1.character[ID].charUpdate, overRide: true);
				break;
			case "rock3":
			case "rock3bow":
			case "rock3bow2":
				Game1.character[ID].charAnim.SetAnim(bowStroke ? "rock3bow2" : "rock3bow", Game1.character[ID].charUpdate, overRide: true);
				break;
			case "rock4":
			case "rock4bow":
			case "rock4bow2":
				Game1.character[ID].charAnim.SetAnim(bowStroke ? "rock4bow2" : "rock4bow", Game1.character[ID].charUpdate, overRide: true);
				break;
			}
			bowStroke = !bowStroke;
		}
		else
		{
			switch (Game1.character[ID].charAnim.animName)
			{
			case "rock1":
			case "rock1pick":
				Game1.character[ID].charAnim.SetAnim("rock1pick", Game1.character[ID].charUpdate, overRide: true);
				break;
			case "rock2":
			case "rock2pick":
				Game1.character[ID].charAnim.SetAnim("rock2pick", Game1.character[ID].charUpdate, overRide: true);
				break;
			case "rock3":
			case "rock3pick":
				Game1.character[ID].charAnim.SetAnim("rock3pick", Game1.character[ID].charUpdate, overRide: true);
				break;
			case "rock4":
			case "rock4pick":
				Game1.character[ID].charAnim.SetAnim("rock4pick", Game1.character[ID].charUpdate, overRide: true);
				break;
			}
		}
		float num = gMgr.currentTime / 30f * (float)gMgr.bpm;
		bool flag = false;
		if (TryPick(note, gMgr, num - 0.9f, ID))
		{
			flag = true;
			hitCount++;
			successAudio = true;
		}
		else if (TryPick(note, gMgr, num, ID))
		{
			flag = true;
			hitCount++;
			successAudio = true;
		}
		else if (TryPick(note, gMgr, num + 0.9f, ID))
		{
			flag = true;
			hitCount++;
			successAudio = true;
		}
		if (!flag)
		{
			missedCount++;
			successAudio = false;
		}
	}

	private int RowFromDifficulty()
	{
		return difficulty switch
		{
			0 => 0, 
			1 => 1, 
			2 => 2, 
			_ => 0, 
		};
	}

	private bool TryPick(Node.Event note, GuitarMgr gMgr, float beatTime, int ID)
	{
		int num = RowFromDifficulty();
		for (int i = 0; i < gMgr.nodeRow[num].nodeCount; i++)
		{
			Node node = gMgr.nodeRow[num].node[i];
			if (node.eventType == note)
			{
				NodeStatus nodeStatus = this.nodeStatus[i];
				if (nodeStatus == NodeStatus.New && node.beats == (int)beatTime)
				{
					this.nodeStatus[i] = NodeStatus.Hit;
					MakeGlow(node.eventType, ID);
					return true;
				}
			}
		}
		return false;
	}

	private void MakeGlow(Node.Event eventType, int ID)
	{
		for (int i = 0; i < 12; i++)
		{
			for (int j = 0; j < guitarSprite.Length; j++)
			{
				if (!(guitarSprite[j].frame <= 0f))
				{
					continue;
				}
				GuitarSprite.GemType type = GuitarSprite.GemType.ButtonA;
				switch (eventType)
				{
				case Node.Event.A:
					type = GuitarSprite.GemType.ButtonA;
					break;
				case Node.Event.B:
					type = GuitarSprite.GemType.ButtonB;
					break;
				case Node.Event.X:
					type = GuitarSprite.GemType.ButtonX;
					break;
				case Node.Event.Y:
					type = GuitarSprite.GemType.ButtonY;
					break;
				}
				if (guitarControllerIdx > -1)
				{
					float num = -96f;
					switch (eventType)
					{
					case Node.Event.B:
						num += 64f;
						break;
					case Node.Event.Y:
						num += 128f;
						break;
					case Node.Event.X:
						num += 192f;
						break;
					}
					guitarSprite[j].Init(GetOrig(ID) + new Vector2(num, 0f), Rand.GetRandomVec2(-100f, 100f, 0f, 200f), type);
				}
				else
				{
					guitarSprite[j].Init(GetOrig(ID), Rand.GetRandomVec2(-200f, 0f, -100f, 100f), type);
				}
				break;
			}
		}
	}

	private Vector2 GetOrig(int ID)
	{
		Vector2 vector = ScrollManager.screenSize / 2f + new Vector2(0f, 200f);
		if (guitarControllerIdx > -1)
		{
			vector = ScrollManager.screenSize / 2f + new Vector2(-300f, 100f);
		}
		if (Game1.netSession.IsClient() || Game1.netSession.IsHost())
		{
			return vector;
		}
		if (guitarControllerIdx > -1)
		{
			if (Game1.GetPlayers() >= 2 && ID == 1)
			{
				return vector + new Vector2(600f, 0f);
			}
			return vector;
		}
		Vector2 vector2 = new Vector2(300f, 0f);
		if (Game1.GetPlayers() >= 2)
		{
			if (ID % 2 == 0)
			{
				vector -= vector2;
			}
			else
			{
				vector += vector2;
			}
			if (ID >= 2)
			{
				vector += new Vector2(0f, -170f);
			}
		}
		return vector;
	}

	internal void Draw(SpriteBatch sprite, GuitarMgr gMgr, int ID, int threedee)
	{
		if ((Game1.netSession.IsHost() && ID == 1) || (Game1.netSession.IsClient() && ID == 0))
		{
			return;
		}
		int prevRenderingPlayer = flibitPort.RenderingPlayer;
		if (Game1.GetPlayers() > 2 && Game1.mainPlayer[ID] > -1)
		{
			flibitPort.RenderingPlayer = Game1.mainPlayer[ID];
		}
		Vector2 orig = GetOrig(ID);
		switch (threedee)
		{
		case 0:
			orig.X++;
			break;
		case 1:
			orig.X--;
			break;
		}
		SpriteTools.BeginAlpha();
		if (guitarControllerIdx > -1)
		{
			sprite.Draw(Game1.spritesTex, orig, new Rectangle(384, 384, 256, 64), new Color(0f, 0f, 0f, 0.25f), 0f, new Vector2(128f, 32f), 1f, SpriteEffects.None, 1f);
		}
		else
		{
			sprite.Draw(Game1.spritesTex, orig, new Rectangle(832, 192, 64, 64), new Color(0f, 0f, 0f, 0.25f), gMgr.currentTime, new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
		}
		int num = RowFromDifficulty();
		for (int i = 0; i < gMgr.nodeRow[num].nodeCount; i++)
		{
			Node node = gMgr.nodeRow[num].node[i];
			float num2 = (float)node.beats * 30f / (float)gMgr.bpm;
			num2 -= gMgr.currentTime;
			switch (nodeStatus[i])
			{
			case NodeStatus.New:
			case NodeStatus.Missed:
			{
				char attrib = 'X';
				switch (node.eventType)
				{
				case Node.Event.Y:
					attrib = 'Y';
					break;
				case Node.Event.A:
					attrib = 'A';
					break;
				case Node.Event.B:
					attrib = 'B';
					break;
				}
				float num3 = num2 * 200f;
				float num4 = 1f;
				if (num3 > 250f)
				{
					num4 = (300f - num3) / 50f;
				}
				if (num3 < -50f)
				{
					num4 = (100f + num3) / 50f;
				}
				if (!(num4 > 0f))
				{
					break;
				}
				if (guitarControllerIdx > -1)
				{
					float num5 = -96f;
					Color color = new Color(0.1f, 1f, 0.1f, num4);
					switch (node.eventType)
					{
					case Node.Event.B:
						color = new Color(1f, 0.1f, 0.1f, num4);
						num5 += 64f;
						break;
					case Node.Event.Y:
						color = new Color(1f, 1f, 0.1f, num4);
						num5 += 128f;
						break;
					case Node.Event.X:
						color = new Color(0.1f, 0.1f, 1f, num4);
						num5 += 192f;
						break;
					}
					sprite.Draw(Game1.spritesTex, orig + new Vector2(num5, 0f - num3), new Rectangle(256, 768, 64, 64), color, 0f, new Vector2(32f, 32f), 0.8f, SpriteEffects.None, 1f);
					if (num2 <= 0f && num2 > -0.1f)
					{
						color.A = (byte)((num2 * 10f + 1f) / 256f);
						sprite.Draw(Game1.spritesTex, orig + new Vector2(num5, 0f - num3) + new Vector2(0f, num2) * 200f, new Rectangle(256, 768, 64, 64), color, 0f, new Vector2(32f, 32f), 1f - num2 * 5f, SpriteEffects.None, 1f);
					}
				}
				else
				{
					float num6 = (flibitPort.OwnerIsKeyboard() ? 2f : 1f);
					flibitPort.DrawButtonAttrib(attrib, orig + new Vector2(num3, 0f) * num6, new Color(1f, 1f, 1f, num4), 0f, new Vector2(32f, 32f), 0.8f, SpriteEffects.None, 1f);
					if (num2 <= 0f && num2 > -0.1f)
					{
						flibitPort.DrawButtonAttrib(attrib, orig + new Vector2(num2, 0f) * 200f, new Color(1f, 1f, 1f, num2 * 10f + 1f), 0f, new Vector2(32f, 32f), 1f - num2 * 5f, SpriteEffects.None, 1f);
					}
				}
				break;
			}
			}
		}
		if (guitarControllerIdx > -1)
		{
			sprite.Draw(Game1.spritesTex, orig, new Rectangle(384, 384, 256, 64), new Color(1f, 1f, 1f, 0.125f), 0f, new Vector2(128f, 32f), 1.05f, SpriteEffects.FlipHorizontally, 1f);
		}
		else
		{
			sprite.Draw(Game1.spritesTex, orig, new Rectangle(768, 128, 64, 64), Color.White, gMgr.currentTime, new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
			sprite.Draw(Game1.spritesTex, orig, new Rectangle(768, 128, 64, 64), Color.White, 0f - gMgr.currentTime, new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
		}
		SpriteTools.End();
		SpriteTools.BeginAdditive();
		for (int j = 0; j < guitarSprite.Length; j++)
		{
			if (guitarSprite[j].frame > 0f)
			{
				guitarSprite[j].Draw(sprite);
			}
		}
		SpriteTools.End();
		flibitPort.RenderingPlayer = prevRenderingPlayer;
	}
}
