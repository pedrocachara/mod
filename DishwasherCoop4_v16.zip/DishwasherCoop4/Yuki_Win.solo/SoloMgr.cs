using System;
using director;
using GuitarEdit.guitar;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.solo;

public class SoloMgr
{
	public GuitarMgr guitarMgr;

	public PlayerSolo[] playerSolo;

	public bool active;

	public bool preparing;

	public Node.Event currentLights = Node.Event.NoLights;

	public Node.Event currentPose = Node.Event.Pose1;

	public float brite;

	private float spotLight;

	public bool waitingForEnd;

	public float cheeseFactor = 0.995f;

	private long pauseTime;

	public SoloMgr()
	{
		guitarMgr = new GuitarMgr();
		playerSolo = new PlayerSolo[4];
		for (int i = 0; i < playerSolo.Length; i++)
		{
			playerSolo[i] = new PlayerSolo(i);
		}
	}

	public static GuitarMgr.SoloName NameFromString(string s)
	{
		return s switch
		{
			"solo" => GuitarMgr.SoloName.Solo, 
			"solo2" => GuitarMgr.SoloName.Solo2, 
			"solo3" => GuitarMgr.SoloName.Solo3, 
			"solo4" => GuitarMgr.SoloName.Solo4, 
			"solo5" => GuitarMgr.SoloName.Solo5, 
			"solo6" => GuitarMgr.SoloName.Solo6, 
			_ => GuitarMgr.SoloName.Solo, 
		};
	}

	public void Init(GuitarMgr.SoloName name)
	{
		guitarMgr.Init(name);
		guitarMgr.currentTime = 0f;
		currentLights = Node.Event.NoLights;
		currentPose = Node.Event.Pose1;
		string text = guitarMgr.soloCatalog[(int)name];
		guitarMgr.path = "solo/data/" + text + ".zgx";
		guitarMgr.Read();
		preparing = true;
		active = true;
		waitingForEnd = false;
	}

	public void Play()
	{
		guitarMgr.Play();
		brite = 0f;
		spotLight = 0f;
	}

	public void Pause()
	{
		if (active && guitarMgr.playing)
		{
			pauseTime = DateTime.UtcNow.Ticks;
			guitarMgr.Pause();
		}
	}

	public void Resume()
	{
		if (active && guitarMgr.paused)
		{
			long dif = DateTime.UtcNow.Ticks - pauseTime;
			guitarMgr.Resume(dif);
		}
	}

	public void Update()
	{
		if (preparing)
		{
			if (guitarMgr.GetReady())
			{
				preparing = false;
				guitarMgr.playing = false;
				guitarMgr.Play();
				for (int sp = 0; sp < playerSolo.Length; sp++)
				{
					if (sp < Game1.GetPlayers())
					{
						playerSolo[sp].Init();
					}
					else
					{
						playerSolo[sp].active = false;
					}
				}
				if (Game1.GetPlayers() < 2)
				{
					playerSolo[1].active = false;
				}
			}
			return;
		}
		if (waitingForEnd)
		{
			for (int i = 0; i < playerSolo.Length; i++)
			{
				if (playerSolo[i].active)
				{
					playerSolo[i].EndSolo(guitarMgr);
				}
			}
			if (brite < 0f)
			{
				brite += FMan.frameTime;
			}
			if (spotLight > 0f)
			{
				spotLight -= FMan.frameTime * 2f;
			}
			currentLights = Node.Event.NoLights;
			currentPose = Node.Event.Pose1;
			return;
		}
		float num = guitarMgr.currentTime / 30f * (float)guitarMgr.bpm;
		cheeseFactor = 0.998f;
		guitarMgr.Update();
		guitarMgr.currentTime *= cheeseFactor;
		if (currentLights != Node.Event.NoLights)
		{
			if (brite > -0.25f)
			{
				brite -= FMan.frameTime;
			}
		}
		else if (brite < 0f)
		{
			brite += FMan.frameTime;
		}
		if (spotLight < 1f)
		{
			spotLight += FMan.frameTime * 0.2f;
		}
		for (int j = 0; j < playerSolo.Length; j++)
		{
			if (playerSolo[j].active)
			{
				playerSolo[j].Update(guitarMgr, currentPose);
			}
		}
		if (guitarMgr.GetDone())
		{
			waitingForEnd = true;
			for (int k = 0; k < playerSolo.Length; k++)
			{
				if (playerSolo[k].active)
				{
					playerSolo[k].Finish();
					if ((float)playerSolo[0].hitCount / (float)(playerSolo[0].hitCount + playerSolo[0].missedCount) >= 0.6f)
					{
						Game1.gameMap.CurMap().scriptMgr.SetFlag("guitarpass");
					}
				}
			}
		}
		float num2 = guitarMgr.currentTime / 30f * (float)guitarMgr.bpm;
		for (int l = 0; l < guitarMgr.nodeRow[3].nodeCount; l++)
		{
			if (num2 > (float)guitarMgr.nodeRow[3].node[l].beats)
			{
				currentLights = guitarMgr.nodeRow[3].node[l].eventType;
			}
		}
		for (int m = 0; m < guitarMgr.nodeRow[4].nodeCount; m++)
		{
			if (num2 > (float)guitarMgr.nodeRow[4].node[m].beats)
			{
				currentPose = guitarMgr.nodeRow[4].node[m].eventType;
			}
		}
		if (currentLights != Node.Event.NoLights)
		{
			float num3 = num2 - (float)(int)num2;
			if (num3 < 0.1f)
			{
				brite += num3;
			}
		}
		switch (currentLights)
		{
		case Node.Event.BlueSparks:
			if ((int)(num * 30f) != (int)(num2 * 30f))
			{
				Vector2 realLoc3 = ScrollManager.GetRealLoc(default, 1f);
				Vector2 realLoc4 = ScrollManager.GetRealLoc(ScrollManager.screenSize, 1f);
				for (int num4 = 1; num4 < 8; num4++)
				{
					Game1.spriteMan.AddSprite(0, new Vector2((realLoc4.X - realLoc3.X) * (float)num4 / 8f + realLoc3.X, realLoc4.Y), Rand.GetRandomVec2(-100f, 100f, -900f, -600f), 1f, 0, 0);
				}
			}
			break;
		case Node.Event.Fire:
			if ((int)(num * 20f) != (int)(num2 * 20f))
			{
				Vector2 realLoc = ScrollManager.GetRealLoc(default, 1f);
				Vector2 realLoc2 = ScrollManager.GetRealLoc(ScrollManager.screenSize, 1f);
				for (int n = 1; n < 8; n++)
				{
					Game1.spriteMan.AddSprite(16, new Vector2((realLoc2.X - realLoc.X) * (float)n / 8f + realLoc.X, realLoc2.Y), Rand.GetRandomVec2(-100f, 100f, -800f, -700f), Rand.GetRandomFloat(0.5f, 0.8f), 0, 0);
				}
			}
			break;
		}
	}

	public void Finish()
	{
		if (active)
		{
			Game1.soloMgr.active = false;
			if (Game1.levelMgr.currentTrack == 2)
			{
				if (Game1.netSession.IsHost())
				{
					Game1.hud.DoGuitar((float)playerSolo[0].hitCount / (float)(playerSolo[0].hitCount + playerSolo[0].missedCount));
				}
				else if (Game1.netSession.IsClient())
				{
					Game1.hud.DoGuitar((float)playerSolo[1].hitCount / (float)(playerSolo[1].hitCount + playerSolo[1].missedCount));
				}
				else if (Game1.GetPlayers() > 2)
				{
					float sumPerc = 0f;
					int cntPerc = 0;
					for (int sp = 0; sp < playerSolo.Length; sp++)
					{
						if (playerSolo[sp].active && playerSolo[sp].hitCount + playerSolo[sp].missedCount > 0)
						{
							sumPerc += (float)playerSolo[sp].hitCount / (float)(playerSolo[sp].hitCount + playerSolo[sp].missedCount);
							cntPerc++;
						}
					}
					Game1.hud.DoGuitar(sumPerc / (float)((cntPerc < 1) ? 1 : cntPerc));
				}
				else
				{
					Game1.hud.DoGuitar((float)playerSolo[0].hitCount / (float)(playerSolo[0].hitCount + playerSolo[0].missedCount), (float)playerSolo[1].hitCount / (float)(playerSolo[1].hitCount + playerSolo[1].missedCount));
				}
			}
			else
			{
				Game1.hud.DoGuitar((float)playerSolo[0].hitCount / (float)(playerSolo[0].hitCount + playerSolo[0].missedCount));
			}
		}
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (Game1.character[i].exists)
			{
				if (Game1.character[i].GetMeta().isGuitar)
				{
					Game1.character[i].charAnim.SetAnim("ampempty", Game1.character[i].charUpdate);
				}
				if (Game1.character[i].GetMeta().isViolin)
				{
					Game1.character[i].charAnim.SetAnim("ampempty", Game1.character[i].charUpdate);
				}
			}
		}
		Game1.levelMgr.guitarEmpty = true;
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		SpriteTools.BeginAdditive();
		switch (currentLights)
		{
		case Node.Event.Fire:
		case Node.Event.BlueSparks:
		{
			for (int j = 0; j < 8; j++)
			{
				float x2 = (float)j / 7f * ScrollManager.screenSize.X;
				float num = guitarMgr.currentTime / 30f * (float)guitarMgr.bpm;
				float num2 = (((int)(num * 4f) % 2 == j % 2) ? 1f : 0.1f);
				sprite.Draw(Game1.spritesTex, new Vector2(x2, ScrollManager.screenSize.Y + 400f), new Rectangle(0, 256, 384, 192), new Color(num2, num2, num2, 0.6f), -1.57f + (float)Math.Cos((float)j * 2.7f + guitarMgr.currentTime * 3f) * 0.3f, new Vector2(32f, 96f), new Vector2(3f, 1.2f), SpriteEffects.None, 1f);
			}
			break;
		}
		case Node.Event.WhiteLights:
		case Node.Event.RedLights:
		case Node.Event.BlueLights:
		{
			for (int i = 0; i < 8; i++)
			{
				float x = (float)i / 7f * ScrollManager.screenSize.X;
				_ = guitarMgr.currentTime / 30f;
				_ = guitarMgr.bpm;
				sprite.Draw(Game1.spritesTex, new Vector2(x, ScrollManager.screenSize.Y + 400f), new Rectangle(0, 256, 384, 192), new Color(1f, 1f, 1f, 0.5f), -1.57f + (float)Math.Cos((float)i * 2.7f + guitarMgr.currentTime * 2.5f) * 0.3f, new Vector2(32f, 96f), new Vector2(2f, 1f), SpriteEffects.None, 1f);
			}
			break;
		}
		}
		sprite.Draw(Game1.spritesTex, new Vector2(ScrollManager.screenSize.X / 2f + 250f, -100f), new Rectangle(0, 256, 384, 192), new Color(1f, 0.9f, 0.8f, spotLight), 2.0700002f, new Vector2(32f, 96f), new Vector2(3f, 1.5f), SpriteEffects.None, 1f);
		switch (currentLights)
		{
		case Node.Event.BlueLights:
		case Node.Event.BlueSparks:
		{
			for (int n = 0; n < 8; n++)
			{
				float x6 = (float)n / 7f * ScrollManager.screenSize.X;
				sprite.Draw(Game1.spritesTex, new Vector2(x6, ScrollManager.screenSize.Y + 100f), new Rectangle(0, 256, 384, 192), new Color(0.1f, 0.1f, 1f, 0.65f), -1.57f + (float)Math.Cos((float)n * 1.7f + guitarMgr.currentTime * 2f) * 0.3f, new Vector2(32f, 96f), new Vector2(3f, 1.2f), SpriteEffects.None, 1f);
			}
			break;
		}
		case Node.Event.WhiteLights:
		{
			for (int l = 0; l < 8; l++)
			{
				float x4 = (float)l / 7f * ScrollManager.screenSize.X;
				sprite.Draw(Game1.spritesTex, new Vector2(x4, ScrollManager.screenSize.Y + 100f), new Rectangle(0, 256, 384, 192), new Color(1f, 1f, 1f, 0.5f), -1.57f + (float)Math.Cos((float)l * 1.7f + guitarMgr.currentTime * 2f) * 0.3f, new Vector2(32f, 96f), new Vector2(3f, 1.2f), SpriteEffects.None, 1f);
			}
			break;
		}
		case Node.Event.StrobeLights:
		{
			for (int m = 0; m < 8; m++)
			{
				float x5 = (float)m / 7f * ScrollManager.screenSize.X;
				float num3 = guitarMgr.currentTime / 30f * (float)guitarMgr.bpm;
				float num4 = (((int)(num3 * 4f) % 2 == m % 2) ? 1f : 0.1f);
				sprite.Draw(Game1.spritesTex, new Vector2(x5, ScrollManager.screenSize.Y + 100f), new Rectangle(0, 256, 384, 192), new Color(num4, num4, num4, 0.6f), -1.57f + (float)Math.Cos((float)m * 1.7f + guitarMgr.currentTime * 2f) * 0.3f, new Vector2(32f, 96f), new Vector2(3f, 1.2f), SpriteEffects.None, 1f);
			}
			break;
		}
		case Node.Event.RedLights:
		case Node.Event.Fire:
		{
			for (int k = 0; k < 8; k++)
			{
				float x3 = (float)k / 7f * ScrollManager.screenSize.X;
				sprite.Draw(Game1.spritesTex, new Vector2(x3, ScrollManager.screenSize.Y + 100f), new Rectangle(0, 256, 384, 192), new Color(1f, 0.2f, 0f, 0.6f), -1.57f + (float)Math.Cos((float)k * 1.7f + guitarMgr.currentTime * 2f) * 0.3f, new Vector2(32f, 96f), new Vector2(3f, 1.2f), SpriteEffects.None, 1f);
			}
			break;
		}
		}
		sprite.End();
		for (int num5 = 0; num5 < playerSolo.Length; num5++)
		{
			if (playerSolo[num5].active)
			{
				playerSolo[num5].Draw(sprite, guitarMgr, num5, threedee);
			}
		}
	}

	internal void Reset()
	{
		active = false;
	}
}
