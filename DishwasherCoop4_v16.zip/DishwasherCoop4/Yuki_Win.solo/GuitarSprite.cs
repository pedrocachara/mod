using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.solo;

public class GuitarSprite
{
	public enum GemType
	{
		ButtonA,
		ButtonB,
		ButtonX,
		ButtonY
	}

	public Vector2 loc;

	public Vector2 traj;

	public GemType type;

	public float frame;

	public int idx;

	public void Init(Vector2 loc, Vector2 traj, GemType type)
	{
		this.loc = loc;
		this.traj = traj;
		this.type = type;
		frame = Rand.GetRandomFloat(0.3f, 0.5f);
		idx = Rand.GetRandomInt(0, 10);
	}

	public void Update()
	{
		loc += traj * FMan.frameTime;
		frame -= FMan.frameTime;
	}

	public void Draw(SpriteBatch sprite)
	{
		Color color = Color.White;
		switch (type)
		{
		case GemType.ButtonA:
			color = new Color(0.4f, 1f, 0.4f, frame);
			break;
		case GemType.ButtonB:
			color = new Color(1f, 0.4f, 0.4f, frame);
			break;
		case GemType.ButtonX:
			color = new Color(0.4f, 0.4f, 1f, frame);
			break;
		case GemType.ButtonY:
			color = new Color(1f, 1f, 0.1f, frame);
			break;
		}
		Vector2 scale = new Vector2(1.4f, 1.4f);
		if (frame > 0.4f)
		{
			scale.X -= 0.5f - frame;
			scale.Y += (0.5f - frame) * 35f;
		}
		sprite.Draw(Game1.spritesTex, loc, new Rectangle(576 + idx % 5 * 64, 192, 64, 64), color, 0f, new Vector2(32f, 32f), scale, (idx / 2 == 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
	}
}
