using System.IO;
using GuitarEdit.guitar;

namespace Yuki_Win.solo;

public class NodeRow
{
	public Node[] node;

	public int nodeCount;

	public NodeRow()
	{
		node = new Node[512];
		nodeCount = 0;
	}

	public void AddNode(int beats, Node.Event e)
	{
		if (nodeCount < node.Length)
		{
			node[nodeCount] = new Node(beats, e);
			nodeCount++;
		}
	}

	public void AddNode(BinaryReader reader)
	{
		if (nodeCount < node.Length)
		{
			node[nodeCount] = new Node(reader);
			nodeCount++;
		}
	}

	public void Reset()
	{
		nodeCount = 0;
	}
}
