using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework.Audio;
using Yuki_Win.audio;

namespace Yuki_Win.solo;

public class GuitarMgr
{
	public enum CuePart
	{
		bg,
		guitar_lead,
		violin_lead
	}

	public enum SoloName
	{
		Solo,
		Solo2,
		Solo3,
		Solo4,
		Solo5,
		Solo6
	}

	public enum EventRow
	{
		None,
		GemsEasy,
		GemsNormal,
		GemsHard,
		Events,
		Poses
	}

	public const int ROW_GEMS_EASY = 0;

	public const int ROW_GEMS_NORMAL = 1;

	public const int ROW_GEMS_HARD = 2;

	public const int ROW_EVENTS = 3;

	public const int ROW_POSES = 4;

	public Dictionary<int, Cue> solo;

	public SoloName soloName;

	public Dictionary<int, string> soloCatalog;

	public NodeRow[] nodeRow = new NodeRow[3];

	public int bpm;

	private long startTime;

	public bool playing;

	public float currentTime;

	public int beats;

	public bool paused;

	private long pTime;

	public string path;

	public GuitarMgr()
	{
		soloCatalog = new Dictionary<int, string>();
		soloCatalog.Add(0, "solo");
		soloCatalog.Add(1, "solo2");
		soloCatalog.Add(2, "solo3");
		soloCatalog.Add(3, "solo4");
		soloCatalog.Add(4, "solo5");
		soloCatalog.Add(5, "solo6");
		solo = new Dictionary<int, Cue>();
		bpm = 100;
		beats = 32;
		nodeRow = new NodeRow[5]
		{
			new NodeRow(),
			new NodeRow(),
			new NodeRow(),
			new NodeRow(),
			new NodeRow()
		};
	}

	public void Init(SoloName name)
	{
		soloName = name;
		solo[0] = Sound.GetSoloCue(soloCatalog[(int)name] + "_bg");
		solo[1] = Sound.GetSoloCue(soloCatalog[(int)name] + "_fg");
		solo[2] = Sound.GetSoloCue(soloCatalog[(int)name] + "_vg");
	}

	public bool GetReady()
	{
		if (solo[0].IsPrepared && solo[1].IsPrepared && solo[2].IsPrepared)
		{
			return true;
		}
		return false;
	}

	public void Play()
	{
		try
		{
			if (playing)
			{
				if (paused)
				{
					solo[0].Resume();
					solo[1].Resume();
					paused = false;
				}
				return;
			}
			startTime = DateTime.UtcNow.Ticks;
			pTime = startTime;
			currentTime = 0f;
			playing = true;
			paused = false;
			solo[0].Play();
			switch (Game1.levelMgr.currentTrack)
			{
			case 1:
				solo[1].Play();
				Sound.GetEngine().GetCategory(PlayerSolo.SOLO_FG).SetVolume(1f);
				break;
			case 0:
				solo[2].Play();
				Sound.GetEngine().GetCategory(PlayerSolo.SOLO_VG).SetVolume(1f);
				break;
			case 2:
				solo[1].Play();
				solo[2].Play();
				Sound.GetEngine().GetCategory(PlayerSolo.SOLO_FG).SetVolume(0.5f);
				Sound.GetEngine().GetCategory(PlayerSolo.SOLO_VG).SetVolume(0.5f);
				break;
			}
		}
		catch
		{
		}
	}

	public void Pause()
	{
		if (playing)
		{
			paused = true;
			solo[0].Pause();
			switch (Game1.levelMgr.currentTrack)
			{
			case 1:
				solo[1].Pause();
				break;
			case 0:
				solo[2].Pause();
				break;
			case 2:
				solo[1].Pause();
				solo[2].Pause();
				break;
			}
		}
	}

	public void Resume(long dif)
	{
		if (playing)
		{
			paused = false;
			solo[0].Resume();
			switch (Game1.levelMgr.currentTrack)
			{
			case 1:
				solo[1].Resume();
				break;
			case 0:
				solo[2].Resume();
				break;
			case 2:
				solo[1].Resume();
				solo[2].Resume();
				break;
			}
			startTime += dif;
		}
	}

	public void Stop()
	{
		if (playing)
		{
			solo[0].Stop(AudioStopOptions.Immediate);
			switch (Game1.levelMgr.currentTrack)
			{
			case 1:
				solo[1].Stop(AudioStopOptions.Immediate);
				break;
			case 0:
				solo[2].Stop(AudioStopOptions.Immediate);
				break;
			case 2:
				solo[1].Stop(AudioStopOptions.Immediate);
				solo[2].Stop(AudioStopOptions.Immediate);
				break;
			}
			playing = false;
			paused = false;
			solo[0] = null;
			solo[1] = null;
			solo[2] = null;
			currentTime = 0f;
		}
	}

	public void Update()
	{
		if (playing)
		{
			long ticks = DateTime.UtcNow.Ticks;
			if (paused)
			{
				long num = ticks - pTime;
				startTime += num;
			}
			else
			{
				currentTime = (float)(ticks - startTime) / 10000000f;
			}
			pTime = ticks;
		}
	}

	public bool GetDone()
	{
		float num = (float)beats * 30f / (float)bpm;
		if (currentTime > num)
		{
			return true;
		}
		return false;
	}

	internal void Read()
	{
		BinaryReader binaryReader = new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read));
		string text = binaryReader.ReadString();
		foreach (KeyValuePair<int, string> item in soloCatalog)
		{
			if (item.Value == text)
			{
				soloName = (SoloName)item.Key;
			}
		}
		beats = binaryReader.ReadInt32();
		bpm = binaryReader.ReadInt32();
		nodeRow[0].Reset();
		nodeRow[1].Reset();
		nodeRow[2].Reset();
		nodeRow[4].Reset();
		nodeRow[3].Reset();
		int num = binaryReader.ReadInt32();
		for (int i = 0; i < num; i++)
		{
			nodeRow[0].AddNode(binaryReader);
		}
		num = binaryReader.ReadInt32();
		for (int j = 0; j < num; j++)
		{
			nodeRow[1].AddNode(binaryReader);
		}
		num = binaryReader.ReadInt32();
		for (int k = 0; k < num; k++)
		{
			nodeRow[2].AddNode(binaryReader);
		}
		int num2 = binaryReader.ReadInt32();
		for (int l = 0; l < num2; l++)
		{
			nodeRow[3].AddNode(binaryReader);
		}
		int num3 = binaryReader.ReadInt32();
		for (int m = 0; m < num3; m++)
		{
			nodeRow[4].AddNode(binaryReader);
		}
		binaryReader.Close();
	}
}
