using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;

namespace Yuki_Win.guidestuff;

public class GamerData
{
	public string currentGamer;

	private string signedOutGamer;

	public float checkFrame;

	private int ID;

	public bool active;

	internal void SetSignedIn(SignedInGamer signedIn)
	{
		currentGamer = signedIn.Gamertag;
	}

	internal void SetSignedOut(SignedInGamer sg)
	{
		signedOutGamer = sg.Gamertag;
		checkFrame = 1f;
	}

	internal void Update(SignedInGamerMgr signedInGamerMgr)
	{
		active = true;
		if (checkFrame > 0f)
		{
			checkFrame -= FMan.realTime;
			if (checkFrame <= 0f)
			{
				CheckSignedInChange(signedInGamerMgr);
			}
		}
	}

	private void CheckSignedInChange(SignedInGamerMgr signedInGamerMgr)
	{
		if (Gamer.SignedInGamers[(PlayerIndex)ID] == null)
		{
			signedInGamerMgr.CatchChange();
			return;
		}
		currentGamer = Gamer.SignedInGamers[(PlayerIndex)ID].Gamertag;
		if (signedOutGamer != currentGamer)
		{
			signedInGamerMgr.CatchChange();
		}
	}

	public GamerData(int ID)
	{
		this.ID = ID;
	}

	internal void Reset()
	{
		signedOutGamer = null;
		checkFrame = 0f;
		if (Gamer.SignedInGamers[(PlayerIndex)ID] != null)
		{
			currentGamer = Gamer.SignedInGamers[(PlayerIndex)ID].Gamertag;
		}
	}
}
