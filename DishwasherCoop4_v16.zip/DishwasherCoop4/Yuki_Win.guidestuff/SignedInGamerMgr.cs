using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.menu;

namespace Yuki_Win.guidestuff;

public class SignedInGamerMgr
{
	public GamerData[] gamerData;

	private ControllerCheckMgr controllerCheckMgr;

	public SignedInGamerMgr()
	{
		controllerCheckMgr = new ControllerCheckMgr();
		gamerData = new GamerData[4];
		for (int i = 0; i < gamerData.Length; i++)
		{
			gamerData[i] = new GamerData(i);
		}
	}

	public void ProcessSignIn(SignedInGamer signedIn)
	{
		gamerData[(int)signedIn.PlayerIndex].SetSignedIn(signedIn);
	}

	public void ProcessSignOut(SignedInGamer signedOut)
	{
		if (!Game1.menuMgr.levels[22].active)
		{
			gamerData[(int)signedOut.PlayerIndex].SetSignedOut(signedOut);
		}
	}

	internal void Update()
	{
		controllerCheckMgr.Update();
		for (int i = 0; i < gamerData.Length; i++)
		{
			gamerData[i].active = false;
		}
		if (Game1.GetPlayers(local: true) == 2)
		{
			if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
			{
				UpdateGamerData(Game1.mainPlayer[0]);
			}
			else
			{
				for (int j = 0; j < 2; j++)
				{
					UpdateGamerData(Game1.mainPlayer[j]);
				}
			}
		}
		else
		{
			UpdateGamerData(Game1.mainPlayer[0]);
		}
		for (int k = 0; k < gamerData.Length; k++)
		{
			if (!gamerData[k].active)
			{
				gamerData[k].checkFrame = 0f;
			}
		}
	}

	private void UpdateGamerData(int idx)
	{
		if (idx > -1 && idx < gamerData.Length)
		{
			gamerData[idx].Update(this);
		}
	}

	public void CatchChange()
	{
		GameState.state = GameState.State.Menu;
		Game1.menuMgr.DeactivateAllLevels();
		Game1.menuMgr.levels[22].active = true;
		Game1.menuMgr.ResetScene(0);
		Game1.menuMgr.transMode = MenuManager.TransitionMode.In;
		Game1.menuMgr.transFrame = 1f;
		Game1.menuMgr.pauseMode = false;
		Game1.menuMgr.messageMgr.AddMsg(YukiText.signedInFail, new string[5]
		{
			YukiText.signedOutOrSwitched1,
			YukiText.signedOutOrSwitched2,
			"",
			YukiText.signedOutOrSwitched3,
			YukiText.signedOutOrSwitched4
		}, clear: true, weak: false);
	}

	internal void Reset()
	{
		for (int i = 0; i < gamerData.Length; i++)
		{
			gamerData[i].Reset();
		}
	}
}
