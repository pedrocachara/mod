using Yuki_Win.arcade;

namespace Yuki_Win.guidestuff;

public class ControllerCheckMgr
{
	private float frame;

	public void Update()
	{
		switch (GameState.state)
		{
		case GameState.State.Menu:
		case GameState.State.Credits:
		case GameState.State.Upsell:
			return;
		}
		if ((Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.hud.IsArcadeIn()) || Game1.hud.IsEndLevel() || MainPlayer.uberDyingFrame >= 1f || (Game1.sceneMgr.playing && !Game1.sceneMgr.overlay))
		{
			return;
		}
		frame += FMan.realTime;
		if (!(frame > 1f))
		{
			return;
		}
		frame = 0f;
		if (GameState.state != GameState.State.Playing)
		{
			return;
		}
		if (Game1.netSession.IsClient())
		{
			CheckController(0);
			return;
		}
		if (Game1.netSession.IsHost())
		{
			CheckController(0);
			return;
		}
		for (int i = 0; i < Game1.GetPlayers(); i++)
		{
			CheckController(i);
		}
	}

	private void CheckController(int ID)
	{
		int player = Game1.mainPlayer[ID];
		if (!flibitPort.IsUserConnected(player) && !Game1.menuMgr.messageMgr.GetActive())
		{
			Game1.menuMgr.Pause(ID);
			Game1.menuMgr.messageMgr.AddMsg(YukiText.controllerDisconnected, new string[2]
			{
				YukiText.controllerDisconnected1,
				YukiText.controllerDisconnected2
			}, clear: true, weak: true);
		}
	}
}
