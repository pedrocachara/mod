using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.player;

namespace Yuki_Win.guidestuff;

public class GuideStuff
{
	public const int TOAST_BOTTOM = 0;

	public const int TOAST_TOP = 1;

	public static bool demo;

	private static float demoCheckFrame = -5f;

	public static bool initedAsLive = false;

	private static int pToast;

	public static int toast;

	public static bool IsSignedIn(int g)
	{
		for (int i = 0; i < Gamer.SignedInGamers.Count; i++)
		{
			if (Gamer.SignedInGamers[i].PlayerIndex == (PlayerIndex)g)
			{
				return true;
			}
		}
		return false;
	}

	public static SignedInGamer GetSignedInGamerAtIndex(int index)
	{
		for (int i = 0; i < Gamer.SignedInGamers.Count; i++)
		{
			if (Gamer.SignedInGamers[i].PlayerIndex == (PlayerIndex)index)
			{
				return Gamer.SignedInGamers[i];
			}
		}
		return null;
	}

	public static void ShowUpsell(int owner)
	{
		bool flag = true;
		SignedInGamer signedInGamerAtIndex = GetSignedInGamerAtIndex(owner);
		if (signedInGamerAtIndex != null && !signedInGamerAtIndex.IsSignedInToLive)
		{
			flag = false;
		}
		if (flag)
		{
			if (Guide.IsVisible)
			{
			}
		}
		else
		{
			Game1.menuMgr.messageMgr.AddMsg(YukiText.cantUnlock, new string[3]
			{
				YukiText.pleaseConnect1,
				YukiText.pleaseConnect2,
				YukiText.pleaseConnect3
			});
		}
	}

	public static void Update()
	{
		if (toast != pToast)
		{
			if (toast == 0)
			{
				Guide.NotificationPosition = NotificationPosition.BottomCenter;
			}
			else
			{
				Guide.NotificationPosition = NotificationPosition.TopCenter;
			}
		}
		pToast = toast;
		if (GameState.state == GameState.State.Playing)
		{
			if (Game1.hud.IsEndLevel())
			{
				demoCheckFrame += FMan.realTime;
			}
			else
			{
				demoCheckFrame += 0.02f * FMan.frameTime;
			}
		}
		else
		{
			demoCheckFrame += FMan.realTime;
		}
		if (demoCheckFrame > 1f)
		{
			demoCheckFrame--;
			CheckDemo();
		}
	}

	public static void CheckDemo()
	{
		demo = false;
	}

	private static void UnlockSave()
	{
	}

	public static bool GetTrial()
	{
		return false;
	}

	internal static void CheckLiveStart()
	{
		CheckLiveStart(noWarn: false);
	}

	internal static void CheckLiveStart(bool noWarn)
	{
		bool flag = initedAsLive;
		bool flag2 = false;
		if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
		{
			flag2 = true;
		}
		else
		{
			for (int i = 0; i < Game1.GetPlayers(); i++)
			{
				SignedInGamer signedInGamerAtIndex = GetSignedInGamerAtIndex(Game1.mainPlayer[i]);
				if (signedInGamerAtIndex != null && signedInGamerAtIndex.IsSignedInToLive)
				{
					flag2 = true;
				}
			}
		}
		initedAsLive = flag2;
		if (flag2)
		{
			return;
		}
		bool flag3 = false;
		switch (Game1.levelMgr.currentTrack)
		{
		case 0:
		case 1:
		case 2:
			if (GameSettings.difficulty == 5)
			{
				flag3 = true;
			}
			break;
		default:
			flag3 = true;
			break;
		}
		if (flag && flag3)
		{
			noWarn = false;
		}
		_ = GameState.paxDemoMode;
	}

	internal static StringBuilder GetSignedInGamerName(int p)
	{
		SignedInGamer signedInGamerAtIndex = GetSignedInGamerAtIndex(Game1.mainPlayer[p]);
		if (signedInGamerAtIndex != null)
		{
			return new StringBuilder(signedInGamerAtIndex.Gamertag);
		}
		return new StringBuilder("");
	}

	internal static bool IsInParty(int mainPlayer)
	{
		SignedInGamer signedInGamerAtIndex = GetSignedInGamerAtIndex(Game1.mainPlayer[mainPlayer]);
		if (signedInGamerAtIndex != null && signedInGamerAtIndex.PartySize > 1)
		{
			return true;
		}
		return false;
	}
}
