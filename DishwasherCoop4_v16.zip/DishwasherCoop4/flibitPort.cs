using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using SDL2;
using Yuki_Win;
using Yuki_Win.gameRender;

public static class flibitPort
{
	private class CrashGame : Game
	{
		private SpriteFont font;

		private SpriteBatch batch;

		private string text;

		public CrashGame(string fail)
		{
			text = Path.Combine(SaveDir, "crash.txt");
			File.WriteAllText(text, fail);
			text = "The game done crashed! A log has been saved to...\n\n" + text + "\n\n" + fail;
			new GraphicsDeviceManager(this);
			Window.Title = "OH FOR THE LOVE-A PETE";
		}

		protected override void LoadContent()
		{
			batch = new SpriteBatch(GraphicsDevice);
			font = Content.Load<SpriteFont>("Content/Arial");
		}

		protected override void UnloadContent()
		{
			batch.Dispose();
			font = null;
		}

		protected override void Draw(GameTime gameTime)
		{
			GraphicsDevice.Clear(Color.Black);
			batch.Begin();
			batch.DrawString(font, text, Vector2.Zero, Color.White);
			batch.End();
			base.Draw(gameTime);
		}
	}

	private struct MouseMenuItem(int smdMono = 0)
	{
		public Rectangle rect = Rectangle.Empty;

		public bool enabled = false;

		public Rectangle left = Rectangle.Empty;

		public Rectangle right = Rectangle.Empty;

		public void Set(Rectangle rect)
		{
			this.rect = rect;
			enabled = true;
			left = Rectangle.Empty;
			right = Rectangle.Empty;
		}
	}

	private enum GamePadType
	{
		Xbox360,
		DualShock4
	}

	public enum InputAction
	{
		JumpAccept,
		GrabCancel,
		Attack,
		StrongSaw,
		SwitchWeapons,
		SwitchLoadouts,
		Gun,
		Magic,
		Inventory,
		PauseConfirm,
		WarpRoll,
		Move_UP,
		Move_DOWN,
		Move_LEFT,
		Move_RIGHT,
		Move
	}

	private const string GameName = "VampireSmile";

	private static Game1 GameInstance;

	private static GraphicsDeviceManager GDM;

	public static Action<int, int, int, int> ApplyVideoMode;

	public static List<List<DisplayMode>> DisplayModes;

	public static string[] Monitors;

	public static int CurrentMonitor;

	public static int CurrentWindowMode;

	public static int CurrentDisplayMode;

	public static int CurrentVSync;

	public static int CurrentVibration;

	public static int CurrentMusicVolume;

	public static int CurrentSoundVolume;

	public static int PauseOnLostFocus;

	public static int CurrentBlood;

	public static int CurrentSwapGunRoll;

	public static bool ForceNoMenuString = false;

	private static GamePadState[] gamepads = new GamePadState[4];

	private static GamePadState[] prevGamepads = new GamePadState[4];

	private static bool[] isKeyboard;

	private static KeyboardState keyboard;

	private static KeyboardState prevKeyboard;

	private static MouseState prevMouse;

	private static int[] mouse;

	private static MouseMenuItem[] mouseItems;

	public static int MouseHoverItem;

	public static bool MouseHoverLeft;

	public static bool MouseHoverRight;

	public static bool MouseClickItem;

	public static bool MouseClickLeft;

	public static bool MouseClickRight;

	public static int MouseScrollDelta;

	public static int RenderingPlayer;

	private static GamePadType[] gamepadTypes;

	private static ButtonState[] clickEvents;

	private static Buttons[] gpBindings;

	private static Keys[] kbBindings;

	private static Keys[] kbMenuBindings;

	private static int[] mBindings;

	private static readonly string[] actionString;

	private static readonly Dictionary<int, int> buttonAttribs;

	private static Dictionary<char, InputAction> gpChar;

	public static bool InControlsMenu;

	public static readonly string ConfigDir;

	public static readonly string SaveDir;

	public static void Crash(Exception e)
	{
		using CrashGame crashGame = new CrashGame(e.ToString());
		crashGame.Run();
	}

	public static void InitVideo(Game1 game, GraphicsDeviceManager graphics)
	{
		GameInstance = game;
		GDM = graphics;
		int count = GraphicsAdapter.Adapters.Count;
		Monitors = new string[count];
		DisplayModes = new List<List<DisplayMode>>();
		for (int i = 0; i < count; i++)
		{
			GraphicsAdapter graphicsAdapter = GraphicsAdapter.Adapters[i];
			Monitors[i] = graphicsAdapter.Description + " (" + i + ")";
			DisplayModes.Add(new List<DisplayMode>());
			foreach (DisplayMode item in graphicsAdapter.SupportedDisplayModes[SurfaceFormat.Color])
			{
				DisplayModes[i].Insert(0, item);
			}
		}
		LoadVideoConfig(out var width, out var height);
		LoadControlConfig();
		CurrentDisplayMode = 0;
		if (CurrentMonitor < 0 || CurrentMonitor >= DisplayModes.Count)
		{
			CurrentMonitor = 0;
		}
		for (int j = 0; j < DisplayModes[CurrentMonitor].Count; j++)
		{
			DisplayMode displayMode = DisplayModes[CurrentMonitor][j];
			if (displayMode.Width == width && displayMode.Height == height)
			{
				CurrentDisplayMode = j;
				break;
			}
		}
		graphics.PreparingDeviceSettings += PrepareDeviceSettings;
		graphics.PreferredBackBufferWidth = width;
		graphics.PreferredBackBufferHeight = height;
		graphics.SynchronizeWithVerticalRetrace = CurrentVSync == 0;
		graphics.IsFullScreen = CurrentWindowMode == 0;
		ApplyVideoMode = ApplyVideo;
		Mouse.ClickedEXT = (Action<int>)Delegate.Combine(Mouse.ClickedEXT, new Action<int>(OnClicked));
		ScrollManager.Init(graphics.GraphicsDevice, new Vector2(graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight));
	}

	private static void ApplyVideo(int monitor, int mode, int fullscreen, int vsync)
	{
		CurrentMonitor = monitor;
		CurrentDisplayMode = mode;
		CurrentWindowMode = fullscreen;
		CurrentVSync = vsync;
		DisplayMode displayMode = DisplayModes[monitor][mode];
		GDM.PreferredBackBufferWidth = displayMode.Width;
		GDM.PreferredBackBufferHeight = displayMode.Height;
		GDM.SynchronizeWithVerticalRetrace = vsync == 0;
		GDM.IsFullScreen = fullscreen == 0;
		GDM.ApplyChanges();
		GameInstance.Window.IsBorderlessEXT = fullscreen == 2;
		ScrollManager.screenSize.X = displayMode.Width;
		ScrollManager.screenSize.Y = displayMode.Height;
		Game1.CreateTargs();
		GameRender.filterRender.readyToDraw = false;
		GameRender.fadeRender.readyToDraw = false;
		GameRender.bloomRender.readyToDraw = false;
		GameRender.threshRender.readyToDraw = false;
		GameRender.mapCompositor.readyToDraw = false;
		SaveVideoConfig(displayMode.Width, displayMode.Height);
	}

	public static string[] GenDisplayList()
	{
		List<DisplayMode> list = DisplayModes[CurrentMonitor];
		string[] array = new string[list.Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = list[i].Width + "x" + list[i].Height;
		}
		return array;
	}

	private static void PrepareDeviceSettings(object sender, PreparingDeviceSettingsEventArgs e)
	{
		try
		{
			e.GraphicsDeviceInformation.Adapter = GraphicsAdapter.Adapters[CurrentMonitor];
		}
		catch
		{
			CurrentMonitor = 0;
			e.GraphicsDeviceInformation.Adapter = GraphicsAdapter.Adapters[0];
		}
	}

	private static void OnClicked(int button)
	{
		if (button < clickEvents.Length)
		{
			clickEvents[button] = ButtonState.Pressed;
		}
	}

	public static void UpdateInput(bool active)
	{
		for (int i = 0; i < gamepads.Length; i++)
		{
			ref GamePadState reference = ref prevGamepads[i];
			reference = gamepads[i];
			ref GamePadState reference2 = ref gamepads[i];
			reference2 = GamePad.GetState((PlayerIndex)i);
			if (gamepads[i].IsConnected)
			{
				isKeyboard[i] = false;
				if (!prevGamepads[i].IsConnected)
				{
					string gUIDEXT = GamePad.GetGUIDEXT((PlayerIndex)i);
					if (gUIDEXT.Equals("4c05c405") || gUIDEXT.Equals("4c05cc09"))
					{
						gamepadTypes[i] = GamePadType.DualShock4;
					}
					else
					{
						gamepadTypes[i] = GamePadType.Xbox360;
					}
				}
			}
			else
			{
				if (isKeyboard[i])
				{
					continue;
				}
				bool flag = false;
				for (int j = 0; j < i; j++)
				{
					if (isKeyboard[j])
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					isKeyboard[i] = true;
					for (int k = i + 1; k < 4; k++)
					{
						isKeyboard[k] = false;
					}
				}
			}
		}
		prevKeyboard = keyboard;
		if (!active)
		{
			keyboard = default;
			prevKeyboard = default;
			prevMouse = default;
			Array.Clear(clickEvents, 0, clickEvents.Length);
			Array.Clear(mouse, 0, mouse.Length);
			MouseHoverItem = -1;
			MouseHoverLeft = false;
			MouseHoverRight = false;
			MouseClickItem = false;
			MouseClickLeft = false;
			MouseClickRight = false;
			MouseScrollDelta = 0;
			return;
		}
		keyboard = Keyboard.GetState();
		MouseState state = Mouse.GetState();
		ButtonState buttonState = state.LeftButton | clickEvents[0];
		ButtonState buttonState2 = state.MiddleButton | clickEvents[1];
		ButtonState buttonState3 = state.RightButton | clickEvents[2];
		ButtonState buttonState4 = state.XButton1 | clickEvents[3];
		ButtonState buttonState5 = state.XButton2 | clickEvents[4];
		clickEvents[0] = ButtonState.Released;
		clickEvents[1] = ButtonState.Released;
		clickEvents[2] = ButtonState.Released;
		clickEvents[3] = ButtonState.Released;
		clickEvents[4] = ButtonState.Released;
		if (buttonState == ButtonState.Released)
		{
			mouse[0] = 0;
		}
		else if (prevMouse.LeftButton == ButtonState.Released)
		{
			mouse[0] = 2;
		}
		else
		{
			mouse[0] = 1;
		}
		if (buttonState3 == ButtonState.Released)
		{
			mouse[1] = 0;
		}
		else if (prevMouse.RightButton == ButtonState.Released)
		{
			mouse[1] = 2;
		}
		else
		{
			mouse[1] = 1;
		}
		if (buttonState2 == ButtonState.Released)
		{
			mouse[2] = 0;
		}
		else if (prevMouse.MiddleButton == ButtonState.Released)
		{
			mouse[2] = 2;
		}
		else
		{
			mouse[2] = 1;
		}
		if (buttonState4 == ButtonState.Released)
		{
			mouse[3] = 0;
		}
		else if (prevMouse.XButton1 == ButtonState.Released)
		{
			mouse[3] = 2;
		}
		else
		{
			mouse[3] = 1;
		}
		if (buttonState5 == ButtonState.Released)
		{
			mouse[4] = 0;
		}
		else if (prevMouse.XButton2 == ButtonState.Released)
		{
			mouse[4] = 2;
		}
		else
		{
			mouse[4] = 1;
		}
		MouseHoverItem = -1;
		MouseHoverLeft = false;
		MouseHoverRight = false;
		MouseClickItem = false;
		MouseClickLeft = false;
		MouseClickRight = false;
		MouseScrollDelta = 0;
		if (MenuMouseMode() && OwnerIsKeyboard())
		{
			UpdateMouseMenu(state);
		}
		prevMouse = state;
	}

	private static void UpdateMouseMenu(MouseState nextMouse)
	{
		MouseHoverItem = -1;
		MouseHoverLeft = false;
		MouseHoverRight = false;
		MouseClickItem = false;
		MouseClickLeft = false;
		MouseClickRight = false;
		MouseScrollDelta = nextMouse.ScrollWheelValue - prevMouse.ScrollWheelValue;
		for (int i = 0; i < mouseItems.Length; i++)
		{
			if (mouseItems[i].enabled)
			{
				if (mouseItems[i].left.Contains(nextMouse.X, nextMouse.Y))
				{
					MouseHoverItem = i;
					MouseHoverLeft = true;
				}
				else if (mouseItems[i].right.Contains(nextMouse.X, nextMouse.Y))
				{
					MouseHoverItem = i;
					MouseHoverRight = true;
				}
				else if (mouseItems[i].rect.Contains(nextMouse.X, nextMouse.Y))
				{
					MouseHoverItem = i;
				}
			}
		}
		if (mouse[0] == 2 && MouseHoverItem > -1)
		{
			if (MouseHoverLeft)
			{
				MouseClickLeft = true;
			}
			else if (MouseHoverRight)
			{
				MouseClickRight = true;
			}
			else
			{
				MouseClickItem = true;
			}
		}
		if (!MouseClickLeft && !MouseClickRight && !MouseClickItem && prevMouse.X == nextMouse.X && prevMouse.Y == nextMouse.Y)
		{
			MouseHoverLeft = false;
			MouseHoverRight = false;
			MouseHoverItem = -1;
		}
		for (int j = 0; j < mouseItems.Length; j++)
		{
			mouseItems[j].enabled = false;
		}
	}

	public static void SetMouseMenuItem(int which, Vector2 origin, float width, float height, float? leftRight)
	{
		float num = 0f;
		width += 10f;
		mouseItems[which].Set(new Rectangle((int)(origin.X - width / 2f), (int)(origin.Y - num), (int)(width + 5f), (int)height));
		if (leftRight.HasValue)
		{
			mouseItems[which].left = new Rectangle((int)((float)mouseItems[which].rect.X - leftRight.Value - 7f), mouseItems[which].rect.Y, (int)leftRight.Value, mouseItems[which].rect.Height);
			mouseItems[which].right = new Rectangle(mouseItems[which].rect.X + mouseItems[which].rect.Width, mouseItems[which].rect.Y, (int)leftRight.Value, mouseItems[which].rect.Height);
		}
	}

	public static bool PressStartClick()
	{
		int[] array = mouse;
		foreach (int num in array)
		{
			if (num <= 0)
			{
				continue;
			}
			for (int j = 0; j < isKeyboard.Length; j++)
			{
				if (isKeyboard[j])
				{
					MouseHoverItem = j;
					return true;
				}
			}
		}
		return false;
	}

	public static void DrawMouse()
	{
		if (MenuMouseMode() && OwnerIsKeyboard() && Game1.spritesTex != null)
		{
			SpriteTools.sprite.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend);
			SpriteTools.sprite.Draw(Game1.spritesTex, new Vector2(prevMouse.X, prevMouse.Y), new Rectangle(4, 640, 52, 64), new Color(1f, 1f, 1f, 1f), -1f, new Vector2(32f, 4f), 1f, SpriteEffects.None, 1f);
			SpriteTools.sprite.End();
		}
	}

	public static void DrawMouseHUD(SpriteBatch sprite, int threedee)
	{
		int num;
		if (isKeyboard[Game1.mainPlayer[0]])
		{
			num = 0;
		}
		else
		{
			if (Game1.levelMgr.currentTrack != 2 || Game1.netSession.IsActive() || !isKeyboard[Game1.mainPlayer[0] ^ 1])
			{
				return;
			}
			num = 1;
		}
		if (!Game1.hud.invMgr.IsActive())
		{
			Vector2 screenLoc = ScrollManager.GetScreenLoc(Game1.character[num].charUpdate.loc, 0);
			Vector2 vector = new Vector2(prevMouse.X, prevMouse.Y);
			Vector2 v = vector - screenLoc;
			sprite.Draw(Game1.spritesTex, vector, new Rectangle(0, 768, 64, 64), new Color(1f, 1f, 1f, 0.8f), Trig.GetAngle(default, v), new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
		}
	}

	public static bool GetInputDigital(int player, InputAction action)
	{
		if (isKeyboard[player])
		{
			if (MenuMouseMode())
			{
				return keyboard.IsKeyDown(kbMenuBindings[(int)action]);
			}
			int num = mBindings[(int)action];
			if (!keyboard.IsKeyDown(kbBindings[(int)action]))
			{
				if (num > -1)
				{
					return mouse[num] > 0;
				}
				return false;
			}
			return true;
		}
		return gamepads[player].IsButtonDown(gpBindings[(int)action]);
	}

	public static bool GetInputClicked(int player, InputAction action)
	{
		if (isKeyboard[player])
		{
			Keys key;
			if (MenuMouseMode())
			{
				key = kbMenuBindings[(int)action];
				if (keyboard.IsKeyDown(key))
				{
					return prevKeyboard.IsKeyUp(key);
				}
				return false;
			}
			key = kbBindings[(int)action];
			int num = mBindings[(int)action];
			if (!keyboard.IsKeyDown(key) || !prevKeyboard.IsKeyUp(key))
			{
				if (num > -1)
				{
					return mouse[num] == 2;
				}
				return false;
			}
			return true;
		}
		if (gamepads[player].IsButtonDown(gpBindings[(int)action]))
		{
			return prevGamepads[player].IsButtonUp(gpBindings[(int)action]);
		}
		return false;
	}

	public static float GetInputAnalog(int player, InputAction action)
	{
		if (isKeyboard[player])
		{
			if (MenuMouseMode())
			{
				if (!keyboard.IsKeyDown(kbMenuBindings[(int)action]))
				{
					return 0f;
				}
				return 1f;
			}
			int num = mBindings[(int)action];
			if (!keyboard.IsKeyDown(kbBindings[(int)action]) && (num <= -1 || mouse[num] <= 0))
			{
				return 0f;
			}
			return 1f;
		}
		if (action == InputAction.Gun && CurrentSwapGunRoll == 1)
		{
			if (!gamepads[player].IsButtonDown(Buttons.RightThumbstickUp) && !gamepads[player].IsButtonDown(Buttons.RightThumbstickDown) && !gamepads[player].IsButtonDown(Buttons.RightThumbstickLeft) && !gamepads[player].IsButtonDown(Buttons.RightThumbstickRight))
			{
				return 0f;
			}
			return 1f;
		}
		Buttons buttons = gpBindings[(int)action];
		switch (buttons)
		{
		case Buttons.LeftTrigger:
			return gamepads[player].Triggers.Left;
		case Buttons.RightTrigger:
			return gamepads[player].Triggers.Right;
		default:
			if (!gamepads[player].IsButtonDown(buttons))
			{
				return 0f;
			}
			return 1f;
		}
	}

	public static Vector2 GetInputStick(int player, InputAction action)
	{
		if (isKeyboard[player])
		{
			Keys[] array = (MenuMouseMode() ? kbMenuBindings : kbBindings);
			Keys key;
			Keys key2;
			Keys key3;
			Keys key4;
			switch (action)
			{
			case InputAction.Move:
				key = array[11];
				key2 = array[13];
				key3 = array[12];
				key4 = array[14];
				break;
			case InputAction.WarpRoll:
				if (keyboard.IsKeyUp(kbBindings[10]))
				{
					return Vector2.Zero;
				}
				key = array[11];
				key2 = array[13];
				key3 = array[12];
				key4 = array[14];
				break;
			default:
				throw new NotImplementedException("How did you get here?!");
			}
			Vector2 zero = Vector2.Zero;
			if (keyboard.IsKeyDown(key))
			{
				zero.Y++;
			}
			if (keyboard.IsKeyDown(key2))
			{
				zero.X--;
			}
			if (keyboard.IsKeyDown(key3))
			{
				zero.Y--;
			}
			if (keyboard.IsKeyDown(key4))
			{
				zero.X++;
			}
			return zero;
		}
		switch (action)
		{
		case InputAction.Move:
			return gamepads[player].ThumbSticks.Left;
		case InputAction.WarpRoll:
			if (CurrentSwapGunRoll == 1)
			{
				CurrentSwapGunRoll = 0;
				float inputAnalog = GetInputAnalog(player, InputAction.Gun);
				CurrentSwapGunRoll = 1;
				if (inputAnalog > 0.3f)
				{
					return gamepads[player].ThumbSticks.Left;
				}
				return Vector2.Zero;
			}
			return gamepads[player].ThumbSticks.Right;
		default:
			throw new NotImplementedException("How did you get here?!");
		}
	}

	public static Vector2 GetInputAim(int player, Vector2 pos)
	{
		if (isKeyboard[player])
		{
			Vector2 screenLoc = ScrollManager.GetScreenLoc(Game1.character[player].charUpdate.loc, 0);
			Vector2 vector = new Vector2(prevMouse.X, prevMouse.Y);
			Vector2 result = vector - screenLoc;
			result.Y *= -1f;
			if (result.X != 0f || result.Y != 0f)
			{
				result.Normalize();
			}
			return result;
		}
		if (CurrentSwapGunRoll == 1)
		{
			return gamepads[player].ThumbSticks.Right;
		}
		return gamepads[player].ThumbSticks.Left;
	}

	public static void GetInputDPad(int player, out bool up, out bool down, out bool left, out bool right)
	{
		if (isKeyboard[player])
		{
			up = keyboard.IsKeyDown(Keys.Up) && prevKeyboard.IsKeyUp(Keys.Up);
			down = keyboard.IsKeyDown(Keys.Down) && prevKeyboard.IsKeyUp(Keys.Down);
			left = keyboard.IsKeyDown(Keys.Left) && prevKeyboard.IsKeyUp(Keys.Left);
			right = keyboard.IsKeyDown(Keys.Right) && prevKeyboard.IsKeyUp(Keys.Right);
		}
		else
		{
			up = gamepads[player].DPad.Up == ButtonState.Pressed && prevGamepads[player].DPad.Up == ButtonState.Released;
			down = gamepads[player].DPad.Down == ButtonState.Pressed && prevGamepads[player].DPad.Down == ButtonState.Released;
			left = gamepads[player].DPad.Left == ButtonState.Pressed && prevGamepads[player].DPad.Left == ButtonState.Released;
			right = gamepads[player].DPad.Right == ButtonState.Pressed && prevGamepads[player].DPad.Right == ButtonState.Released;
		}
	}

	public static void GetDPadUpDown(int player, out bool up, out bool down)
	{
		if (isKeyboard[player])
		{
			up = keyboard.IsKeyDown(Keys.Down);
			down = keyboard.IsKeyDown(Keys.Down);
		}
		else
		{
			up = gamepads[player].DPad.Up == ButtonState.Pressed;
			down = gamepads[player].DPad.Down == ButtonState.Pressed;
		}
	}

	public static void SetUserVibration(int player, float rumble)
	{
		if (!isKeyboard[player] && CurrentVibration == 0)
		{
			GamePad.SetVibration((PlayerIndex)player, rumble, rumble);
		}
	}

	public static bool IsUserConnected(int player)
	{
		if (!gamepads[player].IsConnected)
		{
			return isKeyboard[player];
		}
		return true;
	}

	public static string GetButtonIcon(InputAction action, string fallback)
	{
		if (isKeyboard[Math.Max(RenderingPlayer, 0)] || OwnerIsKeyboard())
		{
			if (MenuMouseMode() && !ForceNoMenuString)
			{
				return "(" + kbMenuBindings[(int)action].ToString() + ")";
			}
			if (mBindings[(int)action] > -1 && !InControlsMenu)
			{
				return "(" + GetMouseString(action) + ")";
			}
			return "(" + kbBindings[(int)action].ToString() + ")";
		}
		return fallback;
	}

	public static string GetButtonString(InputAction action)
	{
		if (action >= InputAction.WarpRoll)
		{
			return "(" + kbBindings[(int)action].ToString() + ")";
		}
		return actionString[(int)action];
	}

	public static string GetMouseString(InputAction action)
	{
		int num = mBindings[(int)action];
		return num switch
		{
			-1 => "---", 
			0 => YukiText.pc_leftmb, 
			1 => YukiText.pc_rightmb, 
			2 => YukiText.pc_middlemb, 
			_ => "MB " + (num + 1), 
		};
	}

	public static void DrawButtonAttrib(char attrib, Vector2 position, Color color, float rotation, Vector2 origin, float scale, SpriteEffects effects, float layerDepth)
	{
		if (!gpChar.ContainsKey(attrib))
		{
			int num = attrib switch
			{
				'u' => 0, 
				'd' => 1, 
				'/' => 4, 
				'D' => 13, 
				'z' => 16, 
				'e' => 17, 
				'a' => 18, 
				'h' => 19, 
				'c' => 20, 
				_ => throw new NotImplementedException("How did you get here?!"), 
			};
			SpriteTools.sprite.Draw(Game1.spritesTex, position, new Rectangle(num % 16 * 64, 640 + num / 16 * 64, 64, 64), color, rotation, origin, scale, effects, layerDepth);
			return;
		}
		InputAction inputAction = gpChar[attrib];
		if (isKeyboard[Math.Max(RenderingPlayer, 0)] || OwnerIsKeyboard())
		{
			string value;
			if (MenuMouseMode() && !ForceNoMenuString)
			{
				value = "(" + kbMenuBindings[(int)inputAction].ToString() + ")";
			}
			else if (mBindings[(int)inputAction] > -1 && !InControlsMenu)
			{
				if (mBindings[(int)inputAction] < 3)
				{
					SpriteTools.sprite.Draw(Game1.spritesTex, position, new Rectangle(896 + mBindings[(int)inputAction] * 64, 1152, 64, 64), color, rotation, origin, scale, effects, layerDepth);
					return;
				}
				value = "(" + GetMouseString(inputAction) + ")";
			}
			else
			{
				value = "(" + kbBindings[(int)inputAction].ToString() + ")";
			}
			Text.DrawCText(SpriteTools.sprite, position - new Vector2(0f, 16f), new StringBuilder(value), color, scale / 0.55f, 1);
		}
		else
		{
			int num2 = buttonAttribs[(int)gpBindings[(int)inputAction]];
			int num3 = 640;
			if ((num2 < 32 || num2 > 35) && gamepadTypes[Math.Max(RenderingPlayer, 0)] == GamePadType.DualShock4)
			{
				num3 = 1216;
			}
			SpriteTools.sprite.Draw(Game1.spritesTex, position, new Rectangle(num2 % 16 * 64, num3 + num2 / 16 * 64, 64, 64), new Color(255, 255, 255, color.A), rotation, origin, scale, effects, layerDepth);
		}
	}

	public static int BindButton(InputAction action, Buttons button)
	{
		int result = -1;
		for (int i = 0; i < 11; i++)
		{
			if (i != (int)action && gpBindings[i] == button)
			{
				result = i;
				Buttons buttons = gpBindings[(int)action];
				gpBindings[i] = buttons;
				break;
			}
		}
		gpBindings[(int)action] = button;
		SaveControlConfig();
		return result;
	}

	public static int BindKey(InputAction action, Keys keys)
	{
		int result = -1;
		for (int i = 0; i < 15; i++)
		{
			if (i != (int)action && kbBindings[i] == keys)
			{
				result = i;
				kbBindings[i] = kbBindings[(int)action];
				break;
			}
		}
		kbBindings[(int)action] = keys;
		SaveControlConfig();
		return result;
	}

	public static int BindMouse(InputAction action, int mouse)
	{
		int result = -1;
		for (int i = 0; i < 11; i++)
		{
			if (i != (int)action && mBindings[i] == mouse)
			{
				result = i;
				mBindings[i] = mBindings[(int)action];
				break;
			}
		}
		mBindings[(int)action] = mouse;
		SaveControlConfig();
		return result;
	}

	public static void ResetGamePadControls()
	{
		gpBindings = new Buttons[10]
		{
			Buttons.A,
			Buttons.B,
			Buttons.X,
			Buttons.Y,
			Buttons.RightShoulder,
			Buttons.LeftShoulder,
			Buttons.RightTrigger,
			Buttons.LeftTrigger,
			Buttons.Back,
			Buttons.Start
		};
		SaveControlConfig();
	}

	public static void ResetKeyboardControls()
	{
		kbBindings = new Keys[15]
		{
			Keyboard.GetKeyFromScancodeEXT(Keys.Space),
			Keyboard.GetKeyFromScancodeEXT(Keys.E),
			Keyboard.GetKeyFromScancodeEXT(Keys.U),
			Keyboard.GetKeyFromScancodeEXT(Keys.O),
			Keyboard.GetKeyFromScancodeEXT(Keys.Q),
			Keyboard.GetKeyFromScancodeEXT(Keys.Z),
			Keyboard.GetKeyFromScancodeEXT(Keys.LeftControl),
			Keyboard.GetKeyFromScancodeEXT(Keys.F),
			Keyboard.GetKeyFromScancodeEXT(Keys.Escape),
			Keyboard.GetKeyFromScancodeEXT(Keys.Enter),
			Keyboard.GetKeyFromScancodeEXT(Keys.LeftShift),
			Keyboard.GetKeyFromScancodeEXT(Keys.W),
			Keyboard.GetKeyFromScancodeEXT(Keys.S),
			Keyboard.GetKeyFromScancodeEXT(Keys.A),
			Keyboard.GetKeyFromScancodeEXT(Keys.D)
		};
		SaveControlConfig();
	}

	public static void ResetMouseControls()
	{
		mBindings = new int[11]
		{
			-1, -1, 0, 1, -1, -1, -1, -1, -1, -1,
			-1
		};
		SaveControlConfig();
	}

	public static bool RenderingKeyboard()
	{
		return isKeyboard[Math.Max(RenderingPlayer, 0)];
	}

	public static int GetMenuOwner()
	{
		if (Game1.menuMgr != null && Game1.menuMgr.pauseMode)
		{
			return Game1.mainPlayer[Game1.menuMgr.owner];
		}
		return Game1.mainPlayer[0];
	}

	public static bool OwnerIsKeyboard()
	{
		int menuOwner = GetMenuOwner();
		if (MenuMouseMode())
		{
			return isKeyboard[menuOwner];
		}
		return false;
	}

	private static bool MenuMouseMode()
	{
		if (Game1.menuMgr == null || !Game1.menuMgr.pauseMode)
		{
			return GameState.state == GameState.State.Menu;
		}
		return true;
	}

	private static void LoadVideoConfig(out int width, out int height)
	{
		string path = Path.Combine(ConfigDir, "config.ini");
		width = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width;
		height = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height;
		if (!File.Exists(path))
		{
			CurrentMonitor = 0;
			CurrentWindowMode = 0;
			CurrentVSync = 0;
			CurrentVibration = 0;
			CurrentBlood = 0;
			PauseOnLostFocus = 0;
			CurrentMusicVolume = 10;
			CurrentSoundVolume = 10;
			SaveVideoConfig(width, height);
		}
		string[] array = File.ReadAllLines(path);
		string[] array2 = array;
		foreach (string text in array2)
		{
			if (text.Contains("="))
			{
				string[] array3 = text.Split('=');
				if (array3[0] == "display")
				{
					CurrentMonitor = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "display_width")
				{
					width = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "display_height")
				{
					height = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "window_mode")
				{
					CurrentWindowMode = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "vsync")
				{
					CurrentVSync = ((!Convert.ToBoolean(array3[1])) ? 1 : 0);
				}
				else if (array3[0] == "vibration")
				{
					CurrentVibration = ((!Convert.ToBoolean(array3[1])) ? 1 : 0);
				}
				else if (array3[0] == "music_volume")
				{
					CurrentMusicVolume = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "sound_volume")
				{
					CurrentSoundVolume = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "pause_on_lost_focus")
				{
					PauseOnLostFocus = ((!Convert.ToBoolean(array3[1])) ? 1 : 0);
				}
				else if (array3[0] == "blood")
				{
					CurrentBlood = ((!Convert.ToBoolean(array3[1])) ? 1 : 0);
				}
			}
		}
	}

	private static void SaveVideoConfig(int width, int height)
	{
		File.WriteAllText(Path.Combine(ConfigDir, "config.ini"), string.Format("display={1}{0}display_width={2}{0}display_height={3}{0}window_mode={4}{0}vsync={5}{0}vibration={6}{0}music_volume={7}{0}sound_volume={8}{0}pause_on_lost_focus={9}{0}blood={10}", Environment.NewLine, CurrentMonitor, width, height, CurrentWindowMode, CurrentVSync == 0, CurrentVibration == 0, CurrentMusicVolume, CurrentSoundVolume, PauseOnLostFocus == 0, CurrentBlood == 0));
	}

	private static void LoadControlConfig()
	{
		string path = Path.Combine(ConfigDir, "controls.ini");
		CurrentSwapGunRoll = 0;
		if (!File.Exists(path))
		{
			SaveControlConfig();
		}
		string[] array = File.ReadAllLines(path);
		string[] array2 = array;
		foreach (string text in array2)
		{
			if (text.Contains("="))
			{
				string[] array3 = text.Split('=');
				if (array3[0] == "gp_JumpAccept")
				{
					gpBindings[0] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_GrabCancel")
				{
					gpBindings[1] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_Attack")
				{
					gpBindings[2] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_StrongSaw")
				{
					gpBindings[3] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_SwitchWeapons")
				{
					gpBindings[4] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_SwitchLoadouts")
				{
					gpBindings[5] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_Gun")
				{
					gpBindings[6] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_Magic")
				{
					gpBindings[7] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_Inventory")
				{
					gpBindings[8] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "gp_PauseConfirm")
				{
					gpBindings[9] = (Buttons)Enum.Parse(typeof(Buttons), array3[1]);
				}
				else if (array3[0] == "kb_JumpAccept")
				{
					kbBindings[0] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_GrabCancel")
				{
					kbBindings[1] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_Attack")
				{
					kbBindings[2] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_StrongSaw")
				{
					kbBindings[3] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_SwitchWeapons")
				{
					kbBindings[4] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_SwitchLoadouts")
				{
					kbBindings[5] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_Gun")
				{
					kbBindings[6] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_Magic")
				{
					kbBindings[7] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_Inventory")
				{
					kbBindings[8] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_PauseConfirm")
				{
					kbBindings[9] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_WarpRoll")
				{
					kbBindings[10] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_MoveUp")
				{
					kbBindings[11] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_MoveDown")
				{
					kbBindings[12] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_MoveLeft")
				{
					kbBindings[13] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "kb_MoveRight")
				{
					kbBindings[14] = (Keys)Enum.Parse(typeof(Keys), array3[1]);
				}
				else if (array3[0] == "m_JumpAccept")
				{
					mBindings[0] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_GrabCancel")
				{
					mBindings[1] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_Attack")
				{
					mBindings[2] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_StrongSaw")
				{
					mBindings[3] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_SwitchWeapons")
				{
					mBindings[4] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_SwitchLoadouts")
				{
					mBindings[5] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_Gun")
				{
					mBindings[6] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_Magic")
				{
					mBindings[7] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_Inventory")
				{
					mBindings[8] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_PauseConfirm")
				{
					mBindings[9] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "m_WarpRoll")
				{
					mBindings[10] = Convert.ToInt32(array3[1]);
				}
				else if (array3[0] == "swapGunWithWarpRoll")
				{
					CurrentSwapGunRoll = Convert.ToInt32(array3[1]);
				}
			}
		}
	}

	private static void SaveControlConfig()
	{
		File.WriteAllText(Path.Combine(ConfigDir, "controls.ini"), string.Format("gp_JumpAccept={1}{0}gp_GrabCancel={2}{0}gp_Attack={3}{0}gp_StrongSaw={4}{0}gp_SwitchWeapons={5}{0}gp_SwitchLoadouts={6}{0}gp_Gun={7}{0}gp_Magic={8}{0}gp_Inventory={9}{0}gp_PauseConfirm={10}{0}kb_JumpAccept={11}{0}kb_GrabCancel={12}{0}kb_Attack={13}{0}kb_StrongSaw={14}{0}kb_SwitchWeapons={15}{0}kb_SwitchLoadouts={16}{0}kb_Gun={17}{0}kb_Magic={18}{0}kb_Inventory={19}{0}kb_PauseConfirm={20}{0}kb_WarpRoll={21}{0}kb_MoveUp={22}{0}kb_MoveDown={23}{0}kb_MoveLeft={24}{0}kb_MoveRight={25}{0}m_JumpAccept={26}{0}m_GrabCancel={27}{0}m_Attack={28}{0}m_StrongSaw={29}{0}m_SwitchWeapons={30}{0}m_SwitchLoadouts={31}{0}m_Gun={32}{0}m_Magic={33}{0}m_Inventory={34}{0}m_PauseConfirm={35}{0}m_WarpRoll={36}{0}swapGunWithWarpRoll={37}{0}", Environment.NewLine, gpBindings[0], gpBindings[1], gpBindings[2], gpBindings[3], gpBindings[4], gpBindings[5], gpBindings[6], gpBindings[7], gpBindings[8], gpBindings[9], kbBindings[0], kbBindings[1], kbBindings[2], kbBindings[3], kbBindings[4], kbBindings[5], kbBindings[6], kbBindings[7], kbBindings[8], kbBindings[9], kbBindings[10], kbBindings[11], kbBindings[12], kbBindings[13], kbBindings[14], mBindings[0], mBindings[1], mBindings[2], mBindings[3], mBindings[4], mBindings[5], mBindings[6], mBindings[7], mBindings[8], mBindings[9], mBindings[10], CurrentSwapGunRoll));
	}

	private static string GetConfigDir()
	{
		string empty = string.Empty;
		string text = SDL.SDL_GetPlatform();
		if (text.Equals("Linux"))
		{
			empty = Environment.GetEnvironmentVariable("XDG_CONFIG_HOME");
			if (string.IsNullOrEmpty(empty))
			{
				empty = Environment.GetEnvironmentVariable("HOME");
				if (string.IsNullOrEmpty(empty))
				{
					return ".";
				}
				empty = Path.Combine(empty, ".config");
			}
			empty = Path.Combine(empty, "VampireSmile");
		}
		else if (text.Equals("Mac OS X"))
		{
			empty = Environment.GetEnvironmentVariable("HOME");
			if (string.IsNullOrEmpty(empty))
			{
				return ".";
			}
			empty = Path.Combine(empty, "Library/Application Support", "VampireSmile");
		}
		else
		{
			if (!text.Equals("Windows"))
			{
				throw new NotSupportedException("Unhandled SDL2 platform!");
			}
			empty = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "VampireSmile");
		}
		if (!Directory.Exists(empty))
		{
			Directory.CreateDirectory(empty);
		}
		return empty;
	}

	private static string GetSaveDir()
	{
		string text = SDL.SDL_GetPlatform();
		string text2;
		if (text.Equals("Linux"))
		{
			text2 = Environment.GetEnvironmentVariable("XDG_DATA_HOME");
			if (string.IsNullOrEmpty(text2))
			{
				text2 = Environment.GetEnvironmentVariable("HOME");
				if (string.IsNullOrEmpty(text2))
				{
					return ".";
				}
				text2 = Path.Combine(text2, ".local/share");
			}
			text2 = Path.Combine(text2, "VampireSmile");
		}
		else if (text.Equals("Mac OS X"))
		{
			text2 = Environment.GetEnvironmentVariable("HOME");
			if (string.IsNullOrEmpty(text2))
			{
				return ".";
			}
			text2 = Path.Combine(text2, "Library/Application Support", "VampireSmile");
		}
		else
		{
			if (!text.Equals("Windows"))
			{
				throw new NotSupportedException("Unhandled SDL2 platform!");
			}
			text2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "VampireSmile");
		}
		if (!Directory.Exists(text2))
		{
			Directory.CreateDirectory(text2);
		}
		return text2;
	}

	static flibitPort()
	{
		bool[] array = new bool[4];
		isKeyboard = array;
		keyboard = default;
		prevKeyboard = default;
		prevMouse = default;
		int[] array2 = new int[5];
		mouse = array2;
		mouseItems = new MouseMenuItem[256];
		MouseHoverItem = -1;
		MouseHoverLeft = false;
		MouseHoverRight = false;
		MouseClickItem = false;
		MouseClickLeft = false;
		MouseClickRight = false;
		MouseScrollDelta = 0;
		RenderingPlayer = 0;
		gamepadTypes = new GamePadType[4];
		ButtonState[] array3 = new ButtonState[5];
		clickEvents = array3;
		gpBindings = new Buttons[11]
		{
			Buttons.A,
			Buttons.B,
			Buttons.X,
			Buttons.Y,
			Buttons.RightShoulder,
			Buttons.LeftShoulder,
			Buttons.RightTrigger,
			Buttons.LeftTrigger,
			Buttons.Back,
			Buttons.Start,
			Buttons.RightStick
		};
		kbBindings = new Keys[15]
		{
			Keyboard.GetKeyFromScancodeEXT(Keys.Space),
			Keyboard.GetKeyFromScancodeEXT(Keys.E),
			Keyboard.GetKeyFromScancodeEXT(Keys.U),
			Keyboard.GetKeyFromScancodeEXT(Keys.O),
			Keyboard.GetKeyFromScancodeEXT(Keys.Q),
			Keyboard.GetKeyFromScancodeEXT(Keys.Tab),
			Keyboard.GetKeyFromScancodeEXT(Keys.LeftControl),
			Keyboard.GetKeyFromScancodeEXT(Keys.F),
			Keyboard.GetKeyFromScancodeEXT(Keys.Escape),
			Keyboard.GetKeyFromScancodeEXT(Keys.Enter),
			Keyboard.GetKeyFromScancodeEXT(Keys.LeftShift),
			Keyboard.GetKeyFromScancodeEXT(Keys.W),
			Keyboard.GetKeyFromScancodeEXT(Keys.S),
			Keyboard.GetKeyFromScancodeEXT(Keys.A),
			Keyboard.GetKeyFromScancodeEXT(Keys.D)
		};
		kbMenuBindings = new Keys[15]
		{
			Keyboard.GetKeyFromScancodeEXT(Keys.Space),
			Keyboard.GetKeyFromScancodeEXT(Keys.Escape),
			Keyboard.GetKeyFromScancodeEXT(Keys.Q),
			Keyboard.GetKeyFromScancodeEXT(Keys.E),
			Keyboard.GetKeyFromScancodeEXT(Keys.Z),
			Keyboard.GetKeyFromScancodeEXT(Keys.C),
			Keys.None,
			Keys.None,
			Keyboard.GetKeyFromScancodeEXT(Keys.Back),
			Keyboard.GetKeyFromScancodeEXT(Keys.Enter),
			Keys.None,
			Keyboard.GetKeyFromScancodeEXT(Keys.W),
			Keyboard.GetKeyFromScancodeEXT(Keys.S),
			Keyboard.GetKeyFromScancodeEXT(Keys.A),
			Keyboard.GetKeyFromScancodeEXT(Keys.D)
		};
		mBindings = new int[11]
		{
			-1, -1, 0, 1, -1, -1, -1, -1, -1, -1,
			-1
		};
		actionString = new string[11]
		{
			"[A]", "[B]", "[X]", "[Y]", "[r]", "[l]", "[R]", "[L]", "[f]", "[g]",
			"[s]"
		};
		buttonAttribs = new Dictionary<int, int>
		{
			{ 4096, 5 },
			{ 8192, 6 },
			{ 16384, 2 },
			{ 32768, 3 },
			{ 8388608, 11 },
			{ 4194304, 12 },
			{ 256, 9 },
			{ 512, 10 },
			{ 32, 14 },
			{ 16, 15 },
			{ 64, 7 },
			{ 128, 8 },
			{ 1, 34 },
			{ 2, 35 },
			{ 4, 32 },
			{ 8, 33 }
		};
		gpChar = new Dictionary<char, InputAction>
		{
			{
				'A',
				InputAction.JumpAccept
			},
			{
				'B',
				InputAction.GrabCancel
			},
			{
				'b',
				InputAction.GrabCancel
			},
			{
				'X',
				InputAction.Attack
			},
			{
				'x',
				InputAction.Attack
			},
			{
				'Y',
				InputAction.StrongSaw
			},
			{
				'y',
				InputAction.StrongSaw
			},
			{
				'r',
				InputAction.SwitchWeapons
			},
			{
				'l',
				InputAction.SwitchLoadouts
			},
			{
				'R',
				InputAction.Gun
			},
			{
				'L',
				InputAction.Magic
			},
			{
				'f',
				InputAction.Inventory
			},
			{
				'g',
				InputAction.PauseConfirm
			},
			{
				's',
				InputAction.WarpRoll
			},
			{
				'S',
				InputAction.Move
			}
		};
		ConfigDir = GetConfigDir();
		SaveDir = GetSaveDir();
	}
}
