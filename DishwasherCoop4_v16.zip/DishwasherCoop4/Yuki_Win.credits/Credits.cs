using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.hud;
using Yuki_Win.menu;

namespace Yuki_Win.credits;

public class Credits
{
	private float frame;

	private CreditList creditList;

	private float transOutFrame = -1f;

	private float saveInFrame;

	public Credits()
	{
		creditList = new CreditList();
	}

	public void Init()
	{
		frame = 0f;
		saveInFrame = 3f;
		if (GameState.state != GameState.State.Credits)
		{
			Game1.sceneMgr.Read("scene/data/credits.zcx");
			GameState.state = GameState.State.Credits;
			Game1.sceneMgr.curScene = 0;
			Game1.sceneMgr.video.time = 0f;
			transOutFrame = -1f;
		}
	}

	public void Update()
	{
		if (saveInFrame > 0f)
		{
			saveInFrame -= FMan.realTime;
			return;
		}
		Game1.sceneMgr.Update();
		frame += FMan.frameTime;
		if (transOutFrame > 0f)
		{
			transOutFrame -= FMan.frameTime;
			if (transOutFrame <= 0f)
			{
				EndIt();
			}
		}
		else
		{
			if (!(frame > 10f) || Game1.netSession.IsClient())
			{
				return;
			}
			for (int i = 0; i < 4; i++)
			{
				if (flibitPort.GetInputDigital(i, flibitPort.InputAction.JumpAccept))
				{
					if (Game1.netSession.IsHost())
					{
						Game1.netSession.netGame.SendCreditsEnd(Game1.netSession.session);
					}
					transOutFrame = 1f;
				}
			}
		}
	}

	public void ClientCreditsEnd()
	{
		transOutFrame = 1f;
	}

	public void DrawListOnly(SpriteBatch sprite, float v, float alpha)
	{
		creditList.Draw(sprite, v, alpha, menu: true);
	}

	public void Draw(GraphicsDeviceManager dev, SpriteBatch sprite)
	{
		Draw(dev, sprite, -1);
	}

	public void Draw(GraphicsDeviceManager g, SpriteBatch sprite, int threedee)
	{
		_ = g.GraphicsDevice;
		if (saveInFrame > 0f)
		{
			return;
		}
		if (transOutFrame < 0f)
		{
			float num = frame;
			if (num > 1f)
			{
				num = 1f;
			}
			try
			{
				Game1.sceneMgr.video.scenes[0].r = num;
				Game1.sceneMgr.video.scenes[0].g = num;
				Game1.sceneMgr.video.scenes[0].b = num;
			}
			catch
			{
			}
		}
		else
		{
			try
			{
				Game1.sceneMgr.video.scenes[0].r = transOutFrame;
				Game1.sceneMgr.video.scenes[0].g = transOutFrame;
				Game1.sceneMgr.video.scenes[0].b = transOutFrame;
			}
			catch
			{
			}
		}
		Game1.sceneMgr.Draw(g, sprite, threedee, overlay: false);
		SpriteTools.BeginAlpha();
		sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, 0.3f));
		creditList.Draw(sprite, frame, (transOutFrame >= 0f) ? transOutFrame : 1f);
		if (frame > 10f && transOutFrame < 0f)
		{
			BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Skip, 0, 1f);
		}
		SpriteTools.End();
	}

	internal void EndIt()
	{
		GameState.state = GameState.State.Menu;
		Game1.menuMgr.MenuReset();
		if (Game1.netSession.IsHost())
		{
			Game1.menuMgr.SetLevel(MenuManager.LevelTitle.HostLobby);
			Game1.menuMgr.transFrame = 1f;
			Game1.menuMgr.transMode = MenuManager.TransitionMode.In;
		}
		else if (Game1.netSession.IsClient())
		{
			Game1.menuMgr.SetLevel(MenuManager.LevelTitle.Lobby);
			Game1.menuMgr.transFrame = 1f;
			Game1.menuMgr.transMode = MenuManager.TransitionMode.In;
		}
	}
}
