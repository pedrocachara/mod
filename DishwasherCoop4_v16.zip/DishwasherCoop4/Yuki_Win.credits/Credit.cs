using System.Text;

namespace Yuki_Win.credits;

public class Credit
{
	public enum CreditType
	{
		Heading,
		SubHeading,
		Text
	}

	public StringBuilder text;

	public CreditType type;

	public int line;

	public Credit(StringBuilder text, CreditType type, int line)
	{
		this.text = text;
		this.type = type;
		this.line = line;
	}
}
