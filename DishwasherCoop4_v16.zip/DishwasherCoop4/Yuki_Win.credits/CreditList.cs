using System.Collections.Generic;
using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.credits;

public class CreditList
{
	private const float CREDIT_SPEED = 80f;

	private List<Credit> credit;

	private int addLine;

	public CreditList()
	{
		credit = new List<Credit>();
		AddCredit(Credit.CreditType.Text, YukiText.isabella1);
		AddCredit(Credit.CreditType.Text, YukiText.isabella2);
		AddCredit(Credit.CreditType.Text, YukiText.isabella3);
		AddLine();
		AddLine();
		AddLine();
		AddLine();
		AddLine();
		AddLine();
		AddLine();
		AddLine();
		AddCredit(Credit.CreditType.Heading, YukiText.creditsTitle1);
		AddCredit(Credit.CreditType.Heading, YukiText.creditsTitle2);
		AddLine();
		AddCredit(Credit.CreditType.Text, YukiText.credits_by);
		AddLine();
		AddCredit(Credit.CreditType.Text, "james silva");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_ska);
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_leadDishwasher);
		AddCredit(Credit.CreditType.Text, "james silva");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_mkting);
		AddCredit(Credit.CreditType.Text, "dustin burg");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_art);
		AddCredit(Credit.CreditType.Text, "michelle juett");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_contribs);
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "pc version");
		AddCredit(Credit.CreditType.Text, "ethan \"flibitijibibo\" lee");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_voiceYuki);
		AddCredit(Credit.CreditType.Text, "mary morgan");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_neuromancer);
		AddCredit(Credit.CreditType.Text, "audio aggregate");
		AddCredit(Credit.CreditType.Text, "www.audioaggregate.com");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_named);
		AddCredit(Credit.CreditType.Text, "joe ark sun (ceark-toid)");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_special);
		AddCredit(Credit.CreditType.Text, "achievementhunter.com");
		AddCredit(Credit.CreditType.Text, "eric doty");
		AddCredit(Credit.CreditType.Text, "rooster teeth");
		AddCredit(Credit.CreditType.Text, "loïc dansart");
		AddCredit(Credit.CreditType.Text, "adam decker");
		AddCredit(Credit.CreditType.Text, "christina garramore");
		AddCredit(Credit.CreditType.Text, "jono hines");
		AddCredit(Credit.CreditType.Text, "larry hryb");
		AddCredit(Credit.CreditType.Text, "jack pattillo");
		AddCredit(Credit.CreditType.Text, "chris paladino");
		AddCredit(Credit.CreditType.Text, "jacob yerdon");
		AddCredit(Credit.CreditType.Text, "liz yerdon");
		AddCredit(Credit.CreditType.Text, "deb young");
		AddCredit(Credit.CreditType.Text, "stephen young");
		AddCredit(Credit.CreditType.Text, "sharon silva");
		AddCredit(Credit.CreditType.Text, "mom and dad");
		AddCredit(Credit.CreditType.Text, "neko and gato");
		AddCredit(Credit.CreditType.Text, "the xna community");
		AddCredit(Credit.CreditType.Text, "#xna on efnet");
		AddCredit(Credit.CreditType.Text, "god");
		AddLine();
		AddCredit(Credit.CreditType.Heading, "xbox live arcade team");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "producer");
		AddCredit(Credit.CreditType.Text, "stuart platt");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "test lead");
		AddCredit(Credit.CreditType.Text, "daniel e. smith");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "release management");
		AddCredit(Credit.CreditType.Text, "josh mulanax");
		AddCredit(Credit.CreditType.Text, "tyler keenan (volt)");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "product planning & business team");
		AddCredit(Credit.CreditType.Text, "cherie lutz");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "marketing");
		AddCredit(Credit.CreditType.Text, "jennifer yi");
		AddCredit(Credit.CreditType.Text, "daniel mcconnell (act 1)");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "executive producer");
		AddCredit(Credit.CreditType.Text, "mark coates");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "director, mgs xbla publishing");
		AddCredit(Credit.CreditType.Text, "ted woolsey");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "mgs first party central teams");
		AddCredit(Credit.CreditType.Text, "matt golz, test manager");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "vmc test manager");
		AddCredit(Credit.CreditType.Text, "scott r. griffiths");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "vmc senior test lead");
		AddCredit(Credit.CreditType.Text, "cala posey");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "vmc mat tester");
		AddCredit(Credit.CreditType.Text, "samuel tharp");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "vmc test lead");
		AddCredit(Credit.CreditType.Text, "ian doble");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "vmc testers");
		AddCredit(Credit.CreditType.Text, "chris f. mears");
		AddCredit(Credit.CreditType.Text, "gregory blake");
		AddCredit(Credit.CreditType.Text, "brianna gerrish");
		AddCredit(Credit.CreditType.Text, "carlton hagler");
		AddCredit(Credit.CreditType.Text, "brian mccarty");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "localization");
		AddCredit(Credit.CreditType.Text, "malika kherfi");
		AddCredit(Credit.CreditType.Text, "mairead stevens");
		AddCredit(Credit.CreditType.Text, "kevin cooke");
		AddCredit(Credit.CreditType.Text, "shinya muto");
		AddCredit(Credit.CreditType.Text, "hiroyasu mimura");
		AddCredit(Credit.CreditType.Text, "satoru komiya");
		AddCredit(Credit.CreditType.Text, "atsushi horiuchi");
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, "special thanks");
		AddCredit(Credit.CreditType.Text, "oliver miyashita");
		AddCredit(Credit.CreditType.Text, "kevin salcedo");
		AddLine();
		AddLine();
		AddCredit(Credit.CreditType.SubHeading, YukiText.credits_thanks);
		AddLine();
		AddLine();
		AddLine();
		AddLine();
		AddLine();
	}

	public void Draw(SpriteBatch sprite, float frame, float uAlpha)
	{
		Draw(sprite, frame, uAlpha, menu: false);
	}

	public void Draw(SpriteBatch sprite, float frame, float uAlpha, bool menu)
	{
		if (frame < 5f && !menu)
		{
			float alpha = 5f - frame;
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, alpha));
		}
		foreach (Credit item in credit)
		{
			if (item.line < 3)
			{
				if (frame < 7f)
				{
					float alpha2 = 1f;
					if (frame < 1f)
					{
						alpha2 = frame;
					}
					if (frame > 5f)
					{
						alpha2 = (7f - frame) / 2f;
					}
					for (int i = 0; i < 2; i++)
					{
						float num = ((i == 0) ? 0f : 1f);
						Vector2 location = ScrollManager.screenSize / 2f + new Vector2(0f, -30f) + new Vector2(0f, (float)item.line * 30f);
						Text.DrawCText(sprite, location, item.text, new Color(1f * num, 1f * num, 1f * num, alpha2), 0.9f, 1, blur: true);
					}
				}
				continue;
			}
			float num2 = frame;
			if (num2 > 1f)
			{
				num2 = 1f;
			}
			Vector2 vector = new Vector2(ScrollManager.screenSize.X / 2f, 720f) - new Vector2(0f, frame * 80f) + new Vector2(0f, (float)item.line * 50f);
			if (vector.Y < 50f)
			{
				num2 *= vector.Y / 50f;
			}
			if (vector.Y > 670f)
			{
				num2 *= (720f - vector.Y) / 50f;
			}
			for (int j = 0; j < 2; j++)
			{
				Vector2 location2 = vector - new Vector2(4f, 4f) * j;
				float num3 = ((j == 0) ? 0f : 1f);
				float num4 = ((j == 0) ? (num2 * 0.4f) : num2);
				num4 *= uAlpha;
				if (num4 > 0f)
				{
					switch (item.type)
					{
					case Credit.CreditType.Heading:
						Text.DrawJText(sprite, location2, item.text, new Color(1f * num3, 0.8f * num3, 0.7f * num3, num4), 1.2f, 1);
						break;
					case Credit.CreditType.SubHeading:
						Text.DrawCText(sprite, location2, item.text, new Color(1f * num3, 0.8f * num3, 0.7f * num3, num4), 1f, 1);
						break;
					case Credit.CreditType.Text:
						Text.DrawCText(sprite, location2, item.text, new Color(1f * num3, 1f * num3, 1f * num3, num4), 0.9f, 1);
						break;
					}
				}
			}
		}
	}

	private void AddCredit(Credit.CreditType type, string text)
	{
		credit.Add(new Credit(new StringBuilder(text), type, addLine));
		addLine++;
	}

	private void AddLine(int count)
	{
		addLine += count;
	}

	private void AddLine()
	{
		addLine++;
	}
}
