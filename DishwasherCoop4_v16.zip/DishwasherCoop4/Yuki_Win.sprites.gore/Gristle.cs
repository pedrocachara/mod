using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;
using Yuki_Win.player;

namespace Yuki_Win.sprites.gore;

public class Gristle : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.5f, 0.75f);
		p.size = size;
		if (GameSettings.difficulty == 0)
		{
			flags = 1;
		}
		p.flags = Rand.GetRandomInt(0, 4);
		p.thresh = Rand.CointToss(0.5f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.owner = owner;
		if (!p.thresh)
		{
			p.subtractive = true;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		p.traj.Y += FMan.AdjustedFrame(p.owner) * 300f;
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
		if (frame > 0.3f && p.frame <= 0.3f)
		{
			p.traj /= 2f;
		}
		spriteMan.TrimSprite(p);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		sprite.Draw(spritesTex, screenLoc, new Rectangle(p.flags % 2 * 64, p.flags / 2 * 32 + 192, 64, 32), p.subtractive ? new Color(0.5f, 1f, 1f, p.frame * 1f) : new Color(p.thresh ? 0.8f : GameRender.bloodR, p.thresh ? 0f : GameRender.bloodG, p.thresh ? 0f : GameRender.bloodB, p.frame * 0.5f), p.rotation, new Vector2(32f, 16f), p.size * ScrollManager.cannedDepth[0] * 0.62f, SpriteEffects.None, 1f);
	}
}
