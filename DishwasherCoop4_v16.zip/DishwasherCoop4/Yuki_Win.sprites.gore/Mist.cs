using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;
using Yuki_Win.player;

namespace Yuki_Win.sprites.gore;

internal class Mist : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 1.1f;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.r = Rand.GetRandomFloat(-1f, 1f);
		p.owner = owner;
		p.z = Rand.GetRandomFloat(0.9f, 1.3f);
		p.subtractive = false;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
		for (int i = 0; i < 2; i++)
		{
			if (Game1.character[i].exists)
			{
				Vector2 loc = Game1.character[i].charUpdate.loc;
				if (p.loc.X > loc.X - 50f && p.loc.X < loc.X + 50f && p.loc.Y > loc.Y - 100f && p.loc.Y < loc.Y)
				{
					Game1.character[i].charUpdate.StainBody(0);
				}
			}
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = 1f;
		if (p.frame > 1.1f)
		{
			num = (1.2f - p.frame) * 10f;
		}
		else if (p.frame < 1f)
		{
			num = p.frame;
		}
		if (GameSettings.difficulty == 0)
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, p.z), new Rectangle(1024, 960, 64, 32), new Color(1f, 1f, 1f, num * 0.175f), p.rotation, new Vector2(32f, 16f), ScrollManager.cannedDepth[0] * p.size + (1.2f - p.frame) * 4f, SpriteEffects.None, 1f);
		}
		else if (Game1.gameMap.goryoAlpha > 0f)
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, p.z), new Rectangle(768, 256, 128, 128), new Color(GameRender.bloodR, GameRender.bloodG, GameRender.bloodB, num * 0.275f), p.rotation, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * p.size + (1.2f - p.frame) * 2f, SpriteEffects.None, 1f);
		}
		else
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, p.z), new Rectangle(768, 256, 128, 128), new Color(GameRender.bloodR, GameRender.bloodG, GameRender.bloodB, num * 0.75f), p.rotation, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * p.size + (1.2f - p.frame) * 2f, SpriteEffects.None, 1f);
		}
	}
}
