using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;
using Yuki_Win.player;

namespace Yuki_Win.sprites.gore;

public class Glob : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 0.5f;
		p.size = size;
		if (GameSettings.difficulty == 0)
		{
			flags = 1;
		}
		p.thresh = flags == 1;
		if (!p.thresh)
		{
			p.subtractive = true;
		}
		p.flags = Rand.GetRandomInt(0, 4);
		p.rDir = Rand.GetRandomFloat(-2f, 2f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.owner = owner;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.AdjustedFrame(p.owner) * 2f;
		if (p.frame < 0.3f)
		{
			p.traj.Y += FMan.AdjustedFrame(p.owner) * 400f;
			if (Rand.CointToss(0.1f))
			{
				spriteMan.AddWallblood(p.loc);
			}
		}
		spriteMan.TrimSprite(p);
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		Rectangle value = new Rectangle(128 + p.flags % 2 * 64, 96 + p.flags / 2 * 64, 64, 64);
		sprite.Draw(spritesTex, screenLoc, value, p.subtractive ? new Color(0.5f, 1f, 1f, p.frame * 6f) : new Color(new Vector4(p.thresh ? 0.8f : GameRender.bloodR, p.thresh ? 0f : GameRender.bloodG, p.thresh ? 0f : GameRender.bloodB, p.frame)), p.rotation, new Vector2(64f, 32f), (p.size + (0.5f - p.frame)) * ScrollManager.cannedDepth[0] * 0.55f, SpriteEffects.None, 1f);
	}
}
