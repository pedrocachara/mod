using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;
using Yuki_Win.player;

namespace Yuki_Win.sprites.gore;

public class Drop : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.45f, 0.5f);
		p.size = size;
		if (GameSettings.difficulty == 0)
		{
			flags = 1;
		}
		p.thresh = flags == 1;
		p.owner = owner;
		p.flags = Rand.GetRandomInt(0, 4);
		if (!p.thresh)
		{
			p.subtractive = true;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.traj.Y += FMan.frameTime * 500f;
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
		spriteMan.TrimSprite(p);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		p.rotation = Trig.GetAngle(default, p.traj);
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		sprite.Draw(spritesTex, screenLoc, new Rectangle(p.flags * 32, 128, 32, 32), p.subtractive ? new Color(0.5f, 1f, 1f, p.frame * 6f) : new Color(p.thresh ? 0.8f : GameRender.bloodR, p.thresh ? 0f : GameRender.bloodG, p.thresh ? 0f : GameRender.bloodB, p.frame * 4f), p.rotation, new Vector2(16f, 16f), p.size * ScrollManager.cannedDepth[0] * 0.55f, SpriteEffects.None, 1f);
	}
}
