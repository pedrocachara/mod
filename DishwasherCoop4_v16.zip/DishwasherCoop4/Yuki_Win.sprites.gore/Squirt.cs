using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;
using Yuki_Win.player;

namespace Yuki_Win.sprites.gore;

public class Squirt : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.05f, 0.15f);
		p.size = size;
		if (GameSettings.difficulty == 0)
		{
			flags = 1;
		}
		p.thresh = Rand.CointToss(0.5f);
		p.owner = owner;
		p.flags = Rand.GetRandomInt(0, 3);
		if (!p.thresh)
		{
			p.subtractive = true;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		spriteMan.TrimSprite(p);
		p.rotation = Trig.GetAngle(default, p.traj);
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		if (GameSettings.difficulty == 0)
		{
			sprite.Draw(spritesTex, screenLoc, new Rectangle(1024, 960, 64, 32), new Color(1f, 1f, 1f, p.frame * 6f), p.rotation, new Vector2(32f, 16f), p.size * ScrollManager.cannedDepth[0] * 0.55f, SpriteEffects.None, 1f);
		}
		else
		{
			sprite.Draw(spritesTex, screenLoc, new Rectangle(128, p.flags * 32, 128, 32), p.subtractive ? new Color(0.5f, 1f, 1f, p.frame * 6f) : new Color(p.thresh ? 0.8f : GameRender.bloodR, p.thresh ? 0f : GameRender.bloodG, p.thresh ? 0f : GameRender.bloodB, p.frame * 6f), p.rotation, new Vector2(96f, 16f), p.size * ScrollManager.cannedDepth[0] * 0.55f, SpriteEffects.None, 1f);
		}
	}
}
