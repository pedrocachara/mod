using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;
using Yuki_Win.player;

namespace Yuki_Win.sprites.gore;

public class Jet : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 1f;
		p.size = size;
		if (GameSettings.difficulty == 0)
		{
			flags = 1;
		}
		p.thresh = Rand.CointToss(0.5f);
		p.flags = Rand.GetRandomInt(0, 4);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.owner = owner;
		if (!p.thresh)
		{
			p.subtractive = true;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		_ = p.frame;
		p.traj.Y += FMan.AdjustedFrame(p.owner) * 700f;
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.rotation += FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
		if (p.wallFree)
		{
			if (Game1.gameMap.CurMap().TestCol(p.loc))
			{
				p.loc -= p.traj * FMan.AdjustedFrame(p.owner);
				p.frame -= FMan.AdjustedFrame(p.owner) * 2f;
				p.traj *= -0.1f;
			}
		}
		else if (!Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.wallFree = true;
		}
		spriteMan.TrimSprite(p);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		float num = 1f;
		if (p.frame > 0.95f)
		{
			num = (1f - p.frame) * 20f;
		}
		sprite.Draw(spritesTex, screenLoc, new Rectangle(256 + p.flags * 64, 128, 64, 64), p.subtractive ? new Color(0.5f, 1f, 1f, p.frame * 6f) : new Color(new Vector4(p.thresh ? 0.6f : GameRender.bloodR, GameRender.bloodG, GameRender.bloodB, p.frame * num)), p.rotation, new Vector2(32f, 32f), p.size * ScrollManager.cannedDepth[0] * 0.62f * num, SpriteEffects.None, 1f);
	}
}
