using System.IO;

namespace WorldEdit.world;

public class Cell
{
	public string path;

	public bool orig;

	public int origX;

	public int origY;

	public bool hWall;

	public bool vWall;

	public Cell()
	{
	}

	public Cell(BinaryReader reader)
	{
		orig = reader.ReadBoolean();
		if (orig)
		{
			path = reader.ReadString();
		}
		else
		{
			origX = reader.ReadInt32();
			origY = reader.ReadInt32();
		}
		hWall = reader.ReadBoolean();
		vWall = reader.ReadBoolean();
	}

	public void Write(BinaryWriter writer)
	{
		writer.Write(value: true);
		writer.Write(orig);
		if (orig)
		{
			if (path == null)
			{
				writer.Write("null");
			}
			else
			{
				writer.Write(path);
			}
		}
		else
		{
			writer.Write(origX);
			writer.Write(origY);
		}
		writer.Write(hWall);
		writer.Write(vWall);
	}
}
