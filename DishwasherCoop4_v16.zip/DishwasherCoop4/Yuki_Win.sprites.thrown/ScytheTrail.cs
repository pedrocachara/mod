using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.thrown;

internal class ScytheTrail : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 0.5f;
		p.owner = owner;
		p.r = Rand.GetRandomFloat(0f, 6.28f);
		p.flags = 1;
		p.alpha = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(576, 702, 256, 128), new Color(new Vector4(1f, 1f, 1f, p.frame)), p.r, new Vector2(128f, -32f), ScrollManager.cannedDepth[0] * 0.45f, SpriteEffects.None, 1f);
	}
}
