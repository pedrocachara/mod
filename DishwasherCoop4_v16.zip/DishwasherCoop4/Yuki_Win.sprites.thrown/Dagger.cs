using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.thrown;

internal class Dagger : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 2f;
		p.owner = owner;
		p.flags = 1;
		p.hitter = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.flags == 1 && Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.flags = 0;
			p.traj.X *= Rand.GetRandomFloat(-0.2f, 0.2f);
			p.traj.Y *= Rand.GetRandomFloat(-0.4f, 0.1f);
			p.hitter = false;
		}
		p.traj.Y += FMan.frameTime * 2500f * ((p.flags == 1) ? 1f : 0.5f);
		if (p.traj.Y > 2000f)
		{
			p.traj.Y = 2000f;
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640, 96, 64, 32), new Color(new Vector4(1f, 1f, 1f, 1f)), p.hitter ? Trig.GetAngle(default, p.traj) : (p.frame * 8f), new Vector2(32f, 16f), ScrollManager.cannedDepth[0] * 0.35f, SpriteEffects.None, 1f);
	}
}
