using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.director;

namespace Yuki_Win.sprites.thrown;

internal class CircularSaw : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 2f;
		p.owner = owner;
		p.flags = 1;
		p.hitter = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.flags == 1 && Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.flags = 0;
			p.traj.X *= Rand.GetRandomFloat(-0.2f, 0.2f);
			p.traj.Y *= Rand.GetRandomFloat(-0.4f, 0.1f);
			QuakeManager.SetQuake(0.2f);
			p.hitter = false;
		}
		p.traj.Y += FMan.frameTime * 2500f * ((p.flags == 1) ? 1f : 0.5f);
		if (p.traj.Y > 2000f)
		{
			p.traj.Y = 2000f;
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(832, 448, 64, 64), new Color(new Vector4(1f, 1f, 1f, 1f)), p.frame * ((p.traj.X < 0f) ? (-1f) : 1f) * 40f, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * 0.35f, SpriteEffects.None, 1f);
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(896, 448, 128, 64), new Color(new Vector4(1f, 1f, 1f, 1f)), p.frame * ((p.traj.X < 0f) ? 1f : (-1f)) * 10f, new Vector2(64f, 53f), ScrollManager.cannedDepth[0] * 0.35f, (p.traj.X > 0f) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
	}
}
