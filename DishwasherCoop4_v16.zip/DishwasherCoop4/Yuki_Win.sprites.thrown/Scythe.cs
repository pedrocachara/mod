using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.thrown;

internal class Scythe : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 2f;
		p.owner = owner;
		p.flags = 1;
		p.hitter = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		p.traj.Y += FMan.frameTime * 2500f * ((p.flags == 1) ? 1f : 0.5f);
		if (p.traj.Y > 2000f)
		{
			p.traj.Y = 2000f;
		}
		base.Update(p, spriteMan);
		if ((int)(p.frame * 50f) != (int)(frame * 50f))
		{
			spriteMan.AddSprite(54, p.loc, default, 0f, 0, 0);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(0, 832, 256, 120), new Color(new Vector4(1f, 1f, 1f, 1f)), p.frame * ((p.traj.X < 0f) ? 1f : (-1f)) * 30f, new Vector2(128f, 100f), ScrollManager.cannedDepth[0] * 0.55f, (p.traj.X > 0f) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
	}
}
