using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.thrown;

internal class Blade : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 1f;
		p.owner = owner;
		p.r = Rand.GetRandomFloat(-0.3f, 0.3f);
		p.flags = 1;
		p.hitter = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		Vector2 loc = p.loc;
		base.Update(p, spriteMan);
		p.loc = loc;
		if (p.frame < 0.8f)
		{
			p.hitter = false;
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(256, 832, 32, 128);
		if (p.frame < 0.95f && p.frame > 0.05f)
		{
			value.X += 32;
		}
		float y = 1f;
		if (p.frame > 0.9f && p.frame < 0.95f)
		{
			y = 1f + (p.frame - 0.9f) * 3f;
		}
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, Color.White, p.r, new Vector2(16f, 120f), 0.55f * ScrollManager.cannedDepth[0] * new Vector2(1f, y), (!(p.traj.X < 0f)) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
		base.Draw(p, sprite, spritesTex);
	}
}
