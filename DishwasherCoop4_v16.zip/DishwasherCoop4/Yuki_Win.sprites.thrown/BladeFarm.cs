using Microsoft.Xna.Framework;
using Yuki_Win.audio;
using Yuki_Win.maps;

namespace Yuki_Win.sprites.thrown;

internal class BladeFarm : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 0.7f;
		p.owner = owner;
		p.flags = 1;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		base.Update(p, spriteMan);
		if ((int)(p.frame * 30f) == (int)(frame * 30f))
		{
			return;
		}
		Vector2 vector = p.loc + Rand.GetRandomVec2(-10f, 10f, -10f, 10f);
		Map map = Game1.gameMap.CurMap();
		if (map.TestCol(vector + new Vector2(0f, 5f)) && !map.TestCol(vector + new Vector2(0f, -30f)))
		{
			spriteMan.AddSprite(52, vector, p.traj, 0f, 0, p.owner);
			switch (Rand.GetRandomInt(0, 5))
			{
			case 0:
				Sound.PlaySnd(Sound.Category.FX, "sword1");
				break;
			case 1:
				Sound.PlaySnd(Sound.Category.FX, "sword2");
				break;
			case 2:
				Sound.PlaySnd(Sound.Category.FX, "sword3");
				break;
			case 3:
				Sound.PlaySnd(Sound.Category.FX, "swing");
				break;
			case 4:
				Sound.PlaySnd(Sound.Category.FX, "throw");
				break;
			}
		}
	}
}
