using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.player;

namespace Yuki_Win.sprites.explosions;

internal class WhiteSmoke : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.4f, 0.8f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 2);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(704 + p.flags, 64, 64, 64);
		float num = 1f;
		if (GameSettings.difficulty == 0)
		{
			value = new Rectangle(832, 64, 64, 64);
			num = 0.5f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, new Color(new Vector4(1f, num, num, p.frame * 2f)), p.frame * -4f + p.rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * 0.5f * p.size - (1f - p.frame), SpriteEffects.None, 1f);
	}
}
