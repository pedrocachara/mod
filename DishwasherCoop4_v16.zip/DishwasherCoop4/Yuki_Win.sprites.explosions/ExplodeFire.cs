using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.explosions;

internal class ExplodeFire : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.3f, 0.4f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 6);
		p.thresh = true;
		p.alpha = true;
		p.owner = owner;
		p.rDir = p.frame;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		spriteMan.TrimSprite(p);
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(384 + p.flags, 256, 64, 64);
		if (p.alpha && !p.thresh)
		{
			float num = (p.rDir - p.frame) / p.rDir;
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle((int)(num * 10f) * 64, 1088, 64, 64), new Color(1f, p.frame * 2f, 1f, 1f), p.rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * p.size * 0.8f, SpriteEffects.None, 1f);
		}
		else
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, new Color(0f, 1f, 0f, p.frame), p.frame + p.rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
		}
		if (p.size > 0.4f && Rand.CointToss(0.5f))
		{
			PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), 1f, 0.4f, 1f, p.size * 0.6f, p.frame * 0.1f, 1f);
		}
		GameRender.threshRender.AddPoint(ScrollManager.GetScreenLoc(p.loc, 1f), ScrollManager.cannedDepth[0] * p.size * 8f);
	}
}
