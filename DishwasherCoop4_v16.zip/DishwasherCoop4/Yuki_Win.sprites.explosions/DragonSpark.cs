using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.explosions;

internal class DragonSpark : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = default;
		p.frame = 0.05f;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 3);
		p.alpha = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(sourceRectangle: new Rectangle(896, p.flags * 128, 128, 128), texture: spritesTex, position: ScrollManager.GetScreenLoc(p.loc, 1f), color: new Color(new Vector4(1f, 1f, 1f, p.frame * 20f)), rotation: p.rotation, origin: new Vector2(64f, 64f), scale: ScrollManager.cannedDepth[0] * p.size, effects: SpriteEffects.None, layerDepth: 1f);
	}
}
