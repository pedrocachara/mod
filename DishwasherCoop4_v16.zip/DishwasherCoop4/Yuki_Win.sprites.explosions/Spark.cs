using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;
using Yuki_Win.player;

namespace Yuki_Win.sprites.explosions;

internal class Spark : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.1f, 0.5f);
		p.alpha = true;
		p.wallFree = false;
		p.owner = owner;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.frameTime;
		spriteMan.TrimSprite(p);
		p.traj.Y += FMan.AdjustedFrame(p.owner) * 800f;
		if (!Game1.soloMgr.active)
		{
			Vector2 loc = p.loc;
			if (!p.wallFree)
			{
				if (!Game1.gameMap.CurMap().TestCol(p.loc))
				{
					p.wallFree = true;
				}
			}
			else
			{
				for (int i = 0; i < 2; i++)
				{
					if (i == 0)
					{
						p.loc.X += p.traj.X * FMan.frameTime;
					}
					else
					{
						p.loc.Y += p.traj.Y * FMan.frameTime;
					}
					if (Game1.gameMap.CurMap().TestCol(p.loc))
					{
						p.loc = loc;
						if (i == 0)
						{
							p.traj.X = p.traj.X * -0.9f;
						}
						else
						{
							p.traj.Y = p.traj.Y * -0.9f;
						}
					}
				}
			}
		}
		p.rotation = Trig.GetAngle(default, p.traj);
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(704, 0, 160, 64);
		float rotation = p.rotation;
		Vector2 scale = ScrollManager.cannedDepth[0] * 0.5f * new Vector2(Trig.GetDist(default, p.traj) * 0.00075f, 0.35f);
		Vector2 origin = new Vector2(80f, 32f);
		if (GameSettings.difficulty == 0)
		{
			value = new Rectangle(832, 64, 64, 64);
			rotation = 0f;
			scale = new Vector2(1f, 1f) * ScrollManager.cannedDepth[0] * 0.2f;
			origin = new Vector2(32f, 32f);
		}
		if (Game1.soloMgr.active)
		{
			scale.Y *= 2f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, new Color(Rand.GetRandomFloat(0f, 0.6f), 0.7f, 0.8f, p.frame * 20f), rotation, origin, scale, SpriteEffects.None, 1f);
		if (Rand.CointToss(0.1f))
		{
			PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), 0.3f, 0.4f, 1f, Rand.GetRandomFloat(0.5f, 1f), Rand.GetRandomFloat(0.05f, 0.15f), 1f);
		}
	}
}
