using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.explosions;

internal class SmokeFarm : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(1.5f, 2f);
		p.thresh = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		p.frame -= FMan.frameTime;
		if (p.frame > 1f)
		{
			if ((int)(frame * 20f) != (int)(p.frame * 20f))
			{
				spriteMan.AddSprite(18, p.loc, Rand.GetRandomVec2(-10f, 10f, -20f, 0f), Rand.GetRandomFloat(0.5f, 1f) * p.frame + 0.1f, 0, 0);
			}
		}
		else if ((int)(frame * 40f) != (int)(p.frame * 40f))
		{
			spriteMan.AddSprite(18, p.loc, Rand.GetRandomVec2(-10f, 10f, -20f, 0f), Rand.GetRandomFloat(0.5f, 1f) * p.frame + 0.1f, 0, 0);
		}
		p.traj.Y += FMan.frameTime * 800f;
		Vector2 loc = p.loc;
		for (int i = 0; i < 2; i++)
		{
			if (i == 0)
			{
				p.loc.X += p.traj.X * FMan.frameTime;
			}
			else
			{
				p.loc.Y += p.traj.Y * FMan.frameTime;
			}
			if (Game1.gameMap.CurMap().TestCol(p.loc))
			{
				p.loc = loc;
				if (i == 0)
				{
					p.traj.X = p.traj.X * -0.9f;
				}
				else
				{
					p.traj.Y = p.traj.Y * -0.9f;
				}
			}
		}
		if (spriteMan.totalSprites > 400)
		{
			p.frame -= FMan.frameTime;
		}
		if (spriteMan.totalSprites > 600)
		{
			p.frame -= FMan.frameTime;
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(sourceRectangle: new Rectangle(576, 256, 64, 64), texture: spritesTex, position: ScrollManager.GetScreenLoc(p.loc, 1f), color: new Color(new Vector4(0f, Rand.GetRandomFloat(0f, 1f), 0f, p.frame)), rotation: Rand.GetRandomFloat(0f, 6.28f), origin: new Vector2(32f, 32f), scale: ScrollManager.cannedDepth[0] * 0.5f * Rand.GetRandomFloat(0.1f, 0.2f), effects: SpriteEffects.None, layerDepth: 1f);
		PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), 1f, 0.4f, 1f, Rand.GetRandomFloat(0.5f, 1f), Rand.GetRandomFloat(0.05f, 0.45f), 1f);
	}
}
