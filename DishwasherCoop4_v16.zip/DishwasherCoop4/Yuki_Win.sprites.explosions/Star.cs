using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.explosions;

public class Star : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.5f, 1f);
		p.owner = owner;
		p.alpha = true;
		p.size = size;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.rDir = Rand.GetRandomFloat(-0.1f, 0.1f);
		p.b = Rand.GetRandomFloat(0f, 1f);
		p.r = p.frame;
		p.g = Rand.GetRandomFloat(0.28f, 0.32f);
		p.z = Rand.GetRandomFloat(0.9f, 1.3f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.AdjustedFrame(p.owner);
		p.g -= FMan.AdjustedFrame(p.owner);
		if (p.g < 0f)
		{
			if (p.traj.X > 50f)
			{
				p.traj.X = Rand.GetRandomFloat(-50f, 50f);
			}
			if (p.traj.X < -50f)
			{
				p.traj.X = Rand.GetRandomFloat(-50f, 50f);
			}
			if (p.traj.Y > 50f)
			{
				p.traj.Y = 50f;
			}
			if (p.traj.Y < -10f)
			{
				p.traj.Y = -10f;
			}
			p.traj.Y += FMan.frameTime * 800f;
		}
		else
		{
			float num = p.traj.Length() * 0.005f;
			if (p.g < 0.2f)
			{
				num *= p.g * 5f;
			}
			p.b = num;
			p.rotation = Trig.GetAngle(default, p.traj);
		}
		p.traj.Y += FMan.AdjustedFrame(p.owner) * 100f;
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float max = 1f;
		if (p.frame > 4.9f)
		{
			max = (5f - p.frame) * 10f;
		}
		else if (p.frame < 0.5f)
		{
			max = p.frame * 2f;
		}
		int randomInt = Rand.GetRandomInt(0, 5);
		Vector2 vector = new Vector2(1f, 1f);
		if (p.g >= 0f)
		{
			vector.X += p.b;
			vector.Y -= p.b / 2f;
			if (vector.Y < 0.4f)
			{
				vector.Y = 0.4f;
			}
		}
		for (int i = 0; i < 1; i++)
		{
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, p.z), new Rectangle(640 + (randomInt + i) % 6 * 32, 1088, 32, 32), new Color(1f, 0.1f, p.b, Rand.GetRandomFloat(0f, max)), p.rotation, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * p.size * vector, SpriteEffects.None, 1f);
		}
		float num = (p.r - p.frame) * 3f;
		if (num < 1f)
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, p.z), new Rectangle((int)(num * 10f) * 64, 1088, 64, 64), new Color(new Vector4(1f, p.frame * 2f, 1f, 1f)), p.rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * p.size * 0.5f * vector, SpriteEffects.None, 1f);
		}
	}
}
