using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.player;

namespace Yuki_Win.sprites.explosions;

internal class DarkSmoke : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(2f, 2.2f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 8);
		p.owner = owner;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
		spriteMan.TrimSprite(p);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(704 + p.flags % 2, 64, 64, 64);
		if (p.flags < 6)
		{
			value = new Rectangle(384 + p.flags, 320, 64, 64);
		}
		float r = 0f;
		float num = p.size;
		float rotation = ((p.flags < 6) ? p.rotation : (p.frame * -4f + p.rotation));
		if (GameSettings.difficulty == 0)
		{
			value = new Rectangle(832, 64, 64, 64);
			r = 1f;
			num /= 5f;
			rotation = 0f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, new Color(r, 0f, 0f, p.frame * 0.4f), rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * num + (1.2f - p.frame) * 0.3f, SpriteEffects.None, 1f);
	}
}
