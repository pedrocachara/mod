using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.chars;
using Yuki_Win.levels;
using Yuki_Win.menu;

namespace Yuki_Win.arcade;

public class Arcade
{
	public enum ArcadeMode
	{
		Off,
		Arcade,
		DishChallenge
	}

	public const int ARCADE_PLAYER_YUKI = 0;

	public const int ARCADE_PLAYER_DISHWASHER = 1;

	public const int ARCADE_PLAYER_LOїC = 2;

	public const int ARCADE_PLAYER_HARGREAVES = 3;

	public const int ARCADE_PLAYER_MARA = 4;

	public int players;

	public int[] player;

	public ArcadeMode arcadeMode;

	private float frame;

	public float blitzFrame;

	public float slowVal = 3f;

	public float[,] hotPotatoFrame = new float[4, 2];

	public static Dictionary<Level.ArcadeSpecial, StringBuilder[]> arcadeStrings;

	public Arcade()
	{
		player = new int[4];
		arcadeStrings = new Dictionary<Level.ArcadeSpecial, StringBuilder[]>();
		arcadeStrings.Add(Level.ArcadeSpecial.Aerials, new StringBuilder[3]
		{
			new StringBuilder(YukiText.aerials),
			new StringBuilder(YukiText.aerials_desc1),
			new StringBuilder(YukiText.aerials_desc2)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.Blitz, new StringBuilder[5]
		{
			new StringBuilder(YukiText.blitz),
			new StringBuilder(YukiText.blitz_desc1),
			new StringBuilder(YukiText.blitz_desc2),
			new StringBuilder(YukiText.blitz_desc3),
			new StringBuilder(YukiText.blitz_desc4)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.TurboBlitz, new StringBuilder[5]
		{
			new StringBuilder(YukiText.blitz),
			new StringBuilder(YukiText.blitz_desc1a),
			new StringBuilder(YukiText.blitz_desc2a),
			new StringBuilder(YukiText.blitz_desc3),
			new StringBuilder(YukiText.blitz_desc4)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.ColorKeys, new StringBuilder[4]
		{
			new StringBuilder(YukiText.colorKeys),
			new StringBuilder(YukiText.colorKeys_desc1),
			new StringBuilder(YukiText.colorKeys_desc2),
			new StringBuilder(YukiText.colorKeys_desc3)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.HotPotato, new StringBuilder[4]
		{
			new StringBuilder(YukiText.hotPotato),
			new StringBuilder(YukiText.hotPotato_desc1),
			new StringBuilder(YukiText.hotPotato_desc2),
			new StringBuilder(YukiText.hotPotato_desc3)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.Instakill, new StringBuilder[4]
		{
			new StringBuilder(YukiText.instakill),
			new StringBuilder(YukiText.instakill_desc1),
			new StringBuilder(YukiText.instakill_desc2),
			new StringBuilder(YukiText.instakill_desc3)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.PowerPlayer, new StringBuilder[6]
		{
			new StringBuilder(YukiText.powerPlayer),
			new StringBuilder(YukiText.powerPlayer_desc1),
			new StringBuilder(YukiText.powerPlayer_desc2),
			null,
			new StringBuilder(YukiText.powerPlayer_desc3),
			new StringBuilder(YukiText.powerPlayer_desc4)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.Slow, new StringBuilder[4]
		{
			new StringBuilder(YukiText.bulletTime),
			new StringBuilder(YukiText.bulletTime_desc1),
			new StringBuilder(YukiText.bulletTime_desc2),
			new StringBuilder(YukiText.bulletTime_desc3)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.SplitAerials, new StringBuilder[6]
		{
			new StringBuilder(YukiText.splitAerials),
			new StringBuilder(YukiText.splitAerials_desc1),
			new StringBuilder(YukiText.splitAerials_desc2),
			null,
			new StringBuilder(YukiText.splitAerials_desc3),
			new StringBuilder(YukiText.splitAerials_desc4)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.NomNom, new StringBuilder[4]
		{
			new StringBuilder(YukiText.omNomNom),
			new StringBuilder(YukiText.omNomNom_desc1),
			new StringBuilder(YukiText.omNomNom_desc2),
			new StringBuilder(YukiText.omNomNom_desc3)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.CrackingSkull, new StringBuilder[5]
		{
			new StringBuilder(YukiText.crackingSkulls),
			new StringBuilder(YukiText.crackingSkulls_desc1),
			new StringBuilder(YukiText.crackingSkulls_desc2),
			new StringBuilder(YukiText.crackingSkulls_desc3),
			new StringBuilder(YukiText.crackingSkulls_desc4)
		});
		arcadeStrings.Add(Level.ArcadeSpecial.Vampire, new StringBuilder[5]
		{
			new StringBuilder(YukiText.vampire),
			new StringBuilder(YukiText.vampire_desc1),
			new StringBuilder(YukiText.vampire_desc2),
			new StringBuilder(YukiText.vampire_desc3),
			new StringBuilder(YukiText.vampire_desc4)
		});
	}

	// Indice (0 ou 1) da configuracao do level usada pelo jogador ID (armas/tipo). Suporta 3-4 jogadores.
	public int GetLevelSrc(Level level, int ID)
	{
		int src = ((players > 2 && ID > 0) ? 0 : ID);
		if (src > 1)
		{
			src = 0;
		}
		if (players >= 2 && arcadeMode == ArcadeMode.Arcade)
		{
			int pickA = Game1.slotChar[ID];
			bool wantDish = pickA == 1 || pickA == 3;
			for (int sIdx = 0; sIdx < 2; sIdx++)
			{
				int t = level.arcadePlayer[sIdx];
				if ((t == 1 || t == 2 || t == 3) == wantDish)
				{
					src = sIdx;
					break;
				}
			}
		}
		return src;
	}

	public bool GetArcadeCoop()
	{
		if (arcadeMode == ArcadeMode.Arcade)
		{
			return players >= 2;
		}
		return false;
	}

	// PvP arena: sem inimigos, melhor de 3 rodadas.
	public void PvpTick()
	{
		if (!Game1.pvpMatch)
		{
			return;
		}
		if (GameState.state != GameState.State.Playing || Game1.menuMgr.pauseMode)
		{
			return;
		}
		for (int e = 4; e < Game1.character.Length; e++)
		{
			if (Game1.character[e].exists && Game1.character[e].team == Character.Team.BadGuys)
			{
				Game1.character[e].exists = false;
			}
		}
		if (Game1.pvpState == 0)
		{
			Game1.pvpFrame += FMan.realTime;
			int alive = 0;
			int last = -1;
			for (int j = 0; j < Game1.coopPlayers && j < 4; j++)
			{
				if (Game1.character[j].exists && Game1.character[j].team == Character.Team.GoodGuys && Game1.character[j].charUpdate.hp >= 0f)
				{
					alive++;
					last = j;
				}
			}
			if (Game1.pvpFrame > 1.5f && alive <= 1)
			{
				Game1.pvpWinner = ((alive == 1) ? last : (-1));
				if (Game1.pvpWinner >= 0)
				{
					Game1.pvpWins[Game1.pvpWinner]++;
				}
				Game1.pvpFrame = 0f;
				Game1.pvpState = ((Game1.pvpWinner >= 0 && Game1.pvpWins[Game1.pvpWinner] >= Game1.pvpRoundsToWin) ? 2 : 1);
			}
		}
		else if (Game1.pvpState == 1)
		{
			Game1.pvpFrame += FMan.realTime;
			if (Game1.pvpFrame > 3f)
			{
				Game1.pvpRound++;
				Game1.pvpFrame = 0f;
				Game1.pvpState = 0;
				Game1.levelMgr.NewLevel(Game1.levelMgr.currentLevel, Game1.levelMgr.currentTrack, newGame: true);
			}
		}
		else if (Game1.pvpState == 2)
		{
			Game1.pvpFrame += FMan.realTime;
			if (Game1.pvpFrame > 5f)
			{
				Game1.pvpState = 3;
				Game1.PvpStop();
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.ResetMenu;
			}
		}
	}

	public void Update()
	{
		frame += FMan.frameTime;
		if (frame > 100f)
		{
			frame -= 100f;
		}
		switch (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial)
		{
		case Level.ArcadeSpecial.Vampire:
		{
			for (int j = 0; j < 2; j++)
			{
				if (!Game1.character[j].exists)
				{
					continue;
				}
				if (Game1.character[j].charUpdate.hp > 2f)
				{
					Game1.character[j].charUpdate.hp -= FMan.frameTime * 2f;
					if (Game1.character[j].charUpdate.hp < 2f)
					{
						Game1.character[j].charUpdate.hp = 2f;
					}
				}
				Game1.character[j].charUpdate.killsToHealth = 0;
			}
			break;
		}
		case Level.ArcadeSpecial.Slow:
		{
			slowVal = 1f;
			long num = 0L;
			for (int m = 0; m < 2; m++)
			{
				if (Game1.gamePlayerMgr.gamePlayer[m].active && Game1.gamePlayerMgr.gamePlayer[m].comboFrame > 0f && Game1.gamePlayerMgr.gamePlayer[m].comboCount > num)
				{
					num = Game1.gamePlayerMgr.gamePlayer[m].comboCount;
				}
			}
			if (num > 5)
			{
				slowVal = 1f + ((float)num - 5f) / 30f;
				if (slowVal > 2f)
				{
					slowVal = 2f;
				}
			}
			FMan.frameTime /= slowVal;
			break;
		}
		case Level.ArcadeSpecial.Blitz:
		case Level.ArcadeSpecial.TurboBlitz:
		{
			if (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.TurboBlitz && blitzFrame > 60f)
			{
				blitzFrame = 60f;
			}
			if (GameState.state != GameState.State.Playing)
			{
				break;
			}
			for (int k = 0; k < Game1.character.Length; k++)
			{
				if (!Game1.character[k].exists || Game1.character[k].team != Character.Team.BadGuys)
				{
					continue;
				}
				blitzFrame -= FMan.frameTime;
				if (!(blitzFrame < 0f))
				{
					break;
				}
				for (int l = 0; l < 2; l++)
				{
					if (Game1.character[l].exists && Game1.character[l].charUpdate.hp >= 0f)
					{
						Game1.character[l].charUpdate.hp = -10f;
						Game1.character[l].charAnim.SetAnim("jhit", Game1.character[l].charUpdate);
						Game1.character[l].charUpdate.traj = new Vector2(0f, -300f);
						Game1.character[l].charUpdate.state = CharUpdate.State.Airborne;
					}
				}
				if (MainPlayer.uberDyingFrame < 1f)
				{
					MainPlayer.uberDyingFrame = 1f;
					Game1.menuMgr.SetLevel(MenuManager.LevelTitle.ArcadeYouAreDead);
					Game1.menuMgr.levels[16].alpha = 0f;
				}
				break;
			}
			break;
		}
		case Level.ArcadeSpecial.HotPotato:
		{
			for (int i = 0; i < 2; i++)
			{
				if (Game1.character[i].exists && Game1.character[i].charUpdate.hp >= 0f)
				{
					hotPotatoFrame[i, 0] += FMan.frameTime * 0.5f;
					if (hotPotatoFrame[i, 1] > 0f)
					{
						hotPotatoFrame[i, 1] -= FMan.frameTime;
					}
				}
			}
			break;
		}
		}
	}

	internal void Init()
	{
		blitzFrame = 120f;
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				hotPotatoFrame[i, j] = 0f;
			}
		}
	}
}
