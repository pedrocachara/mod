﻿using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.hud;
using Yuki_Win.levels;
using Yuki_Win.player;

namespace Yuki_Win.arcade;

public class ArcadeInScreen
{
	public bool active;

	private float inFrame;

	private float outFrame;

	public float elapsedFrame;

	private float frame;

	public void Init()
	{
		active = true;
		inFrame = 0f;
		outFrame = -1f;
		elapsedFrame = 0f;
	}

	public bool IsActive()
	{
		if (!active)
		{
			return false;
		}
		if (outFrame <= 0f)
		{
			return true;
		}
		return false;
	}

	public void Update()
	{
		if (inFrame < 1f)
		{
			inFrame += FMan.realTime;
		}
		else if (outFrame >= 0f)
		{
			outFrame += FMan.realTime;
			if (outFrame >= 1f)
			{
				active = false;
			}
		}
		else if (!Game1.netSession.IsClient() && (Game1.character[0].charKeys.keyJump || Game1.AnyCoopJump()))
		{
			outFrame = 0f;
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.StartArcade(Game1.netSession.session);
			}
		}
		frame += FMan.realTime;
		if (frame > 12.56f)
		{
			frame -= 12.56f;
		}
		elapsedFrame += FMan.realTime;
	}

	public void GetHostArcadeGoSignal()
	{
		if (outFrame < 0f)
		{
			outFrame = 0f;
		}
	}

	private void DrawWeapon(SpriteBatch sprite, InvCatalog.InvItemName name, Vector2 orig, float alpha, float frame)
	{
		sprite.Draw(Game1.spritesTex, orig, new Rectangle(320, 0, 128, 128), new Color(0f, 0f, 0f, alpha), 0f, new Vector2(64f, 64f), 1.4f, SpriteEffects.None, 1f);
		for (int i = 0; i < 2; i++)
		{
			sprite.Draw(Game1.spritesTex, orig, new Rectangle(384 + i % 6 * 64, 320, 64, 64), new Color(1f, 1f, 1f, alpha * 0.3f), frame * ((i == 0) ? (-0.5f) : 0.5f) + (float)i, new Vector2(32f, 32f), 2f, SpriteEffects.None, 1f);
		}
		sprite.Draw(Game1.itemsTex, orig, Game1.invCatalog.GetInvitemRect(name), new Color(1f, 1f, 1f, alpha), 0f, new Vector2(64f, 64f) * 2f, 0.5f, SpriteEffects.None, 1f);
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		float num = 1f;
		if (inFrame < 1f)
		{
			num = inFrame;
		}
		else if (outFrame > 0f)
		{
			num = 1f - outFrame;
		}
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		SpriteTools.BeginAlpha();
		sprite.Draw(Game1.bgTex[0], new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0.1f, 0.1f, 0.1f, num));
		int key = 3;
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.DishChallenge)
		{
			key = 4;
		}
		for (int i = 0; i < Game1.arcade.players; i++)
		{
			float num2 = 640f;
			num2 = ScrollManager.screenSize.X / 2f - 280f + 560f * (float)i;
			if (Game1.arcade.players > 2)
			{
				num2 = ScrollManager.screenSize.X * ((float)i + 0.5f) / (float)Game1.arcade.players;
			}
			int num3 = 0;
			switch (Game1.arcade.player[i])
			{
			case 1:
				num3 = 0;
				break;
			case 0:
				num3 = 1;
				break;
			case 2:
				num3 = 2;
				break;
			case 4:
				num3 = 3;
				break;
			case 3:
				num3 = 4;
				break;
			}
			float num4 = 470f;
			num4 = ScrollManager.screenSize.Y * 0.65f;
			for (int j = 0; j < 5; j++)
			{
				sprite.Draw(Game1.spritesTex, new Vector2(num2 - 100f + (float)j * 50f, num4 - 100f + (float)j * 50f) + vector * 0.5f, new Rectangle(384 + (i + j) % 6 * 64, 320, 64, 64), new Color(1f, 1f, 1f, num * 0.07f), frame / 2f, new Vector2(32f, 32f), 5f, SpriteEffects.None, 1f);
				sprite.Draw(Game1.spritesTex, new Vector2(num2 + 100f - (float)j * 50f, num4 - 100f + (float)j * 50f) + vector * 0.5f, new Rectangle(384 + (i + j + 3) % 6 * 64, 320, 64, 64), new Color(1f, 1f, 1f, num * 0.07f), frame / 2f, new Vector2(32f, 32f), 5f, SpriteEffects.None, 1f);
			}
			sprite.Draw(Game1.portraitsTex, new Vector2(num2, num4) + vector, new Rectangle(num3 * 384, 0, 384, 640), new Color(1f, 1f, 1f, num), 0f, new Vector2(192f, 360f), 0.8f, SpriteEffects.None, 1f);
		}
		for (int k = 0; k < Game1.arcade.players; k++)
		{
			Vector2 vector2 = new Vector2(ScrollManager.screenSize.X / 4f + ScrollManager.screenSize.X / 2f * (float)k, ScrollManager.screenSize.Y * 0.55f);
			if (Game1.arcade.players > 2)
			{
				vector2.X = ScrollManager.screenSize.X * ((float)k + 0.5f) / (float)Game1.arcade.players;
			}
			int ks = Game1.arcade.GetLevelSrc(Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel], k);
			int num5 = 0;
			for (int l = 0; l < 5; l++)
			{
				float num6 = 4.14f - (float)num5;
				num6 += (float)Math.Cos(frame + (float)k + (float)num5) * 0.1f;
				Vector2 vector3 = new Vector2((float)Math.Cos(num6), (float)Math.Sin(num6)) * 160f;
				if (k % 2 == 1)
				{
					vector3.X = 0f - vector3.X;
				}
				if (l < 2)
				{
					if (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].arcadeWeapon[ks, l] != InvCatalog.InvItemName.None)
					{
						DrawWeapon(sprite, Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].arcadeWeapon[ks, l], vector2 + vector3 + vector * 0.9f, num, frame);
						num5++;
					}
					continue;
				}
				switch (l)
				{
				case 2:
					if (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].gunMode != Level.GunMode.None)
					{
						switch (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].arcadePlayer[ks])
						{
						case 1:
						case 2:
						case 3:
							DrawWeapon(sprite, InvCatalog.InvItemName.Uzi, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						case 0:
						case 4:
							DrawWeapon(sprite, InvCatalog.InvItemName.GunArm, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						}
						num5++;
					}
					break;
				case 3:
					if (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].gunMode == Level.GunMode.Shotty)
					{
						switch (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].arcadePlayer[ks])
						{
						case 1:
						case 2:
						case 3:
							DrawWeapon(sprite, InvCatalog.InvItemName.Shotty, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						case 0:
						case 4:
							DrawWeapon(sprite, InvCatalog.InvItemName.ShottyArm, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						}
						num5++;
					}
					break;
				case 4:
					if (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].magic == Level.ArcadeMagic.None)
					{
						break;
					}
					switch (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].arcadePlayer[ks])
					{
					case 1:
					case 2:
					case 3:
						switch (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].magic)
						{
						case Level.ArcadeMagic.Electric:
							DrawWeapon(sprite, InvCatalog.InvItemName.ElectricDishMagic, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						case Level.ArcadeMagic.Steel:
							DrawWeapon(sprite, InvCatalog.InvItemName.SteelDishMagic, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						case Level.ArcadeMagic.Devouring:
							DrawWeapon(sprite, InvCatalog.InvItemName.DevouringDishMagic, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						case Level.ArcadeMagic.Holy:
							DrawWeapon(sprite, InvCatalog.InvItemName.HolyDishMagic, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						}
						break;
					case 0:
					case 4:
						switch (Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].magic)
						{
						case Level.ArcadeMagic.Electric:
							DrawWeapon(sprite, InvCatalog.InvItemName.ElectricBloodMagic, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						case Level.ArcadeMagic.Steel:
							DrawWeapon(sprite, InvCatalog.InvItemName.SteelBloodMagic, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						case Level.ArcadeMagic.Devouring:
							DrawWeapon(sprite, InvCatalog.InvItemName.DevouringBloodMagic, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						case Level.ArcadeMagic.Holy:
							DrawWeapon(sprite, InvCatalog.InvItemName.HolyBloodMagic, vector2 + vector3 + vector * 0.9f, num, frame);
							break;
						}
						break;
					}
					num5++;
					break;
				}
			}
		}
		Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 100f) + vector, Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].nameStr, new Color(1f, 1f, 1f, num), 1.5f, 1);
		float scale = 1f;
		for (int m = 0; m < 2; m++)
		{
			Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 180f + (float)m * 40f) + vector, Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].desc[m], new Color(1f, 1f, 1f, num), scale, 1);
		}
		Level.ArcadeSpecial arcadeSpecial = Game1.levelMgr.levels[key][Game1.levelMgr.currentLevel].arcadeSpecial;
		if (arcadeSpecial != Level.ArcadeSpecial.None)
		{
			float num7 = ScrollManager.screenSize.Y * 0.88f;
			num7 -= (float)Arcade.arcadeStrings[arcadeSpecial].Length * 26f;
			float num8 = 0f;
			for (int n = 0; n < Arcade.arcadeStrings[arcadeSpecial].Length; n++)
			{
				float stringSpace = Text.GetStringSpace(Arcade.arcadeStrings[arcadeSpecial][n]);
				if (stringSpace > num8)
				{
					num8 = stringSpace;
				}
			}
			float num9 = (float)Arcade.arcadeStrings[arcadeSpecial].Length * 29f + 10f + 40f;
			num8 += 30f;
			sprite.Draw(Game1.spritesTex, new Rectangle((int)ScrollManager.screenSize.X / 2 - (int)(num8 / 2f) + (int)vector.X, (int)num7 - 16, (int)num8, (int)num9), new Rectangle(640, 384, 256, 64), new Color(0f, 0f, 0f, num * 0.4f), 0f, default, SpriteEffects.None, 1f);
			sprite.Draw(Game1.spritesTex, new Rectangle((int)ScrollManager.screenSize.X / 2 - (int)(num8 / 2f) - 5 + (int)vector.X, (int)num7 - 16 - 5, (int)num8 + 10, (int)num9 + 10), new Rectangle(640, 384, 256, 64), new Color(0f, 0f, 0f, num * 0.4f), 0f, default, SpriteEffects.None, 1f);
			for (int num10 = 0; num10 < Arcade.arcadeStrings[arcadeSpecial].Length; num10++)
			{
				Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, num7 + (float)num10 * 26f + ((num10 > 0) ? 10f : 0f)) + vector, Arcade.arcadeStrings[arcadeSpecial][num10], (num10 == 0) ? new Color(1f, 0f, 0f, num) : new Color(1f, 1f, 1f, num), 0.9f, 1);
			}
		}
		if (inFrame >= 1f && outFrame < 0f)
		{
			if (Game1.netSession.IsClient())
			{
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.WaitingForHost, 0, 1f);
			}
			else
			{
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Continue, 0, 1f);
			}
		}
		sprite.End();
	}
}
