using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.menu.levels;
using Yuki_Win.player;

namespace Yuki_Win.leaderboards;

public class LeaderEntry
{
	public StringBuilder name;

	public long score;

	public StringBuilder time;

	public long rank;

	public bool exists;

	public int w1;

	public int w2;

	public int character;

	public Gamer gamer;

	public void Init(long rank, Gamer gamer, string name, long score, long ntime)
	{
		Init(rank, gamer, name, score, ntime, -1, -1, -1);
	}

	public void Init(long rank, Gamer gamer, string name, long score, long ntime, int w1, int w2, int character)
	{
		exists = true;
		this.rank = rank;
		float num = (float)ntime / 100f;
		if (ntime > -1)
		{
			if (ntime == long.MaxValue)
			{
				time = new StringBuilder("--:--");
			}
			else
			{
				string text = "";
				int num2 = (int)num;
				int num3 = num2 % 60;
				text = num3.ToString();
				if (num3 < 10)
				{
					text = "0" + text;
				}
				text = num2 / 60 + ":" + text;
				int num4 = (int)((num - (float)(int)num) * 100f);
				string text2 = num4.ToString();
				if (num4 < 10)
				{
					text2 = "0" + text2;
				}
				if (num4 == 0)
				{
					text2 = "00";
				}
				text = text + "." + text2;
				time = new StringBuilder(text);
			}
		}
		else
		{
			time = null;
		}
		this.name = new StringBuilder(name);
		this.score = score;
		this.w1 = w1;
		this.w2 = w2;
		this.character = character;
		this.gamer = gamer;
	}

	public void Draw(SpriteBatch sprite, Vector2 orig, int line, float alpha, bool selected)
	{
		Vector2 vector = orig + new Vector2(0f, (float)line * 28f);
		float num = 0.9f;
		for (int i = 0; i < 2; i++)
		{
			Vector2 vector2 = ((i == 0) ? new Vector2(3f, 3f) : default(Vector2));
			Color color = ((i == 0) ? new Color(0f, 0f, 0f, alpha * 0.4f) : new Color(1f, 1f, 1f, alpha));
			if (i == 1 && selected)
			{
				color = new Color(1f, 0f, 0f, alpha);
			}
			Text.DrawScore((int)(vector.X + vector2.X), (int)(vector.Y + vector2.Y), rank, color, sprite, flip: false, 0f, dashZero: true, num, blur: true);
			Text.DrawLCText(sprite, vector + vector2 + new Vector2(40f, 0f), name, color, num, 0, blur: true);
			if (score > -1)
			{
				Text.DrawScore((int)(vector.X + vector2.X + 560f), (int)(vector.Y + vector2.Y), score, color, sprite, flip: false, 0f, dashZero: true, num, blur: true);
			}
			else if (time != null)
			{
				Text.DrawLCText(sprite, vector + vector2 + new Vector2(560f, 0f), time, color, num, 2, blur: true);
			}
		}
		if (character > -1)
		{
			float num2 = 580f;
			switch (character)
			{
			case 1:
				sprite.Draw(Game1.headTex[4], vector + new Vector2(num2, 0f), new Rectangle(0, 40, 50, 40), new Color(1f, 1f, 1f, alpha), 0f, default, 0.72f, SpriteEffects.None, 1f);
				break;
			case 0:
				sprite.Draw(Game1.headTex[0], vector + new Vector2(num2, 0f), new Rectangle(0, 80, 50, 40), new Color(1f, 1f, 1f, alpha), 0f, default, 0.72f, SpriteEffects.None, 1f);
				break;
			}
			for (int j = 0; j < 2; j++)
			{
				InvCatalog.InvItemName invItemName = InvCatalog.InvItemName.Conviction;
				invItemName = DishChallenge.ItemNameFromDishChallenge(character, (j == 0) ? w1 : w2);
				sprite.Draw(Game1.itemsTex, vector + new Vector2(num2 + (float)(j + 1) * 32f, 0f), Game1.invCatalog.GetInvitemRect(invItemName), new Color(1f, 1f, 1f, alpha), 0f, default, 0.125f, SpriteEffects.None, 1f);
			}
		}
	}
}
