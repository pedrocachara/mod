using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.guidestuff;
using Yuki_Win.hud;
using Yuki_Win.netplay;
using Yuki_Win.player;

namespace Yuki_Win.leaderboards;

public class LeaderBoard
{
	public enum LeaderState
	{
		Idle,
		Writing,
		WriteFailed,
		WriteComplete,
		Reading,
		ReadComplete,
		ReadFailed,
		PagingUp,
		PagingDown,
		ReadingDishChallenge,
		ReadingWeeklyRush,
		CantRead,
		ReadingFriends,
		NotRanked,
		NoFriends
	}

	public const int LEADER_SOLO_ARCADE_SCORE = 0;

	public const int LEADER_SOLO_ARCADE_TIME = 1;

	public const int LEADER_COOP_ARCADE_SCORE = 2;

	public const int LEADER_COOP_ARCADE_TIME = 3;

	public const int LEADER_DISH_CHALLENGE = 4;

	public const int LEADER_WEEKLY_RUSH = 5;

	public const int LEADER_TOURNEY_DISH = 6;

	public const int LEADER_TOURNEY_YUKI = 7;

	public const int FILTER_ALL = 2;

	public const int FILTER_ME = 1;

	public const int FILTER_FRIENDS = 0;

	private NetworkSession tempSession;

	private static Dictionary<int, string[]> leaderList;

	private float frame;

	private int leaderType;

	private int leaderLevel;

	public int filter;

	private long score1;

	private long score2;

	private long time1;

	private long time2;

	private int weapon1;

	private int weapon2;

	private int character;

	public Thread writerThread;

	private bool writingIsFucked;

	private LeaderEntry[] entries;

	private LeaderboardReader leaderboardReader;

	private LeaderboardWriter leaderboardWriter;

	private IAsyncResult result;

	public int entryCount;

	public int topRank;

	public int totalEntries;

	public int owner;

	private long dishScore;

	private long weeklyScore;

	public LeaderState state;

	private StringBuilder totalEntriesStr;

	private StringBuilder cantReadStr = new StringBuilder(YukiText.cantReadLeaderboards);

	private StringBuilder disconnectedFromXboxLive = new StringBuilder(YukiText.disconnectedFromXboxLive);

	private StringBuilder[] youMustBeSignedIn = new StringBuilder[3]
	{
		new StringBuilder(YukiText.youMustBeSignedInLive1),
		new StringBuilder(YukiText.youMustBeSignedInLive2),
		new StringBuilder(YukiText.youMustBeSignedInLive3)
	};

	private StringBuilder noFriendsStr = new StringBuilder(YukiText.noFriends);

	private StringBuilder notRankedStr = new StringBuilder(YukiText.notRanked);

	private StringBuilder noRankingsStr = new StringBuilder(YukiText.noRankings);

	private List<Gamer> friendsList;

	public void DrawBottomRightButtons(SpriteBatch sprite)
	{
		switch (state)
		{
		case LeaderState.Idle:
		case LeaderState.CantRead:
		case LeaderState.NotRanked:
		case LeaderState.NoFriends:
			switch (leaderType)
			{
			case 1:
			case 3:
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.Y, BottomRightMessage.Msg.ShowScore, 2, 1f);
				break;
			case 0:
			case 2:
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.Y, BottomRightMessage.Msg.ShowTime, 2, 1f);
				break;
			}
			switch (filter)
			{
			case 2:
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.FilterAll, 10, 1f);
				break;
			case 0:
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.FilterFriends, 10, 1f);
				break;
			case 1:
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.FilterMe, 10, 1f);
				break;
			}
			break;
		}
	}

	public LeaderBoard()
	{
		leaderList = new Dictionary<int, string[]>();
		totalEntriesStr = new StringBuilder(YukiText.totalentries + " ");
		friendsList = new List<Gamer>();
		entries = new LeaderEntry[10];
		for (int i = 0; i < entries.Length; i++)
		{
			entries[i] = new LeaderEntry();
		}
		leaderList.Add(0, new string[50]
		{
			"SoloArcadeScore_01", "SoloArcadeScore_02", "SoloArcadeScore_03", "SoloArcadeScore_04", "SoloArcadeScore_05", "SoloArcadeScore_06", "SoloArcadeScore_07", "SoloArcadeScore_08", "SoloArcadeScore_09", "SoloArcadeScore_10",
			"SoloArcadeScore_11", "SoloArcadeScore_12", "SoloArcadeScore_13", "SoloArcadeScore_14", "SoloArcadeScore_15", "SoloArcadeScore_16", "SoloArcadeScore_17", "SoloArcadeScore_18", "SoloArcadeScore_19", "SoloArcadeScore_20",
			"SoloArcadeScore_21", "SoloArcadeScore_22", "SoloArcadeScore_23", "SoloArcadeScore_24", "SoloArcadeScore_25", "SoloArcadeScore_26", "SoloArcadeScore_27", "SoloArcadeScore_28", "SoloArcadeScore_29", "SoloArcadeScore_30",
			"SoloArcadeScore_31", "SoloArcadeScore_32", "SoloArcadeScore_33", "SoloArcadeScore_34", "SoloArcadeScore_35", "SoloArcadeScore_36", "SoloArcadeScore_37", "SoloArcadeScore_38", "SoloArcadeScore_39", "SoloArcadeScore_40",
			"SoloArcadeScore_41", "SoloArcadeScore_42", "SoloArcadeScore_43", "SoloArcadeScore_44", "SoloArcadeScore_45", "SoloArcadeScore_46", "SoloArcadeScore_47", "SoloArcadeScore_48", "SoloArcadeScore_49", "SoloArcadeScore_50"
		});
		leaderList.Add(1, new string[50]
		{
			"SoloArcadeTime_01", "SoloArcadeTime_02", "SoloArcadeTime_03", "SoloArcadeTime_04", "SoloArcadeTime_05", "SoloArcadeTime_06", "SoloArcadeTime_07", "SoloArcadeTime_08", "SoloArcadeTime_09", "SoloArcadeTime_10",
			"SoloArcadeTime_11", "SoloArcadeTime_12", "SoloArcadeTime_13", "SoloArcadeTime_14", "SoloArcadeTime_15", "SoloArcadeTime_16", "SoloArcadeTime_17", "SoloArcadeTime_18", "SoloArcadeTime_19", "SoloArcadeTime_20",
			"SoloArcadeTime_21", "SoloArcadeTime_22", "SoloArcadeTime_23", "SoloArcadeTime_24", "SoloArcadeTime_25", "SoloArcadeTime_26", "SoloArcadeTime_27", "SoloArcadeTime_28", "SoloArcadeTime_29", "SoloArcadeTime_30",
			"SoloArcadeTime_31", "SoloArcadeTime_32", "SoloArcadeTime_33", "SoloArcadeTime_34", "SoloArcadeTime_35", "SoloArcadeTime_36", "SoloArcadeTime_37", "SoloArcadeTime_38", "SoloArcadeTime_39", "SoloArcadeTime_40",
			"SoloArcadeTime_41", "SoloArcadeTime_42", "SoloArcadeTime_43", "SoloArcadeTime_44", "SoloArcadeTime_45", "SoloArcadeTime_46", "SoloArcadeTime_47", "SoloArcadeTime_48", "SoloArcadeTime_49", "SoloArcadeTime_50"
		});
		leaderList.Add(2, new string[50]
		{
			"CoopArcadeScore_01", "CoopArcadeScore_02", "CoopArcadeScore_03", "CoopArcadeScore_04", "CoopArcadeScore_05", "CoopArcadeScore_06", "CoopArcadeScore_07", "CoopArcadeScore_08", "CoopArcadeScore_09", "CoopArcadeScore_10",
			"CoopArcadeScore_11", "CoopArcadeScore_12", "CoopArcadeScore_13", "CoopArcadeScore_14", "CoopArcadeScore_15", "CoopArcadeScore_16", "CoopArcadeScore_17", "CoopArcadeScore_18", "CoopArcadeScore_19", "CoopArcadeScore_20",
			"CoopArcadeScore_21", "CoopArcadeScore_22", "CoopArcadeScore_23", "CoopArcadeScore_24", "CoopArcadeScore_25", "CoopArcadeScore_26", "CoopArcadeScore_27", "CoopArcadeScore_28", "CoopArcadeScore_29", "CoopArcadeScore_30",
			"CoopArcadeScore_31", "CoopArcadeScore_32", "CoopArcadeScore_33", "CoopArcadeScore_34", "CoopArcadeScore_35", "CoopArcadeScore_36", "CoopArcadeScore_37", "CoopArcadeScore_38", "CoopArcadeScore_39", "CoopArcadeScore_40",
			"CoopArcadeScore_41", "CoopArcadeScore_42", "CoopArcadeScore_43", "CoopArcadeScore_44", "CoopArcadeScore_45", "CoopArcadeScore_46", "CoopArcadeScore_47", "CoopArcadeScore_48", "CoopArcadeScore_49", "CoopArcadeScore_50"
		});
		leaderList.Add(3, new string[50]
		{
			"CoopArcadeTime_01", "CoopArcadeTime_02", "CoopArcadeTime_03", "CoopArcadeTime_04", "CoopArcadeTime_05", "CoopArcadeTime_06", "CoopArcadeTime_07", "CoopArcadeTime_08", "CoopArcadeTime_09", "CoopArcadeTime_10",
			"CoopArcadeTime_11", "CoopArcadeTime_12", "CoopArcadeTime_13", "CoopArcadeTime_14", "CoopArcadeTime_15", "CoopArcadeTime_16", "CoopArcadeTime_17", "CoopArcadeTime_18", "CoopArcadeTime_19", "CoopArcadeTime_20",
			"CoopArcadeTime_21", "CoopArcadeTime_22", "CoopArcadeTime_23", "CoopArcadeTime_24", "CoopArcadeTime_25", "CoopArcadeTime_26", "CoopArcadeTime_27", "CoopArcadeTime_28", "CoopArcadeTime_29", "CoopArcadeTime_30",
			"CoopArcadeTime_31", "CoopArcadeTime_32", "CoopArcadeTime_33", "CoopArcadeTime_34", "CoopArcadeTime_35", "CoopArcadeTime_36", "CoopArcadeTime_37", "CoopArcadeTime_38", "CoopArcadeTime_39", "CoopArcadeTime_40",
			"CoopArcadeTime_41", "CoopArcadeTime_42", "CoopArcadeTime_43", "CoopArcadeTime_44", "CoopArcadeTime_45", "CoopArcadeTime_46", "CoopArcadeTime_47", "CoopArcadeTime_48", "CoopArcadeTime_49", "CoopArcadeTime_50"
		});
		leaderList.Add(4, new string[1] { "OverallLeaderboard" });
		leaderList.Add(5, new string[1] { "WeeklyRush" });
		leaderList.Add(6, new string[13]
		{
			"TourneyTimeDish_01", "TourneyTimeDish_02", "TourneyTimeDish_03", "TourneyTimeDish_04", "TourneyTimeDish_05", "TourneyTimeDish_06", "TourneyTimeDish_07", "TourneyTimeDish_08", "TourneyTimeDish_09", "TourneyTimeDish_10",
			"TourneyTimeDish_11", "TourneyTimeDish_12", "TourneyTimeDish_13"
		});
		leaderList.Add(7, new string[14]
		{
			"TourneyTimeYuki_01", "TourneyTimeYuki_02", "TourneyTimeYuki_03", "TourneyTimeYuki_04", "TourneyTimeYuki_05", "TourneyTimeYuki_06", "TourneyTimeYuki_07", "TourneyTimeYuki_08", "TourneyTimeYuki_09", "TourneyTimeYuki_10",
			"TourneyTimeYuki_11", "TourneyTimeYuki_12", "TourneyTimeYuki_13", "TourneyTimeYuki_14"
		});
	}

	public void RightFilter()
	{
		switch (state)
		{
		case LeaderState.Idle:
		case LeaderState.NotRanked:
		case LeaderState.NoFriends:
			filter = (filter + 1) % 3;
			Read(leaderType, leaderLevel, owner);
			break;
		}
	}

	public void LeftFilter()
	{
		switch (state)
		{
		case LeaderState.Idle:
		case LeaderState.NotRanked:
		case LeaderState.NoFriends:
			filter = (filter + 2) % 3;
			Read(leaderType, leaderLevel, owner);
			break;
		}
	}

	public bool CanPageUp()
	{
		if (leaderboardReader != null)
		{
			return leaderboardReader.CanPageUp;
		}
		return false;
	}

	public bool CanPageDown()
	{
		if (leaderboardReader != null)
		{
			return leaderboardReader.CanPageDown;
		}
		return false;
	}

	public void Update()
	{
		frame += FMan.frameTime;
		if (frame > 6.28f)
		{
			frame -= 6.28f;
		}
		switch (state)
		{
		case LeaderState.Reading:
		case LeaderState.ReadingFriends:
			if (!result.IsCompleted)
			{
				break;
			}
			try
			{
				leaderboardReader = LeaderboardReader.EndRead(result);
				totalEntries = leaderboardReader.TotalLeaderboardSize;
				if (state == LeaderState.ReadingFriends)
				{
					friendsList.Clear();
					SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[owner]);
					if (signedInGamerAtIndex != null)
					{
						foreach (LeaderboardEntry entry in leaderboardReader.Entries)
						{
							if (entry.Rating > 0)
							{
								friendsList.Add(entry.Gamer);
							}
						}
					}
					Read(leaderType, leaderLevel, owner);
				}
				else if (leaderboardReader.Entries.Count == 0)
				{
					state = LeaderState.NotRanked;
					if (filter == 0)
					{
						state = LeaderState.NoFriends;
					}
				}
				else
				{
					UpdateEntries();
					state = LeaderState.Idle;
				}
				break;
			}
			catch
			{
				state = LeaderState.CantRead;
				break;
			}
		case LeaderState.PagingUp:
			if (result.IsCompleted)
			{
				try
				{
					leaderboardReader.EndPageUp(result);
					UpdateEntries();
					state = LeaderState.Idle;
					break;
				}
				catch
				{
					state = LeaderState.CantRead;
					break;
				}
			}
			break;
		case LeaderState.PagingDown:
			if (result.IsCompleted)
			{
				try
				{
					leaderboardReader.EndPageDown(result);
					UpdateEntries();
					state = LeaderState.Idle;
					break;
				}
				catch
				{
					state = LeaderState.CantRead;
					break;
				}
			}
			break;
		case LeaderState.ReadingDishChallenge:
			if (!result.IsCompleted)
			{
				break;
			}
			try
			{
				leaderboardReader = LeaderboardReader.EndRead(result);
				if (leaderboardReader.Entries.Count <= 0)
				{
					dishScore = 0L;
				}
				else
				{
					dishScore = leaderboardReader.Entries[0].Rating;
				}
				ReadWeeklyRush();
				break;
			}
			catch (Exception)
			{
				state = LeaderState.WriteFailed;
				break;
			}
		case LeaderState.ReadingWeeklyRush:
			if (!result.IsCompleted)
			{
				break;
			}
			try
			{
				leaderboardReader = LeaderboardReader.EndRead(result);
				if (leaderboardReader.Entries.Count <= 0)
				{
					weeklyScore = 0L;
				}
				else
				{
					weeklyScore = leaderboardReader.Entries[0].Rating;
				}
				leaderType = 4;
				Write(4, 0, score1, weapon1, weapon2, character);
				break;
			}
			catch (Exception)
			{
				state = LeaderState.WriteFailed;
				break;
			}
		case LeaderState.ReadComplete:
		case LeaderState.ReadFailed:
		case LeaderState.CantRead:
			break;
		}
	}

	public void PageUp()
	{
		if (leaderboardReader.CanPageUp)
		{
			result = leaderboardReader.BeginPageUp(null, null);
			state = LeaderState.PagingUp;
		}
	}

	public void PageDown()
	{
		if (leaderboardReader.CanPageDown)
		{
			result = leaderboardReader.BeginPageDown(null, null);
			state = LeaderState.PagingDown;
		}
	}

	private void UpdateEntries()
	{
		try
		{
			for (int i = 0; i < entries.Length; i++)
			{
				entries[i].exists = false;
			}
			int num = topRank;
			topRank = -1;
			if (leaderboardReader == null)
			{
				entryCount = 0;
				return;
			}
			if (leaderboardReader.Entries.Count == 1)
			{
				SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[owner]);
				if (signedInGamerAtIndex != null && signedInGamerAtIndex.Gamertag == leaderboardReader.Entries[0].Gamer.Gamertag && leaderboardReader.Entries[0].Rating == 0)
				{
					switch (filter)
					{
					case 1:
						state = LeaderState.NotRanked;
						entryCount = 0;
						return;
					case 0:
						state = LeaderState.NoFriends;
						break;
					}
				}
			}
			for (int j = 0; j < leaderboardReader.Entries.Count; j++)
			{
				if (topRank == -1)
				{
					topRank = leaderboardReader.Entries[j].RankingEXT;
					int num2 = topRank - num;
					Game1.menuMgr.levels[31].selected -= num2;
					if (Game1.menuMgr.levels[31].selected < 0)
					{
						Game1.menuMgr.levels[31].selected = 0;
					}
					if (Game1.menuMgr.levels[31].selected > 9)
					{
						Game1.menuMgr.levels[31].selected = 9;
					}
				}
				switch (state)
				{
				default:
					if (filter == 1)
					{
						SignedInGamer signedInGamerAtIndex2 = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[owner]);
						if (signedInGamerAtIndex2 != null && signedInGamerAtIndex2.Gamertag == leaderboardReader.Entries[j].Gamer.Gamertag)
						{
							Game1.menuMgr.levels[31].selected = j;
						}
					}
					break;
				case LeaderState.PagingUp:
				case LeaderState.PagingDown:
					break;
				}
				switch (leaderType)
				{
				case 0:
				case 2:
					entries[j].Init(leaderboardReader.Entries[j].RankingEXT, leaderboardReader.Entries[j].Gamer, leaderboardReader.Entries[j].Gamer.Gamertag, leaderboardReader.Entries[j].Rating, -1L);
					break;
				case 1:
				case 3:
					entries[j].Init(leaderboardReader.Entries[j].RankingEXT, leaderboardReader.Entries[j].Gamer, leaderboardReader.Entries[j].Gamer.Gamertag, -1L, leaderboardReader.Entries[j].Rating);
					break;
				case 4:
				case 5:
					if (leaderboardReader.Entries[j].Columns.ContainsKey("Weapon1") && leaderboardReader.Entries[j].Columns.ContainsKey("Weapon2") && leaderboardReader.Entries[j].Columns.ContainsKey("Character"))
					{
						entries[j].Init(leaderboardReader.Entries[j].RankingEXT, leaderboardReader.Entries[j].Gamer, leaderboardReader.Entries[j].Gamer.Gamertag, leaderboardReader.Entries[j].Rating, -1L, (int)leaderboardReader.Entries[j].Columns["Weapon1"], (int)leaderboardReader.Entries[j].Columns["Weapon2"], (int)leaderboardReader.Entries[j].Columns["Character"]);
					}
					else
					{
						entries[j].Init(leaderboardReader.Entries[j].RankingEXT, leaderboardReader.Entries[j].Gamer, leaderboardReader.Entries[j].Gamer.Gamertag, leaderboardReader.Entries[j].Rating, -1L);
					}
					break;
				case 6:
				case 7:
					entries[j].Init(leaderboardReader.Entries[j].RankingEXT, leaderboardReader.Entries[j].Gamer, leaderboardReader.Entries[j].Gamer.Gamertag, -1L, leaderboardReader.Entries[j].Rating);
					break;
				}
			}
			entryCount = leaderboardReader.Entries.Count;
		}
		catch (Exception)
		{
			entryCount = 0;
		}
	}

	public void Write(int leaderType, int idx, long score1, long time1)
	{
		Write(leaderType, idx, score1, time1, -1L);
	}

	public void Write(int leaderType, int idx, long score1, long time1, long score2)
	{
		if (GuideStuff.GetTrial())
		{
			return;
		}
		this.leaderType = leaderType;
		leaderLevel = idx;
		this.score1 = score1;
		this.score2 = score2;
		this.time1 = time1;
		time2 = time1;
		if (writingIsFucked)
		{
			return;
		}
		if (state == LeaderState.Writing)
		{
			writerThread.Join(2500);
			if (writerThread.IsAlive)
			{
				writerThread.Abort();
				writingIsFucked = true;
			}
		}
		state = LeaderState.Writing;
		writerThread = new Thread(ThreadedWrite);
		writerThread.Start();
	}

	public void Read(int idx, int owner)
	{
		Read(leaderType, idx, owner);
	}

	public void Read(int leaderType, int idx, int owner)
	{
		try
		{
			this.leaderType = leaderType;
			leaderLevel = idx;
			this.owner = owner;
			SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[owner]);
			LeaderboardIdentity leaderboardId = LeaderboardIdentity.Create(LeaderboardKey.BestScoreLifeTime);
			leaderboardId.Key = leaderList[leaderType][idx];
			switch (filter)
			{
			case 2:
				result = LeaderboardReader.BeginRead(leaderboardId, 0, 10, null, null);
				state = LeaderState.Reading;
				break;
			case 1:
				result = LeaderboardReader.BeginRead(leaderboardId, signedInGamerAtIndex, 10, null, null);
				state = LeaderState.Reading;
				break;
			case 0:
			{
				if (state == LeaderState.ReadingFriends)
				{
					if (friendsList.Contains(signedInGamerAtIndex))
					{
						friendsList.Remove(signedInGamerAtIndex);
						result = LeaderboardReader.BeginRead(leaderboardId, friendsList, signedInGamerAtIndex, 10, null, null);
						state = LeaderState.Reading;
						break;
					}
					if (friendsList.Count > 0)
					{
						result = LeaderboardReader.BeginRead(leaderboardId, friendsList, friendsList[0], 10, null, null);
						state = LeaderState.Reading;
						break;
					}
					state = LeaderState.NotRanked;
					if (filter == 0)
					{
						state = LeaderState.NoFriends;
					}
					break;
				}
				FriendCollection friends = signedInGamerAtIndex.GetFriends();
				ICollection<Gamer> collection = new List<Gamer>();
				List<Gamer> list = new List<Gamer>();
				foreach (FriendGamer item in friends)
				{
					if (!item.FriendRequestReceivedFrom && !item.FriendRequestSentTo && signedInGamerAtIndex.Gamertag != item.Gamertag)
					{
						collection.Add(item);
						list.Add(item);
					}
				}
				result = LeaderboardReader.BeginRead(leaderboardId, list, signedInGamerAtIndex, 100, null, null);
				state = LeaderState.ReadingFriends;
				break;
			}
			}
		}
		catch
		{
			state = LeaderState.CantRead;
		}
	}

	private void ThreadedWrite()
	{
		try
		{
			switch (Game1.netSession.state)
			{
			case NetSession.State.Hosting:
			case NetSession.State.Client:
				foreach (LocalNetworkGamer localGamer in Game1.netSession.session.LocalGamers)
				{
					if (localGamer.SignedInGamer.PlayerIndex == (PlayerIndex)Game1.mainPlayer[0])
					{
						WritePlayer((!Game1.netSession.IsHost()) ? 1 : 0, Game1.netSession.session, localGamer);
					}
				}
				state = LeaderState.WriteComplete;
				break;
			case NetSession.State.None:
			{
				List<SignedInGamer> list = new List<SignedInGamer>();
				for (int i = 0; i < Game1.GetPlayers(); i++)
				{
					SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[i]);
					if (signedInGamerAtIndex.IsSignedInToLive)
					{
						list.Add(signedInGamerAtIndex);
					}
				}
				if (tempSession != null && !tempSession.IsDisposed)
				{
					tempSession.Dispose();
				}
				tempSession = NetworkSession.Create(NetworkSessionType.LocalWithLeaderboards, list, Game1.GetPlayers(), 0, new NetworkSessionProperties());
				tempSession.StartGame();
				while (tempSession.SessionState == NetworkSessionState.Lobby)
				{
					tempSession.Update();
				}
				foreach (LocalNetworkGamer localGamer2 in tempSession.LocalGamers)
				{
					for (int j = 0; j < Game1.GetPlayers(); j++)
					{
						SignedInGamer signedInGamer = localGamer2.SignedInGamer;
						if (signedInGamer == null)
						{
							state = LeaderState.WriteFailed;
						}
						else if (signedInGamer.PlayerIndex == (PlayerIndex)Game1.mainPlayer[j] && signedInGamer.IsSignedInToLive)
						{
							WritePlayer(j, tempSession, localGamer2);
						}
					}
				}
				tempSession.EndGame();
				tempSession.Update();
				tempSession.Dispose();
				state = LeaderState.WriteComplete;
				break;
			}
			}
		}
		catch (Exception)
		{
			state = LeaderState.WriteFailed;
		}
	}

	private void WritePlayer(int i, NetworkSession session, LocalNetworkGamer localNetworkGamer)
	{
		leaderboardWriter = localNetworkGamer.LeaderboardWriter;
		if (leaderboardWriter == null)
		{
			return;
		}
		LeaderboardIdentity leaderboardId = LeaderboardIdentity.Create(LeaderboardKey.BestScoreLifeTime);
		switch (leaderType)
		{
		case 0:
		{
			leaderboardId.Key = leaderList[0][leaderLevel];
			LeaderboardEntry leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
			if (i == 0)
			{
				leaderboard.Rating = score1;
			}
			else
			{
				leaderboard.Rating = score2;
			}
			leaderboardId.Key = leaderList[1][leaderLevel];
			leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
			if (i == 0)
			{
				leaderboard.Rating = time1;
			}
			else
			{
				leaderboard.Rating = time2;
			}
			break;
		}
		case 2:
		{
			leaderboardId.Key = leaderList[2][leaderLevel];
			LeaderboardEntry leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
			if (Game1.netSession.IsClient())
			{
				leaderboard.Rating = score1;
			}
			else if (i == 0)
			{
				leaderboard.Rating = score1;
			}
			else
			{
				leaderboard.Rating = score2;
			}
			leaderboardId.Key = leaderList[3][leaderLevel];
			leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
			if (Game1.netSession.IsClient())
			{
				leaderboard.Rating = time1;
			}
			else if (i == 0)
			{
				leaderboard.Rating = time1;
			}
			else
			{
				leaderboard.Rating = time2;
			}
			break;
		}
		case 4:
			if (score1 > dishScore)
			{
				leaderboardId.Key = leaderList[4][0];
				LeaderboardEntry leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
				leaderboard.Rating = score1;
				leaderboard.Columns["Weapon1"] = weapon1;
				leaderboard.Columns["Weapon2"] = weapon2;
				leaderboard.Columns["Character"] = character;
			}
			if (score1 > weeklyScore)
			{
				leaderboardId.Key = leaderList[5][0];
				LeaderboardEntry leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
				leaderboard.Rating = score1;
				leaderboard.Columns["Weapon1"] = weapon1;
				leaderboard.Columns["Weapon2"] = weapon2;
				leaderboard.Columns["Character"] = character;
			}
			break;
		case 5:
		{
			leaderboardId.Key = leaderList[5][0];
			LeaderboardEntry leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
			leaderboard.Rating = score1;
			leaderboard.Columns["Weapon1"] = weapon1;
			leaderboard.Columns["Weapon2"] = weapon2;
			leaderboard.Columns["Character"] = character;
			break;
		}
		case 6:
		{
			leaderboardId.Key = leaderList[6][leaderLevel];
			LeaderboardEntry leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
			leaderboard.Rating = time1;
			break;
		}
		case 7:
		{
			leaderboardId.Key = leaderList[7][leaderLevel];
			LeaderboardEntry leaderboard = leaderboardWriter.GetLeaderboard(leaderboardId);
			leaderboard.Rating = time1;
			break;
		}
		case 1:
		case 3:
			break;
		}
	}

	public void Draw(SpriteBatch sprite, int selected, float alpha, int threedee)
	{
		Vector2 vector = new Vector2(340f, 170f);
		Vector2 vector2 = default;
		switch (threedee)
		{
		case 0:
			vector2.X++;
			break;
		case 1:
			vector2.X--;
			break;
		}
		if (state == LeaderState.ReadingFriends || state == LeaderState.ReadingWeeklyRush || state == LeaderState.ReadingFriends || state == LeaderState.ReadingDishChallenge || state == LeaderState.Reading || state == LeaderState.PagingUp || state == LeaderState.PagingDown)
		{
			sprite.Draw(Game1.spritesTex, new Vector2(640f, 360f), new Rectangle(832, 192, 64, 64), new Color(1f, 1f, 1f, 0.5f), frame, new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
		}
		else if (state == LeaderState.Idle)
		{
			for (int i = 0; i < entries.Length; i++)
			{
				if (entries[i].exists)
				{
					entries[i].Draw(sprite, vector, i, alpha, selected == i);
				}
			}
		}
		else if (state == LeaderState.NoFriends)
		{
			Text.DrawCText(sprite, new Vector2(640f, 300f) + vector2, noFriendsStr, new Color(0f, 0f, 0f, alpha * 0.4f), 0.9f, 1, blur: true);
			Text.DrawCText(sprite, new Vector2(640f, 300f) + vector2, noFriendsStr, new Color(1f, 1f, 1f, alpha * 1f), 0.9f, 1, blur: true);
		}
		else if (state == LeaderState.NotRanked)
		{
			if (totalEntries == 0)
			{
				Text.DrawCText(sprite, new Vector2(640f, 300f) + vector2, noRankingsStr, new Color(0f, 0f, 0f, alpha * 0.4f), 0.9f, 1, blur: true);
				Text.DrawCText(sprite, new Vector2(640f, 300f) + vector2, noRankingsStr, new Color(1f, 1f, 1f, alpha * 1f), 0.9f, 1, blur: true);
			}
			else
			{
				Text.DrawCText(sprite, new Vector2(640f, 300f) + vector2, notRankedStr, new Color(0f, 0f, 0f, alpha * 0.4f), 0.9f, 1, blur: true);
				Text.DrawCText(sprite, new Vector2(640f, 300f) + vector2, notRankedStr, new Color(1f, 1f, 1f, alpha * 1f), 0.9f, 1, blur: true);
			}
		}
		else if (state == LeaderState.CantRead)
		{
			Text.DrawCText(sprite, new Vector2(640f, 300f) + vector2, cantReadStr, new Color(0f, 0f, 0f, alpha * 0.4f), 0.9f, 1, blur: true);
			Text.DrawCText(sprite, new Vector2(640f, 300f) + vector2, cantReadStr, new Color(1f, 1f, 1f, alpha * 1f), 0.9f, 1, blur: true);
			SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[owner]);
			if (signedInGamerAtIndex != null && !signedInGamerAtIndex.IsSignedInToLive)
			{
				for (int j = 0; j < 3; j++)
				{
					Text.DrawCText(sprite, new Vector2(640f, 340f + (float)j * 28f) + vector2, youMustBeSignedIn[j], new Color(0f, 0f, 0f, alpha * 0.4f), 0.9f, 1, blur: true);
					Text.DrawCText(sprite, new Vector2(640f, 340f + (float)j * 28f) + vector2, youMustBeSignedIn[j], new Color(1f, 1f, 1f, alpha * 1f), 0.9f, 1, blur: true);
				}
			}
			return;
		}
		switch (state)
		{
		case LeaderState.Idle:
		case LeaderState.NotRanked:
		case LeaderState.NoFriends:
			Text.DrawCText(sprite, vector + new Vector2(-16f, 300f) + vector2, totalEntriesStr, new Color(0f, 0f, 0f, alpha * 0.4f), 0.9f, 0, blur: true);
			Text.DrawCText(sprite, vector + new Vector2(-16f, 300f) + vector2, totalEntriesStr, new Color(1f, 1f, 1f, alpha), 0.9f, 0, blur: true);
			Text.DrawScore((int)(vector.X + 200f + vector2.X), (int)(vector.Y + 300f), totalEntries, new Color(0f, 0f, 0f, alpha * 0.4f), sprite, flip: true, 0f, dashZero: false, 0.9f, blur: true);
			Text.DrawScore((int)(vector.X + 200f + vector2.X), (int)(vector.Y + 300f), totalEntries, new Color(1f, 1f, 1f, alpha), sprite, flip: true, 0f, dashZero: false, 0.9f, blur: true);
			break;
		}
	}

	internal void ToggleYOption()
	{
		switch (leaderType)
		{
		case 0:
			Read(1, leaderLevel, owner);
			break;
		case 1:
			Read(0, leaderLevel, owner);
			break;
		case 2:
			Read(3, leaderLevel, owner);
			break;
		case 3:
			Read(2, leaderLevel, owner);
			break;
		}
	}

	internal void DrawHeader(SpriteBatch sprite, float ptA, Vector2 orig)
	{
		float num = 0f;
		switch (leaderType)
		{
		case 0:
		case 1:
		case 2:
		case 3:
			Text.DrawCText(sprite, orig + new Vector2(2f, 2f) + new Vector2(0f, -5f), Game1.levelMgr.levels[3][leaderLevel].nameStr, new Color(0f, 0f, 0f, ptA * 0.4f), 0.9f, 1);
			Text.DrawCText(sprite, orig + new Vector2(0f, -5f), Game1.levelMgr.levels[3][leaderLevel].nameStr, new Color(0.9f, 0.8f, 0.7f, ptA), 0.9f, 1);
			num = -5f;
			sprite.Draw(Game1.spritesTex, orig + new Vector2(Text.GetStringSpace(Game1.levelMgr.levels[3][leaderLevel].nameStr) * -0.5f - 20f, num), new Rectangle(384, 576, 64, 64), new Color(1f, 1f, 1f, ptA * ((leaderLevel > 0) ? 1f : 0.2f)), 0f, new Vector2(32f, 2f), 0.5f, SpriteEffects.None, 1f);
			sprite.Draw(Game1.spritesTex, orig + new Vector2(Text.GetStringSpace(Game1.levelMgr.levels[3][leaderLevel].nameStr) * 0.5f + 20f, num), new Rectangle(448, 576, 64, 64), new Color(1f, 1f, 1f, ptA * ((leaderLevel < 49) ? 1f : 0.2f)), 0f, new Vector2(32f, 2f), 0.5f, SpriteEffects.None, 1f);
			break;
		case 6:
			Text.DrawCText(sprite, orig + new Vector2(2f, 2f) + new Vector2(0f, -5f), Game1.levelMgr.levels[1][leaderLevel].nameStr, new Color(0f, 0f, 0f, ptA * 0.4f), 0.9f, 1);
			Text.DrawCText(sprite, orig + new Vector2(0f, -5f), Game1.levelMgr.levels[1][leaderLevel].nameStr, new Color(0.9f, 0.8f, 0.7f, ptA), 0.9f, 1);
			num = -5f;
			sprite.Draw(Game1.spritesTex, orig + new Vector2(Text.GetStringSpace(Game1.levelMgr.levels[1][leaderLevel].nameStr) * -0.5f - 20f, num), new Rectangle(384, 576, 64, 64), new Color(1f, 1f, 1f, ptA * ((leaderLevel > 0) ? 1f : 0.2f)), 0f, new Vector2(32f, 2f), 0.5f, SpriteEffects.None, 1f);
			sprite.Draw(Game1.spritesTex, orig + new Vector2(Text.GetStringSpace(Game1.levelMgr.levels[1][leaderLevel].nameStr) * 0.5f + 20f, num), new Rectangle(448, 576, 64, 64), new Color(1f, 1f, 1f, ptA * ((leaderLevel < 11) ? 1f : 0.2f)), 0f, new Vector2(32f, 2f), 0.5f, SpriteEffects.None, 1f);
			break;
		case 7:
			Text.DrawCText(sprite, orig + new Vector2(2f, 2f) + new Vector2(0f, -5f), Game1.levelMgr.levels[0][leaderLevel].nameStr, new Color(0f, 0f, 0f, ptA * 0.4f), 0.9f, 1);
			Text.DrawCText(sprite, orig + new Vector2(0f, -5f), Game1.levelMgr.levels[0][leaderLevel].nameStr, new Color(0.9f, 0.8f, 0.7f, ptA), 0.9f, 1);
			num = -5f;
			sprite.Draw(Game1.spritesTex, orig + new Vector2(Text.GetStringSpace(Game1.levelMgr.levels[0][leaderLevel].nameStr) * -0.5f - 20f, num), new Rectangle(384, 576, 64, 64), new Color(1f, 1f, 1f, ptA * ((leaderLevel > 0) ? 1f : 0.2f)), 0f, new Vector2(32f, 2f), 0.5f, SpriteEffects.None, 1f);
			sprite.Draw(Game1.spritesTex, orig + new Vector2(Text.GetStringSpace(Game1.levelMgr.levels[0][leaderLevel].nameStr) * 0.5f + 20f, num), new Rectangle(448, 576, 64, 64), new Color(1f, 1f, 1f, ptA * ((leaderLevel < 12) ? 1f : 0.2f)), 0f, new Vector2(32f, 2f), 0.5f, SpriteEffects.None, 1f);
			break;
		case 4:
		case 5:
			break;
		}
	}

	internal void Left()
	{
		switch (state)
		{
		case LeaderState.Idle:
		case LeaderState.NotRanked:
		case LeaderState.NoFriends:
			switch (leaderType)
			{
			case 0:
			case 1:
			case 2:
			case 3:
			case 6:
			case 7:
				if (leaderLevel > 0)
				{
					leaderLevel--;
					Read(leaderType, leaderLevel, owner);
				}
				break;
			case 4:
			case 5:
				break;
			}
			break;
		}
	}

	internal void Right()
	{
		switch (state)
		{
		case LeaderState.Idle:
		case LeaderState.NotRanked:
		case LeaderState.NoFriends:
			switch (leaderType)
			{
			case 0:
			case 1:
			case 2:
			case 3:
				if (leaderLevel < 49)
				{
					leaderLevel++;
					Read(leaderType, leaderLevel, owner);
				}
				break;
			case 6:
				if (leaderLevel < 11)
				{
					leaderLevel++;
					Read(leaderType, leaderLevel, owner);
				}
				break;
			case 7:
				if (leaderLevel < 12)
				{
					leaderLevel++;
					Read(leaderType, leaderLevel, owner);
				}
				break;
			case 4:
			case 5:
				break;
			}
			break;
		}
	}

	internal void SetType(int p)
	{
		leaderType = p;
	}

	internal void WriteDishChallenge(long score1, InvCatalog.InvItemName weapon1, InvCatalog.InvItemName weapon2, int character)
	{
		this.character = character;
		this.score1 = score1;
		leaderType = 4;
		this.weapon1 = GetWeaponIdxFromInvName(weapon1);
		this.weapon2 = GetWeaponIdxFromInvName(weapon2);
		dishScore = 0L;
		weeklyScore = 0L;
		SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[owner]);
		LeaderboardIdentity leaderboardId = LeaderboardIdentity.Create(LeaderboardKey.BestScoreLifeTime);
		leaderboardId.Key = leaderList[4][0];
		result = LeaderboardReader.BeginRead(leaderboardId, signedInGamerAtIndex, 1, null, null);
		state = LeaderState.ReadingDishChallenge;
	}

	internal void ReadWeeklyRush()
	{
		SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[owner]);
		leaderType = 5;
		LeaderboardIdentity leaderboardId = LeaderboardIdentity.Create(LeaderboardKey.BestScoreLifeTime);
		leaderboardId.Key = leaderList[5][0];
		result = LeaderboardReader.BeginRead(leaderboardId, signedInGamerAtIndex, 1, null, null);
		state = LeaderState.ReadingWeeklyRush;
	}

	internal void Write(int leaderType, int idx, long score1, int weapon1, int weapon2, int character)
	{
		state = LeaderState.Writing;
		Thread thread = new Thread(ThreadedWrite);
		thread.Start();
	}

	private int GetWeaponIdxFromInvName(InvCatalog.InvItemName weapon)
	{
		return weapon switch
		{
			InvCatalog.InvItemName.Conviction => 0, 
			InvCatalog.InvItemName.CloudSword => 1, 
			InvCatalog.InvItemName.Kamakazi => 2, 
			InvCatalog.InvItemName.Painkiller => 3, 
			InvCatalog.InvItemName.ShiftBlade => 0, 
			InvCatalog.InvItemName.MeatCleavers => 1, 
			InvCatalog.InvItemName.ViolenceHammer => 2, 
			InvCatalog.InvItemName.TheGuillotine => 3, 
			InvCatalog.InvItemName.Dekkentozter => 4, 
			_ => 0, 
		};
	}

	internal void Accept(int owner, int selected)
	{
		try
		{
			if (state != LeaderState.NoFriends && state != LeaderState.NotRanked && state != LeaderState.CantRead && selected < entryCount && !Guide.IsVisible)
			{
				Guide.ShowGamerCard((PlayerIndex)Game1.mainPlayer[owner], entries[selected].gamer);
			}
		}
		catch (Exception)
		{
		}
	}
}
