@echo off
REM Uso: build.bat "C:\caminho\da\pasta\do\jogo"
if "%~1"=="" (echo Passe a pasta do jogo entre aspas. & exit /b 1)
if not exist libs mkdir libs
xcopy /Y /Q "%~1\*.dll" libs\
if not exist libs\FNA.dll (echo ERRO: FNA.dll nao encontrada em "%~1" & exit /b 1)
if not exist libs\FNA.Steamworks.dll (echo ERRO: FNA.Steamworks.dll nao encontrada em "%~1" & exit /b 1)
if not exist libs\Steamworks.NET.dll (echo ERRO: Steamworks.NET.dll nao encontrada em "%~1" & exit /b 1)
dotnet build -c Release -o out > build_log.txt 2>&1
type build_log.txt
echo.
echo Se deu certo, o exe novo esta em out\VampireSmile.exe
