using System;

namespace Yuki_Win.chars.script;

public class ScriptCommandParser
{
	public enum Command
	{
		JoyJump = 0,
		SetAnim = 1,
		GotoFrame = 2,
		SetJump = 3,
		Slide = 4,
		Backup = 6,
		SetAnyGoto = 7,
		SetAtkGoto = 8,
		SetUpperGoto = 9,
		SetLowerGoto = 10,
		SetSawAnyGoto = 11,
		SetSawUpperGoto = 12,
		SetSawLowerGoto = 13,
		SetSecAnyGoto = 14,
		SetSecUpperGoto = 15,
		SetSecLowerGoto = 16,
		ClearGotos = 17,
		Float = 18,
		ShowGrabber = 19,
		SetGrabber = 20,
		KillMe = 21,
		Ethereal = 22,
		Solid = 23,
		SetStrongAnyGoto = 24,
		SetStrongUpperGoto = 25,
		SetStrongLowerGoto = 26,
		CheckSec = 27,
		OverSec = 28,
		SetSawSpecial = 29,
		SetGunSpecial = 30,
		Unfloat = 31,
		WallJump = 32,
		SetLandAnim = 33,
		SetFall = 34,
		DeathCheck = 35,
		IfUpGoto = 36,
		IfDownGoto = 37,
		SpeedFac = 38,
		Killfx = 39,
		Slow = 40,
		Play = 41,
		Vox = 42,
		CanCancel = 43,
		Hitfx = 44,
		Quake = 45,
		NoBlock = 46,
		AllBlock = 47,
		KillMeNow = 48,
		GetsExeGrab = 49,
		GetsAllGrab = 50,
		IfDyingGoto = 51,
		ShowAirGrabber = 52,
		IfR25Goto = 53,
		IfR50Goto = 54,
		IfR75Goto = 55,
		ZoomBump = 56,
		SetGrabGoto = 57,
		IfFallGoto = 58,
		AboutFace = 59,
		SetAirGrabber = 60,
		SetJumpGoto = 61,
		IfHealthyGoto = 62,
		SplatterTime = 63,
		DeHealthify = 64,
		CleanKilled = 65,
		RendKilled = 66,
		SmashKilled = 67,
		SlasherKilled = 68,
		BlastKilled = 69,
		GVox = 70,
		SetRunStartAnim = 71,
		Reload = 72,
		HealthSap = 73,
		IfNotDyingGoto = 74,
		KillMonsters = 75,
		GunIdle = 76,
		GunFly = 77,
		CloudCharge = 78,
		IfNoSawGoto = 79,
		Decharge = 80,
		KeyTurn = 81,
		RSetGrabber = 82,
		BreakJuggle = 83,
		JuggleStick = 84,
		WCharge = 85,
		ShoulderWarp = 86,
		RandomShoulderWarp = 87,
		JoyTurn = 88,
		LiftSmash = 89,
		LiftStop = 90,
		LiftFree = 91,
		DeInit = 92,
		SpecialStain = 93,
		CeilingSmash = 94,
		CornerHome = 95,
		KillInactives = 96,
		GroundWarp = 97,
		TargFace = 98,
		Engied = 99,
		SetGroundedGrabber = 100,
		SetAltRunStart = 101,
		IfEdgeGoto = 102,
		MoonRocks = 103,
		CryptRocks = 104,
		SetKatPhase = 105,
		GetKnife = 106,
		StabbedEnd = 107,
		RavenEnd = 108,
		JudgeRise = 109,
		YukiDies = 110,
		HypnoGrabbed = 111,
		IfDuelFailGoto = 112,
		ShowGrabberHit = 113,
		YukiDeath = 114,
		GroundCheck = 115,
		WaitIfNotAlone = 116,
		CallMeDead = 117,
		Quirk = 118,
		BossKill = 119,
		SetNAltRunStart = 120,
		IfCloseGoto = 121
	}

	public static ScriptCommandDef[] command;

	public static void Init()
	{
		command = new ScriptCommandDef[128];
		command[0] = new ScriptCommandDef("joyjump", ScriptCommandDef.ParamType.None);
		command[1] = new ScriptCommandDef("setanim", ScriptCommandDef.ParamType.String);
		command[2] = new ScriptCommandDef("gotoframe", ScriptCommandDef.ParamType.Int);
		command[3] = new ScriptCommandDef("setjump", ScriptCommandDef.ParamType.Int);
		command[4] = new ScriptCommandDef("slide", ScriptCommandDef.ParamType.Int);
		command[6] = new ScriptCommandDef("backup", ScriptCommandDef.ParamType.Int);
		command[8] = new ScriptCommandDef("setatkgoto", ScriptCommandDef.ParamType.Int);
		command[7] = new ScriptCommandDef("setanygoto", ScriptCommandDef.ParamType.Int);
		command[10] = new ScriptCommandDef("setlowergoto", ScriptCommandDef.ParamType.Int);
		command[9] = new ScriptCommandDef("setuppergoto", ScriptCommandDef.ParamType.Int);
		command[11] = new ScriptCommandDef("setsawanygoto", ScriptCommandDef.ParamType.Int);
		command[12] = new ScriptCommandDef("setsawuppergoto", ScriptCommandDef.ParamType.Int);
		command[13] = new ScriptCommandDef("setsawlowergoto", ScriptCommandDef.ParamType.Int);
		command[14] = new ScriptCommandDef("setsecanygoto", ScriptCommandDef.ParamType.Int);
		command[15] = new ScriptCommandDef("setsecuppergoto", ScriptCommandDef.ParamType.Int);
		command[16] = new ScriptCommandDef("setseclowergoto", ScriptCommandDef.ParamType.Int);
		command[17] = new ScriptCommandDef("cleargotos", ScriptCommandDef.ParamType.None);
		command[18] = new ScriptCommandDef("float", ScriptCommandDef.ParamType.None);
		command[31] = new ScriptCommandDef("unfloat", ScriptCommandDef.ParamType.None);
		command[19] = new ScriptCommandDef("showgrabber", ScriptCommandDef.ParamType.None);
		command[113] = new ScriptCommandDef("showgrabberhit", ScriptCommandDef.ParamType.None);
		command[52] = new ScriptCommandDef("showairgrabber", ScriptCommandDef.ParamType.None);
		command[20] = new ScriptCommandDef("setgrabber", ScriptCommandDef.ParamType.String);
		command[82] = new ScriptCommandDef("rsetgrabber", ScriptCommandDef.ParamType.String);
		command[60] = new ScriptCommandDef("setairgrabber", ScriptCommandDef.ParamType.String);
		command[21] = new ScriptCommandDef("killme", ScriptCommandDef.ParamType.None);
		command[48] = new ScriptCommandDef("killmenow", ScriptCommandDef.ParamType.None);
		command[22] = new ScriptCommandDef("ethereal", ScriptCommandDef.ParamType.None);
		command[23] = new ScriptCommandDef("solid", ScriptCommandDef.ParamType.None);
		command[24] = new ScriptCommandDef("setstronganygoto", ScriptCommandDef.ParamType.Int);
		command[25] = new ScriptCommandDef("setstronguppergoto", ScriptCommandDef.ParamType.Int);
		command[26] = new ScriptCommandDef("setstronglowergoto", ScriptCommandDef.ParamType.Int);
		command[27] = new ScriptCommandDef("checksec", ScriptCommandDef.ParamType.None);
		command[28] = new ScriptCommandDef("oversec", ScriptCommandDef.ParamType.None);
		command[29] = new ScriptCommandDef("setsawspecial", ScriptCommandDef.ParamType.None);
		command[30] = new ScriptCommandDef("setgunspecial", ScriptCommandDef.ParamType.None);
		command[32] = new ScriptCommandDef("walljump", ScriptCommandDef.ParamType.None);
		command[33] = new ScriptCommandDef("setlandanim", ScriptCommandDef.ParamType.String);
		command[34] = new ScriptCommandDef("setfall", ScriptCommandDef.ParamType.Int);
		command[35] = new ScriptCommandDef("deathcheck", ScriptCommandDef.ParamType.None);
		command[36] = new ScriptCommandDef("ifupgoto", ScriptCommandDef.ParamType.Int);
		command[37] = new ScriptCommandDef("ifdowngoto", ScriptCommandDef.ParamType.Int);
		command[38] = new ScriptCommandDef("speedfac", ScriptCommandDef.ParamType.Int);
		command[39] = new ScriptCommandDef("killfx", ScriptCommandDef.ParamType.None);
		command[40] = new ScriptCommandDef("slow", ScriptCommandDef.ParamType.Int);
		command[41] = new ScriptCommandDef("play", ScriptCommandDef.ParamType.String);
		command[42] = new ScriptCommandDef("vox", ScriptCommandDef.ParamType.String);
		command[43] = new ScriptCommandDef("cancancel", ScriptCommandDef.ParamType.None);
		command[44] = new ScriptCommandDef("hitfx", ScriptCommandDef.ParamType.None);
		command[45] = new ScriptCommandDef("quake", ScriptCommandDef.ParamType.Int);
		command[46] = new ScriptCommandDef("noblock", ScriptCommandDef.ParamType.None);
		command[47] = new ScriptCommandDef("allblock", ScriptCommandDef.ParamType.None);
		command[49] = new ScriptCommandDef("getsexegrab", ScriptCommandDef.ParamType.None);
		command[50] = new ScriptCommandDef("getsallgrab", ScriptCommandDef.ParamType.None);
		command[51] = new ScriptCommandDef("ifdyinggoto", ScriptCommandDef.ParamType.Int);
		command[53] = new ScriptCommandDef("ifr25goto", ScriptCommandDef.ParamType.Int);
		command[54] = new ScriptCommandDef("ifr50goto", ScriptCommandDef.ParamType.Int);
		command[55] = new ScriptCommandDef("ifr75goto", ScriptCommandDef.ParamType.Int);
		command[56] = new ScriptCommandDef("zoombump", ScriptCommandDef.ParamType.None);
		command[57] = new ScriptCommandDef("setgrabgoto", ScriptCommandDef.ParamType.Int);
		command[58] = new ScriptCommandDef("iffallgoto", ScriptCommandDef.ParamType.Int);
		command[59] = new ScriptCommandDef("aboutface", ScriptCommandDef.ParamType.None);
		command[61] = new ScriptCommandDef("setjumpgoto", ScriptCommandDef.ParamType.Int);
		command[62] = new ScriptCommandDef("ifhealthygoto", ScriptCommandDef.ParamType.Int);
		command[63] = new ScriptCommandDef("splattertime", ScriptCommandDef.ParamType.None);
		command[64] = new ScriptCommandDef("dehealthify", ScriptCommandDef.ParamType.None);
		command[65] = new ScriptCommandDef("cleankilled", ScriptCommandDef.ParamType.None);
		command[66] = new ScriptCommandDef("rendkilled", ScriptCommandDef.ParamType.None);
		command[67] = new ScriptCommandDef("smashkilled", ScriptCommandDef.ParamType.None);
		command[68] = new ScriptCommandDef("slasherkilled", ScriptCommandDef.ParamType.None);
		command[69] = new ScriptCommandDef("blastkilled", ScriptCommandDef.ParamType.None);
		command[70] = new ScriptCommandDef("gvox", ScriptCommandDef.ParamType.String);
		command[71] = new ScriptCommandDef("setrunstartanim", ScriptCommandDef.ParamType.String);
		command[72] = new ScriptCommandDef("reload", ScriptCommandDef.ParamType.None);
		command[73] = new ScriptCommandDef("healthsap", ScriptCommandDef.ParamType.Int);
		command[74] = new ScriptCommandDef("ifnotdyinggoto", ScriptCommandDef.ParamType.Int);
		command[75] = new ScriptCommandDef("killmonsters", ScriptCommandDef.ParamType.None);
		command[76] = new ScriptCommandDef("gunidle", ScriptCommandDef.ParamType.None);
		command[77] = new ScriptCommandDef("gunfly", ScriptCommandDef.ParamType.None);
		command[78] = new ScriptCommandDef("cloudcharge", ScriptCommandDef.ParamType.None);
		command[79] = new ScriptCommandDef("ifnosawgoto", ScriptCommandDef.ParamType.Int);
		command[80] = new ScriptCommandDef("decharge", ScriptCommandDef.ParamType.None);
		command[81] = new ScriptCommandDef("keyturn", ScriptCommandDef.ParamType.None);
		command[83] = new ScriptCommandDef("breakjuggle", ScriptCommandDef.ParamType.None);
		command[84] = new ScriptCommandDef("jugglestick", ScriptCommandDef.ParamType.None);
		command[85] = new ScriptCommandDef("wcharge", ScriptCommandDef.ParamType.Int);
		command[86] = new ScriptCommandDef("shoulderwarp", ScriptCommandDef.ParamType.None);
		command[87] = new ScriptCommandDef("randomshoulderwarp", ScriptCommandDef.ParamType.None);
		command[88] = new ScriptCommandDef("joyturn", ScriptCommandDef.ParamType.None);
		command[89] = new ScriptCommandDef("liftsmash", ScriptCommandDef.ParamType.None);
		command[90] = new ScriptCommandDef("liftstop", ScriptCommandDef.ParamType.None);
		command[91] = new ScriptCommandDef("liftfree", ScriptCommandDef.ParamType.None);
		command[92] = new ScriptCommandDef("deinit", ScriptCommandDef.ParamType.None);
		command[93] = new ScriptCommandDef("specialstain", ScriptCommandDef.ParamType.None);
		command[94] = new ScriptCommandDef("ceilingsmash", ScriptCommandDef.ParamType.None);
		command[95] = new ScriptCommandDef("cornerhome", ScriptCommandDef.ParamType.None);
		command[96] = new ScriptCommandDef("killinactives", ScriptCommandDef.ParamType.None);
		command[97] = new ScriptCommandDef("groundwarp", ScriptCommandDef.ParamType.None);
		command[98] = new ScriptCommandDef("targface", ScriptCommandDef.ParamType.None);
		command[99] = new ScriptCommandDef("engied", ScriptCommandDef.ParamType.None);
		command[100] = new ScriptCommandDef("setgroundedgrabber", ScriptCommandDef.ParamType.String);
		command[101] = new ScriptCommandDef("setaltrunstart", ScriptCommandDef.ParamType.None);
		command[120] = new ScriptCommandDef("setnaltrunstart", ScriptCommandDef.ParamType.None);
		command[102] = new ScriptCommandDef("ifedgegoto", ScriptCommandDef.ParamType.Int);
		command[103] = new ScriptCommandDef("moonrocks", ScriptCommandDef.ParamType.None);
		command[104] = new ScriptCommandDef("cryptrocks", ScriptCommandDef.ParamType.None);
		command[105] = new ScriptCommandDef("setkatphase", ScriptCommandDef.ParamType.None);
		command[106] = new ScriptCommandDef("getknife", ScriptCommandDef.ParamType.None);
		command[107] = new ScriptCommandDef("stabbedend", ScriptCommandDef.ParamType.None);
		command[108] = new ScriptCommandDef("ravenend", ScriptCommandDef.ParamType.None);
		command[109] = new ScriptCommandDef("judgerise", ScriptCommandDef.ParamType.None);
		command[110] = new ScriptCommandDef("yukidies", ScriptCommandDef.ParamType.None);
		command[111] = new ScriptCommandDef("hypnograbbed", ScriptCommandDef.ParamType.None);
		command[112] = new ScriptCommandDef("ifduelfailgoto", ScriptCommandDef.ParamType.Int);
		command[114] = new ScriptCommandDef("yukideath", ScriptCommandDef.ParamType.None);
		command[115] = new ScriptCommandDef("groundcheck", ScriptCommandDef.ParamType.None);
		command[116] = new ScriptCommandDef("waitifnotalone", ScriptCommandDef.ParamType.None);
		command[117] = new ScriptCommandDef("callmedead", ScriptCommandDef.ParamType.None);
		command[118] = new ScriptCommandDef("quirk", ScriptCommandDef.ParamType.Int);
		command[119] = new ScriptCommandDef("bosskill", ScriptCommandDef.ParamType.None);
		command[121] = new ScriptCommandDef("ifclosegoto", ScriptCommandDef.ParamType.Int);
	}

	public static ScriptCommand ParseString(string line)
	{
		for (int i = 0; i < command.Length; i++)
		{
			if (command[i] == null || line.Length < command[i].text.Length || !(line.Substring(0, command[i].text.Length) == command[i].text))
			{
				continue;
			}
			bool flag = false;
			if (line.Length == command[i].text.Length)
			{
				flag = true;
			}
			if (!flag && line.Length > command[i].text.Length && line[command[i].text.Length] == ' ')
			{
				flag = true;
			}
			if (!flag)
			{
				continue;
			}
			switch (command[i].paramType)
			{
			case ScriptCommandDef.ParamType.String:
				return new ScriptCommand((Command)i, -1, line.Substring(command[i].text.Length + 1));
			case ScriptCommandDef.ParamType.Int:
				try
				{
					return new ScriptCommand((Command)i, Convert.ToInt32(line.Substring(command[i].text.Length + 1)), "");
				}
				catch
				{
					return new ScriptCommand((Command)i, 0, "");
				}
			default:
				return new ScriptCommand((Command)i, -1, "");
			}
		}
		return null;
	}
}
