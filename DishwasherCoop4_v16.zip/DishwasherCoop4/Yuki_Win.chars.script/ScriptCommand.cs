using System.IO;

namespace Yuki_Win.chars.script;

public class ScriptCommand
{
	public ScriptCommandParser.Command command;

	public int iParam;

	public string sParam;

	public ScriptCommand(ScriptCommandParser.Command command, int iParam, string sParam)
	{
		this.command = command;
		this.iParam = iParam;
		this.sParam = sParam;
	}

	internal void Write(BinaryWriter b)
	{
		b.Write((int)command);
		switch (ScriptCommandParser.command[(int)command].paramType)
		{
		case ScriptCommandDef.ParamType.Int:
			b.Write(iParam);
			break;
		case ScriptCommandDef.ParamType.String:
			b.Write(sParam);
			break;
		}
	}

	public ScriptCommand(BinaryReader b)
	{
		Read(b);
	}

	internal void Read(BinaryReader b)
	{
		command = (ScriptCommandParser.Command)b.ReadInt32();
		switch (ScriptCommandParser.command[(int)command].paramType)
		{
		case ScriptCommandDef.ParamType.Int:
			iParam = b.ReadInt32();
			break;
		case ScriptCommandDef.ParamType.String:
			sParam = b.ReadString();
			break;
		}
	}
}
