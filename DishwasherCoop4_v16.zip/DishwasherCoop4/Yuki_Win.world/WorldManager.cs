using System.Collections.Generic;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using WorldEdit;
using Yuki_Win.maps;

namespace Yuki_Win.world;

public class WorldManager
{
	public static Dictionary<string, World> worldMap;

	public static string curWorld;

	public static void Init()
	{
		worldMap = new Dictionary<string, World>();
	}

	public static World GetWorld()
	{
		if (curWorld == null)
		{
			return null;
		}
		return worldMap[curWorld];
	}

	public static void LoadWorld(string name)
	{
		worldMap.Add(name, new World());
		worldMap[name].path = "world/data/" + name + ".zwx";
		worldMap[name].Read();
	}

	public static void DrawWorld(SpriteBatch sprite, string name, int x, int y, int w, int h)
	{
		for (int i = y; i < y + h; i++)
		{
			for (int j = x; j < x + w; j++)
			{
				if (worldMap[name].GetPath(j, i) != "" && worldMap[name].GetOrigX(j, i) == j && worldMap[name].GetOrigY(j, i) == i)
				{
					if (Game1.gameMap.mapMap.ContainsKey(worldMap[name].GetPath(j, i)))
					{
						Map map = Game1.gameMap.mapMap[worldMap[name].GetPath(j, i)];
						ScrollManager.scroll = new Vector2((float)j * 64f * -1f, (float)i * 64f * -1f * 1f) * 10f + new Vector2(1f, 1f) * 7500f;
						ScrollManager.zoom = 1f;
						map.UpdateLayerZoom();
						map.Draw(sprite, 2, 4, green: false, Game1.gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 0.1f);
					}
					else
					{
						Game1.gameMap.CacheMap(worldMap[name].GetPath(j, i));
					}
				}
			}
		}
	}
}
