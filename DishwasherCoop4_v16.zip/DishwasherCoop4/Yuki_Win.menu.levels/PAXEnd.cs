using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class PAXEnd : MenuLevel
{
	private const string CONTINUE = "continue";

	private StringBuilder[] paxString = new StringBuilder[3]
	{
		new StringBuilder("demo over!"),
		new StringBuilder("check back for the latest awesome"),
		new StringBuilder("at ska-studios.com and @skastudios!")
	};

	public PAXEnd()
	{
		heading = new StringBuilder("demo end");
		item = new MenuItem[1]
		{
			new MenuItem("continue", YukiText.continues)
		};
		demoEnd = true;
		sceneLoc = SceneLoc.Demons;
		mapScrollGoal = new Vector2(1676f, 607f);
		orig = new Vector2(420f, 470f);
		glowGoal = new Vector2(0.75f, 0.4f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawCText(sprite, new Vector2(640f, 200f), paxString[0], new Color(1f, 1f, 1f, alpha), 1f, 1);
		Text.DrawCText(sprite, new Vector2(640f, 300f), paxString[1], new Color(1f, 1f, 1f, alpha), 1f, 1);
		Text.DrawCText(sprite, new Vector2(640f, 330f), paxString[2], new Color(1f, 1f, 1f, alpha), 1f, 1);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "continue")
		{
			active = false;
			Game1.menuMgr.levels[55].active = true;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[55].active = true;
		base.Cancel();
	}
}
