﻿using System;
using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.debug;
using Yuki_Win.guidestuff;
using Yuki_Win.player;
using Yuki_Win.storage;
using Yuki_Win.worldmap;

namespace Yuki_Win.menu.levels;

public class MenuLevel
{
	public enum SceneLoc
	{
		Water,
		Moon,
		Guys,
		Smile,
		Demons
	}

	public enum CoopReadyState
	{
		Normal,
		Back,
		Go
	}

	public StringBuilder heading;

	public StringBuilder[] message;

	public MenuItem[] item;

	public bool active;

	public float alpha;

	public int selected;

	public Vector2 orig;

	public bool controls;

	public bool video;

	public bool selectPlayers;

	public bool leaderboard;

	public bool arcadeScores;

	public bool buy;

	public bool howToPlay;

	public bool searching;

	public bool listGames;

	public bool lobby;

	public SceneLoc sceneLoc;

	public Vector2 mapScrollGoal;

	public Vector2 glowGoal;

	public bool worldmap;

	public bool scrolling;

	public float scrollVal;

	public bool movesList;

	public bool credits;

	public bool pressStartScreen;

	private float selY;

	public bool demoEnd;

	public bool coopLev;

	private bool skippingUp;

	private bool skippingDown;

	public CoopReadyState coopReadyState;

	public bool moveLocked;

	public virtual void Update()
	{
		if (active)
		{
			if (alpha < 1f)
			{
				alpha += FMan.realTime * 1f;
				if (alpha > 1f)
				{
					alpha = 1f;
				}
			}
			for (int i = 0; i < item.Length; i++)
			{
				if (item[i].alpha < 1f)
				{
					item[i].alpha += FMan.realTime * item[i].fac;
					if (item[i].alpha > 1f)
					{
						item[i].alpha = 1f;
					}
				}
			}
			Game1.menuMgr.sceneLoc = sceneLoc;
			if (this.movesList)
			{
				if (alpha > 0.9f)
				{
					if (orig.Y - scrollVal > 330f)
					{
						scrollVal += FMan.realTime * (220f + (orig.Y - scrollVal - 330f));
					}
					if (selY + orig.Y - scrollVal < 500f)
					{
						scrollVal -= FMan.realTime * (220f + (500f - (selY + orig.Y - scrollVal)));
					}
				}
			}
			else if (scrolling)
			{
				float num = selY + orig.Y - scrollVal;
				if (Game1.menuMgr.pauseMode)
				{
					num = selY + 100f - scrollVal;
				}
				float num2 = 550f;
				float num3 = 170f;
				if (arcadeScores)
				{
					num2 = 300f;
					num3 = 200f;
				}
				if (credits)
				{
					num2 = 90f;
					if (scrollVal < 0f)
					{
						scrollVal = num2;
					}
					if (scrollVal > num2)
					{
						scrollVal = 0f;
					}
				}
				else
				{
					if (num > num2)
					{
						scrollVal += FMan.realTime * 8f * (num - num2);
					}
					if (num < num3)
					{
						scrollVal -= FMan.realTime * 8f * (num3 - num);
					}
				}
			}
			Game1.menuMgr.scrollGoalOffsetAdd += (Game1.menuMgr.scrollGoalOffset - Game1.menuMgr.scrollGoalOffsetAdd) * FMan.realTime * 0.2f;
			Vector2 vector = (mapScrollGoal - Game1.menuMgr.curScroll) * FMan.realTime * 2f;
			Game1.menuMgr.curScroll += vector;
			Game1.menuMgr.BumpInk(vector);
			Game1.menuMgr.glow += (glowGoal - Game1.menuMgr.glow) * FMan.realTime;
			if (!(alpha > 0.6f) || Game1.menuMgr.transMode != MenuManager.TransitionMode.None)
			{
				return;
			}
			if (!Game1.menuMgr.levels[22].active && GuideStuff.GetTrial())
			{
				int unlock = Game1.menuMgr.GetUnlock();
				if (unlock > -1 && unlock < 4)
				{
					GuideStuff.ShowUpsell(unlock);
				}
			}
			if (this.movesList)
			{
				if (Game1.menuMgr.GetHeldUp())
				{
					scrollVal -= FMan.realTime * 250f;
				}
				if (Game1.menuMgr.GetHeldDown())
				{
					scrollVal += FMan.realTime * 250f;
				}
				if (flibitPort.MouseScrollDelta != 0)
				{
					scrollVal += (float)flibitPort.MouseScrollDelta * -0.2f;
				}
				if (!skippingDown && Game1.menuMgr.GetSkipUp())
				{
					skippingUp = true;
					Sound.PlaySnd(Sound.Category.FX, "swing");
				}
				if (!skippingUp && Game1.menuMgr.GetSkipDown())
				{
					skippingDown = true;
					Sound.PlaySnd(Sound.Category.FX, "swing");
				}
				if (skippingDown || skippingUp)
				{
					MovesList movesList = (MovesList)this;
					if (movesList.scrollIdx == null)
					{
						skippingUp = (skippingDown = false);
					}
					else if (movesList.scrollIdx.Length < 2)
					{
						skippingUp = (skippingDown = false);
					}
					else
					{
						float num4 = scrollVal;
						if (skippingUp)
						{
							scrollVal -= FMan.realTime * 2000f;
							if (scrollVal < 0f)
							{
								skippingUp = false;
								scrollVal = 0f;
							}
							for (int j = 0; j < movesList.scrollIdx.Length; j++)
							{
								if (num4 > movesList.scrollIdx[j] && scrollVal <= movesList.scrollIdx[j])
								{
									scrollVal = movesList.scrollIdx[j];
									skippingUp = false;
									Sound.PlaySnd(Sound.Category.FX, "hit");
								}
							}
						}
						if (skippingDown)
						{
							scrollVal += FMan.realTime * 2000f;
							if (scrollVal > movesList.scrollIdx[movesList.scrollIdx.Length - 1])
							{
								skippingDown = false;
								scrollVal = movesList.scrollIdx[movesList.scrollIdx.Length - 1];
							}
							for (int k = 0; k < movesList.scrollIdx.Length; k++)
							{
								if (num4 < movesList.scrollIdx[k] && scrollVal >= movesList.scrollIdx[k])
								{
									scrollVal = movesList.scrollIdx[k];
									skippingDown = false;
									Sound.PlaySnd(Sound.Category.FX, "hit");
								}
							}
						}
					}
				}
			}
			else if (credits)
			{
				if (Game1.menuMgr.GetHeldUp())
				{
					scrollVal -= FMan.realTime * 5f;
				}
				if (Game1.menuMgr.GetHeldDown())
				{
					scrollVal += FMan.realTime * 5f;
				}
				scrollVal += FMan.realTime * 2f;
			}
			else if (!moveLocked)
			{
				if (flibitPort.MouseHoverItem > -1)
				{
					selected = flibitPort.MouseHoverItem;
				}
				if (coopReadyState != CoopReadyState.Go)
				{
					bool flag = false;
					bool flag2 = false;
					if (selected < item.Length)
					{
						if ((Game1.menuMgr.GetLeft() || flibitPort.MouseClickLeft) && selected > -1)
						{
							if (item[selected].text != null && item[selected].text.Length > 1 && item[selected].xSel > 0)
							{
								Sound.PlaySnd(Sound.Category.FX, "swing");
								item[selected].xSel = (item[selected].xSel + item[selected].text.Length - 1) % item[selected].text.Length;
							}
							if (worldmap)
							{
								flag = true;
								Sound.PlaySnd(Sound.Category.FX, "swing");
							}
						}
						if ((Game1.menuMgr.GetRight() || flibitPort.MouseClickRight) && selected > -1)
						{
							if (item[selected].text != null && item[selected].text.Length > 1 && item[selected].xSel < item[selected].text.Length - 1)
							{
								Sound.PlaySnd(Sound.Category.FX, "throw");
								item[selected].xSel = (item[selected].xSel + 1) % item[selected].text.Length;
							}
							if (worldmap)
							{
								flag2 = true;
								Sound.PlaySnd(Sound.Category.FX, "throw");
							}
						}
					}
					if (item != null)
					{
						int num5 = item.Length;
						if (worldmap && !Game1.netSession.IsClient())
						{
							for (int l = 0; l < item.Length; l++)
							{
								num5 = l + 1;
								PlayerLevelData.LevelTrack trackFromDifficulty = PlayerLevelData.GetTrackFromDifficulty(Game1.levelMgr.currentTrack, GameSettings.difficulty);
								if (l > -1 && l < Game1.storageMgr.playerData[0].levelData[(int)trackFromDifficulty].levelData.Length && Game1.storageMgr.playerData[0].levelData[(int)trackFromDifficulty].levelData[l].time <= 0f && !DebugManager.unlockAll)
								{
									break;
								}
							}
							if (GuideStuff.GetTrial())
							{
								num5 = 1;
							}
						}
						if (leaderboard)
						{
							int entryCount = Game1.leaderBoard.entryCount;
							if (Game1.menuMgr.GetUp(this) || flibitPort.MouseScrollDelta > 0)
							{
								selected--;
								if (selected < 0)
								{
									if (Game1.leaderBoard.CanPageUp())
									{
										Game1.leaderBoard.PageUp();
									}
									else
									{
										selected = 0;
									}
								}
							}
							if (Game1.menuMgr.GetDown(this) || flibitPort.MouseScrollDelta < 0)
							{
								selected++;
								if (selected >= entryCount)
								{
									if (Game1.leaderBoard.CanPageDown())
									{
										Game1.leaderBoard.PageDown();
									}
									else
									{
										selected = entryCount - 1;
									}
								}
							}
							if (Game1.menuMgr.GetYOption())
							{
								Game1.leaderBoard.ToggleYOption();
							}
							if (Game1.menuMgr.GetLS())
							{
								Game1.leaderBoard.LeftFilter();
							}
							if (Game1.menuMgr.GetRS())
							{
								Game1.leaderBoard.RightFilter();
							}
							if (Game1.menuMgr.GetLeft())
							{
								Game1.leaderBoard.Left();
							}
							if (Game1.menuMgr.GetRight())
							{
								Game1.leaderBoard.Right();
							}
							if (Game1.menuMgr.GetAccept())
							{
								Game1.leaderBoard.Accept(Game1.menuMgr.GetOwner(), selected);
							}
						}
						else
						{
							if (Game1.menuMgr.GetUp(this) || flag || flibitPort.MouseScrollDelta > 0)
							{
								selected = (selected + (num5 - 1)) % num5;
								if (item[selected].str == null && !leaderboard)
								{
									selected = (selected + (num5 - 1)) % num5;
								}
							}
							if (Game1.menuMgr.GetDown(this) || flag2 || flibitPort.MouseScrollDelta < 0)
							{
								selected = (selected + 1) % num5;
								if (item[selected].str == null && !leaderboard)
								{
									selected = (selected + 1) % num5;
								}
							}
						}
						if (num5 > 0 && selected >= num5)
						{
							selected = num5 - 1;
						}
					}
				}
			}
			if (Game1.menuMgr.GetAccept() || flibitPort.MouseClickItem)
			{
				if (selected > -1 && selected < item.Length)
				{
					if (item[selected].enabled)
					{
						Click();
					}
					else
					{
						Sound.PlaySnd(Sound.Category.FX, "thud");
					}
				}
			}
			else if (flibitPort.MouseClickItem && !flibitPort.MouseClickLeft && !flibitPort.MouseClickRight && flibitPort.MouseHoverItem < item.Length)
			{
				if (item[flibitPort.MouseHoverItem].enabled)
				{
					selected = flibitPort.MouseHoverItem;
					Click();
				}
				else
				{
					Sound.PlaySnd(Sound.Category.FX, "thud");
				}
			}
			if (Game1.menuMgr.GetCancel())
			{
				Cancel();
			}
			Game1.menuMgr.EnablePlayerOne();
			if (coopLev)
			{
				Game1.menuMgr.EnablePlayerTwo();
			}
			if (pressStartScreen)
			{
				Game1.menuMgr.EnableAll();
			}
			return;
		}
		for (int m = 0; m < item.Length; m++)
		{
			if (item[m].alpha > 0f)
			{
				item[m].alpha -= FMan.realTime * item[m].fac;
				if (item[m].alpha < 0f)
				{
					item[m].alpha = 0f;
					item[m].SetFac();
				}
			}
		}
		if (alpha > 0f)
		{
			alpha -= FMan.realTime * 0.5f;
			if (alpha < 0f)
			{
				alpha = 0f;
			}
		}
	}

	public virtual void Click()
	{
		Sound.PlaySnd(Sound.Category.FX, "sword1");
	}

	public virtual void Cancel()
	{
		Sound.PlaySnd(Sound.Category.FX, "block");
	}

	public virtual void DrawHeading(SpriteBatch sprite)
	{
	}

	public virtual void Draw(SpriteBatch sprite, int threedee)
	{
		if (!scrolling)
		{
			scrollVal = 0f;
		}
		if (alpha <= 0f)
		{
			return;
		}
		float num = 0f;
		float num2 = (alpha - 0.6f) * 2.5f;
		Vector2 vector = orig;
		if (!(MainPlayer.uberDyingFrame >= 1f) && Game1.menuMgr.pauseMode)
		{
			vector = new Vector2(ScrollManager.screenSize.X * 0.57f, 100f);
		}
		if (controls || demoEnd)
		{
			vector = new Vector2(ScrollManager.screenSize.X * 0.5f, ScrollManager.screenSize.Y * 0.69f);
		}
		switch (threedee)
		{
		case 0:
			vector.X++;
			break;
		case 1:
			vector.X--;
			break;
		}
		float num3 = num2;
		if (num2 > 0f && !controls && !demoEnd && !buy && !howToPlay && heading != null)
		{
			if (scrolling)
			{
				float num4 = vector.Y + num - scrollVal;
				float num5 = 600f;
				float num6 = 120f;
				if (arcadeScores)
				{
					num5 = 350f;
					num6 = 140f;
				}
				if (num4 < num6)
				{
					num3 *= (num4 - (num6 - 50f)) / 50f;
				}
				if (num4 > num5)
				{
					num3 *= (num5 + 50f - num4) / 50f;
				}
			}
			if (leaderboard)
			{
				Game1.leaderBoard.DrawHeader(sprite, num3, vector);
			}
			else
			{
				Text.DrawCText(sprite, vector + new Vector2(2f, 2f - scrollVal) + new Vector2(0f, -5f), heading, new Color(0f, 0f, 0f, num3 * 0.4f), 0.9f, 1, blur: true);
				Text.DrawCText(sprite, vector + new Vector2(0f, -5f - scrollVal), heading, new Color(0.9f, 0.8f, 0.7f, num3), 0.9f, 1, blur: true);
			}
		}
		num += 40f;
		if (message != null)
		{
			num += 10f;
			for (int i = 0; i < message.Length; i++)
			{
				Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f), message[i], new Color(0f, 0f, 0f, num2 * 0.4f), 0.9f, 1, blur: true);
				Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal), message[i], new Color(1f, 0.9f, 0.9f, num2 * 1f), 0.9f, 1, blur: true);
				num += 36f;
			}
			num += 10f;
		}
		if (demoEnd)
		{
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, num2));
			sprite.Draw(Game1.loadingTex, ScrollManager.screenSize / 2f, new Rectangle(0, 0, 800, 776), new Color(0.45f, 0.45f, 0.45f, num2), 0f, new Vector2(800f, 776f) / 2f, 1.4f, SpriteEffects.None, 1f);
			DrawHeading(sprite);
			return;
		}
		if (buy)
		{
			Game1.menuMgr.buy.Draw(sprite, alpha);
			return;
		}
		if (worldmap)
		{
			if (alpha > 0f && alpha <= 0.5f)
			{
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, alpha * 2f));
				Game1.worldMapMgr.scroll = new Vector2(512f, 512f);
			}
			else if (alpha > 0.5f)
			{
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, alpha * 2f));
				DrawWorldMap(sprite, num2, num3, threedee);
				return;
			}
		}
		if (controls)
		{
			DrawControls(sprite, num2);
		}
		if (howToPlay)
		{
			DrawHowToPlay(sprite, num3);
			vector.Y += 400f;
		}
		if (selectPlayers)
		{
			DrawSelectPlayers(sprite, num2);
			return;
		}
		if (leaderboard && alpha > 0f)
		{
			Game1.leaderBoard.Draw(sprite, selected, alpha, threedee);
			return;
		}
		if (credits)
		{
			Game1.credits.DrawListOnly(sprite, scrollVal, alpha);
		}
		flibitPort.ForceNoMenuString = !pressStartScreen;
		for (int j = 0; j < item.Length; j++)
		{
			if (!(num2 > 0f))
			{
				continue;
			}
			num3 = num2 * item[j].alpha;
			if (scrolling)
			{
				float num7 = vector.Y + num - scrollVal;
				float num8 = 600f;
				float num9 = 120f;
				if (arcadeScores)
				{
					num8 = 350f;
					num9 = 140f;
				}
				if (num7 < num9)
				{
					num3 *= (num7 - (num9 - 50f)) / 50f;
				}
				if (num7 > num8)
				{
					num3 *= (num8 + 50f - num7) / 50f;
				}
			}
			Color color = new Color(1f, 1f, 1f, num3);
			if (!item[j].enabled)
			{
				color = new Color(0.4f, 0.4f, 0.4f, num3);
			}
			if ((flibitPort.MouseClickItem && !flibitPort.MouseClickLeft && !flibitPort.MouseClickRight) || (!flibitPort.MouseClickItem && selected == j && !movesList && !credits))
			{
				color = new Color(1f, 0f, 0f, num3);
				if (!item[j].enabled)
				{
					color = new Color(0.4f, 0f, 0f, num3);
				}
				selY = num;
				if (!pressStartScreen && active && !movesList && !credits)
				{
					Vector2 blipVec = vector;
					blipVec += new Vector2(0f, num - scrollVal);
					switch (item[j].itemflag)
					{
					case MenuItem.ItemFlag.YukiWeapons:
					case MenuItem.ItemFlag.DishWeapons:
						blipVec.Y += 140f;
						break;
					case MenuItem.ItemFlag.SinglePortrait:
					case MenuItem.ItemFlag.CoopPortrait:
					case MenuItem.ItemFlag.CampaignPortrait:
						blipVec.Y += 320f;
						break;
					}
					float size = ((item[j].text.Length <= 1) ? Text.GetStringSpace(item[j].text[0]) : Text.GetStringSpace(item[j].text[item[j].xSel]));
					Game1.menuMgr.UpdateBlips(blipVec, size);
				}
			}
			if (movesList)
			{
				float num10 = vector.Y + num - scrollVal;
				float num11 = 1f;
				if (num10 < 100f)
				{
					num11 = (num10 - 50f) / 50f;
				}
				if (num10 > 600f)
				{
					num11 = (650f - num10) / 50f;
				}
				color = new Color(1f, 1f, 1f, num2 * num11);
				if (j == item.Length - 1)
				{
					selY = num;
				}
			}
			if (item[j].itemflag == MenuItem.ItemFlag.SinglePortrait)
			{
				for (int k = 0; k < 5; k++)
				{
					sprite.Draw(Game1.spritesTex, new Vector2(720f, 360f), new Rectangle(384 + k * 64, 320, 64, 64), new Color(1f, 1f, 1f, num2 * 0.2f), Game1.menuMgr.frame * ((k % 2 == 0) ? (-1f) : 1f) * ((float)(k / 2) + 1f), new Vector2(32f, 32f), 10f, SpriteEffects.None, 1f);
				}
				sprite.Draw(Game1.portraitsTex, new Vector2(720f, 360f), new Rectangle(item[j].xSel * 384, 0, 384, 640), new Color(1f, 1f, 1f, num2), 0f, new Vector2(192f, 320f), new Vector2(1f, 1f), SpriteEffects.None, 1f);
				num += 320f;
			}
			else if (item[j].itemflag == MenuItem.ItemFlag.YukiWeapons || item[j].itemflag == MenuItem.ItemFlag.DishWeapons)
			{
				for (int l = 0; l < 2; l++)
				{
					sprite.Draw(Game1.spritesTex, vector + new Vector2(0f, 70f + num), new Rectangle(384 + l * 64, 320, 64, 64), new Color(1f, 1f, 1f, num2 * 0.2f), Game1.menuMgr.frame * ((l % 2 == 0) ? (-1f) : 1f) * ((float)(l / 2) + 1f), new Vector2(32f, 32f), 4f, SpriteEffects.None, 1f);
				}
				sprite.Draw(Game1.itemsTex, vector + new Vector2(0f, 70f + num), Game1.invCatalog.GetInvitemRect(DishChallenge.ItemNameFromDishChallenge((item[j].itemflag != MenuItem.ItemFlag.YukiWeapons) ? 1 : 0, item[j].xSel)), new Color(1f, 1f, 1f, num2), 0f, new Vector2(64f, 64f) * 2f, 0.5f, SpriteEffects.None, 1f);
				num += 140f;
			}
			else if (item[j].itemflag == MenuItem.ItemFlag.CampaignPortrait)
			{
				for (int m = 0; m < 2; m++)
				{
					sprite.Draw(Game1.spritesTex, vector + new Vector2(0f, 140f + num), new Rectangle(384 + m * 64, 320, 64, 64), new Color(1f, 1f, 1f, num2 * 0.2f), Game1.menuMgr.frame * ((m % 2 == 0) ? (-1f) : 1f) * ((float)(m / 2) + 1f), new Vector2(32f, 32f), 6f, SpriteEffects.None, 1f);
				}
				sprite.Draw(Game1.portraitsTex, vector + new Vector2(0f, 140f + num), new Rectangle((1 - item[j].xSel) * 384, 0, 384, 640), new Color(1f, 1f, 1f, num2), 0f, new Vector2(192f, 320f), 0.57f, SpriteEffects.None, 1f);
				num += 320f;
			}
			else if (item[j].itemflag == MenuItem.ItemFlag.CoopPortrait)
			{
				for (int n = 0; n < 5; n++)
				{
					sprite.Draw(Game1.spritesTex, vector + new Vector2(0f, 130f + num), new Rectangle(384 + n * 64, 320, 64, 64), new Color(1f, 1f, 1f, num2 * 0.2f), Game1.menuMgr.frame * ((n % 2 == 0) ? (-1f) : 1f) * ((float)(n / 2) + 1f), new Vector2(32f, 32f), 6f, SpriteEffects.None, 1f);
				}
				sprite.Draw(Game1.portraitsTex, vector + new Vector2(0f, 130f + num), new Rectangle(item[j].xSel * 384, 0, 384, 640), new Color(1f, 1f, 1f, num2), 0f, new Vector2(192f, 320f), 0.6f, SpriteEffects.None, 1f);
				num += 320f;
			}
			if (item[j].str == null)
			{
				sprite.Draw(Game1.spritesTex, vector + new Vector2(0f, 7f + num - scrollVal), new Rectangle(128, 0, 128, 32), color, 0f, new Vector2(64f, 16f), 0.6f, SpriteEffects.None, 1f);
				num += 18f;
				continue;
			}
			Vector2 vector2 = default;
			vector2 += new Vector2((float)Math.Cos((float)j + Game1.menuMgr.swimFrame), (float)Math.Sin((float)j + Game1.menuMgr.swimFrame)) * new Vector2(11f, 7f);
			if (item[j].alpha < 1f)
			{
				vector2 += new Vector2((float)Math.Cos((float)j), (float)Math.Sin((float)j)) * (1f - item[j].alpha) * 20f;
			}
			if (threedee <= 0)
			{
				flibitPort.SetMouseMenuItem(j, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, Text.GetStringSpace(item[j].text[item[j].xSel]), 36f, null);
			}
			if (item[j].text.Length > 1)
			{
				if (threedee <= 0)
				{
					flibitPort.SetMouseMenuItem(j, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, Text.GetStringSpace(item[j].text[item[j].xSel]), 36f, 20f);
				}
				if (coopReadyState == CoopReadyState.Go)
				{
					Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, item[j].enabled ? item[j].text[item[j].xSel] : item[j].ltext[item[j].xSel], new Color(0f, 0f, 0f, num2 * 0.4f), 1f, 1, blur: true);
					Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + vector2, item[j].enabled ? item[j].text[item[j].xSel] : item[j].ltext[item[j].xSel], color, 1f, 1, blur: true);
				}
				else
				{
					if (j == selected)
					{
						bool flag = flibitPort.MouseHoverItem == j && flibitPort.MouseClickLeft;
						sprite.Draw(Game1.spritesTex, vector + new Vector2(0f, num - scrollVal) + new Vector2(Text.GetStringSpace(item[j].text[item[j].xSel]) * -0.5f - 20f, 0f) + vector2, new Rectangle(384, 576, 64, 64), new Color(1f, flag ? 0f : 1f, flag ? 0f : 1f, num2 * ((item[j].xSel > 0) ? 1f : 0.2f)), 0f, new Vector2(32f, 2f), 0.5f, SpriteEffects.None, 1f);
						bool flag2 = flibitPort.MouseHoverItem == j && flibitPort.MouseClickRight;
						sprite.Draw(Game1.spritesTex, vector + new Vector2(0f, num - scrollVal) + new Vector2(Text.GetStringSpace(item[j].text[item[j].xSel]) * 0.5f + 20f, 0f) + vector2, new Rectangle(448, 576, 64, 64), new Color(1f, flag2 ? 0f : 1f, flag2 ? 0f : 1f, num2 * ((item[j].xSel < item[j].text.Length - 1) ? 1f : 0.2f)), 0f, new Vector2(32f, 2f), 0.5f, SpriteEffects.None, 1f);
					}
					Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, item[j].text[item[j].xSel], new Color(0f, 0f, 0f, num2 * 0.4f), 1f, 1, blur: true);
					Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + vector2, item[j].text[item[j].xSel], color, 1f, 1, blur: true);
				}
				num += 37f;
			}
			else
			{
				if (coopReadyState == CoopReadyState.Go)
				{
					continue;
				}
				if (pressStartScreen)
				{
					vector = new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y * 0.8f);
					if (threedee <= 0)
					{
						flibitPort.SetMouseMenuItem(j, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, Text.GetStringSpace(item[j].text[item[j].xSel]), 36f, null);
					}
					Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, item[j].enabled ? item[j].text[0] : item[j].ltext[0], new Color(0f, 0f, 0f, num2 * 0.4f), 1f, 1, blur: true);
					Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + vector2, item[j].enabled ? item[j].text[0] : item[j].ltext[0], new Color(1f, 1f, 1f, num2), 1f, 1, blur: true);
					continue;
				}
				if (item[j].move)
				{
					if (num2 > 0f)
					{
						Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, item[j].enabled ? item[j].text[0] : item[j].ltext[0], new Color(0f, 0f, 0f, num2 * 0.4f), 0.75f, 1, blur: true);
						Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + vector2, item[j].enabled ? item[j].text[0] : item[j].ltext[0], color, 0.75f, 1, blur: true);
					}
					num += 30f;
					continue;
				}
				if (arcadeScores)
				{
					if (j > 0 && j < item.Length - 1)
					{
						int key = 18;
						if (Game1.netSession.IsHost() || Game1.netSession.IsClient() || Game1.arcade.players >= 2)
						{
							key = 19;
						}
						if (Game1.storageMgr.playerData[0].levelData[key].levelData[j - 1].score > 0 || DebugManager.unlockAll)
						{
							item[j].enabled = true;
						}
						else
						{
							item[j].enabled = false;
						}
					}
					if (GuideStuff.GetTrial())
					{
						if (j == 0)
						{
							item[j].enabled = true;
						}
						else
						{
							item[j].enabled = false;
						}
					}
					if (j == item.Length - 1)
					{
						item[j].enabled = true;
					}
				}
				if (listGames && j < item.Length - 2)
				{
					Text.DrawLCText(sprite, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, item[j].enabled ? item[j].text[0] : item[j].ltext[0], new Color(0f, 0f, 0f, num3 * 0.4f), 1f, 1, blur: true);
					Text.DrawLCText(sprite, vector + new Vector2(0f, num - scrollVal) + vector2, item[j].enabled ? item[j].text[0] : item[j].ltext[0], color, 1f, 1, blur: true);
				}
				else if (lobby && j < 2)
				{
					if (Game1.netSession.gamerTag[0] == null && Game1.netSession.gamerTag[1] == null)
					{
						if (j == 0)
						{
							Text.DrawLCText(sprite, vector + new Vector2(-200f, num + 16f - scrollVal) + new Vector2(2f, 2f) + vector2, Game1.menuMgr.connectingStr, new Color(0f, 0f, 0f, num3 * 0.4f), 1f, 0, blur: true);
							Text.DrawLCText(sprite, vector + new Vector2(-200f, num + 16f - scrollVal) + vector2, Game1.menuMgr.connectingStr, color, 1f, 0, blur: true);
						}
					}
					else if (Game1.netSession.gamerTag[j] == null)
					{
						Text.DrawLCText(sprite, vector + new Vector2(-200f, num - scrollVal) + new Vector2(2f, 2f) + vector2, Game1.netSession.nullString, new Color(0f, 0f, 0f, num3 * 0.4f), 1f, 0, blur: true);
						Text.DrawLCText(sprite, vector + new Vector2(-200f, num - scrollVal) + vector2, Game1.netSession.nullString, color, 1f, 0, blur: true);
					}
					else
					{
						Text.DrawLCText(sprite, vector + new Vector2(-200f, num - scrollVal) + new Vector2(2f, 2f) + vector2, Game1.netSession.gamerTag[j], new Color(0f, 0f, 0f, num3 * 0.4f), 1f, 0, blur: true);
						Text.DrawLCText(sprite, vector + new Vector2(-200f, num - scrollVal) + vector2, Game1.netSession.gamerTag[j], color, 1f, 0, blur: true);
					}
				}
				else
				{
					Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, item[j].enabled ? item[j].text[0] : item[j].ltext[0], new Color(0f, 0f, 0f, num3 * 0.4f), 1f, 1, blur: true);
					Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + vector2, item[j].enabled ? item[j].text[0] : item[j].ltext[0], color, 1f, 1, blur: true);
					if (item[j].desc != null)
					{
						num += 12f;
						for (int num12 = 0; num12 < item[j].desc.Length; num12++)
						{
							num += 25f;
							Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + new Vector2(2f, 2f) + vector2, item[j].desc[num12], new Color(0f, 0f, 0f, num3 * 0.4f), 0.75f, 1, blur: true);
							Text.DrawCText(sprite, vector + new Vector2(0f, num - scrollVal) + vector2, item[j].desc[num12], new Color(0.8f, 0.8f, 0.8f, num3), 0.75f, 1, blur: true);
						}
						num += 5f;
					}
				}
				num += 37f;
			}
		}
		flibitPort.ForceNoMenuString = false;
		if (!arcadeScores)
		{
			return;
		}
		int track = 18;
		if (Game1.netSession.IsHost() || Game1.netSession.IsClient() || Game1.arcade.players >= 2)
		{
			track = 19;
		}
		if (!Game1.netSession.IsClient())
		{
			Game1.storageMgr.playerData[0].DrawScoreCard(sprite, track, selected, new Vector2(100f, ScrollManager.screenSize.Y - 320f), alpha, threedee);
			if (!Game1.netSession.IsHost() && Game1.arcade.players >= 2)
			{
				Game1.storageMgr.playerData[1].DrawScoreCard(sprite, track, selected, new Vector2(ScrollManager.screenSize.X - 100f - 384f, ScrollManager.screenSize.Y - 320f), alpha, threedee);
			}
		}
		else
		{
			Game1.storageMgr.playerData[1].DrawScoreCard(sprite, track, selected, new Vector2(ScrollManager.screenSize.X - 100f - 384f, ScrollManager.screenSize.Y - 320f), alpha, threedee);
		}
	}

	private void DrawHowToPlay(SpriteBatch sprite, float ptA)
	{
		Text.DrawCText(sprite, orig + new Vector2(2f, 2f - scrollVal) + new Vector2(0f, -5f), heading, new Color(0f, 0f, 0f, ptA * 0.4f), 0.9f, 1, blur: true);
		Text.DrawCText(sprite, orig + new Vector2(0f, -5f - scrollVal), heading, new Color(0.9f, 0.8f, 0.7f, ptA), 0.9f, 1, blur: true);
		HowToPlay howToPlay = (HowToPlay)this;
		howToPlay.Draw(sprite, ptA);
	}

	private void DrawWorldMap(SpriteBatch sprite, float tA, float ptA, int threedee)
	{
		Game1.worldMapMgr.Draw(sprite, WorldMapMgr.WorldDrawMode.Menu, (alpha - 0.5f) * 2f, selected, threedee);
		if (item.Length <= selected || selected <= -1)
		{
			return;
		}
		sprite.Draw(Game1.spritesTex, new Vector2(ScrollManager.screenSize.X / 2f, 100f), new Rectangle(640, 384, 256, 64), new Color(0f, 0f, 0f, 0.5f), 0f, new Vector2(128f, 16f), new Vector2((Text.GetStringSpace(item[selected].enabled ? item[selected].text[0] : item[selected].ltext[0]) + 16f) / 246f, 1f), SpriteEffects.None, 1f);
		Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, -20f) + new Vector2(2f, 2f), item[selected].enabled ? item[selected].text[0] : item[selected].ltext[0], new Color(0f, 0f, 0f, tA * 0.1f), 5f, 1);
		Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 100f) + new Vector2(2f, 2f), item[selected].enabled ? item[selected].text[0] : item[selected].ltext[0], new Color(0f, 0f, 0f, tA * 0.4f), 1f, 1, blur: true);
		Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 100f), item[selected].enabled ? item[selected].text[0] : item[selected].ltext[0], new Color(1f, 1f, 1f, ptA), 1f, 1, blur: true);
		if (!Game1.netSession.IsClient())
		{
			Game1.storageMgr.playerData[0].DrawScoreCard(sprite, (int)PlayerLevelData.GetTrackFromDifficulty(Game1.levelMgr.currentTrack, GameSettings.difficulty), selected, new Vector2(100f, 400f), tA, threedee);
			if (Game1.GetPlayers() >= 2 && !Game1.netSession.IsHost())
			{
				Game1.storageMgr.playerData[1].DrawScoreCard(sprite, (int)PlayerLevelData.GetTrackFromDifficulty(Game1.levelMgr.currentTrack, GameSettings.difficulty), selected, new Vector2(ScrollManager.screenSize.X - 100f - 384f, ScrollManager.screenSize.Y - 320f), tA, threedee);
			}
		}
		else
		{
			Game1.storageMgr.playerData[1].DrawScoreCard(sprite, (int)PlayerLevelData.GetTrackFromDifficulty(Game1.levelMgr.currentTrack, GameSettings.difficulty), selected, new Vector2(ScrollManager.screenSize.X - 100f - 384f, ScrollManager.screenSize.Y - 320f), tA, threedee);
		}
	}

	private void DrawControls(SpriteBatch sprite)
	{
	}

	private void DrawControls(SpriteBatch sprite, float tA)
	{
		sprite.Draw(Game1.controllerTex, ScrollManager.screenSize / 2f + new Vector2(10f, 10f), new Rectangle(0, 0, 500, 500), new Color(0f, 0f, 0f, tA * 0.4f), 0f, new Vector2(500f, 500f) / 2f, 1.05f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.controllerTex, ScrollManager.screenSize / 2f, new Rectangle(0, 0, 500, 500), new Color(1f, 1f, 1f, tA), 0f, new Vector2(500f, 500f) / 2f, 1f, SpriteEffects.None, 1f);
		Vector2 vector = ScrollManager.screenSize / 2f + new Vector2(-250f, -250f);
		int xSel = item[0].xSel;
		Text.DrawCText(sprite, vector + new Vector2(471f, 62f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].RightTriggerString, new Color(1f, 1f, 1f, tA), 0.8f, 0);
		Text.DrawCText(sprite, vector + new Vector2(32f, 59f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].LeftTriggerString, new Color(1f, 1f, 1f, tA), 0.8f, 2);
		Text.DrawCText(sprite, vector + new Vector2(467f, 100f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].RightShoulderString, new Color(1f, 1f, 1f, tA), 0.8f, 0);
		Text.DrawCText(sprite, vector + new Vector2(30f, 100f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].LeftShoulderString, new Color(1f, 1f, 1f, tA), 0.8f, 2);
		Text.DrawCText(sprite, vector + new Vector2(472f, 176f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].StartString, new Color(1f, 1f, 1f, tA), 0.8f, 0);
		Text.DrawCText(sprite, vector + new Vector2(33f, 193f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].BackString, new Color(1f, 1f, 1f, tA), 0.8f, 2);
		Text.DrawCText(sprite, vector + new Vector2(30f, 259f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].LeftStickString, new Color(1f, 1f, 1f, tA), 0.8f, 2);
		Text.DrawCText(sprite, vector + new Vector2(469f, 206f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].XString, new Color(1f, 1f, 1f, tA), 0.8f, 0);
		Text.DrawCText(sprite, vector + new Vector2(467f, 239f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].YString, new Color(1f, 1f, 1f, tA), 0.8f, 0);
		Text.DrawCText(sprite, vector + new Vector2(467f, 263f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].BString, new Color(1f, 1f, 1f, tA), 0.8f, 0);
		Text.DrawCText(sprite, vector + new Vector2(469f, 286f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].AString, new Color(1f, 1f, 1f, tA), 0.8f, 0);
		Text.DrawCText(sprite, vector + new Vector2(469f, 316f), Game1.menuMgr.controlsStrings.controlLayouts[xSel].RightStickString, new Color(1f, 1f, 1f, tA), 0.8f, 0);
	}

	private static void SpOutline(SpriteBatch sprite, Vector2 pos, StringBuilder str, float scale, float a, Color color)
	{
		Color dark = new Color(0f, 0f, 0f, a * 0.95f);
		for (int dx = -2; dx <= 2; dx += 4)
		{
			for (int dy = -2; dy <= 2; dy += 4)
			{
				Text.DrawLCText(sprite, pos + new Vector2((float)dx, (float)dy), str, dark, scale, 1);
			}
		}
		Text.DrawLCText(sprite, pos, str, color, scale, 1);
	}

	// Tela de selecao: 4 colunas lado a lado (como a introducao do arcade); o retrato do personagem fica embaixo de cada jogador.
	private void DrawSelectPlayers(SpriteBatch sprite, float tA)
	{
		orig = new Vector2(600f, 180f);
		if (!active || !(alpha > 0f))
		{
			return;
		}
		float W = ScrollManager.screenSize.X;
		float H = ScrollManager.screenSize.Y;
		float top = 230f - scrollVal;
		float spin = (float)(System.Environment.TickCount % 100000) * 0.001f;
		for (int i = 0; i < 4; i++)
		{
			float cx = W * ((float)i + 0.5f) / 4f;
			bool joined = Game1.mainPlayer[i] > -1;
			if (joined && Game1.gamePlayerMgr.gamePlayer[i].nameStr == null)
			{
				try
				{
					SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[i]);
					if (signedInGamerAtIndex == null)
					{
						Game1.gamePlayerMgr.gamePlayer[i].nameStr = new StringBuilder("Player " + (i + 1));
					}
					else
					{
						Game1.gamePlayerMgr.gamePlayer[i].nameStr = new StringBuilder(signedInGamerAtIndex.Gamertag);
					}
				}
				catch
				{
					Game1.gamePlayerMgr.gamePlayer[i].nameStr = new StringBuilder("Player " + (i + 1));
				}
			}
			if (!joined || Game1.gamePlayerMgr.gamePlayer[i].nameStr == null)
			{
				SpOutline(sprite, new Vector2(cx, top - 10f), new StringBuilder("PLAYER " + (i + 1)), 1f, tA * 0.6f, new Color(1f, 1f, 1f, tA * 0.6f));
				SpOutline(sprite, new Vector2(cx, top + 40f), item[0].text[0], 1f, tA * 0.7f, new Color(1f, 1f, 1f, tA * 0.7f));
				continue;
			}
			int pick = Game1.slotChar[i];
			int portrait = Game1.PortraitIndex(pick);
			// icone do controle + nome
			sprite.Draw(Game1.comicText, new Vector2(cx, top - 30f) + new Vector2(2f, 2f), new Rectangle(Game1.mainPlayer[i] * 64 + 192, 448, 64, 64), new Color(0f, 0f, 0f, tA * 0.6f), 0f, new Vector2(32f, 32f), 0.8f, SpriteEffects.None, 1f);
			sprite.Draw(Game1.comicText, new Vector2(cx, top - 30f), new Rectangle(Game1.mainPlayer[i] * 64 + 192, 448, 64, 64), new Color(1f, 1f, 1f, tA), 0f, new Vector2(32f, 32f), 0.8f, SpriteEffects.None, 1f);
			SpOutline(sprite, new Vector2(cx, top + 10f), Game1.gamePlayerMgr.gamePlayer[i].nameStr, 1.2f, tA, new Color(1f, 1f, 1f, tA));
			// seletor de personagem
			SpOutline(sprite, new Vector2(cx - 125f, top + 52f), new StringBuilder("<"), 1.3f, tA, new Color(1f, 1f, 1f, tA));
			SpOutline(sprite, new Vector2(cx, top + 56f), new StringBuilder(Game1.slotCharName[pick]), 0.9f, tA, new Color(1f, 0.9f, 0.5f, tA));
			SpOutline(sprite, new Vector2(cx + 125f, top + 52f), new StringBuilder(">"), 1.3f, tA, new Color(1f, 1f, 1f, tA));
			// retrato embaixo do jogador
			float py = top + 100f;
			float ps = (H - py - 10f) / 640f;
			if (ps > 0.62f)
			{
				ps = 0.62f;
			}
			float cy = py + 640f * ps * 0.5f;
			for (int g = 0; g < 2; g++)
			{
				sprite.Draw(Game1.spritesTex, new Vector2(cx, cy), new Rectangle(384 + (i + g * 3) % 6 * 64, 320, 64, 64), new Color(1f, 1f, 1f, tA * 0.10f), spin * ((g == 0) ? (-0.5f) : 0.5f), new Vector2(32f, 32f), 5f, SpriteEffects.None, 1f);
			}
			sprite.Draw(Game1.portraitsTex, new Vector2(cx, py) + new Vector2(4f, 4f), new Rectangle(portrait * 384, 0, 384, 640), new Color(0f, 0f, 0f, tA * 0.5f), 0f, new Vector2(192f, 0f), ps, SpriteEffects.None, 1f);
			sprite.Draw(Game1.portraitsTex, new Vector2(cx, py), new Rectangle(portrait * 384, 0, 384, 640), new Color(1f, 1f, 1f, tA), 0f, new Vector2(192f, 0f), ps, SpriteEffects.None, 1f);
		}
	}
}
