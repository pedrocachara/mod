using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class DishDishChallenge : MenuLevel
{
	private const string WEAP1 = "weap1";

	private const string WEAP2 = "weap2";

	private const string GO = "go!";

	private const string BACK = "_back";

	public DishDishChallenge()
	{
		heading = new StringBuilder(YukiText.selectWeapons);
		item = new MenuItem[Game1.levelMgr.levels[3].Count + 2];
		item = new MenuItem[6]
		{
			new MenuItem("weap1", new string[5]
			{
				YukiText.shiftBlade,
				YukiText.meatCleavers,
				YukiText.violenceHammer,
				YukiText.theGuillotine,
				YukiText.dekkentozter
			}, MenuItem.ItemFlag.DishWeapons),
			new MenuItem("weap2", new string[5]
			{
				YukiText.shiftBlade,
				YukiText.meatCleavers,
				YukiText.violenceHammer,
				YukiText.theGuillotine,
				YukiText.dekkentozter
			}, MenuItem.ItemFlag.DishWeapons),
			new MenuItem("", ""),
			new MenuItem("go!", YukiText.go),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Demons;
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(640f, 100f);
		glowGoal = new Vector2(0.75f, 0.3f);
	}

	public override void Click()
	{
		if (!Game1.netSession.IsClient())
		{
			switch (item[selected].str)
			{
			case "_back":
				active = false;
				Game1.menuMgr.levels[41].active = true;
				break;
			case "go!":
			{
				for (int i = 0; i < 2; i++)
				{
					Game1.levelMgr.levels[4][0].arcadeWeapon[0, i] = DishChallenge.ItemNameFromDishChallenge(1, item[i].xSel);
				}
				GameSettings.difficulty = 2;
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.DishChallenge;
				Game1.menuMgr.transGoalLevel = selected;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
				break;
			}
			}
		}
		base.Click();
	}

	public override void Cancel()
	{
		if (!Game1.netSession.IsClient())
		{
			active = false;
			Game1.menuMgr.levels[41].active = true;
		}
		base.Cancel();
	}
}
