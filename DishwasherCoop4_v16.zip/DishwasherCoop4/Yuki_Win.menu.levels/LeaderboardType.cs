using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class LeaderboardType : MenuLevel
{
	private const string SOLO_ARCADE = "arcade (solo)";

	private const string COOP_ARCADE = "arcade (coop)";

	private const string DISH_CHALLENGE = "dish challenge";

	private const string TOURNEY = "tourney (solo)";

	private const string WEEKLY_RUSH = "weekly rush";

	private const string DISHWASHER_SPEEDRUN = "speed run (dishwasher)";

	private const string YUKI_SPEEDRUN = "speed run (yuki)";

	private const string BACK = "_back";

	public LeaderboardType()
	{
		heading = new StringBuilder(YukiText.leaderboards);
		item = new MenuItem[10]
		{
			new MenuItem("arcade (solo)", YukiText.arcadeSolo),
			new MenuItem("arcade (coop)", YukiText.arcadeCoop),
			new MenuItem("", ""),
			new MenuItem("dish challenge", YukiText.dishChallenge),
			new MenuItem("weekly rush", YukiText.weeklyRush),
			new MenuItem("", ""),
			new MenuItem("speed run (dishwasher)", YukiText.speedRunDishwasher),
			new MenuItem("speed run (yuki)", YukiText.speedRunYuki),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Moon;
		mapScrollGoal = new Vector2(675f, 772f);
		orig = new Vector2(800f, 180f);
		glowGoal = new Vector2(0.25f, 0.45f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 500f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.55f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "arcade (solo)":
			active = false;
			Game1.menuMgr.levels[30].active = true;
			Game1.leaderBoard.SetType(0);
			Game1.leaderBoard.filter = 0;
			if (Game1.menuMgr.pauseMode && Game1.levelMgr.currentTrack == 3)
			{
				Game1.menuMgr.levels[30].selected = Game1.levelMgr.currentLevel;
			}
			break;
		case "arcade (coop)":
			active = false;
			Game1.menuMgr.levels[30].active = true;
			Game1.leaderBoard.SetType(2);
			Game1.leaderBoard.filter = 0;
			if (Game1.menuMgr.pauseMode && Game1.levelMgr.currentTrack == 3)
			{
				Game1.menuMgr.levels[30].selected = Game1.levelMgr.currentLevel;
			}
			break;
		case "dish challenge":
		{
			active = false;
			MenuLeaderboard menuLeaderboard = (MenuLeaderboard)Game1.menuMgr.levels[31];
			menuLeaderboard.returnLev = 29;
			Game1.menuMgr.levels[31].active = true;
			Game1.leaderBoard.SetType(4);
			Game1.leaderBoard.filter = 0;
			Game1.leaderBoard.Read(0, 0);
			Game1.menuMgr.levels[31].heading = new StringBuilder("dish challenge");
			break;
		}
		case "weekly rush":
		{
			active = false;
			MenuLeaderboard menuLeaderboard2 = (MenuLeaderboard)Game1.menuMgr.levels[31];
			menuLeaderboard2.returnLev = 29;
			Game1.menuMgr.levels[31].active = true;
			Game1.leaderBoard.SetType(5);
			Game1.leaderBoard.filter = 0;
			Game1.leaderBoard.Read(0, 0);
			Game1.menuMgr.levels[31].heading = new StringBuilder("weekly rush");
			break;
		}
		case "speed run (dishwasher)":
			active = false;
			Game1.menuMgr.levels[48].active = true;
			Game1.leaderBoard.SetType(6);
			Game1.leaderBoard.filter = 0;
			if (Game1.menuMgr.pauseMode && Game1.levelMgr.currentTrack == 1 && GameSettings.difficulty == 5)
			{
				Game1.menuMgr.levels[48].selected = Game1.levelMgr.currentLevel;
			}
			break;
		case "speed run (yuki)":
			active = false;
			Game1.menuMgr.levels[47].active = true;
			Game1.leaderBoard.SetType(7);
			Game1.leaderBoard.filter = 0;
			if (Game1.menuMgr.pauseMode && Game1.levelMgr.currentTrack == 0 && GameSettings.difficulty == 5)
			{
				Game1.menuMgr.levels[47].selected = Game1.levelMgr.currentLevel;
			}
			break;
		case "_back":
			active = false;
			if (Game1.menuMgr.pauseMode)
			{
				if (Game1.menuMgr.remotePause)
				{
					Game1.menuMgr.levels[40].active = true;
				}
				else
				{
					Game1.menuMgr.levels[4].active = true;
				}
			}
			else
			{
				Game1.menuMgr.levels[0].active = true;
			}
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		if (Game1.menuMgr.pauseMode)
		{
			if (Game1.menuMgr.remotePause)
			{
				Game1.menuMgr.levels[40].active = true;
			}
			else
			{
				Game1.menuMgr.levels[4].active = true;
			}
		}
		else
		{
			Game1.menuMgr.levels[0].active = true;
		}
		base.Cancel();
	}
}
