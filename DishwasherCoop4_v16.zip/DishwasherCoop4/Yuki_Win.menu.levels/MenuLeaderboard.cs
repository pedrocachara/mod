using System.Text;
using Microsoft.Xna.Framework;

namespace Yuki_Win.menu.levels;

public class MenuLeaderboard : MenuLevel
{
	private const string BACK = "_back";

	public int returnLev = 29;

	public MenuLeaderboard()
	{
		heading = new StringBuilder(YukiText.totalPlayers);
		item = new MenuItem[10];
		for (int i = 0; i < item.Length; i++)
		{
			item[i] = new MenuItem("", "");
		}
		leaderboard = true;
		sceneLoc = SceneLoc.Smile;
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(640f, 100f);
		glowGoal = new Vector2(0.75f, 0.3f);
		scrolling = true;
	}

	public override void Click()
	{
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[returnLev].active = true;
		base.Cancel();
	}
}
