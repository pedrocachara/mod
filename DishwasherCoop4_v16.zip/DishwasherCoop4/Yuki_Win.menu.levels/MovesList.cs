using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.arcade;
using Yuki_Win.levels;
using Yuki_Win.menu.levels.moveslist;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class MovesList : MenuLevel
{
	private const string BACK = "_back";

	public float[] scrollIdx;

	public MovesList()
	{
		heading = new StringBuilder(YukiText.movesList);
		RefreshMovesList();
		scrolling = true;
		movesList = true;
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(600f, 200f);
		glowGoal = new Vector2(0.75f, 0.3f);
	}

	public void RefreshMovesList()
	{
		RefreshMovesList(0);
	}

	public void RefreshMovesList(int owner)
	{
		MovesListCatalog movesListCatalog = Game1.movesListCatalog;
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off)
		{
			switch (Game1.player.levelType)
			{
			case Level.LevelType.YukiLevel:
				switch (Game1.player.yukiPhase)
				{
				case 0:
					if (Game1.levelMgr.currentTrack == 5)
					{
						MakeList(new MovesListBase[1] { movesListCatalog.movesList[11] }, owner);
					}
					else
					{
						MakeList(new MovesListBase[2]
						{
							movesListCatalog.movesList[4],
							movesListCatalog.movesList[6]
						}, owner);
					}
					break;
				case 1:
					item = new MenuItem[1]
					{
						new MenuItem("", YukiText.noMovesAvailable)
					};
					break;
				case 2:
				case 3:
					MakeList(new MovesListBase[1] { movesListCatalog.movesList[11] }, owner);
					break;
				case 4:
					MakeList(new MovesListBase[1] { movesListCatalog.movesList[0] }, owner);
					break;
				case 5:
				case 6:
					MakeList(new MovesListBase[2]
					{
						movesListCatalog.movesList[0],
						movesListCatalog.movesList[1]
					}, owner);
					break;
				case 7:
				case 8:
				case 9:
					MakeList(new MovesListBase[3]
					{
						movesListCatalog.movesList[0],
						movesListCatalog.movesList[1],
						movesListCatalog.movesList[8]
					}, owner);
					break;
				case 10:
				case 11:
					MakeList(new MovesListBase[4]
					{
						movesListCatalog.movesList[0],
						movesListCatalog.movesList[1],
						movesListCatalog.movesList[8],
						movesListCatalog.movesList[2]
					}, owner);
					break;
				case 12:
				case 13:
				case 14:
				case 15:
					MakeList(new MovesListBase[5]
					{
						movesListCatalog.movesList[0],
						movesListCatalog.movesList[1],
						movesListCatalog.movesList[8],
						movesListCatalog.movesList[2],
						movesListCatalog.movesList[9]
					}, owner);
					break;
				}
				break;
			case Level.LevelType.DishLevel:
				switch (Game1.player.dishPhase)
				{
				case 0:
					MakeList(new MovesListBase[1] { movesListCatalog.movesList[4] }, owner);
					break;
				case 1:
					MakeList(new MovesListBase[2]
					{
						movesListCatalog.movesList[4],
						movesListCatalog.movesList[6]
					}, owner);
					break;
				case 2:
				case 3:
				case 4:
					MakeList(new MovesListBase[3]
					{
						movesListCatalog.movesList[4],
						movesListCatalog.movesList[6],
						movesListCatalog.movesList[5]
					}, owner);
					break;
				case 5:
				case 6:
					MakeList(new MovesListBase[4]
					{
						movesListCatalog.movesList[4],
						movesListCatalog.movesList[6],
						movesListCatalog.movesList[5],
						movesListCatalog.movesList[7]
					}, owner);
					break;
				case 7:
				case 8:
				case 9:
				case 10:
					MakeList(new MovesListBase[5]
					{
						movesListCatalog.movesList[4],
						movesListCatalog.movesList[6],
						movesListCatalog.movesList[5],
						movesListCatalog.movesList[7],
						movesListCatalog.movesList[10]
					}, owner);
					break;
				}
				break;
			}
		}
		else
		{
			MakeList(new MovesListBase[2]
			{
				movesListCatalog.movesList[MoveCatalogIdx(Game1.levelMgr.levels[Game1.levelMgr.currentTrack][Game1.levelMgr.currentLevel].arcadeWeapon[Game1.arcade.GetLevelSrc(Game1.levelMgr.levels[Game1.levelMgr.currentTrack][Game1.levelMgr.currentLevel], owner), 0])],
				movesListCatalog.movesList[MoveCatalogIdx(Game1.levelMgr.levels[Game1.levelMgr.currentTrack][Game1.levelMgr.currentLevel].arcadeWeapon[Game1.arcade.GetLevelSrc(Game1.levelMgr.levels[Game1.levelMgr.currentTrack][Game1.levelMgr.currentLevel], owner), 1])]
			}, owner);
		}
	}

	private int MoveCatalogIdx(InvCatalog.InvItemName name)
	{
		return name switch
		{
			InvCatalog.InvItemName.ShiftBlade => 4, 
			InvCatalog.InvItemName.MeatCleavers => 6, 
			InvCatalog.InvItemName.ViolenceHammer => 5, 
			InvCatalog.InvItemName.TheGuillotine => 7, 
			InvCatalog.InvItemName.Dekkentozter => 10, 
			InvCatalog.InvItemName.Conviction => 0, 
			InvCatalog.InvItemName.CloudSword => 8, 
			InvCatalog.InvItemName.Kamakazi => 2, 
			InvCatalog.InvItemName.Painkiller => 9, 
			_ => 4, 
		};
	}

	private void MakeList(MovesListBase[] list, int owner)
	{
		int num = 0;
		for (int i = 0; i < list.Length; i++)
		{
			num += list[i].GetLength();
		}
		int num2 = 0;
		item = new MenuItem[num];
		float num3 = 0f;
		scrollIdx = new float[list.Length];
		for (int j = 0; j < list.Length; j++)
		{
			float num4 = num3;
			scrollIdx[j] = num3;
			item[num2] = new MenuItem("", list[j].weapon);
			item[num2 + 1] = new MenuItem("", "");
			num3 += 92f;
			num2 += 2;
			for (int k = 0; k < list[j].move.Length; k++)
			{
				item[num2] = new MenuItem("", list[j].move[k].name, move: true);
				item[num2 + 1] = new MenuItem("", list[j].move[k].desc, move: true);
				item[num2 + 2] = new MenuItem("", " ", move: true);
				item[num2].enabled = true;
				item[num2 + 1].enabled = true;
				item[num2 + 2].enabled = true;
				num2 += 3;
				num3 += 90f;
			}
			item[num2] = new MenuItem("", " ");
			num2++;
			if (Game1.character != null)
			{
				InvCatalog.InvItemName invItemName = Game1.gamePlayerMgr.gamePlayer[owner].loadOut[Game1.character[owner].loadOut].weapon[Game1.character[owner].weapIdx];
				if (list[j].name == invItemName)
				{
					scrollVal = num4;
				}
			}
		}
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(50f, 500f) + (1f - alpha) * new Vector2(20f, 1f), heading, new Color(1f, 1f, 1f, alpha * 0.55f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 600f) + (1f - alpha) * new Vector2(-20f, -1f), heading, new Color(0f, 0f, 0f, alpha * 0.95f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		if (Game1.menuMgr.remotePause)
		{
			Game1.menuMgr.levels[40].active = true;
		}
		else
		{
			Game1.menuMgr.levels[4].active = true;
		}
		base.Cancel();
	}
}
