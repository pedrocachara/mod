using System.Text;
using Microsoft.Xna.Framework;

namespace Yuki_Win.menu.levels;

public class ListGames : MenuLevel
{
	private const string BACK = "_back";

	public ListGames()
	{
		heading = new StringBuilder(YukiText.availableGames);
		listGames = true;
		item = new MenuItem[1]
		{
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Moon;
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(500f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Moon;
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "_back")
		{
			active = false;
			Game1.menuMgr.levels[35].active = true;
		}
		else
		{
			active = false;
			Game1.menuMgr.levels[36].active = true;
			Game1.netSession.Join(Game1.netSession.availableSessions[selected]);
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[35].active = true;
		base.Cancel();
	}
}
