using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.debug;
using Yuki_Win.player;
using Yuki_Win.storage;

namespace Yuki_Win.menu.levels;

public class DebugLev : MenuLevel
{
	private const string GOD_MODE = "godmode";

	private const string SHOW_FPS = "showfps";

	private const string HIDE_CHARS = "hidechars";

	private const string SHOW_SPRITES = "showsprites";

	private const string SHOW_HITRECTS = "showhitrects";

	private const string CLICK_ACTION = "clickaction";

	private const string LEFTTRIG_ACTION = "lefttrigaction";

	private const string STEP_MODE = "stepmode";

	private const string MOUSE_ROPE = "mouserope";

	private const string THREE_DEE_MODE = "threedeemode";

	private const string PERF_MODE = "perfmode";

	private const string INSTA_KILL_MODE = "instakillmode";

	private const string NO_CLIP_WARP = "noclipwarp";

	private const string UNLOCK_ALL = "unlockall";

	private const string VIDRECORDMODE = "vidrecordmode";

	private const string HARD_UNLOCK = "hard unlock";

	private const string NETLACKEY = "netlackey";

	private const string RESET_ACHIEVES = "resetachieves";

	private const string BACK = "_back";

	public DebugLev()
	{
		heading = new StringBuilder("debug");
		item = new MenuItem[20]
		{
			new MenuItem("godmode", new string[2] { "god mode: off", "god mode: on" }),
			new MenuItem("showfps", new string[3] { "show fps: off", "show fps: on", "show fps: history" }),
			new MenuItem("hidechars", new string[2] { "show characters: on", "show characters: off" }),
			new MenuItem("showsprites", new string[3] { "show particle count: off", "show particle count: on", "show particle count: history" }),
			new MenuItem("showhitrects", new string[2] { "show hit rects: off", "show hit rects: on" }),
			new MenuItem("clickaction", new string[27]
			{
				"right click: nothing", "right click: spawn transmara", "right click: spawn midengie", "right click: spawn freak", "right click: end level", "right click: enable water", "right click: spawn fore guy", "right click: spawn puppet", "right click: quirk", "right click: spawn swordsman",
				"right click: goresplode", "right click: doguitar", "right click: spawn invalid", "right click: spawn bigengie", "right click: cycle theme", "right click: spawn box", "right click: toggle filter", "right click: do pickup", "right click: spawn chef", "right click: spawn yukinpc",
				"right click: award cheevo", "right click: spawn beatdown", "right click: spawn samurai", "right click: prison start", "right click: eight bit game", "right click: neko toasty", "right click: dustin terror"
			}),
			new MenuItem("lefttrigaction", new string[5] { "left trig: nothing", "left trig: slow time", "left trig: speed up time", "left trig: zoom", "left trig: data jam" }),
			new MenuItem("stepmode", new string[2] { "step mode: off", "step mode: on" }),
			new MenuItem("mouserope", new string[2] { "rope test: off", "rope test: on" }),
			new MenuItem("threedeemode", new string[2] { "3d mode: off", "3d mode: on" }),
			new MenuItem("perfmode", new string[2] { "show perf: off", "show perf: on" }),
			new MenuItem("instakillmode", new string[2] { "instakill: off", "instakill: on" }),
			new MenuItem("noclipwarp", new string[2] { "noclip warp: off", "noclip warp: on" }),
			new MenuItem("unlockall", new string[2] { "unlock all: off", "unlock all: on" }),
			new MenuItem("vidrecordmode", new string[2] { "vidrecordmode: off", "vidrecordmode: on" }),
			new MenuItem("hard unlock", "hard unlock"),
			new MenuItem("netlackey", new string[2] { "net lackey: off", "net lackey: on" }),
			new MenuItem("resetachieves", "reset achieves"),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		mapScrollGoal = new Vector2(665f, 972f);
		orig = new Vector2(800f, 200f);
		glowGoal = new Vector2(0.25f, 0.25f);
		scrolling = true;
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 500f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.55f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Update()
	{
		if (active && alpha > 0.5f)
		{
			DebugManager.godMode = item[0].xSel == 1;
			DebugManager.showFPS = (DebugManager.StatMode)item[1].xSel;
			DebugManager.hideChars = item[2].xSel == 1;
			DebugManager.showSprites = (DebugManager.StatMode)item[3].xSel;
			DebugManager.showHitRects = item[4].xSel == 1;
			DebugManager.clickAction = (DebugManager.ClickAction)item[5].xSel;
			DebugManager.leftTrigAction = (DebugManager.LeftTrigAction)item[6].xSel;
			DebugManager.stepMode = item[7].xSel == 1;
			DebugManager.ropeTest = item[8].xSel == 1;
			DebugManager.threeDeeMode = item[9].xSel == 1;
			DebugManager.showPerf = item[10].xSel == 1;
			DebugManager.instakill = item[11].xSel == 1;
			DebugManager.noclipwarp = item[12].xSel == 1;
			DebugManager.unlockAll = item[13].xSel == 1;
			DebugManager.videoRecordMode = item[14].xSel == 1;
			DebugManager.netLackeyMode = item[16].xSel == 1;
		}
		base.Update();
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "hard unlock":
		{
			for (int i = 0; i < Game1.storageMgr.playerData[0].levelData.Count; i++)
			{
				for (int j = 0; j < Game1.storageMgr.playerData[0].levelData[i].levelData.Length; j++)
				{
					LevelData levelData = Game1.storageMgr.playerData[0].levelData[i].levelData[j];
					levelData.damage = 1000f;
					levelData.time = 1000f;
					levelData.score = 100L;
					levelData.kills = 1;
					levelData.maxCombo = 1;
				}
			}
			Game1.gamePlayerMgr.gamePlayer[0].highestYukiPhase = 15;
			Game1.gamePlayerMgr.gamePlayer[0].highestDishPhase = 10;
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.AchievablesBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.BatBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.BellBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.BoneBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.BrainBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.CatBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.CloudBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.ContrastBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.CrossBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.CrownBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.EyeBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.FlowerBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.GoatBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.GunBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.HacksawBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.HeartBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.IceBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.MathBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.MirrorBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.MoneyBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.PigBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.PlateBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.RobotBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.RocketBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.ShieldBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.SkullBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.SpiderBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.SquidBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.ThreeDeeBead);
			Game1.hud.invMgr.inv[0].AddBead(InvCatalog.InvItemName.WineBead);
			break;
		}
		case "_back":
			active = false;
			if (Game1.menuMgr.pauseMode)
			{
				if (Game1.menuMgr.remotePause)
				{
					Game1.menuMgr.levels[40].active = true;
				}
				else
				{
					Game1.menuMgr.levels[4].active = true;
				}
			}
			else
			{
				Game1.menuMgr.levels[0].active = true;
			}
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		if (Game1.menuMgr.pauseMode)
		{
			if (Game1.menuMgr.remotePause)
			{
				Game1.menuMgr.levels[40].active = true;
			}
			else
			{
				Game1.menuMgr.levels[4].active = true;
			}
		}
		else
		{
			Game1.menuMgr.levels[0].active = true;
		}
		base.Cancel();
	}
}
