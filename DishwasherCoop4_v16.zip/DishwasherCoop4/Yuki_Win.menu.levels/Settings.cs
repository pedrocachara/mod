using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.audio;

namespace Yuki_Win.menu.levels;

public class Settings : MenuLevel
{
	private const string MONITOR = "monitor";

	private const string WINDOWMODE = "window mode";

	private const string RESOLUTION = "resolution";

	private const string VSYNC = "vsync";

	private const string SFX = "sfx";

	private const string BGM = "bgm";

	private const string VIBRATION = "vibration";

	private const string PAUSEONLOSTFOCUS = "pauseonlostfocus";

	private const string BLOOD = "blood";

	private const string BACK = "_back";

	public Settings()
	{
		heading = new StringBuilder(YukiText.settings);
		item = new MenuItem[11]
		{
			new MenuItem("monitor", flibitPort.Monitors),
			new MenuItem("resolution", flibitPort.GenDisplayList()),
			new MenuItem("window mode", new string[3]
			{
				YukiText.pc_fullscreen,
				YukiText.pc_windowed,
				YukiText.pc_borderlesswindowed
			}),
			new MenuItem("vsync", new string[2]
			{
				YukiText.pc_vsyncon,
				YukiText.pc_vsyncoff
			}),
			new MenuItem("sfx", new string[11]
			{
				YukiText.sfx0,
				YukiText.sfx10,
				YukiText.sfx20,
				YukiText.sfx30,
				YukiText.sfx40,
				YukiText.sfx50,
				YukiText.sfx60,
				YukiText.sfx70,
				YukiText.sfx80,
				YukiText.sfx90,
				YukiText.sfx100
			}),
			new MenuItem("bgm", new string[11]
			{
				YukiText.bgm0,
				YukiText.bgm10,
				YukiText.bgm20,
				YukiText.bgm30,
				YukiText.bgm40,
				YukiText.bgm50,
				YukiText.bgm60,
				YukiText.bgm70,
				YukiText.bgm80,
				YukiText.bgm90,
				YukiText.bgm100
			}),
			new MenuItem("vibration", new string[2]
			{
				YukiText.vibrationon,
				YukiText.vibrationoff
			}),
			new MenuItem("pauseonlostfocus", new string[2]
			{
				YukiText.pc_pauseonlostfocuson,
				YukiText.pc_pauseonlostfocusoff
			}),
			new MenuItem("blood", new string[2]
			{
				YukiText.bloodon,
				YukiText.bloodoff
			}),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		mapScrollGoal = new Vector2(665f, 972f);
		orig = new Vector2(650f, 200f);
		glowGoal = new Vector2(0.25f, 0.25f);
		scrolling = true;
		sceneLoc = SceneLoc.Guys;
	}

	public void Init()
	{
		item[0].xSel = flibitPort.CurrentMonitor;
		item[1] = new MenuItem("resolution", flibitPort.GenDisplayList());
		item[1].xSel = flibitPort.CurrentDisplayMode;
		item[2].xSel = flibitPort.CurrentWindowMode;
		item[3].xSel = flibitPort.CurrentVSync;
		item[4].xSel = flibitPort.CurrentSoundVolume;
		item[5].xSel = flibitPort.CurrentMusicVolume;
		item[6].xSel = flibitPort.CurrentVibration;
		item[7].xSel = flibitPort.PauseOnLostFocus;
		item[8].xSel = flibitPort.CurrentBlood;
	}

	public override void Update()
	{
		if (active && alpha > 0.5f)
		{
			if (flibitPort.CurrentMonitor != item[0].xSel)
			{
				flibitPort.CurrentMonitor = item[0].xSel;
				item[1] = new MenuItem("resolution", flibitPort.GenDisplayList());
			}
			flibitPort.CurrentSoundVolume = item[4].xSel;
			flibitPort.CurrentMusicVolume = item[5].xSel;
			flibitPort.CurrentVibration = item[6].xSel;
			flibitPort.PauseOnLostFocus = item[7].xSel;
			flibitPort.CurrentBlood = item[8].xSel;
			Sound.UpdateVolume((float)flibitPort.CurrentSoundVolume / 10f);
			Music.UpdateVolume((float)flibitPort.CurrentMusicVolume / 10f);
		}
		base.Update();
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "monitor":
		case "resolution":
		case "window mode":
		case "vsync":
			flibitPort.ApplyVideoMode(item[0].xSel, item[1].xSel, item[2].xSel, item[3].xSel);
			break;
		case "_back":
			flibitPort.ApplyVideoMode(item[0].xSel, item[1].xSel, item[2].xSel, item[3].xSel);
			active = false;
			Game1.menuMgr.levels[34].active = true;
			Game1.storageMgr.storage[Game1.menuMgr.GetOwner()].Write(0);
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[34].active = true;
		Game1.storageMgr.storage[Game1.menuMgr.GetOwner()].Write(0);
		base.Cancel();
	}
}
