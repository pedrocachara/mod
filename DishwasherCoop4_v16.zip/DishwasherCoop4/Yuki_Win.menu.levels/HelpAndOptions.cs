using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace Yuki_Win.menu.levels;

public class HelpAndOptions : MenuLevel
{
	private const string HOWTOPLAY = "how to play";

	private const string CONTROLS = "controls";

	private const string MOUSE = "mouse";

	private const string SETTINGS = "settings";

	private const string CREDITS = "credits";

	private const string BACK = "_back";

	public HelpAndOptions()
	{
		heading = new StringBuilder(YukiText.helpAndOptions);
		Init();
		mapScrollGoal = new Vector2(665f, 972f);
		orig = new Vector2(650f, 200f);
		glowGoal = new Vector2(0.25f, 0.25f);
		scrolling = true;
		sceneLoc = SceneLoc.Moon;
	}

	public void Init()
	{
		List<MenuItem> list = new List<MenuItem>();
		list.Add(new MenuItem("how to play", YukiText.howToPlay));
		list.Add(new MenuItem("settings", YukiText.settings));
		list.Add(new MenuItem("controls", YukiText.controls));
		if (flibitPort.OwnerIsKeyboard())
		{
			list.Add(new MenuItem("mouse", YukiText.pc_mousecontrols));
		}
		list.Add(new MenuItem("", ""));
		list.Add(new MenuItem("credits", YukiText.credits));
		list.Add(new MenuItem("", ""));
		list.Add(new MenuItem("_back", YukiText.back));
		item = list.ToArray();
	}

	public override void Update()
	{
		base.Update();
	}

	public override void Click()
	{
		Game1.menuMgr.GetOwner();
		switch (item[selected].str)
		{
		case "how to play":
			active = false;
			Game1.menuMgr.levels[33].active = true;
			break;
		case "controls":
			active = false;
			Game1.menuMgr.levels[25].active = true;
			((Controls)Game1.menuMgr.levels[25]).Init();
			break;
		case "mouse":
			active = false;
			Game1.menuMgr.levels[57].active = true;
			((MouseControls)Game1.menuMgr.levels[57]).Init();
			break;
		case "settings":
			active = false;
			((Settings)Game1.menuMgr.levels[50]).Init();
			Game1.menuMgr.levels[50].active = true;
			break;
		case "credits":
			active = false;
			Game1.menuMgr.levels[53].active = true;
			break;
		case "_back":
			active = false;
			if (Game1.menuMgr.pauseMode)
			{
				if (Game1.menuMgr.remotePause)
				{
					Game1.menuMgr.levels[40].active = true;
				}
				else
				{
					Game1.menuMgr.levels[4].active = true;
				}
			}
			else
			{
				Game1.menuMgr.levels[0].active = true;
			}
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		if (Game1.menuMgr.pauseMode)
		{
			if (Game1.menuMgr.remotePause)
			{
				Game1.menuMgr.levels[40].active = true;
			}
			else
			{
				Game1.menuMgr.levels[4].active = true;
			}
		}
		else
		{
			Game1.menuMgr.levels[0].active = true;
		}
		base.Cancel();
	}
}
