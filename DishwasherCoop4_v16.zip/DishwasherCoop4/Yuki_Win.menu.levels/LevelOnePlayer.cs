using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class LevelOnePlayer : MenuLevel
{
	private const string PLAYER = "the dishwasher";

	private const string BACK = "_back";

	public LevelOnePlayer()
	{
		heading = new StringBuilder(YukiText.whoContinues);
		item = new MenuItem[1]
		{
			new MenuItem("the dishwasher", new string[2]
			{
				YukiText.theprisoner,
				YukiText.theDishwasher
			}, MenuItem.ItemFlag.CampaignPortrait)
		};
		sceneLoc = SceneLoc.Smile;
		mapScrollGoal = new Vector2(2176f, 407f);
		orig = new Vector2(640f, 170f);
		glowGoal = new Vector2(0.75f, 0.4f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "the dishwasher")
		{
			switch (item[selected].xSel)
			{
			case 0:
				Game1.worldMapMgr.Read("yuki");
				Game1.levelMgr.currentTrack = 0;
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.YukiCampaign;
				Game1.menuMgr.transGoalLevel = 1;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
				break;
			case 1:
				Game1.worldMapMgr.Read("dish");
				Game1.levelMgr.currentTrack = 1;
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.DishCampaign;
				Game1.menuMgr.transGoalLevel = 0;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
				break;
			}
			active = false;
		}
		base.Click();
	}

	public override void Cancel()
	{
		base.Cancel();
	}
}
