using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class HowToPlay : MenuLevel
{
	private const string BACK = "_back";

	private StringBuilder[] howToPlayText;

	public HowToPlay()
	{
		heading = new StringBuilder(YukiText.howToPlay);
		howToPlay = true;
		item = new MenuItem[1]
		{
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Moon;
		howToPlayText = new StringBuilder[6]
		{
			new StringBuilder(YukiText.howToPlay1),
			new StringBuilder(YukiText.howToPlay2),
			new StringBuilder(YukiText.howToPlay3),
			new StringBuilder(YukiText.howToPlay4),
			new StringBuilder(YukiText.howToPlay5),
			new StringBuilder(YukiText.howToPlay6)
		};
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(640f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Guys;
	}

	public void Draw(SpriteBatch sprite, float ptA)
	{
		bool forceNoMenuString = flibitPort.ForceNoMenuString;
		flibitPort.ForceNoMenuString = true;
		DrawHTPLine(sprite, ptA, 0, new Vector2(620f, 200f), 1);
		DrawHTPLine(sprite, ptA, 1, new Vector2(660f, 250f), 1);
		DrawHTPLine(sprite, ptA, 2, new Vector2(660f, 280f), 1);
		DrawHTPLine(sprite, ptA, 3, new Vector2(400f, 330f), 0);
		DrawHTPLine(sprite, ptA, 4, new Vector2(880f, 380f), 2);
		DrawHTPLine(sprite, ptA, 5, new Vector2(400f, 430f), 0);
		flibitPort.ForceNoMenuString = forceNoMenuString;
		SpriteTools.End();
		SpriteTools.BeginAdditive();
		sprite.Draw(Game1.spritesTex, new Vector2(400f, 330f) + new Vector2(-32f, 8f), new Rectangle(640, 576, 32, 32), new Color(1f, 1f, 1f, ptA), 0f, new Vector2(16f, 16f), 1f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Vector2(400f, 330f) + new Vector2(-32f, 8f), new Rectangle(320, 0, 128, 128), new Color(1f, 0.8f, 0.4f, ptA * 0.1f), 0f, new Vector2(64f, 64f), 1f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Vector2(880f, 380f) + new Vector2(32f, 8f), new Rectangle(640 + Rand.GetRandomInt(0, 6) * 32, 608, 32, 32), new Color(1f, 0.8f, 1f, ptA), 0f, new Vector2(16f, 16f), 1f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Vector2(880f, 380f) + new Vector2(32f, 8f), new Rectangle(640 + Rand.GetRandomInt(0, 6) * 32, 608, 32, 32), new Color(1f, 0.8f, 1f, ptA), 0f, new Vector2(16f, 16f), 1.2f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Vector2(400f, 430f) + new Vector2(-16f, -8f), new Rectangle(896 + Rand.GetRandomInt(0, 4) * 32, 864, 32, 32), new Color(1f, 0.1f, 1f, ptA), 0f, new Vector2(32f, 0f), 1f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Vector2(400f, 430f) + new Vector2(-16f, -8f), new Rectangle(896 + Rand.GetRandomInt(0, 4) * 32, 832, 32, 32), new Color(1f, 1f, 0.1f, ptA), 0f, new Vector2(32f, 0f), 1f, SpriteEffects.None, 1f);
		SpriteTools.End();
		SpriteTools.BeginAlpha();
	}

	private void DrawHTPLine(SpriteBatch sprite, float ptA, int idx, Vector2 loc, int j)
	{
		Text.DrawCText(sprite, loc + new Vector2(2f, 2f - scrollVal) + new Vector2(0f, -5f), howToPlayText[idx], new Color(0f, 0f, 0f, ptA * 0.4f), 0.9f, j, blur: true);
		Text.DrawCText(sprite, loc + new Vector2(0f, -5f - scrollVal), howToPlayText[idx], new Color(1f, 1f, 1f, ptA), 0.9f, j, blur: true);
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "_back")
		{
			active = false;
			Game1.menuMgr.levels[34].active = true;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[34].active = true;
		base.Cancel();
	}
}
