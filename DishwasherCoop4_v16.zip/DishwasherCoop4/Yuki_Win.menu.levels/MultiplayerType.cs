using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.guidestuff;

namespace Yuki_Win.menu.levels;

public class MultiplayerType : MenuLevel
{
	private const string LOCAL = "local";

	private const string XBL = "xbox live";

	private const string BACK = "_back";

	public MultiplayerType()
	{
		heading = new StringBuilder(YukiText.multiplayer);
		item = new MenuItem[4]
		{
			new MenuItem("local", YukiText.local),
			new MenuItem("xbox live", YukiText.xboxLive),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(500f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Smile;
	}

	public override void Update()
	{
		if (active)
		{
			if (GuideStuff.GetTrial())
			{
				item[1].enabled = false;
			}
			else
			{
				item[1].enabled = true;
			}
		}
		base.Update();
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		mapScrollGoal = new Vector2(1157f, 931f);
		orig = new Vector2(600f, 140f);
		glowGoal = new Vector2(0.9f, 0.6f);
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 400f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "local":
			active = false;
			Game1.menuMgr.levels[28].active = true;
			Game1.mainPlayer[1] = -1;
			Game1.mainPlayer[2] = -1;
			Game1.mainPlayer[3] = -1;
			Game1.pvpMode = false;
			Game1.gamePlayerMgr.gamePlayer[1].nameStr = null;
			Game1.gamePlayerMgr.gamePlayer[0].nameStr = null;
			break;
		case "xbox live":
		{
			bool flag = false;
			SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[0]);
			if (signedInGamerAtIndex == null)
			{
				flag = true;
			}
			else if (!signedInGamerAtIndex.Privileges.AllowOnlineSessions)
			{
				flag = true;
			}
			if (flag)
			{
				Game1.menuMgr.messageMgr.AddMsg(YukiText.epicFail, new string[3]
				{
					YukiText.needToBeSignedInXBL1,
					YukiText.needToBeSignedInXBL2,
					YukiText.needToBeSignedInXBL3
				}, clear: true, weak: true);
				break;
			}
			active = false;
			Game1.menuMgr.levels[35].active = true;
			Game1.menuMgr.levels[35].item[2].enabled = false;
			SignedInGamer signedInGamerAtIndex2 = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[0]);
			if (signedInGamerAtIndex2 != null && signedInGamerAtIndex2.PartySize > 0)
			{
				Game1.menuMgr.levels[35].item[2].enabled = true;
			}
			break;
		}
		case "_back":
			active = false;
			Game1.menuMgr.levels[0].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[0].active = true;
		base.Cancel();
	}
}
