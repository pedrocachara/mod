using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.netplay;

namespace Yuki_Win.menu.levels;

public class Searching : MenuLevel
{
	private const string BACK = "_back";

	public Searching()
	{
		heading = new StringBuilder(YukiText.searching);
		searching = true;
		item = new MenuItem[1]
		{
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Moon;
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(500f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Moon;
	}

	public override void Update()
	{
		if (active)
		{
			if (Game1.netSession.state == NetSession.State.None)
			{
				active = false;
				MenuLevel menuLevel = Game1.menuMgr.levels[37];
				menuLevel.active = true;
				menuLevel.item = new MenuItem[Game1.netSession.availableSessions.Count + 2];
				menuLevel.item[menuLevel.item.Length - 1] = new MenuItem("_back", YukiText.back);
				menuLevel.item[menuLevel.item.Length - 2] = new MenuItem(null, "");
				for (int i = 0; i < Game1.netSession.availableSessions.Count; i++)
				{
					menuLevel.item[i] = new MenuItem(" ", Game1.netSession.availableSessions[i].HostGamertag);
				}
			}
			Game1.netSession.timeOut += FMan.realTime;
			if (Game1.netSession.timeOut > 20f)
			{
				Game1.netSession.Dispose();
				active = false;
				Game1.menuMgr.levels[15].active = true;
				Game1.menuMgr.messageMgr.AddMsg(YukiText.quickFindFailed, new string[2]
				{
					YukiText.returningToMultiplayer1,
					YukiText.returningToMultiplayer2
				});
			}
		}
		base.Update();
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "_back")
		{
			active = false;
			Game1.menuMgr.levels[35].active = true;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[35].active = true;
		base.Cancel();
	}
}
