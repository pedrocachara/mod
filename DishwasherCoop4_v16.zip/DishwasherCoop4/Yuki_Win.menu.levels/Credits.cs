using Microsoft.Xna.Framework;

namespace Yuki_Win.menu.levels;

public class Credits : MenuLevel
{
	private const string BACK = "_back";

	public Credits()
	{
		item = new MenuItem[0];
		scrolling = true;
		credits = true;
		sceneLoc = SceneLoc.Demons;
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(600f, 200f);
		glowGoal = new Vector2(0.75f, 0.3f);
	}

	public override void Click()
	{
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[34].active = true;
		base.Cancel();
	}
}
