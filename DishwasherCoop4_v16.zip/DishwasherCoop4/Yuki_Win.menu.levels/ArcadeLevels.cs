using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.levels;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class ArcadeLevels : MenuLevel
{
	private const string BACK = "_back";

	public ArcadeLevels()
	{
		heading = new StringBuilder(YukiText.selectLevel);
		arcadeScores = true;
		item = new MenuItem[Game1.levelMgr.levels[3].Count + 2];
		int num = 0;
		foreach (Level item in Game1.levelMgr.levels[3])
		{
			base.item[num] = new MenuItem(item.name, item.name);
			num++;
		}
		base.item[base.item.Length - 2] = new MenuItem("", "");
		base.item[base.item.Length - 1] = new MenuItem("_back", YukiText.back);
		sceneLoc = SceneLoc.Smile;
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(640f, 200f);
		glowGoal = new Vector2(0.75f, 0.3f);
		scrolling = true;
	}

	public override void Update()
	{
		if (active)
		{
			if (Game1.arcade.players >= 2)
			{
				if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
				{
					coopLev = false;
				}
				else
				{
					coopLev = true;
				}
			}
			else
			{
				coopLev = false;
			}
		}
		base.Update();
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(50f, 500f) + (1f - alpha) * new Vector2(20f, 1f), heading, new Color(1f, 1f, 1f, alpha * 0.55f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 600f) + (1f - alpha) * new Vector2(-20f, -1f), heading, new Color(0f, 0f, 0f, alpha * 0.95f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		if (!Game1.netSession.IsClient())
		{
			string str;
			if ((str = item[selected].str) != null && str == "_back")
			{
				active = false;
				if (Game1.arcade.players == 1)
				{
					Game1.menuMgr.levels[2].active = true;
				}
				else
				{
					Game1.menuMgr.levels[12].active = true;
				}
			}
			else
			{
				GameSettings.difficulty = 2;
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Arcade;
				Game1.menuMgr.transGoalLevel = selected;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
				if (Game1.netSession.IsHost())
				{
					Game1.netSession.netGame.StartArcadeGame(Game1.netSession.session, selected);
				}
			}
		}
		base.Click();
	}

	public override void Cancel()
	{
		if (!Game1.netSession.IsClient())
		{
			active = false;
			if (Game1.arcade.players == 1)
			{
				Game1.menuMgr.levels[2].active = true;
			}
			else
			{
				Game1.menuMgr.levels[12].active = true;
			}
		}
		else
		{
			Game1.menuMgr.NetGameQuitYouSure(MenuManager.LevelTitle.ArcadeLevels);
		}
		base.Cancel();
	}
}
