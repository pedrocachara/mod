using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Yuki_Win.audio;

namespace Yuki_Win.menu.levels;

public class Controls : MenuLevel
{
	private const string JUMPACCEPT = "Jump/Accept";

	private const string GRABCANCEL = "Grab/Cancel";

	private const string ATTACK = "Attack";

	private const string STRONGSAW = "Strong/Saw";

	private const string SWITCHWEAPONS = "Switch Weapons";

	private const string SWITCHLOADOUTS = "Switch Loadouts";

	private const string GUN = "Gun";

	private const string MAGIC = "Magic";

	private const string INVENTORY = "Inventory";

	private const string PAUSECONFIRM = "Pause/Confirm";

	private const string WARPROLL = "Warp/Roll";

	private const string MOVEUP = "Move Up";

	private const string MOVEDOWN = "Move Down";

	private const string MOVELEFT = "Move Left";

	private const string MOVERIGHT = "Move Right";

	private const string SWAPGUNROLL = "Swap Gun/Dodge";

	private const string RESET = "Reset to Defaults";

	private const string BACK = "_back";

	private int bindingActive;

	private PlayerIndex activePlayer;

	private bool keyboardBind;

	private GamePadState prevGPState;

	private KeyboardState prevKBState;

	private bool justBound;

	public Controls()
	{
		heading = new StringBuilder(YukiText.controls);
		bindingActive = -1;
		justBound = false;
		Init();
		flibitPort.InControlsMenu = false;
	}

	public void Init()
	{
		List<MenuItem> list = new List<MenuItem>();
		list.Add(new MenuItem("Jump/Accept", YukiText.jumpAccept + ": [A]"));
		list.Add(new MenuItem("Grab/Cancel", YukiText.grabCancel + ": [B]"));
		list.Add(new MenuItem("Attack", YukiText.attack + ": [X]"));
		list.Add(new MenuItem("Strong/Saw", YukiText.strongSaw + ": [Y]"));
		list.Add(new MenuItem("Switch Weapons", YukiText.switchWeapons + ": [r]"));
		list.Add(new MenuItem("Switch Loadouts", YukiText.switchLoadouts + ": [l]"));
		list.Add(new MenuItem("Gun", ((!flibitPort.OwnerIsKeyboard() && flibitPort.CurrentSwapGunRoll == 1) ? YukiText.warpRoll : YukiText.gun) + ": [R]"));
		list.Add(new MenuItem("Magic", YukiText.magic + ": [L]"));
		list.Add(new MenuItem("Inventory", YukiText.inventory + ": [f]"));
		list.Add(new MenuItem("Pause/Confirm", YukiText.pc_pauseconfirm + ": [g]"));
		if (flibitPort.OwnerIsKeyboard())
		{
			list.Add(new MenuItem("Warp/Roll", YukiText.warpRoll + ": " + flibitPort.GetButtonString(flibitPort.InputAction.WarpRoll)));
			list.Add(new MenuItem("Move Up", YukiText.pc_moveup + ": " + flibitPort.GetButtonString(flibitPort.InputAction.Move_UP)));
			list.Add(new MenuItem("Move Down", YukiText.pc_movedown + ": " + flibitPort.GetButtonString(flibitPort.InputAction.Move_DOWN)));
			list.Add(new MenuItem("Move Left", YukiText.pc_moveleft + ": " + flibitPort.GetButtonString(flibitPort.InputAction.Move_LEFT)));
			list.Add(new MenuItem("Move Right", YukiText.pc_moveright + ": " + flibitPort.GetButtonString(flibitPort.InputAction.Move_RIGHT)));
		}
		else
		{
			MenuItem menuItem = new MenuItem("Swap Gun/Dodge", new string[2]
			{
				YukiText.pc_swapgunrolloff,
				YukiText.pc_swapgunrollon
			});
			menuItem.xSel = flibitPort.CurrentSwapGunRoll;
			list.Add(menuItem);
		}
		list.Add(new MenuItem("Reset to Defaults", YukiText.pc_resettodefaults));
		list.Add(new MenuItem("_back", YukiText.back));
		item = list.ToArray();
		sceneLoc = SceneLoc.Guys;
		mapScrollGoal = new Vector2(665f, 972f);
		orig = new Vector2(800f, 200f);
		glowGoal = new Vector2(0.25f, 0.25f);
		scrolling = true;
		flibitPort.InControlsMenu = true;
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Update()
	{
		if (justBound)
		{
			justBound = false;
			moveLocked = false;
		}
		if (bindingActive >= 0)
		{
			if (keyboardBind)
			{
				KeyboardState state = Keyboard.GetState();
				Keys? keys = null;
				Keys[] pressedKeys = prevKBState.GetPressedKeys();
				Keys[] pressedKeys2 = state.GetPressedKeys();
				if (pressedKeys2.Length > pressedKeys.Length)
				{
					keys = pressedKeys2[pressedKeys2.Length - 1];
				}
				if (keys.HasValue)
				{
					int num = flibitPort.BindKey((flibitPort.InputAction)bindingActive, keys.Value);
					string str = item[bindingActive].str;
					item[bindingActive] = new MenuItem(str, str + ": " + flibitPort.GetButtonString((flibitPort.InputAction)bindingActive));
					if (num >= 0)
					{
						str = item[num].str;
						item[num] = new MenuItem(str, str + ": " + flibitPort.GetButtonString((flibitPort.InputAction)num));
					}
					Sound.PlaySnd(Sound.Category.FX, "sword1");
					bindingActive = -1;
					justBound = true;
				}
				else
				{
					prevKBState = state;
				}
			}
			else
			{
				GamePadState state2 = GamePad.GetState(activePlayer);
				Buttons? buttons = null;
				if (state2.IsButtonDown(Buttons.A) && prevGPState.IsButtonUp(Buttons.A))
				{
					buttons = Buttons.A;
				}
				else if (state2.IsButtonDown(Buttons.B) && prevGPState.IsButtonUp(Buttons.B))
				{
					buttons = Buttons.B;
				}
				else if (state2.IsButtonDown(Buttons.X) && prevGPState.IsButtonUp(Buttons.X))
				{
					buttons = Buttons.X;
				}
				else if (state2.IsButtonDown(Buttons.Y) && prevGPState.IsButtonUp(Buttons.Y))
				{
					buttons = Buttons.Y;
				}
				else if (state2.IsButtonDown(Buttons.LeftShoulder) && prevGPState.IsButtonUp(Buttons.LeftShoulder))
				{
					buttons = Buttons.LeftShoulder;
				}
				else if (state2.IsButtonDown(Buttons.RightShoulder) && prevGPState.IsButtonUp(Buttons.RightShoulder))
				{
					buttons = Buttons.RightShoulder;
				}
				else if (state2.IsButtonDown(Buttons.LeftTrigger) && prevGPState.IsButtonUp(Buttons.LeftTrigger))
				{
					buttons = Buttons.LeftTrigger;
				}
				else if (state2.IsButtonDown(Buttons.RightTrigger) && prevGPState.IsButtonUp(Buttons.RightTrigger))
				{
					buttons = Buttons.RightTrigger;
				}
				else if (state2.IsButtonDown(Buttons.Back) && prevGPState.IsButtonUp(Buttons.Back))
				{
					buttons = Buttons.Back;
				}
				else if (state2.IsButtonDown(Buttons.Start) && prevGPState.IsButtonUp(Buttons.Start))
				{
					buttons = Buttons.Start;
				}
				else if (state2.IsButtonDown(Buttons.DPadUp) && prevGPState.IsButtonUp(Buttons.DPadUp))
				{
					buttons = Buttons.DPadUp;
				}
				else if (state2.IsButtonDown(Buttons.DPadDown) && prevGPState.IsButtonUp(Buttons.DPadDown))
				{
					buttons = Buttons.DPadDown;
				}
				else if (state2.IsButtonDown(Buttons.DPadLeft) && prevGPState.IsButtonUp(Buttons.DPadLeft))
				{
					buttons = Buttons.DPadLeft;
				}
				else if (state2.IsButtonDown(Buttons.DPadRight) && prevGPState.IsButtonUp(Buttons.DPadRight))
				{
					buttons = Buttons.DPadRight;
				}
				else if (state2.IsButtonDown(Buttons.LeftStick) && prevGPState.IsButtonUp(Buttons.LeftStick))
				{
					buttons = Buttons.LeftStick;
				}
				else if (state2.IsButtonDown(Buttons.RightStick) && prevGPState.IsButtonUp(Buttons.RightStick))
				{
					buttons = Buttons.RightStick;
				}
				if (buttons.HasValue)
				{
					int num2 = flibitPort.BindButton((flibitPort.InputAction)bindingActive, buttons.Value);
					string str2 = item[bindingActive].str;
					item[bindingActive] = new MenuItem(str2, str2 + ": " + flibitPort.GetButtonString((flibitPort.InputAction)bindingActive));
					if (num2 >= 0)
					{
						str2 = item[num2].str;
						item[num2] = new MenuItem(str2, str2 + ": " + flibitPort.GetButtonString((flibitPort.InputAction)num2));
					}
					Sound.PlaySnd(Sound.Category.FX, "sword1");
					bindingActive = -1;
					justBound = true;
				}
				else
				{
					prevGPState = state2;
				}
			}
		}
		else if (!flibitPort.OwnerIsKeyboard() && item[10].xSel != flibitPort.CurrentSwapGunRoll)
		{
			flibitPort.CurrentSwapGunRoll = item[10].xSel;
			item[6] = new MenuItem("Gun", ((flibitPort.CurrentSwapGunRoll == 1) ? YukiText.warpRoll : YukiText.gun) + ": [R]");
		}
		base.Update();
	}

	public override void Click()
	{
		if (moveLocked || justBound)
		{
			return;
		}
		switch (item[selected].str)
		{
		case "Reset to Defaults":
			if (flibitPort.OwnerIsKeyboard())
			{
				flibitPort.ResetKeyboardControls();
			}
			else
			{
				flibitPort.ResetGamePadControls();
			}
			Init();
			break;
		case "_back":
			active = false;
			if (GameState.paxDemoMode || GameState.longDemoMode)
			{
				Game1.menuMgr.levels[4].active = true;
				break;
			}
			flibitPort.InControlsMenu = false;
			Game1.menuMgr.levels[34].active = true;
			Game1.storageMgr.storage[Game1.menuMgr.GetOwner()].Write(0);
			break;
		default:
		{
			bindingActive = selected;
			activePlayer = (PlayerIndex)Game1.mainPlayer[0];
			prevGPState = GamePad.GetState(activePlayer);
			prevKBState = Keyboard.GetState();
			keyboardBind = !prevGPState.IsConnected;
			string text = item[selected].text[0].ToString();
			text = text.Substring(0, text.IndexOf(":"));
			item[selected] = new MenuItem(text, text + ": ???");
			moveLocked = true;
			break;
		}
		}
		base.Click();
	}

	public override void Cancel()
	{
		if (!moveLocked && !justBound)
		{
			active = false;
			if (GameState.paxDemoMode || GameState.longDemoMode)
			{
				Game1.menuMgr.levels[4].active = true;
			}
			else
			{
				flibitPort.InControlsMenu = false;
				Game1.menuMgr.levels[34].active = true;
				Game1.storageMgr.storage[Game1.menuMgr.GetOwner()].Write(0);
			}
			base.Cancel();
		}
	}
}
