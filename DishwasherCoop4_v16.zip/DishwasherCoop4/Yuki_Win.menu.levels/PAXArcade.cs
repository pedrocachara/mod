using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class PAXArcade : MenuLevel
{
	private const string SOLO = "1 player";

	private const string COO = "2 players";

	private const string BACK = "_back";

	public PAXArcade()
	{
		heading = new StringBuilder("arcade mode");
		item = new MenuItem[4]
		{
			new MenuItem("1 player", "1 player"),
			new MenuItem("2 players", "2 players"),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Smile;
		mapScrollGoal = new Vector2(1676f, 607f);
		orig = new Vector2(420f, 170f);
		glowGoal = new Vector2(0.75f, 0.4f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "1 player":
			active = false;
			Game1.arcade.players = 1;
			Game1.menuMgr.levels[26].active = true;
			break;
		case "2 players":
			Game1.arcade.players = 2;
			Game1.mainPlayer[1] = -1;
			Game1.mainPlayer[2] = -1;
			Game1.mainPlayer[3] = -1;
			Game1.pvpMode = false;
			Game1.gamePlayerMgr.gamePlayer[1].nameStr = null;
			Game1.gamePlayerMgr.gamePlayer[0].nameStr = null;
			active = false;
			Game1.menuMgr.levels[28].active = true;
			break;
		case "_back":
			active = false;
			Game1.menuMgr.levels[55].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[55].active = true;
		base.Cancel();
	}
}
