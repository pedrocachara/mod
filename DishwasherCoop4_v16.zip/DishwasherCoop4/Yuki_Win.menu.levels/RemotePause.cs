using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class RemotePause : MenuLevel
{
	private const string RESUME_GAME = "resume game";

	private const string MOVES_LIST = "moves list";

	private const string ACHIEVEMENTS = "achievements";

	private const string LEADERBOARDS = "leaderboards";

	private const string HELPANDOPTIONS = "help & options";

	private const string HOWTOPLAY = "how to play";

	private const string DEBUG = "debug";

	private const string QUIT = "end game";

	private const string CONTROLS = "controls";

	public RemotePause()
	{
		heading = new StringBuilder(YukiText.remotelyPaused);
		if (GameState.paxDemoMode || GameState.longDemoMode)
		{
			item = new MenuItem[4]
			{
				new MenuItem("moves list", YukiText.movesList),
				new MenuItem("", ""),
				new MenuItem("controls", YukiText.controls),
				new MenuItem("end game", YukiText.exitGame)
			};
		}
		else
		{
			item = new MenuItem[7]
			{
				new MenuItem("moves list", YukiText.movesList),
				new MenuItem("", ""),
				new MenuItem("achievements", YukiText.achievements),
				new MenuItem("leaderboards", YukiText.leaderboards),
				new MenuItem("how to play", YukiText.howToPlay),
				new MenuItem("help & options", YukiText.helpAndOptions),
				new MenuItem("end game", YukiText.exitGame)
			};
		}
		mapScrollGoal = new Vector2(675f, 772f);
		orig = new Vector2(800f, 200f);
		glowGoal = new Vector2(0.25f, 0.45f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 500f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.55f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "moves list":
		{
			active = false;
			MovesList movesList = (MovesList)Game1.menuMgr.levels[6];
			movesList.RefreshMovesList(Game1.menuMgr.owner);
			Game1.menuMgr.levels[6].active = true;
			break;
		}
		case "achievements":
		{
			for (int i = 0; i < Gamer.SignedInGamers.Count; i++)
			{
				if (Gamer.SignedInGamers[i].PlayerIndex == (PlayerIndex)Game1.mainPlayer[0])
				{
					Guide.ShowAchievementsEXT(Gamer.SignedInGamers[i].PlayerIndex);
				}
			}
			break;
		}
		case "leaderboards":
			active = false;
			Game1.menuMgr.levels[29].active = true;
			break;
		case "how to play":
			active = false;
			Game1.menuMgr.levels[33].active = true;
			break;
		case "help & options":
			active = false;
			Game1.menuMgr.levels[34].active = true;
			break;
		case "controls":
			active = false;
			Game1.menuMgr.levels[25].active = true;
			break;
		case "debug":
			active = false;
			Game1.menuMgr.levels[13].active = true;
			break;
		case "end game":
			active = false;
			Game1.menuMgr.levels[5].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		base.Cancel();
	}
}
