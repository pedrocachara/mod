using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class ArcadeYouAreDead : MenuLevel
{
	private const string RETRY = "retry";

	private const string END_GAME = "end game";

	public ArcadeYouAreDead()
	{
		heading = new StringBuilder(YukiText.youAreDead);
		item = new MenuItem[2]
		{
			new MenuItem("retry", YukiText.retry),
			new MenuItem("end game", YukiText.endGame)
		};
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(640f, 400f);
		glowGoal = new Vector2(0.7f, 0.6f);
	}

	public override void Update()
	{
		if (Game1.netSession.IsClient())
		{
			item[0].enabled = false;
		}
		else
		{
			item[0].enabled = true;
		}
		base.Update();
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(50f, 300f) + (1f - alpha) * new Vector2(20f, 1f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 400f) + (1f - alpha) * new Vector2(-20f, -1f), heading, new Color(0f, 0f, 0f, alpha * 0.95f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "retry":
			Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Continue;
			Game1.menuMgr.transFrame = 1f;
			Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.SendContinue(Game1.netSession.session);
			}
			break;
		case "end game":
			active = false;
			Game1.menuMgr.levels[17].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
	}
}
