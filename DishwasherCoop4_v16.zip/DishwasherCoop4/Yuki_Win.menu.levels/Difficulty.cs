using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.guidestuff;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class Difficulty : MenuLevel
{
	private const string PRETTY_PRINCESS = "pretty princess";

	private const string EASY = "easy";

	private const string NORMAL = "normal";

	private const string NINJA = "ninja";

	private const string SAMURAI = "samurai";

	private const string TOURNEY = "speed run";

	private const string BACK = "_back";

	public Difficulty()
	{
		heading = new StringBuilder(YukiText.selectDifficulty);
		item = new MenuItem[8]
		{
			new MenuItem("pretty princess", YukiText.prettyPrincess),
			new MenuItem("easy", YukiText.easy),
			new MenuItem("normal", YukiText.normal),
			new MenuItem("ninja", YukiText.ninja),
			new MenuItem("samurai", YukiText.samurai),
			new MenuItem("speed run", YukiText.speedRun),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		item[0].ltext[0] = new StringBuilder("~" + YukiText.qqq);
		item[0].enabled = false;
		item[4].enabled = false;
		item[5].enabled = false;
		sceneLoc = SceneLoc.Guys;
		mapScrollGoal = new Vector2(1676f, 607f);
		orig = new Vector2(420f, 170f);
		glowGoal = new Vector2(0.75f, 0.4f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "pretty princess":
		case "easy":
		case "normal":
		case "ninja":
		case "samurai":
		case "speed run":
			active = false;
			GameSettings.difficulty = selected;
			if (GuideStuff.GetTrial())
			{
				Game1.menuMgr.levels[19].active = true;
				Game1.worldMapMgr.Read("yuki");
				Game1.levelMgr.currentTrack = 0;
			}
			else if (Game1.storageMgr.playerData[0].levelData[0].levelData[0].score > 0 || Game1.storageMgr.playerData[0].levelData[1].levelData[0].score > 0 || Game1.storageMgr.playerData[0].levelData[2].levelData[0].score > 0 || Game1.storageMgr.playerData[0].levelData[3].levelData[0].score > 0 || Game1.storageMgr.playerData[0].levelData[4].levelData[0].score > 0)
			{
				Game1.menuMgr.levels[18].active = true;
			}
			else
			{
				Game1.menuMgr.levels[19].active = true;
				Game1.worldMapMgr.Read("yuki");
				Game1.levelMgr.currentTrack = 0;
			}
			if (Game1.menuMgr.levels[19].active && ((GameSettings.difficulty == 0 && Game1.storageMgr.playerData[0].levelData[0].levelData[0].score == 0) || (GameSettings.difficulty == 1 && Game1.storageMgr.playerData[0].levelData[1].levelData[0].score == 0) || (GameSettings.difficulty == 2 && Game1.storageMgr.playerData[0].levelData[2].levelData[0].score == 0) || (GameSettings.difficulty == 3 && Game1.storageMgr.playerData[0].levelData[3].levelData[0].score == 0) || GuideStuff.GetTrial()))
			{
				Game1.menuMgr.levels[19].active = false;
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.YukiCampaign;
				Game1.menuMgr.transGoalLevel = 0;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
			}
			break;
		case "_back":
			active = false;
			Game1.menuMgr.levels[2].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[2].active = true;
		base.Cancel();
	}
}
