using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Yuki_Win.audio;

namespace Yuki_Win.menu.levels;

public class MouseControls : MenuLevel
{
	private const string JUMPACCEPT = "Jump/Accept";

	private const string GRABCANCEL = "Grab/Cancel";

	private const string ATTACK = "Attack";

	private const string STRONGSAW = "Strong/Saw";

	private const string SWITCHWEAPONS = "Switch Weapons";

	private const string SWITCHLOADOUTS = "Switch Loadouts";

	private const string GUN = "Gun";

	private const string MAGIC = "Magic";

	private const string INVENTORY = "Inventory";

	private const string PAUSECONFIRM = "Pause/Confirm";

	private const string RESET = "Reset to Defaults";

	private const string BACK = "_back";

	private int bindingActive;

	private MouseState prevMState;

	private bool justBound;

	public MouseControls()
	{
		heading = new StringBuilder(YukiText.controls);
		bindingActive = -1;
		justBound = false;
		Init();
	}

	public void Init()
	{
		List<MenuItem> list = new List<MenuItem>();
		list.Add(new MenuItem("Jump/Accept", YukiText.jumpAccept + ": " + flibitPort.GetMouseString(flibitPort.InputAction.JumpAccept)));
		list.Add(new MenuItem("Grab/Cancel", YukiText.grabCancel + ": " + flibitPort.GetMouseString(flibitPort.InputAction.GrabCancel)));
		list.Add(new MenuItem("Attack", YukiText.attack + ": " + flibitPort.GetMouseString(flibitPort.InputAction.Attack)));
		list.Add(new MenuItem("Strong/Saw", YukiText.strongSaw + ": " + flibitPort.GetMouseString(flibitPort.InputAction.StrongSaw)));
		list.Add(new MenuItem("Switch Weapons", YukiText.switchWeapons + ": " + flibitPort.GetMouseString(flibitPort.InputAction.SwitchWeapons)));
		list.Add(new MenuItem("Switch Loadouts", YukiText.switchLoadouts + ": " + flibitPort.GetMouseString(flibitPort.InputAction.SwitchLoadouts)));
		list.Add(new MenuItem("Gun", YukiText.gun + ": " + flibitPort.GetMouseString(flibitPort.InputAction.Gun)));
		list.Add(new MenuItem("Magic", YukiText.magic + ": " + flibitPort.GetMouseString(flibitPort.InputAction.Magic)));
		list.Add(new MenuItem("Inventory", YukiText.inventory + ": " + flibitPort.GetMouseString(flibitPort.InputAction.Inventory)));
		list.Add(new MenuItem("Pause/Confirm", YukiText.pc_pauseconfirm + ": " + flibitPort.GetMouseString(flibitPort.InputAction.PauseConfirm)));
		list.Add(new MenuItem("Reset to Defaults", YukiText.pc_resettodefaults));
		list.Add(new MenuItem("_back", YukiText.back));
		item = list.ToArray();
		sceneLoc = SceneLoc.Guys;
		mapScrollGoal = new Vector2(665f, 972f);
		orig = new Vector2(800f, 200f);
		glowGoal = new Vector2(0.25f, 0.25f);
		scrolling = true;
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Update()
	{
		if (justBound)
		{
			justBound = false;
			moveLocked = false;
		}
		if (bindingActive >= 0)
		{
			MouseState state = Mouse.GetState();
			int? num = null;
			if (state.LeftButton == ButtonState.Pressed && prevMState.LeftButton == ButtonState.Released)
			{
				num = 0;
			}
			else if (state.RightButton == ButtonState.Pressed && prevMState.RightButton == ButtonState.Released)
			{
				num = 1;
			}
			else if (state.MiddleButton == ButtonState.Pressed && prevMState.MiddleButton == ButtonState.Released)
			{
				num = 2;
			}
			else if (state.XButton1 == ButtonState.Pressed && prevMState.XButton1 == ButtonState.Released)
			{
				num = 3;
			}
			else if (state.XButton2 == ButtonState.Pressed && prevMState.XButton2 == ButtonState.Released)
			{
				num = 4;
			}
			if (num.HasValue)
			{
				int num2 = flibitPort.BindMouse((flibitPort.InputAction)bindingActive, num.Value);
				string str = item[bindingActive].str;
				item[bindingActive] = new MenuItem(str, str + ": " + flibitPort.GetMouseString((flibitPort.InputAction)bindingActive));
				if (num2 >= 0)
				{
					str = item[num2].str;
					item[num2] = new MenuItem(str, str + ": " + flibitPort.GetMouseString((flibitPort.InputAction)num2));
				}
				Sound.PlaySnd(Sound.Category.FX, "sword1");
				bindingActive = -1;
				justBound = true;
			}
			else
			{
				prevMState = state;
			}
		}
		base.Update();
	}

	public override void Click()
	{
		if (moveLocked || justBound)
		{
			return;
		}
		switch (item[selected].str)
		{
		case "Reset to Defaults":
			if (flibitPort.OwnerIsKeyboard())
			{
				flibitPort.ResetKeyboardControls();
			}
			else
			{
				flibitPort.ResetGamePadControls();
			}
			Init();
			break;
		case "_back":
			active = false;
			if (GameState.paxDemoMode || GameState.longDemoMode)
			{
				Game1.menuMgr.levels[4].active = true;
				break;
			}
			Game1.menuMgr.levels[34].active = true;
			Game1.storageMgr.storage[Game1.menuMgr.GetOwner()].Write(0);
			break;
		default:
		{
			bindingActive = selected;
			prevMState = Mouse.GetState();
			string text = item[selected].text[0].ToString();
			text = text.Substring(0, text.IndexOf(":"));
			item[selected] = new MenuItem(text, text + ": ???");
			moveLocked = true;
			break;
		}
		}
		base.Click();
	}

	public override void Cancel()
	{
		if (!moveLocked && !justBound)
		{
			active = false;
			if (GameState.paxDemoMode || GameState.longDemoMode)
			{
				Game1.menuMgr.levels[4].active = true;
			}
			else
			{
				Game1.menuMgr.levels[34].active = true;
				Game1.storageMgr.storage[Game1.menuMgr.GetOwner()].Write(0);
			}
			base.Cancel();
		}
	}
}
