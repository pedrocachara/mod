using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.arcade;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class PAXControls : MenuLevel
{
	private const string CONTINUE = "continue";

	private const string BACK = "_back";

	public PAXControls()
	{
		heading = new StringBuilder(YukiText.controls);
		item = new MenuItem[2]
		{
			new MenuItem("continue", YukiText.continues),
			new MenuItem("_back", YukiText.back)
		};
		controls = true;
		sceneLoc = SceneLoc.Demons;
		mapScrollGoal = new Vector2(1676f, 607f);
		orig = new Vector2(420f, 470f);
		glowGoal = new Vector2(0.75f, 0.4f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "continue":
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
			{
				GameSettings.difficulty = 2;
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Arcade;
				Game1.menuMgr.transGoalLevel = 0;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
			}
			else
			{
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.YukiCampaign;
				Game1.menuMgr.transGoalLevel = 0;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
			}
			break;
		case "_back":
			active = false;
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
			{
				Game1.menuMgr.levels[54].active = true;
			}
			else
			{
				Game1.menuMgr.levels[55].active = true;
			}
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
		{
			Game1.menuMgr.levels[54].active = true;
		}
		else
		{
			Game1.menuMgr.levels[55].active = true;
		}
		base.Cancel();
	}
}
