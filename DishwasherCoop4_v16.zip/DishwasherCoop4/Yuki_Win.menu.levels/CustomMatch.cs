using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class CustomMatch : MenuLevel
{
	private const string CREATE_PUBLIC_MATCH = "create public match";

	private const string CREATE_PRIVATE_MATCH = "create private match";

	private const string BACK = "_back";

	public CustomMatch()
	{
		heading = new StringBuilder(YukiText.customMatch);
		item = new MenuItem[4]
		{
			new MenuItem("create public match", YukiText.createPublicMatch),
			new MenuItem("create private match", YukiText.createPrivateMatch),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(500f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Moon;
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		mapScrollGoal = new Vector2(1157f, 931f);
		orig = new Vector2(600f, 140f);
		glowGoal = new Vector2(0.9f, 0.6f);
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 400f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "create public match":
			active = false;
			Game1.menuMgr.levels[39].active = true;
			Game1.netSession.Host();
			break;
		case "create private match":
			active = false;
			Game1.menuMgr.levels[39].active = true;
			Game1.netSession.HostPrivate();
			break;
		case "_back":
			active = false;
			Game1.menuMgr.levels[35].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[35].active = true;
		base.Cancel();
	}
}
