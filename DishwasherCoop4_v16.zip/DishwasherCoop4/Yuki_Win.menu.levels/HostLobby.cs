using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.guidestuff;
using Yuki_Win.netplay;

namespace Yuki_Win.menu.levels;

public class HostLobby : MenuLevel
{
	private const string BACK = "_back";

	private const string LAUNCH = "launch!";

	private const string INVITE_FRIENDS = "invite friends";

	private const string INVITE_XBOX_LIVE_PARTY = "invite xbox live party";

	public HostLobby()
	{
		heading = new StringBuilder(YukiText.xboxLiveMultiplayer);
		lobby = true;
		item = new MenuItem[7]
		{
			new MenuItem("", "..."),
			new MenuItem("", "..."),
			new MenuItem(null, ""),
			new MenuItem("launch!", YukiText.launch),
			new MenuItem("invite friends", YukiText.inviteFriends),
			new MenuItem(null, ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Moon;
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(640f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Moon;
	}

	public override void Update()
	{
		if (active)
		{
			if (Game1.netSession.state == NetSession.State.None)
			{
				active = false;
				Game1.menuMgr.levels[35].active = true;
			}
			item[5].enabled = false;
			if (Game1.netSession.IsReadyToLaunch())
			{
				item[3].enabled = true;
				item[4].enabled = false;
			}
			else
			{
				item[3].enabled = false;
				item[4].enabled = true;
				if (GuideStuff.IsInParty(Game1.menuMgr.GetOwner()))
				{
					item[5].enabled = true;
				}
			}
			bool flag = false;
			if (Game1.netSession.session != null)
			{
				if (Game1.netSession.session.AllGamers.Count < 1)
				{
					flag = true;
				}
			}
			else
			{
				flag = true;
			}
			if (flag)
			{
				Game1.netSession.createTimeOut += FMan.realTime;
				if (Game1.netSession.createTimeOut > 10f)
				{
					Game1.netSession.Dispose();
					active = false;
					Game1.menuMgr.levels[15].active = true;
					Game1.menuMgr.messageMgr.AddMsg(YukiText.cantHost, new string[5]
					{
						YukiText.checkXboxLiveTry1,
						YukiText.checkXboxLiveTry2,
						"",
						YukiText.returningToMultiplayer1,
						YukiText.returningToMultiplayer2
					}, clear: true, weak: true);
				}
			}
		}
		base.Update();
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "_back":
			active = false;
			Game1.menuMgr.levels[52].active = true;
			break;
		case "launch!":
			if (Game1.netSession.IsReadyToLaunch())
			{
				active = false;
				Game1.menuMgr.levels[12].active = true;
			}
			break;
		case "invite friends":
			try
			{
				if (!Guide.IsVisible)
				{
					Guide.ShowFriends((PlayerIndex)Game1.mainPlayer[0]);
				}
			}
			catch
			{
			}
			break;
		default:
			try
			{
				Gamer gamer = null;
				if (Game1.netSession.IsClient())
				{
					gamer = ((selected != 0) ? Game1.netSession.session.LocalGamers[0] : Game1.netSession.session.RemoteGamers[0]);
				}
				if (Game1.netSession.IsHost())
				{
					gamer = ((selected != 1) ? Game1.netSession.session.LocalGamers[0] : Game1.netSession.session.RemoteGamers[0]);
				}
				if (gamer != null)
				{
					Guide.ShowGamerCard((PlayerIndex)Game1.mainPlayer[Game1.menuMgr.GetOwner()], gamer);
				}
			}
			catch
			{
			}
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[52].active = true;
		base.Cancel();
	}
}
