using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class Video : MenuLevel
{
	private const string BACK = "_back";

	public Video()
	{
		heading = new StringBuilder("video");
		item = new MenuItem[1]
		{
			new MenuItem("_back", YukiText.back)
		};
		video = true;
		sceneLoc = SceneLoc.Guys;
		mapScrollGoal = new Vector2(1676f, 607f);
		orig = new Vector2(420f, 470f);
		glowGoal = new Vector2(0.75f, 0.4f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "_back")
		{
			active = false;
			Game1.menuMgr.levels[23].active = true;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[23].active = true;
		base.Cancel();
	}
}
