using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class DishChallenge : MenuLevel
{
	private const string CHARACTER = "character";

	private const string BACK = "_back";

	public DishChallenge()
	{
		heading = new StringBuilder(YukiText.selectHero);
		item = new MenuItem[Game1.levelMgr.levels[3].Count + 2];
		item = new MenuItem[3]
		{
			new MenuItem("character", new string[2]
			{
				YukiText.theprisoner,
				YukiText.theDishwasher
			}, MenuItem.ItemFlag.CampaignPortrait),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Smile;
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(640f, 150f);
		glowGoal = new Vector2(0.75f, 0.3f);
	}

	public override void Click()
	{
		if (!Game1.netSession.IsClient())
		{
			switch (item[selected].str)
			{
			case "_back":
				active = false;
				Game1.menuMgr.levels[2].active = true;
				break;
			case "character":
				if (item[0].xSel == 0)
				{
					Game1.levelMgr.levels[4][0].arcadePlayer[0] = 0;
					active = false;
					Game1.menuMgr.levels[43].active = true;
				}
				else
				{
					Game1.levelMgr.levels[4][0].arcadePlayer[0] = 1;
					active = false;
					Game1.menuMgr.levels[42].active = true;
				}
				break;
			}
		}
		base.Click();
	}

	public override void Cancel()
	{
		if (!Game1.netSession.IsClient())
		{
			active = false;
			Game1.menuMgr.levels[2].active = true;
		}
		base.Cancel();
	}

	public static InvCatalog.InvItemName ItemNameFromDishChallenge(int character, int weapon)
	{
		switch (character)
		{
		case 0:
			switch (weapon)
			{
			case 0:
				return InvCatalog.InvItemName.Conviction;
			case 1:
				return InvCatalog.InvItemName.CloudSword;
			case 2:
				return InvCatalog.InvItemName.Kamakazi;
			case 3:
				return InvCatalog.InvItemName.Painkiller;
			}
			break;
		case 1:
			switch (weapon)
			{
			case 0:
				return InvCatalog.InvItemName.ShiftBlade;
			case 1:
				return InvCatalog.InvItemName.MeatCleavers;
			case 2:
				return InvCatalog.InvItemName.ViolenceHammer;
			case 3:
				return InvCatalog.InvItemName.TheGuillotine;
			case 4:
				return InvCatalog.InvItemName.Dekkentozter;
			}
			break;
		}
		return InvCatalog.InvItemName.Conviction;
	}
}
