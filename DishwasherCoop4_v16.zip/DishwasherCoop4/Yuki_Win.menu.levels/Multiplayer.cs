using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.arcade;
using Yuki_Win.debug;
using Yuki_Win.guidestuff;

namespace Yuki_Win.menu.levels;

public class Multiplayer : MenuLevel
{
	private const string STORY = "coop story";

	private const string ARCADE = "arcade mode";

	private const string BACK = "_back";

	public Multiplayer()
	{
		heading = new StringBuilder(YukiText.multiplayer);
		item = new MenuItem[5]
		{
			new MenuItem("coop story", YukiText.coopStory),
			new MenuItem("arcade mode", YukiText.arcadeMode),
			new MenuItem("pvp arena", "pvp arena"),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Guys;
		mapScrollGoal = new Vector2(1457f, 1031f);
		orig = new Vector2(700f, 180f);
		glowGoal = new Vector2(0.2f, 0.8f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 400f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Update()
	{
		if (active)
		{
			if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
			{
				coopLev = false;
			}
			else
			{
				coopLev = true;
			}
		}
		base.Update();
	}

	public override void Click()
	{
		if (!Game1.netSession.IsClient())
		{
			switch (item[selected].str)
			{
			case "coop story":
				Game1.PvpStop();
				Game1.arcade.arcadeMode = Arcade.ArcadeMode.Off;
				active = false;
				Game1.menuMgr.levels[11].active = true;
				Game1.levelMgr.currentTrack = 2;
				Game1.coopPlayers = Game1.LocalPlayerCount();
				if (GuideStuff.GetTrial())
				{
					Game1.menuMgr.levels[11].item[0].enabled = false;
					Game1.menuMgr.levels[11].item[4].enabled = false;
					Game1.menuMgr.levels[11].item[5].enabled = false;
				}
				else if (DebugManager.unlockAll)
				{
					Game1.menuMgr.levels[11].item[0].enabled = true;
					Game1.menuMgr.levels[11].item[4].enabled = true;
					Game1.menuMgr.levels[11].item[5].enabled = true;
				}
				break;
			case "arcade mode":
				Game1.PvpStop();
				Game1.arcade.arcadeMode = Arcade.ArcadeMode.Arcade;
				Game1.arcade.players = Game1.LocalPlayerCount();
				active = false;
				Game1.menuMgr.levels[14].active = true;
				break;
			case "pvp arena":
				if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
				{
					break;
				}
				Game1.arcade.arcadeMode = Arcade.ArcadeMode.Off;
				Game1.levelMgr.currentTrack = 2;
				Game1.coopPlayers = Game1.LocalPlayerCount();
				Game1.arcade.players = Game1.coopPlayers;
				Game1.PvpStart();
				active = false;
				for (int pl = 0; pl < Game1.menuMgr.levels[21].item.Length; pl++)
				{
					Game1.menuMgr.levels[21].item[pl].enabled = true;
				}
				Game1.menuMgr.levels[21].active = true;
				break;
			case "_back":
				active = false;
				if (Game1.netSession.IsHost())
				{
					Game1.menuMgr.levels[39].active = true;
				}
				else
				{
					Game1.menuMgr.levels[15].active = true;
				}
				break;
			}
		}
		base.Click();
	}

	public override void Cancel()
	{
		if (!Game1.netSession.IsClient())
		{
			active = false;
			if (Game1.netSession.IsHost())
			{
				Game1.menuMgr.levels[39].active = true;
			}
			else
			{
				Game1.menuMgr.levels[15].active = true;
			}
		}
		else
		{
			Game1.menuMgr.NetGameQuitYouSure(MenuManager.LevelTitle.Multiplayer);
		}
		base.Cancel();
	}
}
