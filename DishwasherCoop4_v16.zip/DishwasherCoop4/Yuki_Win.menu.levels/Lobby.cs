using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.netplay;

namespace Yuki_Win.menu.levels;

public class Lobby : MenuLevel
{
	private const string BACK = "_back";

	public Lobby()
	{
		heading = new StringBuilder(YukiText.xboxLiveMultiplayer);
		lobby = true;
		item = new MenuItem[4]
		{
			new MenuItem("", "..."),
			new MenuItem("", "..."),
			new MenuItem(null, ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Moon;
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(640f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Moon;
	}

	public override void Update()
	{
		if (active && Game1.netSession.state == NetSession.State.None)
		{
			active = false;
			Game1.menuMgr.levels[35].active = true;
		}
		base.Update();
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "_back")
		{
			Game1.menuMgr.NetGameQuitYouSure(MenuManager.LevelTitle.Lobby);
		}
		else
		{
			try
			{
				Gamer gamer = null;
				if (Game1.netSession.IsClient())
				{
					gamer = ((selected != 0) ? Game1.netSession.session.LocalGamers[0] : Game1.netSession.session.RemoteGamers[0]);
				}
				if (Game1.netSession.IsHost())
				{
					gamer = ((selected != 1) ? Game1.netSession.session.LocalGamers[0] : Game1.netSession.session.RemoteGamers[0]);
				}
				if (gamer != null)
				{
					Guide.ShowGamerCard((PlayerIndex)Game1.mainPlayer[Game1.menuMgr.GetOwner()], gamer);
				}
			}
			catch
			{
			}
		}
		base.Click();
	}

	public override void Cancel()
	{
		Game1.menuMgr.NetGameQuitYouSure(MenuManager.LevelTitle.Lobby);
		base.Cancel();
	}
}
