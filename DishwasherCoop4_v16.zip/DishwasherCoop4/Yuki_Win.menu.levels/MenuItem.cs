using System.Text;

namespace Yuki_Win.menu.levels;

public class MenuItem
{
	public enum ItemFlag
	{
		None,
		SinglePortrait,
		CoopPortrait,
		CampaignPortrait,
		YukiWeapons,
		DishWeapons,
		KeyMapping
	}

	public StringBuilder[] text;

	public StringBuilder[] ltext;

	public StringBuilder[] desc;

	public string str;

	public bool move;

	public bool enabled;

	public int xSel;

	public float fac;

	public float alpha;

	public ItemFlag itemflag;

	public void SetFac()
	{
		fac = Rand.GetRandomFloat(0.7f, 1.8f);
		if (alpha <= 0f)
		{
			alpha -= Rand.GetRandomFloat(0f, 0.5f);
		}
	}

	public MenuItem(string text, string sbtext)
	{
		this.text = new StringBuilder[1]
		{
			new StringBuilder(sbtext)
		};
		if (sbtext == "")
		{
			str = null;
		}
		else
		{
			str = text;
		}
		enabled = true;
		MakeLockText();
		SetFac();
	}

	public MenuItem(string text, string sbtext, bool move)
	{
		this.text = new StringBuilder[1]
		{
			new StringBuilder(sbtext)
		};
		if (sbtext == "")
		{
			str = null;
		}
		else
		{
			str = text;
		}
		this.move = move;
		enabled = false;
		MakeLockText();
		SetFac();
	}

	public MenuItem(string str, string[] text)
	{
		this.text = new StringBuilder[text.Length];
		for (int i = 0; i < text.Length; i++)
		{
			this.text[i] = new StringBuilder(text[i]);
		}
		this.str = str;
		enabled = true;
		MakeLockText();
		SetFac();
	}

	public MenuItem(string str, string text, string[] desc)
	{
		this.text = new StringBuilder[1]
		{
			new StringBuilder(text)
		};
		this.desc = new StringBuilder[desc.Length];
		for (int i = 0; i < desc.Length; i++)
		{
			this.desc[i] = new StringBuilder(desc[i]);
		}
		this.str = str;
		enabled = true;
		MakeLockText();
		SetFac();
	}

	public MenuItem(string str, string[] text, ItemFlag flag)
	{
		this.text = new StringBuilder[text.Length];
		for (int i = 0; i < text.Length; i++)
		{
			this.text[i] = new StringBuilder(text[i]);
		}
		this.str = str;
		enabled = true;
		itemflag = flag;
		MakeLockText();
		SetFac();
	}

	private void MakeLockText()
	{
		ltext = new StringBuilder[text.Length];
		for (int i = 0; i < text.Length; i++)
		{
			ltext[i] = new StringBuilder("~" + text[i].ToString());
		}
	}
}
