using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.levels;

namespace Yuki_Win.menu.levels;

public class LeaderboardLevels : MenuLevel
{
	private const string BACK = "_back";

	public LeaderboardLevels()
	{
		heading = new StringBuilder(YukiText.selectLevel);
		item = new MenuItem[Game1.levelMgr.levels[3].Count + 2];
		int num = 0;
		foreach (Level item in Game1.levelMgr.levels[3])
		{
			base.item[num] = new MenuItem("", item.name);
			num++;
		}
		base.item[base.item.Length - 2] = new MenuItem("", "");
		base.item[base.item.Length - 1] = new MenuItem("_back", YukiText.back);
		sceneLoc = SceneLoc.Guys;
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(600f, 200f);
		glowGoal = new Vector2(0.75f, 0.3f);
		scrolling = true;
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(50f, 500f) + (1f - alpha) * new Vector2(20f, 1f), heading, new Color(1f, 1f, 1f, alpha * 0.55f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 600f) + (1f - alpha) * new Vector2(-20f, -1f), heading, new Color(0f, 0f, 0f, alpha * 0.95f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "_back")
		{
			active = false;
			Game1.menuMgr.levels[29].active = true;
		}
		else
		{
			active = false;
			MenuLeaderboard menuLeaderboard = (MenuLeaderboard)Game1.menuMgr.levels[31];
			menuLeaderboard.returnLev = 30;
			Game1.menuMgr.levels[31].active = true;
			Game1.leaderBoard.filter = 0;
			int owner = 0;
			if (Game1.menuMgr.pauseMode)
			{
				owner = Game1.menuMgr.owner;
			}
			Game1.leaderBoard.Read(selected, owner);
			Game1.menuMgr.levels[31].heading = new StringBuilder(Game1.levelMgr.levels[3][selected].name);
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[29].active = true;
		base.Cancel();
	}
}
