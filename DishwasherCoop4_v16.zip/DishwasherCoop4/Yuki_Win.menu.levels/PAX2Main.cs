using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.arcade;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class PAX2Main : MenuLevel
{
	private const string CAMPAIGN = "campaign";

	private const string ARCADE = "arcade";

	private const string BACK = "_back";

	public PAX2Main()
	{
		heading = new StringBuilder("select mode");
		item = new MenuItem[4]
		{
			new MenuItem("campaign", "campaign", new string[2] { "yuki's death brings about", "unimaginable suffering." }),
			new MenuItem("arcade", "arcade", new string[2] { "challenge rooms are painted with", "viscera by one or two players." }),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Water;
		mapScrollGoal = new Vector2(2176f, 407f);
		orig = new Vector2(640f, 170f);
		glowGoal = new Vector2(0.75f, 0.4f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "campaign":
			Game1.arcade.arcadeMode = Arcade.ArcadeMode.Off;
			GameSettings.difficulty = 2;
			GameState.paxLevel = item[selected].xSel;
			Game1.menuMgr.levels[26].active = true;
			active = false;
			Game1.worldMapMgr.Read("yuki");
			break;
		case "arcade":
			Game1.arcade.arcadeMode = Arcade.ArcadeMode.Arcade;
			GameSettings.difficulty = 2;
			Game1.menuMgr.levels[54].active = true;
			active = false;
			break;
		case "_back":
			active = false;
			Game1.menuMgr.levels[22].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[22].active = true;
		base.Cancel();
	}
}
