using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.guidestuff;

namespace Yuki_Win.menu.levels;

public class MainMenu : MenuLevel
{
	private const string SINGLE_PLAYER = "single player";

	private const string MULTIPLAYER = "multiplayer";

	private const string ACHIEVEMENTS = "achievements";

	private const string LEADERBOARDS = "leaderboards";

	private const string HELPANDOPTIONS = "help & options";

	private const string DEBUG = "debug";

	private const string QUIT = "quit";

	public MainMenu()
	{
		heading = new StringBuilder(YukiText.mainMenu);
		item = new MenuItem[7]
		{
			new MenuItem("single player", YukiText.singlePlayer),
			new MenuItem("multiplayer", YukiText.multiplayer),
			new MenuItem("", ""),
			new MenuItem("achievements", YukiText.achievements),
			new MenuItem("leaderboards", YukiText.leaderboards),
			new MenuItem("help & options", YukiText.helpAndOptions),
			new MenuItem("quit", "Quit")
		};
		sceneLoc = SceneLoc.Water;
		mapScrollGoal = new Vector2(675f, 772f);
		orig = new Vector2(800f, 150f);
		glowGoal = new Vector2(0.25f, 0.45f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 500f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.55f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "single player":
			active = false;
			Game1.menuMgr.levels[2].active = true;
			Game1.netSession.Dispose();
			if (GuideStuff.GetTrial())
			{
				Game1.menuMgr.levels[2].item[2].enabled = false;
			}
			else
			{
				Game1.menuMgr.levels[2].item[2].enabled = true;
			}
			break;
		case "multiplayer":
			active = false;
			Game1.menuMgr.levels[15].active = true;
			Game1.mainPlayer[1] = -1;
			Game1.mainPlayer[2] = -1;
			Game1.mainPlayer[3] = -1;
			Game1.pvpMode = false;
			if (GuideStuff.GetTrial())
			{
				Game1.menuMgr.levels[15].item[1].enabled = false;
			}
			else
			{
				Game1.menuMgr.levels[15].item[1].enabled = true;
			}
			break;
		case "achievements":
		{
			for (int i = 0; i < Gamer.SignedInGamers.Count; i++)
			{
				if (Gamer.SignedInGamers[i].PlayerIndex == (PlayerIndex)Game1.mainPlayer[0])
				{
					Guide.ShowAchievementsEXT(Gamer.SignedInGamers[i].PlayerIndex);
				}
			}
			break;
		}
		case "leaderboards":
		{
			bool flag = false;
			SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[0]);
			if (signedInGamerAtIndex != null && !signedInGamerAtIndex.IsSignedInToLive)
			{
				Game1.menuMgr.messageMgr.AddMsg(YukiText.cantReadLeaderboards, new string[3]
				{
					YukiText.youMustBeSignedInLive1,
					YukiText.youMustBeSignedInLive2,
					YukiText.youMustBeSignedInLive3
				});
				flag = true;
			}
			if (!flag)
			{
				active = false;
				Game1.menuMgr.levels[29].active = true;
			}
			break;
		}
		case "help & options":
			active = false;
			Game1.menuMgr.levels[34].active = true;
			((HelpAndOptions)Game1.menuMgr.levels[34]).Init();
			Game1.menuMgr.levels[34].item[4].enabled = true;
			break;
		case "debug":
			active = false;
			Game1.menuMgr.levels[13].active = true;
			break;
		case "quit":
			active = false;
			Game1.menuMgr.levels[1].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[22].active = true;
		base.Cancel();
	}
}
