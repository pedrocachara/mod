using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.guidestuff;

namespace Yuki_Win.menu.levels;

public class XBLA : MenuLevel
{
	private const string QUICK_MATCH = "quick match";

	private const string CUSTOM_MATCH = "custom match";

	private const string BACK = "_back";

	public XBLA()
	{
		heading = new StringBuilder(YukiText.multiplayer);
		item = new MenuItem[4]
		{
			new MenuItem("quick match", YukiText.quickMatch),
			new MenuItem("custom match", YukiText.customMatch),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(500f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Demons;
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		mapScrollGoal = new Vector2(1157f, 931f);
		orig = new Vector2(600f, 140f);
		glowGoal = new Vector2(0.9f, 0.6f);
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 400f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Update()
	{
		if (active)
		{
			if (GuideStuff.IsInParty(Game1.menuMgr.GetOwner()))
			{
				item[2].enabled = true;
			}
			else
			{
				item[2].enabled = false;
			}
		}
		base.Update();
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "quick match":
			active = false;
			Game1.menuMgr.levels[45].active = true;
			Game1.netSession.QuickFind();
			break;
		case "custom match":
			active = false;
			Game1.menuMgr.levels[44].active = true;
			break;
		case "_back":
			active = false;
			Game1.menuMgr.levels[15].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[15].active = true;
		base.Cancel();
	}
}
