using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class HostQuitYouSure : MenuLevel
{
	private const string QUIT = "ok";

	private const string CANCEL = "cancel";

	public int backLev;

	public HostQuitYouSure()
	{
		heading = new StringBuilder(YukiText.exitGameSession);
		message = new StringBuilder[2]
		{
			new StringBuilder(YukiText.youWillLose1),
			new StringBuilder(YukiText.youWillLose2)
		};
		item = new MenuItem[2]
		{
			new MenuItem("ok", YukiText.ok),
			new MenuItem("cancel", YukiText.cancel)
		};
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(400f, 200f);
		glowGoal = new Vector2(0.7f, 0.6f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(50f, 300f) + (1f - alpha) * new Vector2(20f, 1f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 400f) + (1f - alpha) * new Vector2(-20f, -1f), heading, new Color(0f, 0f, 0f, alpha * 0.95f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "ok":
			Game1.netSession.Dispose();
			active = false;
			Game1.menuMgr.levels[35].active = true;
			break;
		case "cancel":
			active = false;
			Game1.menuMgr.levels[39].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[39].active = true;
		base.Cancel();
	}
}
