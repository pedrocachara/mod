using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.guidestuff;

namespace Yuki_Win.menu.levels;

public class BuyLev : MenuLevel
{
	public bool quitOnExit;

	public BuyLev()
	{
		heading = new StringBuilder(YukiText.buy);
		item = new MenuItem[1]
		{
			new MenuItem(" ", " ")
		};
		buy = true;
		mapScrollGoal = new Vector2(665f, 972f);
		orig = new Vector2(800f, 200f);
		glowGoal = new Vector2(0.25f, 0.25f);
		scrolling = true;
		sceneLoc = SceneLoc.Demons;
	}

	public override void Update()
	{
		if (alpha > 0f)
		{
			Game1.menuMgr.buy.Update();
		}
		if (active && !GuideStuff.GetTrial())
		{
			active = false;
			if (quitOnExit)
			{
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Quit;
				Game1.menuMgr.transGoalLevel = selected;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
			}
			else
			{
				Game1.menuMgr.levels[0].active = true;
			}
		}
		base.Update();
	}

	public override void Click()
	{
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		if (quitOnExit)
		{
			Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Quit;
			Game1.menuMgr.transGoalLevel = selected;
			Game1.menuMgr.transFrame = 1f;
			Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
		}
		else
		{
			Game1.menuMgr.levels[0].active = true;
		}
		base.Cancel();
	}
}
