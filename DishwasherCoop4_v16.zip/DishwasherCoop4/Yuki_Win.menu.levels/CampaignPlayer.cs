using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class CampaignPlayer : MenuLevel
{
	private const string PLAYER = "the dishwasher";

	private const string BACK = "_back";

	public CampaignPlayer()
	{
		heading = new StringBuilder(YukiText.selectCampaign);
		item = new MenuItem[3]
		{
			new MenuItem("the dishwasher", new string[2]
			{
				YukiText.theprisoner,
				YukiText.theDishwasher
			}, MenuItem.ItemFlag.CampaignPortrait),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Smile;
		mapScrollGoal = new Vector2(2176f, 407f);
		orig = new Vector2(640f, 170f);
		glowGoal = new Vector2(0.75f, 0.4f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(0f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(1f, 1f, 1f, alpha * 0.25f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 600f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "the dishwasher":
			switch (item[selected].xSel)
			{
			case 0:
				Game1.menuMgr.levels[19].active = true;
				Game1.worldMapMgr.Read("yuki");
				Game1.levelMgr.currentTrack = 0;
				break;
			case 1:
				Game1.menuMgr.levels[20].active = true;
				Game1.worldMapMgr.Read("dish");
				Game1.levelMgr.currentTrack = 1;
				break;
			}
			active = false;
			break;
		case "_back":
			active = false;
			Game1.menuMgr.levels[3].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[3].active = true;
		base.Cancel();
	}
}
