using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.arcade;
using Yuki_Win.debug;
using Yuki_Win.guidestuff;
using Yuki_Win.player;

namespace Yuki_Win.menu.levels;

public class SinglePlayer : MenuLevel
{
	private const string STORY = "story mode";

	private const string ARCADE = "arcade mode";

	private const string CHALLENGE = "dish challenge";

	private const string PRACTICE = "practice room";

	private const string BACK = "_back";

	public SinglePlayer()
	{
		heading = new StringBuilder(YukiText.singlePlayer);
		item = new MenuItem[7]
		{
			new MenuItem("story mode", YukiText.storyMode),
			new MenuItem("arcade mode", YukiText.arcadeMode),
			new MenuItem("dish challenge", YukiText.dishChallenge),
			new MenuItem("", ""),
			new MenuItem("practice room", YukiText.practiceRoom),
			new MenuItem("", ""),
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Moon;
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(500f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(450f, 50f) + (1f - alpha) * new Vector2(1f, -20f), heading, new Color(0f, 0f, 0f, alpha * 0.85f), 8f, 0);
		Text.DrawJText(sprite, new Vector2(1000f, 400f) + (1f - alpha) * new Vector2(1f, 20f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Update()
	{
		if (active)
		{
			if (GuideStuff.GetTrial())
			{
				item[2].enabled = false;
			}
			else
			{
				item[2].enabled = true;
			}
		}
		base.Update();
	}

	public override void Click()
	{
		int num = 12;
		int num2 = 11;
		switch (item[selected].str)
		{
		case "story mode":
			Game1.arcade.arcadeMode = Arcade.ArcadeMode.Off;
			active = false;
			Game1.menuMgr.levels[3].active = true;
			if (GuideStuff.GetTrial())
			{
				Game1.menuMgr.levels[3].item[0].enabled = false;
				Game1.menuMgr.levels[3].item[4].enabled = false;
				Game1.menuMgr.levels[3].item[5].enabled = false;
				break;
			}
			if (DebugManager.unlockAll)
			{
				Game1.menuMgr.levels[3].item[0].enabled = true;
				Game1.menuMgr.levels[3].item[4].enabled = true;
				Game1.menuMgr.levels[3].item[5].enabled = true;
				break;
			}
			Game1.menuMgr.levels[3].item[0].enabled = false;
			Game1.menuMgr.levels[3].item[4].enabled = false;
			Game1.menuMgr.levels[3].item[5].enabled = false;
			if (Game1.storageMgr.playerData[0].levelData[0].levelData[num].score > 0 || Game1.storageMgr.playerData[0].levelData[1].levelData[num].score > 0 || Game1.storageMgr.playerData[0].levelData[2].levelData[num].score > 0 || Game1.storageMgr.playerData[0].levelData[3].levelData[num].score > 0 || Game1.storageMgr.playerData[0].levelData[6].levelData[num2].score > 0 || Game1.storageMgr.playerData[0].levelData[7].levelData[num2].score > 0 || Game1.storageMgr.playerData[0].levelData[8].levelData[num2].score > 0 || Game1.storageMgr.playerData[0].levelData[9].levelData[num2].score > 0)
			{
				Game1.menuMgr.levels[3].item[4].enabled = true;
				Game1.menuMgr.levels[3].item[5].enabled = true;
			}
			if (Game1.gamePlayerMgr.gamePlayer[0].prettyPrincessUnlock)
			{
				Game1.menuMgr.levels[3].item[0].enabled = true;
			}
			break;
		case "practice room":
			if (Game1.storageMgr.playerData[0].levelData[1].levelData[num].score > 0 || Game1.storageMgr.playerData[0].levelData[2].levelData[num].score > 0 || Game1.storageMgr.playerData[0].levelData[3].levelData[num].score > 0)
			{
				active = false;
				Game1.menuMgr.levels[49].active = true;
				break;
			}
			Game1.arcade.arcadeMode = Arcade.ArcadeMode.Off;
			GameSettings.difficulty = 2;
			Game1.menuMgr.transGoal = MenuManager.TransitionGoal.YukiPractice;
			Game1.menuMgr.transGoalLevel = selected;
			Game1.menuMgr.transFrame = 1f;
			Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
			break;
		case "arcade mode":
			Game1.arcade.arcadeMode = Arcade.ArcadeMode.Arcade;
			active = false;
			Game1.arcade.players = 1;
			Game1.menuMgr.levels[14].active = true;
			break;
		case "dish challenge":
			Game1.arcade.arcadeMode = Arcade.ArcadeMode.DishChallenge;
			active = false;
			Game1.arcade.players = 1;
			Game1.menuMgr.levels[41].active = true;
			break;
		case "_back":
			active = false;
			Game1.menuMgr.levels[0].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[0].active = true;
		base.Cancel();
	}
}
