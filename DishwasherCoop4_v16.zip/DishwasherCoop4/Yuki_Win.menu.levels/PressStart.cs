using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class PressStart : MenuLevel
{
	private const string PRESS_START = "press start";

	public PressStart()
	{
		item = new MenuItem[1]
		{
			new MenuItem("press start", YukiText.pressStart)
		};
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(640f, 400f);
		glowGoal = new Vector2(0.7f, 0.6f);
		pressStartScreen = true;
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "press start")
		{
			for (int i = 0; i < Game1.menuMgr.menuPlayer.Length; i++)
			{
				if (flibitPort.PressStartClick() || Game1.menuMgr.menuPlayer[i].keyAccept || Game1.menuMgr.menuPlayer[i].keyStart)
				{
					Game1.signedInGamerMgr.Reset();
					Game1.mainPlayer[0] = i;
					Game1.storageMgr.storage[0].ReadAll();
					Game1.storageMgr.storage[1].ReadAll();
					active = false;
					if (GameState.paxDemoMode || GameState.longDemoMode)
					{
						Game1.menuMgr.levels[55].active = true;
					}
					else
					{
						Game1.menuMgr.levels[0].active = true;
					}
					break;
				}
			}
		}
		base.Click();
	}

	public override void Cancel()
	{
	}
}
