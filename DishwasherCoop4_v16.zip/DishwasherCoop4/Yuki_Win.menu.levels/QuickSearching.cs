using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.netplay;

namespace Yuki_Win.menu.levels;

public class QuickSearching : MenuLevel
{
	private const string BACK = "_back";

	public QuickSearching()
	{
		heading = new StringBuilder(YukiText.searching);
		searching = true;
		item = new MenuItem[1]
		{
			new MenuItem("_back", YukiText.back)
		};
		sceneLoc = SceneLoc.Moon;
		mapScrollGoal = new Vector2(957f, 931f);
		orig = new Vector2(500f, 140f);
		glowGoal = new Vector2(0.7f, 0.6f);
		sceneLoc = SceneLoc.Moon;
	}

	public override void Update()
	{
		if (active)
		{
			if (Game1.netSession.state == NetSession.State.Hosting)
			{
				active = false;
				Game1.menuMgr.levels[39].active = true;
			}
			else if (Game1.netSession.state == NetSession.State.None)
			{
				active = false;
				Game1.menuMgr.levels[36].active = true;
				Game1.netSession.Join(Game1.netSession.availableSessions[0]);
			}
			Game1.netSession.timeOut += FMan.realTime;
			if (Game1.netSession.timeOut > 20f)
			{
				Game1.netSession.Dispose();
				active = false;
				Game1.menuMgr.levels[15].active = true;
				Game1.menuMgr.messageMgr.AddMsg(YukiText.quickFindFailed, new string[2]
				{
					YukiText.returningToMultiplayer1,
					YukiText.returningToMultiplayer2
				});
			}
		}
		base.Update();
	}

	public override void Click()
	{
		string str;
		if ((str = item[selected].str) != null && str == "_back")
		{
			active = false;
			Game1.menuMgr.levels[35].active = true;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		Game1.menuMgr.levels[35].active = true;
		base.Cancel();
	}
}
