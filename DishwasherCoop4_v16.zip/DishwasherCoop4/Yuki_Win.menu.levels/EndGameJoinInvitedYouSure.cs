using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class EndGameJoinInvitedYouSure : MenuLevel
{
	private const string QUIT = "ok";

	private const string CANCEL = "cancel";

	public EndGameJoinInvitedYouSure()
	{
		heading = new StringBuilder(YukiText.acceptInvitation);
		message = new StringBuilder[2]
		{
			new StringBuilder(YukiText.youWillLose1),
			new StringBuilder(YukiText.youWillLose2)
		};
		item = new MenuItem[2]
		{
			new MenuItem("ok", YukiText.ok),
			new MenuItem("cancel", YukiText.cancel)
		};
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(400f, 200f);
		glowGoal = new Vector2(0.7f, 0.6f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(50f, 300f) + (1f - alpha) * new Vector2(20f, 1f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 400f) + (1f - alpha) * new Vector2(-20f, -1f), heading, new Color(0f, 0f, 0f, alpha * 0.95f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "ok":
			active = false;
			if (Game1.netSession.IsClient() || Game1.netSession.IsHost())
			{
				Game1.netSession.Dispose();
			}
			Game1.menuMgr.transFrame = 1f;
			Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
			Game1.menuMgr.transGoal = MenuManager.TransitionGoal.ResetMenu;
			break;
		case "cancel":
			active = false;
			if (Game1.menuMgr.remotePause)
			{
				Game1.menuMgr.levels[40].active = true;
			}
			else
			{
				Game1.menuMgr.levels[4].active = true;
			}
			DitchInvite();
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		if (Game1.menuMgr.remotePause)
		{
			Game1.menuMgr.levels[40].active = true;
		}
		else
		{
			Game1.menuMgr.levels[4].active = true;
		}
		DitchInvite();
		base.Cancel();
	}

	private void DitchInvite()
	{
		Game1.DitchInvite();
	}
}
