using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.guidestuff;

namespace Yuki_Win.menu.levels;

public class SelectPlayers : MenuLevel
{
	public SelectPlayers()
	{
		heading = new StringBuilder(YukiText.selectPlayers);
		selectPlayers = true;
		item = new MenuItem[1]
		{
			new MenuItem("press start!", YukiText.pressStart)
		};
		sceneLoc = SceneLoc.Moon;
		coopLev = true;
		mapScrollGoal = new Vector2(1457f, 1031f);
		orig = new Vector2(600f, 180f);
		glowGoal = new Vector2(0.2f, 0.8f);
	}

	public override void Update()
	{
		base.Update();
	}

	public override void Click()
	{
		if (active && alpha > 0.9f && Game1.mainPlayer[0] > -1 && Game1.mainPlayer[1] > -1)
		{
			active = false;
			if (GameState.paxDemoMode || GameState.longDemoMode)
			{
				Game1.menuMgr.levels[26].active = true;
			}
			else
			{
				Game1.menuMgr.levels[12].active = true;
				if (GuideStuff.demo)
				{
					Game1.menuMgr.levels[12].item[0].enabled = false;
				}
				else
				{
					Game1.menuMgr.levels[12].item[0].enabled = true;
				}
			}
		}
		base.Click();
	}

	public override void Cancel()
	{
		active = false;
		if (GameState.paxDemoMode || GameState.longDemoMode)
		{
			Game1.menuMgr.levels[54].active = true;
		}
		else
		{
			Game1.menuMgr.levels[0].active = true;
		}
		base.Cancel();
	}
}
