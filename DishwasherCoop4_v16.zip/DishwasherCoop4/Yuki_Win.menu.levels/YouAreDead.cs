using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.menu.levels;

public class YouAreDead : MenuLevel
{
	private const string CONTINUE = "continue";

	private const string RESTART_LEVEL = "restart level";

	private const string END_GAME = "end game";

	public YouAreDead()
	{
		heading = new StringBuilder(YukiText.youAreDead);
		item = new MenuItem[3]
		{
			new MenuItem("continue", YukiText.continues),
			new MenuItem("restart level", YukiText.restartLevel),
			new MenuItem("end game", YukiText.endGame)
		};
		mapScrollGoal = new Vector2(900f, 374f);
		orig = new Vector2(ScrollManager.screenSize.X / 2f, 400f);
		glowGoal = new Vector2(0.7f, 0.6f);
	}

	public override void DrawHeading(SpriteBatch sprite)
	{
		Text.DrawJText(sprite, new Vector2(50f, 300f) + (1f - alpha) * new Vector2(20f, 1f), heading, new Color(1f, 1f, 1f, alpha * 0.35f), 5f, 0);
		Text.DrawJText(sprite, new Vector2(1200f, 400f) + (1f - alpha) * new Vector2(-20f, -1f), heading, new Color(0f, 0f, 0f, alpha * 0.95f), 5f, 2);
		base.DrawHeading(sprite);
	}

	public override void Update()
	{
		if (Game1.netSession.IsClient())
		{
			item[0].enabled = false;
			item[1].enabled = false;
		}
		else
		{
			item[0].enabled = true;
			item[1].enabled = true;
		}
		base.Update();
	}

	public override void Click()
	{
		switch (item[selected].str)
		{
		case "continue":
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.SendContinue(Game1.netSession.session);
			}
			if (!Game1.netSession.IsClient())
			{
				Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Continue;
				Game1.menuMgr.transFrame = 1f;
				Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
			}
			break;
		case "restart level":
			active = false;
			Game1.menuMgr.levels[9].active = true;
			break;
		case "end game":
			active = false;
			Game1.menuMgr.levels[8].active = true;
			break;
		}
		base.Click();
	}

	public override void Cancel()
	{
	}
}
