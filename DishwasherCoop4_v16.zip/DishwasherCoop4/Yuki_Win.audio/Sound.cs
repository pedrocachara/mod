using System;
using Microsoft.Xna.Framework.Audio;
using Yuki_Win.chars;
using Yuki_Win.hud;

namespace Yuki_Win.audio;

public class Sound
{
	public enum Category
	{
		FX,
		Vox
	}

	private const string PAIN = "pain";

	private const string DIE = "die";

	private const string FIERCE = "fierce";

	private const string JAB = "jab";

	private const string LAUGH = "laugh";

	private const string GROWL = "growl";

	private const string SCREAM = "scream";

	private const string CATEGORY_DEFAULT = "Default";

	private static AudioEngine engine;

	private static SoundBank sound;

	private static WaveBank wave;

	private static SoundBank voxsnd;

	private static WaveBank voxwav;

	private static SoundBank solosnd;

	private static WaveBank solowav;

	private static float chunkFrame = 0f;

	private static float sprayFrame = 0f;

	private static float crunchFrame = 0f;

	private static float crushFrame = 0f;

	private static float splatFrame = 0f;

	private static float explodeFrame = 0f;

	public static float silenceFrame = 0f;

	public static float larryFrame = 0f;

	public static void UpdateVolume(float vol)
	{
		engine.GetCategory("Default").SetVolume(vol);
	}

	public static void Init()
	{
		engine = new AudioEngine("Content/sfx/sfxproj2.xgs");
		wave = new WaveBank(engine, "Content/sfx/fx.xwb");
		sound = new SoundBank(engine, "Content/sfx/fx.xsb");
		voxwav = new WaveBank(engine, "Content/sfx/vox.xwb");
		voxsnd = new SoundBank(engine, "Content/sfx/vox.xsb");
		solowav = new WaveBank(engine, "Content/sfx/solo.xwb");
		solosnd = new SoundBank(engine, "Content/sfx/solo.xsb");
		Music.Init();
		UpdateVolume((float)flibitPort.CurrentSoundVolume / 10f);
		Music.UpdateVolume((float)flibitPort.CurrentMusicVolume / 10f);
	}

	public static void Dispose()
	{
		if (engine != null)
		{
			engine.GetCategory("Global").Stop(AudioStopOptions.Immediate);
		}
		Music.Dispose();
		if (sound != null)
		{
			sound.Dispose();
		}
		if (voxsnd != null)
		{
			voxsnd.Dispose();
		}
		if (solosnd != null)
		{
			solosnd.Dispose();
		}
		if (wave != null)
		{
			wave.Dispose();
		}
		if (voxwav != null)
		{
			voxwav.Dispose();
		}
		if (solowav != null)
		{
			solowav.Dispose();
		}
		if (engine != null)
		{
			engine.Dispose();
		}
	}

	public static AudioEngine GetEngine()
	{
		return engine;
	}

	public static void PlayVox(int def, string name)
	{
		if (silenceFrame > 0f)
		{
			return;
		}
		CharMeta charMeta = Game1.charMeta[def];
		switch (name)
		{
		case "pain":
			if (charMeta.painsnd != "")
			{
				voxsnd.PlayCue(charMeta.painsnd);
			}
			break;
		case "die":
			if (charMeta.diesnd != "")
			{
				voxsnd.PlayCue(charMeta.diesnd);
			}
			break;
		case "jab":
			if (charMeta.jabsnd != "")
			{
				voxsnd.PlayCue(charMeta.jabsnd);
			}
			break;
		case "fierce":
			if (charMeta.fiercesnd != "")
			{
				voxsnd.PlayCue(charMeta.fiercesnd);
			}
			break;
		case "growl":
			if (charMeta.growlsnd != "")
			{
				voxsnd.PlayCue(charMeta.growlsnd);
			}
			break;
		case "laugh":
			if (charMeta.laughsnd != "")
			{
				voxsnd.PlayCue(charMeta.laughsnd);
			}
			break;
		case "scream":
			if (charMeta.screamsnd != "")
			{
				voxsnd.PlayCue(charMeta.screamsnd);
			}
			break;
		}
	}

	public static void EnterLobby()
	{
		engine.GetCategory("Larry").SetVolume(1f);
	}

	public static void ExitLobby()
	{
		engine.GetCategory("Larry").SetVolume(0.2f);
	}

	public static void PlaySnd(Category category, string name)
	{
		if (silenceFrame > 0f)
		{
			return;
		}
		try
		{
			switch (category)
			{
			case Category.FX:
				sound.PlayCue(name);
				break;
			case Category.Vox:
				voxsnd.PlayCue(name);
				break;
			}
		}
		catch (InvalidOperationException)
		{
			Printf.WriteLine("ERROR: Can't find sound: " + name);
		}
	}

	public static void Update()
	{
		if (larryFrame > 0f)
		{
			larryFrame -= FMan.frameTime;
		}
		if (silenceFrame > 0f)
		{
			silenceFrame -= FMan.frameTime;
		}
		if (chunkFrame > 0f)
		{
			chunkFrame -= FMan.realTime;
		}
		if (crushFrame > 0f)
		{
			crushFrame -= FMan.realTime;
		}
		if (sprayFrame > 0f)
		{
			sprayFrame -= FMan.realTime;
		}
		if (crunchFrame > 0f)
		{
			crunchFrame -= FMan.realTime;
		}
		if (splatFrame > 0f)
		{
			splatFrame -= FMan.realTime;
		}
		if (explodeFrame > 0f)
		{
			explodeFrame -= FMan.frameTime;
		}
		Music.Update();
		engine.Update();
	}

	public static void PlaySplat()
	{
		if (!(silenceFrame > 0f) && splatFrame <= 0f)
		{
			PlaySnd(Category.FX, "splat");
			splatFrame = 0.1f;
		}
	}

	public static void PlayExplode()
	{
		if (!(silenceFrame > 0f) && explodeFrame <= 0f)
		{
			PlaySnd(Category.FX, "explode");
			explodeFrame = 0.1f;
		}
	}

	public static void PlayChunk()
	{
		if (!(silenceFrame > 0f) && chunkFrame <= 0f)
		{
			PlaySnd(Category.FX, "chunk");
			chunkFrame = 0.1f;
		}
	}

	public static void PlayCrunch()
	{
		if (!(silenceFrame > 0f) && crunchFrame <= 0f)
		{
			PlaySnd(Category.FX, "crunch");
			crunchFrame = 0.1f;
		}
	}

	public static void PlaySpray()
	{
		if (!(silenceFrame > 0f) && sprayFrame <= 0f)
		{
			PlaySnd(Category.FX, "spray");
			sprayFrame = 0.2f;
		}
	}

	public static void PlayCrush()
	{
		if (!(silenceFrame > 0f) && crushFrame <= 0f)
		{
			PlaySnd(Category.FX, "crush");
			crushFrame = 0.1f;
		}
	}

	internal static Cue GetSoloCue(string p)
	{
		return solosnd.GetCue(p);
	}

	internal static void PlayLarry()
	{
		larryFrame = 20f;
		PlaySnd(Category.FX, "larry");
	}
}
