using Microsoft.Xna.Framework.Audio;

namespace Yuki_Win.audio;

public class Track
{
	public Cue cue;

	public string name;

	public Track(string name)
	{
		this.name = name;
	}
}
