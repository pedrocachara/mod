using System;
using System.Collections.Generic;
using director;
using Microsoft.Xna.Framework.Audio;
using Yuki_Win.arcade;
using Yuki_Win.debug;
using Yuki_Win.eightbit;
using Yuki_Win.hud;
using Yuki_Win.maps;

namespace Yuki_Win.audio;

public class Music
{
	public const int MUSIC_PULSE = 0;

	public const int MUSIC_JUNGLE = 1;

	public const int MUSIC_ASYLUM = 2;

	public const int MUSIC_BOSS = 3;

	public const int MUSIC_DARK = 4;

	public const int MUSIC_STEADY = 5;

	public const int MUSIC_MONSTER = 6;

	public const int MUSIC_ROCK = 7;

	public const int MUSIC_DOOM = 8;

	public const int MUSIC_CREDITS = 9;

	public const int MUSIC_DISTURBY = 10;

	public const int MUSIC_FINAL = 11;

	public const int MUSIC_NEURO = 12;

	private const string MUSIC = "Music";

	private const string MOANER = "Moaner";

	public static Dictionary<int, Track> library;

	private static WaveBank musicWav;

	private static SoundBank musicSnd;

	public static int track = 4;

	private static float vol;

	public static float settingsVol;

	public static void UpdateVolume(float newVol)
	{
		settingsVol = newVol;
		Sound.GetEngine().GetCategory("Music").SetVolume(vol * newVol);
	}

	public static void Init()
	{
		musicWav = new WaveBank(Sound.GetEngine(), "Content/sfx/music.xwb", 0, 4);
		musicSnd = new SoundBank(Sound.GetEngine(), "Content/sfx/music.xsb");
		library = new Dictionary<int, Track>();
		library.Add(0, new Track("pulse"));
		library.Add(1, new Track("jungle"));
		library.Add(2, new Track("asylum"));
		library.Add(3, new Track("boss"));
		library.Add(4, new Track("dark"));
		library.Add(5, new Track("steady"));
		library.Add(6, new Track("monster"));
		library.Add(7, new Track("rock"));
		library.Add(8, new Track("doom"));
		library.Add(9, new Track("credits"));
		library.Add(10, new Track("disturby"));
		library.Add(11, new Track("final"));
		library.Add(12, new Track("neuro"));
		settingsVol = 1f;
		Sound.GetEngine().Update();
	}

	public static void Dispose()
	{
		if (musicSnd != null)
		{
			musicSnd.Dispose();
		}
		if (musicWav != null)
		{
			musicWav.Dispose();
		}
	}

	public static void Update()
	{
		if (Game1.hud.IsEndLevel())
		{
			track = 0;
		}
		if (GameState.state == GameState.State.Credits)
		{
			track = 9;
		}
		if (GameState.state == GameState.State.Upsell)
		{
			vol = 0f;
			Sound.GetEngine().GetCategory("Music").SetVolume(0f);
			return;
		}
		if (Game1.soloMgr.active)
		{
			vol = 0f;
			Sound.GetEngine().GetCategory("Music").SetVolume(0f);
			return;
		}
		if (DebugManager.videoRecordMode)
		{
			vol = 0f;
			Sound.GetEngine().GetCategory("Music").SetVolume(0f);
			return;
		}
		bool flag = false;
		for (int i = 0; i < library.Count; i++)
		{
			if (i != track)
			{
				Cue cue = library[i].cue;
				if (cue != null && cue.IsPlaying && !cue.IsPaused)
				{
					flag = true;
				}
			}
		}
		if (Game1.gameMap.moaner)
		{
			Sound.GetEngine().GetCategory("Moaner").SetVolume(1f * settingsVol);
		}
		else
		{
			Sound.GetEngine().GetCategory("Moaner").SetVolume(0f);
		}
		if (flag)
		{
			vol -= FMan.frameTime * 3f;
			if (Game1.gameMap.theme.theme == Themes.ThemeType.Final && GameState.state == GameState.State.Playing && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off)
			{
				vol = -0.1f;
			}
			if (vol < 0f)
			{
				vol = 0f;
				flag = false;
				for (int j = 0; j < library.Count; j++)
				{
					Cue cue2 = library[j].cue;
					if (cue2 != null && cue2.IsPlaying)
					{
						cue2.Pause();
					}
				}
				if (library[track].cue != null)
				{
					switch (track)
					{
					case 3:
					case 5:
					case 7:
					case 8:
					case 9:
					case 11:
						try
						{
							if (track == 8 && Game1.levelMgr.currentTrack != 3)
							{
								if (library[track].cue.IsPaused)
								{
									library[track].cue.Resume();
								}
							}
							else if (library[track].cue.IsPaused)
							{
								library[track].cue.Stop(AudioStopOptions.Immediate);
							}
							else if (!library[track].cue.IsStopping && library[track].cue.IsStopped)
							{
								library[track].cue.Play();
							}
						}
						catch (Exception ex)
						{
							Printf.WriteLine(ex.StackTrace);
						}
						break;
					default:
						if (library[track].cue.IsPaused)
						{
							library[track].cue.Resume();
						}
						break;
					}
				}
				else
				{
					try
					{
						library[track].cue = musicSnd.GetCue(library[track].name);
						library[track].cue.Play();
					}
					catch (Exception ex2)
					{
						Printf.WriteLine(ex2.StackTrace);
					}
				}
			}
			Sound.GetEngine().GetCategory("Music").SetVolume(vol * settingsVol);
			return;
		}
		if (GameState.state == GameState.State.Playing && ((Game1.gameMap.theme.theme == Themes.ThemeType.EliteDarkQuiet && !EightBitGame.enabled) || Game1.gameMap.theme.quiet || Game1.gameMap.yukiDeathFocus || Game1.gameMap.theme.theme == Themes.ThemeType.Judge))
		{
			vol = 0.01f;
			Sound.GetEngine().GetCategory("Music").SetVolume(vol * settingsVol);
		}
		else if (Game1.gameMap.musicRamp)
		{
			float num = (ScrollManager.scroll.X - (float)Game1.gameMap.musicRampMin) / (float)(Game1.gameMap.musicRampMax - Game1.gameMap.musicRampMin);
			if (num < 0f)
			{
				num = 0f;
			}
			if (num > 1f)
			{
				num = 1f;
			}
			vol = num;
			Sound.GetEngine().GetCategory("Music").SetVolume(vol * settingsVol);
		}
		else
		{
			float num2 = 1f;
			if (Sound.larryFrame > 0f)
			{
				float num3 = Sound.larryFrame / 2f;
				if (num3 > 9f)
				{
					num3 = 10f - Sound.larryFrame / 2f;
				}
				if (num3 > 1f)
				{
					num3 = 1f;
				}
				if (num3 < 0f)
				{
					num3 = 0f;
				}
				num2 = 1f - num3 * 0.8f;
			}
			if (vol < num2)
			{
				vol += FMan.frameTime * 3f;
				if (vol > num2)
				{
					vol = num2;
				}
				if (track == 3)
				{
					vol = 1f;
				}
				Sound.GetEngine().GetCategory("Music").SetVolume(vol * settingsVol);
			}
		}
		if (library[track].cue == null)
		{
			try
			{
				library[track].cue = musicSnd.GetCue(library[track].name);
				library[track].cue.Play();
				return;
			}
			catch (Exception ex3)
			{
				Printf.WriteLine(ex3.StackTrace);
				return;
			}
		}
		if (library[track].cue.IsPaused)
		{
			library[track].cue.Resume();
		}
		else if (!library[track].cue.IsPlaying && !library[track].cue.IsPreparing)
		{
			try
			{
				library[track].cue = musicSnd.GetCue(library[track].name);
				library[track].cue.Play();
			}
			catch (Exception ex4)
			{
				Printf.WriteLine(ex4.StackTrace);
			}
		}
	}
}
