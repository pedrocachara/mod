using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.refract;

public class BlastGoo : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.rDir = Rand.GetRandomFloat(-60f, 60f);
		p.frame = 0.2f;
		p.flags = Rand.GetRandomInt(0, 4);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(768, 256, 128, 128), new Color(0f, 0f, 0.5f, p.frame * 0.1f), p.rotation, new Vector2(64f, 64f), (0.25f - p.frame) * p.size * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
	}
}
