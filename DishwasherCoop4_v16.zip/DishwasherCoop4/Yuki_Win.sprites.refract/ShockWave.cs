using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.refract;

public class ShockWave : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.frame = 0.1f;
		p.flags = Rand.GetRandomInt(0, 4);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(768, 128, 64, 64), new Color(0f, 0f, 1f, p.frame * p.size * 0.05f), 0f, new Vector2(32f, 32f), (0.11f - p.frame) * p.size * ScrollManager.cannedDepth[0] * new Vector2(1f, 0.7f), SpriteEffects.None, 1f);
	}
}
