using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.refract;

internal class YukiWarpRefract : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.flags = Rand.GetRandomInt(0, 3);
		p.frame = Rand.GetRandomFloat(0.1f, 0.2f);
		p.size = Rand.GetRandomFloat(1f, 1.5f);
		p.thresh = false;
		p.rotation = Trig.GetAngle(default, traj) + Rand.GetRandomFloat(-0.2f, 0.2f);
		p.traj = Rand.GetRandomVec2(-50f, 50f, -50f, 50f);
		p.rDir = Rand.GetRandomFloat(-1f, 1f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite par, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = par.frame * 2f;
		if (num > 0.2f)
		{
			num = 0.2f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(par.loc, 1f) * (par.thresh ? 0.25f : 1f), new Rectangle(128, 32 * par.flags, 128, 32), new Color(0f, 0f, 0.125f, num), par.rotation, new Vector2(32f, 32f), par.size * ScrollManager.cannedDepth[0] * new Vector2(1f, 0.5f), SpriteEffects.None, 1f);
	}
}
