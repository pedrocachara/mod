using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.refract;

public class Zap : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.rDir = Rand.GetRandomFloat(-5f, 5f);
		p.frame = 0.4f;
		p.flags = Rand.GetRandomInt(0, 4);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float alpha = p.frame * 0.05f;
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(576 + p.flags * 64, 192, 64, 64), new Color(0f, 0f, 1f, alpha), p.rotation, new Vector2(32f, 32f), (1.6f - p.frame) * p.size * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
	}
}
