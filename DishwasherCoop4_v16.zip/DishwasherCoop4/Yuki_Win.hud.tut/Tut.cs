using System.Text;

namespace Yuki_Win.hud.tut;

public class Tut
{
	public StringBuilder[] msg;

	public Tut(string[] msg)
	{
		this.msg = new StringBuilder[msg.Length];
		for (int i = 0; i < this.msg.Length; i++)
		{
			this.msg[i] = new StringBuilder(msg[i]);
		}
	}
}
