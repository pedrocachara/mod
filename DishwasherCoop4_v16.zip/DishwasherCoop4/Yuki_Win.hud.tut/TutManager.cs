using System.Collections.Generic;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;

namespace Yuki_Win.hud.tut;

public class TutManager
{
	public Dictionary<string, Tut> tuts;

	public bool active;

	public float bufferFrame;

	public float alpha;

	private string curTut;

	public bool IsGoing()
	{
		if (alpha > 0f)
		{
			return true;
		}
		if (active)
		{
			return true;
		}
		return false;
	}

	public void Update()
	{
		if (active)
		{
			bufferFrame -= FMan.realTime;
			if (alpha < 1f)
			{
				alpha += FMan.frameTime * 3f;
			}
			if (alpha > 1f)
			{
				alpha = 1f;
			}
			if (!(bufferFrame <= 0f))
			{
				return;
			}
			for (int i = 0; i < 4; i++)
			{
				if (Game1.character[i].exists && Game1.character[i].charKeys.idx > -1 && Game1.character[i].charKeys.keyJump)
				{
					Sound.PlaySnd(Sound.Category.FX, "block");
					active = false;
				}
			}
		}
		else
		{
			if (alpha > 0f)
			{
				alpha -= FMan.frameTime * 3f;
			}
			if (alpha < 0f)
			{
				alpha = 0f;
			}
		}
	}

	public void DoTut(string stut)
	{
		if (!Game1.netSession.IsHost() && !Game1.netSession.IsClient() && tuts.ContainsKey(stut) && !MainPlayer.GetUberFlag(stut))
		{
			active = true;
			curTut = stut;
			bufferFrame = 3f;
			MainPlayer.SetUberFlag(stut);
		}
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		if (alpha <= 0f)
		{
			return;
		}
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		float num = 34f;
		Tut tut = tuts[curTut];
		float num2 = ScrollManager.screenSize.Y / 2f - (float)tut.msg.Length * num * 0.5f;
		int num3 = (int)((float)tut.msg.Length * num * 1.3f) + 40;
		sprite.Draw(Game1.spritesTex, new Rectangle((int)(ScrollManager.screenSize.X / 2f) - 440 + (int)vector.X, (int)(ScrollManager.screenSize.Y / 2f) - num3 / 2, 880, num3), new Rectangle(640, 384, 256, 60), new Color(0f, 0f, 0f, alpha * 0.5f), 0f, default, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Rectangle((int)(ScrollManager.screenSize.X / 2f) - 440 + (int)vector.X, (int)(ScrollManager.screenSize.Y / 2f) - num3 / 2, 880, num3), new Rectangle(640, 384, 256, 60), new Color(0f, 0f, 0f, alpha * 0.5f), 0f, default, SpriteEffects.FlipHorizontally, 1f);
		sprite.Draw(Game1.spritesTex, new Rectangle((int)(ScrollManager.screenSize.X / 2f) - 440 + (int)vector.X, (int)(ScrollManager.screenSize.Y / 2f) - num3 / 2, 880, num3), new Rectangle(640, 384, 256, 60), new Color(0f, 0f, 0f, alpha * 0.5f), 0f, default, SpriteEffects.FlipVertically, 1f);
		for (int i = 0; i < tut.msg.Length; i++)
		{
			Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, num2) + vector, tut.msg[i], new Color(1f, 1f, 1f, alpha), 0.82f, 1);
			num2 += num;
		}
		if (alpha > 0.8f)
		{
			if (bufferFrame <= 0f)
			{
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Close, 0, 1f);
			}
			else
			{
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.Waiting, 0, 1f);
			}
		}
	}

	public TutManager()
	{
		tuts = new Dictionary<string, Tut>();
		tuts.Add("move", new Tut(new string[2]
		{
			YukiText.moveTut1,
			YukiText.moveTut2
		}));
		tuts.Add("attack", new Tut(new string[4]
		{
			YukiText.attackTut1,
			YukiText.attackTut2,
			YukiText.attackTut3,
			YukiText.attackTut4
		}));
		tuts.Add("stunned", new Tut(new string[3]
		{
			YukiText.stunnedTut1,
			YukiText.stunnedTut2,
			YukiText.stunnedTut3
		}));
		tuts.Add("crash", new Tut(new string[14]
		{
			"your c.r.a.s.h. gauges fills up when you", "dispatch enemies creatively.  c.r.a.s.h. stands for:", "", "  [c] chop!", "  [e] rend!", "  [a] arsenal! ", "  [z] slash! ", "  [h] hammer! ", "", "you can't use all of the c.r.a.s.h. kill techniques",
			"yet, but will be able to when you get new weapons!", "", "the more c.r.a.s.h. gauges you have full, the", "more momentum you'll have in battle!"
		}));
		tuts.Add("crash2", new Tut(new string[8] { "right now you can pull off:", "", "[c] chop kills by using a [B] finisher,", "[z] slash kills with a [X] finisher or", "[h] hammer kills with a mid-air [B] finisher.", "", "try to vary up your kills to improve your", "c.r.a.s.h. momentum!" }));
		tuts.Add("warp", new Tut(new string[5]
		{
			YukiText.warpTut1,
			YukiText.warpTut2,
			YukiText.warpTut3,
			YukiText.warpTut4,
			YukiText.warpTut5
		}));
		tuts.Add("chainsaw", new Tut(new string[6]
		{
			YukiText.chainsawTut1,
			YukiText.chainsawTut2,
			YukiText.chainsawTut3,
			YukiText.chainsawTut4,
			YukiText.chainsawTut5,
			YukiText.chainsawTut6
		}));
		tuts.Add("gun", new Tut(new string[5]
		{
			YukiText.gunTut1,
			YukiText.gunTut2,
			YukiText.gunTut3,
			YukiText.gunTut4,
			YukiText.gunTut5
		}));
		tuts.Add("cloud", new Tut(new string[10]
		{
			YukiText.cloudTut1,
			YukiText.cloudTut2,
			YukiText.cloudTut3,
			YukiText.cloudTut4,
			YukiText.cloudTut5,
			YukiText.cloudTut6,
			YukiText.cloudTut7,
			YukiText.cloudTut8,
			YukiText.cloudTut9,
			YukiText.cloudTut10
		}));
		tuts.Add("hammer", new Tut(new string[12]
		{
			YukiText.hammerTut1,
			YukiText.hammerTut2,
			YukiText.hammerTut3,
			YukiText.hammerTut4,
			YukiText.hammerTut5,
			YukiText.hammerTut6,
			YukiText.hammerTut7,
			YukiText.hammerTut8,
			YukiText.hammerTut9,
			YukiText.hammerTut10,
			YukiText.hammerTut11,
			YukiText.hammerTut12
		}));
		tuts.Add("kama", new Tut(new string[12]
		{
			YukiText.kamaTut1,
			YukiText.kamaTut2,
			YukiText.kamaTut3,
			YukiText.kamaTut4,
			YukiText.kamaTut5,
			YukiText.kamaTut6,
			YukiText.kamaTut7,
			YukiText.kamaTut8,
			YukiText.kamaTut9,
			YukiText.kamaTut10,
			YukiText.kamaTut11,
			YukiText.kamaTut12
		}));
		tuts.Add("scissor", new Tut(new string[6]
		{
			YukiText.scissorTut1,
			YukiText.scissorTut2,
			YukiText.scissorTut3,
			YukiText.scissorTut4,
			YukiText.scissorTut5,
			YukiText.scissorTut6
		}));
		tuts.Add("uzi", new Tut(new string[5]
		{
			YukiText.uziTut1,
			YukiText.uziTut2,
			YukiText.uziTut3,
			YukiText.uziTut4,
			YukiText.uziTut5
		}));
		tuts.Add("electricdishmagic", new Tut(new string[8]
		{
			YukiText.electricDishMagicTut1,
			YukiText.electricDishMagicTut2,
			YukiText.electricDishMagicTut3,
			YukiText.electricDishMagicTut4,
			YukiText.electricDishMagicTut5,
			YukiText.electricDishMagicTut6,
			YukiText.electricDishMagicTut7,
			YukiText.electricDishMagicTut8
		}));
		tuts.Add("electricbloodmagic", new Tut(new string[8]
		{
			YukiText.electricBloodMagicTut1,
			YukiText.electricBloodMagicTut2,
			YukiText.electricBloodMagicTut3,
			YukiText.electricBloodMagicTut4,
			YukiText.electricBloodMagicTut5,
			YukiText.electricBloodMagicTut6,
			YukiText.electricBloodMagicTut7,
			YukiText.electricBloodMagicTut8
		}));
		tuts.Add("steeldishmagic", new Tut(new string[8]
		{
			YukiText.steelDishMagicTut1,
			YukiText.steelDishMagicTut2,
			YukiText.steelDishMagicTut3,
			YukiText.steelDishMagicTut4,
			YukiText.steelDishMagicTut5,
			YukiText.steelDishMagicTut6,
			YukiText.steelDishMagicTut7,
			YukiText.steelDishMagicTut8
		}));
		tuts.Add("steelbloodmagic", new Tut(new string[8]
		{
			YukiText.steelBloodMagicTut1,
			YukiText.steelBloodMagicTut2,
			YukiText.steelBloodMagicTut3,
			YukiText.steelBloodMagicTut4,
			YukiText.steelBloodMagicTut5,
			YukiText.steelBloodMagicTut6,
			YukiText.steelBloodMagicTut7,
			YukiText.steelBloodMagicTut8
		}));
		tuts.Add("painkiller", new Tut(new string[3]
		{
			YukiText.painKillerTut1,
			YukiText.painKillerTut2,
			YukiText.painKillerTut3
		}));
		tuts.Add("toaster", new Tut(new string[3]
		{
			YukiText.toasterTut1,
			YukiText.toasterTut2,
			YukiText.toasterTut3
		}));
		tuts.Add("devouringdishmagic", new Tut(new string[8]
		{
			YukiText.devouringDishMagicTut1,
			YukiText.devouringDishMagicTut2,
			YukiText.devouringDishMagicTut3,
			YukiText.devouringDishMagicTut4,
			YukiText.devouringDishMagicTut5,
			YukiText.devouringDishMagicTut6,
			YukiText.devouringDishMagicTut7,
			YukiText.devouringDishMagicTut8
		}));
		tuts.Add("devouringbloodmagic", new Tut(new string[8]
		{
			YukiText.devouringBloodMagicTut1,
			YukiText.devouringBloodMagicTut2,
			YukiText.devouringBloodMagicTut3,
			YukiText.devouringBloodMagicTut4,
			YukiText.devouringBloodMagicTut5,
			YukiText.devouringBloodMagicTut6,
			YukiText.devouringBloodMagicTut7,
			YukiText.devouringBloodMagicTut8
		}));
		tuts.Add("holydishmagic", new Tut(new string[8]
		{
			YukiText.holyDishMagicTut1,
			YukiText.holyDishMagicTut2,
			YukiText.holyDishMagicTut3,
			YukiText.holyDishMagicTut4,
			YukiText.holyDishMagicTut5,
			YukiText.holyDishMagicTut6,
			YukiText.holyDishMagicTut7,
			YukiText.holyDishMagicTut8
		}));
		tuts.Add("holybloodmagic", new Tut(new string[8]
		{
			YukiText.holyBloodMagicTut1,
			YukiText.holyBloodMagicTut2,
			YukiText.holyBloodMagicTut3,
			YukiText.holyBloodMagicTut4,
			YukiText.holyBloodMagicTut5,
			YukiText.holyBloodMagicTut6,
			YukiText.holyBloodMagicTut7,
			YukiText.holyBloodMagicTut8
		}));
		tuts.Add("shotty", new Tut(new string[3]
		{
			YukiText.shottyTut1,
			YukiText.shottyTut2,
			YukiText.shottyTut3
		}));
		tuts.Add("shottyarm", new Tut(new string[3]
		{
			YukiText.shottyArmTut1,
			YukiText.shottyArmTut2,
			YukiText.shottyArmTut3
		}));
		tuts.Add("cloudy", new Tut(new string[5]
		{
			YukiText.cloudyTut1,
			YukiText.cloudyTut2,
			YukiText.cloudyTut3,
			YukiText.cloudyTut4,
			YukiText.cloudyTut5
		}));
		tuts.Add("hammery", new Tut(new string[5]
		{
			YukiText.hammeryTut1,
			YukiText.hammeryTut2,
			YukiText.hammeryTut3,
			YukiText.hammeryTut4,
			YukiText.hammeryTut5
		}));
		tuts.Add("coopy", new Tut(new string[8]
		{
			YukiText.coopyTut1,
			YukiText.coopyTut2,
			YukiText.coopyTut3,
			YukiText.coopyTut4,
			YukiText.coopyTut5,
			YukiText.coopyTut6,
			YukiText.coopyTut7,
			YukiText.coopyTut8
		}));
		tuts.Add("shop", new Tut(new string[3]
		{
			YukiText.shopTut1,
			YukiText.shopTut2,
			YukiText.shopTut3
		}));
	}
}
