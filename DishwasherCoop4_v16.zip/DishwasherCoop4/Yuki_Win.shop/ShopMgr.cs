using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.hud;
using Yuki_Win.player;

namespace Yuki_Win.shop;

public class ShopMgr
{
	public Shop[] shop;

	public ShopMgr()
	{
		shop = new Shop[4];
		for (int i = 0; i < shop.Length; i++)
		{
			shop[i] = new Shop(i);
		}
	}

	public void Update()
	{
		for (int i = 0; i < shop.Length; i++)
		{
			shop[i].Update();
		}
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		for (int i = 0; i < shop.Length; i++)
		{
			if (shop[i].alpha > 0f)
			{
				shop[i].Draw(sprite, threedee);
			}
		}
		for (int j = 0; j < shop.Length; j++)
		{
			if (shop[j].alpha > 0.9f)
			{
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.ShopBuy, 1, 1f);
				BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.B, BottomRightMessage.Msg.ShopDone, 0, 1f);
				break;
			}
		}
	}

	public bool IsActive()
	{
		for (int i = 0; i < shop.Length; i++)
		{
			if (shop[i].alpha > 0f)
			{
				return true;
			}
		}
		return false;
	}

	public void InitShop(int i)
	{
		Shop shop = this.shop[i];
		shop.Reset();
		shop.alpha = 0f;
		shop.active = true;
		bool flag = false;
		if (Game1.character[i].GetMeta().isDish)
		{
			flag = true;
		}
		shop.AddItem(InvCatalog.InvItemName.MoonBread);
		shop.AddItem(InvCatalog.InvItemName.MoonFish);
		shop.AddItem(InvCatalog.InvItemName.SquidChips);
		shop.AddItem(InvCatalog.InvItemName.KittenVitamins);
		GamePlayer gamePlayer = Game1.gamePlayerMgr.gamePlayer[i];
		if (flag)
		{
			switch (gamePlayer.upgrades[9].lev)
			{
			case 1:
				shop.AddItem(InvCatalog.InvItemName.UpgradeShiftblade);
				break;
			case 2:
				shop.AddItem(InvCatalog.InvItemName.UpgradeShiftblade2);
				break;
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestDishPhase >= 1)
			{
				switch (gamePlayer.upgrades[10].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeCleavers);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeCleavers2);
					break;
				}
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestDishPhase >= 2)
			{
				switch (gamePlayer.upgrades[11].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeViolenceHammer);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeViolenceHammer2);
					break;
				}
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestDishPhase >= 5)
			{
				switch (gamePlayer.upgrades[12].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeGuillotine);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeGuillotine2);
					break;
				}
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestDishPhase >= 7)
			{
				switch (gamePlayer.upgrades[13].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeDekkentozter);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeDekkentozter2);
					break;
				}
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestDishPhase >= 3)
			{
				switch (gamePlayer.upgrades[14].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeUzi);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeUzi2);
					break;
				}
			}
		}
		else
		{
			switch (gamePlayer.upgrades[2].lev)
			{
			case 1:
				shop.AddItem(InvCatalog.InvItemName.UpgradeConviction);
				break;
			case 2:
				shop.AddItem(InvCatalog.InvItemName.UpgradeConviction2);
				break;
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestYukiPhase >= 7)
			{
				switch (gamePlayer.upgrades[4].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeCloudSword);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeCloudSword2);
					break;
				}
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestYukiPhase >= 10)
			{
				switch (gamePlayer.upgrades[3].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeKamakazi);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeKamakazi2);
					break;
				}
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestYukiPhase >= 12)
			{
				switch (gamePlayer.upgrades[5].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradePainkiller);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradePainkiller2);
					break;
				}
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestYukiPhase >= 6)
			{
				switch (gamePlayer.upgrades[8].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeChainsaw);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeChainsaw2);
					break;
				}
			}
			if (Game1.gamePlayerMgr.GamePlayer(i).highestYukiPhase >= 8)
			{
				switch (gamePlayer.upgrades[6].lev)
				{
				case 1:
					shop.AddItem(InvCatalog.InvItemName.UpgradeGunArm);
					break;
				case 2:
					shop.AddItem(InvCatalog.InvItemName.UpgradeGunArm2);
					break;
				}
			}
		}
		switch (gamePlayer.upgrades[0].lev)
		{
		case 1:
			shop.AddItem(InvCatalog.InvItemName.UpgradeHealth);
			break;
		case 2:
			shop.AddItem(InvCatalog.InvItemName.UpgradeHealth2);
			break;
		case 3:
			shop.AddItem(InvCatalog.InvItemName.UpgradeHealth3);
			break;
		case 4:
			shop.AddItem(InvCatalog.InvItemName.UpgradeHealth4);
			break;
		}
		bool flag2 = false;
		if (flag)
		{
			if (Game1.gamePlayerMgr.GamePlayer(i).highestDishPhase >= 4)
			{
				flag2 = true;
			}
		}
		else if (Game1.gamePlayerMgr.GamePlayer(i).highestYukiPhase >= 9)
		{
			flag2 = true;
		}
		if (flag2)
		{
			switch (gamePlayer.upgrades[1].lev)
			{
			case 1:
				shop.AddItem(InvCatalog.InvItemName.UpgradeSkulls);
				break;
			case 2:
				shop.AddItem(InvCatalog.InvItemName.UpgradeSkulls2);
				break;
			case 3:
				shop.AddItem(InvCatalog.InvItemName.UpgradeSkulls3);
				break;
			case 4:
				shop.AddItem(InvCatalog.InvItemName.UpgradeSkulls4);
				break;
			}
		}
	}

	internal void Clear()
	{
		for (int i = 0; i < shop.Length; i++)
		{
			shop[i].active = false;
			shop[i].alpha = 0f;
		}
	}
}
