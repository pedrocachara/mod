using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.player;
using Yuki_Win.player.inventory;

namespace Yuki_Win.shop;

public class Shop
{
	public int cursor;

	public int scroll;

	public InvCatalog.InvItemName[] items;

	private float[] itemAlpha;

	public int totalItems;

	public Vector2 loc;

	public float frame;

	public bool active;

	public float alpha;

	public int ID;

	private int lines = 7;

	private bool pKeyUp;

	private bool pKeyDown;

	private bool DoUpgrade(InvCatalog.InvItemName upgrade)
	{
		bool flag = false;
		GamePlayer gamePlayer = Game1.gamePlayerMgr.gamePlayer[ID];
		switch (upgrade)
		{
		case InvCatalog.InvItemName.UpgradeShiftblade:
		case InvCatalog.InvItemName.UpgradeShiftblade2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Shiftblade);
			break;
		case InvCatalog.InvItemName.UpgradeCleavers:
		case InvCatalog.InvItemName.UpgradeCleavers2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Cleavers);
			break;
		case InvCatalog.InvItemName.UpgradeViolenceHammer:
		case InvCatalog.InvItemName.UpgradeViolenceHammer2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Hammer);
			break;
		case InvCatalog.InvItemName.UpgradeGuillotine:
		case InvCatalog.InvItemName.UpgradeGuillotine2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Guillotine);
			break;
		case InvCatalog.InvItemName.UpgradeDekkentozter:
		case InvCatalog.InvItemName.UpgradeDekkentozter2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Dekkentozter);
			break;
		case InvCatalog.InvItemName.UpgradeUzi:
		case InvCatalog.InvItemName.UpgradeUzi2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Uzi);
			break;
		case InvCatalog.InvItemName.UpgradeGunArm:
		case InvCatalog.InvItemName.UpgradeGunArm2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Gunarm);
			break;
		case InvCatalog.InvItemName.UpgradeChainsaw:
		case InvCatalog.InvItemName.UpgradeChainsaw2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Chainsaw);
			break;
		case InvCatalog.InvItemName.UpgradeConviction:
		case InvCatalog.InvItemName.UpgradeConviction2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Murderblade);
			break;
		case InvCatalog.InvItemName.UpgradeKamakazi:
		case InvCatalog.InvItemName.UpgradeKamakazi2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Kamakazi);
			break;
		case InvCatalog.InvItemName.UpgradeCloudSword:
		case InvCatalog.InvItemName.UpgradeCloudSword2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Cloud);
			break;
		case InvCatalog.InvItemName.UpgradePainkiller:
		case InvCatalog.InvItemName.UpgradePainkiller2:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Painkiller);
			break;
		case InvCatalog.InvItemName.UpgradeHealth:
		case InvCatalog.InvItemName.UpgradeHealth2:
		case InvCatalog.InvItemName.UpgradeHealth3:
		case InvCatalog.InvItemName.UpgradeHealth4:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Health);
			if (flag)
			{
				Game1.character[ID].SetUpgradeHealth(fill: true);
			}
			break;
		case InvCatalog.InvItemName.UpgradeSkulls:
		case InvCatalog.InvItemName.UpgradeSkulls2:
		case InvCatalog.InvItemName.UpgradeSkulls3:
		case InvCatalog.InvItemName.UpgradeSkulls4:
			flag = gamePlayer.UpgradeLev(GamePlayer.UpName.Magic);
			if (flag)
			{
				Game1.character[ID].SetUpgradeMagic(fill: true);
			}
			break;
		}
		if (flag)
		{
			Sound.PlaySnd(Sound.Category.FX, "bell");
			int num = cursor;
			int num2 = scroll;
			Game1.hud.shopMgr.InitShop(ID);
			alpha = 1f;
			cursor = num;
			scroll = num2;
			if (cursor >= totalItems)
			{
				cursor = totalItems - 1;
			}
		}
		return flag;
	}

	public void Update()
	{
		lines = 5;
		if (active)
		{
			if (alpha < 1f)
			{
				alpha += FMan.frameTime * 4f;
			}
			if (alpha >= 1f)
			{
				alpha = 1f;
			}
			if (alpha >= 1f)
			{
				Game1.character[ID].charKeys.Update(Game1.character[ID].ai, Game1.character, Game1.character[ID]);
				CharKeys charKeys = Game1.character[ID].charKeys;
				bool flag = charKeys.keyUp || charKeys.keyDUp;
				bool flag2 = charKeys.keyDown || charKeys.keyDDown;
				if (flag && !pKeyUp)
				{
					Sound.PlaySnd(Sound.Category.FX, "swing");
					cursor--;
					if (cursor < 0)
					{
						cursor = totalItems - 1;
					}
				}
				if (flag2 && !pKeyDown)
				{
					Sound.PlaySnd(Sound.Category.FX, "throw");
					cursor = (cursor + 1) % totalItems;
				}
				if (cursor < scroll)
				{
					scroll--;
				}
				if (cursor >= scroll + lines)
				{
					scroll++;
				}
				if (charKeys.keyGrab)
				{
					active = false;
				}
				if (charKeys.keyJump)
				{
					bool flag3 = true;
					if (Game1.invCatalog.catalog[(int)items[cursor]].max > 0 && Game1.hud.invMgr.inv[ID].GetItemCount(items[cursor]) >= Game1.invCatalog.catalog[(int)items[cursor]].max)
					{
						flag3 = false;
					}
					if (Game1.gamePlayerMgr.gamePlayer[ID].picks < Game1.invCatalog.catalog[(int)items[cursor]].pickValue || Game1.gamePlayerMgr.gamePlayer[ID].gold < (float)Game1.invCatalog.catalog[(int)items[cursor]].value)
					{
						flag3 = false;
					}
					if (flag3)
					{
						Sound.PlaySnd(Sound.Category.FX, "slash1");
						Game1.gamePlayerMgr.gamePlayer[ID].picks -= Game1.invCatalog.catalog[(int)items[cursor]].pickValue;
						Game1.gamePlayerMgr.gamePlayer[ID].gold -= Game1.invCatalog.catalog[(int)items[cursor]].value;
						switch (Game1.invCatalog.catalog[(int)items[cursor]].section)
						{
						case Inv.InvTabSection.Food:
						case Inv.InvTabSection.Beads:
							Game1.hud.invMgr.AddItem(ID, items[cursor], 1);
							break;
						case Inv.InvTabSection.Upgrade:
							DoUpgrade(items[cursor]);
							break;
						}
						for (int i = 0; i < Game1.character.Length; i++)
						{
							if (Game1.character[i].exists && Game1.character[i].GetMeta().isShop)
							{
								Game1.character[i].charAnim.SetAnim("shop", Game1.character[i].charUpdate, overRide: true);
								break;
							}
						}
					}
					else
					{
						Sound.PlaySnd(Sound.Category.FX, "thud");
					}
				}
				pKeyDown = flag2;
				pKeyUp = flag;
			}
		}
		else
		{
			alpha -= FMan.frameTime * 4f;
			if (alpha < 0f)
			{
				alpha = 0f;
			}
		}
		if (!(alpha > 0f))
		{
			return;
		}
		frame += FMan.frameTime;
		if (frame > 12.56f)
		{
			frame -= 12.56f;
		}
		for (int j = 0; j < Game1.character.Length; j++)
		{
			if (Game1.character[j].exists && Game1.character[j].GetMeta().isShop)
			{
				Vector2 vector = Game1.character[j].charUpdate.loc;
				vector += new Vector2(((float)Game1.character[j].charUpdate.face - 0.5f) * 150f, 0f);
				Game1.character[ID].charUpdate.traj.X = (vector - Game1.character[ID].charUpdate.loc).X * 10f;
				Game1.character[ID].charUpdate.face = 1 - Game1.character[j].charUpdate.face;
			}
		}
		for (int k = 0; k < totalItems; k++)
		{
			if (k == cursor)
			{
				if (itemAlpha[k] < 1f)
				{
					itemAlpha[k] += FMan.frameTime * 5f;
					if (itemAlpha[k] > 1f)
					{
						itemAlpha[k] = 1f;
					}
				}
			}
			else if (itemAlpha[k] > 0f)
			{
				itemAlpha[k] -= FMan.frameTime * 5f;
				if (itemAlpha[k] < 0f)
				{
					itemAlpha[k] = 0f;
				}
			}
		}
	}

	public Shop(int ID)
	{
		items = new InvCatalog.InvItemName[30];
		itemAlpha = new float[30];
		totalItems = 0;
		this.ID = ID;
	}

	public void Reset()
	{
		totalItems = 0;
		scroll = 0;
	}

	public void AddItem(InvCatalog.InvItemName name)
	{
		items[totalItems] = name;
		totalItems++;
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		float num = 271f * alpha;
		float num2 = 211f * alpha;
		loc = new Vector2(380f, 420f);
		if (ID == 1)
		{
			loc.X += (640f - loc.X) * 2f;
		}
		switch (threedee)
		{
		case 0:
			loc.X++;
			break;
		case 1:
			loc.X--;
			break;
		}
		Inv.DrawRect(sprite, new Rectangle((int)(loc.X - num), (int)(loc.Y - num2), (int)(num * 2f), (int)(num2 * 2f)), alpha, frame);
		if (!(alpha >= 1f))
		{
			return;
		}
		Vector2 position = loc + new Vector2(-250f, 170f);
		sprite.Draw(Game1.spritesTex, position, new Rectangle(640, 576, 32, 32), new Color(1f, 1f, 1f, 1f), 0f, default, 1f, SpriteEffects.None, 1f);
		Text.DrawScore((int)position.X + 30, (int)position.Y, (long)Game1.gamePlayerMgr.gamePlayer[ID].gold, new Color(1f, 1f, 1f, 1f), sprite, flip: true, 0f, 0.8f);
		for (int i = 0; i < 2; i++)
		{
			sprite.Draw(Game1.spritesTex, loc + new Vector2(0f, 157f) + new Vector2(80f - (float)i * 160f, 0f), new Rectangle(128, 32 * i, 128, 32), new Color(1f, 1f, 1f, 0.4f), 0f, new Vector2(64f, 16f), new Vector2(2f, 0.5f), SpriteEffects.None, 1f);
		}
		int num3 = 0;
		for (int j = scroll; j < scroll + lines; j++)
		{
			if (j < totalItems)
			{
				Text.DrawCText(sprite, loc + new Vector2(0f - num + 50f + itemAlpha[j] * 10f, -10f + (float)num3 * 30f), Game1.invCatalog.catalog[(int)items[j]].name, new Color(1f, 1f - itemAlpha[j], 1f - itemAlpha[j], 1f), 0.75f, 0);
				sprite.Draw(Game1.itemsTex, loc + new Vector2(0f - num + 20f + itemAlpha[j] * 10f, -10f + (float)num3 * 30f), Game1.invCatalog.GetInvitemRect(items[j]), new Color(1f, 1f, 1f, 1f), 0f, default, 0.125f, SpriteEffects.None, 1f);
				if (Game1.invCatalog.catalog[(int)items[j]].section == Inv.InvTabSection.Food)
				{
					int itemCount = Game1.hud.invMgr.inv[ID].GetItemCount(items[j]);
					Text.DrawScore((int)(loc.X + 50f), (int)(loc.Y - 10f + (float)num3 * 30f), itemCount, new Color(1f, 1f - itemAlpha[j], 1f - itemAlpha[j], 1f), sprite, flip: true, 0f, 0.75f);
					Text.DrawCText(sprite, loc + new Vector2(74f, -10f + (float)num3 * 30f), new StringBuilder("/"), new Color(1f, 1f - itemAlpha[j], 1f - itemAlpha[j], 1f), 0.75f, 1);
					Text.DrawScore((int)(loc.X + 90f), (int)(loc.Y - 10f + (float)num3 * 30f), Game1.invCatalog.catalog[(int)items[j]].max, new Color(1f, 1f - itemAlpha[j], 1f - itemAlpha[j], 1f), sprite, flip: true, 0f, 0.75f);
				}
				if (itemAlpha[j] > 0f)
				{
					sprite.Draw(Game1.itemsTex, loc + new Vector2(0f, -160f), Game1.invCatalog.GetInvitemRect(items[j]), new Color(1f, 1f, 1f, itemAlpha[j]), 0f, new Vector2(64f, 64f) * 2f, 1.6f * (0.5f + 0.5f * itemAlpha[j]) / 2f, SpriteEffects.None, 1f);
					if (Game1.invCatalog.catalog[(int)items[j]].desc2 == null)
					{
						Text.DrawCText(sprite, loc + new Vector2(0f, -55f), Game1.invCatalog.catalog[(int)items[j]].desc, new Color(1f, 1f, 1f, itemAlpha[j]), 0.75f, 1, blur: false, 490f);
					}
					else
					{
						Text.DrawCText(sprite, loc + new Vector2(0f, -65f), Game1.invCatalog.catalog[(int)items[j]].desc, new Color(1f, 1f, 1f, itemAlpha[j]), 0.75f, 1, blur: false, 490f);
						Text.DrawCText(sprite, loc + new Vector2(0f, -45f), Game1.invCatalog.catalog[(int)items[j]].desc2, new Color(1f, 1f, 1f, itemAlpha[j]), 0.75f, 1, blur: false, 490f);
					}
				}
				sprite.Draw(Game1.spritesTex, loc + new Vector2(150f, -10f + (float)num3 * 30f), new Rectangle(640 + j % 4 * 32, 576, 32, 32), new Color(1f, 1f, 1f, 1f), 0f, default, 1f, SpriteEffects.None, 1f);
				Text.DrawScore((int)(loc.X + 180f), (int)(loc.Y - 10f + (float)num3 * 30f), Game1.invCatalog.catalog[(int)items[j]].value, new Color(1f, 1f - itemAlpha[j], 1f - itemAlpha[j], 1f), sprite, flip: true, 0f, 0.75f);
				if (Game1.invCatalog.catalog[(int)items[j]].pickValue > 0)
				{
					sprite.Draw(Game1.itemsTex, loc + new Vector2(80f, -10f + (float)num3 * 30f), Game1.invCatalog.GetInvitemRect(InvCatalog.InvItemName.PsychoPick), new Color(1f, 1f, 1f, 1f), 0f, default, 0.125f, SpriteEffects.None, 1f);
					Text.DrawScore((int)(loc.X + 120f), (int)(loc.Y - 10f + (float)num3 * 30f), Game1.invCatalog.catalog[(int)items[j]].pickValue, new Color(1f, 1f - itemAlpha[j], 1f - itemAlpha[j], 1f), sprite, flip: true, 0f, 0.75f);
				}
			}
			num3++;
		}
	}
}
