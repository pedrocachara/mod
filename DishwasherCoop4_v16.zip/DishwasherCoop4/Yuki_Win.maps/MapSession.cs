namespace Yuki_Win.maps;

internal class MapSession
{
	private Map map;

	public MapSession(Map map)
	{
		this.map = map;
	}

	public void Update()
	{
	}
}
