using Microsoft.Xna.Framework;
using WorldEdit;

namespace Yuki_Win.maps;

public class NeighborManager
{
	public string[,] neighbor;

	private int origX;

	private int origY;

	public void Refresh(World world, Map map)
	{
		if (world == null)
		{
			neighbor = null;
			return;
		}
		string name = map.name;
		origX = -1;
		origY = -1;
		neighbor = new string[map.mapWidth + 2, map.mapHeight + 2];
		for (int i = 0; i < map.mapWidth + 2; i++)
		{
			for (int j = 0; j < map.mapHeight + 2; j++)
			{
				neighbor[i, j] = "";
			}
		}
		for (int k = 1; k < world.width - 1; k++)
		{
			for (int l = 1; l < world.height - 1; l++)
			{
				if (world.GetPath(k, l) == name)
				{
					if (origX == -1)
					{
						origX = k;
						origY = l;
					}
					TestNeighbor(k, l, k - 1, l, world, name);
					TestNeighbor(k, l, k + 1, l, world, name);
					TestNeighbor(k, l, k, l - 1, world, name);
					TestNeighbor(k, l, k, l + 1, world, name);
				}
			}
		}
	}

	private void TestNeighbor(int sX, int sY, int dX, int dY, World world, string curPath)
	{
		if (neighbor != null)
		{
			string path = world.GetPath(dX, dY);
			if (path != "" && path != curPath)
			{
				int num = dX - origX + 1;
				int num2 = dY - origY + 1;
				neighbor[num, num2] = path;
			}
		}
	}

	public Vector2 GetTransitionOffset(int sX, int sY, int dirX, int dirY, World world)
	{
		int num = sX + origX;
		int num2 = sY + origY;
		int x = num + dirX;
		int y = num2 + dirY;
		int num3 = world.GetOrigX(x, y);
		int num4 = world.GetOrigY(x, y);
		int num5 = origX - num3;
		int num6 = origY - num4;
		return new Vector2((float)(num5 * 10) * 64f, (float)(num6 * 10) * 64f);
	}

	public bool CheckIsNeighbor(Vector2 loc, int dirX, int dirY)
	{
		if (neighbor == null)
		{
			return false;
		}
		int num = (int)(loc.X / 64f) / 10;
		int num2 = (int)(loc.Y / 64f) / 10;
		int num3 = num + dirX + 1;
		int num4 = num2 + dirY + 1;
		if (num3 < 0)
		{
			num3 = 0;
		}
		if (num4 < 0)
		{
			num4 = 0;
		}
		if (num3 >= neighbor.GetLength(0))
		{
			num3 = neighbor.GetLength(0) - 1;
		}
		if (num4 >= neighbor.GetLength(1))
		{
			num4 = neighbor.GetLength(1) - 1;
		}
		if (num3 < 0 || num4 < 0 || num3 >= neighbor.GetLength(0) || num4 >= neighbor.GetLength(1))
		{
			return false;
		}
		if (neighbor[num3, num4] != "")
		{
			return true;
		}
		return false;
	}

	public string GetTransition(Vector2 loc, int dirX, int dirY)
	{
		int num = (int)(loc.X / 64f) / 10;
		int num2 = (int)(loc.Y / 64f) / 10;
		int num3 = num + dirX + 1;
		int num4 = num2 + dirY + 1;
		if (num3 < 0)
		{
			num3 = 0;
		}
		if (num4 < 0)
		{
			num4 = 0;
		}
		if (num3 >= neighbor.GetLength(0))
		{
			num3 = neighbor.GetLength(0) - 1;
		}
		if (num4 >= neighbor.GetLength(1))
		{
			num4 = neighbor.GetLength(1) - 1;
		}
		return neighbor[num3, num4];
	}
}
