using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.maps.environ;

namespace Yuki_Win.maps;

public class Environ
{
	public Ship[] ship;

	public float alpha;

	public float beta;

	public Aquarium aquarium;

	public Final final;

	public Environ()
	{
		ResetShips();
		aquarium = new Aquarium();
		final = new Final();
	}

	public void ResetShips()
	{
		ship = new Ship[20];
		for (int i = 0; i < ship.Length; i++)
		{
			ship[i] = new Ship(i);
			ship[i].loc = Rand.GetRandomVec2(0f, 2560f, 0f, 800f);
			ship[i].traj = Rand.GetRandomVec2(40f, 50f, -5f, 5f) * (Rand.CointToss(0.5f) ? 1f : (-1f));
			ship[i].depth = 0.1f + (float)i / 60f;
		}
	}

	internal void Update(GameMap map)
	{
		if (alpha > 6.28f)
		{
			alpha -= 6.28f;
		}
		if (beta > 6.28f)
		{
			beta -= 6.28f;
		}
		if (alpha < 0f)
		{
			alpha += 6.28f;
		}
		if (beta < 0f)
		{
			beta += 6.28f;
		}
		switch (map.theme.GetBackground())
		{
		case 1:
		case 3:
		{
			UpdateShips(map);
			for (int j = 0; j < ship.Length; j++)
			{
				ship[j].depth = 20f + (float)j / 180f;
			}
			alpha += FMan.frameTime * 0.4f;
			beta -= FMan.frameTime * 0.3f;
			break;
		}
		case 2:
		{
			alpha += FMan.frameTime * 0.15f;
			beta -= FMan.frameTime * 0.1f;
			for (int i = 0; i < ship.Length; i++)
			{
				ship[i].depth = 20f + (float)i / 180f;
			}
			UpdateShips(map);
			break;
		}
		case 8:
			final.Update();
			return;
		}
		if (aquarium.active)
		{
			aquarium.Update();
		}
	}

	internal void Draw(SpriteBatch sprite, GameMap map)
	{
		switch (map.theme.GetBackground())
		{
		case 1:
		case 3:
			DrawShips(sprite);
			break;
		case 2:
			if (map.theme.theme != Themes.ThemeType.Escape && Game1.gameMap.theme.theme != Themes.ThemeType.EscapeOut)
			{
				DrawShips(sprite);
			}
			break;
		case 8:
			sprite.End();
			SpriteTools.BeginAdditive();
			final.Draw(sprite);
			break;
		}
	}

	public void DrawAquarium(SpriteBatch sprite)
	{
		aquarium.Draw(sprite);
	}

	private void DrawShips(SpriteBatch sprite)
	{
		for (int i = 0; i < ship.Length; i++)
		{
			ship[i].Draw(sprite);
		}
	}

	private void UpdateShips(GameMap map)
	{
		for (int i = 0; i < ship.Length; i++)
		{
			ship[i].Update(map);
		}
	}
}
