using System;
using director;
using Microsoft.Xna.Framework;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.director;
using Yuki_Win.eightbit;
using Yuki_Win.gameRender;
using Yuki_Win.levels;
using Yuki_Win.player;

namespace Yuki_Win.maps;

public class Themes
{
	public enum ThemeType
	{
		Marble,
		Asylum,
		Prison,
		Escape,
		Moon,
		Moondoors,
		MarbleMoon,
		Lobby,
		LobbyChute,
		Closet,
		PrisonOut,
		BigCloset,
		Crypt,
		MoonDark,
		Dark,
		Descent,
		Ascent,
		Swamp,
		Tank,
		Elite,
		EliteLobby,
		Lift,
		EliteDark,
		Aquarium,
		EliteDarkQuiet,
		Rush,
		GearCloset,
		Dish,
		Final,
		MapRoom,
		Cache,
		TankBrite,
		FishlessAquarium,
		Terror,
		Church,
		Judge,
		EscapeOut
	}

	public const int BG_BLACK = 0;

	public const int BG_ORBITING = 2;

	public const int BG_NORMAL = 1;

	public const int BG_HAZY = 3;

	public const int BG_DARK = 4;

	public const int BG_SWAMP = 5;

	public const int BG_AQUARIUM = 6;

	public const int BG_GRAY = 7;

	public const int BG_FINAL = 8;

	public const int BG_BRIGHT = 9;

	public const int BG_HAZY_DARK = 10;

	public ThemeType theme;

	public ThemeType pTheme;

	public bool quiet;

	public int GetBackground()
	{
		if (Game1.gameMap.lichFreakoutMode)
		{
			return 5;
		}
		switch (theme)
		{
		case ThemeType.Cache:
		case ThemeType.Church:
			return 0;
		case ThemeType.MapRoom:
			return 9;
		case ThemeType.Aquarium:
		case ThemeType.FishlessAquarium:
			return 6;
		case ThemeType.Asylum:
		case ThemeType.Moondoors:
		case ThemeType.Lobby:
		case ThemeType.LobbyChute:
		case ThemeType.Closet:
		case ThemeType.MoonDark:
		case ThemeType.Elite:
		case ThemeType.EliteLobby:
		case ThemeType.EliteDark:
		case ThemeType.EliteDarkQuiet:
		case ThemeType.Rush:
		case ThemeType.Dish:
			return 0;
		case ThemeType.Final:
			return 8;
		case ThemeType.GearCloset:
		case ThemeType.Terror:
			return 7;
		case ThemeType.Crypt:
			return 4;
		case ThemeType.Prison:
		case ThemeType.Escape:
		case ThemeType.PrisonOut:
		case ThemeType.EscapeOut:
			return 2;
		case ThemeType.Moon:
		case ThemeType.MarbleMoon:
		case ThemeType.Dark:
		case ThemeType.Descent:
		case ThemeType.TankBrite:
			return 3;
		case ThemeType.Tank:
			return 10;
		case ThemeType.Swamp:
			return 5;
		default:
			return 1;
		}
	}

	public Color ColorK(float r, float g, float b, float k)
	{
		return new Color(r * k, g * k, b * k, 1f);
	}

	public Color ColorKBG(float r, float g, float b)
	{
		float adjustedKillBrite = Game1.killManager.GetAdjustedKillBrite();
		return new Color(r * adjustedKillBrite, g * adjustedKillBrite, b * adjustedKillBrite, 1f);
	}

	public Color ColorK3(float r, float g, float b, float k)
	{
		return new Color(r * k, g * k, b * k, 1f);
	}

	public Color ColorK2(float r, float g, float b, float k)
	{
		k = 0.25f + k * 0.75f;
		return new Color(r * k, g * k, b * k, 1f);
	}

	public Color ColorK1(float r, float g, float b, float k)
	{
		k = 0.5f + k * 0.5f;
		return new Color(r * k, g * k, b * k, 1f);
	}

	public Color ColorK0(float r, float g, float b, float k)
	{
		k = 0.75f + k * 0.25f;
		return new Color(r * k, g * k, b * k, 1f);
	}

	public void UpdateColors()
	{
		quiet = false;
		float num = 0f;
		if (Game1.transMgr.inFrame > 0f || Game1.transMgr.outFrame > 0f)
		{
			num = ((Game1.transMgr.inFrame > Game1.transMgr.outFrame) ? Game1.transMgr.inFrame : (1f - Game1.transMgr.outFrame));
		}
		bool flag = false;
		bool flag2 = false;
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (!Game1.character[i].exists || Game1.character[i].team != Character.Team.BadGuys)
			{
				continue;
			}
			if (!Game1.character[i].charUpdate.inactive && !Game1.character[i].charUpdate.nomusic && !Game1.character[i].GetMeta().isBox)
			{
				flag = true;
				if (Game1.character[i].GetMeta().isBoss && !Game1.character[i].GetMeta().nobossmusic && !Game1.character[i].GetMeta().nomusic && !Game1.character[i].charUpdate.nomusic)
				{
					flag2 = true;
				}
			}
			if (Game1.character[i].GetMeta().nomusic)
			{
				quiet = true;
			}
		}
		if (Game1.gameMap.bucketKillMode)
		{
			flag = false;
		}
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off && (Game1.gameMap.redLightval > 0f || Game1.gameMap.redlights))
		{
			flag = false;
		}
		GameRender.filterRender.brite = 0f;
		if (Game1.levelMgr.currentTrack == 6 || Game1.levelMgr.currentTrack == 5)
		{
			flag = false;
		}
		if (GameState.state == GameState.State.Menu)
		{
			if (!Game1.menuMgr.pauseMode)
			{
				Music.track = 4;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = -0.2f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(0f, 0.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.6f, 0.61f);
			return;
		}
		GameRender.filterRender.charBrite = 0.8f;
		GameRender.filterRender.burn = 0.1f;
		GameRender.bloomRender.sat = 0.1f;
		float num2 = Game1.killManager.GetAdjustedKillBrite();
		bool flag3 = false;
		float num3 = 0f;
		for (int j = 0; j < 2; j++)
		{
			if (!Game1.character[j].exists || !(Game1.character[j].charUpdate.magic > 0f))
			{
				continue;
			}
			float magic = Game1.character[j].charUpdate.magic;
			magic = 1f - magic;
			if (magic < 0.3f)
			{
				magic = 0.3f;
			}
			if (Game1.character[j].charUpdate.magicOut > 0f)
			{
				magic += 1f - Game1.character[j].charUpdate.magicOut;
				if (magic > 1f)
				{
					magic = 1f;
				}
			}
			num2 *= magic;
			num3 = 1f - magic;
			if (Game1.character[j].GetMeta().isDish)
			{
				flag3 = true;
			}
		}
		GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.None;
		GameRender.fadingBackgroundContrast = 1f;
		GameRender.fadingBackgroundBrite = 0f;
		GameRender.filterRender.charBrite = 0.85f + Game1.killManager.killVal;
		GameRender.feedbackMode = false;
		switch (theme)
		{
		case ThemeType.Lobby:
		case ThemeType.LobbyChute:
			Music.track = 0;
			if (flag)
			{
				Music.track = 5;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = 0f;
			GameRender.filterRender.bR = 0.1f;
			GameRender.filterRender.bG = 0f;
			GameRender.filterRender.bB = 0.1f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0f;
			break;
		case ThemeType.Church:
			Music.track = 0;
			if (flag)
			{
				Music.track = 5;
			}
			GameRender.filterRender.tR = 0.2f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = -0.3f;
			Game1.gameMap.fog = true;
			Game1.gameMap.glows = true;
			Game1.gameMap.ashes = true;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = -0.2f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.015f, 0.016f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Elite:
		case ThemeType.EliteLobby:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = 0.1f;
			GameRender.filterRender.bR = 0.1f;
			GameRender.filterRender.bG = 0f;
			GameRender.filterRender.bB = 0.1f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0f;
			break;
		case ThemeType.MapRoom:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0.1f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = 0.1f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = 0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0f;
			break;
		case ThemeType.Cache:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0.2f;
			GameRender.filterRender.tG = 0.3f;
			GameRender.filterRender.tB = 0.25f;
			GameRender.filterRender.bR = -0.3f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = -0.1f;
			GameRender.filterRender.burn = 0.75f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.006f, 0.007f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			GameRender.fadingBackgroundContrast = 1.5f;
			GameRender.fadingBackgroundBrite = 0.1f;
			GameRender.filterRender.charBrite = 0.7f;
			break;
		case ThemeType.Rush:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0.18f;
			GameRender.filterRender.tG = 0.1f;
			GameRender.filterRender.tB = 0.1f;
			GameRender.filterRender.bR = 0.1f;
			GameRender.filterRender.bG = 0.1f;
			GameRender.filterRender.bB = 0.15f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.2f, 0.2f, 0.2f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.4f, 0.4f, 0.4f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0.1f;
			GameRender.filterRender.charBrite = 0.5f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Final:
			Music.track = 11;
			if (MainPlayer.uberDyingFrame > 0f)
			{
				Music.track = 0;
			}
			GameRender.feedbackMode = true;
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.4f;
			GameRender.filterRender.tB = -0.5f;
			GameRender.filterRender.bR = 0.5f;
			GameRender.filterRender.bG = 0.1f;
			GameRender.filterRender.bB = 0.1f;
			GameRender.filterRender.burn = 0.85f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.0075f, 0.0076f);
			GameRender.bloomRender.alpha = 0f;
			if (Game1.gameMap.CrazyTransitionInFrame > 0f)
			{
				num2 *= (5f - Game1.gameMap.CrazyTransitionInFrame) / 5f;
				GameRender.filterRender.bR -= 0.5f * (Game1.gameMap.CrazyTransitionInFrame / 5f);
				GameRender.filterRender.bG -= 0.1f * (Game1.gameMap.CrazyTransitionInFrame / 5f);
				GameRender.filterRender.bB += 0.1f * (Game1.gameMap.CrazyTransitionInFrame / 5f);
			}
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.2f, 0.2f, 0.2f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.4f, 0.4f, 0.4f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0f;
			GameRender.filterRender.charBrite = 0.85f;
			if (Game1.gameMap.CrazyTransitionInFrame > 0f)
			{
				GameRender.filterRender.charBrite *= (5f - Game1.gameMap.CrazyTransitionInFrame) / 5f;
			}
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.EliteDark:
		case ThemeType.EliteDarkQuiet:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = 0f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.1f, 0.1f, 0.1f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.2f, 0.2f, 0.2f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Lift:
		{
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			float num4 = Game1.gameMap.liftFrame / 40f;
			if (num4 > 1f)
			{
				num4 = 1f;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = -0.1f + num4 * 0.1f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = -0.1f + num4 * 0.1f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.5f + num4 * 0.5f, 0.5f + num4 * 0.5f, 0.5f + num4 * 0.5f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.LowLevels;
			GameRender.fadingBackgroundBrite = 0.1f;
			GameRender.fadingBackgroundContrast = 1.2f;
			break;
		}
		case ThemeType.MarbleMoon:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = -0.1f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = -0.05f;
			GameRender.filterRender.bB = -0.1f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.5f, 0.5f, 0.5f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.7f, 0.7f, 0.7f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = -0.2f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Crypt:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0f;
			GameRender.filterRender.tG = 0.1f;
			GameRender.filterRender.tB = 0f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = 0f;
			GameRender.filterRender.bB = 0.1f;
			GameRender.filterRender.burn = 0.65f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.008f, 0.009f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.5f, 0.51f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.3f, 0.35f, 0.3f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.55f, 0.6f, 0.55f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = -0.15f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			GameRender.fadingBackgroundBrite = 0.1f;
			GameRender.fadingBackgroundContrast = 1.2f;
			GameRender.filterRender.charBrite = 0.8f;
			break;
		case ThemeType.Aquarium:
		case ThemeType.FishlessAquarium:
		{
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0f;
			GameRender.filterRender.tG = 0.05f;
			GameRender.filterRender.tB = 0.1f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = 0.05f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.008f, 0.009f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.5f, 0.51f);
			float num5 = 1f - Game1.gameMap.goryoAlpha;
			if (Game1.gameMap.goryoAlpha > 0f)
			{
				GameRender.filterRender.tR += Game1.gameMap.goryoAlpha * 0.02f;
				GameRender.filterRender.tG += Game1.gameMap.goryoAlpha * 0.02f;
				GameRender.filterRender.tB += Game1.gameMap.goryoAlpha * 0.02f;
				GameRender.filterRender.bR += Game1.gameMap.goryoAlpha * 0.12f;
				GameRender.filterRender.bG += Game1.gameMap.goryoAlpha * 0.02f;
				GameRender.filterRender.bB += Game1.gameMap.goryoAlpha * 0.02f;
				GameRender.filterRender.burn -= Game1.gameMap.goryoAlpha * 0.1f;
				GameRender.filterRender.charBrite -= Game1.gameMap.goryoAlpha * 0.2f;
			}
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.3f * num5, 0.35f * num5, 0.3f * num5, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.55f * num5, 0.6f * num5, 0.85f * num5, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.7f * num5, 0.75f * num5, 0.75f * num5, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0.1f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		}
		case ThemeType.Closet:
		case ThemeType.BigCloset:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = -0.15f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = 0.05f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 0.7f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.3f, 0.31f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.59f, 0.58f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.7f, 0.7f, 0.7f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = 0.1f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Dish:
		{
			GameRender.feedbackMode = true;
			Music.track = 10;
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = -0.15f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 1f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.009f, 0.01f);
			GameRender.bloomRender.alpha = 0f;
			float num7 = 1f - Game1.gameMap.goryoAlpha;
			if (Game1.gameMap.goryoAlpha > 0f)
			{
				GameRender.filterRender.tR += Game1.gameMap.goryoAlpha * 0.2f;
				GameRender.filterRender.tG += Game1.gameMap.goryoAlpha * 0.2f;
				GameRender.filterRender.tB += Game1.gameMap.goryoAlpha * 0.2f;
				GameRender.filterRender.bR += Game1.gameMap.goryoAlpha * 0.2f;
				GameRender.filterRender.bG += Game1.gameMap.goryoAlpha * 0.2f;
				GameRender.filterRender.bB += Game1.gameMap.goryoAlpha * 0.2f;
				GameRender.filterRender.burn -= Game1.gameMap.goryoAlpha * 0.5f;
				GameRender.filterRender.gray = 5f;
			}
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f * num7, 0.59f * num7, 0.58f * num7, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.6f * num7, 0.58f * num7, 0.56f * num7, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f * num7, 0.975f * num7, 0.95f * num7, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2 * Game1.gameMap.goryoAlpha);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2 * Game1.gameMap.goryoAlpha);
			GameRender.filterRender.brite = 0f;
			if (Game1.gameMap.isPuppeteer)
			{
				if (Game1.gameMap.puppeteerFrame < 1f)
				{
					Game1.gameMap.puppeteerFrame += FMan.frameTime;
					if (Game1.gameMap.puppeteerFrame > 1f)
					{
						Game1.gameMap.puppeteerFrame = 1f;
					}
				}
				GameRender.filterRender.tR += Game1.gameMap.puppeteerFrame * 0.4f;
				if (Game1.gameMap.actuallyBlueLightval > 0f)
				{
					GameRender.filterRender.tR -= Game1.gameMap.actuallyBlueLightval * 0.4f;
					GameRender.filterRender.tG += Game1.gameMap.actuallyBlueLightval * 0.1f;
					GameRender.filterRender.tB += Game1.gameMap.actuallyBlueLightval * 0.4f;
					Game1.gameMap.CurMap().layer[1].color = ColorK(0.6f - Game1.gameMap.actuallyBlueLightval, 0.58f - Game1.gameMap.actuallyBlueLightval, 0.56f - Game1.gameMap.actuallyBlueLightval, num2);
				}
			}
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		}
		case ThemeType.GearCloset:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = -0.15f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 0.8f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.4f, 0.41f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.59f, 0.58f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.1f, 0.1f, 0.1f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 0.975f, 0.95f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = -0.1f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Marble:
		case ThemeType.Judge:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = -0.2f;
			GameRender.filterRender.bR = 0.1f;
			GameRender.filterRender.bG = 0f;
			GameRender.filterRender.bB = 0.1f;
			GameRender.filterRender.burn = 0.5f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.8f, 0.81f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.5f, 0.5f, 0.5f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.brite = -0.05f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.LowLevels;
			GameRender.fadingBackgroundContrast = 2f;
			GameRender.fadingBackgroundBrite = 0.125f;
			break;
		case ThemeType.Asylum:
			Music.track = 2;
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = 0f;
			GameRender.filterRender.bR = -0.1f;
			GameRender.filterRender.bG = 0f;
			GameRender.filterRender.bB = -0.1f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(1.2f, 1.21f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(0.1f, 0.11f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.01f, 0.011f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.06f, 0.07f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.5f, 0.5f, 0.5f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.65f, 0.65f, 0.65f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			QuakeManager.SetBurst(0.2f, ScrollManager.screenSize / 2f + new Vector2((float)Math.Cos(30f * Game1.gameMap.tvFrame), (float)Math.Sin(30f * Game1.gameMap.tvFrame)) * 50f);
			break;
		case ThemeType.Prison:
			Music.track = 0;
			if (Game1.gameMap.alert)
			{
				Music.track = 1;
			}
			else if (!Game1.sceneMgr.playing || Game1.sceneMgr.overlay)
			{
				quiet = true;
			}
			GameRender.filterRender.tR = -0.2f;
			GameRender.filterRender.tG = -0.2f;
			GameRender.filterRender.tB = -0.3f;
			GameRender.filterRender.bR = -0.1f;
			GameRender.filterRender.bG = -0.2f;
			GameRender.filterRender.bB = -0.2f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.8f, 0.81f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.65f, 0.651f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.5f, 0.5f, 0.5f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.7f, 0.7f, 0.7f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 0.99f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			if (Game1.gameMap.alert)
			{
				Game1.gameMap.CurMap().layer[2].color = ColorK((float)Math.Sin(Game1.gameMap.tvFrame * 6.28f * 10f) * 0.1f + 0.6f, 0.5f, 0.5f, num2);
				GameRender.bloomRender.alpha += (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f * 20f + 1.57f) * 0.1f + 0.1f;
				GameRender.filterRender.tR += 0.1f;
				GameRender.filterRender.tG += 0.1f;
				GameRender.filterRender.tB += 0.1f;
				GameRender.filterRender.bR += 0.1f;
				GameRender.filterRender.bG += 0.1f;
				GameRender.filterRender.bB += 0.1f;
			}
			else
			{
				Game1.gameMap.CurMap().layer[0].color = ColorK2(0.5f, 0.5f, 0.5f, num2);
				Game1.gameMap.CurMap().layer[1].color = ColorK1(0.7f, 0.7f, 0.7f, num2);
				Game1.gameMap.CurMap().layer[2].color = ColorK0(0.7f, 0.7f, 0.69f, num2);
			}
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.PrisonOut:
			Music.track = 0;
			if (Game1.gameMap.alert)
			{
				Music.track = 1;
			}
			GameRender.filterRender.tR = -0.2f;
			GameRender.filterRender.tG = -0.2f;
			GameRender.filterRender.tB = -0.3f;
			GameRender.filterRender.bR = -0.1f;
			GameRender.filterRender.bG = -0.2f;
			GameRender.filterRender.bB = -0.2f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.8f, 0.81f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.011f, 0.012f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.55f, 0.551f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.55f, 0.4f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.8f, 0.7f, 0.5f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 0.99f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0.05f, 0.05f, 0.05f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Escape:
		case ThemeType.EscapeOut:
			Music.track = 2;
			GameRender.filterRender.tR = -0.2f;
			GameRender.filterRender.tG = -0.2f;
			GameRender.filterRender.tB = -0.3f;
			GameRender.filterRender.bR = -0.1f;
			GameRender.filterRender.bG = -0.2f;
			GameRender.filterRender.bB = -0.2f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.8f, 0.81f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.65f, 0.651f);
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.55f, 0.4f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.8f, 0.7f, 0.5f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 0.99f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			QuakeManager.SetQuake(0.1f);
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			if (theme == ThemeType.EscapeOut)
			{
				GameRender.feedbackMode = true;
				Game1.gameMap.CurMap().layer[2].color = ColorK0(0.5f, 0.5f, 0.49f, num2);
			}
			break;
		case ThemeType.Moon:
		case ThemeType.MoonDark:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.3f;
			GameRender.filterRender.tG = -0.3f;
			GameRender.filterRender.tB = -0.4f;
			GameRender.filterRender.bR = -0.3f;
			GameRender.filterRender.bG = -0.3f;
			GameRender.filterRender.bB = -0.2f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.6f, 0.61f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.7f, 0.71f);
			GameRender.filterRender.brite = 0.2f;
			if (theme == ThemeType.MoonDark)
			{
				Game1.gameMap.CurMap().layer[0].color = ColorK2(0.125f, 0.125f, 0.125f, num2);
				Game1.gameMap.CurMap().layer[1].color = ColorK1(0.35f, 0.35f, 0.35f, num2);
			}
			else
			{
				Game1.gameMap.CurMap().layer[0].color = ColorK2(1f, 1f, 1f, num2);
				Game1.gameMap.CurMap().layer[1].color = ColorK1(0.35f, 0.35f, 0.35f, num2);
			}
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.5f, 0.5f, 0.5f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.charBrite = 0.7f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.LowLevels;
			break;
		case ThemeType.Moondoors:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.2f;
			GameRender.filterRender.tG = -0.2f;
			GameRender.filterRender.tB = -0.3f;
			GameRender.filterRender.bR = -0.3f;
			GameRender.filterRender.bG = -0.15f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.6f, 0.61f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.6f, 0.61f);
			GameRender.bloomRender.sat = 0.1f;
			Game1.gameMap.CurMap().layer[0].color = ColorK2(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.85f, 0.85f, 0.85f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.8f, 0.8f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Dark:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0f;
			GameRender.filterRender.tG = 0.1f;
			GameRender.filterRender.tB = 0f;
			GameRender.filterRender.bR = -0.1f;
			GameRender.filterRender.bG = 0f;
			GameRender.filterRender.bB = 0.1f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.4f, 0.41f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.6f, 0.61f);
			GameRender.bloomRender.sat = 1f;
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.7f, 0.7f, 0.7f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			GameRender.fadingBackgroundContrast = 2f;
			GameRender.fadingBackgroundBrite = 0.1f;
			break;
		case ThemeType.Terror:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = -0.1f;
			GameRender.filterRender.bR = -0.2f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.4f, 0.41f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.6f, 0.61f);
			GameRender.bloomRender.sat = 1f;
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.7f, 0.7f, 0.7f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.filterRender.charBrite = 0.8f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Descent:
			Music.track = 0;
			Music.track = 1;
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = -0.1f;
			GameRender.filterRender.bR = -0.2f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.4f, 0.41f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.6f, 0.61f);
			GameRender.bloomRender.sat = 1f;
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			if (Game1.gameMap.descentFrame < 20f)
			{
				Game1.gameMap.CurMap().layer[1].color = ColorK1(0.7f, 0.7f, 0.7f, num2);
				Game1.gameMap.CurMap().layer[2].color = ColorK0(0.7f, 0.7f, 0.7f, num2);
			}
			else if (Game1.gameMap.descentFrame < 30f)
			{
				float num6 = (30f - Game1.gameMap.descentFrame) / 10f * 0.4f + 0.3f;
				Game1.gameMap.CurMap().layer[1].color = ColorK1(num6, num6, num6, num2);
				num6 = (Game1.gameMap.descentFrame - 20f) / 10f * 0.3f + 0.7f;
				Game1.gameMap.CurMap().layer[2].color = ColorK0(num6, num6, num6, num2);
			}
			else
			{
				Game1.gameMap.CurMap().layer[1].color = ColorK1(0.3f, 0.3f, 0.3f, num2);
				Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			}
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.LowLevels;
			GameRender.fadingBackgroundContrast = 1f + Game1.gameMap.descentFrame;
			GameRender.fadingBackgroundBrite = 0.25f;
			break;
		case ThemeType.Swamp:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = -0.1f;
			GameRender.filterRender.bR = -0.2f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.4f, 0.41f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.015f, 0.016f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.6f, 0.61f);
			GameRender.bloomRender.sat = 1f;
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.7f, 0.7f, 0.7f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.Tank:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = 0.1f;
			GameRender.filterRender.bR = 0.15f;
			GameRender.filterRender.bG = 0.075f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.6f, 0.61f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.9f, 0.91f);
			GameRender.filterRender.brite = 0.1f;
			GameRender.filterRender.charBrite = 0.6f;
			Game1.gameMap.CurMap().layer[0].color = ColorK2(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.35f, 0.32f, 0.32f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.55f, 0.5f, 0.5f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			if (Game1.gameMap.descentSpeed > 0.1f)
			{
				QuakeManager.SetQuake(0.04f);
			}
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		case ThemeType.TankBrite:
			Music.track = 0;
			if (flag)
			{
				Music.track = 6;
			}
			GameRender.filterRender.tR = 0f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = -0.1f;
			GameRender.filterRender.bR = -0.5f;
			GameRender.filterRender.bG = -0.35f;
			GameRender.filterRender.bB = -0.2f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.4f, 0.41f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.005f, 0.006f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.7f, 0.71f);
			GameRender.filterRender.charBrite = 0.7f;
			Game1.gameMap.CurMap().layer[0].color = ColorK2(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.85f, 0.85f, 0.85f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(0.7f, 0.7f, 0.7f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
			break;
		}
		GameRender.redVal = 0f;
		if (MainPlayer.uberDyingFrame > 1f)
		{
			float num8 = MainPlayer.uberDyingFrame - 1f;
			num8 *= 1f;
			if (num8 > 1f)
			{
				num8 = 1f;
			}
			GameRender.redVal = 0.8f * num8;
			GameRender.bloomRender.sat *= 1f - num8;
		}
		if (Game1.gameMap.theme.theme == ThemeType.Asylum)
		{
			GameRender.bloomRender.alpha += Rand.GetRandomFloat(0f, 0.2f);
		}
		else
		{
			float num9 = 0f;
			if (Game1.gameMap.CrazyTransitionInFrame > 0f && Game1.gameMap.CrazyTransitionInFrame < 1f)
			{
				num9 = 1f - Game1.gameMap.CrazyTransitionInFrame;
			}
			if (Game1.gameMap.CrazyTransitionOutFrame > 0f)
			{
				num9 = Game1.gameMap.CrazyTransitionOutFrame;
			}
			if (num9 > 0f)
			{
				GameRender.bloomRender.alpha += num9;
			}
		}
		if (Game1.gameMap.bgRefractMode)
		{
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.None;
		}
		switch (Game1.gameMap.beadTheme)
		{
		case GameMap.BeadTheme.Contrast:
			QuakeManager.contrast = 2f;
			QuakeManager.bright = 1f;
			GameRender.filterRender.gray = 2f;
			GameRender.bloomRender.alpha = 0f;
			GameRender.feedbackMode = false;
			break;
		case GameMap.BeadTheme.ThreeDee:
			QuakeManager.SetBright(0.1f);
			GameRender.filterRender.tR = 0f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = 0f;
			GameRender.filterRender.bR = 0f;
			GameRender.filterRender.bG = 0f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.burn = 0f;
			break;
		}
		if (Music.track == 6 && Game1.gameMap.CurMap().scriptMgr.mapHasZombiesInIt)
		{
			Music.track = 8;
		}
		if (flag2)
		{
			switch (theme)
			{
			default:
				Music.track = 3;
				if (Game1.gameMap.yukiDeathFocus)
				{
					Music.track = 0;
				}
				break;
			case ThemeType.Asylum:
			case ThemeType.Dish:
			case ThemeType.Final:
				break;
			}
		}
		if (EightBitGame.enabled)
		{
			Music.track = 12;
		}
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade || Game1.arcade.arcadeMode == Arcade.ArcadeMode.DishChallenge)
		{
			if (flag)
			{
				Music.track = Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].track;
			}
			else
			{
				Music.track = 0;
			}
		}
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.Slow)
		{
			float num10 = Game1.arcade.slowVal - 1f;
			GameRender.bloomRender.val += num10 * 0.005f;
			GameRender.bloomRender.alpha += num10 * 0.7f;
			GameRender.filterRender.tR -= num10 * 0.2f;
			GameRender.filterRender.tG -= num10 * 0.2f;
			GameRender.filterRender.tB += num10 * 0.2f;
			GameRender.filterRender.bR -= num10 * 0.2f;
			GameRender.filterRender.bG += num10 * 0.2f;
			GameRender.filterRender.bB -= num10 * 0.2f;
			GameRender.filterRender.brite -= num10 * 0.1f;
		}
		if (flag3)
		{
			GameRender.filterRender.bG += num3 / 3f;
			GameRender.filterRender.tB += num3 / 3f;
		}
		else
		{
			GameRender.filterRender.bR += num3 / 3f;
			GameRender.filterRender.tB += num3 / 3f;
		}
		if (Game1.gameMap.lichFreakoutMode)
		{
			GameRender.filterRender.tR = -0.1f;
			GameRender.filterRender.tG = 0f;
			GameRender.filterRender.tB = -0.1f;
			GameRender.filterRender.bR = -0.2f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0f;
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.bloomRender.sat = 1f;
			Game1.gameMap.CurMap().layer[0].color = ColorK2(0.6f, 0.6f, 0.6f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK1(0.7f, 0.7f, 0.7f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK0(1f, 1f, 1f, num2);
			Game1.gameMap.CurMap().layer[3].color = ColorK(0f, 0f, 0f, num2);
			Game1.gameMap.CurMap().layer[4].color = ColorK(0f, 0f, 0f, num2);
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.025f, 0.036f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.6f, 0.7f);
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.7f, 0.81f);
			GameRender.filterRender.bR = 0.3f;
			GameRender.filterRender.bG = 0.2f;
			GameRender.fadingBackgroundBrite = 0.1f;
			GameRender.filterRender.brite = 0.1f;
			GameRender.fadingBackgroundMode = GameRender.FadingBackgroundMode.MidLevelsHeavy;
		}
		else if (theme == ThemeType.Swamp)
		{
			GameRender.filterRender.brite = -0.2f;
		}
		if (GameSettings.difficulty == 0)
		{
			GameRender.filterRender.tR = 0.1f;
			GameRender.filterRender.tG = -0.1f;
			GameRender.filterRender.tB = 0.05f;
			GameRender.filterRender.bR = -0.1f;
			GameRender.filterRender.bG = -0.1f;
			GameRender.filterRender.bB = 0.1f;
			GameRender.filterRender.burn = Rand.GetRandomFloat(0.1f, 0.11f);
			GameRender.filterRender.gray = Rand.GetRandomFloat(1f, 1.1f);
			GameRender.filterRender.brite = 0f;
			GameRender.bloomRender.val = Rand.GetRandomFloat(0.015f, 0.016f);
			GameRender.bloomRender.alpha = Rand.GetRandomFloat(0.3f, 0.31f);
			GameRender.bloomRender.sat = 0.1f;
			Game1.gameMap.CurMap().layer[0].color = ColorK(0.4f, 0.6f, 1f, num2);
			Game1.gameMap.CurMap().layer[1].color = ColorK(0.4f, 0.5f, 0.8f, num2);
			Game1.gameMap.CurMap().layer[2].color = ColorK(0.7f, 0.5f, 0.6f, num2);
			Game1.gameMap.glows = true;
			Game1.gameMap.drips = false;
			Game1.gameMap.fog = false;
			Game1.gameMap.haze = false;
			Game1.gameMap.halfhaze = false;
			Game1.gameMap.ashes = false;
			Game1.gameMap.rain = false;
			GameRender.feedbackMode = true;
		}
		_ = Game1.gameMap.strobe;
		if (Game1.gameMap.redLightval > 0f && Game1.gameMap.beadTheme != GameMap.BeadTheme.Contrast)
		{
			GameRender.filterRender.tR += Game1.gameMap.redLightval * 0.1f;
			GameRender.filterRender.bR += Game1.gameMap.redLightval * 0.3f;
			GameRender.filterRender.tG -= Game1.gameMap.redLightval * 0.1f;
			GameRender.filterRender.tB -= Game1.gameMap.redLightval * 0.1f;
			GameRender.filterRender.bG -= Game1.gameMap.redLightval * 0.1f;
			GameRender.filterRender.bB -= Game1.gameMap.redLightval * 0.1f;
			GameRender.filterRender.brite += Game1.gameMap.redLightval * 0.15f;
			GameRender.bloomRender.val += Game1.gameMap.redLightval * 0.01f;
			GameRender.bloomRender.alpha += Game1.gameMap.redLightval * 0.1f;
			QuakeManager.contrast = 0f;
		}
		GameRender.filterRender.burn += Game1.killManager.killVal * Rand.GetRandomFloat(0f, 0.005f);
		GameRender.filterRender.gray += num * 4f;
		if (GameRender.filterRender.gray > 1f)
		{
			GameRender.filterRender.gray = 1f;
		}
		GameRender.filterRender.gray = 0.1f;
		if (Game1.gameMap.CrazyTransitionInFrame > 0f && Game1.gameMap.CrazyTransitionInFrame < 1f)
		{
			GameRender.bloomRender.alpha += 1f - Game1.gameMap.CrazyTransitionInFrame;
			GameRender.bloomRender.val += (1f - Game1.gameMap.CrazyTransitionInFrame) * 0.01f;
		}
		if (Game1.gameMap.CrazyTransitionOutFrame > 0f)
		{
			GameRender.bloomRender.alpha += Game1.gameMap.CrazyTransitionOutFrame * 4f;
		}
		if (Game1.gameMap.CrazyTransitionInFrame > 0f && Game1.gameMap.CrazyTransitionInFrame < 1f)
		{
			GameRender.bloomRender.alpha += (1f - Game1.gameMap.CrazyTransitionInFrame) * 4f;
		}
	}
}
