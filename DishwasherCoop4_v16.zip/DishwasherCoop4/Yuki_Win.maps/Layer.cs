using Microsoft.Xna.Framework;

namespace Yuki_Win.maps;

public class Layer
{
	public enum Level
	{
		Back2,
		Back1,
		Mid,
		Fore1,
		Fore2
	}

	public Segment[] segment;

	public Level level;

	public float zoom;

	public float adjustedZoom;

	public Color color;

	public Layer(Level level)
	{
		segment = new Segment[256];
		this.level = level;
		color = Color.White;
	}
}
