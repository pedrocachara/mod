using System;
using System.IO;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using yMapEdit.segdef;
using Yuki_Win.director;
using Yuki_Win.eightbit;
using Yuki_Win.gameRender;
using Yuki_Win.maps.script;

namespace Yuki_Win.maps;

public class Map
{
	public enum Collision : byte
	{
		None,
		Full,
		Rise,
		Fall,
		CeilingRise,
		CeilingFall,
		Ceiling,
		Pipe,
		Null,
		Ledge
	}

	public const int ICELL = 64;

	public const float FCELL = 64f;

	public string path;

	public string name;

	public Layer[] layer;

	public bool isBlood;

	public bool drewBGRefract;

	public int bgRefractEndIdx;

	public int xSize = 20;

	public int ySize = 20;

	public int mapWidth = 2;

	public int mapHeight = 2;

	public ScriptManager scriptMgr;

	public Collision[,] collision;

	private Collision[,] ocol;

	public void SetWidth(int w)
	{
		mapWidth = w;
		xSize = mapWidth * 10;
	}

	public void SetHeight(int h)
	{
		mapHeight = h;
		ySize = mapHeight * 10;
	}

	public Collision GetCol(Vector2 v)
	{
		int num = (int)(v.X / 64f);
		int num2 = (int)(v.Y / 32f);
		if (num >= 0 && num2 >= 0 && num < xSize && (float)num2 < (float)ySize * 2f)
		{
			return collision[num, num2];
		}
		return Collision.None;
	}

	public bool TestCol(Vector2 v)
	{
		return TestCol(v, ceils: false, shadow: false, ledge: false);
	}

	public bool TestCol(Vector2 v, bool ceils)
	{
		return TestCol(v, ceils, shadow: false, ledge: false);
	}

	public bool TestCol(Vector2 v, bool ceils, bool shadow)
	{
		return TestCol(v, ceils, shadow, ledge: false);
	}

	public bool TestCol(Vector2 v, bool ceils, bool shadow, bool ledge)
	{
		switch (GetCol(v))
		{
		case Collision.None:
			return false;
		case Collision.Ceiling:
			return ceils;
		case Collision.Full:
		case Collision.Pipe:
			return true;
		case Collision.Null:
			if (shadow)
			{
				return false;
			}
			return true;
		case Collision.Rise:
		case Collision.Fall:
			if (v.Y > GetMinY(v))
			{
				return true;
			}
			return false;
		case Collision.CeilingRise:
		case Collision.CeilingFall:
			if (v.Y < GetMaxY(v))
			{
				return true;
			}
			return false;
		case Collision.Ledge:
			return ledge;
		default:
			return false;
		}
	}

	public float GetMinY(Vector2 v)
	{
		int num = (int)(v.X / 64f);
		int num2 = (int)(v.Y / 32f);
		float num3 = (v.X - (float)num * 64f) / 64f;
		float num4 = (v.Y - (float)num2 * 32f) / 32f;
		if (num >= 0 && num2 > 0 && num < xSize && (float)num2 < (float)ySize * 2f && collision[num, num2] == Collision.Full && (collision[num, num2 - 1] == Collision.Rise || collision[num, num2 - 1] == Collision.Fall) && num4 < 10f)
		{
			num2--;
			num4++;
		}
		float num5 = num4;
		if (num >= 0 && num2 >= 0 && num < xSize && (float)num2 < (float)ySize * 2f)
		{
			switch (collision[num, num2])
			{
			case Collision.Full:
			case Collision.Null:
			case Collision.Ledge:
				num5 = 0f;
				break;
			case Collision.Rise:
				if (num4 >= 1f - num3)
				{
					num5 = 1f - num3;
				}
				break;
			case Collision.Fall:
				if (num4 >= num3)
				{
					num5 = num3;
				}
				break;
			case Collision.CeilingRise:
				if (num4 < 1f - num3)
				{
					num5 = 0f;
				}
				break;
			case Collision.CeilingFall:
				if (num4 < num3)
				{
					num5 = 0f;
				}
				break;
			}
		}
		return (float)num2 * 32f + num5 * 32f;
	}

	public float GetMaxY(Vector2 v)
	{
		int num = (int)(v.X / 64f);
		int num2 = (int)(v.Y / 32f);
		float num3 = (v.X - (float)num * 64f) / 64f;
		float num4 = (v.Y - (float)num2 * 32f) / 32f;
		float num5 = 1f;
		if (num >= 0 && num2 >= 0 && num < xSize && (float)num2 < (float)ySize * 2f)
		{
			switch (collision[num, num2])
			{
			case Collision.Full:
			case Collision.Null:
				num5 = 1f;
				break;
			case Collision.Rise:
				if (num4 > 1f - num3)
				{
					num5 = 1f;
				}
				break;
			case Collision.Fall:
				if (num4 > num3)
				{
					num5 = 1f;
				}
				break;
			case Collision.CeilingRise:
				if (num4 < 1f - num3)
				{
					num5 = 1f - num3;
				}
				break;
			case Collision.CeilingFall:
				if (num4 < num3)
				{
					num5 = num3;
				}
				break;
			}
		}
		return (float)num2 * 32f + num5 * 32f;
	}

	public void Reset()
	{
		Game1.gameMap.foregroundMgr.Reset();
		Game1.gameMap.rightgreensensors = false;
		Game1.gameMap.leftgreensensors = false;
		Game1.gameMap.bedMode = false;
		Game1.gameMap.bucketKillMode = false;
		Game1.gameMap.chairScreamMode = false;
		Game1.gameMap.dentistChairMode = false;
		Game1.gameMap.alert = false;
		Game1.gameMap.liftOn = false;
		Game1.gameMap.redlights = false;
		Game1.gameMap.noprize = false;
		Game1.gameMap.isPuppeteer = false;
		Game1.gameMap.redLightval = 0f;
		Game1.gameMap.actuallyBlueLights = false;
		Game1.gameMap.electricInFrame = 0f;
		Game1.gameMap.actuallyBlueLightval = 0f;
		Game1.gameMap.liftFrame = 0f;
		Game1.gameMap.moaner = false;
		Game1.gameMap.firstExe = false;
		Game1.gameMap.arrowsOff = false;
		Game1.gameMap.slavachase = false;
		Game1.gameMap.musicRamp = false;
		Game1.gameMap.goryoMode = false;
		Game1.gameMap.goryoAlpha = 0f;
		Game1.gameMap.nekoToasty = false;
		Game1.gameMap.theme.theme = Themes.ThemeType.Marble;
		Game1.gameMap.fog = false;
		Game1.gameMap.water = false;
		Game1.gameMap.dishTransOutFrame = 0f;
		Game1.gameMap.haze = false;
		Game1.gameMap.halfhaze = false;
		Game1.gameMap.drips = false;
		Game1.gameMap.ashes = false;
		Game1.gameMap.yukiDeathFocus = false;
		Game1.gameMap.glows = false;
		Game1.gameMap.hypnograbbed = 0;
		Game1.gameMap.slavapounce = false;
		Game1.gameMap.bgRefractMode = false;
		Game1.gameMap.skullFarm = false;
		Game1.gameMap.lockCharMode = false;
		Game1.gameMap.rain = false;
		Game1.gameMap.fakeCeiling = -1f;
		Game1.gameMap.xmax = -1f;
		Game1.gameMap.xmin = -1f;
		Game1.gameMap.strobe = false;
		Game1.gameMap.warpTrap = false;
		Game1.gameMap.slippyWalls = false;
		Game1.gameMap.wallBlood = false;
		Game1.gameMap.goresploded = 0f;
		Game1.gameMap.blackscreen = false;
		Game1.gameMap.fadingblackscreen = false;
		Game1.gameMap.forceX = -1f;
		Game1.gameMap.forceFrame = 0f;
		Game1.gameMap.lichFreakoutMode = false;
		Game1.gameMap.bucket.Clear();
		Game1.gameMap.liftStopMode = false;
		Game1.gameMap.invalidPhase = GameMap.InvalidPhase.None;
		Game1.gameMap.liftStopVal = 0f;
		Game1.gameMap.puppeteerFrame = 0f;
		Game1.gameMap.tankStopFrame = 0f;
		Game1.gameMap.engied = false;
		Game1.gameMap.engiedFrame = 0f;
		Game1.gameMap.nosplatter = false;
		GameRender.feedbackMode = false;
		GameRender.feedbackReady = false;
		EightBitGame.enabled = false;
		for (int i = 0; i < 5; i++)
		{
			Layer layer = this.layer[i];
			for (int j = 0; j < layer.segment.Length; j++)
			{
				if (layer.segment[j] != null)
				{
					layer.segment[j].hidden = false;
					layer.segment[j].open = false;
					layer.segment[j].frame = 0f;
					layer.segment[j].smashed = false;
				}
			}
		}
		for (int k = 0; k < xSize; k++)
		{
			for (int l = 0; l < ySize * 2; l++)
			{
				collision[k, l] = ocol[k, l];
			}
		}
		scriptMgr.Reset();
	}

	public Map(string path)
	{
		layer = new Layer[5];
		for (int i = 0; i < layer.Length; i++)
		{
			layer[i] = new Layer((Layer.Level)i);
		}
		collision = new Collision[100, 200];
		layer[0].zoom = 0.6f;
		layer[1].zoom = 0.75f;
		layer[2].zoom = 1f;
		layer[3].zoom = 1f;
		layer[4].zoom = 1.25f;
		scriptMgr = new ScriptManager();
		ReadName(path);
	}

	public void UpdateLayerZoom()
	{
		layer[0].zoom = 4f;
		layer[1].zoom = 2f;
		layer[2].zoom = 1f;
		layer[3].zoom = 1f;
		layer[4].zoom = -1f;
		for (int i = 0; i < layer.Length; i++)
		{
			layer[i].adjustedZoom = layer[i].zoom;
		}
	}

	public void DrawCol(SpriteBatch sprite, Texture2D colTex)
	{
		for (int i = 0; i < xSize; i++)
		{
			for (int j = 0; j < ySize * 2; j++)
			{
				if (collision[i, j] != Collision.None)
				{
					Vector2 screenLoc = ScrollManager.GetScreenLoc(new Vector2((float)i * 64f, (float)j * 64f * 0.5f), layer[2].adjustedZoom);
					Rectangle value = default;
					switch (collision[i, j])
					{
					case Collision.Full:
						value.X = 0;
						break;
					case Collision.Rise:
						value.X = 128;
						break;
					case Collision.Fall:
						value.X = 64;
						break;
					case Collision.CeilingRise:
						value.X = 192;
						break;
					case Collision.CeilingFall:
						value.X = 256;
						break;
					}
					value.Width = 64;
					value.Y = 0;
					value.Height = 64;
					sprite.Draw(colTex, screenLoc, value, new Color(new Vector4(1f, 1f, 1f, 0.3f)), 0f, default, new Vector2(ScrollManager.zoom * layer[2].adjustedZoom, ScrollManager.zoom * layer[2].adjustedZoom * 0.5f), SpriteEffects.None, 1f);
				}
			}
		}
	}

	public void Draw(SpriteBatch sprite, int s, int e, Texture2D nullTex, Texture2D vGradTex, Texture2D hGradTex, Texture2D[] mapTex)
	{
		Draw(sprite, s, e, green: false, null, nullTex, vGradTex, hGradTex, mapTex, 1f);
	}

	public void DrawMapBlood(SpriteBatch sprite, Texture2D[] mapTex)
	{
		int num = 2;
		float adjustedZoom = layer[num].adjustedZoom;
		for (int i = 0; i < layer[num].segment.Length; i++)
		{
			if (layer[num].segment[i] == null)
			{
				continue;
			}
			Segment segment = layer[num].segment[i];
			if (segment.idx > -1 && !segment.hidden)
			{
				SegDef segDef = Game1.segDefMgr.segDef[segment.idx];
				if (segDef.flags == 19)
				{
					Vector2 screenLoc = ScrollManager.GetScreenLoc(segment.loc, adjustedZoom);
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc, segDef.sRect, new Color(1f, 0f, 0f, 1f), segment.rotation, segDef.lockLoc, ScrollManager.GetSize(adjustedZoom), SpriteEffects.None, 1f);
				}
			}
		}
	}

	public void DrawPostBGRefract(SpriteBatch sprite, Texture2D[] mapTex)
	{
		int num = 1;
		float adjustedZoom = layer[num].adjustedZoom;
		SpriteTools.BeginAlpha();
		for (int i = bgRefractEndIdx; i < layer[num].segment.Length; i++)
		{
			if (layer[num].segment[i] != null)
			{
				Segment segment = layer[num].segment[i];
				if (segment.idx > -1 && !segment.hidden)
				{
					SegDef segDef = Game1.segDefMgr.segDef[segment.idx];
					Vector2 screenLoc = ScrollManager.GetScreenLoc(segment.loc, adjustedZoom);
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc, segDef.sRect, layer[num].color, 0f, segDef.lockLoc, ScrollManager.GetSize(adjustedZoom), SpriteEffects.None, 1f);
				}
			}
		}
		sprite.End();
	}

	private void DrawMapSeg(SpriteBatch sprite, Texture2D texture, Vector2 position, Rectangle sRect, Color color, float rotation, Vector2 origin, float scale, SpriteEffects se, float layer)
	{
		sprite.Draw(texture, position, new Rectangle(sRect.X * 2, sRect.Y * 2, sRect.Width * 2, sRect.Height * 2), color, rotation, origin * 2f, scale / 2f, se, layer);
	}

	private void DrawMapSeg(SpriteBatch sprite, Texture2D texture, Vector2 position, Rectangle sRect, Color color, float rotation, Vector2 origin, Vector2 scale, SpriteEffects se, float layer)
	{
		sprite.Draw(texture, position, new Rectangle(sRect.X * 2, sRect.Y * 2, sRect.Width * 2, sRect.Height * 2), color, rotation, origin * 2f, scale / 2f, se, layer);
	}

	public void Draw(SpriteBatch sprite, int s, int e, bool green, GameMap gameMap, Texture2D nullTex, Texture2D vGradTex, Texture2D hGradTex, Texture2D[] mapTex, float scale)
	{
		isBlood = false;
		if (gameMap.goryoAlpha >= 1f)
		{
			return;
		}
		for (int i = s; i < e; i++)
		{
			Color color = Color.White;
			if (gameMap == null)
			{
				switch ((Layer.Level)i)
				{
				case Layer.Level.Back2:
					color = Color.DarkGray;
					break;
				case Layer.Level.Back1:
					color = Color.Gray;
					break;
				case Layer.Level.Mid:
					color = Color.White;
					break;
				case Layer.Level.Fore1:
					color = new Color(new Vector4(0.05f, 0.05f, 0.05f, 1f));
					break;
				case Layer.Level.Fore2:
					color = Color.Black;
					break;
				}
			}
			else
			{
				color = layer[i].color;
				if (i == 3)
				{
					color = layer[2].color;
				}
				if (green)
				{
					color = new Color(new Vector4(0f, 1f, 0f, 1f));
					if (gameMap != null)
					{
						Themes.ThemeType theme = gameMap.theme.theme;
						if (theme == Themes.ThemeType.Dark)
						{
							color = new Color(new Vector4(0f, 0.5f, 0f, 1f));
						}
					}
				}
			}
			bool flag = false;
			float num = layer[i].adjustedZoom;
			_ = 3;
			for (int j = 0; j < layer[i].segment.Length; j++)
			{
				if (layer[i].segment[j] == null)
				{
					continue;
				}
				Segment segment = layer[i].segment[j];
				if (segment.idx <= -1 || segment.hidden)
				{
					continue;
				}
				switch (Game1.segDefMgr.segDef[segment.idx].flags)
				{
				case 8:
					num -= 0.05f;
					break;
				case 12:
				{
					for (int l = 0; l < 2; l++)
					{
						Vector2 loc2 = segment.loc;
						loc2 += Game1.segDefMgr.segDef[segment.idx].lockLoc;
						Vector2 screenLoc3 = ScrollManager.GetScreenLoc(segment.loc, num);
						if (!flag)
						{
							SpriteTools.BeginAdditive();
							flag = true;
						}
						float num11 = Game1.gameMap.tvFrame * 6.28f + segment.loc.X;
						num11 *= 15f;
						sprite.Draw(Game1.spritesTex, screenLoc3 * scale, new Rectangle(0, 256, 384, 192), new Color(new Vector4(1f, 0f, 0f, 0.3f)), num11 + (float)l * 3.14f, new Vector2(18f, 96f), ScrollManager.GetSize(num) * 1.3f * scale, SpriteEffects.None, 1f);
						sprite.Draw(Game1.spritesTex, screenLoc3 * scale, new Rectangle(0, 256, 384, 192), new Color(new Vector4(1f, 1f, 1f, 0.1f)), num11 + (float)l * 3.14f, new Vector2(18f, 96f), ScrollManager.GetSize(num) * 2f * scale, SpriteEffects.None, 1f);
					}
					break;
				}
				case 23:
				case 24:
				{
					for (int k = 0; k < 5; k++)
					{
						float num4 = (float)k * 1.256f + gameMap.tvFrame * 6.28f * 3f;
						Vector2 vector = new Vector2((float)Math.Cos(num4), (float)Math.Sin(num4));
						float num5 = 40f;
						float num6 = 120f;
						float num7 = 1f;
						if (Game1.segDefMgr.segDef[segment.idx].flags == 24)
						{
							num5 = 20f;
							num6 = 90f;
							num7 = 0.7f;
						}
						if (!flag)
						{
							SpriteTools.BeginAdditive();
							flag = true;
						}
						float num8 = 1f;
						float num9 = Math.Abs(vector.X * num6 - vector.X * num5);
						if (!(num9 < 10f))
						{
							if (num9 < 20f)
							{
								num8 = (num9 - 10f) / 10f;
							}
							if (vector.Y < 0f)
							{
								num8 += vector.Y;
							}
							if (num8 > 0f)
							{
								sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(segment.loc + new Vector2(vector.X * (num5 + num6) / 2f, vector.X / 5f + vector.Y / 5f), num) * scale, new Rectangle(960, 704, 64, 128), new Color(1f, 1f, 1f, 0.04f * num8), vector.X / -10f + 0.1f, new Vector2(32f, 6f), new Vector2(Math.Abs(vector.X * num6 - vector.X * num5) * 0.02f + 0.1f, 5f * num7) * ScrollManager.cannedDepth[0] * scale, SpriteEffects.None, 1f);
								sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(segment.loc + new Vector2(vector.X * (num5 + num6) / 2f, vector.X / 5f + vector.Y / 5f), num) * scale, new Rectangle(960, 704, 64, 128), new Color(1f, 1f, 1f, 0.04f * num8), vector.X / -10f + 0.1f, new Vector2(32f, 6f), new Vector2(Math.Abs(vector.X * num6 - vector.X * num5) * 0.01f + 0.1f, 4f * num7) * ScrollManager.cannedDepth[0] * scale, SpriteEffects.None, 1f);
								float num10 = (float)Math.Sin(num4 + (float)k + segment.loc.X) * 0.5f + 0.5f;
								sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(segment.loc + new Vector2(vector.X * num5 + vector.X * num6 * num10, vector.X / 5f + vector.Y / 5f), num) * scale, new Rectangle(960, 704, 64, 128), new Color(1f, 1f, 1f, 0.04f * num8), vector.X / -10f + 0.1f, new Vector2(32f, 6f), new Vector2(Math.Abs(vector.X * num6 - vector.X * num5) * 0.001f + 0.1f, 3f * num7) * ScrollManager.cannedDepth[0] * scale, SpriteEffects.None, 1f);
							}
						}
					}
					break;
				}
				case 68:
				{
					Vector2 screenLoc2 = ScrollManager.GetScreenLoc(segment.loc, num);
					PostGlowMgr.AddGlow(screenLoc2, 1f, 0.8f, 0.8f, 2f, 0.25f, 0f);
					break;
				}
				case 67:
				{
					Vector2 screenLoc4 = ScrollManager.GetScreenLoc(segment.loc, num);
					PostGlowMgr.AddGlow(screenLoc4, 1f, 0.8f, 0.8f, 2f, 0.3f, 0f);
					break;
				}
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
				{
					float num2 = 0.3f;
					if (i < 2)
					{
						num2 = 0.5f;
					}
					if (!flag)
					{
						SpriteTools.BeginAdditive();
						flag = true;
					}
					if (gameMap.goryoAlpha > 0f)
					{
						num2 *= 1f - gameMap.goryoAlpha;
					}
					Vector2 loc = segment.loc;
					loc += Game1.segDefMgr.segDef[segment.idx].lockLoc;
					Vector2 screenLoc = ScrollManager.GetScreenLoc(segment.loc, num);
					float rotation = 0f;
					switch (Game1.segDefMgr.segDef[segment.idx].flags)
					{
					case 2:
						rotation = 1.57f;
						break;
					case 3:
						rotation = 1.99f;
						break;
					case 4:
						rotation = 1.1500001f;
						break;
					case 5:
						rotation = 4.71f;
						break;
					case 6:
						rotation = 4.29f;
						break;
					case 7:
						rotation = 5.13f;
						break;
					}
					float num3 = 1f - gameMap.redLightval * 0.85f;
					sprite.Draw(Game1.spritesTex, screenLoc * scale, new Rectangle(0, 256, 384, 192), new Color(new Vector4(1f, num3, num3, 0.7f * Rand.GetRandomFloat(num2 * 0.96f, num2))), rotation, new Vector2(48f, 96f), ScrollManager.GetSize(num) * scale * 1.3f, SpriteEffects.None, 1f);
					if (gameMap.theme.theme != Themes.ThemeType.Lobby && gameMap.theme.theme != Themes.ThemeType.LobbyChute)
					{
						sprite.Draw(Game1.spritesTex, screenLoc * scale, new Rectangle(320, 0, 128, 128), new Color(new Vector4(1f, 0.3f, 0.15f, Rand.GetRandomFloat(num2 * 0.2f, num2 * 0.21f))), rotation, new Vector2(64f, 64f), ScrollManager.GetSize(num) * scale * 1.3f, SpriteEffects.None, 1f);
					}
					PostGlowMgr.AddGlow(screenLoc, 1f, 0.8f, 0.8f, 2f, 0.2f * (1f - Game1.gameMap.goryoAlpha), 1f);
					break;
				}
				}
			}
			if (flag)
			{
				sprite.End();
			}
			bool flag2 = false;
			SpriteTools.BeginAlpha();
			if (i == 4 && gameMap.foregroundMgr.needsDraw)
			{
				gameMap.foregroundMgr.Draw(sprite);
			}
			_ = 1;
			num = layer[i].adjustedZoom;
			for (int m = 0; m < layer[i].segment.Length; m++)
			{
				if (layer[i].segment[m] == null)
				{
					continue;
				}
				Segment segment2 = layer[i].segment[m];
				if (segment2.idx <= -1 || segment2.hidden)
				{
					continue;
				}
				SegDef segDef = Game1.segDefMgr.segDef[segment2.idx];
				if (segDef.flags == 8)
				{
					num -= 0.05f;
					if (!flag2)
					{
						flag2 = true;
						if (i == 3)
						{
							color = layer[3].color;
							if (Game1.gameMap.yukiDeathFocus && i > 2)
							{
								float num12 = (float)(int)color.A / 256f;
								num12 *= 1f - Game1.gameMap.yukiDeathFrame;
								color.A = (byte)(num12 * 256f);
							}
						}
					}
				}
				Vector2 screenLoc5 = ScrollManager.GetScreenLoc(segment2.loc, num);
				int num13 = 0;
				float num14 = 0f;
				if (mapTex[segDef.texIdx] == null)
				{
					continue;
				}
				switch (segDef.flags)
				{
				case 19:
					isBlood = true;
					break;
				case 18:
					if (Game1.gameMap.theme.theme == Themes.ThemeType.Lift)
					{
						PostGlowMgr.AddGlow(screenLoc5, 0.85f + 0.15f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X), 0.85f + 0.15f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X), 0.85f + 0.15f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X + segment2.loc.X), 1.7f + 0.05f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X), 0.125f, 0.2f + 0.05f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X * segment2.loc.X));
					}
					else if (!(gameMap.goryoAlpha > 0f))
					{
						PostGlowMgr.AddGlow(screenLoc5, 0.85f + 0.15f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X), 0.85f + 0.15f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.Y), 0.85f + 0.15f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X + segment2.loc.Y), 3.7f + 0.05f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X - segment2.loc.Y), 0.125f, 0.2f + 0.05f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X * segment2.loc.Y));
					}
					break;
				case 9:
					num13 = (int)(Game1.gameMap.tvFrame * 194f) + (int)segment2.loc.Y;
					num13 %= 194;
					num13 = ((num13 >= 97) ? 194 : (num13 * 2));
					num14 = Rand.GetRandomFloat(0.5f, 1f);
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, new Rectangle(185, 967 + num13, 145, 115), green ? new Color(0f, num14, 0f, 1f) : new Color(num14, num14, num14, 1f), segment2.rotation, default, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
					if (num13 < 15 || (num13 > 100 && num13 < 115))
					{
						sprite.Draw(Game1.spritesTex, screenLoc5 * scale, new Rectangle(653 + Rand.GetRandomInt(0, 60), 399, 29, 23), green ? new Color(0f, 1f, 0f, Rand.GetRandomFloat(0.4f, 0.7f)) : new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.4f, 0.7f)), segment2.rotation, default, ScrollManager.GetSize(num) * 5f * scale, SpriteEffects.None, 1f);
					}
					break;
				case 63:
					if (Game1.gameMap.updating)
					{
						Game1.spriteMan.AddSprite(25, segment2.loc, default, Rand.GetRandomFloat(0.1f, 1f), 0, 0);
						Game1.spriteMan.AddSprite(0, segment2.loc, Rand.GetRandomVec2(-500f, 500f, -500f, 500f), 1f, 0, 0);
					}
					break;
				case 10:
					num13 = (int)(Game1.gameMap.tvFrame * 194f) + (int)segment2.loc.Y;
					num13 %= 194;
					num13 = ((num13 >= 97) ? 194 : (num13 * 2));
					num14 = Rand.GetRandomFloat(0.85f, 1f);
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, new Rectangle(186, 967 + num13, 130, 85), green ? new Color(0f, num14, 0f, 1f) : new Color(num14, num14, num14, 1f), segment2.rotation, default, ScrollManager.GetSize(num) * 0.85f * scale, SpriteEffects.None, 1f);
					if (num13 < 15 || (num13 > 100 && num13 < 115))
					{
						sprite.Draw(Game1.spritesTex, screenLoc5 * scale, new Rectangle(653 + Rand.GetRandomInt(0, 60), 399, 22, 17), green ? new Color(0f, 1f, 0f, Rand.GetRandomFloat(0.4f, 0.7f)) : new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.4f, 0.7f)), segment2.rotation, default, ScrollManager.GetSize(num) * 5f * scale, SpriteEffects.None, 1f);
					}
					break;
				case 11:
					num13 = (int)(Game1.gameMap.tvFrame * 194f) + (int)segment2.loc.Y;
					num13 %= 194;
					num13 = ((num13 >= 97) ? 194 : (num13 * 2));
					num14 = Rand.GetRandomFloat(0.5f, 1f);
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, new Rectangle(188, 967 + num13, 120, 80), green ? new Color(0f, num14, 0f, 1f) : new Color(num14, num14, num14, 1f), segment2.rotation, default, ScrollManager.GetSize(num) * 0.5f * scale, SpriteEffects.None, 1f);
					if (num13 < 15 || (num13 > 100 && num13 < 115))
					{
						sprite.Draw(Game1.spritesTex, screenLoc5 * scale, new Rectangle(653 + Rand.GetRandomInt(0, 60), 399, 12, 8), green ? new Color(0f, 1f, 0f, Rand.GetRandomFloat(0.4f, 0.7f)) : new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.4f, 0.7f)), segment2.rotation, default, ScrollManager.GetSize(num) * 5f * scale, SpriteEffects.None, 1f);
					}
					break;
				case 57:
					num13 = (int)(Game1.gameMap.tvFrame * 1024f);
					num13 %= 32;
					num13 = ((num13 >= 16) ? ((num13 - 16) * 2) : 0);
					num14 = (gameMap.arrowsOff ? 0f : Rand.GetRandomFloat(0.5f, 1f));
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, new Rectangle(0, 1088 + (32 - num13), 64, 32), green ? new Color(0f, num14, 0f, 1f) : new Color(num14, num14, num14, 1f), segment2.rotation, default, ScrollManager.GetSize(num) * new Vector2(0.95f, 1.3f) * scale, SpriteEffects.FlipVertically, 1f);
					break;
				case 59:
					num13 = (int)(Game1.gameMap.tvFrame * 1024f);
					num13 %= 32;
					num13 = ((num13 >= 16) ? ((num13 - 16) * 2) : 0);
					num14 = (gameMap.arrowsOff ? 0f : Rand.GetRandomFloat(0.5f, 1f));
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, new Rectangle(0, 1088 + (32 - num13), 64, 32), green ? new Color(0f, num14, 0f, 1f) : new Color(num14, num14, num14, 1f), segment2.rotation, default, ScrollManager.GetSize(num) * new Vector2(0.95f, 1.3f) * scale, SpriteEffects.None, 1f);
					break;
				case 60:
					num13 = (int)(Game1.gameMap.tvFrame * 1024f);
					num13 %= 32;
					num13 = ((num13 >= 16) ? ((num13 - 16) * 4) : 0);
					num14 = (gameMap.arrowsOff ? 0f : Rand.GetRandomFloat(0.5f, 1f));
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, new Rectangle(num13, 1047, 64, 41), green ? new Color(0f, num14, 0f, 1f) : new Color(num14, num14, num14, 1f), segment2.rotation, default, ScrollManager.GetSize(num) * new Vector2(0.95f, 1.1f) * scale, SpriteEffects.FlipHorizontally, 1f);
					break;
				case 58:
					num13 = (int)(Game1.gameMap.tvFrame * 1024f);
					num13 %= 32;
					num13 = ((num13 >= 16) ? ((num13 - 16) * 4) : 0);
					num14 = (gameMap.arrowsOff ? 0f : Rand.GetRandomFloat(0.5f, 1f));
					DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, new Rectangle(num13, 1047, 64, 41), green ? new Color(0f, num14, 0f, 1f) : new Color(num14, num14, num14, 1f), segment2.rotation, default, ScrollManager.GetSize(num) * new Vector2(0.95f, 1.1f) * scale, SpriteEffects.None, 1f);
					break;
				case 13:
					sprite.Draw(Game1.spritesTex, screenLoc5 * scale, new Rectangle(384, 448, 128, 128), color, Game1.gameMap.tvFrame * 6.28f * 15f, new Vector2(64f, 64f), ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
					break;
				case 22:
				{
					float bigTvFrame = Game1.gameMap.bigTvFrame;
					for (bigTvFrame += (segment2.loc.X + segment2.loc.Y) / 5f; bigTvFrame > 22f; bigTvFrame -= 22f)
					{
					}
					if (bigTvFrame < 5f)
					{
						Rectangle sRect2 = new Rectangle(668, 660, 420, 234);
						sRect2.X += (int)(bigTvFrame / 5f * 180f);
						sRect2.Y += (int)(bigTvFrame / 5f * 180f);
						Color color2 = color;
						float num19 = 1f;
						if (bigTvFrame < 0.5f)
						{
							num19 = bigTvFrame * 2f;
						}
						DrawMapSeg(color: (!green) ? new Color(new Vector4(num19, num19, num19, 1f)) : new Color(new Vector4(0f, num19, 0f, 1f)), sprite: sprite, texture: Game1.mapsTex[7], position: screenLoc5 * scale, sRect: sRect2, rotation: 0f, origin: default, scale: ScrollManager.GetSize(num) * scale, se: SpriteEffects.None, layer: 1f);
						if (bigTvFrame > 4f)
						{
							TVDraw(sprite, screenLoc5 * scale, default, num, 271, color, 1f, 1f, 1f, bigTvFrame - 4f, scale);
						}
						break;
					}
					if (bigTvFrame < 8f)
					{
						TVDraw(sprite, screenLoc5 * scale, default, num, 271, color, 1f, 1f, 1f, 1f, scale);
						float a = 1f;
						if (bigTvFrame < 6f)
						{
							a = bigTvFrame - 5f;
						}
						TVDraw(sprite, screenLoc5 * scale, new Vector2(224f, 121f), num, 274, color, 1f, 1f, 1f, a, scale);
						if (bigTvFrame > 7f)
						{
							TVDraw(sprite, screenLoc5 * scale, default, num, 271, color, 1f, 1f, 1f, bigTvFrame - 7f, scale);
						}
						break;
					}
					if (bigTvFrame < 15f)
					{
						TVDraw(sprite, screenLoc5 * scale, default, num, 271, color, 1f, 1f, 1f, 1f, scale);
						float a2 = 1f;
						if (bigTvFrame < 9f)
						{
							a2 = bigTvFrame - 8f;
						}
						TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, 100f), num, 275, color, 1f, 1f, 1f, a2, scale);
						if (bigTvFrame >= 9f)
						{
							a2 = 1f;
							float y = 160f;
							if (bigTvFrame < 11.1f)
							{
								a2 = bigTvFrame - 9f;
								if (a2 > 1f)
								{
									a2 = 1f;
								}
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, 276, color, 1f, 1f, 1f, a2, scale);
							}
							else if (bigTvFrame < 12.2f)
							{
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, 277, color, 1f, 1f, 1f, a2, scale);
							}
							else if (bigTvFrame < 13.3f)
							{
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, 278, color, 1f, 1f, 1f, a2, scale);
							}
							else if (bigTvFrame < 14f)
							{
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, 279, color, 1f, 1f, 1f, a2, scale);
							}
							else if (bigTvFrame < 14.2f)
							{
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, 280, color, 1f, 1f, 1f, a2, scale);
							}
							else if (bigTvFrame < 14.4f)
							{
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, 281, color, 1f, 1f, 1f, a2, scale);
							}
							else if (bigTvFrame < 14.5f)
							{
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, 282, color, 1f, 1f, 1f, a2, scale);
							}
							else if (bigTvFrame < 15f)
							{
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, Rand.GetRandomInt(283, 290), color, 1f, 1f, 1f, a2, scale);
							}
							else
							{
								TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, y), num, 290, color, 1f, 1f, 1f, a2, scale);
							}
						}
						if (bigTvFrame > 14f)
						{
							TVDraw(sprite, screenLoc5 * scale, default, num, 271, color, 1f, 1f, 1f, bigTvFrame - 14f, scale);
						}
						break;
					}
					TVDraw(sprite, screenLoc5 * scale, default, num, 271, color, 1f, 1f, 1f, 1f, scale);
					float num20 = (bigTvFrame - 15f) * 2f;
					if (num20 > 1f)
					{
						num20 = 1f;
					}
					TVDraw(sprite, screenLoc5 * scale, new Vector2(32f, 160f), num, 290, color, 1f, 1f, 1f, num20, scale);
					if (bigTvFrame > 18f)
					{
						num20 = bigTvFrame - 18f;
						if (num20 > 1f)
						{
							num20 = 1f;
						}
						TVDraw(sprite, screenLoc5 * scale, default, num, 271, color, 0f, 0f, 0f, num20, scale);
						if (bigTvFrame > 21f)
						{
							num20 = 22f - bigTvFrame;
						}
						TVDraw(sprite, screenLoc5 * scale, new Vector2(206f, 121f), num, 273, color, 1f, 1f, 1f, num20, scale);
					}
					break;
				}
				case 14:
				case 15:
				case 16:
				case 17:
				{
					for (int n = 0; n < 64; n++)
					{
						float num21 = Game1.gameMap.tvFrame * 10f;
						num21 -= (float)(int)num21;
						float num22 = (float)n + num21 * 64f;
						float num23 = (float)Math.Sin((float)n + num21 * 6.28f) * 46f;
						if (num22 > 64f)
						{
							num22 -= 64f;
						}
						num22 -= 32f;
						num22 *= 9f;
						Vector2 vector3 = default;
						switch (segDef.flags)
						{
						case 15:
							vector3 = new Vector2(num22, num23);
							break;
						case 14:
							vector3 = new Vector2(0f - num22, num23);
							break;
						case 16:
							vector3 = new Vector2(num23, 0f - num22);
							break;
						case 17:
							vector3 = new Vector2(num23, num22);
							break;
						}
						Color color3 = color;
						if (Rand.CointToss(0.5f))
						{
							color3.R /= 2;
							color3.G /= 2;
							color3.B /= 2;
						}
						sprite.Draw(Game1.spritesTex, screenLoc5 * scale + vector3 * ScrollManager.GetSize(num) * scale, new Rectangle(512 + n % 4 % 2 * 32, 448 + n % 4 / 2 * 32, 32, 32), color3, Game1.gameMap.tvFrame * 6.28f * 15f + (float)n, new Vector2(16f, 16f), ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
					}
					break;
				}
				case 56:
				{
					DrawMapSeg(sprite, mapTex[14], screenLoc5 * scale, new Rectangle(768, 0, 512, 256), green ? new Color(0f, 1f, 0f, Rand.GetRandomFloat(0.7f, 1f)) : new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.7f, 1f)), segment2.rotation, default, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
					for (int num27 = 0; num27 < 2; num27++)
					{
						DrawMapSeg(sprite, mapTex[14], screenLoc5 * scale + gameMap.mapMonitorLoc * num * ScrollManager.GetSize(num) * scale, new Rectangle(1152, 256, 128, 128), green ? new Color(0f, 1f, 0f, 1f - (float)num27 / 2f) : new Color(1f, 1f, 1f, 1f - (float)num27 / 2f), gameMap.tvFrame * 6.28f * ((num27 == 0) ? (-5f) : 5f), new Vector2(64f, 64f), ScrollManager.GetSize(num) * scale * 0.5f + (float)num27 / 2f, SpriteEffects.None, 1f);
					}
					sprite.Draw(Game1.nullTex, screenLoc5 + new Vector2(0f, gameMap.mapMonitorLoc.Y) * num * ScrollManager.GetSize(num) * scale, new Rectangle(0, 0, 1, 1), green ? new Color(0f, 1f, 0f, 0.25f) : new Color(1f, 1f, 1f, 0.25f), 0f, new Vector2(0f, 0.5f), ScrollManager.GetSize(num) * scale * new Vector2(512f, 3f), SpriteEffects.None, 1f);
					sprite.Draw(Game1.nullTex, screenLoc5 + new Vector2(gameMap.mapMonitorLoc.X, 0f) * num * ScrollManager.GetSize(num) * scale, new Rectangle(0, 0, 1, 1), green ? new Color(0f, 1f, 0f, 0.25f) : new Color(1f, 1f, 1f, 0.25f), 0f, new Vector2(0.5f, 0f), ScrollManager.GetSize(num) * scale * new Vector2(3f, 256f), SpriteEffects.None, 1f);
					sprite.Draw(Game1.mapsTex[14], screenLoc5 + new Vector2(gameMap.mapMonitorLoc.X + 48f, gameMap.mapMonitorLoc.Y - 24f) * num * ScrollManager.GetSize(num) * scale, new Rectangle(768, 256 + (int)(gameMap.tvFrame * 128f), 64, 16), green ? new Color(0f, 1f, 0f, 0.5f) : new Color(1f, 1f, 1f, 0.5f), 0f, new Vector2(0f, 0f), ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
					sprite.Draw(Game1.mapsTex[14], screenLoc5 + new Vector2(494f, 240f) * num * ScrollManager.GetSize(num) * scale, new Rectangle(832, 256 + (int)(gameMap.tvFrame * 256f) % 128, 64, 32), green ? new Color(0f, 1f, 0f, 0.5f) : new Color(1f, 1f, 1f, 0.5f), 0f, new Vector2(64f, 32f), ScrollManager.GetSize(num) * scale * 1.8f, SpriteEffects.None, 1f);
					float num28 = gameMap.tvFrame * 3f;
					num28 -= (float)(int)num28;
					sprite.Draw(Game1.nullTex, screenLoc5, new Rectangle(0, 0, 1, 1), green ? new Color(0f, 1f, 0f, (1f - num28) * 0.3f) : new Color(1f, 1f, 1f, (1f - num28) * 0.3f), 0f, new Vector2(0f, 0f), ScrollManager.GetSize(num) * scale * new Vector2(512f, 256f * num28), SpriteEffects.None, 1f);
					break;
				}
				case 69:
				case 70:
				{
					float num24 = gameMap.tvFrame + segment2.loc.X * 0.11f + segment2.loc.Y * 0.13f;
					num24 *= 10f;
					num24 -= (float)(int)num24;
					int num25 = 0;
					num24 *= 1.5f;
					for (int num26 = 0; num26 < 2; num26++)
					{
						num24 += (float)num26 * 0.02f;
						if (num24 < 0.4f)
						{
							num25 = (int)(num24 * 20f) % 3;
						}
						else if (num24 < 0.5f)
						{
							num25 = 3 + (int)(num24 * 350f) % 2;
						}
						else if (num24 < 0.9f)
						{
							num25 = (int)(num24 * 20f) % 3;
						}
						else if (num24 < 1f)
						{
							num25 = 5 + (int)(num24 * 350f) % 2;
						}
						else
						{
							num25 = ((!(num24 < 1.4f)) ? (7 + (int)(num24 * 350f) % 2) : ((int)(num24 * 20f) % 3));
						}
						DrawMapSeg(sprite, mapTex[16], screenLoc5 + (Rand.CointToss(0.1f) ? Rand.GetRandomVec2(0f, 0f, -5f, -1f) : default(Vector2)), new Rectangle(672 + ((segDef.flags == 70) ? 64 : 0), num25 * 36, 56, 36), green ? new Color(0f, 1f, 0f, 1f - (float)num26 * 0.5f) : new Color(1f, 1f, 1f, 1f - (float)num26 * 0.5f), 0f, new Vector2(0f, 0f), ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
					}
					break;
				}
				case 61:
				case 62:
				{
					float num29 = gameMap.tvFrame + segment2.loc.X * 0.11f + segment2.loc.Y * 0.13f;
					num29 *= 2f;
					num29 -= (float)(int)num29;
					int num30 = (int)(num29 * 6f);
					float num31 = num29 * 6f - (float)num30;
					DrawMapSeg(sprite, mapTex[15], screenLoc5 + (Rand.CointToss(0.1f) ? Rand.GetRandomVec2(0f, 0f, -5f, -1f) : default(Vector2)), new Rectangle(num30 % 2 * 64, 1130 + num30 / 2 * 50, 64, 50), green ? new Color(0f, 1f, 0f, 1f) : new Color(1f, 1f, 1f, 1f), 0f, new Vector2(0f, 0f), ScrollManager.GetSize(num) * scale * ((segDef.flags == 62) ? 1.5f : 1f), SpriteEffects.None, 1f);
					if ((int)(num31 * 10f) % 2 == 0)
					{
						sprite.Draw(Game1.nullTex, screenLoc5, new Rectangle(0, 0, 1, 1), green ? new Color(0f, 1f, 0f, 0.4f) : new Color(1f, 1f, 1f, 0.4f), 0f, new Vector2(0f, 0f), ScrollManager.GetSize(num) * scale * new Vector2(64f, 50f) * ((segDef.flags == 62) ? 1.5f : 1f), SpriteEffects.None, 1f);
					}
					if (num31 < 0.1f)
					{
						num31 = 0.1f - num31;
						sprite.Draw(Game1.nullTex, screenLoc5, new Rectangle(0, 0, 1, 1), green ? new Color(0f, 1f, 0f, num31 * 10f) : new Color(1f, 1f, 1f, num31 * 10f), 0f, new Vector2(0f, 0f), ScrollManager.GetSize(num) * scale * new Vector2(64f, 50f) * ((segDef.flags == 62) ? 1.5f : 1f), SpriteEffects.None, 1f);
					}
					num29 = gameMap.tvFrame + segment2.loc.X * 0.005f + segment2.loc.Y * 0.006f;
					num29 *= 2f;
					num29 -= (float)(int)num29;
					if (num29 >= 0f && num29 < 0.4f)
					{
						float alpha = 1f;
						if (num29 < 0.1f)
						{
							alpha = num29 * 10f;
						}
						if (num29 > 0.3f)
						{
							alpha = (0.4f - num29) * 10f;
						}
						DrawMapSeg(sprite, mapTex[16], screenLoc5, new Rectangle(352 + (Rand.CointToss(0.5f) ? 96 : 0) + Rand.GetRandomInt(0, 48), 352 + Rand.GetRandomInt(0, 32), 48, 32), green ? new Color(0f, 1f, 0f, alpha) : new Color(1f, 1f, 1f, alpha), 0f, default, ScrollManager.GetSize(num) * scale * new Vector2(0.68f, 0.78f) * 2f * ((segDef.flags == 62) ? 1.5f : 1f), (!Rand.CointToss(0.5f)) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
					}
					if (num29 >= 0.5f && num29 < 0.52f)
					{
						float num32 = num29 - 0.5f;
						num32 *= 30f;
						Rectangle sRect3 = new Rectangle(352 + (int)(num29 * 400f) % 2 * 96 + (int)(num32 * 30f), 416 + (int)(num32 * 20f), 96 - (int)(num32 * 60f), 64 - (int)(num32 * 40f));
						if ((float)sRect3.Width > 0f)
						{
							DrawMapSeg(sprite, mapTex[16], screenLoc5, sRect3, green ? new Color(0f, 1f, 0f, 1f) : new Color(1f, 1f, 1f, 1f), 0f, default, ScrollManager.GetSize(num) * scale * new Vector2(0.68f, 0.78f) * (96f / (float)sRect3.Width) * ((segDef.flags == 62) ? 1.5f : 1f), (!Rand.CointToss(0.5f)) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
						}
					}
					if ((num29 >= 0.6f && num29 < 0.62f) || (num29 > 0.63f && num29 < 0.64f))
					{
						float num33 = num29 - 0.6f;
						num33 *= 30f;
						Rectangle sRect4 = new Rectangle(352 + (int)(num29 * 400f) % 2 * 96 + (int)(num33 * 30f), 480 + (int)(num33 * 20f), 96 - (int)(num33 * 60f), 64 - (int)(num33 * 40f));
						if ((float)sRect4.Width > 0f)
						{
							DrawMapSeg(sprite, mapTex[16], screenLoc5, sRect4, green ? new Color(0f, 1f, 0f, 1f) : new Color(1f, 1f, 1f, 1f), 0f, default, ScrollManager.GetSize(num) * scale * new Vector2(0.68f, 0.78f) * (96f / (float)sRect4.Width) * ((segDef.flags == 62) ? 1.5f : 1f), (!Rand.CointToss(0.5f)) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
						}
					}
					if (num29 >= 0.7f && num29 < 1f)
					{
						float alpha2 = 1f;
						if (num29 < 0.8f)
						{
							alpha2 = (num29 - 0.7f) * 10f;
						}
						if (num29 > 0.9f)
						{
							alpha2 = (1f - num29) * 10f;
						}
						DrawMapSeg(sprite, mapTex[16], screenLoc5, new Rectangle(352 + (Rand.CointToss(0.5f) ? 96 : 0) + Rand.GetRandomInt(0, 48), 352 + Rand.GetRandomInt(0, 32), 48, 32), green ? new Color(0f, 1f, 0f, alpha2) : new Color(1f, 1f, 1f, alpha2), 0f, default, ScrollManager.GetSize(num) * scale * new Vector2(0.68f, 0.78f) * 2f * ((segDef.flags == 62) ? 1.5f : 1f), (!Rand.CointToss(0.5f)) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
					}
					break;
				}
				case 25:
				case 26:
				case 27:
				case 28:
				case 29:
				case 30:
				case 31:
				case 32:
				case 33:
				case 34:
				{
					float num15 = gameMap.tvFrame + segment2.loc.X * 0.11f + segment2.loc.Y * 0.13f;
					num15 *= 2f;
					if (gameMap.theme.theme == Themes.ThemeType.Dark)
					{
						num15 *= 4f;
					}
					num15 -= (float)(int)num15;
					Rectangle sRect = new Rectangle(1152, 0, 128, 128);
					float num16 = num15 * 5f;
					float num17 = num16 - (float)(int)num16;
					if (num17 > 0.9f)
					{
						float num18 = (num17 - 0.9f) * 10f;
						num18 *= 3.14f;
						sRect.Y = sRect.Y + 64 + (int)(Math.Cos(num18) * -64.0);
					}
					sRect.Y += 128 * (int)num16;
					Vector2 vector2 = new Vector2(1f, 1f);
					float randomFloat = Rand.GetRandomFloat(0.6f, 0.7f);
					if (Rand.CointToss(0.02f))
					{
						sRect.Y += 10;
					}
					if (gameMap.theme.theme == Themes.ThemeType.Dark && (int)(num15 * 80f) % 2 == 0)
					{
						sRect.X -= 128;
					}
					if (gameMap.theme.theme == Themes.ThemeType.Tank)
					{
						sRect.Y += 256;
						if ((int)num16 != 4)
						{
							if ((int)num16 % 2 == 0)
							{
								if (!(num17 < 0.4f))
								{
									if (num17 < 0.5f)
									{
										sRect.X -= (int)((num17 - 0.4f) * 10f * 128f);
									}
									else
									{
										sRect.X -= 128;
									}
								}
							}
							else if (num17 < 0.4f)
							{
								sRect.X -= 128;
							}
							else if (num17 < 0.5f)
							{
								sRect.X -= (int)((0.5f - num17) * 10f * 128f);
							}
						}
					}
					switch (segDef.flags)
					{
					case 26:
						vector2 = new Vector2(1f, 1f);
						break;
					case 28:
						vector2 = new Vector2(1f, 1f) * 0.75f;
						break;
					case 30:
						vector2 = new Vector2(1f, 1f) * 0.5f;
						break;
					case 32:
						vector2 = new Vector2(1f, 1f) * 0.75f * 0.5f;
						break;
					case 34:
						vector2 = new Vector2(1f, 1f) * 0.25f;
						break;
					case 25:
						vector2 = new Vector2(1.5f, 1f);
						break;
					case 27:
						vector2 = new Vector2(1.5f, 1f) * 0.75f;
						break;
					case 29:
						vector2 = new Vector2(1.5f, 1f) * 0.5f;
						break;
					case 31:
						vector2 = new Vector2(1.5f, 1f) * 0.75f * 0.5f;
						break;
					case 33:
						vector2 = new Vector2(1.5f, 1f) * 0.25f;
						break;
					}
					Map map = this;
					SpriteBatch sprite2 = sprite;
					Texture2D texture;
					if (gameMap.theme.theme == Themes.ThemeType.Dark)
					{
						texture = mapTex[10];
					}
					else
					{
						texture = ((gameMap.theme.theme == Themes.ThemeType.Tank) ? mapTex[12] : mapTex[8]);
					}
					map.DrawMapSeg(sprite2, texture, screenLoc5 * scale, sRect, green ? new Color(0f, randomFloat, 0f, 1f) : new Color(randomFloat, randomFloat, randomFloat, 1f), segment2.rotation, default, vector2 * ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
					break;
				}
				}
				bool flag3 = false;
				if (i == 1 && drewBGRefract && segDef.flags != 51)
				{
					if (bgRefractEndIdx < 0)
					{
						bgRefractEndIdx = m;
					}
					flag3 = true;
				}
				if (!flag3)
				{
					switch (segDef.flags)
					{
					case 51:
						if (gameMap.bgRefractMode)
						{
							for (int num35 = 0; num35 < 3; num35++)
							{
								Rectangle sRect6 = new Rectangle
								{
									X = 880,
									Y = 243,
									Height = 384,
									Width = 128
								};
								sRect6.Y += 384;
								int num36 = (int)(segment2.loc.X * 3f + segment2.loc.Y + (float)m + gameMap.tvFrame * 384f * (4f + (float)(num35 * 3)));
								num36 %= 384;
								sRect6.Y -= num36;
								DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5, sRect6, new Color(1f, 0f, 0f, 1f), segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * new Vector2(1f, 2f), (num35 == 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 0f);
							}
							drewBGRefract = true;
							bgRefractEndIdx = -1;
						}
						else
						{
							gameMap.bgRefractMode = true;
						}
						break;
					case 21:
					{
						float num39 = 1f - Game1.gameMap.goryoAlpha;
						if (gameMap.theme.theme == Themes.ThemeType.Aquarium)
						{
							DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, new Color(0.5f, 1f, 1f, num39 * (float)Math.Cos(Game1.gameMap.tvFrame * 6.28f * 7f + segment2.loc.X + segment2.loc.Y + segment2.rotation) * 0.3f + 0.7f), segment2.rotation, segDef.lockLoc, ScrollManager.cannedDepth[0] * Rand.GetRandomFloat(0.99f, 1f) * scale, SpriteEffects.None, 1f);
						}
						else
						{
							DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, new Color(1f, 1f, 1f, num39 * ((float)Math.Cos(Game1.gameMap.tvFrame * 6.28f * 7f + segment2.loc.X + segment2.loc.Y + segment2.rotation) * 0.3f + 0.7f)), segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * Rand.GetRandomFloat(0.99f, 1f) * scale, SpriteEffects.None, 1f);
						}
						break;
					}
					case 35:
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, green ? new Color(0f, 1f, 0f, Rand.GetRandomFloat(0.5f, 1f)) : new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.5f, 1f)), segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						PostGlowMgr.AddGlow(screenLoc5, 1f, 0.6f, 0.3f, Rand.GetRandomFloat(3.8f, 3.9f), Rand.GetRandomFloat(0.2f, 0.25f) * 0.5f, 0f);
						break;
					case 40:
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, segment2.rotation - gameMap.tvFrame * 6.28f * 2f, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					case 39:
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, segment2.rotation + gameMap.tvFrame * 6.28f * 2f, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					case 38:
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, segment2.rotation - gameMap.tvFrame * 6.28f, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					case 37:
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, segment2.rotation + gameMap.tvFrame * 6.28f, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					case 55:
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, new Color(1f, 1f, 1f, 1f), segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						PostGlowMgr.AddGlow(screenLoc5, 0.85f + 0.15f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X), 0.6f, 0.6f, 1f + 0.05f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X - segment2.loc.Y), 0.45f, 0.2f + 0.05f * (float)Math.Sin(Game1.gameMap.tvFrame * 6.28f + segment2.loc.X * segment2.loc.Y));
						break;
					case 25:
					case 26:
					case 27:
					case 28:
					case 29:
					case 30:
					case 31:
					case 32:
					case 33:
					case 34:
						if (gameMap.fadingblackscreen)
						{
							float num37 = 1f;
							if (segment2.loc.X < 200f)
							{
								num37 = (200f - segment2.loc.X) / 300f;
							}
							else
							{
								num37 = ((!(segment2.loc.X > (float)xSize * 64f - 200f)) ? 0f : ((segment2.loc.X - ((float)xSize * 64f - 200f)) / 300f));
							}
							DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, green ? new Color(0f, num37, 0f, 1f) : new Color(num37, num37, num37, 1f), segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						}
						else if (gameMap.blackscreen)
						{
							DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, new Color(0f, 0f, 0f, 1f), segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						}
						else
						{
							DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						}
						break;
					case 36:
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, (float)Math.Cos((float)segment2.idx + segment2.loc.X * 0.3f + segment2.loc.Y * 0.7f + gameMap.tvFrame * 5f * 6.28f) * 0.02f, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					case 41:
					{
						Vector2 vector5 = screenLoc5;
						if (gameMap.descentSpeed > 0f)
						{
							vector5.Y += (float)Math.Sin(gameMap.descentFrame * gameMap.descentSpeed * 2f) * gameMap.descentSpeed * 0.7f * num;
						}
						DrawMapSeg(sprite, mapTex[segDef.texIdx], vector5 * scale, segDef.sRect, color, segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					}
					case 42:
					case 43:
					case 46:
					{
						float num40 = segment2.rotation;
						if (segDef.flags == 42)
						{
							num40 += (float)Math.Cos(gameMap.tvFrame * 6.28f * 7f + segment2.loc.X + segment2.loc.Y) * 0.1f;
						}
						if (segDef.flags == 43)
						{
							num40 += (float)Math.Cos(gameMap.tvFrame * 6.28f * 7f + segment2.loc.X + segment2.loc.Y) * 0.015f;
						}
						if (segDef.flags == 46)
						{
							num40 += (float)Math.Cos(gameMap.tvFrame * 6.28f * 4f + (float)m + num + segment2.loc.X + segment2.loc.Y) * 0.015f;
						}
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, num40, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					}
					case 44:
					case 49:
					{
						float num34 = gameMap.tankFrame * 6.28f;
						if (gameMap.theme.theme != Themes.ThemeType.Tank && gameMap.theme.theme != Themes.ThemeType.TankBrite)
						{
							num34 = 0f;
						}
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, segment2.rotation + num34, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					}
					case 45:
						if (segDef.flags == 45)
						{
							float num38 = gameMap.tankFrame * 12f;
							if (gameMap.theme.theme != Themes.ThemeType.Tank && gameMap.theme.theme != Themes.ThemeType.TankBrite)
							{
								num38 = 0f;
							}
							num38 += 0.5f;
							num38 -= (float)(int)num38;
							Vector2 vector4 = new Vector2((float)Math.Cos(segment2.rotation) * num38 * 128f, (float)Math.Sin(segment2.rotation) * num38 * 128f);
							screenLoc5 = ScrollManager.GetScreenLoc(segment2.loc + vector4, num);
						}
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						break;
					default:
						if (segment2.open)
						{
							if (segment2.rotation < 0f)
							{
								segment2.rotation += 6.28f;
							}
							if (segment2.rotation > 6.28f)
							{
								segment2.rotation -= 6.28f;
							}
							if (segment2.rotation > 4.46f && segment2.rotation < 4.96f)
							{
								screenLoc5.X -= (float)segDef.sRect.Height * ScrollManager.GetSize(num);
								screenLoc5.X += (float)segDef.sRect.Height * ScrollManager.GetSize(num) * segment2.frame;
							}
							else if (segment2.rotation > 1.32f && segment2.rotation < 1.82f)
							{
								screenLoc5.X += (float)segDef.sRect.Height * ScrollManager.GetSize(num);
								screenLoc5.X -= (float)segDef.sRect.Height * ScrollManager.GetSize(num) * segment2.frame;
							}
							else
							{
								screenLoc5.Y -= (float)segDef.sRect.Height * ScrollManager.GetSize(num);
								screenLoc5.Y += (float)segDef.sRect.Height * ScrollManager.GetSize(num) * segment2.frame;
							}
						}
						else if (segment2.frame > 0f)
						{
							if (segment2.rotation > 4.46f && segment2.rotation < 4.96f)
							{
								screenLoc5.X += (float)segDef.sRect.Height * ScrollManager.GetSize(num) * segment2.frame;
							}
							else if (segment2.rotation > 1.32f && segment2.rotation < 1.82f)
							{
								screenLoc5.X -= (float)segDef.sRect.Height * ScrollManager.GetSize(num) * segment2.frame;
							}
							else
							{
								screenLoc5.Y -= (float)segDef.sRect.Height * ScrollManager.GetSize(num) * segment2.frame;
							}
						}
						if (segment2.smashed)
						{
							Rectangle sRect5 = segDef.sRect;
							sRect5.X += 576;
							DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, sRect5, color, segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						}
						else
						{
							DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, segDef.sRect, color, segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
						}
						break;
					case 12:
					case 19:
					case 47:
					case 48:
						break;
					}
				}
				switch (segDef.flags)
				{
				case 50:
				{
					for (int num49 = 0; num49 < 2; num49++)
					{
						float num50 = gameMap.tvFrame + segment2.loc.X * 0.3f + segment2.loc.Y * 0.3f;
						num50 *= 8f;
						num50 += (float)num49 * 0.5f;
						num50 -= (float)(int)num50;
						int num51 = (int)(num50 * 3f);
						num50 *= 3f;
						num50 -= (float)(int)num50;
						Rectangle sRect7 = segDef.sRect;
						sRect7.Y += 50 * (num51 + 1);
						Color color4 = color;
						if (num50 < 0.05f)
						{
							color4.A = (byte)(num50 * 20f * 221f);
						}
						else if (num50 > 0.95f)
						{
							color4.A = (byte)((1f - num50) * 20f * 221f);
						}
						else
						{
							color4.A = 221;
						}
						DrawMapSeg(sprite, mapTex[segDef.texIdx], screenLoc5 * scale, sRect7, color4, segment2.rotation, segDef.lockLoc, ScrollManager.GetSize(num) * scale, SpriteEffects.None, 1f);
					}
					break;
				}
				case 47:
				{
					SpriteTools.End();
					SpriteTools.BeginAdditive();
					PostGlowMgr.AddGlow(screenLoc5, gameMap.leftgreensensors ? 0f : 1f, gameMap.leftgreensensors ? 1f : 0f, 0f, 2f, 0.25f, 1f);
					for (int num46 = 0; num46 < 8; num46++)
					{
						sprite.Draw(Game1.spritesTex, screenLoc5, new Rectangle(0, 320, 385, 64), new Color(gameMap.leftgreensensors ? 0.1f : 1f, gameMap.leftgreensensors ? 1f : 0.1f, 0.1f, Rand.GetRandomFloat(0f, 0.2f)), (float)Math.Cos(gameMap.tvFrame * 6.28f * 2f + (float)num46) * 0.2f + ((segDef.flags == 48) ? 0.6f : (-0.6f)) + 1.57f, new Vector2(20f, 32f), new Vector2(2f, 0.1f) * ScrollManager.GetSize(num), SpriteEffects.None, 1f);
					}
					SpriteTools.End();
					SpriteTools.BeginAlpha();
					break;
				}
				case 48:
				{
					SpriteTools.End();
					SpriteTools.BeginAdditive();
					PostGlowMgr.AddGlow(screenLoc5, gameMap.rightgreensensors ? 0f : 1f, gameMap.rightgreensensors ? 1f : 0f, 0f, 2f, 0.25f, 1f);
					for (int num45 = 0; num45 < 8; num45++)
					{
						sprite.Draw(Game1.spritesTex, screenLoc5, new Rectangle(0, 320, 385, 64), new Color(gameMap.rightgreensensors ? 0.1f : 1f, gameMap.rightgreensensors ? 1f : 0.1f, 0.1f, Rand.GetRandomFloat(0f, 0.2f)), (float)Math.Cos(gameMap.tvFrame * 6.28f * 2f + (float)num45) * 0.2f + ((segDef.flags == 48) ? 0.6f : (-0.6f)) + 1.57f, new Vector2(20f, 32f), new Vector2(2f, 0.1f) * ScrollManager.GetSize(num), SpriteEffects.None, 1f);
					}
					SpriteTools.End();
					SpriteTools.BeginAlpha();
					break;
				}
				case 44:
				{
					for (int num47 = 0; num47 < 6; num47++)
					{
						float num48 = (float)num47 * 6.28f / 12f + gameMap.tvFrame * 6.28f + 0.2616667f;
						if (gameMap.theme.theme != Themes.ThemeType.Tank && gameMap.theme.theme != Themes.ThemeType.TankBrite)
						{
							num48 = (float)num47 * 6.28f / 12f + 0.2616667f;
						}
						while (num48 > 3.14f)
						{
							num48 -= 3.14f;
						}
						num48 += 3.14f;
						DrawMapSeg(sRect: new Rectangle(14, 938, 84, 80), sprite: sprite, texture: mapTex[segDef.texIdx], position: screenLoc5, color: color, rotation: segment2.rotation + num48, origin: new Vector2(43f, 256f), scale: ScrollManager.GetSize(num), se: SpriteEffects.None, layer: 0f);
					}
					break;
				}
				case 20:
				{
					if (i > 2)
					{
						break;
					}
					float num41 = Game1.gameMap.tvFrame * 32f;
					float num42 = 1f - (num41 - (float)(int)num41);
					Vector2 vector6 = segment2.loc + new Vector2((float)Math.Cos(segment2.rotation), (float)Math.Sin(segment2.rotation)) * segDef.lockLoc.X + new Vector2((float)Math.Cos(segment2.rotation + 1.57f), (float)Math.Sin(segment2.rotation + 1.57f)) * segDef.lockLoc.Y;
					vector6 = segment2.loc;
					for (int num43 = 0; num43 < 4; num43++)
					{
						if ((int)num41 % 4 == num43)
						{
							SpriteTools.End();
							SpriteTools.BeginAdditive();
							float num44 = segment2.rotation - 1.57f;
							Vector2 loc3 = vector6 + new Vector2((float)Math.Cos(num44), (float)Math.Sin(num44)) * ((float)num43 * 79.5f);
							sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(loc3, num) * scale, new Rectangle(320, 0, 128, 128), new Color(1f, 0.2f, 0.2f, num42 * 0.65f), 0f, new Vector2(64f, 64f), ScrollManager.GetSize(num) * 0.8f * scale, SpriteEffects.None, 1f);
							sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(loc3, num) * scale, new Rectangle(320, 0, 128, 128), new Color(1f, 0.5f, 0.5f, num42 * 0.65f), 0f, new Vector2(64f, 64f), ScrollManager.GetSize(num) * 0.3f * scale, SpriteEffects.None, 1f);
							sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(loc3, num) * scale, new Rectangle(512, 64, 128, 128), new Color(1f, 0.5f, 0.5f, num42 * 0.65f), Rand.GetRandomFloat(0f, 6.28f), new Vector2(64f, 64f), ScrollManager.GetSize(num) * 0.3f * scale, SpriteEffects.None, 1f);
							SpriteTools.End();
							SpriteTools.BeginAlpha();
						}
					}
					break;
				}
				}
			}
			sprite.End();
		}
		if (e == 5 && gameMap.theme.theme == Themes.ThemeType.PrisonOut)
		{
			if (xSize > 10)
			{
				SpriteTools.BeginAdditive();
				sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(new Vector2(64f * (float)xSize, 64f * (float)ySize * 0.95f), 1f), new Rectangle(320, 0, 128, 128), new Color(1f, 0f, 0f, Rand.GetRandomFloat(0.25f, 0.26f)), 0f, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * Rand.GetRandomFloat(21f, 22f), SpriteEffects.None, 1f);
				sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(new Vector2(64f * (float)xSize, 64f * (float)ySize * 0.95f), 1f), new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.5f, 0.6f)), 0f, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * Rand.GetRandomFloat(16f, 17f), SpriteEffects.None, 1f);
				sprite.End();
			}
			QuakeManager.SetQuake(0.1f);
		}
		if (e == 5 && gameMap.theme.theme == Themes.ThemeType.EscapeOut)
		{
			SpriteTools.BeginAdditive();
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(new Vector2(0f, 64f * (float)ySize * 0.5f), 1f), new Rectangle(320, 0, 128, 128), new Color(1f, 0f, 0f, Rand.GetRandomFloat(0.25f, 0.26f)), 0f, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * Rand.GetRandomFloat(11f, 12f), SpriteEffects.None, 1f);
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(new Vector2(0f, 64f * (float)ySize * 0.5f), 1f), new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.5f, 0.6f)), 0f, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * Rand.GetRandomFloat(12f, 13f), SpriteEffects.None, 1f);
			sprite.End();
		}
		if (e == 5 && gameMap.theme.theme != Themes.ThemeType.Final)
		{
			Vector2 screenLoc6 = ScrollManager.GetScreenLoc(default(Vector2), layer[2].adjustedZoom);
			Vector2 screenLoc7 = ScrollManager.GetScreenLoc(new Vector2((float)xSize * 64f, (float)ySize * 64f), layer[2].adjustedZoom);
			Vector2 screenSize = ScrollManager.screenSize;
			Vector2 vector7 = screenLoc6;
			Vector2 vector8 = screenLoc7;
			if (screenLoc6.X < 0f)
			{
				screenLoc6.X = 0f;
			}
			if (screenLoc6.Y < 0f)
			{
				screenLoc6.Y = 0f;
			}
			if (screenLoc7.X > screenSize.X)
			{
				screenLoc7.X = screenSize.X;
			}
			if (screenLoc7.Y > screenSize.Y)
			{
				screenLoc7.Y = screenSize.Y;
			}
			SpriteTools.BeginAlpha();
			if (screenLoc6.X > 0f && screenLoc6.Y > 0f)
			{
				sprite.Draw(nullTex, new Vector2(0f, 0f), new Rectangle(0, 0, 1, 1), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, default, new Vector2(screenLoc6.X, screenLoc6.Y), SpriteEffects.None, 1f);
			}
			if (screenLoc6.X > 0f)
			{
				sprite.Draw(nullTex, new Vector2(0f, screenLoc6.Y), new Rectangle(0, 0, 1, 1), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, default, new Vector2(screenLoc6.X, screenSize.Y - screenLoc6.Y), SpriteEffects.None, 1f);
			}
			if (vector7.X > -64f)
			{
				sprite.Draw(vGradTex, new Vector2(vector7.X, vector7.Y), new Rectangle(0, 0, 32, 4), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, default, new Vector2(2f, (screenSize.Y - vector7.Y) / 4f), SpriteEffects.None, 1f);
			}
			if (screenLoc6.Y > 0f)
			{
				sprite.Draw(nullTex, new Vector2(screenLoc6.X, 0f), new Rectangle(0, 0, 1, 1), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, default, new Vector2(screenSize.X - screenLoc6.X, screenLoc6.Y), SpriteEffects.None, 1f);
			}
			if (vector7.Y > -64f)
			{
				sprite.Draw(hGradTex, new Vector2(vector7.X, vector7.Y), new Rectangle(0, 0, 4, 32), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, default, new Vector2((screenSize.X - vector7.X) / 4f, 2f), SpriteEffects.FlipVertically, 1f);
			}
			if (screenLoc7.X < screenSize.X && screenLoc7.Y < screenSize.Y)
			{
				sprite.Draw(nullTex, new Vector2(screenLoc7.X, screenLoc7.Y), new Rectangle(1, 1, 1, 1), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, default, new Vector2(screenSize.X - screenLoc7.X, screenSize.Y - screenLoc7.Y), SpriteEffects.None, 1f);
			}
			if (screenLoc7.X < screenSize.X)
			{
				sprite.Draw(nullTex, new Vector2(screenLoc7.X, screenLoc6.Y), new Rectangle(1, 1, 1, 1), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, default, new Vector2(screenSize.X - screenLoc7.X, screenLoc7.Y - screenLoc6.Y), SpriteEffects.None, 1f);
			}
			if (vector8.X < screenSize.X + 64f)
			{
				sprite.Draw(vGradTex, new Vector2(vector8.X, vector7.Y), new Rectangle(0, 0, 32, 4), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, new Vector2(32f, 0f), new Vector2(2f, (screenSize.Y - vector7.Y) / 4f), SpriteEffects.FlipHorizontally, 1f);
			}
			if (screenLoc7.Y < screenSize.Y)
			{
				sprite.Draw(nullTex, new Vector2(screenLoc6.X, screenLoc7.Y), new Rectangle(1, 1, 1, 1), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, default, new Vector2(screenLoc7.X - screenLoc6.X, screenSize.Y - screenLoc7.Y), SpriteEffects.None, 1f);
			}
			if (vector8.Y < screenSize.Y + 64f)
			{
				sprite.Draw(hGradTex, new Vector2(vector7.X, vector8.Y), new Rectangle(0, 0, 4, 32), new Color(new Vector4(0f, 0f, 0f, 1f)), 0f, new Vector2(0f, 32f), new Vector2((screenSize.X - vector7.X) / 4f, 2f), SpriteEffects.None, 1f);
			}
			sprite.End();
		}
	}

	private void TVDraw(SpriteBatch sprite, Vector2 orig, Vector2 offset, float aZ, int idx, Color color, float r, float g, float b, float a, float scale)
	{
		DrawMapSeg(color: new Color(r * (float)(int)color.R / 256f, g * (float)(int)color.G / 256f, b * (float)(int)color.B / 256f, a * (float)(int)color.A / 256f), sprite: sprite, texture: Game1.mapsTex[7], position: orig + offset * ScrollManager.GetSize(aZ) * scale, sRect: Game1.segDefMgr.segDef[idx].sRect, rotation: 0f, origin: Game1.segDefMgr.segDef[idx].lockLoc, scale: ScrollManager.GetSize(aZ) * scale, se: SpriteEffects.None, layer: 1f);
	}

	public void Read(string path)
	{
		this.path = path;
		Read();
	}

	public void ReadName(string name)
	{
		path = "maps/data/" + name + ".zkx";
		this.name = name;
		Read();
	}

	public void Read()
	{
		BinaryReader binaryReader = new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read));
		xSize = binaryReader.ReadInt32();
		ySize = binaryReader.ReadInt32();
		for (int i = 0; i < layer.Length; i++)
		{
			for (int j = 0; j < layer[i].segment.Length; j++)
			{
				if (binaryReader.ReadBoolean())
				{
					if (layer[i].segment[j] == null)
					{
						layer[i].segment[j] = new Segment();
					}
					layer[i].segment[j].idx = binaryReader.ReadInt32();
					layer[i].segment[j].loc.X = binaryReader.ReadSingle();
					layer[i].segment[j].loc.Y = binaryReader.ReadSingle();
					layer[i].segment[j].rotation = binaryReader.ReadSingle();
					if (i == 2)
					{
						layer[i].segment[j].CalculateRect(Game1.segDefMgr.segDef[layer[i].segment[j].idx]);
					}
				}
				else if (layer[i].segment[j] != null)
				{
					layer[i].segment[j] = null;
				}
			}
		}
		mapWidth = xSize / 10;
		mapHeight = ySize / 10;
		ocol = new Collision[xSize, ySize * 2];
		for (int k = 0; k < xSize; k++)
		{
			for (int l = 0; l < ySize * 2; l++)
			{
				collision[k, l] = (Collision)binaryReader.ReadByte();
				ocol[k, l] = collision[k, l];
			}
		}
		scriptMgr.Init(binaryReader);
		binaryReader.Close();
		Game1.loader.LoadMapTextures(this);
	}
}
