using director;
using Microsoft.Xna.Framework;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.world;

namespace Yuki_Win.maps;

public class TransitionManager
{
	public enum TransitionDirection
	{
		Left,
		Right,
		Up,
		Down,
		Warp
	}

	public float outFrame;

	public float inFrame;

	public float levelInFrame;

	public float pauseResumeFrame;

	public string dest;

	public int srcX;

	public int srcY;

	public int dirX;

	public int dirY;

	public Vector2 enterVec;

	public int enterFace;

	public CharUpdate.State enterState;

	public int transitionOwner;

	public string enterMap;

	public string enterWorld;

	public Vector2 warpVec;

	public TransitionDirection direction;

	public bool mapsSynced;

	public TransitionManager()
	{
		dest = "";
	}

	public void DoTrans(string dest, Vector2 loc)
	{
		warpVec = loc;
		this.dest = dest;
		direction = TransitionDirection.Warp;
		outFrame = 1f;
	}

	private void ReadyCharForTransition(int ID)
	{
		if (!Game1.character[ID].charUpdate.charGrab.grabbing)
		{
			return;
		}
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (Game1.character[i].exists && Game1.character[i].charUpdate.charGrab.grabbedByChar == ID)
			{
				Game1.character[ID].charUpdate.loc = Game1.character[i].charUpdate.loc;
			}
		}
	}

	public void Update(GameMap gameMap, NeighborManager nMgr)
	{
		Map map = gameMap.CurMap();
		if (levelInFrame > 0f)
		{
			levelInFrame -= FMan.frameTime;
		}
		if (pauseResumeFrame > 0f)
		{
			pauseResumeFrame -= FMan.frameTime * 5f;
		}
		bool flag = gameMap.theme.theme == Themes.ThemeType.TankBrite && direction == TransitionDirection.Warp;
		if (outFrame > 0f)
		{
			if (gameMap.theme.theme == Themes.ThemeType.Descent)
			{
				outFrame -= FMan.frameTime * 0.5f;
			}
			else if ((gameMap.theme.theme == Themes.ThemeType.TankBrite || gameMap.theme.theme == Themes.ThemeType.Tank || gameMap.theme.theme == Themes.ThemeType.Lift) && direction == TransitionDirection.Warp)
			{
				outFrame -= FMan.frameTime * 0.5f;
			}
			else
			{
				outFrame -= FMan.frameTime * 4f;
			}
			if (!(outFrame <= 0f))
			{
				return;
			}
			Vector2 vector = default;
			Map.Collision col = map.GetCol(Game1.character[transitionOwner].charUpdate.loc + new Vector2(0f, 0f));
			if (direction != TransitionDirection.Warp)
			{
				vector = Game1.neighborMgr.GetTransitionOffset(srcX, srcY, dirX, dirY, WorldManager.GetWorld());
			}
			gameMap.SetMap(dest);
			dest = "";
			ReadyCharForTransition(transitionOwner);
			Game1.character[transitionOwner].charUpdate.loc += vector;
			Game1.character[transitionOwner].charPhysics.Update(Game1.character[transitionOwner], Game1.character[transitionOwner].charUpdate.netLoc, Game1.character[transitionOwner].charUpdate.face, Game1.character[transitionOwner].charAnim.GetCurFrame(), -1);
			Game1.character[transitionOwner].charPhysics.ResetRope();
			if (direction != TransitionDirection.Warp)
			{
				ScrollManager.scroll += vector;
			}
			switch (direction)
			{
			case TransitionDirection.Left:
				Game1.character[transitionOwner].charUpdate.loc.X -= 64f;
				if (col == Map.Collision.Rise)
				{
					Game1.character[transitionOwner].charUpdate.loc.Y += 32f;
				}
				if (col == Map.Collision.Fall)
				{
					Game1.character[transitionOwner].charUpdate.loc.Y -= 32f;
				}
				break;
			case TransitionDirection.Right:
				Game1.character[transitionOwner].charUpdate.loc.X += 64f;
				if (col == Map.Collision.Rise)
				{
					Game1.character[transitionOwner].charUpdate.loc.Y -= 32f;
				}
				if (col == Map.Collision.Fall)
				{
					Game1.character[transitionOwner].charUpdate.loc.Y += 32f;
				}
				break;
			case TransitionDirection.Up:
				Game1.character[transitionOwner].charUpdate.loc.Y -= 64f;
				if (Game1.character[transitionOwner].charAnim.animName != Game1.character[transitionOwner].GetMeta().wall_run_anim)
				{
					Game1.character[transitionOwner].charUpdate.airJuggleFrame = 1f;
					Game1.character[transitionOwner].charUpdate.airJuggleVec = Game1.character[transitionOwner].charUpdate.loc + new Vector2(0f, -100f);
				}
				break;
			case TransitionDirection.Down:
				Game1.character[transitionOwner].charUpdate.loc.Y += 64f;
				break;
			case TransitionDirection.Warp:
				Game1.character[transitionOwner].charUpdate.loc = warpVec;
				Game1.character[transitionOwner].FloorMe(warpVec);
				ScrollManager.scroll = Game1.character[transitionOwner].charUpdate.loc - new Vector2(0f, 40f);
				break;
			}
			inFrame = 1f;
			Game1.character[transitionOwner].charUpdate.FixNetLoc();
			for (int i = 4; i < Game1.character.Length; i++)
			{
				Game1.character[i].exists = false;
			}
			enterVec = Game1.character[transitionOwner].charUpdate.loc;
			enterFace = Game1.character[transitionOwner].charUpdate.face;
			enterState = Game1.character[transitionOwner].charUpdate.state;
			Game1.spawnMgr.SpawnFamiliar(transitionOwner);
			Game1.levelMgr.SetMapEnterVals(transitionOwner, Game1.character[transitionOwner].charUpdate.hp, Game1.character[transitionOwner].charUpdate.mp);
			if (Game1.levelMgr.currentTrack == 2)
			{
				for (int pn = 0; pn < 4; pn++)
			{
			if (pn == transitionOwner || !Game1.IsPlayerChar(pn))
			{
				continue;
			}
			int num = pn;
				Game1.levelMgr.SetMapEnterVals(num, Game1.character[num].charUpdate.hp, Game1.character[num].charUpdate.mp);
				Game1.character[num].charUpdate.loc = Game1.character[transitionOwner].charUpdate.loc;
				Game1.character[num].charAnim.SetAnim(Game1.character[num].GetMeta().fly_anim, Game1.character[num].charUpdate);
				Game1.character[num].charUpdate.state = CharUpdate.State.Airborne;
				Game1.character[num].charUpdate.traj = Game1.character[transitionOwner].charUpdate.traj;
				if (direction == TransitionDirection.Up && Game1.character[num].charAnim.animName != Game1.character[num].GetMeta().wall_run_anim)
				{
					Game1.character[num].charUpdate.airJuggleFrame = 1f;
					Game1.character[num].charUpdate.airJuggleVec = Game1.character[num].charUpdate.loc + new Vector2(0f, -100f);
				}
				Game1.character[num].charPhysics.Update(Game1.character[num], Game1.character[num].charUpdate.netLoc, Game1.character[num].charUpdate.face, Game1.character[num].charAnim.GetCurFrame(), -1);
				Game1.character[num].charPhysics.ResetRope();
				if (direction == TransitionDirection.Warp)
				{
					Game1.character[num].FloorMe(warpVec);
				}
				Game1.character[num].charUpdate.FixNetLoc();
				Game1.spawnMgr.SpawnFamiliar(num);
			}
			}
			Game1.hud.PickupDeathReset();
			Game1.spriteMan.Reset();
			if (flag)
			{
				gameMap.tankStopFrame = 1f;
			}
			return;
		}
		if (inFrame > 0f)
		{
			float num2 = inFrame;
			if (gameMap.theme.theme == Themes.ThemeType.Descent || direction == TransitionDirection.Warp)
			{
				inFrame -= FMan.frameTime * 0.5f;
			}
			else if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
			{
				inFrame -= FMan.frameTime;
			}
			else
			{
				inFrame -= FMan.frameTime * 4f;
			}
			if ((gameMap.theme.theme == Themes.ThemeType.Tank || gameMap.theme.theme == Themes.ThemeType.TankBrite) && direction == TransitionDirection.Warp && num2 > 0.6f && inFrame <= 0.6f)
			{
				Sound.PlaySnd(Sound.Category.FX, "treads");
			}
			return;
		}
		switch (Game1.levelMgr.currentTrack)
		{
		case 0:
		case 1:
			CheckTrans(0, nMgr, map);
			break;
		case 2:
			CheckTrans(0, nMgr, map);
			for (int ct = 1; ct < 4; ct++)
			{
				if (outFrame <= 0f && Game1.IsPlayerChar(ct))
				{
					CheckTrans(ct, nMgr, map);
				}
			}
			break;
		}
	}

	private void CheckTrans(int ID, NeighborManager nMgr, Map map)
	{
		if (Game1.netSession.IsClient() || (Game1.netSession.IsHost() && Game1.netSession.netGame.IsPanic()) || Game1.sceneMgr.playing || Game1.character[ID].charUpdate.warpFrame > 0f)
		{
			return;
		}
		Vector2 loc = Game1.character[ID].charUpdate.loc;
		Vector2 traj = Game1.character[ID].charUpdate.traj;
		if (Game1.netSession.IsHost() && !mapsSynced)
		{
			return;
		}
		if (Game1.character[ID].charUpdate.charGrab.grabbing)
		{
			for (int i = 0; i < Game1.character.Length; i++)
			{
				if (Game1.character[i].exists && Game1.character[i].charUpdate.charGrab.grabbedByChar == ID)
				{
					loc = Game1.character[i].charUpdate.loc;
					traj = Game1.character[i].charUpdate.traj;
				}
			}
		}
		dirX = 0;
		dirY = 0;
		if (loc.X < 64f && traj.X < 0f && Game1.character[ID].charKeys.keyLeft && nMgr.CheckIsNeighbor(loc, -1, 0) && Game1.character[ID].charAnim.animName == Game1.character[ID].GetMeta().run_anim && CoopTransOk(ID))
		{
			dest = nMgr.GetTransition(loc, -1, 0);
			direction = TransitionDirection.Left;
			dirX = -1;
		}
		if (loc.X > (float)map.xSize * 64f - 64f && traj.X > 0f && Game1.character[ID].charKeys.keyRight && nMgr.CheckIsNeighbor(loc, 1, 0) && Game1.character[ID].charAnim.animName == Game1.character[ID].GetMeta().run_anim && CoopTransOk(ID))
		{
			dest = nMgr.GetTransition(loc, 1, 0);
			direction = TransitionDirection.Right;
			dirX = 1;
		}
		if (loc.Y < 64f && traj.Y < 0f && nMgr.CheckIsNeighbor(loc, 0, -1))
		{
			dest = nMgr.GetTransition(loc, 0, -1);
			direction = TransitionDirection.Up;
			dirY = -1;
		}
		if (loc.Y > (float)map.ySize * 64f - 16f && traj.Y > 0f && nMgr.CheckIsNeighbor(loc, 0, 1))
		{
			dest = nMgr.GetTransition(loc, 0, 1);
			direction = TransitionDirection.Down;
			dirY = 1;
			loc.Y = (float)map.ySize * 64f - 16f;
		}
		if (dest != "")
		{
			transitionOwner = ID;
			outFrame = 1f;
			srcX = (int)(loc.X / 64f) / 10;
			srcY = (int)(loc.Y / 64f) / 10;
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.SendTransition(Game1.netSession.session, Game1.character[ID].charUpdate.loc, dest, direction, dirX, dirY, transitionOwner, srcX, srcY);
			}
		}
	}

	private bool CoopTransOk(int ID)
	{
		if (Game1.levelMgr.currentTrack == 2)
		{
			if (Game1.GetPlayers() <= 2)
			{
				int num = 1 - ID;
				if ((Game1.character[ID].charUpdate.loc - Game1.character[num].charUpdate.loc).LengthSquared() < 5000f)
				{
					if (Game1.character[ID].charKeys.keyLeft && Game1.character[num].charKeys.keyLeft)
					{
						return true;
					}
					if (Game1.character[ID].charKeys.keyRight && Game1.character[num].charKeys.keyRight)
					{
						return true;
					}
				}
				return false;
			}
			for (int pn = 0; pn < 4; pn++)
			{
				if (pn == ID || !Game1.IsPlayerChar(pn) || !Game1.character[pn].exists || Game1.character[pn].charUpdate.hp < 0f)
				{
					continue;
				}
				if (!((Game1.character[ID].charUpdate.loc - Game1.character[pn].charUpdate.loc).LengthSquared() < 20000f))
				{
					return false;
				}
				bool sameLeft = Game1.character[ID].charKeys.keyLeft && Game1.character[pn].charKeys.keyLeft;
				bool sameRight = Game1.character[ID].charKeys.keyRight && Game1.character[pn].charKeys.keyRight;
				if (!sameLeft && !sameRight)
				{
					return false;
				}
			}
			return true;
		}
		return true;
	}

	internal void DoNetTrans(string dest, Vector2 loc, int direction, int dirX, int dirY, int transitionOwner, int srcX, int srcY)
	{
		this.transitionOwner = transitionOwner;
		this.direction = (TransitionDirection)direction;
		Game1.character[transitionOwner].charUpdate.loc = loc;
		this.dirX = dirX;
		this.dirY = dirY;
		this.srcX = srcX;
		this.srcY = srcY;
		this.dest = dest;
		outFrame = 1f;
	}
}
