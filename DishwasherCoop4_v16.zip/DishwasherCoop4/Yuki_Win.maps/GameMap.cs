using System;
using System.Collections.Generic;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.achievements.cheevos;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.director;
using Yuki_Win.eightbit;
using Yuki_Win.maps.foreground;
using Yuki_Win.maps.script;
using Yuki_Win.player;
using Yuki_Win.sprites.camsplat;
using Yuki_Win.world;

namespace Yuki_Win.maps;

public class GameMap
{
	public enum BeadTheme
	{
		None,
		Contrast,
		Zune,
		ThreeDee
	}

	public enum InvalidPhase
	{
		None,
		Intro,
		Cem,
		Text,
		Dishes,
		Blackout
	}

	public Dictionary<string, Map> mapMap;

	public string curMap;

	public Map curMapPointer;

	public Map lichMapPointer;

	public Environ environ;

	public Bucket bucket;

	public bool updating;

	public float fakeCeiling;

	public Themes theme;

	public bool fog;

	public bool haze;

	public bool halfhaze;

	public bool rain;

	public float xmax;

	public float xmin;

	public bool drips;

	public bool ashes;

	public bool glows;

	public bool wallBlood;

	public bool strobe;

	public bool water;

	public float waterLev;

	public float goresploded;

	public bool lichFreakoutMode;

	public int lichFreakoutSpeedyMode;

	public float lichFreakoutSpeedyFrame;

	public bool bgRefractMode;

	public float trapWarpFrame;

	public int hypnograbbed;

	public bool warpTrap;

	public int warpTrapX;

	public bool slippyWalls;

	private float treadFrame;

	public bool fadingblackscreen;

	public bool blackscreen;

	public bool skullFarm;

	public bool lockCharMode;

	public float tvFrame;

	public float bigTvFrame;

	public float tankFrame;

	public float frame;

	public bool bedMode;

	public bool dentistChairMode;

	public bool zapchairmode;

	public bool chairScreamMode;

	public int doorFocus;

	public float doorFocusFrame;

	public int scriptTrigX;

	public string scriptDestMap;

	public string scriptDestWorld;

	public bool bankerSplashed;

	public bool generalSplashed;

	public bool judgeSplashed;

	public bool yukiDeathFocus;

	public float yukiDeathFrame;

	public bool firstExe;

	public bool alert;

	public bool moaner;

	public float moanframe;

	public bool arrowsOff;

	public bool slavachase;

	public bool chainMash;

	public bool liftOn;

	public float liftFrame;

	public float liftSpeed;

	public float dishTransOutFrame;

	public string dishTransOutDest;

	public float electricInFrame;

	public bool nosplatter;

	public BeadTheme beadTheme;

	public bool engied;

	public float engiedFrame;

	public bool dragonReady;

	public float goryoAlpha;

	public bool goryoMode;

	public bool nekoToasty;

	public float nekoToastyFrame;

	public bool liftBlack;

	public float liftBlackFrame;

	public bool musicRamp;

	public int musicRampMin;

	public int musicRampMax;

	public bool bucketKillMode;

	public float CrazyTransitionOutFrame;

	public float CrazyTransitionInFrame;

	public bool noprize;

	public bool redlights;

	public float redLightval;

	public bool actuallyBlueLights;

	public float actuallyBlueLightval;

	public float forceX;

	public float forceY;

	public float forceFrame;

	public float descentFrame;

	public float descentSpeed;

	public bool rightgreensensors;

	public bool leftgreensensors;

	public bool liftStopMode;

	public float liftStopVal;

	public float psychoTVAlpha;

	public float psychoTVFrame;

	private Vector2 mapMonitorTarg = new Vector2(64f, 64f);

	public Vector2 mapMonitorLoc = new Vector2(64f, 64f);

	private float mapMonitorFrame;

	public float puppeteerFrame;

	public float tankStopFrame;

	public ForeGroundMgr foregroundMgr;

	public Vector2[] fingerVec = new Vector2[4]
	{
		default,
		default,
		default,
		default
	};

	public bool isPuppeteer;

	public InvalidPhase invalidPhase;

	public bool slavapounce;

	public GameMap()
	{
		mapMap = new Dictionary<string, Map>();
		environ = new Environ();
		bucket = new Bucket();
		theme = new Themes();
		foregroundMgr = new ForeGroundMgr();
	}

	public int DoorFocus()
	{
		if (doorFocusFrame > 0.3f)
		{
			return doorFocus;
		}
		return -1;
	}

	public void SplashPortrait(int def)
	{
		if (Game1.levelMgr.currentTrack != 0 && Game1.levelMgr.currentTrack != 1 && Game1.levelMgr.currentTrack != 2)
		{
			return;
		}
		switch (def)
		{
		case 64:
			if (!bankerSplashed)
			{
				bankerSplashed = true;
				for (int k = 0; k < Game1.GetPlayers(); k++)
				{
					BloodyPaintings bloodyPaintings3 = (BloodyPaintings)Game1.achievementMgr.playerAchievements[k].achievementList[6];
					bloodyPaintings3.bankerPainting = true;
					bloodyPaintings3.Unlock(overRide: false);
				}
			}
			break;
		case 65:
			if (!generalSplashed)
			{
				generalSplashed = true;
				for (int j = 0; j < Game1.GetPlayers(); j++)
				{
					BloodyPaintings bloodyPaintings2 = (BloodyPaintings)Game1.achievementMgr.playerAchievements[j].achievementList[6];
					bloodyPaintings2.generalPainting = true;
					bloodyPaintings2.Unlock(overRide: false);
				}
			}
			break;
		case 66:
			if (!judgeSplashed)
			{
				judgeSplashed = true;
				for (int i = 0; i < Game1.GetPlayers(); i++)
				{
					BloodyPaintings bloodyPaintings = (BloodyPaintings)Game1.achievementMgr.playerAchievements[i].achievementList[6];
					bloodyPaintings.judgePainting = true;
					bloodyPaintings.Unlock(overRide: false);
				}
			}
			break;
		}
	}

	public void CacheMap(string map)
	{
		if (!mapMap.ContainsKey(map))
		{
			mapMap.Add(map, new Map(map));
		}
	}

	public void SetMap(string map)
	{
		if (curMap != null && curMap != "")
		{
			Game1.spriteMan.goreInstanceMgr.SetInstances();
		}
		if (Game1.transMgr.enterMap != null)
		{
			Game1.transMgr.enterMap = null;
		}
		if (mapMap.ContainsKey(map))
		{
			curMap = map;
			if (mapMap[curMap].scriptMgr.resetNecessary)
			{
				mapMap[curMap].Read();
			}
			curMapPointer = mapMap[curMap];
		}
		else
		{
			mapMap.Add(map, new Map(map));
			curMap = map;
			curMapPointer = mapMap[curMap];
		}
		Game1.neighborMgr.Refresh(WorldManager.GetWorld(), curMapPointer);
		curMapPointer.Reset();
		Game1.beadMgr.UpdateMapTheme();
		environ.ResetShips();
		CurMap().scriptMgr.SetHashTag();
		if (Game1.netSession.IsClient())
		{
			CurMap().scriptMgr.ClientProcess();
		}
	}

	public void SmashWindow(Vector2 loc)
	{
		Map map = CurMap();
		Layer layer = map.layer[1];
		for (int i = 0; i < layer.segment.Length; i++)
		{
			if (layer.segment[i] == null || layer.segment[i].idx <= -1 || Game1.segDefMgr.segDef[layer.segment[i].idx].flags != 53 || !(layer.segment[i].loc.Y < loc.Y) || (int)layer.segment[i].loc.Y + Game1.segDefMgr.segDef[layer.segment[i].idx].sRect.Height <= (int)loc.Y || layer.segment[i].smashed)
			{
				continue;
			}
			layer.segment[i].smashed = true;
			for (int j = 0; j < 40; j++)
			{
				for (int k = 0; k < 3; k++)
				{
					Game1.spriteMan.AddSprite(55, Rand.GetRandomVec2(loc.X - 10f, loc.X + 60f, loc.Y - 400f, loc.Y), Rand.GetRandomVec2(-1600f, 0f, -300f, 400f), Rand.GetRandomFloat(1f, 5f), 0, 0);
				}
				Vector2 randomVec = Rand.GetRandomVec2(loc.X - 10f, loc.X + 60f, loc.Y - 400f, loc.Y);
				Game1.spriteMan.AddSprite(56, randomVec, Rand.GetRandomVec2(-400f, 0f, 0f, 100f), Rand.GetRandomFloat(1f, 5f), 0, 0);
			}
			Sound.PlaySnd(Sound.Category.FX, "glass");
			Sound.PlaySnd(Sound.Category.FX, "bass");
			Sound.PlaySnd(Sound.Category.FX, "hit");
			QuakeManager.SetQuake(0.5f);
		}
	}

	public void Update()
	{
		updating = true;
		bucket.Update();
		CurMap().scriptMgr.Update();
		if (doorFocusFrame > 0f)
		{
			doorFocusFrame -= FMan.frameTime;
		}
		environ.aquarium.active = theme.theme == Themes.ThemeType.Aquarium;
		environ.Update(this);
		if (forceFrame > 0f)
		{
			forceFrame -= FMan.frameTime;
		}
		if (nekoToastyFrame > 0f)
		{
			nekoToastyFrame -= FMan.realTime;
		}
		mapMonitorFrame -= FMan.frameTime;
		if (mapMonitorFrame < 0f)
		{
			mapMonitorTarg = Rand.GetRandomVec2(64f, 408f, 64f, 192f);
			mapMonitorFrame = Rand.GetRandomFloat(2f, 4f);
		}
		if (mapMonitorLoc.X < mapMonitorTarg.X - 2f)
		{
			mapMonitorLoc.X += FMan.frameTime * 70f;
		}
		if (mapMonitorLoc.X > mapMonitorTarg.X - 2f)
		{
			mapMonitorLoc.X -= FMan.frameTime * 70f;
		}
		if (mapMonitorLoc.Y < mapMonitorTarg.Y - 2f)
		{
			mapMonitorLoc.Y += FMan.frameTime * 70f;
		}
		if (mapMonitorLoc.Y > mapMonitorTarg.Y - 2f)
		{
			mapMonitorLoc.Y -= FMan.frameTime * 70f;
		}
		foregroundMgr.Update();
		if (lichFreakoutMode && MainPlayer.uberDyingFrame >= 1f)
		{
			lichFreakoutMode = false;
			for (int i = 0; i < Game1.character.Length; i++)
			{
				if (Game1.character[i].exists && Game1.character[i].GetMeta().isGhost)
				{
					Game1.character[i].exists = false;
				}
			}
		}
		if (electricInFrame > 0f)
		{
			float num = electricInFrame;
			electricInFrame -= FMan.frameTime;
			if ((int)(num * 30f) != (int)(electricInFrame * 30f))
			{
				float randomFloat = Rand.GetRandomFloat(0f, 6.28f);
				Vector2 vector = new Vector2((float)Math.Cos(randomFloat), (float)Math.Sin(randomFloat)) * 400f;
				Game1.spriteMan.AddSprite(59, Game1.character[0].charUpdate.loc - vector, vector * 2f, 1f, 0, 0);
			}
		}
		if (goryoMode)
		{
			if (goryoAlpha < 1f)
			{
				goryoAlpha += FMan.frameTime;
				if (goryoAlpha > 1f)
				{
					goryoAlpha = 1f;
				}
			}
		}
		else if (goryoAlpha > 0f)
		{
			goryoAlpha -= FMan.frameTime;
			if (goryoAlpha < 0f)
			{
				goryoAlpha = 0f;
			}
		}
		if (yukiDeathFocus && yukiDeathFrame < 1f)
		{
			yukiDeathFrame += FMan.frameTime * 0.07f;
			if (yukiDeathFrame >= 1f)
			{
				Game1.gameMap.CurMap().scriptMgr.SetFlag("yukideath");
			}
		}
		if (GameState.flowerFrame > 0f)
		{
			GameState.flowerFrame -= FMan.frameTime;
			if (GameState.flowerFrame <= 0f)
			{
				for (int j = 0; j < 2; j++)
				{
					if (Game1.character[j].exists && Game1.character[j].charUpdate.hp >= 0f && Game1.beadMgr.beads[j].HasBead(InvCatalog.InvItemName.FlowerBead))
					{
						Game1.character[j].charUpdate.hp += 0.25f;
						if (Game1.character[j].charUpdate.hp > Game1.character[j].charUpdate.mhp)
						{
							Game1.character[j].charUpdate.hp = Game1.character[j].charUpdate.mhp;
						}
					}
				}
			}
		}
		switch (invalidPhase)
		{
		case InvalidPhase.Blackout:
			psychoTVFrame -= FMan.frameTime;
			if (psychoTVFrame <= 0f)
			{
				Game1.eightBitGame.Init(0);
				EightBitGame.enabled = true;
			}
			break;
		case InvalidPhase.Intro:
		{
			if (invalidPhase != InvalidPhase.Intro)
			{
				break;
			}
			for (int k = 0; k < Game1.character.Length; k++)
			{
				if (!Game1.character[k].exists || !Game1.character[k].GetMeta().isInvalid)
				{
					continue;
				}
				Vector2 vector2 = Game1.character[0].charUpdate.loc - Game1.character[k].charUpdate.loc;
				vector2.X = Math.Abs(vector2.X);
				if (vector2.X < 300f)
				{
					invalidPhase = InvalidPhase.Blackout;
					psychoTVFrame = 5f;
					Sound.PlaySnd(Sound.Category.FX, "clickoff");
				}
				vector2.X -= 600f;
				if (vector2.X < 600f)
				{
					float num2 = vector2.X / 600f;
					if (num2 < 0f)
					{
						num2 = 0f;
					}
					num2 = 1f - num2;
					psychoTVAlpha = num2;
					if (vector2.X < 500f)
					{
						float num3 = (vector2.X - 200f) / 300f;
						if (num3 < 0f)
						{
							num3 = 0f;
						}
						num3 = num3 * 0.75f + 0.25f;
						FMan.frameTime *= num3;
					}
				}
				else
				{
					psychoTVAlpha = 0.01f;
				}
				Game1.eightBitGame.staticFrame -= FMan.realTime;
				if (Game1.eightBitGame.staticFrame <= 0f)
				{
					Game1.eightBitGame.staticFrame = 0.5f;
					if (Rand.CointToss(0.3f))
					{
						Sound.PlaySnd(Sound.Category.FX, "static1");
					}
					else if (Rand.CointToss(0.5f))
					{
						Sound.PlaySnd(Sound.Category.FX, "static2");
					}
					else
					{
						Sound.PlaySnd(Sound.Category.FX, "static3");
					}
				}
			}
			break;
		}
		case InvalidPhase.Cem:
		case InvalidPhase.Text:
		case InvalidPhase.Dishes:
			psychoTVAlpha = Rand.GetRandomFloat(0.1f, 0.65f);
			psychoTVFrame -= FMan.frameTime;
			Game1.eightBitGame.screenFrame += FMan.frameTime * 4f;
			if (Game1.eightBitGame.screenFrame > 10f)
			{
				Game1.eightBitGame.screenFrame -= 10f;
			}
			if (psychoTVFrame < 0f)
			{
				switch (invalidPhase)
				{
				case InvalidPhase.Cem:
					Game1.eightBitGame.Init(2);
					EightBitGame.enabled = true;
					break;
				case InvalidPhase.Text:
					Game1.eightBitGame.Init(1);
					EightBitGame.enabled = true;
					break;
				case InvalidPhase.Dishes:
					Game1.character[0].charAnim.SetAnim("ikill", Game1.character[0].charUpdate, overRide: true);
					invalidPhase = InvalidPhase.None;
					break;
				}
			}
			else if (Rand.CointToss(0.1f))
			{
				Game1.killManager.DoKill(0);
			}
			break;
		default:
			psychoTVAlpha = 0f;
			break;
		}
		if (goresploded > 0f)
		{
			float num4 = goresploded;
			goresploded += FMan.frameTime / 10f;
			if (num4 < 1f && goresploded >= 1f)
			{
				for (int l = 0; l < Game1.character.Length; l++)
				{
					if (Game1.character[l].GetMeta().autoGroundSplode)
					{
						Game1.character[l].exists = false;
					}
				}
				Game1.spriteMan.Reset();
				QuakeManager.SetQuake(0.2f);
				Sound.PlaySnd(Sound.Category.FX, "wetdrop");
				Sound.PlaySnd(Sound.Category.FX, "splat");
				FMan.slowFrame = 0f;
				ScrollManager.scroll += Rand.GetRandomVec2(-30f, 30f, 100f, 120f);
			}
			if (goresploded > 2f)
			{
				goresploded = 2f;
			}
			else if (goresploded >= 1f && (int)(num4 * 40f) != (int)(goresploded * 40f) && Rand.CointToss(0.8f))
			{
				Vector2 loc = new Vector2(Rand.GetRandomFloat(ScrollManager.GetRealLoc(default, 1f).X, ScrollManager.GetRealLoc(new Vector2(ScrollManager.screenSize.X, 0f), 1f).X), ScrollManager.GetRealLoc(default, 1f).Y);
				if (Rand.CointToss(0.5f))
				{
					Game1.spriteMan.AddGib(loc, Rand.GetRandomVec2(-50f, 50f, 0f, 100f), Rand.GetRandomInt(0, 2), Game1.charMeta[17].headTex, Game1.charMeta[17].torsoTex, Game1.charMeta[17].legsTex, Game1.charMeta[17].weapTex, 1, "headfall", "headland", 0.35f, CurMap(), 0, 0, -1, -1);
				}
				else
				{
					Game1.spriteMan.AddGib(loc, Rand.GetRandomVec2(-50f, 50f, 0f, 100f), Rand.GetRandomInt(0, 2), Game1.charMeta[17].headTex, Game1.charMeta[17].torsoTex, Game1.charMeta[17].legsTex, Game1.charMeta[17].weapTex, 1, "armfall", "armland", 0.35f, CurMap(), 0, 0, -1, -1);
				}
			}
		}
		tvFrame += FMan.frameTime * 0.05f;
		if (tvFrame > 1f)
		{
			tvFrame--;
		}
		bigTvFrame += FMan.frameTime;
		if (bigTvFrame > 22f)
		{
			bigTvFrame = 0f;
		}
		float num5 = frame;
		frame += FMan.frameTime;
		if (frame > 100f)
		{
			frame = 0f;
		}
		if (theme.theme == Themes.ThemeType.PrisonOut && (int)(num5 * 5f) != (int)(frame * 5f))
		{
			Sound.PlaySnd(Sound.Category.FX, "engineflame");
		}
		if (tankStopFrame > 0f)
		{
			float num6 = tankStopFrame;
			tankStopFrame -= FMan.frameTime;
			if (num6 >= 1f && tankStopFrame < 1f)
			{
				Sound.PlaySnd(Sound.Category.FX, "bass");
				Sound.PlaySnd(Sound.Category.FX, "tankland");
				Sound.PlaySnd(Sound.Category.FX, "robodie");
			}
			if (tankStopFrame > 0.9f && (int)(num6 * 60f) != (int)(tankStopFrame * 60f))
			{
				Game1.spriteMan.AddSprite(89, Rand.GetRandomVec2(0f, 500f, 1000f, 1200f), Rand.GetRandomVec2(100f, 1000f, -100f, 0f), Rand.GetRandomFloat(15f, 25f), 0, 0);
			}
			QuakeManager.SetQuake(tankStopFrame);
		}
		if (dishTransOutFrame > 0f)
		{
			QuakeManager.SetQuake(1f - dishTransOutFrame);
			QuakeManager.SetBright(1f - dishTransOutFrame);
			dishTransOutFrame -= FMan.frameTime;
			if (dishTransOutFrame <= 0f)
			{
				Game1.gameMap.CrazyTransitionInFrame = 5f;
				Sound.PlaySnd(Sound.Category.FX, "lieend");
				Game1.gameMap.SetMap(dishTransOutDest);
				float num7 = 0f;
				switch (dishTransOutDest)
				{
				case "final":
					num7 = -128f;
					ScrollManager.zoom = 0.01f;
					break;
				case "judge":
				{
					num7 = -512f;
					Game1.gameMap.CrazyTransitionInFrame = 0f;
					for (int m = 4; m < Game1.character.Length; m++)
					{
						if (Game1.character[m].exists && Game1.character[m].team == Character.Team.BadGuys)
						{
							switch (Game1.character[m].charAnim.animName)
							{
							case "dishgrabbed2":
								Game1.character[m].charAnim.SetAnim("dishgrabbed2end", Game1.character[m].charUpdate);
								break;
							case "yukigrabbed2":
								Game1.character[m].charAnim.SetAnim("yukigrabbed2end", Game1.character[m].charUpdate);
								break;
							}
						}
					}
					break;
				}
				}
				for (int n = 0; n < Game1.character.Length; n++)
				{
					if (Game1.character[n].exists)
					{
						Game1.character[n].charUpdate.loc.Y += num7;
						Game1.character[n].charUpdate.loc.X = 640f;
					}
				}
				Game1.spriteMan.Reset();
				ScrollManager.scroll.Y += num7;
				ScrollManager.scroll.X = 640f;
				QuakeManager.SetBright(1f);
				Game1.transMgr.enterVec = Game1.character[0].charUpdate.loc;
			}
		}
		if (engied)
		{
			engiedFrame += FMan.frameTime * 0.25f;
			if (engiedFrame > 1f)
			{
				engiedFrame = 1f;
			}
		}
		if (theme.theme == Themes.ThemeType.GearCloset)
		{
			QuakeManager.SetQuake(0.02f);
		}
		if (redlights)
		{
			moaner = true;
			if (redLightval < 1f)
			{
				redLightval += FMan.frameTime * 0.5f;
				if (redLightval > 1f)
				{
					redLightval = 1f;
				}
			}
		}
		else if (redLightval > 0f)
		{
			moaner = false;
			redLightval -= FMan.frameTime * 3f;
			if (redLightval < 0f)
			{
				redLightval = 0f;
			}
		}
		if (actuallyBlueLights)
		{
			if (actuallyBlueLightval < 1f)
			{
				actuallyBlueLightval += FMan.frameTime * 0.5f;
				if (actuallyBlueLightval > 1f)
				{
					actuallyBlueLightval = 1f;
				}
			}
			if (actuallyBlueLightval > 0.5f && (int)(num5 * 50f) != (int)(frame * 50f) && Rand.CointToss(0.15f))
			{
				Vector2 realLoc = ScrollManager.GetRealLoc(new Vector2(0f, -100f), 1f);
				Vector2 realLoc2 = ScrollManager.GetRealLoc(new Vector2(ScrollManager.screenSize.X, ScrollManager.screenSize.Y / 2f), 1f);
				Vector2 randomVec = Rand.GetRandomVec2(realLoc.X, realLoc2.X, realLoc.Y, realLoc2.Y);
				int num8 = (int)((actuallyBlueLightval - 0.5f) * 25f);
				if (num8 > 0)
				{
					for (int num9 = 0; num9 < num8; num9++)
					{
						Game1.spriteMan.AddSprite(0, randomVec, Rand.GetRandomVec2(-600f, 600f, -600f, 600f), 0f, 0, 0);
					}
					QuakeManager.SetBright(0.125f);
				}
			}
		}
		if (warpTrap)
		{
			if (Game1.character[0].charUpdate.loc.X < (float)warpTrapX)
			{
				warpTrap = false;
				trapWarpFrame = 0.16f;
				Game1.character[0].charUpdate.ForceWarp();
				QuakeManager.SetQuake(0.2f);
				Sound.PlaySnd(Sound.Category.FX, "slam");
				Sound.PlaySnd(Sound.Category.FX, "zbomb");
				Sound.PlaySnd(Sound.Category.FX, "gitwarp");
				Sound.PlaySnd(Sound.Category.FX, "crush");
			}
		}
		else if (trapWarpFrame > 0f)
		{
			if (trapWarpFrame > 0.14f)
			{
				QuakeManager.bright = (trapWarpFrame - 0.14f) * 50f;
			}
			else
			{
				QuakeManager.bright = 0f;
			}
			QuakeManager.contrast = trapWarpFrame * 5f;
			trapWarpFrame -= FMan.frameTime;
			_ = trapWarpFrame;
			_ = 0f;
		}
		if (theme.theme == Themes.ThemeType.Tank || theme.theme == Themes.ThemeType.TankBrite)
		{
			fog = false;
			Map map = CurMap();
			descentSpeed = 1f;
			if (Game1.transMgr.outFrame > 0f && Game1.transMgr.direction == TransitionManager.TransitionDirection.Warp)
			{
				descentSpeed *= Game1.transMgr.outFrame;
				if (descentSpeed < 0f)
				{
					descentSpeed = 0f;
				}
			}
			if (Game1.transMgr.inFrame > 0f && Game1.transMgr.direction == TransitionManager.TransitionDirection.Warp)
			{
				descentSpeed *= 1f - Game1.transMgr.inFrame * 2f;
				if (descentSpeed < 0f)
				{
					descentSpeed = 0f;
				}
			}
			tankFrame += FMan.frameTime * 0.05f * descentSpeed;
			if (tankFrame > 1f)
			{
				tankFrame--;
			}
			for (int num10 = 0; num10 < 5; num10++)
			{
				if (num10 == 2 || num10 == 3)
				{
					continue;
				}
				Layer layer = map.layer[num10];
				for (int num11 = 0; num11 < layer.segment.Length; num11++)
				{
					Segment segment = layer.segment[num11];
					if (segment != null && segment.idx > -1)
					{
						segment.loc -= new Vector2(30f, 0f) * descentSpeed * FMan.frameTime * 2f;
						if (segment.loc.X < -700f)
						{
							segment.loc += new Vector2(3000f, 0f);
						}
					}
				}
			}
			treadFrame -= FMan.frameTime;
			if (treadFrame < 0f && descentSpeed >= 1f)
			{
				treadFrame += 3f;
				Sound.PlaySnd(Sound.Category.FX, "treads");
			}
		}
		if (theme.theme == Themes.ThemeType.Descent)
		{
			descentFrame += FMan.frameTime;
			if (descentFrame > 4f)
			{
				treadFrame -= FMan.frameTime;
				if (treadFrame < 0f)
				{
					Sound.PlaySnd(Sound.Category.FX, "shuttleengine");
					treadFrame += 0.5f;
				}
			}
			else
			{
				treadFrame = 0f;
			}
			descentSpeed = 0f;
			if (!(descentFrame < 5f))
			{
				if (descentFrame < 10f)
				{
					descentSpeed = descentFrame - 5f;
				}
				else
				{
					descentSpeed = 5f;
				}
			}
			if (Game1.transMgr.outFrame > 0f)
			{
				descentSpeed = 5f * Game1.transMgr.outFrame;
			}
			if (QuakeManager.quake < descentSpeed / 121f)
			{
				QuakeManager.quake = descentSpeed / 121f;
			}
			Map map2 = CurMap();
			for (int num12 = 0; num12 < 5; num12++)
			{
				if (num12 != 2 && num12 != 3)
				{
					Layer layer2 = map2.layer[num12];
					for (int num13 = 0; num13 < layer2.segment.Length; num13++)
					{
						Segment segment2 = layer2.segment[num13];
						if (segment2 != null && segment2.idx > -1)
						{
							segment2.loc -= new Vector2(30f, 5f) * descentSpeed * FMan.frameTime * 2f;
							if (segment2.loc.X < -1000f)
							{
								segment2.loc += new Vector2(3000f, 500f);
							}
						}
					}
				}
				if (num12 != 2)
				{
					continue;
				}
				Layer layer3 = map2.layer[num12];
				for (int num14 = 0; num14 < layer3.segment.Length; num14++)
				{
					Segment segment3 = layer3.segment[num14];
					if (segment3 != null && segment3.idx > -1 && Game1.segDefMgr.segDef[segment3.idx].flags == 41)
					{
						segment3.rotation += descentSpeed * FMan.frameTime;
						if (segment3.rotation > 6.28f)
						{
							segment3.rotation -= 6.28f;
						}
					}
				}
			}
		}
		if (liftOn)
		{
			liftFrame += FMan.frameTime;
			if (liftFrame > 15f)
			{
				fog = false;
			}
			if (liftFrame > 30f)
			{
				haze = false;
			}
			liftSpeed = 0f;
			if (!(liftFrame < 5f))
			{
				if (liftFrame < 10f)
				{
					liftSpeed = liftFrame - 5f;
				}
				else
				{
					liftSpeed = 5f;
				}
			}
			if (liftStopMode)
			{
				liftStopVal += FMan.frameTime * 4f;
				if (liftStopVal > 1f)
				{
					liftStopVal = 1f;
				}
			}
			else
			{
				liftStopVal -= FMan.frameTime * 0.2f;
				if (liftStopVal < 0f)
				{
					liftStopVal = 0f;
				}
			}
			if (liftStopVal > 0f)
			{
				liftSpeed *= 1f - liftStopVal;
			}
			if (Game1.transMgr.outFrame > 0f)
			{
				liftSpeed = 5f * Game1.transMgr.outFrame;
			}
			if (QuakeManager.quake < liftSpeed / 121f)
			{
				QuakeManager.quake = liftSpeed / 121f;
			}
			Map map3 = CurMap();
			bool flag = false;
			if (liftBlack)
			{
				liftBlackFrame += 50f * liftSpeed * FMan.frameTime * 2f;
			}
			for (int num15 = 0; num15 < 5; num15++)
			{
				Layer layer4 = map3.layer[num15];
				for (int num16 = 0; num16 < layer4.segment.Length; num16++)
				{
					Segment segment4 = layer4.segment[num16];
					if (segment4 == null || segment4.idx <= -1 || Game1.segDefMgr.segDef[segment4.idx].flags == 52)
					{
						continue;
					}
					if (num15 == 3 && Game1.segDefMgr.segDef[segment4.idx].flags == 8)
					{
						flag = true;
					}
					segment4.loc += new Vector2(0f, 50f) * liftSpeed * FMan.frameTime * 2f;
					if (!(segment4.loc.Y > (float)map3.ySize * 64f * 0.5f + 1200f))
					{
						continue;
					}
					segment4.loc -= new Vector2(0f, 2140f);
					segment4.smashed = false;
					if (Game1.segDefMgr.segDef[segment4.idx].flags == 54 && dragonReady)
					{
						Game1.spawnMgr.SpawnLockedMonster(new Vector2(825f, 1150f), 30, "");
						dragonReady = false;
					}
					if (num15 != 2 && num15 != 0 && num15 != 3)
					{
						continue;
					}
					if (num15 == 3)
					{
						if (Game1.segDefMgr.segDef[segment4.idx].flags != 8 && !flag)
						{
							layer4.segment[num16] = null;
						}
					}
					else
					{
						layer4.segment[num16] = null;
					}
				}
			}
		}
		Vector2 realLoc3 = ScrollManager.GetRealLoc(default, 1f);
		Vector2 realLoc4 = ScrollManager.GetRealLoc(ScrollManager.screenSize, 1f);
		Layer layer5 = CurMap().layer[2];
		for (int num17 = 0; num17 < layer5.segment.Length; num17++)
		{
			if (layer5.segment[num17] != null)
			{
				layer5.segment[num17].Update();
			}
		}
		if (CrazyTransitionInFrame > 0f)
		{
			CrazyTransitionInFrame -= FMan.frameTime * 0.7f;
		}
		if (CrazyTransitionOutFrame > 0f)
		{
			CrazyTransitionOutFrame -= FMan.frameTime * 4f;
		}
		if (moaner)
		{
			moanframe -= FMan.frameTime;
			if (moanframe < 0f)
			{
				Sound.PlaySnd(Sound.Category.FX, "moan");
				moanframe = 18f;
			}
		}
		if (!Game1.camMgr.bossToast.IsActive())
		{
			if (water)
			{
				Game1.spriteMan.AddCamsplat(CamSplat.CamSplatType.Water);
			}
			_ = strobe;
			if (drips && (int)(num5 * 45f) != (int)(frame * 45f))
			{
				Game1.spriteMan.AddSprite(27, Rand.GetRandomVec2(realLoc3.X, realLoc4.X, ScrollManager.scroll.Y - 360f, ScrollManager.scroll.Y - 360f), new Vector2(0f, 1500f), Rand.GetRandomFloat(1f, 2f), 0, 0);
			}
			if (glows && (int)(num5 * 25f) != (int)(frame * 25f))
			{
				Game1.spriteMan.AddSprite(28, Rand.GetRandomVec2(realLoc3.X, realLoc4.X, -100f, (realLoc3.Y + realLoc4.Y) / 2f + realLoc3.Y), Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.04f, 0.05f), 0, 0);
			}
			if (theme.theme == Themes.ThemeType.EscapeOut && (int)(num5 * 61f) != (int)(frame * 61f))
			{
				Game1.spriteMan.AddSprite(16, Rand.GetRandomVec2(realLoc3.X, realLoc4.X, -100f, (realLoc3.Y + realLoc4.Y) / 2f + realLoc3.Y), Rand.GetRandomVec2(-2200f, -2100f, -100f, 100f), Rand.GetRandomFloat(0.35f, 0.4f), 0, 0);
				Game1.spriteMan.AddSprite(18, Rand.GetRandomVec2(realLoc3.X, realLoc4.X, -100f, (realLoc3.Y + realLoc4.Y) / 2f + realLoc3.Y), Rand.GetRandomVec2(-2200f, -2100f, -100f, 100f), Rand.GetRandomFloat(0.45f, 0.5f), 0, 0);
			}
			if (theme.theme == Themes.ThemeType.PrisonOut && (int)(num5 * 25f) != (int)(frame * 25f))
			{
				Game1.spriteMan.AddSprite(28, Rand.GetRandomVec2(realLoc3.X, realLoc4.X, -100f, (realLoc3.Y + realLoc4.Y) / 2f + realLoc3.Y), Rand.GetRandomVec2(500f, 600f, -100f, 100f), Rand.GetRandomFloat(0.05f, 0.1f), 0, 0);
			}
			if (ashes && (int)(num5 * 60f) != (int)(frame * 60f))
			{
				Game1.spriteMan.AddSprite(29, Rand.GetRandomVec2(realLoc3.X, realLoc4.X, -100f, (realLoc3.Y + realLoc4.Y) / 2f + realLoc3.Y), Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.3f, 0.5f), 0, 0);
			}
		}
	}

	public Map CurMap()
	{
		if (lichFreakoutMode)
		{
			if (lichMapPointer == null)
			{
				lichMapPointer = mapMap["lichworld"];
			}
			return lichMapPointer;
		}
		if (curMap == null)
		{
			return null;
		}
		if (curMapPointer == null)
		{
			curMapPointer = mapMap[curMap];
		}
		return curMapPointer;
	}

	internal void DrawEnviron(SpriteBatch sprite)
	{
		environ.Draw(sprite, this);
	}

	internal void DrawNekoToasty(SpriteBatch sprite)
	{
		if (nekoToastyFrame > 0f)
		{
			float num = 1f;
			if (nekoToastyFrame > 0.8f)
			{
				num = (1f - nekoToastyFrame) * 5f;
			}
			if (nekoToastyFrame < 0.2f)
			{
				num = nekoToastyFrame * 5f;
			}
			sprite.Draw(Game1.waterTex, ScrollManager.screenSize, new Rectangle(384, 0, 128, 128), Color.White, 0f, new Vector2(num * 128f, 128f), 2f, SpriteEffects.None, 1f);
		}
	}

	internal void PopUpNekoToasty()
	{
		if (nekoToastyFrame <= 0f)
		{
			Sound.PlaySnd(Sound.Category.FX, "toasty");
			nekoToastyFrame = 1f;
			nekoToasty = false;
		}
	}

	internal void SmashCeiling(Vector2 loc)
	{
		for (int i = 0; i < 70; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				Game1.spriteMan.AddSprite(55, Rand.GetRandomVec2(loc.X - 400f, loc.X + 400f, loc.Y - 40f, loc.Y) + new Vector2(0f, 220f), Rand.GetRandomVec2(-500f, 200f, 200f, 400f), Rand.GetRandomFloat(1f, 5f), 0, 0);
			}
			Vector2 loc2 = Rand.GetRandomVec2(loc.X - 400f, loc.X + 400f, loc.Y - 40f, loc.Y) + new Vector2(0f, 220f);
			Game1.spriteMan.AddSprite(56, loc2, Rand.GetRandomVec2(-40f, 40f, 0f, 400f), Rand.GetRandomFloat(1f, 5f), 0, 0);
		}
		Sound.PlaySnd(Sound.Category.FX, "glass");
		Sound.PlaySnd(Sound.Category.FX, "bass");
		Sound.PlaySnd(Sound.Category.FX, "hit");
		QuakeManager.SetQuake(0.5f);
	}

	internal void DoLichFreakout(bool netInduced)
	{
		if (lichFreakoutMode || (Game1.netSession.IsClient() && !netInduced))
		{
			return;
		}
		if (Game1.netSession.IsHost())
		{
			Game1.netSession.netGame.SendLichFreakout(Game1.netSession.session);
		}
		lichFreakoutMode = true;
		if (!Game1.netSession.IsClient())
		{
			bucket.Init(5, fix: false);
			for (int i = 0; i < 8; i++)
			{
				bucket.AddItem(new Vector2((float)Game1.gameMap.CurMap().xSize * 64f * 0.5f, 500f) + Rand.GetRandomVec2(-800f, 800f, 0f, 0f), 26);
			}
		}
		QuakeManager.SetBright(1f);
		Sound.PlaySnd(Sound.Category.FX, "lieend");
	}

	internal void EndLichFreakout(bool p)
	{
		Game1.gameMap.lichFreakoutMode = false;
		QuakeManager.SetBright(1f);
		Sound.PlaySnd(Sound.Category.FX, "lieend");
		Game1.spriteMan.Reset();
	}
}
