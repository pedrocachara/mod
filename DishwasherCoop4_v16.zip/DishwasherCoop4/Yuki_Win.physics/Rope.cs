using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.physics;

public class Rope
{
	public float dist;

	public RopeNode[] node;

	public float scale;

	public float fac;

	public Rope(int nodes, float segDist)
	{
		dist = segDist;
		node = new RopeNode[nodes];
		for (int i = 0; i < node.Length; i++)
		{
			node[i] = new RopeNode();
		}
	}

	public void Update()
	{
		Update(0f);
	}

	public void Update(float lim)
	{
		if (node.Length > 2)
		{
			node[0].Update(null, node[1], this, lim);
			for (int i = 1; i < node.Length - 1; i++)
			{
				node[i].Update(node[i - 1], node[i + 1], this, lim);
			}
			node[node.Length - 1].Update(node[node.Length - 2], null, this, lim);
			node[0].traj = default;
			for (int j = 0; j < node.Length; j++)
			{
				node[j].loc += node[j].traj * FMan.frameTime;
			}
		}
	}

	public void SetOrig(Vector2 v)
	{
		node[0].loc = v * fac;
	}

	public void Reset()
	{
		if (node.Length >= 2)
		{
			for (int i = 1; i < node.Length; i++)
			{
				node[i].loc = node[0].loc;
				node[i].traj = default;
			}
		}
	}

	internal void DrawHair(SpriteBatch sprite, int idx)
	{
		scale = 0.1f;
		fac = 8f;
		Vector2 vector = node[0].loc / fac;
		int num = 640;
		int y = 448;
		float num2 = 0f;
		switch (idx)
		{
		case 0:
		case 1:
			y = 448 + idx * 32;
			break;
		case 2:
			num2 = 0.5f;
			num = 768;
			y = 512;
			break;
		case 3:
		case 4:
			num2 = 0.5f;
			num = 736;
			y = 448 + (4 - idx) * 32;
			break;
		}
		for (int i = 0; i < node.Length - 1; i++)
		{
			Vector2 vector2 = node[i + 1].loc - node[i].loc;
			vector2 *= scale;
			_ = node[i].loc;
			_ = vector + vector2 * 0.5f;
			Vector2 v = node[i].loc - node[i + 1].loc;
			float num3 = v.Length();
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(vector, 1f), new Rectangle(num + i * 16, y, 16, 32), new Color(num2, num2, num2, 1f), Trig.GetAngle(default, v), new Vector2(0f, 16f), new Vector2(num3 / 15f, 2.3f) * ScrollManager.cannedDepth[0] * scale, SpriteEffects.None, 1f);
			vector += vector2;
		}
	}

	internal void Draw(SpriteBatch spriteBatch)
	{
		SpriteTools.BeginAdditive();
		for (int i = 0; i < node.Length - 1; i++)
		{
			float num = 1f - (float)i / (float)node.Length;
			Vector2 position = (node[i].loc + node[i + 1].loc) / 2f;
			Vector2 v = node[i].loc - node[i + 1].loc;
			float num2 = v.Length();
			spriteBatch.Draw(Game1.spritesTex, position, new Rectangle(144, 64, 96, 32), new Color(1f, 0f, 0f, 1f), Trig.GetAngle(default, v), new Vector2(48f, 16f), new Vector2(num2 / 96f, 0.2f + num), SpriteEffects.None, 1f);
			spriteBatch.Draw(Game1.spritesTex, position, new Rectangle(256, 0, 64, 64), new Color(1f, 1f, 1f, 0.1f), 0f, new Vector2(32f, 32f), 0.2f, SpriteEffects.None, 1f);
			spriteBatch.Draw(Game1.spritesTex, node[i].loc, new Rectangle(256, 0, 64, 64), new Color(1f, 1f, 1f, 0.1f), 0f, new Vector2(32f, 32f), 0.2f, SpriteEffects.None, 1f);
		}
		spriteBatch.End();
	}
}
