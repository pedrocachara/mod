using Microsoft.Xna.Framework;

namespace Yuki_Win.physics;

public class RopeNode
{
	public Vector2 loc;

	public Vector2 traj;

	public void Update(RopeNode i, RopeNode j, Rope parent, float lim)
	{
		bool flag = true;
		if (i != null)
		{
			Vector2 vector = i.loc - loc;
			Vector2 vector2 = vector;
			vector2.Normalize();
			float num = vector.Length();
			if (num > parent.dist)
			{
				Vector2 vector3 = (num - parent.dist) * vector2 * 60f;
				traj += vector3 * FMan.frameTime;
				flag = false;
				if (num > parent.dist * 3f)
				{
					Vector2 vector4 = loc;
					loc = i.loc - vector2 * parent.dist * 3f;
					traj += (loc - vector4) * FMan.frameTime;
				}
			}
			traj.Y += 700f * FMan.frameTime;
		}
		if (i != null)
		{
			if (j != null)
			{
				Vector2 vector5 = j.loc - loc;
				Vector2 vector6 = vector5;
				vector6.Normalize();
				float num2 = vector5.Length();
				if (num2 > parent.dist)
				{
					Vector2 vector7 = (num2 - parent.dist) * vector6 * 20f;
					traj += vector7 * FMan.frameTime;
					flag = false;
				}
			}
			if (lim < 0f && loc.X < i.loc.X)
			{
				loc.X = i.loc.X;
				if (traj.X < 0f)
				{
					traj.X = 0f - traj.X;
				}
			}
			if (lim > 0f && loc.X > i.loc.X)
			{
				loc.X = i.loc.X;
				if (traj.X > 0f)
				{
					traj.X = 0f - traj.X;
				}
			}
		}
		float num3 = 1200f;
		if (traj.X > num3)
		{
			traj.X = num3;
		}
		if (traj.X < 0f - num3)
		{
			traj.X = 0f - num3;
		}
		if (traj.Y > num3)
		{
			traj.Y = num3;
		}
		if (traj.Y < 0f - num3)
		{
			traj.Y = 0f - num3;
		}
		if (!flag)
		{
			return;
		}
		if (traj.X > 0f)
		{
			traj.X -= FMan.frameTime * 50f;
			if (traj.X < 0f)
			{
				traj.X = 0f;
			}
		}
		if (traj.X < 0f)
		{
			traj.X += FMan.frameTime * 50f;
			if (traj.X > 0f)
			{
				traj.X = 0f;
			}
		}
	}

	public void OldUpdate(RopeNode i, RopeNode j, Rope parent, float lim)
	{
		if (i == null)
		{
			return;
		}
		if (float.IsNaN(loc.X))
		{
			loc = i.loc;
		}
		if (float.IsNaN(traj.X) || float.IsInfinity(traj.X))
		{
			traj = default;
		}
		Vector2 vector = i.loc - loc;
		Vector2 vector2 = vector;
		vector2.Normalize();
		float num = vector.Length();
		if (num > parent.dist)
		{
			Vector2 vector3 = (num - parent.dist) * vector2 * FMan.frameTime * 61f;
			traj += vector3;
			if (num > parent.dist * 3f)
			{
				vector2 = -vector2;
				loc = i.loc + vector2 * parent.dist * 3f;
				traj -= vector3 * 0.125f;
				i.traj += vector3 * 0.125f;
			}
		}
		if (lim < 0f && loc.X < i.loc.X)
		{
			loc.X = i.loc.X;
			if (traj.X < 0f)
			{
				traj.X = 0f - traj.X;
			}
		}
		if (lim > 0f && loc.X > i.loc.X)
		{
			loc.X = i.loc.X;
			if (traj.X > 0f)
			{
				traj.X = 0f - traj.X;
			}
		}
		traj.Y += FMan.frameTime * 900f;
		if (traj.X > 0f)
		{
			traj.X -= FMan.frameTime * 50f;
			if (traj.X < 0f)
			{
				traj.X = 0f;
			}
		}
		if (traj.X < 0f)
		{
			traj.X += FMan.frameTime * 50f;
			if (traj.X > 0f)
			{
				traj.X = 0f;
			}
		}
	}
}
