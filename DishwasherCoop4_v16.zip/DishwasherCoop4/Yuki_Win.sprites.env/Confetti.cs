using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.env;

public class Confetti : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		switch (Rand.GetRandomInt(0, 3))
		{
		case 0:
			p.r = 1f;
			p.g = 1f;
			p.b = 0f;
			break;
		case 1:
			p.r = 1f;
			p.g = 0f;
			p.b = 0f;
			break;
		case 2:
			p.r = 1f;
			p.g = 0f;
			p.b = 1f;
			break;
		}
		p.size = Rand.GetRandomFloat(1f, 2f);
		p.flags = 0;
		p.frame = Rand.GetRandomFloat(4f, 5f);
		p.alpha = false;
		p.rDir = Rand.GetRandomFloat(-10f, 10f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.z = Rand.GetRandomFloat(0.9f, 1.3f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		p.traj.Y += FMan.frameTime * 800f;
		if (p.traj.Y > 0f)
		{
			if (p.traj.X > 50f)
			{
				p.traj.X = Rand.GetRandomFloat(-50f, 50f);
			}
			if (p.traj.X < -50f)
			{
				p.traj.X = Rand.GetRandomFloat(-50f, 50f);
			}
			if (p.traj.Y > 50f)
			{
				p.traj.Y = 50f;
			}
		}
		float frame = p.frame;
		base.Update(p, spriteMan);
		if ((int)(frame * 10f) != (int)(p.frame * 10f))
		{
			if (p.frame < 4f && Rand.CointToss(0.1f))
			{
				p.traj.X = Rand.GetRandomFloat(-50f, 50f);
			}
			if (Game1.gameMap.CurMap().TestCol(p.loc))
			{
				p.frame = -1f;
			}
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, p.z);
		float num = p.frame * 4f;
		num -= (float)(int)num;
		float num2 = 1f;
		sprite.Draw(scale: ScrollManager.cannedDepth[0] * 15f * new Vector2(0.25f, (num < 0.5f) ? ((!(num < 0.25f)) ? (0.5f - num) : num) : ((!(num < 0.75f)) ? (num - 0.5f) : (1f - num))) * p.z, texture: Game1.nullTex, position: screenLoc, sourceRectangle: new Rectangle(0, 0, 1, 1), color: (num < 0.5f) ? new Color(1f, 1f, 1f, 0.5f) : new Color(p.r, p.g, p.b, 0.5f), rotation: p.rotation, origin: new Vector2(0.5f, 0.5f), effects: SpriteEffects.None, layerDepth: 1f);
	}
}
