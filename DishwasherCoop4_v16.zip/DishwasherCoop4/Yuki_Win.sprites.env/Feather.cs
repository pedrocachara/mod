using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.env;

public class Feather : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.r = 1f;
		p.g = 1f;
		p.b = 1f;
		p.size = size;
		p.flags = 0;
		p.frame = 0.5f;
		p.alpha = false;
		p.rDir = Rand.GetRandomFloat(-10f, 10f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		sprite.Draw(spritesTex, screenLoc, new Rectangle(256, 64, 64, 32), new Color(0f, 0f, 0f, p.frame * 5f), p.rotation, new Vector2(32f, 16f), ScrollManager.cannedDepth[0] * 0.2f, SpriteEffects.None, 1f);
	}
}
