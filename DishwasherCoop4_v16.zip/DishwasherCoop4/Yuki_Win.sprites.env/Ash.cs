using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.env;

public class Ash : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.r = Rand.GetRandomFloat(0f, 1f);
		p.g = 1f;
		p.b = 1f;
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 6);
		p.frame = 3.14f;
		p.alpha = false;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.rDir = Rand.GetRandomFloat(-2f, 2f);
		p.z = Rand.GetRandomFloat(1f, 3f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		if ((int)(frame * 20f) != (int)((frame - FMan.frameTime) * 20f))
		{
			p.traj += Rand.GetRandomVec2(-15f, 15f, -15f, 15f);
		}
		p.rotation += p.rDir * FMan.frameTime;
		float num = 20f;
		if (p.traj.X < 0f - num)
		{
			p.traj.X = 0f - num;
		}
		if (p.traj.X > num)
		{
			p.traj.X = num;
		}
		if (p.traj.Y < 0f - num)
		{
			p.traj.Y = 0f - num;
		}
		if (p.traj.Y > num * 3f)
		{
			p.traj.Y = num * 3f;
		}
		Vector2 realLoc = ScrollManager.GetRealLoc(default, p.z);
		Vector2 realLoc2 = ScrollManager.GetRealLoc(ScrollManager.screenSize, p.z);
		if (p.loc.X < realLoc.X)
		{
			p.loc.X = realLoc2.X;
		}
		if (p.loc.Y < realLoc.Y)
		{
			p.loc.Y = realLoc2.Y;
		}
		if (p.loc.X > realLoc2.X)
		{
			p.loc.X = realLoc.X;
		}
		if (p.loc.Y > realLoc2.Y)
		{
			p.loc.Y = realLoc.Y;
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, p.z);
		Rectangle value = new Rectangle(384 + p.flags * 64, 320, 64, 64);
		float rotation = p.rotation;
		float size = p.size;
		_ = p.frame;
		_ = p.frame;
		float x = ((p.frame > 0.5f) ? (1f - p.frame) : p.frame) * 2f;
		sprite.Draw(spritesTex, screenLoc, value, new Color(0f, 0f, 0f, 2f * (float)Math.Sin(p.frame)), rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * size * new Vector2(x, 1f) * p.z * 0.2f, SpriteEffects.None, 1f);
	}
}
