using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;

namespace Yuki_Win.sprites.env;

public class HammerStuff : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.r = 1f;
		p.g = 1f;
		p.b = 1f;
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 4);
		p.frame = Rand.GetRandomFloat(0.25f, 1.25f);
		p.alpha = false;
		p.rDir = Rand.GetRandomFloat(-40f, 40f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.owner = 1;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += FMan.frameTime * p.rDir;
		p.traj.Y += FMan.frameTime * 1200f;
		p.frame -= FMan.frameTime;
		Vector2 loc = p.loc;
		p.loc.X += p.traj.X * FMan.frameTime;
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.loc.X = loc.X;
			p.traj.X *= -0.5f;
			if (p.owner > 0)
			{
				Sound.PlaySnd(Sound.Category.FX, "junkbit");
				p.owner = -1;
			}
			p.rDir = Rand.GetRandomFloat(-10f, 10f);
		}
		p.loc.Y += p.traj.Y * FMan.frameTime;
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.loc.Y = loc.Y;
			p.traj.Y *= -0.4f;
			if (p.owner > 0)
			{
				Sound.PlaySnd(Sound.Category.FX, "junkbit");
				p.owner = -1;
			}
			p.rDir = Rand.GetRandomFloat(-10f, 10f);
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		float num = p.frame * 5f;
		if (num > 0.7f)
		{
			num = 0.7f;
		}
		sprite.Draw(spritesTex, screenLoc, new Rectangle(512 + p.flags * 32, 576, 32, 64), new Color(1f, 1f, 1f, num), p.rotation, new Vector2(16f, 32f), ScrollManager.cannedDepth[0] * 0.6f, SpriteEffects.None, 1f);
	}
}
