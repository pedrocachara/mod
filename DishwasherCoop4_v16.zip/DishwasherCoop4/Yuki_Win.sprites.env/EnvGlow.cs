using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.maps;
using Yuki_Win.player;

namespace Yuki_Win.sprites.env;

public class EnvGlow : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.r = Rand.GetRandomFloat(0f, 1f);
		p.g = 1f;
		p.b = 1f;
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 5);
		p.frame = 3.14f;
		p.alpha = true;
		p.z = Rand.GetRandomFloat(0.1f, 2f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		if ((int)(frame * 20f) != (int)((frame - FMan.frameTime) * 20f))
		{
			p.traj += spriteMan.spriteRand.GetRandomVec2(-5f, 5f, -5f, 5f);
		}
		float num = 20f;
		if (Game1.gameMap.theme.theme == Themes.ThemeType.PrisonOut)
		{
			num = 2000f;
		}
		if (p.traj.X < 0f - num)
		{
			p.traj.X = 0f - num;
		}
		if (p.traj.X > num)
		{
			p.traj.X = num;
		}
		if (p.traj.Y < 0f - num)
		{
			p.traj.Y = 0f - num;
		}
		if (p.traj.Y > num)
		{
			p.traj.Y = num;
		}
		Vector2 realLoc = ScrollManager.GetRealLoc(default, p.z);
		Vector2 realLoc2 = ScrollManager.GetRealLoc(ScrollManager.screenSize, p.z);
		if (p.loc.X < realLoc.X)
		{
			p.loc.X = realLoc2.X;
		}
		if (p.loc.Y < realLoc.Y)
		{
			p.loc.Y = realLoc2.Y;
		}
		if (p.loc.X > realLoc2.X)
		{
			p.loc.X = realLoc.X;
		}
		if (p.loc.Y > realLoc2.Y)
		{
			p.loc.Y = realLoc.Y;
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, p.z);
		Rectangle value = new Rectangle(576 + p.flags * 64, 192, 64, 64);
		float r = 1f;
		float g = 1f;
		float b = 1f;
		float rotation = p.frame;
		float num = p.size * 4f;
		float num2 = 0.1f;
		if (GameSettings.difficulty == 0)
		{
			value = new Rectangle(832, 64, 64, 64);
			r = p.r / 2f + 0.5f;
			g = 0.5f;
			b = (1f - p.r) / 2f + 0.5f;
			rotation = 0f;
			num = 0.5f;
			num2 = 0.25f;
		}
		sprite.Draw(spritesTex, screenLoc, value, new Color(r, g, b, (float)Math.Sin(p.frame) * num2), rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * num * p.z * 0.7f, SpriteEffects.None, 1f);
	}
}
