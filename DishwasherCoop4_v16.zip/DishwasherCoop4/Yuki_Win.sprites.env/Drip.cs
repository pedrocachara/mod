using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.env;

public class Drip : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.r = 1f;
		p.g = 1f;
		p.b = 1f;
		p.size = size;
		p.flags = 0;
		p.frame = 0.3f;
		p.alpha = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		sprite.Draw(spritesTex, screenLoc, new Rectangle(448, 32, 128, 32), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0f, 1f) * Rand.GetRandomFloat(0f, 0.5f)), 1.57f, new Vector2(64f, 16f), ScrollManager.cannedDepth[0] * Rand.GetRandomFloat(0f, 0.2f), SpriteEffects.None, 1f);
	}
}
