using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.maps;

namespace Yuki_Win.sprites.env;

internal class Ice : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 1.1f;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.r = Rand.GetRandomFloat(-1f, 1f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		base.Update(p, spriteMan);
		p.traj.Y += FMan.frameTime * 400f;
		Map map = Game1.gameMap.CurMap();
		if (map.TestCol(p.loc))
		{
			p.frame -= FMan.frameTime * 20f;
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = 1f;
		if (p.frame > 1.1f)
		{
			num = (1.2f - p.frame) * 10f;
		}
		else if (p.frame < 1f)
		{
			num = p.frame;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(768, 256, 128, 128), new Color(1f, 1f, 1f, num * 0.25f), p.rotation, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * p.size + (1.2f - p.frame) * 1f, SpriteEffects.None, 1f);
	}
}
