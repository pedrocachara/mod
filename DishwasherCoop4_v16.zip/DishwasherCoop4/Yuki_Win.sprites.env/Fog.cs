using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.env;

public class Fog : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.r = 1f;
		p.g = 1f;
		p.b = 1f;
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 2);
		p.frame = 6.28f;
		p.alpha = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += FMan.frameTime * 0.2f;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		sprite.Draw(spritesTex, screenLoc, new Rectangle(192 * p.flags, 448, 192, 192), new Color(new Vector4(p.r, p.g, p.b, 0.125f * (float)Math.Sin((double)p.frame * 0.5))), p.rotation, new Vector2(96f, 96f), p.size * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
	}
}
