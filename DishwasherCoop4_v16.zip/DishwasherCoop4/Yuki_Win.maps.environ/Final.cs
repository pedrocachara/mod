using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.maps.environ;

public class Final
{
	public Flame[] flame;

	public Final()
	{
		flame = new Flame[128];
		for (int i = 0; i < flame.Length; i++)
		{
			flame[i] = new Flame(i);
		}
	}

	public void Update()
	{
		for (int i = 0; i < flame.Length; i++)
		{
			flame[i].Update();
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		for (int i = 0; i < flame.Length; i++)
		{
			flame[i].Draw(sprite);
		}
	}
}
