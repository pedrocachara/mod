using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.maps.environ;

public class Ship
{
	public Vector2 loc;

	public Vector2 traj;

	public float depth;

	private int idx;

	public Ship(int idx)
	{
		this.idx = idx;
	}

	internal void Update(GameMap map)
	{
		loc += traj * FMan.frameTime;
		float num = 100f;
		float num2 = ScrollManager.GetRealLoc(new Vector2(0f, 0f), depth).X - num;
		float num3 = ScrollManager.GetRealLoc(new Vector2(ScrollManager.screenSize.X, 0f), depth).X + num;
		float num4 = num3 - num2;
		if (loc.X < num2)
		{
			loc.X += num4;
		}
		if (loc.X > num3)
		{
			loc.X -= num4;
		}
	}

	internal void Draw(SpriteBatch sprite)
	{
		float num = (depth - 0.2f) * 7f;
		if (num < 0f)
		{
			num = 0f;
		}
		if (num > 1f)
		{
			num = 1f;
		}
		float num2 = ((GameRender.fadingBackgroundMode == GameRender.FadingBackgroundMode.None) ? 1f : 0.25f);
		if (Game1.gameMap.redLightval > 0f)
		{
			num -= Game1.gameMap.redLightval;
		}
		Rectangle rectangle = new Rectangle(idx % 4 * 128, 0, 128, 64);
		int num3 = idx % 4;
		rectangle = new Rectangle(num3 % 2 * 128, 192 + num3 / 2 * 64, 128, 64);
		ScrollManager.GetSize(depth);
		sprite.Draw(Game1.environText, ScrollManager.GetScreenLoc(loc, depth) * num2, rectangle, new Color(num, num, num, 1f), 0f, new Vector2(64f, 32f), depth * ScrollManager.GetSize(depth) * 0.1f * num2, (traj.X > 0f) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
	}
}
