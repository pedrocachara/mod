using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.maps.environ;

public class Aquarium
{
	public Shark[] shark = new Shark[4];

	public bool active;

	public Aquarium()
	{
		for (int i = 0; i < shark.Length; i++)
		{
			shark[i] = new Shark();
		}
	}

	public void Update()
	{
		for (int i = 0; i < shark.Length; i++)
		{
			shark[i].Update();
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		SpriteTools.BeginAlpha();
		for (int i = 0; i < shark.Length; i++)
		{
			shark[i].Draw(sprite);
		}
		SpriteTools.End();
	}
}
