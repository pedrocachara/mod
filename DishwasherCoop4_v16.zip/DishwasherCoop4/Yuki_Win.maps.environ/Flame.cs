using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.maps.environ;

public class Flame
{
	public Vector2 loc;

	public Vector2 traj;

	public int ID;

	private float r;

	private float rDir;

	public Flame(int ID)
	{
		loc = Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, ScrollManager.screenSize.Y * 0.69f, ScrollManager.screenSize.X);
		traj = Rand.GetRandomVec2(500f, 1000f, -500f, 0f);
		rDir = Rand.GetRandomFloat(-2f, 2f);
		this.ID = ID;
	}

	internal void Update()
	{
		loc += traj * FMan.frameTime;
		r += rDir * FMan.frameTime;
		while (r > 6.28f)
		{
			r -= 6.28f;
		}
		while (r < 0f)
		{
			r += 6.28f;
		}
		if (loc.X > ScrollManager.screenSize.X + 100f)
		{
			loc.X = Rand.GetRandomFloat(-200f, -100f);
			loc.Y = Rand.GetRandomFloat(ScrollManager.screenSize.Y * 0.69f, ScrollManager.screenSize.X);
			traj = Rand.GetRandomVec2(500f, 1000f, -500f, 0f);
			rDir = Rand.GetRandomFloat(-2f, 2f);
		}
		if (loc.Y < 400f)
		{
			loc.Y = 1280f;
		}
	}

	internal void Draw(SpriteBatch sprite)
	{
		float num = 1f;
		if (loc.Y < 600f)
		{
			num = (loc.Y - 400f) / 200f;
		}
		if (loc.Y > 1080f)
		{
			num = (1280f - loc.Y) / 200f;
		}
		if (Game1.gameMap.CrazyTransitionInFrame > 0f)
		{
			num *= (3f - Game1.gameMap.CrazyTransitionInFrame) / 3f;
		}
		float num2 = 0.25f;
		num2 = 1f;
		sprite.Draw(Game1.spritesTex, new Vector2(loc.X, 600f + loc.Y - ScrollManager.scroll.Y) * num2, new Rectangle(ID % 6 * 64 + 384, 320, 64, 64), new Color(0.6f * num, 0.1f * num, 0.1f * num, 1f), r, new Vector2(32f, 32f), 5f * num2 * (ScrollManager.screenSize.X / 1280f), SpriteEffects.None, 1f);
	}
}
