using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;
using Yuki_Win.chars;

namespace Yuki_Win.maps.environ;

public class Shark
{
	private const int IDLE_ANIM = 0;

	private const int TURN_ANIM = 1;

	private const int TEXTURE = 39;

	private const float size = 0.35f;

	public Vector2 loc;

	public int face;

	public Vector2 traj;

	public Vector2 goalVec;

	private float frame;

	private int anim;

	private float layer = 0.7f;

	private int key;

	public Shark()
	{
		GetRandomGoal();
	}

	private void GetRandomGoal()
	{
		Vector2 realLoc = ScrollManager.GetRealLoc(new Vector2(0f, 0f), layer);
		Vector2 realLoc2 = ScrollManager.GetRealLoc(ScrollManager.screenSize, layer);
		goalVec = Rand.GetRandomVec2(realLoc.X - 500f, realLoc2.X + 500f, realLoc.Y - 100f, realLoc2.Y + 100f);
	}

	public void Update()
	{
		CharDef charDef = Game1.charDef[24];
		Vector2 vector = goalVec - loc;
		traj += (vector - traj) * FMan.frameTime * 0.4f;
		if (traj.X > 200f)
		{
			traj.X = 200f;
		}
		if (traj.Y > 50f)
		{
			traj.Y = 50f;
		}
		if (traj.Y < -50f)
		{
			traj.Y = -50f;
		}
		if (traj.X < -200f)
		{
			traj.X = -200f;
		}
		loc += traj * FMan.frameTime * layer;
		if (anim != 1)
		{
			if (traj.X > 0f && face == 1)
			{
				face = 0;
				anim = 1;
				key = 0;
				frame = 0f;
			}
			if (traj.X < 0f && face == 0)
			{
				face = 1;
				anim = 1;
				key = 0;
				frame = 0f;
			}
		}
		if ((loc.X > goalVec.X - 50f && loc.X < goalVec.X + 50f) || (loc.Y > goalVec.Y - 50f && loc.Y < goalVec.Y + 50f))
		{
			GetRandomGoal();
		}
		frame += FMan.frameTime * 30f;
		Animation animation = charDef.GetAnimation(anim);
		KeyFrame[] keyFrameArray = animation.getKeyFrameArray();
		if (!(frame > (float)keyFrameArray[key].duration))
		{
			return;
		}
		key++;
		frame = 0f;
		if (keyFrameArray[key] == null)
		{
			if (anim == 1)
			{
				key = 0;
				anim = 0;
			}
			else
			{
				key = 0;
			}
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		CharDef charDef = Game1.charDef[24];
		float num = 0.25f;
		Vector2 vector = ScrollManager.GetScreenLoc(loc, layer) * num;
		float num2 = ScrollManager.zoom * 0.35f * layer * num;
		Animation animation = charDef.GetAnimation(anim);
		KeyFrame[] keyFrameArray = animation.getKeyFrameArray();
		if (keyFrameArray[key] == null)
		{
			key = 0;
		}
		Frame frame = charDef.GetFrame(keyFrameArray[key].frameRef);
		Rectangle rectangle = default;
		float num3 = vector.X - 640f;
		if (num3 < 0f)
		{
			num3 = 0f - num3;
		}
		num3 = (640f - num3) / 640f;
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx > -1)
			{
				float num4 = part.rotation;
				Vector2 position = part.location * num2 + vector;
				Vector2 scale = part.scaling * num2;
				if (face == 0)
				{
					num4 = 0f - num4;
					position.X -= part.location.X * num2 * 2f;
				}
				Texture2D texture2D = Game1.headTex[39];
				rectangle = Game1.headTexMeta[39].GetRect(part.idx);
				Color color = new Color(0f, 0f, 0f, 1f);
				bool flag = false;
				if ((face == 1 && part.flip == 0) || (face == 0 && part.flip == 1))
				{
					flag = true;
				}
				if (texture2D != null)
				{
					rectangle.X /= 2;
					rectangle.Y /= 2;
					rectangle.Width /= 2;
					rectangle.Height /= 2;
					scale *= 2f;
					sprite.Draw(texture2D, position, rectangle, color, num4, new Vector2((float)rectangle.Width / 2f, (float)rectangle.Height / 2f), scale, (!flag) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
				}
			}
		}
	}
}
