using System.IO;

namespace Yuki_Win.achievements.cheevos;

public class Separate100Dudes : AchievementDef
{
	public int dudesChopped;

	public override void Write(BinaryWriter writer)
	{
		writer.Write(dudesChopped);
		base.Write(writer);
	}

	public override void Read(BinaryReader reader)
	{
		dudesChopped = reader.ReadInt32();
		base.Read(reader);
	}

	public override void Unlock(bool overRide)
	{
		if (overRide)
		{
			base.Unlock(overRide: false);
		}
		else if (dudesChopped >= 100)
		{
			base.Unlock(overRide: false);
		}
	}

	internal override void Copy(AchievementDef src)
	{
		Separate100Dudes separate100Dudes = (Separate100Dudes)src;
		dudesChopped = separate100Dudes.dudesChopped;
		base.Copy(src);
	}
}
