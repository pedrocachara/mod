using System.IO;

namespace Yuki_Win.achievements.cheevos;

public class BloodyPaintings : AchievementDef
{
	public bool bankerPainting;

	public bool generalPainting;

	public bool judgePainting;

	public override void Write(BinaryWriter writer)
	{
		writer.Write(bankerPainting);
		writer.Write(generalPainting);
		writer.Write(judgePainting);
		base.Write(writer);
	}

	public override void Read(BinaryReader reader)
	{
		bankerPainting = reader.ReadBoolean();
		generalPainting = reader.ReadBoolean();
		judgePainting = reader.ReadBoolean();
		base.Read(reader);
	}

	public override void Unlock(bool overRide)
	{
		if (overRide)
		{
			base.Unlock(overRide: false);
		}
		else if (bankerPainting && generalPainting && judgePainting)
		{
			base.Unlock(overRide: false);
		}
	}

	internal override void Copy(AchievementDef src)
	{
		BloodyPaintings bloodyPaintings = (BloodyPaintings)src;
		bankerPainting = bloodyPaintings.bankerPainting;
		generalPainting = bloodyPaintings.generalPainting;
		judgePainting = bloodyPaintings.judgePainting;
		base.Copy(src);
	}
}
