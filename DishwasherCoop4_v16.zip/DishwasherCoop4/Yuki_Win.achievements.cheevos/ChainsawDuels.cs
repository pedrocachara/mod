using System.IO;

namespace Yuki_Win.achievements.cheevos;

public class ChainsawDuels : AchievementDef
{
	public int duelsWon;

	public override void Write(BinaryWriter writer)
	{
		writer.Write(duelsWon);
		base.Write(writer);
	}

	public override void Read(BinaryReader reader)
	{
		duelsWon = reader.ReadInt32();
		base.Read(reader);
	}

	public override void Unlock(bool overRide)
	{
		if (overRide)
		{
			base.Unlock(overRide: false);
		}
		else if (duelsWon >= 3)
		{
			base.Unlock(overRide: false);
		}
	}

	internal override void Copy(AchievementDef src)
	{
		ChainsawDuels chainsawDuels = (ChainsawDuels)src;
		duelsWon = chainsawDuels.duelsWon;
		base.Copy(src);
	}
}
