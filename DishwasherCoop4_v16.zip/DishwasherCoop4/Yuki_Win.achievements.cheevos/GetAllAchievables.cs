using System.IO;

namespace Yuki_Win.achievements.cheevos;

public class GetAllAchievables : AchievementDef
{
	public bool openPresents;

	public bool doubleJump;

	public bool squirtgunFight;

	public bool killSquid;

	public bool watchCredits;

	public bool achievable6;

	public bool achievable7;

	public bool achievable8;

	public override void Read(BinaryReader reader)
	{
		openPresents = reader.ReadBoolean();
		doubleJump = reader.ReadBoolean();
		squirtgunFight = reader.ReadBoolean();
		killSquid = reader.ReadBoolean();
		watchCredits = reader.ReadBoolean();
		achievable6 = reader.ReadBoolean();
		achievable7 = reader.ReadBoolean();
		achievable8 = reader.ReadBoolean();
		base.Read(reader);
	}

	public override void Write(BinaryWriter writer)
	{
		writer.Write(openPresents);
		writer.Write(doubleJump);
		writer.Write(squirtgunFight);
		writer.Write(killSquid);
		writer.Write(watchCredits);
		writer.Write(achievable6);
		writer.Write(achievable7);
		writer.Write(achievable8);
		base.Write(writer);
	}

	public override void Unlock(bool overRide)
	{
		if (overRide)
		{
			base.Unlock(overRide: false);
			return;
		}
		Game1.menuMgr.achievable.Init();
		if (openPresents && doubleJump && squirtgunFight && killSquid && watchCredits)
		{
			base.Unlock(overRide: false);
		}
	}

	internal override void Copy(AchievementDef src)
	{
		GetAllAchievables getAllAchievables = (GetAllAchievables)src;
		openPresents = getAllAchievables.openPresents;
		doubleJump = getAllAchievables.doubleJump;
		squirtgunFight = getAllAchievables.squirtgunFight;
		killSquid = getAllAchievables.killSquid;
		watchCredits = getAllAchievables.watchCredits;
		achievable6 = getAllAchievables.achievable6;
		achievable7 = getAllAchievables.achievable7;
		achievable8 = getAllAchievables.achievable8;
		base.Copy(src);
	}
}
