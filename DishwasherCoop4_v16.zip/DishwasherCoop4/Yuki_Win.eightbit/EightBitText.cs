using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.eightbit;

public class EightBitText
{
	public static void DrawString(SpriteBatch sprite, Texture2D eightBitTex, StringBuilder text, int x, int y, int len, bool selected)
	{
		if (Text.IsAsian())
		{
			if (selected)
			{
				sprite.Draw(Game1.nullTex, new Rectangle(x * 5, (y + 1) * 5, 8 * len * 5, 60), new Rectangle(0, 0, 1, 1), new Color(1f, 1f, 1f, 1f));
			}
			Text.DrawCText(sprite, new Vector2((x + 3) * 5, y * 5), text, selected ? new Color(0f, 0f, 0f, 1f) : new Color(1f, 1f, 1f, 1f), 1.6500001f, 0);
			return;
		}
		if (len == -1)
		{
			len = text.Length;
		}
		if (len > text.Length)
		{
			len = text.Length;
		}
		if (selected)
		{
			sprite.Draw(Game1.nullTex, new Rectangle(x, y + 1, 8 * len, 12), new Rectangle(0, 0, 1, 1), new Color(1f, 1f, 1f, 1f));
		}
		int num = 218;
		if (text.Length * 7 > num)
		{
			float num2 = (float)num / (float)(text.Length * 7);
			float num3 = x;
			float y2 = y;
			for (int i = 0; i < len; i++)
			{
				int num4 = GetIdx(text[i]);
				if (len < text.Length && i == len - 1)
				{
					num4 = Rand.GetRandomInt(0, 44);
				}
				if (num4 > -1)
				{
					sprite.Draw(sourceRectangle: new Rectangle(432 + num4 % 10 * 8, 12 + num4 / 10 * 12, 8, 12), texture: eightBitTex, position: new Vector2(num3, y2), color: (!selected) ? new Color(1f, 1f, 1f, 1f) : new Color(0f, 0f, 0f, 1f), rotation: 0f, origin: default, scale: new Vector2(num2, 1f), effects: SpriteEffects.None, layerDepth: 1f);
				}
				num3 += 7f * num2;
			}
			return;
		}
		for (int j = 0; j < len; j++)
		{
			int num5 = GetIdx(text[j]);
			if (len < text.Length && j == len - 1)
			{
				num5 = Rand.GetRandomInt(0, 44);
			}
			if (num5 > -1)
			{
				Rectangle value = new Rectangle(432 + num5 % 10 * 8, 12 + num5 / 10 * 12, 8, 12);
				if (selected)
				{
					sprite.Draw(eightBitTex, new Rectangle(x, y, 8, 12), value, new Color(0f, 0f, 0f, 1f));
				}
				else
				{
					sprite.Draw(eightBitTex, new Rectangle(x, y, 8, 12), value, new Color(1f, 1f, 1f, 1f));
				}
			}
			x += 7;
		}
	}

	private static int GetIdx(char c)
	{
		switch (c)
		{
		case 'A':
		case 'a':
			return 0;
		case 'B':
		case 'b':
			return 1;
		case 'C':
		case 'c':
			return 2;
		case 'D':
		case 'd':
			return 3;
		case 'E':
		case 'e':
			return 4;
		case 'F':
		case 'f':
			return 5;
		case 'G':
		case 'g':
			return 6;
		case 'H':
		case 'h':
			return 7;
		case 'I':
		case 'i':
			return 8;
		case 'J':
		case 'j':
			return 9;
		case 'K':
		case 'k':
			return 10;
		case 'L':
		case 'l':
			return 11;
		case 'M':
		case 'm':
			return 12;
		case 'N':
		case 'n':
			return 13;
		case 'O':
		case 'o':
			return 14;
		case 'P':
		case 'p':
			return 15;
		case 'Q':
		case 'q':
			return 16;
		case 'R':
		case 'r':
			return 17;
		case 'S':
		case 's':
			return 18;
		case 'T':
		case 't':
			return 19;
		case 'U':
		case 'u':
			return 20;
		case 'V':
		case 'v':
			return 21;
		case 'W':
		case 'w':
			return 22;
		case 'X':
		case 'x':
			return 23;
		case 'Y':
		case 'y':
			return 24;
		case 'Z':
		case 'z':
			return 25;
		case '.':
			return 26;
		case ',':
			return 27;
		case '!':
			return 28;
		case ':':
			return 29;
		case '?':
			return 30;
		case '_':
			return 31;
		case '0':
			return 32;
		case '1':
			return 33;
		case '2':
			return 34;
		case '3':
			return 35;
		case '4':
			return 36;
		case '5':
			return 37;
		case '6':
			return 38;
		case '7':
			return 39;
		case '8':
			return 40;
		case '9':
			return 41;
		case '(':
			return 42;
		case ')':
			return 43;
		case 'Á':
		case 'á':
			return 44;
		case 'À':
		case 'à':
			return 45;
		case 'É':
		case 'é':
			return 46;
		case 'È':
		case 'è':
			return 47;
		case 'Ó':
		case 'ó':
			return 48;
		case 'Í':
		case 'í':
			return 49;
		case 'Î':
		case 'î':
			return 50;
		case 'Ê':
		case 'ê':
			return 51;
		case 'ç':
			return 52;
		case '¡':
			return 53;
		case 'Ñ':
		case 'ñ':
			return 54;
		case 'ä':
			return 55;
		case 'ö':
			return 56;
		case 'â':
			return 57;
		case 'ß':
			return 58;
		case '-':
			return 59;
		case ' ':
			return -1;
		default:
			return -1;
		}
	}
}
