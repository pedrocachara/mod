using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.chars;

namespace Yuki_Win.eightbit;

internal class EightBitChar
{
	public enum Anim
	{
		Idle,
		Running,
		Attacking,
		Hit,
		Dead,
		Flying
	}

	public Vector2 loc;

	public Vector2 traj;

	public bool exists;

	public float frame;

	public int ID;

	public int face;

	private bool keyLeft;

	private bool keyRight;

	private bool keyAttack;

	private bool keyJump;

	public int tex;

	public float etherealFrame;

	public Anim anim;

	public void Update(EightBitChar[] chars)
	{
		loc.X += traj.X * FMan.frameTime;
		if (loc.Y < 0f)
		{
			traj.Y += FMan.frameTime * 800f;
			loc.Y += traj.Y * FMan.frameTime;
			if (loc.Y > 0f)
			{
				loc.Y = 0f;
				anim = Anim.Idle;
			}
		}
		else
		{
			traj.X = 0f;
		}
		if (etherealFrame > 0f)
		{
			etherealFrame -= FMan.frameTime;
		}
		keyLeft = false;
		keyRight = false;
		keyJump = false;
		keyAttack = false;
		if (ID < 2)
		{
			if (Game1.character[ID].charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[Game1.character[ID].charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				Game1.character[ID].charUpdate.charGrab.grabbedByChar = -1;
			}
			Game1.character[ID].charKeys.Update(Game1.character[ID].ai, Game1.character, Game1.character[ID]);
			CharKeys charKeys = Game1.character[ID].charKeys;
			if (charKeys.keyLeft)
			{
				keyLeft = true;
			}
			if (charKeys.keyRight)
			{
				keyRight = true;
			}
			if (charKeys.keyJump)
			{
				keyJump = true;
			}
			if (charKeys.keyAttack)
			{
				keyAttack = true;
			}
		}
		else
		{
			if (face == 0)
			{
				keyLeft = true;
			}
			if (face == 1)
			{
				keyRight = true;
			}
			if (anim == Anim.Running)
			{
				for (int i = 0; i < 2; i++)
				{
					if (chars[i].exists && chars[i].etherealFrame <= 0f && loc.X > chars[i].loc.X - 16f && loc.X < chars[i].loc.X + 16f && loc.Y > chars[i].loc.Y - 4f && loc.Y < chars[i].loc.Y + 4f && chars[i].anim != Anim.Hit)
					{
						chars[i].anim = Anim.Hit;
						if (chars[i].loc.Y >= 0f)
						{
							chars[i].loc.Y = -1f;
						}
						chars[i].traj.X = (float)chars[i].face - 0.5f;
						chars[i].traj.X *= -150f;
						chars[i].traj.Y = -100f;
						chars[i].etherealFrame = 2f;
					}
				}
			}
		}
		float num = frame;
		switch (anim)
		{
		case Anim.Idle:
		case Anim.Running:
			if (keyLeft)
			{
				face = 0;
				if (anim != Anim.Running)
				{
					anim = Anim.Running;
					frame = 0f;
				}
				else
				{
					frame += FMan.frameTime * 2f;
					if (frame > 0.5f)
					{
						frame -= 0.5f;
					}
				}
				traj.X = -60f;
			}
			else if (keyRight)
			{
				face = 1;
				if (anim != Anim.Running)
				{
					anim = Anim.Running;
					frame = 0f;
				}
				else
				{
					frame += FMan.frameTime * 2f;
					if (frame > 0.5f)
					{
						frame -= 0.5f;
					}
				}
				traj.X = 60f;
			}
			else
			{
				anim = Anim.Idle;
			}
			if (keyJump)
			{
				anim = Anim.Flying;
				loc.Y = -1f;
				traj.Y = -200f;
			}
			if (keyAttack)
			{
				anim = Anim.Attacking;
				frame = 0f;
				Sound.PlaySnd(Sound.Category.FX, "8bitsword");
			}
			break;
		case Anim.Attacking:
			frame += FMan.frameTime * 4f;
			if (num < 0.1f && frame >= 0.1f)
			{
				bool flag = false;
				Vector2 vector = loc + new Vector2(16f * ((face == 1) ? 1f : (-1f)), -6f);
				for (int j = 2; j < chars.Length; j++)
				{
					if (chars[j].exists && chars[j].anim != Anim.Hit && vector.X > chars[j].loc.X - 21f && vector.X < chars[j].loc.X + 21f && vector.Y > chars[j].loc.Y - 24f && vector.Y < chars[j].loc.Y)
					{
						chars[j].anim = Anim.Hit;
						chars[j].frame = 0f;
						flag = true;
					}
				}
				if (flag)
				{
					Sound.PlaySnd(Sound.Category.FX, "8bitslash");
				}
			}
			if (frame > 0.5f)
			{
				anim = Anim.Idle;
				frame = 0f;
			}
			break;
		case Anim.Flying:
			frame += FMan.frameTime * 4f;
			if (frame > 0.4f)
			{
				frame -= 0.4f;
			}
			break;
		case Anim.Hit:
			if (ID >= 2)
			{
				frame += FMan.frameTime * 8f;
				if (frame >= 1f)
				{
					exists = false;
				}
			}
			break;
		case Anim.Dead:
			break;
		}
	}

	public void Draw(SpriteBatch sprite, Texture2D eightBitTex)
	{
		int num = 0;
		switch (anim)
		{
		case Anim.Idle:
			num = 0;
			break;
		case Anim.Running:
			num = ((frame < 0.25f) ? 1 : 2);
			break;
		case Anim.Flying:
			num = (int)(frame * 10f) + 3;
			break;
		case Anim.Dead:
			num = 8;
			break;
		case Anim.Hit:
			num = 7;
			break;
		case Anim.Attacking:
			if (frame < 0.1f)
			{
				num = 9;
			}
			else
			{
				num = ((!(frame < 0.2f)) ? 11 : 10);
			}
			break;
		}
		Rectangle value = new Rectangle(num % 9 * 24, num / 9 * 24, 24, 24);
		if (num > 8)
		{
			value.Width = 48;
			value.X = (num - 9) * 48;
		}
		value.X += 216 * (tex % 2);
		value.Y += 48 * (tex / 2);
		Rectangle destinationRectangle = new Rectangle((int)loc.X, (int)loc.Y - 22 + 96, value.Width, value.Height);
		if (num > 8 && face == 0)
		{
			destinationRectangle.X -= 24;
		}
		if (ID >= 2 && anim == Anim.Hit)
		{
			for (int i = 0; i < 4; i++)
			{
				sprite.Draw(eightBitTex, new Rectangle((int)loc.X + (int)((float)Math.Cos((float)(i - 1) * 1.57f + 0.785f) * (frame + 0.3f) * 20f) + 12, (int)loc.Y + (int)((float)Math.Sin((float)(i - 1) * 1.57f + 0.785f) * (frame + 0.3f) * 20f) + 96 - 6 - 6, 12, 12), new Rectangle(432 + 12 * (int)(frame * 4f), 0, 12, 12), Color.White, (float)i * 1.57f, new Vector2(6f, 6f), SpriteEffects.None, 1f);
			}
		}
		else if (!(etherealFrame > 0f) || (int)(etherealFrame * 9f) % 2 != 0)
		{
			sprite.Draw(eightBitTex, destinationRectangle, value, Color.White, 0f, default, (face == 1) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
		}
	}

	public void Init(Vector2 loc, int tex, int face)
	{
		this.tex = tex;
		this.loc = loc;
		this.face = face;
		frame = 0f;
		if (this.loc.Y < 0f)
		{
			anim = Anim.Flying;
		}
		else
		{
			anim = Anim.Idle;
		}
		exists = true;
		traj = default;
	}

	public EightBitChar(int ID)
	{
		this.ID = ID;
		exists = false;
	}
}
