namespace Yuki_Win.eightbit;

internal class EightBitConsoleLevel
{
	public string[] text;

	public string[] options;

	public int lines;

	public EightBitConsoleLevel(string[] text, string[] options)
	{
		this.text = new string[text.Length];
		for (int i = 0; i < this.text.Length; i++)
		{
			this.text[i] = text[i];
		}
		this.options = new string[options.Length];
		for (int j = 0; j < this.options.Length; j++)
		{
			this.options[j] = options[j];
		}
		lines = this.text.Length - this.options.Length;
	}
}
