using System.Text;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.eightbit;

public class EightBitConsole
{
	private StringBuilder[] text;

	public int lines;

	public int updateLine;

	public int updateLen;

	public bool ready;

	private float updateFrame;

	public EightBitConsole()
	{
		text = new StringBuilder[24];
	}

	public void Reset()
	{
		lines = 0;
		for (int i = 0; i < text.Length; i++)
		{
			text[i] = null;
		}
		updateLine = 0;
		updateLen = 0;
		ready = false;
		updateFrame = 1f;
	}

	public void AddLine(string line)
	{
		text[lines] = new StringBuilder(line);
		lines++;
	}

	public void Update()
	{
		if (ready)
		{
			return;
		}
		if (text[updateLine].Length > updateLen)
		{
			updateFrame -= FMan.frameTime;
			if (!(updateFrame <= 0f))
			{
				return;
			}
			updateLen++;
			if (updateLen == text[updateLine].Length)
			{
				updateLen = 0;
				updateLine++;
				if (updateLine >= lines)
				{
					ready = true;
				}
			}
			updateFrame = Rand.GetRandomFloat(0f, 0.02f);
		}
		else if (text[updateLine].Length == updateLen)
		{
			updateLen = 0;
			updateLine++;
			if (updateLine >= lines)
			{
				ready = true;
			}
		}
	}

	public void Draw(SpriteBatch sprite, Texture2D eightBitTex, int selOption)
	{
		int x = 21;
		int num = 21;
		for (int i = 0; i < updateLine + 1; i++)
		{
			try
			{
				if (text[i] != null)
				{
					int length = text[i].Length;
					if (i == updateLine)
					{
						length = updateLen;
					}
					if (ready && selOption == i)
					{
						EightBitText.DrawString(sprite, eightBitTex, text[i], x, num, length, selected: true);
					}
					else
					{
						EightBitText.DrawString(sprite, eightBitTex, text[i], x, num, length, selected: false);
					}
					num += 12;
				}
			}
			catch
			{
			}
		}
	}
}
