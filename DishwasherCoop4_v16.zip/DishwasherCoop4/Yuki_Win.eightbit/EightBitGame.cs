using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.director;
using Yuki_Win.maps;

namespace Yuki_Win.eightbit;

public class EightBitGame
{
	private EightBitChar[] eightBitchar;

	public int map;

	public static bool enabled;

	public Effect eightBitEffect;

	private EffectPass pass;

	public float screenFrame;

	public float staticFrame;

	private EightBitConsoleMgr eightBitConsoleMgr;

	public float inFrame;

	public int monsters;

	private float outFrame;

	private float uberInFrame;

	public EightBitGame()
	{
		eightBitchar = new EightBitChar[32];
		for (int i = 0; i < eightBitchar.Length; i++)
		{
			eightBitchar[i] = new EightBitChar(i);
		}
		eightBitConsoleMgr = new EightBitConsoleMgr();
	}

	public void Update()
	{
		Music.track = 12;
		if (inFrame > 0f)
		{
			inFrame -= FMan.frameTime;
		}
		staticFrame -= FMan.frameTime;
		if (staticFrame <= 0f)
		{
			Game1.eightBitGame.staticFrame = 0.5f;
			if (Rand.CointToss(0.3f))
			{
				Sound.PlaySnd(Sound.Category.FX, "static1");
			}
			else if (Rand.CointToss(0.5f))
			{
				Sound.PlaySnd(Sound.Category.FX, "static2");
			}
			else
			{
				Sound.PlaySnd(Sound.Category.FX, "static3");
			}
		}
		screenFrame += FMan.frameTime * 4f;
		if (screenFrame > 10f)
		{
			screenFrame -= 10f;
		}
		if (map == 2)
		{
			eightBitConsoleMgr.Update();
			if (eightBitConsoleMgr.curLev == "end")
			{
				outFrame += FMan.frameTime;
				if (outFrame > 1f)
				{
					EndThing();
				}
			}
			else
			{
				outFrame = 0f;
			}
			return;
		}
		if (uberInFrame > 0f)
		{
			uberInFrame -= FMan.frameTime * 2f;
			return;
		}
		for (int i = 0; i < eightBitchar.Length; i++)
		{
			if (eightBitchar[i].exists)
			{
				eightBitchar[i].Update(eightBitchar);
			}
		}
		int num = 0;
		for (int j = 0; j < 2; j++)
		{
			if (eightBitchar[j].exists)
			{
				if (eightBitchar[j].loc.X < 10f)
				{
					eightBitchar[j].loc.X = 10f;
				}
				if (eightBitchar[j].loc.X > 216f)
				{
					eightBitchar[j].loc.X = 216f;
				}
			}
		}
		for (int k = 2; k < 16; k++)
		{
			if (!eightBitchar[k].exists)
			{
				if (monsters > 0)
				{
					if (Rand.CointToss(0.5f))
					{
						eightBitchar[k].Init(new Vector2(Rand.GetRandomFloat(-500f, 0f), 0f), map + 2, 1);
					}
					else
					{
						eightBitchar[k].Init(new Vector2(Rand.GetRandomFloat(256f, 756f), 0f), map + 2, 0);
					}
					monsters--;
				}
				continue;
			}
			num++;
			if (eightBitchar[k].loc.X < -20f && eightBitchar[k].face == 0)
			{
				eightBitchar[k].exists = false;
				monsters++;
			}
			if (eightBitchar[k].loc.X > 276f && eightBitchar[k].face == 1)
			{
				eightBitchar[k].exists = false;
				monsters++;
			}
		}
		if (num <= 0 && monsters <= 0)
		{
			outFrame += FMan.frameTime;
			if (outFrame > 1f)
			{
				EndThing();
			}
		}
	}

	public void EndThing()
	{
		Sound.PlaySnd(Sound.Category.FX, "staticin");
		enabled = false;
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (Game1.character[i].GetMeta().isInvalid)
			{
				Game1.character[0].charAnim.SetAnim("igrabbed", Game1.character[0].charUpdate, overRide: true);
				Game1.character[0].charUpdate.charGrab.grabbedByChar = i;
				Game1.character[i].charUpdate.charGrab.grabbing = true;
				Game1.character[i].charUpdate.lastSpecial = (Game1.character[0].charUpdate.lastSpecial = 1);
			}
		}
		switch (Game1.gameMap.invalidPhase)
		{
		case GameMap.InvalidPhase.Intro:
		case GameMap.InvalidPhase.Blackout:
			Game1.gameMap.psychoTVFrame = 5.9f;
			Sound.PlaySnd(Sound.Category.FX, "freak");
			break;
		case GameMap.InvalidPhase.Text:
			Game1.gameMap.psychoTVFrame = 1.9f;
			Sound.PlaySnd(Sound.Category.FX, "freakend");
			break;
		default:
			Game1.gameMap.psychoTVFrame = 2.9f;
			Sound.PlaySnd(Sound.Category.FX, "freakshort");
			break;
		}
		QuakeManager.SetBright(0.5f);
		switch (Game1.gameMap.invalidPhase)
		{
		case GameMap.InvalidPhase.Intro:
		case GameMap.InvalidPhase.Blackout:
			Game1.gameMap.invalidPhase = GameMap.InvalidPhase.Cem;
			break;
		case GameMap.InvalidPhase.Cem:
			Game1.gameMap.invalidPhase = GameMap.InvalidPhase.Text;
			break;
		case GameMap.InvalidPhase.Text:
			Game1.gameMap.invalidPhase = GameMap.InvalidPhase.Dishes;
			break;
		case GameMap.InvalidPhase.Dishes:
			break;
		}
	}

	public void Init(int map)
	{
		this.map = map;
		staticFrame = 0.5f;
		outFrame = 0f;
		Sound.PlaySnd(Sound.Category.FX, "static1");
		Sound.PlaySnd(Sound.Category.FX, "staticzap");
		Sound.PlaySnd(Sound.Category.FX, "staticin");
		monsters = 40;
		if (map == 2)
		{
			eightBitConsoleMgr.SetLevel("viking");
		}
		else
		{
			for (int i = 0; i < eightBitchar.Length; i++)
			{
				eightBitchar[i].exists = false;
			}
			eightBitchar[0].Init(new Vector2(108f, 0f), (!Game1.character[0].GetMeta().isDish) ? 1 : 0, 0);
			uberInFrame = 2f;
		}
		inFrame = 0.1f;
	}

	public void DrawStatic(SpriteBatch sprite, GraphicsDevice graphics, RenderTarget2D mainTarg)
	{
		graphics.SetRenderTarget(mainTarg);
		graphics.Clear(Color.Black);
		SpriteTools.BeginAlpha();
		for (int i = 0; i < 31; i++)
		{
			float randomFloat = Rand.GetRandomFloat(0f, 1f);
			sprite.Draw(Game1.spritesTex, Rand.GetRandomVec2(0f, 256f, 0f, 144f), new Rectangle(768, 256, 128, 128), new Color(randomFloat, randomFloat, randomFloat, 0.6f), Rand.GetRandomFloat(0f, 6.28f), new Vector2(64f, 64f), Rand.GetRandomFloat(2f, 3f), SpriteEffects.None, 1f);
		}
		sprite.End();
	}

	public void DrawStaticOverlay(SpriteBatch sprite, RenderTarget2D mainTarg, float a)
	{
		if (Game1.camMgr.bossToast.frame > 0f && a > 0.5f)
		{
			a = 0.5f - Rand.GetRandomFloat(0f, 0.1f);
		}
		eightBitEffect.Parameters["a"].SetValue(a);
		SpriteTools.BeginAlpha(eightBitEffect);
		sprite.Draw(mainTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, 1f));
		SpriteTools.End();
		SpriteTools.BeginAdditive();
		sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f, new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.16f, 0.17f)), 0f, new Vector2(64f, 64f), new Vector2(13f, 12f) * (ScrollManager.screenSize.X / 1280f), SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Vector2(ScrollManager.screenSize.X * 0.75f, ScrollManager.screenSize.Y * 0.22f), new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.03f, 0.04f)), 0f, new Vector2(64f, 64f), new Vector2(5f, 4f) * (ScrollManager.screenSize.X / 1280f), SpriteEffects.None, 1f);
		sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)(72f * screenFrame)), new Color(1f, 1f, 1f, (10f - screenFrame) / 10f * Rand.GetRandomFloat(0.03f, 0.04f)));
		SpriteTools.End();
	}

	public void Draw(SpriteBatch sprite, Texture2D eightBitTex, GraphicsDevice graphics, RenderTarget2D mainTarg)
	{
		Draw(sprite, eightBitTex, graphics, mainTarg, -1);
	}

	public void Draw(SpriteBatch sprite, Texture2D eightBitTex, GraphicsDevice graphics, RenderTarget2D mainTarg, int threedee)
	{
		graphics.SetRenderTarget(mainTarg);
		graphics.Clear(Color.Black);
		SpriteTools.BeginAlpha();
		if (map == 2)
		{
			if (!Text.IsAsian())
			{
				eightBitConsoleMgr.Draw(sprite, eightBitTex);
			}
		}
		else
		{
			sprite.Draw(eightBitTex, new Rectangle(0, 0, 256, 144), new Rectangle(map * 256, 96, 216, 144), Color.White);
			for (int i = 0; i < eightBitchar.Length; i++)
			{
				if (eightBitchar[i].exists)
				{
					eightBitchar[i].Draw(sprite, eightBitTex);
				}
			}
		}
		sprite.End();
		switch (threedee)
		{
		case -1:
			graphics.SetRenderTarget(null);
			break;
		case 0:
		case 1:
			graphics.SetRenderTarget(Game1.threeDeeTarg[threedee]);
			break;
		}
		eightBitEffect.Parameters["a"].SetValue(1f);
		SpriteTools.BeginAlpha(eightBitEffect);
		if (uberInFrame > 0f)
		{
			float num = uberInFrame;
			num *= 100f;
			num *= num;
			int num2 = (int)num % (int)ScrollManager.screenSize.Y;
			sprite.Draw(mainTarg, new Rectangle(0, num2, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Rectangle(0, 0, 1280, 720), new Color(1f, 1f, 1f, 1f));
			sprite.Draw(mainTarg, new Rectangle(0, num2 - (int)ScrollManager.screenSize.Y, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Rectangle(0, 0, 1280, 720), new Color(1f, 1f, 1f, 1f));
		}
		else
		{
			sprite.Draw(mainTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Rectangle(0, 0, 1280, 720), new Color(1f, 1f, 1f, 1f));
		}
		SpriteTools.End();
		if (map == 2 && Text.IsAsian())
		{
			SpriteTools.BeginAlpha();
			eightBitConsoleMgr.Draw(sprite, eightBitTex);
			SpriteTools.End();
		}
		SpriteTools.BeginAdditive();
		sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f, new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.16f, 0.17f)), 0f, new Vector2(64f, 64f), new Vector2(13f, 12f) * (ScrollManager.screenSize.X / 1280f), SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Vector2(ScrollManager.screenSize.X * 0.75f, ScrollManager.screenSize.Y * 0.22f), new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.03f, 0.04f)), 0f, new Vector2(64f, 64f), new Vector2(5f, 4f) * (ScrollManager.screenSize.X / 1280f), SpriteEffects.None, 1f);
		sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)(72f * screenFrame)), new Color(1f, 1f, 1f, (10f - screenFrame) / 10f * Rand.GetRandomFloat(0.03f, 0.04f)));
		if (inFrame > 0f)
		{
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Rectangle(0, 0, 1, 1), new Color(1f, 1f, 1f, inFrame * 10f));
		}
		sprite.End();
	}
}
