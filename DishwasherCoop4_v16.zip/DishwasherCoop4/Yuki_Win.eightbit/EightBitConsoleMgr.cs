using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.chars;

namespace Yuki_Win.eightbit;

public class EightBitConsoleMgr
{
	private EightBitConsole eightBitConsole;

	public string curLev;

	private Dictionary<string, EightBitConsoleLevel> levels;

	public int selOption;

	private bool pkeyUp;

	private bool pkeyDown;

	private bool pkeyA;

	public EightBitConsoleMgr()
	{
		eightBitConsole = new EightBitConsole();
		levels = new Dictionary<string, EightBitConsoleLevel>();
		levels.Add("viking", new EightBitConsoleLevel(new string[7]
		{
			YukiText.eb_viking1,
			YukiText.eb_viking2,
			YukiText.eb_viking3,
			"",
			YukiText.eb_1_Attack,
			YukiText.eb_2_Dodge,
			YukiText.eb_3_UseDishMagic
		}, new string[3] { "attacked", "dodged", "magicked" }));
		levels.Add("attacked", new EightBitConsoleLevel(new string[7]
		{
			YukiText.eb_attacked1,
			YukiText.eb_attacked2,
			YukiText.eb_attacked3,
			"",
			YukiText.eb_1_Attack,
			YukiText.eb_2_Dodge,
			YukiText.eb_3_UseDishMagic
		}, new string[3] { "attacked", "dodged", "magicked" }));
		levels.Add("dodged", new EightBitConsoleLevel(new string[7]
		{
			YukiText.eb_dodged1,
			YukiText.eb_dodged2,
			YukiText.eb_dodged3,
			"",
			YukiText.eb_1_Attack,
			YukiText.eb_2_Dodge,
			YukiText.eb_3_UseDishMagic
		}, new string[3] { "goodattack", "baddodged", "magicked" }));
		levels.Add("goodattack", new EightBitConsoleLevel(new string[6]
		{
			YukiText.eb_goodattack1,
			YukiText.eb_goodattack2,
			"",
			YukiText.eb_1_Grab,
			YukiText.eb_2_Attack,
			YukiText.eb_3_UseDishMagic
		}, new string[3] { "grabbed", "stunattack", "magicked" }));
		levels.Add("grabbed", new EightBitConsoleLevel(new string[5]
		{
			YukiText.eb_grabbed1,
			YukiText.eb_grabbed2,
			YukiText.eb_grabbed3,
			"",
			YukiText.eb_1_Continue
		}, new string[1] { "victory" }));
		levels.Add("stunattack", new EightBitConsoleLevel(new string[7]
		{
			YukiText.eb_stunattack1,
			YukiText.eb_stunattack2,
			YukiText.eb_stunattack3,
			"",
			YukiText.eb_1_Attack,
			YukiText.eb_2_Dodge,
			YukiText.eb_3_UseDishMagic
		}, new string[3] { "attacked", "dodged", "magicked" }));
		levels.Add("baddodged", new EightBitConsoleLevel(new string[6]
		{
			YukiText.eb_baddodged1,
			YukiText.eb_baddodged2,
			"",
			YukiText.eb_1_Attack,
			YukiText.eb_2_Dodge,
			YukiText.eb_3_UseDishMagic
		}, new string[3] { "attacked", "dodged", "magicked" }));
		levels.Add("magicked", new EightBitConsoleLevel(new string[7]
		{
			YukiText.eb_magicked1,
			YukiText.eb_magicked2,
			YukiText.eb_magicked3,
			"",
			YukiText.eb_1_Attack,
			YukiText.eb_2_Dodge,
			YukiText.eb_3_UseDishMagic
		}, new string[3] { "attacked", "dodged", "magicked" }));
		levels.Add("victory", new EightBitConsoleLevel(new string[3]
		{
			YukiText.eb_victory1,
			"",
			YukiText.eb_1_Continue
		}, new string[1] { "end" }));
		levels.Add("end", new EightBitConsoleLevel(new string[1] { "" }, new string[1] { "end" }));
		SetLevel("viking");
	}

	public void SetLevel(string lev)
	{
		curLev = lev;
		eightBitConsole.Reset();
		for (int i = 0; i < levels[curLev].text.Length; i++)
		{
			eightBitConsole.AddLine(levels[curLev].text[i]);
		}
		selOption = 0;
	}

	public void Update()
	{
		eightBitConsole.Update();
		if (eightBitConsole.ready && curLev != "end")
		{
			int num = 0;
			if (Game1.character[num].charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[Game1.character[num].charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				Game1.character[num].charUpdate.charGrab.grabbedByChar = -1;
			}
			Game1.character[num].charKeys.Update(Game1.character[num].ai, Game1.character, Game1.character[num]);
			CharKeys charKeys = Game1.character[num].charKeys;
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			if (!pkeyUp && charKeys.keyUp)
			{
				flag = true;
			}
			if (!pkeyDown && charKeys.keyDown)
			{
				flag2 = true;
			}
			if (!pkeyA && charKeys.keyJump)
			{
				flag3 = true;
			}
			if (flag)
			{
				selOption = (selOption + (levels[curLev].options.Length - 1)) % levels[curLev].options.Length;
			}
			if (flag2)
			{
				selOption = (selOption + 1) % levels[curLev].options.Length;
			}
			if (flag3)
			{
				SetLevel(levels[curLev].options[selOption]);
			}
			pkeyUp = charKeys.keyUp;
			pkeyDown = charKeys.keyDown;
			pkeyA = charKeys.keyJump;
		}
	}

	public void Draw(SpriteBatch sprite, Texture2D eightBitTex)
	{
		if (!(curLev == "end"))
		{
			eightBitConsole.Draw(sprite, eightBitTex, selOption + levels[curLev].lines);
		}
	}
}
