namespace Yuki_Win.chars.charMeta;

internal class CharMetaCommand
{
	public string name;

	public CharMetaCommand(string name)
	{
		this.name = name;
	}
}
