namespace Yuki_Win.chars.charMeta;

internal class CharMetaCommands
{
	public enum Command
	{
		mhp,
		speed,
		jump,
		idle_anim,
		run_anim,
		jump_anim,
		runstart_anim,
		runend_anim,
		fly_anim,
		name,
		idlet_anim,
		land_anim,
		fatk_anim,
		hit_anim,
		grab_anim,
		attack_anim,
		strong_anim,
		secondary_anim,
		strong_kill_anim,
		wall_anim,
		wall_jump_anim,
		wall_run_anim,
		flip_anim,
		wall_flip_anim,
		wall_slide_anim,
		wall_slam_anim,
		fstrong_anim,
		special,
		jgrab_anim,
		head_tex,
		torso_tex,
		legs_tex,
		weap_tex,
		dying_anim,
		strong_kill2_anim,
		block_anim,
		isrobot,
		iszombie,
		isboss,
		isblocker,
		isheavy,
		isgiant,
		katgrabbed_anim,
		kamgrabbed_anim,
		iscyborg,
		exer_anim,
		isNeko,
		walk_anim,
		jog_anim,
		ceilrun_anim,
		ceildrop_anim,
		wallatk_anim,
		ceilatk_anim,
		turn_anim,
		alwaysright,
		ischair,
		isyuki,
		isdish,
		spawn_anim,
		jkatgrabbed_anim,
		jkamgrabbed_anim,
		autogroundsplode,
		switch_anim,
		fswitch_anim,
		groundsplode_anim,
		damage,
		roll_anim,
		dishgrabbed_anim,
		dishbladegrabbed_anim,
		dishkamagrabbed_anim,
		dishsawgrabbed_anim,
		dishhammergrabbed_anim,
		dishhold2grabbed_anim,
		painsnd,
		diesnd,
		jabsnd,
		fiercesnd,
		laughsnd,
		growlsnd,
		screamsnd,
		dishwalled_anim,
		yukiwalled_anim,
		wall_land_anim,
		isCrow,
		isjuggernaut,
		isRoller,
		ismara,
		ishargreaves,
		isloic,
		isjuicyrobot,
		hitland_anim,
		vampslammed_anim,
		dishslammed_anim,
		ispumpkin,
		widthbuffer,
		ismetallegs,
		isnolegs,
		mapwidthbuffer,
		inactive_anim,
		isinnerrect,
		isbreaker,
		isbox,
		isforce,
		toast1,
		toast2,
		isglowyblue,
		fakeceiling,
		faketop,
		introyadd,
		exe_anim,
		isstopbeforeattack,
		issmallblood,
		turnexetograb,
		isghost,
		isdragon,
		mapheightbuffer,
		isflyinglanding,
		lock_anim,
		lockdie_anim,
		isinvalid,
		isshop,
		fturn_anim,
		activate_anim,
		ispuppet,
		ispuppeteer,
		heightminus,
		burnentry,
		istvcrazy,
		iskatana,
		iskama,
		iscloud,
		issyringe,
		iscleavers,
		ishammer,
		istoaster,
		isscissors,
		ismagicsponge,
		altrunstart_anim,
		altturn_anim,
		inactivefacecenter,
		nogroundzombie,
		isfists,
		nomusic,
		nobossmusic,
		isfriendly,
		isknife,
		isunaware,
		redeyes,
		greeneyes,
		blueeyes,
		ishypno,
		issawer,
		ishatless,
		isGuitar,
		isViolin,
		isThermop,
		suicide_anim,
		speeder,
		bigspeeder,
		nogold,
		altdefault,
		isquickgrabbable,
		warpcleavers,
		warpscissors,
		warphammer
	}

	public static CharMetaCommand[] command;

	public static void Init()
	{
		command = new CharMetaCommand[192];
		command[0] = new CharMetaCommand("mhp");
		command[1] = new CharMetaCommand("speed");
		command[2] = new CharMetaCommand("jumpval");
		command[3] = new CharMetaCommand("idle_anim");
		command[4] = new CharMetaCommand("run_anim");
		command[5] = new CharMetaCommand("jump_anim");
		command[6] = new CharMetaCommand("runstart_anim");
		command[7] = new CharMetaCommand("runend_anim");
		command[8] = new CharMetaCommand("fly_anim");
		command[9] = new CharMetaCommand("name");
		command[10] = new CharMetaCommand("idlet_anim");
		command[11] = new CharMetaCommand("land_anim");
		command[117] = new CharMetaCommand("lock_anim");
		command[118] = new CharMetaCommand("lockdie_anim");
		command[12] = new CharMetaCommand("fatk_anim");
		command[13] = new CharMetaCommand("hit_anim");
		command[14] = new CharMetaCommand("grab_anim");
		command[15] = new CharMetaCommand("attack_anim");
		command[16] = new CharMetaCommand("strong_anim");
		command[17] = new CharMetaCommand("secondary_anim");
		command[18] = new CharMetaCommand("strong_kill_anim");
		command[19] = new CharMetaCommand("wall_anim");
		command[20] = new CharMetaCommand("wall_jump_anim");
		command[21] = new CharMetaCommand("wall_run_anim");
		command[22] = new CharMetaCommand("flip_anim");
		command[23] = new CharMetaCommand("wall_flip_anim");
		command[24] = new CharMetaCommand("wall_slide_anim");
		command[25] = new CharMetaCommand("wall_slam_anim");
		command[26] = new CharMetaCommand("fstrong_anim");
		command[27] = new CharMetaCommand("special");
		command[28] = new CharMetaCommand("jgrab_anim");
		command[29] = new CharMetaCommand("head_tex");
		command[30] = new CharMetaCommand("torso_tex");
		command[31] = new CharMetaCommand("legs_tex");
		command[32] = new CharMetaCommand("weap_tex");
		command[33] = new CharMetaCommand("dying_anim");
		command[34] = new CharMetaCommand("strong_kill2_anim");
		command[35] = new CharMetaCommand("block_anim");
		command[36] = new CharMetaCommand("isrobot");
		command[37] = new CharMetaCommand("iszombie");
		command[38] = new CharMetaCommand("isboss");
		command[39] = new CharMetaCommand("isblocker");
		command[40] = new CharMetaCommand("isheavy");
		command[41] = new CharMetaCommand("isgiant");
		command[42] = new CharMetaCommand("katgrabbed_anim");
		command[43] = new CharMetaCommand("kamgrabbed_anim");
		command[59] = new CharMetaCommand("jkatgrabbed_anim");
		command[60] = new CharMetaCommand("jkamgrabbed_anim");
		command[44] = new CharMetaCommand("iscyborg");
		command[45] = new CharMetaCommand("exer_anim");
		command[46] = new CharMetaCommand("isneko");
		command[47] = new CharMetaCommand("walk_anim");
		command[48] = new CharMetaCommand("jog_anim");
		command[49] = new CharMetaCommand("ceilrun_anim");
		command[50] = new CharMetaCommand("ceildrop_anim");
		command[51] = new CharMetaCommand("wallatk_anim");
		command[52] = new CharMetaCommand("ceilatk_anim");
		command[53] = new CharMetaCommand("turn_anim");
		command[109] = new CharMetaCommand("exe_anim");
		command[54] = new CharMetaCommand("alwaysright");
		command[55] = new CharMetaCommand("ischair");
		command[56] = new CharMetaCommand("isyuki");
		command[57] = new CharMetaCommand("isdish");
		command[58] = new CharMetaCommand("spawn_anim");
		command[61] = new CharMetaCommand("autogroundsplode");
		command[62] = new CharMetaCommand("switch_anim");
		command[63] = new CharMetaCommand("fswitch_anim");
		command[64] = new CharMetaCommand("groundsplode_anim");
		command[65] = new CharMetaCommand("damage");
		command[66] = new CharMetaCommand("roll_anim");
		command[67] = new CharMetaCommand("dishgrabbed_anim");
		command[68] = new CharMetaCommand("dishbladegrabbed_anim");
		command[69] = new CharMetaCommand("dishkamagrabbed_anim");
		command[70] = new CharMetaCommand("dishsawgrabbed_anim");
		command[71] = new CharMetaCommand("dishhammergrabbed_anim");
		command[72] = new CharMetaCommand("dishhold2grabbed_anim");
		command[73] = new CharMetaCommand("painsnd");
		command[74] = new CharMetaCommand("diesnd");
		command[75] = new CharMetaCommand("jabsnd");
		command[76] = new CharMetaCommand("fiercesnd");
		command[77] = new CharMetaCommand("laughsnd");
		command[78] = new CharMetaCommand("growlsnd");
		command[79] = new CharMetaCommand("screamsnd");
		command[80] = new CharMetaCommand("dishwalled_anim");
		command[81] = new CharMetaCommand("yukiwalled_anim");
		command[82] = new CharMetaCommand("wall_land_anim");
		command[83] = new CharMetaCommand("iscrow");
		command[84] = new CharMetaCommand("isjuggernaut");
		command[85] = new CharMetaCommand("isroller");
		command[86] = new CharMetaCommand("ismara");
		command[87] = new CharMetaCommand("ishargreaves");
		command[88] = new CharMetaCommand("isloic");
		command[89] = new CharMetaCommand("isjuicyrobot");
		command[90] = new CharMetaCommand("hitland_anim");
		command[91] = new CharMetaCommand("vampslammed_anim");
		command[92] = new CharMetaCommand("dishslammed_anim");
		command[93] = new CharMetaCommand("ispumpkin");
		command[94] = new CharMetaCommand("widthbuffer");
		command[95] = new CharMetaCommand("ismetallegs");
		command[96] = new CharMetaCommand("isnolegs");
		command[97] = new CharMetaCommand("mapwidthbuffer");
		command[115] = new CharMetaCommand("mapheightbuffer");
		command[98] = new CharMetaCommand("inactive_anim");
		command[99] = new CharMetaCommand("isinnerrect");
		command[100] = new CharMetaCommand("isbreaker");
		command[101] = new CharMetaCommand("isbox");
		command[102] = new CharMetaCommand("isforce");
		command[103] = new CharMetaCommand("toast1");
		command[104] = new CharMetaCommand("toast2");
		command[105] = new CharMetaCommand("isglowyblue");
		command[106] = new CharMetaCommand("fakeceiling");
		command[107] = new CharMetaCommand("faketop");
		command[108] = new CharMetaCommand("introyadd");
		command[110] = new CharMetaCommand("isstopbeforeattack");
		command[111] = new CharMetaCommand("issmallblood");
		command[112] = new CharMetaCommand("turnexetograb");
		command[113] = new CharMetaCommand("isghost");
		command[114] = new CharMetaCommand("isdragon");
		command[116] = new CharMetaCommand("isflyinglanding");
		command[119] = new CharMetaCommand("isinvalid");
		command[120] = new CharMetaCommand("isshop");
		command[121] = new CharMetaCommand("fturn_anim");
		command[122] = new CharMetaCommand("activate_anim");
		command[123] = new CharMetaCommand("ispuppet");
		command[124] = new CharMetaCommand("ispuppeer");
		command[125] = new CharMetaCommand("heightminus");
		command[126] = new CharMetaCommand("burnentry");
		command[127] = new CharMetaCommand("istvcrazy");
		command[127] = new CharMetaCommand("istvcrazy");
		command[128] = new CharMetaCommand("iskatana");
		command[129] = new CharMetaCommand("iskama");
		command[130] = new CharMetaCommand("iscloud");
		command[131] = new CharMetaCommand("issyringe");
		command[132] = new CharMetaCommand("iscleavers");
		command[133] = new CharMetaCommand("ishammer");
		command[135] = new CharMetaCommand("isscissors");
		command[134] = new CharMetaCommand("istoaster");
		command[136] = new CharMetaCommand("ismagicsponge");
		command[137] = new CharMetaCommand("altrunstart_anim");
		command[138] = new CharMetaCommand("altturn_anim");
		command[139] = new CharMetaCommand("inactivefacecenter");
		command[140] = new CharMetaCommand("nogroundzombie");
		command[141] = new CharMetaCommand("isfists");
		command[142] = new CharMetaCommand("nomusic");
		command[143] = new CharMetaCommand("nobossmusic");
		command[144] = new CharMetaCommand("isfriendly");
		command[145] = new CharMetaCommand("isknife");
		command[146] = new CharMetaCommand("isunaware");
		command[161] = new CharMetaCommand("isquickgrabbable");
		command[147] = new CharMetaCommand("redeyes");
		command[149] = new CharMetaCommand("blueeyes");
		command[148] = new CharMetaCommand("greeneyes");
		command[150] = new CharMetaCommand("ishypno");
		command[151] = new CharMetaCommand("issawer");
		command[152] = new CharMetaCommand("ishatless");
		command[153] = new CharMetaCommand("isguitar");
		command[154] = new CharMetaCommand("isviolin");
		command[155] = new CharMetaCommand("isthermop");
		command[156] = new CharMetaCommand("suicide_anim");
		command[157] = new CharMetaCommand("speder");
		command[158] = new CharMetaCommand("bigspeder");
		command[159] = new CharMetaCommand("nogold");
		command[160] = new CharMetaCommand("altdefault");
		command[162] = new CharMetaCommand("warpcleavers");
		command[163] = new CharMetaCommand("warpscissors");
		command[164] = new CharMetaCommand("warphammer");
	}
}
