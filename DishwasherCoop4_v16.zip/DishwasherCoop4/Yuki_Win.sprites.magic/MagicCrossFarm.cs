using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.chars;

namespace Yuki_Win.sprites.magic;

public class MagicCrossFarm : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.frame = 1f;
		p.alpha = true;
		p.traj = traj;
		p.size = size;
		p.owner = owner;
		if (Game1.character[p.owner].GetMeta().isDish)
		{
			p.wallFree = true;
		}
		else
		{
			p.wallFree = false;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		base.Update(p, spriteMan);
		p.loc = Game1.character[p.owner].charUpdate.loc + new Vector2(0f, -90f);
		Game1.character[p.owner].charUpdate.etherealFrame = 1f;
		if ((int)(frame * 5f) != (int)(p.frame * 5f))
		{
			spriteMan.AddSprite(60, p.loc + new Vector2(0f, -50f), default, 0.4f + (3f - p.frame) * 0.1f, 0, p.owner);
			for (int i = 0; i < 3; i++)
			{
				spriteMan.AddSprite(60, p.loc + new Vector2(0f, -50f) + Rand.GetRandomVec2(-800f, 800f, -100f, 100f), new Vector2(0f, -100f), 0.05f, 0, p.owner);
			}
		}
		if ((int)(frame * 8f) == (int)(p.frame * 8f))
		{
			return;
		}
		int randomInt = Rand.GetRandomInt(0, Game1.character.Length);
		for (int j = 0; j < Game1.character.Length; j++)
		{
			int num = (randomInt + j) % Game1.character.Length;
			if (Game1.character[num].exists && Game1.character[num].team == Character.Team.BadGuys && Game1.character[num].charUpdate.hp > 0f && !Game1.character[num].charUpdate.ethereal && !Game1.character[num].charUpdate.inactive && Game1.character[num].charUpdate.etherealFrame <= 0f)
			{
				spriteMan.AddSprite(64, Game1.character[num].charUpdate.loc + Rand.GetRandomVec2(-20f, 20f, -90f, -10f), Rand.GetRandomVec2(-10f, 10f, -100f, -90f), Rand.GetRandomFloat(0.1f, 0.2f), 0, p.owner);
				spriteMan.AddSprite(12, Game1.character[num].charUpdate.loc + Rand.GetRandomVec2(-20f, 20f, -90f, -10f), Rand.GetRandomVec2(-1f, 1f, -1f, 1f), 0f, 8, p.owner);
				break;
			}
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
	}
}
