using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.player;

namespace Yuki_Win.sprites.magic;

public class MagicSlashFarm : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.owner = owner;
		p.frame = 1f;
		if (Game1.character[p.owner].GetMeta().isDish)
		{
			p.wallFree = true;
		}
		else
		{
			p.wallFree = false;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.frame > 0.5f)
		{
			float frame = p.frame;
			base.Update(p, spriteMan);
			for (int i = 0; i < Game1.character.Length; i++)
			{
				if (!Game1.character[i].exists || Game1.character[i].team == Game1.character[p.owner].team || Game1.character[i].charUpdate.ethereal || !(Game1.character[i].charUpdate.etherealFrame <= 0f) || Game1.character[i].charUpdate.inactive || !(Game1.character[i].charUpdate.hp >= 0f))
				{
					continue;
				}
				Vector2 loc = Game1.character[i].charUpdate.loc;
				if (loc.X > p.loc.X - 90f && loc.X < p.loc.X + 90f && loc.Y < p.loc.Y + 200f && loc.Y > p.loc.Y - 200f)
				{
					float num = (Game1.character[i].GetMeta().isMagicSponge ? 10f : 500f);
					if (p.owner < 2 && Game1.beadMgr.beads[p.owner].HasBead(InvCatalog.InvItemName.SpiderBead))
					{
						num += 100f;
					}
					Game1.character[i].charUpdate.hp -= num * FMan.frameTime;
				}
			}
			if ((int)(frame * 30f) != (int)(p.frame * 30f) && Rand.CointToss(0.5f))
			{
				if (Rand.CointToss(0.3f))
				{
					Sound.PlaySnd(Sound.Category.FX, "sword1");
				}
				else if (Rand.CointToss(0.5f))
				{
					Sound.PlaySnd(Sound.Category.FX, "sword2");
				}
				else
				{
					Sound.PlaySnd(Sound.Category.FX, "sword3");
				}
			}
			if ((int)(frame * 60f) != (int)(p.frame * 60f))
			{
				spriteMan.AddSprite(62, p.loc, default, 0f, 0, p.owner);
				if (Rand.CointToss(0.2f))
				{
					spriteMan.AddSprite(58, p.loc, Rand.GetRandomVec2(-10f, 20f, -50f, 0f), Rand.GetRandomFloat(1f, 2f), 0, p.owner);
				}
				spriteMan.AddSprite(12, p.loc, p.traj, 0f, 7, p.owner);
			}
		}
		else
		{
			p.traj = default;
			base.Update(p, spriteMan);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
	}
}
