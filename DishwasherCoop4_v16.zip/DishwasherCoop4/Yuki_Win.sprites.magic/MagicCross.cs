using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.magic;

public class MagicCross : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.frame = 1f;
		p.alpha = true;
		p.traj = traj;
		p.size = size;
		p.owner = owner;
		if (Game1.character[p.owner].GetMeta().isDish)
		{
			p.wallFree = true;
		}
		else
		{
			p.wallFree = false;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.size > 0.4f)
		{
			p.loc = Game1.character[p.owner].charUpdate.loc + new Vector2(0f, -50f);
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(416, 832, 464, 128);
		float num = 1f;
		num = ((!(p.frame > 0.9f)) ? (num * (p.frame / 0.9f)) : ((1f - p.frame) * 10f));
		for (int i = 0; i < 2; i++)
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, p.wallFree ? new Color(0f, 1f, 0.2f, num) : new Color(1f, 0f, 0.2f, num), (float)i * 1.57f, new Vector2(224f, 64f), new Vector2(0.7f + (float)i * 0.4f, 1f) * ScrollManager.cannedDepth[0] * p.size * (1f + (1f - p.frame)), SpriteEffects.None, 1f);
		}
	}
}
