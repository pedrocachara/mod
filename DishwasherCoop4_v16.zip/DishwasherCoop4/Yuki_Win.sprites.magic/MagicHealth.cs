using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.magic;

public class MagicHealth : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.frame = 3f;
		p.alpha = true;
		p.traj = default;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.owner = owner;
		if (Game1.character[p.owner].GetMeta().isDish)
		{
			p.wallFree = true;
		}
		else
		{
			p.wallFree = false;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float num = p.frame - FMan.frameTime;
		if ((int)(num * 60f) != (int)(p.frame * 60f))
		{
			spriteMan.AddSprite(65, p.loc, Rand.GetRandomVec2(-10f, 10f, -50f, 10f), 0.4f, 0, p.owner);
		}
		int owner = p.owner;
		float num2;
		for (num2 = 3.14f + Trig.GetAngle(p.loc, Game1.character[owner].charUpdate.loc - new Vector2(0f, 50f)); num2 > 6.28f; num2 -= 6.28f)
		{
		}
		float num3;
		for (num3 = num2 - p.rotation; num3 > 6.28f; num3 -= 6.28f)
		{
		}
		for (; num3 < 0f; num3 += 6.28f)
		{
		}
		if (num3 > 3.14f)
		{
			p.rotation -= FMan.frameTime * 4f;
		}
		else
		{
			p.rotation += FMan.frameTime * 4f;
		}
		while (p.rotation > 6.28f)
		{
			p.rotation -= 6.28f;
		}
		while (p.rotation < 0f)
		{
			p.rotation += 6.28f;
		}
		p.traj = new Vector2((float)Math.Cos(p.rotation), (float)Math.Sin(p.rotation)) * 400f;
		if ((p.loc - (Game1.character[owner].charUpdate.loc + new Vector2(0f, -50f))).LengthSquared() < 3000f)
		{
			p.frame = -1f;
			Game1.character[owner].charUpdate.hp += 5f;
			if (Game1.character[owner].charUpdate.hp > Game1.character[owner].charUpdate.mhp)
			{
				Game1.character[owner].charUpdate.hp = Game1.character[owner].charUpdate.mhp;
			}
			for (int i = 0; i < 3; i++)
			{
				spriteMan.AddSprite(65, Game1.character[owner].charUpdate.loc + Rand.GetRandomVec2(-50f, 50f, -100f, 0f), Rand.GetRandomVec2(-100f, 100f, -100f, -90f), Rand.GetRandomFloat(0.4f, 0.5f), 0, p.owner);
			}
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(512, 64, 128, 128), p.wallFree ? new Color(0f, 1f, 0.2f, 1f) : new Color(1f, 0f, 0.2f, 1f), p.frame * 20f, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * 0.2f, SpriteEffects.None, 1f);
	}
}
