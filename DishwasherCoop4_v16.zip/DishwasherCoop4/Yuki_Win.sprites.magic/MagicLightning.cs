using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.magic;

public class MagicLightning : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.alpha = true;
		p.loc = loc;
		p.traj = traj;
		p.rDir = Trig.GetDist(default, traj);
		p.frame = 0.5f;
		p.r = Rand.GetRandomFloat(-1f, 1f);
		p.g = Rand.GetRandomFloat(-1f, 1f);
		p.owner = owner;
		if (Game1.character[p.owner].GetMeta().isDish)
		{
			p.wallFree = true;
		}
		else
		{
			p.wallFree = false;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.frameTime;
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 vector = p.loc + p.traj;
		int num = (int)(p.rDir / 30f);
		Vector2 vector2 = new Vector2(p.r, p.g) * num * 80f;
		for (int i = 0; i < 2; i++)
		{
			Vector2 vector3 = ScrollManager.GetScreenLoc(p.loc, 1f);
			for (int j = 1; j < num + 1; j++)
			{
				Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc + (vector - p.loc) * j / num, 1f);
				screenLoc += (float)Math.Sin((float)j / (float)num * 3.14f) * vector2;
				float num2 = 30f;
				if (i == 1)
				{
					num2 = 15f;
				}
				if (j != num)
				{
					screenLoc += Rand.GetRandomVec2(0f - num2, num2, 0f - num2, num2) * ScrollManager.cannedDepth[0];
				}
				sprite.Draw(spritesTex, vector3, new Rectangle(Rand.GetRandomInt(0, 4) * 128 + 16 + 512, 960, 96, 64), p.wallFree ? new Color(0.2f, 1f, (i == 1) ? 0.8f : 0.2f, p.frame) : new Color(1f, 0.2f, (i == 1) ? 0.8f : 0.2f, p.frame), Trig.GetAngle(screenLoc, vector3), new Vector2(0f, 32f), new Vector2(Trig.GetDist(screenLoc, vector3) / 96f, ScrollManager.cannedDepth[0] * ((i == 0) ? 0.2f : 0.4f)), SpriteEffects.None, 1f);
				vector3 = screenLoc;
				if (Rand.CointToss(0.05f))
				{
					PostGlowMgr.AddGlow(vector3, p.wallFree ? 0.1f : 1f, p.wallFree ? 1f : 0.1f, 0.1f, 1f, 1f, 1f);
				}
			}
		}
	}
}
