using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.magic;

public class MagicHealthGlow : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.frame = Rand.GetRandomFloat(0.2f, 0.3f);
		p.traj = traj;
		p.size = size;
		p.loc = loc;
		p.flags = Rand.GetRandomInt(0, 5);
		p.b = Rand.GetRandomFloat(0f, 1f);
		p.alpha = true;
		p.owner = owner;
		p.rDir = Rand.GetRandomFloat(-11f, 11f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		if (Game1.character[p.owner].GetMeta().isDish)
		{
			p.wallFree = true;
		}
		else
		{
			p.wallFree = false;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = 1f;
		if (p.frame < 0.2f)
		{
			num = p.frame * 5f;
		}
		else
		{
			num = ((!(p.frame < 0.8f)) ? ((1f - p.frame) * 5f) : 1f);
		}
		num *= 0.25f;
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(576 + p.flags * 64, 192, 64, 64), p.wallFree ? new Color(0f, 1f, p.b, num) : new Color(1f, 0f, p.b, num), p.rotation, new Vector2(32f, 32f), p.size * ScrollManager.cannedDepth[0] * new Vector2(2f, 1f), SpriteEffects.None, 1f);
		base.Draw(p, sprite, spritesTex);
	}
}
