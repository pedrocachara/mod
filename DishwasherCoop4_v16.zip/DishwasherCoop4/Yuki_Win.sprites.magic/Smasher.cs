using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.chars;
using Yuki_Win.director;

namespace Yuki_Win.sprites.magic;

public class Smasher : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.frame = 1f;
		p.owner = owner;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		base.Update(p, spriteMan);
		Game1.killManager.doBits(Rand.GetRandomFloat(0f, 1f));
		QuakeManager.SetQuake(0.5f);
		if ((int)(frame * 30f) != (int)(p.frame * 30f))
		{
			Vector2 realLoc = ScrollManager.GetRealLoc(new Vector2(0f, ScrollManager.screenSize.Y / 2f), 1f);
			Vector2 realLoc2 = ScrollManager.GetRealLoc(ScrollManager.screenSize, 1f);
			for (int i = 0; i < 2; i++)
			{
				spriteMan.AddSprite(58, Rand.GetRandomVec2(realLoc.X, realLoc2.X, realLoc.Y, realLoc2.Y), Rand.GetRandomVec2(-5f, 5f, -350f, -130f), Rand.GetRandomFloat(0.15f, 3f), 0, p.owner);
			}
		}
		Game1.character[p.owner].charUpdate.etherealFrame = 1f;
		if (!(p.frame > 0.5f) || (int)(frame * 25f) == (int)(p.frame * 25f) || !Rand.CointToss(0.95f))
		{
			return;
		}
		for (int j = 0; j < Game1.character.Length; j++)
		{
			if (Game1.character[j].exists && Game1.character[j].team == Character.Team.BadGuys && Game1.character[j].charUpdate.slammedFrame <= 0f && !Game1.character[j].GetMeta().isBoss && !Game1.character[j].charUpdate.ethereal && !Game1.character[j].charUpdate.inactive && Game1.character[j].charUpdate.etherealFrame <= 0f && Game1.character[j].charAnim.CheckAnim(Game1.character[j].GetMeta().groundsplode_anim) > -1 && Rand.CointToss(0.5f))
			{
				Game1.character[j].charUpdate.slammedFrame = Rand.GetRandomFloat(9f, 10f);
				Game1.character[j].charUpdate.lastHitBy = p.owner;
				Game1.killManager.DoKill(-1);
				break;
			}
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
	}
}
