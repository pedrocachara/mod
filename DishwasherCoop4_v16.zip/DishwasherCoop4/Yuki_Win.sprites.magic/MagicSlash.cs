using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.magic;

public class MagicSlash : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.traj = new Vector2((float)Math.Cos(p.rotation), (float)Math.Sin(p.rotation)) * 5500f;
		p.loc -= p.traj * 0.05f;
		p.owner = owner;
		p.frame = 0.1f;
		p.alpha = true;
		if (Game1.character[p.owner].GetMeta().isDish)
		{
			p.wallFree = true;
		}
		else
		{
			p.wallFree = false;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(448, 0, 256, 32), p.wallFree ? new Color(0.2f, 1f, p.r, p.frame * 10f) : new Color(1f, 0.2f, p.r, p.frame * 10f), p.rotation, new Vector2(128f, 16f), ScrollManager.cannedDepth[0] * (0.15f - p.frame) * 5f, SpriteEffects.None, 1f);
		if (p.frame < 0.06f && p.frame > 0.04f)
		{
			PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), p.wallFree ? 0.1f : 1f, p.wallFree ? 1f : 0.1f, 0.2f, 1f, 1f, 1f);
		}
		base.Draw(p, sprite, spritesTex);
	}
}
