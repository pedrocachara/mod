using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;

namespace Yuki_Win.sprites.items;

public class Heart : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 5f;
		p.owner = owner;
		p.alpha = true;
		if (traj.X == 0f && traj.Y == 0f)
		{
			traj.X = 0.1f;
		}
		p.rotation = 3.14f + Trig.GetAngle(default, traj);
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		if (p.size < 1f)
		{
			p.size += FMan.frameTime;
		}
		int owner = p.owner;
		float num;
		for (num = 3.14f + Trig.GetAngle(p.loc, Game1.character[owner].charUpdate.loc - new Vector2(0f, 50f)); num > 6.28f; num -= 6.28f)
		{
		}
		float num2;
		for (num2 = num - p.rotation; num2 > 6.28f; num2 -= 6.28f)
		{
		}
		for (; num2 < 0f; num2 += 6.28f)
		{
		}
		if (num2 > 3.14f)
		{
			p.rotation -= FMan.frameTime * 4f;
		}
		else
		{
			p.rotation += FMan.frameTime * 4f;
		}
		while (p.rotation > 6.28f)
		{
			p.rotation -= 6.28f;
		}
		while (p.rotation < 0f)
		{
			p.rotation += 6.28f;
		}
		p.traj = new Vector2((float)Math.Cos(p.rotation), (float)Math.Sin(p.rotation)) * 220f;
		if (p.size > 0.9f && p.frame < 4.5f && (p.loc - (Game1.character[owner].charUpdate.loc + new Vector2(0f, -50f))).LengthSquared() < 3000f)
		{
			p.frame = -1f;
			Game1.character[owner].charUpdate.hp += 5f;
			if (Game1.character[owner].charUpdate.hp > Game1.character[owner].charUpdate.mhp)
			{
				Game1.character[owner].charUpdate.hp = Game1.character[owner].charUpdate.mhp;
			}
			Sound.PlaySnd(Sound.Category.FX, "pickup");
			for (int i = 0; i < 4; i++)
			{
				spriteMan.AddSprite(72, p.loc, Rand.GetRandomVec2(-40f, 40f, -40f, 40f), 1f, 0, 0);
			}
		}
		base.Update(p, spriteMan);
		if ((int)(frame * 20f) != (int)(p.frame * 20f))
		{
			spriteMan.AddSprite(72, p.loc, Rand.GetRandomVec2(-2f, 2f, -10f, -2f), Rand.GetRandomFloat(0.1f, 0.2f) * p.size, 0, 0);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float alpha = 1f;
		if (p.frame > 4.9f)
		{
			alpha = (5f - p.frame) * 10f;
		}
		else if (p.frame < 0.5f)
		{
			alpha = p.frame * 2f;
		}
		int randomInt = Rand.GetRandomInt(0, 6);
		for (int i = 0; i < 3; i++)
		{
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640 + (randomInt + i) % 6 * 32, 608, 32, 32), new Color(1f, 0.1f, 0.3f, alpha), 0f, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * 0.45f * p.size * ((i == 2) ? 1.7f : 1f), SpriteEffects.None, 1f);
		}
	}
}
