using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.items;

public class HeartTrail : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.alpha = true;
		p.frame = 0.4f;
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		int randomInt = Rand.GetRandomInt(0, 6);
		float alpha = p.frame * 5f;
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640 + randomInt % 6 * 32, 608, 32, 32), new Color(1f, 0.1f, 1f, alpha), 0f, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
	}
}
