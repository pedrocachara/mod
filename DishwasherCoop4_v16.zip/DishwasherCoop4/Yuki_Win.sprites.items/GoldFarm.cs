using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.items;

public class GoldFarm : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.frame = 5f;
		p.traj = default;
		p.size = size;
		p.r = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.frame <= 5f)
		{
			float num = Rand.GetRandomFloat(0.5f, 2f);
			if (p.r >= 10f)
			{
				num *= 1.25f;
			}
			if (p.r >= 20f)
			{
				num *= 1.25f;
			}
			if (p.r >= 50f)
			{
				num *= 1.25f;
			}
			if (num > p.size)
			{
				num = p.size;
			}
			p.frame += Rand.GetRandomFloat(0.01f, 0.1f);
			if (num < 1.5f)
			{
				num = 1.5f;
			}
			spriteMan.AddSprite(67, p.loc, Rand.GetRandomVec2(-300f, 300f, -500f, -100f), num / 5f, 0, 0);
			p.size -= num;
			if (p.size <= 0f)
			{
				p.frame = 0f;
			}
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		base.Draw(p, sprite, spritesTex);
	}
}
