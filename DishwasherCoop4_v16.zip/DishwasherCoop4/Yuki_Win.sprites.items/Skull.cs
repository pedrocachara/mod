using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.items;

public class Skull : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 5f;
		p.owner = owner;
		p.alpha = true;
		if (traj.X == 0f && traj.Y == 0f)
		{
			traj.X = 0.1f;
		}
		p.rotation = 3.14f + Trig.GetAngle(default, traj);
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		int owner = p.owner;
		if (p.size < 1f)
		{
			p.size += FMan.frameTime;
		}
		float num;
		for (num = 3.14f + Trig.GetAngle(p.loc, Game1.character[owner].charUpdate.loc - new Vector2(0f, 50f)); num > 6.28f; num -= 6.28f)
		{
		}
		float num2;
		for (num2 = num - p.rotation; num2 > 6.28f; num2 -= 6.28f)
		{
		}
		for (; num2 < 0f; num2 += 6.28f)
		{
		}
		if (num2 > 3.14f)
		{
			p.rotation -= FMan.frameTime * 4f;
		}
		else
		{
			p.rotation += FMan.frameTime * 4f;
		}
		while (p.rotation > 6.28f)
		{
			p.rotation -= 6.28f;
		}
		while (p.rotation < 0f)
		{
			p.rotation += 6.28f;
		}
		p.traj = new Vector2((float)Math.Cos(p.rotation), (float)Math.Sin(p.rotation)) * 200f;
		if (p.frame < 4.5f && (p.loc - (Game1.character[owner].charUpdate.loc + new Vector2(0f, -50f))).LengthSquared() < 3000f)
		{
			p.frame = -1f;
			Game1.character[owner].charUpdate.hp += 5f;
			if (Game1.character[owner].charUpdate.hp > Game1.character[owner].charUpdate.mhp)
			{
				Game1.character[owner].charUpdate.hp = Game1.character[owner].charUpdate.mhp;
			}
			for (int i = 0; i < 4; i++)
			{
				spriteMan.AddSprite(76, p.loc, Rand.GetRandomVec2(-80f, 80f, -80f, 80f), 1.6f * p.size, 0, 0);
			}
			if (Game1.character[owner].charUpdate.mp < Game1.character[owner].charUpdate.mmp)
			{
				Game1.character[owner].charUpdate.mp++;
			}
		}
		base.Update(p, spriteMan);
		if ((int)(frame * 60f) != (int)(p.frame * 60f) && p.size > 0.1f)
		{
			spriteMan.AddRefractSprite(69, p.loc + Rand.GetRandomVec2(-40f, 40f, -40f, 40f) * p.size, Rand.GetRandomVec2(-2f, 2f, -10f, -2f), Rand.GetRandomFloat(0.4f, 1f) * p.size, 0, 0);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = 1f;
		if (p.frame > 4.9f)
		{
			num = (5f - p.frame) * 10f;
		}
		else if (p.frame < 0.5f)
		{
			num = p.frame * 2f;
		}
		float x = 1f;
		float num2 = 1f;
		if (p.frame > 4.8f)
		{
			num2 += (p.frame - 4.8f) * 30f;
			x = (5f - p.frame) * 5f;
		}
		int randomInt = Rand.GetRandomInt(0, 4);
		for (int i = 0; i < 2; i++)
		{
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(896 + randomInt * 32, 832 + i * 32, 32, 32), (i == 0) ? new Color(1f, 0.5f, 0.2f, num * 0.5f) : new Color(0.5f, 1f, 0.3f, num * 0.5f), 0f, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * 1.2f * new Vector2(x, num2) * p.size, SpriteEffects.None, 1f);
		}
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(896 + randomInt * 32, 864, 32, 32), new Color(1f, 0.5f, 0.5f, 1f), 0f, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * 1.5f * new Vector2(x, num2) * p.size, SpriteEffects.None, 1f);
	}
}
