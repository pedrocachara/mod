using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.gameRender;
using Yuki_Win.player;

namespace Yuki_Win.sprites.items;

internal class Gold : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj + Rand.GetRandomVec2(-40f, 40f, -40f, 40f);
		p.frame = 15f;
		p.flags = Rand.GetRandomInt(0, 4);
		p.size = size;
		p.owner = 1;
		p.b = 0f;
		p.g = Rand.GetRandomFloat(0f, 1f);
		p.alpha = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.traj.Y += FMan.frameTime * 1600f;
		p.frame -= FMan.frameTime;
		Vector2 loc = p.loc;
		if (p.b <= 0f)
		{
			if (!p.wallFree)
			{
				p.loc += p.traj * FMan.frameTime;
				if (!Game1.gameMap.CurMap().TestCol(p.loc))
				{
					p.wallFree = true;
				}
			}
			else
			{
				p.loc.X += p.traj.X * FMan.frameTime;
				if (Game1.gameMap.CurMap().TestCol(p.loc))
				{
					p.loc.X = loc.X;
					p.traj.X *= -0.5f;
					if (p.owner > 0)
					{
						p.owner = -1;
					}
					p.rDir = Rand.GetRandomFloat(-10f, 10f);
				}
				p.loc.Y += p.traj.Y * FMan.frameTime * 2f;
				if (Game1.gameMap.CurMap().TestCol(p.loc))
				{
					p.loc.Y = loc.Y;
					p.traj.X *= 0.2f;
					p.traj.Y *= -0.4f;
					if (p.owner > 0)
					{
						p.owner = -1;
					}
					p.rDir = Rand.GetRandomFloat(-10f, 10f);
				}
			}
			if (!(p.frame < 14.8f))
			{
				return;
			}
			for (int i = 0; i < 2; i++)
			{
				if (!Game1.character[i].exists)
				{
					continue;
				}
				Vector2 vector = Game1.character[i].charUpdate.loc - p.loc;
				if (vector.X < 30f && vector.X > -30f && vector.Y < 100f && vector.Y > -10f)
				{
					p.b = 1f;
					p.frame = 0.5f;
					Sound.PlaySnd(Sound.Category.FX, "pickup");
					spriteMan.AddRefractSprite(74, p.loc, new Vector2(0f, -800f), p.size * Rand.GetRandomFloat(1f, 2f), 0, 0);
					float num = p.size;
					if (Game1.beadMgr.beads[i].HasBead(InvCatalog.InvItemName.MoneyBead))
					{
						num *= 1.1f;
					}
					num *= 2f;
					Game1.gamePlayerMgr.gamePlayer[i].gold += num;
				}
			}
		}
		else
		{
			p.traj.X = 0f;
			p.traj.Y = -500f;
			p.loc += p.traj * FMan.frameTime;
			p.frame -= FMan.frameTime;
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = 1f;
		if (p.frame > 14.9f)
		{
			num = (15f - p.frame) * 10f;
		}
		if (p.frame < 0.5f)
		{
			num = p.frame * 2f;
		}
		if (p.b > 0f)
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640 + p.flags * 32, 576, 32, 32), new Color(1f, 1f, 1f, num), 0f, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * p.size * new Vector2(1f, 1f + 50f * (0.5f - p.frame)), SpriteEffects.None, 1f);
		}
		else
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640 + p.flags * 32, 576, 32, 32), new Color(1f, 1f, 1f, num), p.rotation, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
		}
		float num2 = p.frame + p.g;
		num2 -= (float)(int)num2;
		if (num2 < 0.5f)
		{
			num = ((!(num2 > 0.25f)) ? (num * (1f + num2 * 2f)) : (num * (1f + (0.5f - num2) * 2f)));
		}
		float num3 = 1f;
		if (p.size < 1f)
		{
			num3 = p.size * 0.5f + 0.5f;
		}
		PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), 1f, 1f, 0.1f, num * Rand.GetRandomFloat(1.7f, 1.8f) * num3, num * 0.02f, 0f);
	}
}
