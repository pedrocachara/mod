using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.items;

public class HeartFarm : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = default;
		p.owner = owner;
		p.frame = 5f;
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		_ = p.frame;
		base.Update(p, spriteMan);
		if (p.frame <= 5f)
		{
			p.frame += Rand.GetRandomFloat(0.01f, 0.1f);
			p.size--;
			if (p.size <= 0f)
			{
				p.frame = -1f;
			}
			spriteMan.AddSprite(71, p.loc, Rand.GetRandomVec2(-1f, 1f, -1f, 1f), 0f, 0, p.owner);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
	}
}
