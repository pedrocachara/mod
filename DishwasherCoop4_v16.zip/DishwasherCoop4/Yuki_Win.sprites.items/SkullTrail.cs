using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.items;

public class SkullTrail : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.alpha = true;
		p.frame = 0.25f;
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		int randomInt = Rand.GetRandomInt(0, 4);
		float num = p.frame * 4f;
		float x = p.frame * 4f;
		float y = 1f + (0.25f - p.frame) * 20f;
		for (int i = 0; i < 2; i++)
		{
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(896 + randomInt * 32, 832 + i * 32, 32, 32), (i == 0) ? new Color(1f, 0.1f, 0.2f, num) : new Color(0.1f, 1f, 0.3f, num), 0f, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * p.size * new Vector2(x, y), SpriteEffects.None, 1f);
		}
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(896 + randomInt * 32, 864, 32, 32), new Color(1f, 0.5f, 0.5f, num), 0f, new Vector2(16f, 16f), ScrollManager.cannedDepth[0] * p.size * 1.3f * new Vector2(x, y), SpriteEffects.None, 1f);
		PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), 1f, 1f, 0.5f, 1f, num * 0.1f, 0f);
	}
}
