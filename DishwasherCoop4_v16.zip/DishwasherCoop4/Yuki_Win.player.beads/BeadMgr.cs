using Yuki_Win.maps;

namespace Yuki_Win.player.beads;

public class BeadMgr
{
	public Beads[] beads;

	public BeadMgr()
	{
		beads = new Beads[4];
		for (int i = 0; i < beads.Length; i++)
		{
			beads[i] = new Beads();
		}
	}

	public void UpdateMapTheme()
	{
		Game1.gameMap.beadTheme = GameMap.BeadTheme.None;
		for (int i = 0; i < 4; i++)
		{
			if (Game1.character[i].exists)
			{
				if (beads[i].HasBead(InvCatalog.InvItemName.ContrastBead))
				{
					Game1.gameMap.beadTheme = GameMap.BeadTheme.Contrast;
				}
				if (beads[i].HasBead(InvCatalog.InvItemName.ThreeDeeBead))
				{
					Game1.gameMap.beadTheme = GameMap.BeadTheme.ThreeDee;
				}
			}
		}
	}
}
