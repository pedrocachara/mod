using Yuki_Win.arcade;

namespace Yuki_Win.player.beads;

public class Beads
{
	public InvCatalog.InvItemName[] bead;

	public Beads()
	{
		bead = new InvCatalog.InvItemName[4];
		for (int i = 0; i < bead.Length; i++)
		{
			bead[i] = InvCatalog.InvItemName.None;
		}
	}

	public bool HasBead(InvCatalog.InvItemName bead)
	{
		if (Game1.arcade.arcadeMode != Arcade.ArcadeMode.Off)
		{
			return false;
		}
		for (int i = 0; i < this.bead.Length; i++)
		{
			if (this.bead[i] == bead)
			{
				return true;
			}
		}
		return false;
	}

	public void Copy(Beads src)
	{
		for (int i = 0; i < bead.Length; i++)
		{
			bead[i] = src.bead[i];
		}
	}
}
