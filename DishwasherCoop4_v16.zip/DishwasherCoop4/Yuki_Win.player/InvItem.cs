using System.Text;
using Yuki_Win.player.inventory;

namespace Yuki_Win.player;

public class InvItem
{
	public StringBuilder name;

	public StringBuilder desc;

	public StringBuilder desc2;

	public StringBuilder usedStr;

	public StringBuilder gotStr;

	public Inv.InvTabSection section;

	public string friendlyName;

	public int idx;

	public int value;

	public int pickValue;

	public int max;

	public InvItem(string name, string desc, string desc2, int idx, string friendlyName, int value, int pickValue, int max, Inv.InvTabSection section)
	{
		Init(name, desc, desc2, idx, friendlyName, value, pickValue, max, section);
	}

	public InvItem(string name, string desc, string desc2, int idx, string friendlyName, int value, int pickValue, Inv.InvTabSection section)
	{
		Init(name, desc, desc2, idx, friendlyName, value, pickValue, 0, section);
	}

	public InvItem(string name, string desc, string desc2, int idx, string friendlyName, int value, Inv.InvTabSection section)
	{
		Init(name, desc, desc2, idx, friendlyName, value, 0, 0, section);
	}

	public InvItem(string name, string desc, string desc2, int idx, string friendlyName, Inv.InvTabSection section)
	{
		Init(name, desc, desc2, idx, friendlyName, 0, 0, 0, section);
	}

	public void Init(string name, string desc, string desc2, int idx, string friendlyName, int value, int pickValue, int max, Inv.InvTabSection section)
	{
		this.name = new StringBuilder(name);
		this.desc = new StringBuilder(desc);
		if (desc2 != "")
		{
			this.desc2 = new StringBuilder(desc2);
		}
		usedStr = new StringBuilder(YukiText.used + " " + name);
		gotStr = new StringBuilder(YukiText.got + " " + name);
		this.section = section;
		this.friendlyName = friendlyName;
		this.idx = idx;
		this.value = value;
		this.pickValue = pickValue;
		this.max = max;
	}
}
