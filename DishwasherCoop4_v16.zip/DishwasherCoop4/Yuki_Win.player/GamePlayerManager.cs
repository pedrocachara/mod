using Yuki_Win.arcade;
using Yuki_Win.sprites;

namespace Yuki_Win.player;

public class GamePlayerManager
{
	public GamePlayer[] gamePlayer;

	public GamePlayerManager()
	{
		gamePlayer = new GamePlayer[4];
		for (int i = 0; i < gamePlayer.Length; i++)
		{
			gamePlayer[i] = new GamePlayer(i);
		}
		gamePlayer[0].active = true;
	}

	public GamePlayer GamePlayer(int ID)
	{
		return gamePlayer[ID];
	}

	public void CopyPlayer(int src, int dest)
	{
		gamePlayer[dest].Copy(gamePlayer[src]);
		Game1.beadMgr.beads[dest].Copy(Game1.beadMgr.beads[src]);
		Game1.storageMgr.playerData[dest].CopyData(Game1.storageMgr.playerData[src]);
		Game1.achievementMgr.playerAchievements[dest].Copy(Game1.achievementMgr.playerAchievements[src]);
		Game1.hud.invMgr.inv[dest].Copy(Game1.hud.invMgr.inv[src]);
	}

	public void Update()
	{
		int num = 1;
		switch (Game1.levelMgr.currentTrack)
		{
		case 2:
			num = Game1.coopPlayers;
			break;
		case 3:
			num = Game1.arcade.players;
			break;
		}
		for (int i = 0; i < gamePlayer.Length; i++)
		{
			if (i < num)
			{
				gamePlayer[i].active = true;
			}
			else
			{
				gamePlayer[i].active = false;
			}
			gamePlayer[i].hp = Game1.character[i].charUpdate.hp;
			gamePlayer[i].mhp = Game1.character[i].charUpdate.mhp;
			gamePlayer[i].Update();
		}
	}

	internal int GetUpgrade(int ID, GamePlayer.UpName upName)
	{
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off && ID > -1 && Game1.IsPlayerChar(ID))
		{
			return gamePlayer[ID].upgrades[(int)upName].lev - 2;
		}
		return -1;
	}

	internal float GetUpgradeDamage(Sprite sprite)
	{
		if (Game1.arcade.arcadeMode != Arcade.ArcadeMode.Off)
		{
			return 1f;
		}
		float num = 1f;
		int num2 = 1;
		if (Game1.character[sprite.owner].GetMeta().isYuki)
		{
			int type = sprite.type;
			if (type == 11)
			{
				num2 = gamePlayer[sprite.owner].upgrades[6].lev;
			}
			else if (sprite.type == 12 && (sprite.flags == 9 || sprite.flags == 68 || sprite.flags == 20))
			{
				num2 = gamePlayer[sprite.owner].upgrades[8].lev;
			}
			else
			{
				switch (gamePlayer[sprite.owner].yukiLoadOut[Game1.character[sprite.owner].loadOut].weapon[Game1.character[sprite.owner].weapIdx])
				{
				case InvCatalog.InvItemName.Conviction:
					num2 = gamePlayer[sprite.owner].upgrades[2].lev;
					break;
				case InvCatalog.InvItemName.CloudSword:
					num2 = gamePlayer[sprite.owner].upgrades[4].lev;
					break;
				case InvCatalog.InvItemName.Kamakazi:
					num2 = gamePlayer[sprite.owner].upgrades[3].lev;
					break;
				case InvCatalog.InvItemName.Painkiller:
					num2 = gamePlayer[sprite.owner].upgrades[5].lev;
					break;
				}
			}
		}
		else
		{
			int type2 = sprite.type;
			if (type2 == 11)
			{
				num2 = gamePlayer[sprite.owner].upgrades[14].lev;
			}
			else
			{
				switch (gamePlayer[sprite.owner].dishLoadOut[Game1.character[sprite.owner].loadOut].weapon[Game1.character[sprite.owner].weapIdx])
				{
				case InvCatalog.InvItemName.ShiftBlade:
					num2 = gamePlayer[sprite.owner].upgrades[9].lev;
					break;
				case InvCatalog.InvItemName.MeatCleavers:
					num2 = gamePlayer[sprite.owner].upgrades[10].lev;
					break;
				case InvCatalog.InvItemName.ViolenceHammer:
					num2 = gamePlayer[sprite.owner].upgrades[11].lev;
					break;
				case InvCatalog.InvItemName.TheGuillotine:
					num2 = gamePlayer[sprite.owner].upgrades[12].lev;
					break;
				case InvCatalog.InvItemName.Dekkentozter:
					num2 = gamePlayer[sprite.owner].upgrades[13].lev;
					break;
				}
			}
		}
		return 0.9f + (float)num2 * 0.1f;
	}

	internal void ResetGamertags()
	{
		for (int i = 0; i < gamePlayer.Length; i++)
		{
			gamePlayer[i].gamerTag = null;
		}
	}
}
