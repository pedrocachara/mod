namespace Yuki_Win.player;

public class Loadout
{
	public InvCatalog.InvItemName[] weapon = new InvCatalog.InvItemName[2];
}
