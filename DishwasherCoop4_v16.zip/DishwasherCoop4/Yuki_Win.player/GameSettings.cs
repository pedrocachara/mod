namespace Yuki_Win.player;

public class GameSettings
{
	public const int DIFFICULTY_PRETTYPRINCESS = 0;

	public const int DIFFICULTY_EASY = 1;

	public const int DIFFICULTY_NORMAL = 2;

	public const int DIFFICULTY_NINJA = 3;

	public const int DIFFICULTY_SAMURAI = 4;

	public const int DIFFICULTY_SPEEDRUN = 5;

	public static int difficulty;
}
