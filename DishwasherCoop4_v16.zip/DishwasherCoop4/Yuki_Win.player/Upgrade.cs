namespace Yuki_Win.player;

public class Upgrade
{
	public int lev;

	public int max;

	public Upgrade(int lev, int max)
	{
		this.lev = lev;
		this.max = max;
	}

	public bool AddLev()
	{
		if (lev < max)
		{
			lev++;
			return true;
		}
		return false;
	}
}
