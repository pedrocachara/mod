using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.guidestuff;
using Yuki_Win.levels;

namespace Yuki_Win.player;

public class GamePlayer
{
	public enum UpName
	{
		Health,
		Magic,
		Murderblade,
		Kamakazi,
		Cloud,
		Painkiller,
		Gunarm,
		Gunshotty,
		Chainsaw,
		Shiftblade,
		Cleavers,
		Hammer,
		Guillotine,
		Dekkentozter,
		Uzi,
		Shotty
	}

	public const float MAXTIME = 20f;

	public const float MAXCOMBOTTIME = 3f;

	private const long KILL_SCORE = 1000L;

	public float hp;

	public float mhp;

	public float comboFrame;

	public long comboCount;

	public long comboKills;

	public long comboSlasherKills;

	public long comboSmashKills;

	public long comboCleanKills;

	public long comboBlastKills;

	public long comboRendKills;

	public float slasherKillFrame;

	public float smashKillFrame;

	public float cleanKillFrame;

	public float blastKillFrame;

	public float rendKillFrame;

	public long comboScore;

	public long score;

	public float time;

	public bool active;

	private bool comboPush;

	public float scoreFrame;

	public int totalKills;

	public int maxCombos;

	public float damage;

	public long comboCash;

	public float comboCashFrame;

	public int ID;

	public StringBuilder gamerTag;

	public Dictionary<int, Upgrade> upgrades;

	public float gold;

	public int picks;

	public Loadout[] loadOut = new Loadout[2]
	{
		new Loadout(),
		new Loadout()
	};

	public Loadout[] dishLoadOut = new Loadout[2]
	{
		new Loadout(),
		new Loadout()
	};

	public Loadout[] yukiLoadOut = new Loadout[2]
	{
		new Loadout(),
		new Loadout()
	};

	public uint deathCount;

	public bool prettyPrincessUnlock;

	public int highestYukiPhase;

	public int highestDishPhase;

	public StringBuilder nameStr;

	public void AddDeath(int idx)
	{
		if (Game1.levelMgr.currentTrack == 0 || Game1.levelMgr.currentTrack == 1)
		{
			deathCount++;
			if (deathCount >= 5)
			{
				Game1.achievementMgr.playerAchievements[idx].achievementList[10].Unlock(overRide: false);
				prettyPrincessUnlock = true;
			}
		}
	}

	public void Copy(GamePlayer src)
	{
		foreach (KeyValuePair<int, Upgrade> upgrade in src.upgrades)
		{
			upgrades[upgrade.Key].lev = upgrade.Value.lev;
			upgrades[upgrade.Key].max = upgrade.Value.max;
		}
		gold = src.gold;
		picks = src.picks;
		deathCount = src.deathCount;
		for (int i = 0; i < yukiLoadOut.Length; i++)
		{
			for (int j = 0; j < yukiLoadOut[i].weapon.Length; j++)
			{
				yukiLoadOut[i].weapon[j] = src.yukiLoadOut[i].weapon[j];
			}
		}
		for (int k = 0; k < dishLoadOut.Length; k++)
		{
			for (int l = 0; l < dishLoadOut[k].weapon.Length; l++)
			{
				dishLoadOut[k].weapon[l] = src.dishLoadOut[k].weapon[l];
			}
		}
		highestDishPhase = src.highestDishPhase;
		highestYukiPhase = src.highestYukiPhase;
	}

	public void SetLoadout(int loadout, int slot, InvCatalog.InvItemName weapon, int ID)
	{
		if (Game1.character[ID].GetMeta().isYuki || Game1.character[ID].GetMeta().isMara)
		{
			yukiLoadOut[loadout].weapon[slot] = weapon;
		}
		else
		{
			dishLoadOut[loadout].weapon[slot] = weapon;
		}
		loadOut[loadout].weapon[slot] = weapon;
	}

	public void ResetLoadout()
	{
		for (int i = 0; i < loadOut.Length; i++)
		{
			for (int j = 0; j < loadOut[i].weapon.Length; j++)
			{
				loadOut[i].weapon[j] = InvCatalog.InvItemName.None;
			}
		}
		for (int k = 0; k < dishLoadOut.Length; k++)
		{
			for (int l = 0; l < dishLoadOut[k].weapon.Length; l++)
			{
				dishLoadOut[k].weapon[l] = InvCatalog.InvItemName.None;
			}
		}
		for (int m = 0; m < yukiLoadOut.Length; m++)
		{
			for (int n = 0; n < yukiLoadOut[m].weapon.Length; n++)
			{
				yukiLoadOut[m].weapon[n] = InvCatalog.InvItemName.None;
			}
		}
	}

	public GamePlayer(int ID)
	{
		this.ID = ID;
		upgrades = new Dictionary<int, Upgrade>();
		upgrades.Add(0, new Upgrade(1, 5));
		upgrades.Add(1, new Upgrade(1, 5));
		upgrades.Add(2, new Upgrade(1, 3));
		upgrades.Add(3, new Upgrade(1, 3));
		upgrades.Add(4, new Upgrade(1, 3));
		upgrades.Add(5, new Upgrade(1, 3));
		upgrades.Add(6, new Upgrade(1, 3));
		upgrades.Add(7, new Upgrade(1, 3));
		upgrades.Add(8, new Upgrade(1, 3));
		upgrades.Add(9, new Upgrade(1, 3));
		upgrades.Add(10, new Upgrade(1, 3));
		upgrades.Add(11, new Upgrade(1, 3));
		upgrades.Add(12, new Upgrade(1, 3));
		upgrades.Add(13, new Upgrade(1, 3));
		upgrades.Add(14, new Upgrade(1, 3));
		upgrades.Add(15, new Upgrade(1, 3));
	}

	public void Write(BinaryWriter writer, int ID)
	{
		foreach (KeyValuePair<int, Upgrade> upgrade in upgrades)
		{
			writer.Write(upgrade.Key);
			writer.Write(upgrade.Value.lev);
		}
		writer.Write(gold);
		writer.Write(picks);
		writer.Write(deathCount);
		for (int i = 0; i < yukiLoadOut.Length; i++)
		{
			for (int j = 0; j < yukiLoadOut[i].weapon.Length; j++)
			{
				writer.Write(Game1.invCatalog.catalog[(int)yukiLoadOut[i].weapon[j]].friendlyName);
			}
		}
		for (int k = 0; k < dishLoadOut.Length; k++)
		{
			for (int l = 0; l < dishLoadOut[k].weapon.Length; l++)
			{
				writer.Write(Game1.invCatalog.catalog[(int)dishLoadOut[k].weapon[l]].friendlyName);
			}
		}
		for (int m = 0; m < Game1.beadMgr.beads[ID].bead.Length; m++)
		{
			writer.Write(Game1.invCatalog.catalog[(int)Game1.beadMgr.beads[ID].bead[m]].friendlyName);
		}
		writer.Write(highestYukiPhase);
		writer.Write(highestDishPhase);
	}

	public void Read(BinaryReader reader, int ID)
	{
		for (int i = 0; i < upgrades.Count; i++)
		{
			upgrades[reader.ReadInt32()].lev = reader.ReadInt32();
		}
		gold = reader.ReadSingle();
		picks = reader.ReadInt32();
		deathCount = reader.ReadUInt32();
		if (deathCount >= 5)
		{
			prettyPrincessUnlock = true;
		}
		else
		{
			prettyPrincessUnlock = false;
		}
		for (int j = 0; j < yukiLoadOut.Length; j++)
		{
			for (int k = 0; k < yukiLoadOut[j].weapon.Length; k++)
			{
				yukiLoadOut[j].weapon[k] = Game1.invCatalog.GetNameFromName(reader.ReadString());
			}
		}
		for (int l = 0; l < dishLoadOut.Length; l++)
		{
			for (int m = 0; m < dishLoadOut[l].weapon.Length; m++)
			{
				dishLoadOut[l].weapon[m] = Game1.invCatalog.GetNameFromName(reader.ReadString());
			}
		}
		for (int n = 0; n < Game1.beadMgr.beads[ID].bead.Length; n++)
		{
			Game1.beadMgr.beads[ID].bead[n] = Game1.invCatalog.GetNameFromName(reader.ReadString());
		}
		highestYukiPhase = reader.ReadInt32();
		highestDishPhase = reader.ReadInt32();
	}

	public bool UpgradeLev(UpName name)
	{
		return upgrades[(int)name].AddLev();
	}

	public void DoHit(float hVal)
	{
		DoHit(hVal, grab: false);
	}

	public void DoHit(float hVal, bool grab)
	{
		if (comboFrame <= 0f)
		{
			comboSlasherKills = 0L;
			comboCleanKills = 0L;
			comboBlastKills = 0L;
			comboRendKills = 0L;
			comboSmashKills = 0L;
			comboKills = 0L;
			comboCount = 0L;
			comboScore = 0L;
		}
		if (hVal > 1f || comboCount < 1 || grab)
		{
			comboCount++;
		}
		if (hVal > 0f)
		{
			comboScore += (long)((hVal + 5f) * 20f);
		}
		comboFrame = 3f;
		if (comboCount > maxCombos)
		{
			maxCombos = (int)comboCount;
		}
	}

	public void DoSlasherKill()
	{
		slasherKillFrame = 20f;
		comboSlasherKills++;
		comboFrame = 3f;
		comboScore += 1000L;
	}

	public void DoSmashKill()
	{
		smashKillFrame = 20f;
		comboSmashKills++;
		comboFrame = 3f;
		comboScore += 1000L;
	}

	public void DoCleanKill()
	{
		cleanKillFrame = 20f;
		comboCleanKills++;
		comboFrame = 3f;
		comboScore += 1000L;
	}

	public void DoBlastKill()
	{
		blastKillFrame = 20f;
		comboBlastKills++;
		comboFrame = 3f;
		comboScore += 1000L;
	}

	public void DoRendKill()
	{
		rendKillFrame = 20f;
		comboRendKills++;
		comboFrame = 3f;
		comboScore += 1000L;
	}

	public void DoKill()
	{
		comboKills++;
		comboFrame = 3f;
		totalKills++;
		comboScore += 1000L;
	}

	public void CashInCombo()
	{
		if (comboFrame > 0f)
		{
			EndCombo();
		}
	}

	public void EndCombo()
	{
		comboFrame = 0f;
		float num = 1f;
		float num2 = 5f;
		num += (float)comboCount * 0.2f * num2;
		num += (float)comboKills * num2;
		num += (float)comboSlasherKills * 5f * num2;
		num += (float)comboSmashKills * 5f * num2;
		num += (float)comboCleanKills * 5f * num2;
		num += (float)comboBlastKills * 5f * num2;
		num += (float)comboRendKills * 5f * num2;
		comboCash = (long)((float)comboScore * num);
		if (comboCash <= 0)
		{
			return;
		}
		comboCashFrame = 3f;
		if ((!Game1.netSession.IsHost() || ID != 1) && (!Game1.netSession.IsClient() || ID != 0))
		{
			score += comboCash;
			Sound.PlaySnd(Sound.Category.FX, "chime");
			scoreFrame = 1f;
			if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
			{
				Game1.netSession.netGame.SendScore(Game1.netSession.session, score);
			}
		}
	}

	internal void Update()
	{
		float num = FMan.frameTime;
		if (gamerTag == null)
		{
			if (Game1.netSession.IsHost())
			{
				if (ID == 0)
				{
					gamerTag = GuideStuff.GetSignedInGamerName(0);
				}
				else
				{
					gamerTag = Game1.netSession.GetRemoteGamerName();
				}
			}
			else if (Game1.netSession.IsClient())
			{
				if (ID == 1)
				{
					gamerTag = GuideStuff.GetSignedInGamerName(0);
				}
				else
				{
					gamerTag = Game1.netSession.GetRemoteGamerName();
				}
			}
			else if (ID > -1 && ID < 2)
			{
				SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(ID);
				if (signedInGamerAtIndex != null)
				{
					gamerTag = new StringBuilder(signedInGamerAtIndex.Gamertag);
				}
				else
				{
					gamerTag = new StringBuilder("");
				}
			}
			else
			{
				gamerTag = new StringBuilder("");
			}
		}
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.Slow)
		{
			num *= Game1.arcade.slowVal;
		}
		if (rendKillFrame > 0f)
		{
			rendKillFrame -= num;
		}
		if (slasherKillFrame > 0f)
		{
			slasherKillFrame -= num;
		}
		if (smashKillFrame > 0f)
		{
			smashKillFrame -= num;
		}
		if (cleanKillFrame > 0f)
		{
			cleanKillFrame -= num;
		}
		if (blastKillFrame > 0f)
		{
			blastKillFrame -= num;
		}
		if (comboFrame > 0f)
		{
			comboFrame -= num;
			if (comboPush)
			{
				comboFrame -= num * 4f;
			}
			if (comboFrame <= 0f)
			{
				EndCombo();
			}
		}
		else
		{
			comboPush = false;
		}
		if (comboCashFrame > 0f)
		{
			comboCashFrame -= num;
		}
		if (scoreFrame > 0f)
		{
			scoreFrame -= num;
			if (scoreFrame < 0f)
			{
				scoreFrame = 0f;
			}
		}
	}

	internal void Reset(bool newGame)
	{
		score = 0L;
		scoreFrame = 0f;
		comboFrame = 0f;
		totalKills = 0;
		maxCombos = 0;
		damage = 0f;
		cleanKillFrame = 0f;
		rendKillFrame = 0f;
		blastKillFrame = 0f;
		slasherKillFrame = 0f;
		smashKillFrame = 0f;
	}

	internal void PushCombo()
	{
		comboPush = true;
	}
}
