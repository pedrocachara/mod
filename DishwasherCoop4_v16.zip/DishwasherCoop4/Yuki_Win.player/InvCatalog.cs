using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Yuki_Win.player.inventory;

namespace Yuki_Win.player;

public class InvCatalog
{
	public enum InvItemName
	{
		None,
		Conviction,
		Kamakazi,
		CloudSword,
		Painkiller,
		ShiftBlade,
		MeatCleavers,
		ViolenceHammer,
		TheGuillotine,
		Dekkentozter,
		SquidChips,
		KittenVitamins,
		MoonBread,
		MoonFish,
		ContinueHeart,
		PsychoPick,
		OmodoKey,
		BoardKey,
		GunArm,
		SkullBead,
		CrossBead,
		HeartBead,
		FlowerBead,
		MathBead,
		RobotBead,
		CrownBead,
		PigBead,
		CatBead,
		EyeBead,
		PlateBead,
		WineBead,
		BoneBead,
		SquidBead,
		RocketBead,
		GoatBead,
		BellBead,
		BrainBead,
		BatBead,
		SpiderBead,
		MirrorBead,
		CloudBead,
		MoneyBead,
		GunBead,
		HacksawBead,
		ShieldBead,
		ContrastBead,
		IceBead,
		ThreeDeeBead,
		Vaultkey,
		Towerkey,
		Roofkey,
		Commskey,
		PuckKey,
		AquaKey,
		SummitKey,
		UpgradeConviction,
		UpgradeKamakazi,
		UpgradeCloudSword,
		UpgradePainkiller,
		UpgradeShiftblade,
		UpgradeCleavers,
		UpgradeViolenceHammer,
		UpgradeGuillotine,
		UpgradeDekkentozter,
		UpgradeChainsaw,
		UpgradeGunArm,
		UpgradeUzi,
		UpgradeConviction2,
		UpgradeKamakazi2,
		UpgradeCloudSword2,
		UpgradePainkiller2,
		UpgradeShiftblade2,
		UpgradeCleavers2,
		UpgradeViolenceHammer2,
		UpgradeGuillotine2,
		UpgradeDekkentozter2,
		UpgradeChainsaw2,
		UpgradeGunArm2,
		UpgradeUzi2,
		UpgradeHealth,
		UpgradeSkulls,
		UpgradeHealth2,
		UpgradeSkulls2,
		UpgradeHealth3,
		UpgradeSkulls3,
		UpgradeHealth4,
		UpgradeSkulls4,
		ElectricBloodMagic,
		SteelBloodMagic,
		HolyBloodMagic,
		DevouringBloodMagic,
		ElectricDishMagic,
		SteelDishMagic,
		HolyDishMagic,
		DevouringDishMagic,
		Uzi,
		Shotty,
		ShottyArm,
		Claws,
		Dummy,
		AchievablesBead
	}

	public Dictionary<int, InvItem> catalog;

	public InvItemName GetNameFromName(string name)
	{
		foreach (int key in catalog.Keys)
		{
			if (catalog[key].friendlyName == name)
			{
				return (InvItemName)key;
			}
		}
		return InvItemName.MoonFish;
	}

	public Rectangle GetInvitemRect(InvItemName item)
	{
		return new Rectangle(catalog[(int)item].idx % 8 * 256, catalog[(int)item].idx / 8 * 256, 256, 256);
	}

	public InvCatalog()
	{
		catalog = new Dictionary<int, InvItem>();
		catalog.Add(0, new InvItem("none", "", "", 0, "none", Inv.InvTabSection.Food));
		catalog.Add(1, new InvItem(YukiText.conviction, "", "", 0, "murderblade", Inv.InvTabSection.Progression));
		catalog.Add(2, new InvItem(YukiText.kamakazi, "", "", 3, "kama", Inv.InvTabSection.Progression));
		catalog.Add(3, new InvItem(YukiText.cloudSword, "", "", 6, "cloud", Inv.InvTabSection.Progression));
		catalog.Add(4, new InvItem(YukiText.painkiller, "", "", 7, "painkiller", Inv.InvTabSection.Progression));
		catalog.Add(5, new InvItem(YukiText.shiftBlade, "", "", 0, "shiftblade", Inv.InvTabSection.Progression));
		catalog.Add(6, new InvItem(YukiText.meatCleavers, "", "", 2, "cleavers", Inv.InvTabSection.Progression));
		catalog.Add(7, new InvItem(YukiText.violenceHammer, "", "", 1, "hammer", Inv.InvTabSection.Progression));
		catalog.Add(8, new InvItem(YukiText.theGuillotine, "", "", 4, "scissor", Inv.InvTabSection.Progression));
		catalog.Add(9, new InvItem(YukiText.dekkentozter, "", "", 5, "toaster", Inv.InvTabSection.Progression));
		catalog.Add(18, new InvItem(YukiText.gunArmUpgrade, "", "", 16, "gunarm", Inv.InvTabSection.Progression));
		catalog.Add(95, new InvItem(YukiText.smg, "", "", 74, "uzi", Inv.InvTabSection.Progression));
		catalog.Add(96, new InvItem(YukiText.shotgun, "", "", 75, "shotty", Inv.InvTabSection.Progression));
		catalog.Add(97, new InvItem(YukiText.shottyUpgrade, "", "", 76, "shottyarm", Inv.InvTabSection.Progression));
		catalog.Add(98, new InvItem(YukiText.claws, "", "", 77, "fists", Inv.InvTabSection.Progression));
		catalog.Add(10, new InvItem(YukiText.squidChips, YukiText.squidChipsDesc1, YukiText.squidChipsDesc2, 8, "chips", 100, 0, 5, Inv.InvTabSection.Food));
		catalog.Add(11, new InvItem(YukiText.kittenVitamins, YukiText.kittenVitaminsDesc1, YukiText.kittenVitaminsDesc2, 9, "vitamins", 100, 0, 3, Inv.InvTabSection.Food));
		catalog.Add(12, new InvItem(YukiText.moonBread, YukiText.moonBreadDesc1, "", 10, "bread", 50, 0, 5, Inv.InvTabSection.Food));
		catalog.Add(13, new InvItem(YukiText.moonFish, YukiText.moonFishDesc1, "", 11, "fish", 200, 0, 3, Inv.InvTabSection.Food));
		catalog.Add(14, new InvItem("continue heart", "", "", 12, "continue", 500, 0, 3, Inv.InvTabSection.Food));
		catalog.Add(15, new InvItem("psycho pick", "psycho picks are magic-imbued picks used to", "upgrade your health, skulls and weapons.", 13, "pick", 800, Inv.InvTabSection.Food));
		catalog.Add(16, new InvItem(YukiText.omodoKey, "", "", 14, "omodokey", Inv.InvTabSection.Keys));
		catalog.Add(17, new InvItem(YukiText.boardroomKeycard, "", "", 15, "boardkey", Inv.InvTabSection.Keys));
		catalog.Add(48, new InvItem(YukiText.vaultKey, "", "", 48, "vaultkey", Inv.InvTabSection.Keys));
		catalog.Add(49, new InvItem(YukiText.towerKey, "", "", 49, "towerkey", Inv.InvTabSection.Keys));
		catalog.Add(50, new InvItem(YukiText.roofKey, "", "", 50, "roofkey", Inv.InvTabSection.Keys));
		catalog.Add(51, new InvItem(YukiText.commsKey, "", "", 51, "commskey", Inv.InvTabSection.Keys));
		catalog.Add(52, new InvItem(YukiText.stadiumKey, "", "", 52, "puckkey", Inv.InvTabSection.Keys));
		catalog.Add(53, new InvItem(YukiText.marinaKey, "", "", 53, "aquakey", Inv.InvTabSection.Keys));
		catalog.Add(54, new InvItem(YukiText.summitKey, "", "", 54, "summitkey", Inv.InvTabSection.Keys));
		catalog.Add(19, new InvItem(YukiText.skullBead, YukiText.skullBeadDesc1, YukiText.skullBeadDesc2, 17, "skullbead", Inv.InvTabSection.Beads));
		catalog.Add(20, new InvItem(YukiText.crossBead, YukiText.crossBeadDesc1, YukiText.crossBeadDesc2, 18, "crossbead", Inv.InvTabSection.Beads));
		catalog.Add(21, new InvItem(YukiText.heartBead, YukiText.heartBeadDesc1, YukiText.heartBeadDesc2, 19, "heartbead", Inv.InvTabSection.Beads));
		catalog.Add(22, new InvItem(YukiText.flowerBead, YukiText.flowerBeadDesc1, YukiText.flowerBeadDesc2, 20, "flowerbead", Inv.InvTabSection.Beads));
		catalog.Add(23, new InvItem(YukiText.mathBead, YukiText.mathBeadDesc1, YukiText.mathBeadDesc2, 21, "mathbead", Inv.InvTabSection.Beads));
		catalog.Add(24, new InvItem(YukiText.robotBead, YukiText.robotBeadDesc1, YukiText.robotBeadDesc2, 22, "robotbead", Inv.InvTabSection.Beads));
		catalog.Add(25, new InvItem(YukiText.crownBead, YukiText.crownBeadDesc1, YukiText.crownBeadDesc2, 23, "crownbead", Inv.InvTabSection.Beads));
		catalog.Add(26, new InvItem(YukiText.pigBead, YukiText.pigBeadDesc1, "", 24, "pigbead", Inv.InvTabSection.Beads));
		catalog.Add(27, new InvItem(YukiText.catBead, YukiText.catBeadDesc1, "", 25, "catbead", Inv.InvTabSection.Beads));
		catalog.Add(28, new InvItem(YukiText.eyeBead, YukiText.eyeBeadDesc1, "", 26, "eyebead", Inv.InvTabSection.Beads));
		catalog.Add(29, new InvItem(YukiText.plateBead, YukiText.plateBeadDesc1, YukiText.plateBeadDesc2, 27, "platebead", Inv.InvTabSection.Beads));
		catalog.Add(30, new InvItem(YukiText.wineBead, YukiText.wineBeadDesc1, YukiText.wineBeadDesc2, 28, "winebead", Inv.InvTabSection.Beads));
		catalog.Add(31, new InvItem(YukiText.boneBead, YukiText.boneBeadDesc1, YukiText.boneBeadDesc2, 29, "bonebead", Inv.InvTabSection.Beads));
		catalog.Add(32, new InvItem(YukiText.squidBead, YukiText.squidBeadDesc1, YukiText.squidBeadDesc2, 30, "squidbead", Inv.InvTabSection.Beads));
		catalog.Add(33, new InvItem(YukiText.rocketBead, YukiText.rocketBeadDesc1, YukiText.rocketBeadDesc2, 31, "rocketbead", Inv.InvTabSection.Beads));
		catalog.Add(34, new InvItem(YukiText.goatBead, YukiText.goatBeadDesc1, YukiText.goatBeadDesc2, 32, "goatbead", Inv.InvTabSection.Beads));
		catalog.Add(35, new InvItem(YukiText.bellBead, YukiText.bellBeadDesc1, "", 33, "bellbead", Inv.InvTabSection.Beads));
		catalog.Add(36, new InvItem(YukiText.brainBead, YukiText.brainBeadDesc1, YukiText.brainBeadDesc2, 35, "brainbead", Inv.InvTabSection.Beads));
		catalog.Add(37, new InvItem(YukiText.batBead, YukiText.batBeadDesc1, YukiText.batBeadDesc2, 34, "batbead", Inv.InvTabSection.Beads));
		catalog.Add(38, new InvItem(YukiText.spiderBead, YukiText.spiderBeadDesc1, YukiText.spiderBeadDesc2, 36, "spiderbead", Inv.InvTabSection.Beads));
		catalog.Add(39, new InvItem(YukiText.mirrorBead, YukiText.mirrorBeadDesc1, YukiText.mirrorBeadDesc2, 37, "mirrorbead", Inv.InvTabSection.Beads));
		catalog.Add(40, new InvItem(YukiText.cloudBead, YukiText.cloudBeadDesc1, YukiText.cloudBeadDesc2, 38, "cloudbead", Inv.InvTabSection.Beads));
		catalog.Add(41, new InvItem(YukiText.moneyBead, YukiText.moneyBeadDesc1, YukiText.moneyBeadDesc2, 39, "moneybead", Inv.InvTabSection.Beads));
		catalog.Add(42, new InvItem(YukiText.gunBead, YukiText.gunBeadDesc1, "", 40, "gunbead", Inv.InvTabSection.Beads));
		catalog.Add(43, new InvItem(YukiText.hacksaw, YukiText.hacksawDesc1, "", 41, "hacksawbead", Inv.InvTabSection.Beads));
		catalog.Add(44, new InvItem(YukiText.shieldBead, YukiText.shieldBeadDesc1, "", 42, "shieldbead", Inv.InvTabSection.Beads));
		catalog.Add(45, new InvItem(YukiText.contrastBead, YukiText.contrastBeadDesc1, YukiText.contrastBeadDesc2, 43, "contrastbead", Inv.InvTabSection.Beads));
		catalog.Add(46, new InvItem(YukiText.iceBead, YukiText.iceBeadDesc1, "", 44, "icebead", Inv.InvTabSection.Beads));
		catalog.Add(47, new InvItem(YukiText.threedeeBead, YukiText.threedeeBeadDesc1, "", 45, "threedeebead", Inv.InvTabSection.Beads));
		catalog.Add(100, new InvItem(YukiText.achievablesBead, YukiText.achievablesBeadDesc1, "", 47, "achievablesbead", Inv.InvTabSection.Beads));
		catalog.Add(55, new InvItem(YukiText.conviction + "+", YukiText.convictionUpgradeDesc1, "", 56, "upgrademurderblade", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(56, new InvItem(YukiText.kamakazi + "+", YukiText.kamakaziUpgradeDesc1, "", 59, "upgradekamakazi", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(57, new InvItem(YukiText.cloudSword + "+", YukiText.cloudSwordUpgradeDesc1, "", 62, "upgradecloudsword", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(58, new InvItem(YukiText.painkiller + "+", YukiText.painkillerUpgradeDesc1, "", 63, "upgradepainkiller", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(59, new InvItem(YukiText.shiftBlade + "+", YukiText.shiftBladeUpgradeDesc1, "", 56, "upgrademurderblade", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(60, new InvItem(YukiText.meatCleavers + "+", YukiText.meatCleaversUpgradeDesc1, "", 58, "upgradecleavers", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(61, new InvItem(YukiText.violenceHammer + "+", YukiText.violenceHammerUpgradeDesc1, "", 57, "upgradeviolencehammer", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(62, new InvItem(YukiText.theGuillotine + "+", YukiText.guillotineUpgradeDesc1, "", 60, "upgradeguillotine", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(63, new InvItem(YukiText.dekkentozter + "+", YukiText.dekkentozterUpgradeDesc1, "", 61, "upgradedekkentozter", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(66, new InvItem(YukiText.smg + "+", YukiText.smgUpgradeDesc1, "", 55, "upgradesmg", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(65, new InvItem(YukiText.machineArmGun + "+", YukiText.gunArmUpgradeDesc1, "", 79, "upgradegunarm", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(64, new InvItem(YukiText.machineArmSaw + "+", YukiText.sawArmUpgradeDesc1, "", 78, "upgradechainsaw", 200, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(67, new InvItem(YukiText.conviction + "++", YukiText.convictionUpgradeDesc1, "", 56, "upgrademurderblade", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(68, new InvItem(YukiText.kamakazi + "++", YukiText.kamakaziUpgradeDesc1, "", 59, "upgradekamakazi", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(69, new InvItem(YukiText.cloudSword + "++", YukiText.cloudSwordUpgradeDesc1, "", 62, "upgradecloudsword", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(70, new InvItem(YukiText.painkiller + "++", YukiText.painkillerUpgradeDesc1, "", 63, "upgradepainkiller", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(71, new InvItem(YukiText.shiftBlade + "++", YukiText.shiftBladeUpgradeDesc1, "", 56, "upgrademurderblade", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(72, new InvItem(YukiText.meatCleavers + "++", YukiText.meatCleaversUpgradeDesc1, "", 58, "upgradecleavers", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(73, new InvItem(YukiText.violenceHammer + "++", YukiText.violenceHammerUpgradeDesc1, "", 57, "upgradeviolencehammer", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(74, new InvItem(YukiText.theGuillotine + "++", YukiText.guillotineUpgradeDesc1, "", 60, "upgradeguillotine", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(75, new InvItem(YukiText.dekkentozter + "++", YukiText.dekkentozterUpgradeDesc1, "", 61, "upgradedekkentozter", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(78, new InvItem(YukiText.smg + "++", YukiText.smgUpgradeDesc1, "", 55, "upgradesmg", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(77, new InvItem(YukiText.machineArmGun + "++", YukiText.gunArmUpgradeDesc1, "", 79, "upgradegunarm", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(76, new InvItem(YukiText.machineArmSaw + "++", YukiText.sawArmUpgradeDesc1, "", 78, "upgradechainsaw", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(79, new InvItem(YukiText.health + "+", YukiText.healthUpgradeDesc1, "", 64, "upgradehealth", 50, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(80, new InvItem(YukiText.magic + "+", YukiText.magicUpgradeDesc1, "", 65, "upgrademagic", 50, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(81, new InvItem(YukiText.health + "++", YukiText.healthUpgradeDesc1, "", 64, "upgradehealth2", 250, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(82, new InvItem(YukiText.magic + "++", YukiText.magicUpgradeDesc1, "", 65, "upgrademagic2", 250, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(83, new InvItem(YukiText.health + "+++", YukiText.healthUpgradeDesc1, "", 64, "upgradehealth3", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(84, new InvItem(YukiText.magic + "+++", YukiText.magicUpgradeDesc1, "", 65, "upgrademagic3", 500, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(85, new InvItem(YukiText.health + "++++", YukiText.healthUpgradeDesc1, "", 64, "upgradehealth4", 1000, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(86, new InvItem(YukiText.magic + "++++", YukiText.magicUpgradeDesc1, "", 65, "upgrademagic4", 1000, 0, Inv.InvTabSection.Upgrade));
		catalog.Add(87, new InvItem(YukiText.electricBloodMagic, "", "", 66, "electricbloodmagic", Inv.InvTabSection.Progression));
		catalog.Add(88, new InvItem(YukiText.steelBloodMagic, "", "", 67, "steelbloodmagic", Inv.InvTabSection.Progression));
		catalog.Add(89, new InvItem(YukiText.spiritBloodMagic, "", "", 68, "holybloodmagic", Inv.InvTabSection.Progression));
		catalog.Add(90, new InvItem(YukiText.devouringBloodMagic, "", "", 69, "devouringbloodmagic", Inv.InvTabSection.Progression));
		catalog.Add(91, new InvItem(YukiText.electricDishMagic, "", "", 70, "electricdishmagic", Inv.InvTabSection.Progression));
		catalog.Add(92, new InvItem(YukiText.steelDishMagic, "", "", 71, "steeldishmagic", Inv.InvTabSection.Progression));
		catalog.Add(93, new InvItem(YukiText.spiritDishMagic, "", "", 72, "holydishmagic", Inv.InvTabSection.Progression));
		catalog.Add(94, new InvItem(YukiText.devouringDishMagic, "", "", 73, "devouringdishmagic", Inv.InvTabSection.Progression));
	}
}
