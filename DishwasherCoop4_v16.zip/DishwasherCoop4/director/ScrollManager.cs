using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace director;

public class ScrollManager
{
	public const int DEPTH_ONE = 0;

	public const int DEPTH_ZERO = 1;

	public const int DEPTH_MINUS_ONE = 2;

	public const int DEPTH_TWO = 3;

	public const int DEPTH_THREE = 4;

	public const int DEPTH_FOUR = 5;

	public const int DEPTH_FIVE = 6;

	public const int DEPTH_MINUS_TWO = 7;

	public const int DEPTH_MINUS_THREE = 8;

	public const int DEPTH_MINUS_FOUR = 9;

	public const int DEPTH_MINUS_FIVE = 10;

	public const int DEPTH_MINUS_SIX = 11;

	public const int DEPTH_TWENTY = 12;

	public const int DEPTH_FIFTEEN = 13;

	public static float zoom = 1f;

	public static Vector2 screenSize;

	public static Vector2 scroll;

	private static Matrix projectionMatrix;

	private static GraphicsDevice dev;

	public static Vector2 camOffset = default;

	public static float camOffsetFrame = 0f;

	public static float camZoom = 0f;

	public static float camZoomFrame = 0f;

	public static float xoff3;

	public static float[] cannedDepth;

	public static void Init(GraphicsDevice _dev, Vector2 _screenSize)
	{
		dev = _dev;
		SetProjectionMatrix((float)Math.PI / 4f);
		screenSize = _screenSize;
		zoom = -10f;
		scroll = default;
		cannedDepth = new float[14];
	}

	public static void UpdateCannedValues()
	{
		if (float.IsNaN(scroll.Y))
		{
			scroll.Y = 0f;
		}
		if (float.IsNaN(scroll.X))
		{
			scroll.X = 0f;
		}
		cannedDepth[0] = GetCannedSize(1f);
		cannedDepth[1] = GetCannedSize(0f);
		cannedDepth[2] = GetCannedSize(-1f);
		cannedDepth[3] = GetCannedSize(2f);
		cannedDepth[4] = GetCannedSize(3f);
		cannedDepth[5] = GetCannedSize(4f);
		cannedDepth[6] = GetCannedSize(5f);
		cannedDepth[13] = GetCannedSize(15f);
		cannedDepth[12] = GetCannedSize(20f);
		cannedDepth[7] = GetCannedSize(-2f);
		cannedDepth[8] = GetCannedSize(-3f);
		cannedDepth[9] = GetCannedSize(-4f);
		cannedDepth[10] = GetCannedSize(-5f);
		cannedDepth[11] = GetCannedSize(-6f);
	}

	public static void SetProjectionMatrix(float fov)
	{
		projectionMatrix = Matrix.CreatePerspectiveFieldOfView(fov, dev.Viewport.AspectRatio, 0.3f, 1000f);
	}

	private static float GetCannedSize(float dist)
	{
		Matrix view = Matrix.CreateLookAt(new Vector3(zoom, 0f, 0f), new Vector3(dist, 0f, 0f), new Vector3(0f, 1f, 0f));
		Vector3 vector = dev.Viewport.Project(new Vector3(dist, 0f, 0f), projectionMatrix, view, Matrix.Identity);
		return dev.Viewport.Project(new Vector3(dist, 0f, 0.01f), projectionMatrix, view, Matrix.Identity).X - vector.X;
	}

	public static float GetSize(float dist)
	{
		if (dist == 0f)
		{
			return cannedDepth[1];
		}
		if (dist > 0f)
		{
			if (dist <= 1f)
			{
				return cannedDepth[0];
			}
			if (dist <= 2f)
			{
				return cannedDepth[3];
			}
			if (dist <= 3f)
			{
				return cannedDepth[4];
			}
			if (dist <= 4f)
			{
				return cannedDepth[5];
			}
			if (dist <= 5f)
			{
				return cannedDepth[6];
			}
			if (dist <= 15f)
			{
				return cannedDepth[13];
			}
			return cannedDepth[12];
		}
		if (dist < 0f)
		{
			if (dist >= -1f)
			{
				return cannedDepth[2];
			}
			if (dist >= -2f)
			{
				return cannedDepth[7];
			}
			if (dist >= -3f)
			{
				return cannedDepth[8];
			}
			if (dist >= -4f)
			{
				return cannedDepth[9];
			}
			if (dist >= -5f)
			{
				return cannedDepth[10];
			}
			if (dist >= -6f)
			{
				return cannedDepth[11];
			}
		}
		Matrix view = Matrix.CreateLookAt(new Vector3(zoom, 0f, 0f), new Vector3(dist, 0f, 0f), new Vector3(0f, 1f, 0f));
		Vector3 vector = dev.Viewport.Project(new Vector3(dist, 0f, 0f), projectionMatrix, view, Matrix.Identity);
		return dev.Viewport.Project(new Vector3(dist, 0f, 0.01f), projectionMatrix, view, Matrix.Identity).X - vector.X;
	}

	public static Vector2 GetRealLoc(Vector2 loc, float layer)
	{
		return (loc - screenSize / 2f) / GetSize(layer) + scroll;
	}

	public static Vector2 GetScreenLoc(Vector2 loc, float layer)
	{
		if (layer == 1f)
		{
			return GetScreenLoc(loc, 0);
		}
		if (layer == -1f)
		{
			return GetScreenLoc(loc, 2);
		}
		if (layer == 0f)
		{
			return GetScreenLoc(loc, 1);
		}
		if (layer == 2f)
		{
			return GetScreenLoc(loc, 3);
		}
		if (layer == 3f)
		{
			return GetScreenLoc(loc, 4);
		}
		if (layer == 4f)
		{
			return GetScreenLoc(loc, 5);
		}
		if (layer == 5f)
		{
			return GetScreenLoc(loc, 6);
		}
		if (layer == 15f)
		{
			return GetScreenLoc(loc, 13);
		}
		if (layer == 20f)
		{
			return GetScreenLoc(loc, 12);
		}
		if (layer == -2f)
		{
			return GetScreenLoc(loc, 7);
		}
		if (layer == -3f)
		{
			return GetScreenLoc(loc, 8);
		}
		if (layer == -4f)
		{
			return GetScreenLoc(loc, 9);
		}
		if (layer == -5f)
		{
			return GetScreenLoc(loc, 10);
		}
		return (loc - scroll) * GetSize(layer) + screenSize / 2f;
	}

	public static Vector2 GetScreenLoc(Vector3 loc, float layer)
	{
		return (new Vector2(loc.X, loc.Y - loc.Z) - scroll) * GetSize(layer) + screenSize / 2f;
	}

	public static Vector2 GetScreenLoc(Vector2 loc, int layer)
	{
		return (loc - scroll) * cannedDepth[layer] + screenSize / 2f;
	}

	public static Vector2 GetScreenLoc(Vector3 loc, int layer)
	{
		return (new Vector2(loc.X, loc.Y - loc.Z) - scroll) * cannedDepth[layer] + screenSize / 2f;
	}

	internal static void Reset()
	{
		scroll = default;
		zoom = -10f;
	}
}
