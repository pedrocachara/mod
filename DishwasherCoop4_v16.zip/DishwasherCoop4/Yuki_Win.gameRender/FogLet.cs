using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.maps;

namespace Yuki_Win.gameRender;

public class FogLet
{
	public const float OUT = 100f;

	public const float WIDTH = 256f;

	private Vector2 loc;

	private Vector2 traj;

	private float rSpeed;

	private float r;

	public void Update(Vector2 scrollDif)
	{
		loc += traj * FMan.frameTime * 0.1f;
		loc.X -= scrollDif.X * (0.2f + loc.Y / 1100f) * 2.5f;
		loc.Y -= scrollDif.Y * 0.75f * 2.5f;
		r += rSpeed * FMan.frameTime * 0.2f;
		if (loc.X < -100f)
		{
			loc.X = 356f;
		}
		if (loc.Y < -100f)
		{
			loc.Y = 356f;
		}
		if (loc.X > 356f)
		{
			loc.X = -100f;
		}
		if (loc.Y > 356f)
		{
			loc.Y = -100f;
		}
	}

	public FogLet()
	{
		Reset();
	}

	public void Reset()
	{
		loc = Rand.GetRandomVec2(0f, 256f, 0f, 256f);
		traj = Rand.GetRandomVec2(-100f, 100f, -100f, 100f);
		rSpeed = Rand.GetRandomFloat(-1f, 1f);
	}

	public void Draw(SpriteBatch sprite, int ID)
	{
		float num = 1.5f;
		switch (Game1.gameMap.theme.theme)
		{
		case Themes.ThemeType.Moon:
			num = 0.6f;
			break;
		case Themes.ThemeType.Cache:
			num = 1f;
			break;
		}
		float num2 = 0.001f * num * loc.Y;
		float num3 = (float)Game1.gameMap.CurMap().ySize * 64f - ScrollManager.scroll.Y;
		num3 -= 100f;
		float num4 = 400f;
		if (num3 < num4)
		{
			if (num3 < 0f)
			{
				num3 = 0f;
			}
			num3 = (num4 - num3) / num4;
			num2 *= num3;
			sprite.Draw(Game1.spritesTex, loc * new Vector2(4f * (ScrollManager.screenSize.X / 1280f), 1.5f * (ScrollManager.screenSize.Y / 720f)) + new Vector2(0f, ScrollManager.screenSize.Y - 220f), new Rectangle(576 + ID % 4 * 64, 192, 64, 64), new Color(num2, num2, num2, 1f), 0f, new Vector2(32f, 32f), new Vector2(8f, 3f) * (ScrollManager.screenSize.X / 1280f), SpriteEffects.None, 1f);
		}
	}
}
