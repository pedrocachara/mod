using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender;

public class WaterRender
{
	private float[] delta = new float[3];

	private float[] gamma = new float[3];

	private GlowLet[] glowlet;

	public WaterRender()
	{
		glowlet = new GlowLet[32];
		for (int i = 0; i < glowlet.Length; i++)
		{
			glowlet[i] = new GlowLet();
		}
	}

	public void Update(Vector2 scrollDif)
	{
		MoveWater(scrollDif);
		for (int i = 0; i < delta.Length; i++)
		{
			delta[i] += FMan.frameTime * ((float)i / 10f + 1f) * 0.3f;
			gamma[i] += FMan.frameTime * ((float)(3 - i) / 10f + 1f) * 0.3f;
			if (delta[i] > 1f)
			{
				delta[i]--;
			}
			if (gamma[i] > 1f)
			{
				gamma[i]--;
			}
		}
		for (int j = 0; j < glowlet.Length; j++)
		{
			glowlet[j].frame += FMan.frameTime * 2f;
			if (glowlet[j].frame > 6.28f)
			{
				glowlet[j].frame -= 6.28f;
			}
			if (j % 2 == 0)
			{
				glowlet[j].loc.X += FMan.frameTime * 15f;
			}
			else
			{
				glowlet[j].loc.X -= FMan.frameTime * 15f;
			}
			while (glowlet[j].loc.X < -100f)
			{
				glowlet[j].loc.X += ScrollManager.screenSize.X + 200f;
			}
			while (glowlet[j].loc.X > ScrollManager.screenSize.X + 100f)
			{
				glowlet[j].loc.X -= ScrollManager.screenSize.X + 200f;
			}
		}
	}

	public void MoveWater(Vector2 mov)
	{
		mov.X /= -200f;
		mov.Y /= 400f;
		delta[0] -= mov.X;
		gamma[0] -= mov.Y;
		delta[1] -= mov.X;
		gamma[1] += mov.Y;
		delta[2] += mov.X;
		gamma[2] -= mov.Y;
		for (int i = 0; i < delta.Length; i++)
		{
			while (delta[i] < 0f)
			{
				delta[i]++;
			}
			while (gamma[i] < 0f)
			{
				gamma[i]++;
			}
			while (delta[i] > 1f)
			{
				delta[i]--;
			}
			while (gamma[i] > 1f)
			{
				gamma[i]--;
			}
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		SpriteTools.BeginAlpha();
		for (int i = 0; i < delta.Length; i++)
		{
			sprite.Draw(Game1.waterTex, new Rectangle(0, 0, 256, 256), new Rectangle((int)(delta[i] * 128f), (int)(gamma[i] * 128f), 128, 128), Color.White, 0f, default, i switch
			{
				1 => SpriteEffects.FlipVertically, 
				0 => SpriteEffects.None, 
				_ => SpriteEffects.FlipHorizontally, 
			}, 1f);
		}
		sprite.End();
	}

	public void DrawGlowlets(SpriteBatch sprite)
	{
		SpriteTools.BeginAdditive();
		for (int i = 0; i < glowlet.Length; i++)
		{
			Vector2 screenLoc = ScrollManager.GetScreenLoc(new Vector2(0f, Game1.gameMap.waterLev) + glowlet[i].loc, -1f);
			if (float.IsPositiveInfinity(screenLoc.X) || float.IsNegativeInfinity(screenLoc.X) || float.IsNaN(screenLoc.X))
			{
				screenLoc.X = 0f;
			}
			while (screenLoc.X > ScrollManager.screenSize.X + 200f)
			{
				screenLoc.X -= ScrollManager.screenSize.X + 200f;
			}
			while (screenLoc.X < -200f)
			{
				screenLoc.X += ScrollManager.screenSize.X + 200f;
			}
			float num = 1f;
			if (glowlet[i].loc.X < 0f)
			{
				num = glowlet[i].loc.X / -100f;
			}
			if (glowlet[i].loc.X > ScrollManager.screenSize.X)
			{
				num = (glowlet[i].loc.X - ScrollManager.screenSize.X) / 100f;
			}
			sprite.Draw(Game1.spritesTex, screenLoc, new Rectangle(896, 704, 64, 128), new Color(1f, 1f, 1f, num * ((float)Math.Sin(glowlet[i].frame) * 0.05f + 0.15f)), 3.3f, new Vector2(32f, 16f), ScrollManager.cannedDepth[2] * new Vector2(4f, 2f), SpriteEffects.None, 1f);
		}
		sprite.End();
	}
}
