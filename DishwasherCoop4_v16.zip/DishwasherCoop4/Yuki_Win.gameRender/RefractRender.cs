using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.chars;

namespace Yuki_Win.gameRender;

public class RefractRender
{
	public void Prepare(SpriteBatch sprite, GraphicsDeviceManager dev, int threedee)
	{
		dev.GraphicsDevice.SetRenderTarget(Game1.refractTarg);
		dev.GraphicsDevice.Clear(Color.Black);
		SpriteTools.BeginAdditive();
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (Game1.character[i].exists && Game1.character[i].charAnim.charTrigs.hasGibSpray && Game1.character[i].charAnim.charTrigs.sprayType == CharTrigs.SprayType.SquirtGun)
			{
				Game1.character[i].charAnim.charTrigs.DrawSquirtGun(sprite, refract: true);
			}
		}
		Game1.spriteMan.DrawCamsplats(sprite, threedee);
		Game1.spriteMan.DrawRefract(sprite);
		CharSwishes.Draw(sprite);
		for (int j = 0; j < Game1.character.Length; j++)
		{
			if (Game1.character[j].exists && Game1.character[j].charUpdate.thermop > 0f)
			{
				Game1.character[j].Draw(sprite, grabberOnly: false);
			}
		}
		if (Game1.gameMap.water)
		{
			Vector2 screenLoc = ScrollManager.GetScreenLoc(new Vector2(0f, Game1.gameMap.waterLev), 1f);
			if (!Game1.waterReady)
			{
				Game1.waterTargTex = Game1.waterTarg;
				Game1.waterReady = true;
			}
			int num = (int)ScrollManager.screenSize.X / 427 + 1;
			for (int k = 0; k < num; k++)
			{
				for (int l = 0; l < 3; l++)
				{
					sprite.Draw(Game1.waterTargTex, new Rectangle(k * 427, (int)screenLoc.Y + l * 150, 427, 150), new Color(0f, 1f, 0f, 1f));
				}
			}
		}
		SpriteTools.End();
	}
}
