using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.maps;
using Yuki_Win.player;

namespace Yuki_Win.gameRender;

public class PostGlow
{
	private float r;

	private float g;

	private float b;

	private float mag;

	private float brite;

	private Vector2 loc;

	private float bursts;

	public bool exists;

	public PostGlow()
	{
		exists = false;
	}

	public void Init(Vector2 loc, float r, float g, float b, float mag, float brite, float bursts)
	{
		this.loc = loc;
		this.r = r;
		this.g = g;
		this.b = b;
		this.mag = mag;
		this.brite = brite;
		this.bursts = bursts;
		exists = true;
	}

	public void Draw(SpriteBatch spriteBatch, Texture2D spritesTex)
	{
		float num = mag;
		float num2 = brite;
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Lift)
		{
			float num3 = 1f;
			if (Game1.gameMap.liftOn && Game1.gameMap.liftFrame > 5f)
			{
				num3 = ((!(Game1.gameMap.liftFrame > 30f)) ? (num3 * ((30f - Game1.gameMap.liftFrame) / 25f)) : 0f);
			}
			num3++;
			num *= num3;
			num2 *= num3;
		}
		else if (Game1.gameMap.theme.theme != Themes.ThemeType.Church && Game1.gameMap.theme.theme != Themes.ThemeType.Closet && Game1.gameMap.theme.theme != Themes.ThemeType.GearCloset)
		{
			_ = Game1.gameMap.theme.theme;
			_ = 11;
		}
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Prison && Game1.gameMap.alert)
		{
			num *= 1.5f;
			num2 *= 2f;
		}
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Aquarium)
		{
			g *= 1.2f;
			b *= 1.5f;
		}
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Dark)
		{
			g *= 0.25f;
			b *= 0.25f;
		}
		if (Game1.gameMap.theme.theme == Themes.ThemeType.EliteLobby || Game1.gameMap.theme.theme == Themes.ThemeType.Elite)
		{
			r *= 0.5f;
			g *= 0.75f;
		}
		if (ScrollManager.zoom < 1.8f)
		{
			float num4 = ScrollManager.cannedDepth[0] / 1.5f;
			num *= num4;
		}
		if (GameSettings.difficulty == 0)
		{
			r *= 0.1f;
			g *= 0.1f;
			num2 *= 1.5f;
		}
		if (Game1.gameMap.redLightval > 0f && Game1.gameMap.beadTheme != GameMap.BeadTheme.Contrast)
		{
			r += Game1.gameMap.redLightval * 0.25f;
			g -= Game1.gameMap.redLightval * 0.25f;
			b -= Game1.gameMap.redLightval * 0.25f;
		}
		if (num > 0f)
		{
			spriteBatch.Draw(spritesTex, loc, new Rectangle(320, 704, 128, 128), new Color(new Vector4(r, g, b, num2)), loc.X / 550f, new Vector2(64f, 64f), num * 2f, SpriteEffects.None, 1f);
			_ = Game1.gameMap.theme.theme;
			_ = 12;
		}
	}
}
