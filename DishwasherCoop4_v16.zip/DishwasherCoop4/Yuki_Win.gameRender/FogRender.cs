using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender;

internal class FogRender
{
	private FogLet[] fog;

	public static int TOP = 400;

	public FogRender()
	{
		fog = new FogLet[128];
		for (int i = 0; i < fog.Length; i++)
		{
			fog[i] = new FogLet();
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		for (int i = 0; i < 32; i++)
		{
			fog[i].Draw(sprite, i % 8);
		}
	}

	public void Update(Vector2 offset)
	{
		for (int i = 0; i < 32; i++)
		{
			fog[i].Update(offset);
		}
	}

	internal void Reset()
	{
		for (int i = 0; i < 32; i++)
		{
			fog[i].Reset();
		}
	}
}
