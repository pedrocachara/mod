using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.director;

namespace Yuki_Win.gameRender;

internal class FilterRender
{
	private Effect filterEffect;

	private Effect oldFilterEffect;

	public bool newVersion;

	private EffectPass pass;

	public float tR;

	public float tG;

	public float tB;

	public float bR;

	public float bG;

	public float bB;

	public float burn = 0.3f;

	public float gray;

	public float charBrite = 1f;

	public float brite;

	private Texture2D drawTex;

	public bool readyToDraw;

	public FilterRender(ContentManager Content)
	{
		filterEffect = Content.Load<Effect>("fx/filter");
		oldFilterEffect = Content.Load<Effect>("fx/oldfilter");
		newVersion = true;
	}

	public void SetFilter(float tR, float tG, float tB, float bR, float bG, float bB)
	{
		this.tR = tR;
		this.tG = tG;
		this.tB = tB;
		this.bR = bR;
		this.bG = bG;
		this.bB = bB;
	}

	internal void Draw(GraphicsDeviceManager dev, RenderTarget2D refractTarg, RenderTarget2D mainTarg, SpriteBatch sprite)
	{
		readyToDraw = false;
		if (!readyToDraw)
		{
			readyToDraw = true;
			drawTex = mainTarg;
		}
		dev.GraphicsDevice.Textures[1] = refractTarg;
		if (Game1.soloMgr.active)
		{
			brite += Game1.soloMgr.brite;
		}
		if (newVersion)
		{
			filterEffect.Parameters["tR"].SetValue(tR);
			filterEffect.Parameters["tG"].SetValue(tG);
			filterEffect.Parameters["tB"].SetValue(tB);
			filterEffect.Parameters["bR"].SetValue(bR);
			filterEffect.Parameters["bG"].SetValue(bG);
			filterEffect.Parameters["bB"].SetValue(bB);
			if (QuakeManager.quirkFrame > 0f)
			{
				float num = QuakeManager.quirkFrame / QuakeManager.quirkMax * 3.14f;
				burn += (float)Math.Sin(num) * QuakeManager.quirkMax * Rand.GetRandomFloat(5f, 7f);
			}
			filterEffect.Parameters["burn"].SetValue(burn * 2f);
			filterEffect.Parameters["brite"].SetValue(QuakeManager.Bright() + brite + (Game1.gameMap.haze ? 0.2f : 0f));
			if (flibitPort.CurrentBlood == 0)
			{
				filterEffect.Parameters["blood"].SetValue(0.2f);
			}
			else
			{
				filterEffect.Parameters["blood"].SetValue(0.5f);
			}
			filterEffect.Parameters["contrast"].SetValue(QuakeManager.Contrast());
			if (Game1.gameMap.water)
			{
				Vector2 screenLoc = ScrollManager.GetScreenLoc(new Vector2(0f, Game1.gameMap.waterLev), 1f);
				if (screenLoc.Y < 360f)
				{
					screenLoc.Y = 360f;
				}
				filterEffect.Parameters["waterLev"].SetValue(screenLoc.Y / ScrollManager.screenSize.Y);
			}
			else
			{
				filterEffect.Parameters["waterLev"].SetValue(0f);
			}
			SpriteTools.BeginOpaque(filterEffect);
			sprite.Draw(drawTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
			SpriteTools.End();
		}
		else
		{
			oldFilterEffect.Parameters["tR"].SetValue(tR);
			oldFilterEffect.Parameters["tG"].SetValue(tG);
			oldFilterEffect.Parameters["tB"].SetValue(tB);
			oldFilterEffect.Parameters["bR"].SetValue(bR);
			oldFilterEffect.Parameters["bG"].SetValue(bG);
			oldFilterEffect.Parameters["bB"].SetValue(bB);
			oldFilterEffect.Parameters["burn"].SetValue(burn * 4f);
			oldFilterEffect.Parameters["brite"].SetValue(QuakeManager.Bright() + brite);
			oldFilterEffect.Parameters["gray"].SetValue(gray);
			oldFilterEffect.Parameters["contrast"].SetValue(QuakeManager.Contrast());
			if (Game1.gameMap.water)
			{
				Vector2 screenLoc2 = ScrollManager.GetScreenLoc(new Vector2(0f, Game1.gameMap.waterLev), 1f);
				if (screenLoc2.Y < 360f)
				{
					screenLoc2.Y = 360f;
				}
				oldFilterEffect.Parameters["waterLev"].SetValue(screenLoc2.Y / ScrollManager.screenSize.Y);
			}
			else
			{
				oldFilterEffect.Parameters["waterLev"].SetValue(0f);
			}
			SpriteTools.BeginOpaque(oldFilterEffect);
			sprite.Draw(drawTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
			SpriteTools.End();
		}
		dev.GraphicsDevice.Textures[1] = null;
	}
}
