using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender;

public class PostGlowMgr
{
	private static PostGlow[] postGlow;

	private static CharGlow[] charGlow;

	public static int charGlowCount;

	public static bool drawAble = false;

	public static int totalPostGlows;

	public static void Init()
	{
		postGlow = new PostGlow[64];
		charGlow = new CharGlow[16];
		for (int i = 0; i < postGlow.Length; i++)
		{
			postGlow[i] = new PostGlow();
		}
		for (int j = 0; j < charGlow.Length; j++)
		{
			charGlow[j] = new CharGlow();
		}
	}

	public static void AddGlow(Vector2 loc, float r, float g, float b, float mag, float brite, float bursts)
	{
		if (totalPostGlows < postGlow.Length)
		{
			postGlow[totalPostGlows].Init(loc, r, g, b, mag, brite, bursts);
			drawAble = true;
			totalPostGlows++;
		}
	}

	public static void AddCharGlow(Vector2 loc, float r, float g, float b, float size)
	{
		drawAble = true;
		if (charGlowCount < charGlow.Length)
		{
			charGlow[charGlowCount].Init(loc, r, g, b, size);
			charGlowCount++;
		}
	}

	public static void Draw(SpriteBatch spriteBatch, Texture2D spritesTex)
	{
		if (drawAble)
		{
			for (int i = 0; i < totalPostGlows; i++)
			{
				postGlow[i].Draw(spriteBatch, spritesTex);
				postGlow[i].exists = false;
			}
			for (int j = 0; j < charGlowCount; j++)
			{
				charGlow[j].Draw(spriteBatch);
			}
			totalPostGlows = 0;
			charGlowCount = 0;
			drawAble = false;
		}
	}
}
