using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.chars;
using Yuki_Win.debug;
using Yuki_Win.director;
using Yuki_Win.eightbit;
using Yuki_Win.gameRender.bloom;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.sprites;

namespace Yuki_Win.gameRender;

internal class GameRender
{
	public enum FadingBackgroundMode
	{
		None,
		BGOnly,
		LowLevels,
		MidLevels,
		MidLevelsHeavy
	}

	private const float XOFF_DEF = -9f;

	private const float XEYE_DEF = 6f;

	private static bool canDrawFeedback;

	public static RefractRender refractRender;

	public static BloomRender bloomRender;

	public static FilterRender filterRender;

	public static FadeRender fadeRender;

	public static ThreshRender threshRender;

	public static MapCompositor mapCompositor;

	public static BGRefractCompositor bgRefractCompositor;

	public static BloomComponent bloomComponent;

	public static float redVal = 0f;

	public static FogRender fogRender;

	public static WaterRender waterRender;

	private static bool needsEnd;

	public static float bloodR = 0.3f;

	public static float bloodG = 0f;

	public static float bloodB = 0f;

	public static bool feedbackMode;

	public static bool feedbackReady;

	public static int feedbackIdx;

	public static ThreeDeeRender threedeeRender;

	public static float fadingBackgroundContrast = 1f;

	public static float fadingBackgroundBrite = 0f;

	public static FadingBackgroundMode fadingBackgroundMode = FadingBackgroundMode.None;

	public static void Init(GraphicsDeviceManager graphics, ContentManager Content)
	{
		fadeRender = new FadeRender(Content);
		bloomRender = new BloomRender(Content);
		filterRender = new FilterRender(Content);
		mapCompositor = new MapCompositor(Content);
		threshRender = new ThreshRender(Content);
		refractRender = new RefractRender();
		bgRefractCompositor = new BGRefractCompositor(Content);
		threedeeRender = new ThreeDeeRender(Content);
		fogRender = new FogRender();
		waterRender = new WaterRender();
		BurstRender.Initialize(Content);
		ToastRender.Initialize(Content);
		bloomComponent = new BloomComponent(graphics.GraphicsDevice, Content);
	}

	public static void DrawNoShaders(GraphicsDeviceManager dev, Character[] c, GameMap gameMap, SpriteBatch sprite, SpriteManager spriteMan, Texture2D spritesTex)
	{
		if (EightBitGame.enabled)
		{
			return;
		}
		gameMap.CurMap().Draw(sprite, 0, 3, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
		SpriteTools.BeginAlpha();
		spriteMan.DrawGibs(sprite, spritesTex, grounded: true);
		for (int i = 0; i < c.Length; i++)
		{
			if (c[i].exists)
			{
				c[i].Draw(sprite, grabberOnly: false);
			}
		}
		spriteMan.Draw(sprite, spritesTex);
		spriteMan.DrawGibs(sprite, spritesTex, grounded: false);
		SpriteTools.End();
		SpriteTools.BeginAdditive();
		spriteMan.DrawAlpha(sprite, spritesTex);
		SpriteTools.End();
		gameMap.CurMap().Draw(sprite, 3, 5, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
		SpriteTools.BeginAdditive();
		PostGlowMgr.Draw(sprite, spritesTex);
		SpriteTools.End();
		SpriteTools.BeginAlpha();
		if (Game1.killManager.bits > 0f)
		{
			for (int j = 0; j < 64; j++)
			{
				float randomFloat = Rand.GetRandomFloat(0f, 6.28f);
				Vector2 position = ScrollManager.screenSize / 2f + new Vector2((float)Math.Cos(randomFloat) * (ScrollManager.screenSize.X * 0.468f), (float)Math.Sin(randomFloat) * (ScrollManager.screenSize.Y * 0.555f)) * Rand.GetRandomFloat(0.8f, 1.5f);
				sprite.Draw(spritesTex, position, new Rectangle(128, 0, 128, 32), new Color(new Vector4(0f, 0f, 0f, 5f * Game1.killManager.bits)), randomFloat, new Vector2(64f, 32f), Rand.GetRandomFloat(0.5f, 2f), SpriteEffects.None, 1f);
			}
		}
		SpriteTools.End();
	}

	private static void DrawBack(SpriteBatch sprite, GameMap gameMap, float scale)
	{
		SpriteTools.BeginAlpha();
		int background = gameMap.theme.GetBackground();
		if (GameSettings.difficulty == 0)
		{
			if (background == 0 || background == 4)
			{
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), Color.Black);
			}
			else
			{
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), new Color(0.5f, 0.2f, 0.4f, 1f));
			}
		}
		else
		{
			switch (background)
			{
			case 6:
			{
				float num3 = 1f - Game1.gameMap.goryoAlpha;
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), gameMap.theme.ColorKBG(0f, 0.03f * num3, 0.05f * num3));
				break;
			}
			case 9:
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), gameMap.theme.ColorKBG(0.2f, 0.25f, 0.3f));
				break;
			case 7:
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), gameMap.theme.ColorKBG(0.3f, 0.25f, 0.25f));
				break;
			case 0:
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), Color.Black);
				break;
			case 4:
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), gameMap.theme.ColorKBG(0.2f, 0.15f, 0.1f));
				break;
			case 8:
			{
				float num2 = 1f;
				if (Game1.gameMap.CrazyTransitionInFrame > 0f)
				{
					num2 = (5f - Game1.gameMap.CrazyTransitionInFrame) / 5f;
				}
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), gameMap.theme.ColorKBG(0.2f * num2, 0.15f * num2, 0.1f * num2));
				gameMap.DrawEnviron(sprite);
				break;
			}
			case 1:
			case 2:
			{
				if (gameMap.redLightval >= 1f)
				{
					sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), Color.Black);
					break;
				}
				float num4 = 1f;
				if (gameMap.redLightval > 0f)
				{
					num4 -= gameMap.redLightval;
				}
				if (background == 2)
				{
					num4 -= 0.4f;
				}
				gameMap.theme.ColorKBG(num4, num4, num4);
				if (background == 2)
				{
					gameMap.theme.ColorKBG(0.8f, 0.8f, 0.8f);
				}
				Vector2 vector = new Vector2((float)gameMap.CurMap().xSize * 64f, (float)gameMap.CurMap().ySize * 64f);
				vector = ScrollManager.scroll / vector;
				vector -= new Vector2(0.5f, 0.5f);
				vector *= 128f;
				sprite.Draw(Game1.bgTex[(background == 2) ? 1u : 0u], new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), gameMap.theme.ColorKBG(num4, num4, num4));
				switch (background)
				{
				case 2:
				{
					for (int j = 0; j < 2; j++)
					{
						sprite.Draw(Game1.environText, (new Vector2(ScrollManager.screenSize.X, ScrollManager.screenSize.Y) / 2f - vector + new Vector2(360f, 110f)) * scale, new Rectangle(320, 64 + j * 192, 192, 192), new Color(1f, 1f, 1f, 0.5f), (j == 0) ? gameMap.environ.alpha : gameMap.environ.beta, new Vector2(96f, 96f), (4f + (float)j) * scale, SpriteEffects.None, 1f);
					}
					break;
				}
				case 1:
				{
					for (int i = 0; i < 2; i++)
					{
						sprite.Draw(Game1.environText, (new Vector2(460f, 82f) * 2f - vector) * scale, new Rectangle(i * 128, 64, 128, 128), new Color(num4, num4, num4, 0.6f), (i == 0) ? gameMap.environ.alpha : gameMap.environ.beta, new Vector2(64f, 64f), (2.2f + (float)i * 0.4f) * scale, SpriteEffects.None, 1f);
					}
					break;
				}
				}
				gameMap.DrawEnviron(sprite);
				if (!gameMap.liftOn || !gameMap.liftBlack)
				{
					break;
				}
				Vector2 screenLoc = ScrollManager.GetScreenLoc(new Vector2(0f, gameMap.liftBlackFrame / 4f), 1f);
				if (screenLoc.Y > 0f)
				{
					if (screenLoc.Y > ScrollManager.screenSize.Y)
					{
						screenLoc.Y = ScrollManager.screenSize.Y;
					}
					sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)screenLoc.Y), Color.Black);
				}
				break;
			}
			case 3:
			case 10:
			{
				Color color = gameMap.theme.ColorKBG(1f, 1f, 1f);
				if (background == 10)
				{
					color = gameMap.theme.ColorKBG(0.65f, 0.65f, 0.65f);
				}
				bool flag = false;
				if (gameMap.theme.theme == Themes.ThemeType.Descent && !(gameMap.descentFrame < 15f))
				{
					if (gameMap.descentFrame < 25f)
					{
						float num = (25f - gameMap.descentFrame) / 10f;
						color = gameMap.theme.ColorKBG(num, num, num);
					}
					else
					{
						color = Color.Black;
						flag = true;
					}
				}
				sprite.Draw(Game1.bgTex[2], new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), color);
				if (!flag && background != 10)
				{
					gameMap.DrawEnviron(sprite);
				}
				break;
			}
			case 5:
				sprite.Draw(Game1.bgTex[3], new Rectangle(0, 0, (int)(ScrollManager.screenSize.X * scale), (int)(ScrollManager.screenSize.Y * scale)), Color.White);
				break;
			}
		}
		sprite.End();
		if (gameMap.theme.theme == Themes.ThemeType.Escape || Game1.gameMap.theme.theme == Themes.ThemeType.EscapeOut)
		{
			SpriteTools.BeginAdditive();
			for (int k = 0; k < 128; k++)
			{
				sprite.Draw(Game1.spritesTex, Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, 0f, ScrollManager.screenSize.Y) * scale, new Rectangle(Rand.GetRandomInt(0, 3) * 64 + 256, 192, 64, 64), new Color(1f, 1f, 1f, 0.1f), 0f, new Vector2(32f, 32f), new Vector2(20f, 1f) * scale, SpriteEffects.None, 1f);
			}
			sprite.End();
		}
		switch (fadingBackgroundMode)
		{
		case FadingBackgroundMode.None:
			if (gameMap.bgRefractMode)
			{
				bgRefractCompositor.Draw(Game1.bgRefractTarg, sprite);
				if (gameMap.CurMap().drewBGRefract && gameMap.CurMap().bgRefractEndIdx > -1)
				{
					gameMap.CurMap().DrawPostBGRefract(sprite, Game1.mapsTex);
				}
			}
			else
			{
				gameMap.CurMap().Draw(sprite, 0, 2, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, scale);
				if (gameMap.theme.theme == Themes.ThemeType.Aquarium)
				{
					gameMap.environ.DrawAquarium(sprite);
				}
			}
			break;
		case FadingBackgroundMode.LowLevels:
			gameMap.CurMap().Draw(sprite, 0, 1, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, scale);
			break;
		case FadingBackgroundMode.MidLevels:
		case FadingBackgroundMode.MidLevelsHeavy:
			gameMap.CurMap().Draw(sprite, 0, 2, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, scale);
			if (gameMap.theme.theme == Themes.ThemeType.Aquarium)
			{
				gameMap.environ.DrawAquarium(sprite);
			}
			break;
		case FadingBackgroundMode.BGOnly:
			break;
		}
	}

	public static void Draw(GraphicsDeviceManager dev, Character[] c, GameMap gameMap, SpriteBatch sprite, SpriteManager spriteMan, Texture2D spritesTex, GraphicsDeviceManager graphics)
	{
		ScrollManager.xoff3 = 0f;
		if (Game1.loader.loadingStuff)
		{
			dev.GraphicsDevice.Clear(Color.Black);
			Game1.sceneMgr.DrawLoader(sprite);
			return;
		}
		if (gameMap.beadTheme == GameMap.BeadTheme.ThreeDee)
		{
			Vector2 scroll = ScrollManager.scroll;
			ScrollManager.scroll = scroll + new Vector2(-5f, 0f);
			DrawAll(dev, c, gameMap, sprite, spriteMan, spritesTex, 0, graphics);
			ScrollManager.scroll = scroll + new Vector2(5f, 0f);
			DrawAll(dev, c, gameMap, sprite, spriteMan, spritesTex, 1, graphics);
			ScrollManager.scroll = scroll;
			dev.GraphicsDevice.SetRenderTarget(null);
			dev.GraphicsDevice.Clear(Color.Black);
			threedeeRender.Draw(dev, Game1.threeDeeTarg[0], Game1.threeDeeTarg[1], sprite);
		}
		else
		{
			if (Game1.camMgr.bossToast.needsImprint)
			{
				DrawAll(dev, c, gameMap, sprite, spriteMan, spritesTex, 0, graphics);
				Game1.camMgr.bossToast.needsImprint = false;
			}
			if (Game1.camMgr.bossToast.IsActive())
			{
				DrawBossToast(dev, sprite, threedee: false);
			}
			else
			{
				DrawAll(dev, c, gameMap, sprite, spriteMan, spritesTex, -1, graphics);
			}
		}
		QuakeManager.flashBack = false;
	}

	private static void DrawTVClose(SpriteBatch sprite)
	{
		SpriteTools.BeginAlpha();
		sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.Black);
		float num = 5f - Game1.gameMap.psychoTVFrame;
		if (num < 0.2f)
		{
			sprite.Draw(Game1.spritesTex, new Vector2(640f, 360f), new Rectangle(448, 32, 128, 32), Color.White, 0f, new Vector2(64f, 16f), (0.2f - num) * 250f, SpriteEffects.None, 1f);
		}
		if (num < 0.1f)
		{
			sprite.Draw(Game1.nullTex, new Rectangle(0, (int)(num * 3580f), (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y - (int)(num * 3580f) * 2), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.9f, 1f)));
		}
		else if (num < 0.2f)
		{
			sprite.Draw(Game1.nullTex, new Rectangle((int)((num - 0.1f) * 6400f), 358, (int)ScrollManager.screenSize.X - (int)((num - 0.1f) * 6400f) * 2, 4), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.9f, 1f)));
			sprite.Draw(Game1.spritesTex, new Vector2(640f, 360f), new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.9f, 1f)), 0f, new Vector2(64f, 64f), (num - 0.1f) * 10f, SpriteEffects.None, 1f);
		}
		else if (num < 0.3f)
		{
			sprite.Draw(Game1.spritesTex, new Vector2(640f, 360f), new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, (0.3f - num) * 10f * Rand.GetRandomFloat(0.9f, 1f)), 0f, new Vector2(64f, 64f), 1f, SpriteEffects.None, 1f);
		}
		SpriteTools.End();
	}

	private static void DrawBossToast(GraphicsDeviceManager dev, SpriteBatch sprite, bool threedee)
	{
		if (threedee)
		{
			dev.GraphicsDevice.SetRenderTarget(Game1.threeDeeTarg[1]);
		}
		else
		{
			dev.GraphicsDevice.SetRenderTarget(null);
		}
		dev.GraphicsDevice.Clear(Color.Black);
		ToastRender.Draw(sprite);
	}

	public static void DrawAll(GraphicsDeviceManager dev, Character[] c, GameMap gameMap, SpriteBatch sprite, SpriteManager spriteMan, Texture2D spritesTex, int threedee, GraphicsDeviceManager graphics)
	{
		long ticks = DateTime.UtcNow.Ticks;
		if (Game1.gameMap.water)
		{
			dev.GraphicsDevice.SetRenderTarget(Game1.waterTarg);
			dev.GraphicsDevice.Clear(new Color(new Vector4(0f, 0.2f, 0f, 1f)));
			waterRender.Draw(sprite);
		}
		DebugManager.PerfSnap(0, DateTime.UtcNow.Ticks);
		if (fadingBackgroundMode != FadingBackgroundMode.None)
		{
			dev.GraphicsDevice.SetRenderTarget(Game1.mapBackTarg);
			dev.GraphicsDevice.Clear(Color.Black);
			DrawBack(sprite, gameMap, 0.25f);
		}
		else if (gameMap.bgRefractMode)
		{
			dev.GraphicsDevice.SetRenderTarget(Game1.bgRefractTarg);
			dev.GraphicsDevice.Clear(new Color(0f, 0f, 1f, 1f));
			gameMap.CurMap().drewBGRefract = false;
			gameMap.CurMap().Draw(sprite, 0, 2, green: true, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
		}
		threshRender.canDraw = true;
		if (threshRender.canDraw)
		{
			dev.GraphicsDevice.SetRenderTarget(Game1.threshTarg);
			dev.GraphicsDevice.Clear(new Color(new Vector4(0f, 0f, 0f, 1f)));
			SpriteTools.BeginAlpha();
			spriteMan.DrawThresh(sprite, spritesTex);
			SpriteTools.End();
		}
		if (Game1.gameMap.beadTheme != GameMap.BeadTheme.ThreeDee)
		{
			dev.GraphicsDevice.SetRenderTarget(Game1.mapTarg);
			dev.GraphicsDevice.Clear(new Color(new Vector4(0f, 0f, 1f, 1f)));
			gameMap.CurMap().Draw(sprite, 2, 3, green: true, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
			SpriteTools.BeginAdditive();
			spriteMan.DrawWallBlood(sprite, spritesTex);
			SpriteTools.End();
			DebugManager.PerfSnap(1, DateTime.UtcNow.Ticks);
			if (gameMap.psychoTVAlpha > 0f)
			{
				Game1.eightBitGame.DrawStatic(sprite, dev.GraphicsDevice, Game1.menuTarg);
			}
		}
		switch (threedee)
		{
		case -1:
			dev.GraphicsDevice.SetRenderTarget(Game1.mainTarg);
			break;
		case 0:
		case 1:
			dev.GraphicsDevice.SetRenderTarget(Game1.mainTarg);
			break;
		}
		dev.GraphicsDevice.Clear(Color.Black);
		fadingBackgroundMode = FadingBackgroundMode.None;
		switch (fadingBackgroundMode)
		{
		case FadingBackgroundMode.None:
			DrawBack(sprite, gameMap, 1f);
			break;
		case FadingBackgroundMode.BGOnly:
			fadeRender.Draw(sprite, Game1.mapBackTarg);
			gameMap.CurMap().Draw(sprite, 0, 2, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
			break;
		case FadingBackgroundMode.LowLevels:
			fadeRender.Draw(sprite, Game1.mapBackTarg);
			gameMap.CurMap().Draw(sprite, 1, 2, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
			break;
		default:
			fadeRender.Draw(sprite, Game1.mapBackTarg);
			break;
		}
		mapCompositor.hazeVal = 0f;
		if (Game1.gameMap.beadTheme == GameMap.BeadTheme.ThreeDee)
		{
			gameMap.CurMap().Draw(sprite, 2, 3, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
		}
		else
		{
			if ((Game1.gameMap.haze || gameMap.lichFreakoutMode) && (gameMap.haze || gameMap.lichFreakoutMode))
			{
				float num = 0.65f;
				if (gameMap.liftOn && gameMap.liftFrame > 5f)
				{
					num = ((!(gameMap.liftFrame > 30f)) ? (num * ((30f - gameMap.liftFrame) / 25f)) : 0f);
				}
				if (num > 0f)
				{
					mapCompositor.hazeVal = num;
				}
			}
			mapCompositor.Draw(Game1.mapTarg, sprite);
		}
		SpriteTools.BeginAlpha();
		spriteMan.DrawGibs(sprite, spritesTex, grounded: true);
		if (gameMap.psychoTVAlpha > 0f)
		{
			SpriteTools.End();
			Game1.eightBitGame.DrawStaticOverlay(sprite, Game1.menuTarg, gameMap.psychoTVAlpha);
			SpriteTools.BeginAlpha();
		}
		bool flag = false;
		for (int i = 0; i < 2; i++)
		{
			if (c[i].exists && c[i].charUpdate.magic > 0f)
			{
				c[i].charUpdate.magic += FMan.frameTime;
				if (!flag)
				{
					SpriteTools.End();
					SpriteTools.BeginAdditive();
					flag = true;
				}
				c[i].charRender.DrawMagic(c[i], c[i].charUpdate.magic, c[i].charUpdate.magicOut, sprite);
				if (c[i].charUpdate.magic > 0.9f && c[i].charUpdate.magicOut <= 0f)
				{
					float num2 = c[i].charUpdate.magic - 0.9f;
					QuakeManager.SetBurst(num2 * 2f, ScrollManager.GetScreenLoc(c[i].charUpdate.loc + new Vector2(0f, -50f) + Rand.GetRandomVec2(-200f, 200f, -100f, 100f) * num2 * 2f, 1f));
				}
			}
		}
		if (flag)
		{
			SpriteTools.End();
			SpriteTools.BeginAlpha();
		}
		for (int j = 0; j < c.Length; j++)
		{
			if (c[j].exists && c[j].charUpdate.thermop <= 0f)
			{
				c[j].CalculateShadows();
			}
		}
		for (int k = 0; k < c.Length; k++)
		{
			if (c[k].exists && c[k].charUpdate.thermop <= 0f)
			{
				c[k].DrawShadows(sprite);
			}
		}
		if (gameMap.engied)
		{
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, gameMap.engiedFrame));
		}
		if (QuakeManager.flashBack)
		{
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, 0.4f));
		}
		if (Game1.gameMap.goryoAlpha > 0f)
		{
			SpriteTools.End();
			SpriteTools.BeginAdditive();
			for (int l = 0; l < 2; l++)
			{
				if (!c[l].exists)
				{
					continue;
				}
				Vector2 loc = c[l].charUpdate.loc;
				bool flag2 = false;
				while (!flag2)
				{
					if (Game1.gameMap.CurMap().TestCol(loc, ceils: false, shadow: true))
					{
						loc.Y = Game1.gameMap.CurMap().GetMinY(loc);
						sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(loc, 1f), new Rectangle(320, 0, 128, 128), new Color(1f, 1f, 1f, 0.25f * Game1.gameMap.goryoAlpha), 0f, new Vector2(64f, 64f), ScrollManager.zoom * new Vector2(2f, 0.5f), SpriteEffects.None, 1f);
						break;
					}
					loc += new Vector2(0f, 16f);
					if (loc.Y > (float)Game1.gameMap.CurMap().ySize * 64f)
					{
						break;
					}
				}
			}
			SpriteTools.End();
			SpriteTools.BeginAlpha();
		}
		lock (c)
		{
			for (int m = 0; m < c.Length; m++)
			{
				if (c[m].exists && c[m].GetMeta().isGiant && c[m].charUpdate.thermop <= 0f)
				{
					c[m].Draw(sprite, grabberOnly: false);
				}
			}
			for (int n = 0; n < c.Length; n++)
			{
				if (c[n].exists && !c[n].GetMeta().isGiant)
				{
					if (c[n].charUpdate.thermop <= 0f)
					{
						c[n].Draw(sprite, grabberOnly: false);
					}
					else if (c[n].charUpdate.charGrab.grabbedByChar > -1)
					{
						c[n].Draw(sprite, grabberOnly: true);
					}
				}
			}
		}
		DebugManager.PerfSnap(2, DateTime.UtcNow.Ticks);
		SpriteTools.End();
		SpriteTools.BeginSubtractive();
		spriteMan.DrawSub(sprite, spritesTex);
		SpriteTools.End();
		SpriteTools.BeginAlpha();
		spriteMan.DrawGibs(sprite, spritesTex, grounded: false);
		spriteMan.Draw(sprite, spritesTex);
		DebugManager.PerfSnap(3, DateTime.UtcNow.Ticks);
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Asylum || Game1.gameMap.lichFreakoutMode)
		{
			for (int num3 = 0; num3 < 50; num3++)
			{
				Vector2 randomVec = Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, 0f, ScrollManager.screenSize.Y);
				float num4 = (randomVec - ScrollManager.screenSize / 2f).Length();
				sprite.Draw(spritesTex, randomVec, new Rectangle(384 + Rand.GetRandomInt(0, 6) * 64, 320, 64, 64), new Color(new Vector4(0f, 0f, 0f, Rand.GetRandomFloat(0f, num4 / 2000f))), Rand.GetRandomFloat(0f, 6.28f), new Vector2(32f, 32f), Rand.GetRandomFloat(0.2f, 1f), SpriteEffects.None, 1f);
			}
			for (int num5 = 0; num5 < 5; num5++)
			{
				sprite.Draw(spritesTex, Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, ScrollManager.screenSize.Y / 2f, ScrollManager.screenSize.Y / 2f), new Rectangle(160 + Rand.GetRandomInt(0, 32), Rand.GetRandomInt(0, 3) * 32, 32, 32), new Color(0f, 0f, 0f, Rand.GetRandomFloat(0f, 0.5f)), 1.57f, new Vector2(16f, 16f), new Vector2(100f, 0.1f), Rand.CointToss(0.5f) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
			}
		}
		sprite.End();
		threshRender.Draw(Game1.threshTarg, sprite);
		if (GameSettings.difficulty == 0)
		{
			bloodR = 1f;
			bloodG = 0.5f;
			bloodB = 0.7f;
		}
		else
		{
			bloodR = 0.3f;
			bloodG = 0f;
			bloodB = 0f;
			if (Game1.gameMap.goryoAlpha > 0f)
			{
				bloodR = 1f;
				bloodG = 1f;
				bloodB = 1f;
			}
			if (Game1.killManager.killVal > 0f)
			{
				bloodR += Game1.killManager.killVal * 0.1f;
			}
			if (Game1.gameMap.lichFreakoutMode)
			{
				bloodR = (bloodB = (bloodG = 0f));
			}
			if (Game1.gameMap.beadTheme == GameMap.BeadTheme.Contrast)
			{
				bloodR = 1f;
			}
			if (flibitPort.CurrentBlood == 1)
			{
				bloodR = (bloodG = (bloodB = 0f));
			}
		}
		SpriteTools.BeginAdditive();
		spriteMan.DrawAlpha(sprite, spritesTex);
		SpriteTools.End();
		DebugManager.PerfSnap(4, DateTime.UtcNow.Ticks);
		gameMap.CurMap().Draw(sprite, 3, 5, green: false, gameMap, Game1.nullTex, Game1.vGradTex, Game1.hGradTex, Game1.mapsTex, 1f);
		DebugManager.PerfSnap(5, DateTime.UtcNow.Ticks);
		SpriteTools.BeginAdditive();
		PostGlowMgr.Draw(sprite, spritesTex);
		if (gameMap.fog && threedee == -1)
		{
			fogRender.Draw(sprite);
		}
		SpriteTools.End();
		DebugManager.PerfSnap(6, DateTime.UtcNow.Ticks);
		SpriteTools.BeginAlpha();
		spriteMan.DrawAlphaCamsplats(sprite, threedee);
		if (Game1.killManager.bits > 0f)
		{
			for (int num6 = 0; num6 < 128; num6++)
			{
				float randomFloat = Rand.GetRandomFloat(0f, 6.28f);
				Vector2 position = ScrollManager.screenSize / 2f + new Vector2((float)Math.Cos(randomFloat) * ScrollManager.screenSize.X * 0.468f, (float)Math.Sin(randomFloat) * ScrollManager.screenSize.Y * 0.555f) * Rand.GetRandomFloat(0.8f, 1.5f);
				sprite.Draw(spritesTex, position, new Rectangle(128, 0, 128, 32), new Color(new Vector4(0f, 0f, 0f, 0.5f * Game1.killManager.bits)), randomFloat, new Vector2(64f, 16f), Rand.GetRandomFloat(0.5f, 2f), SpriteEffects.None, 1f);
			}
		}
		sprite.End();
		if (gameMap.invalidPhase == GameMap.InvalidPhase.Blackout)
		{
			DrawTVClose(sprite);
		}
		refractRender.Prepare(sprite, dev, threedee);
		bool flag3 = BurstRender.IsActive();
		if (feedbackMode)
		{
			feedbackIdx = (feedbackIdx + 1) % 2;
			dev.GraphicsDevice.SetRenderTarget(Game1.feedbackTarg[feedbackIdx]);
			dev.GraphicsDevice.Clear(new Color(0f, 0f, 0f, 1f));
			SpriteTools.BeginOpaque();
			SpriteTools.sprite.Draw(Game1.feedbackTarg[(feedbackIdx + 1) % 2], new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0.9f, 0.9f, 0.9f, 1f));
			SpriteTools.End();
			SpriteTools.BeginAdditive();
			SpriteTools.sprite.Draw(Game1.mainTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, 0.05f));
			SpriteTools.End();
		}
		switch (threedee)
		{
		case -1:
			dev.GraphicsDevice.SetRenderTarget(Game1.mapTarg);
			dev.GraphicsDevice.Clear(Color.Black);
			break;
		case 0:
		case 1:
			dev.GraphicsDevice.SetRenderTarget(Game1.mapTarg);
			break;
		}
		DebugManager.PerfSnap(7, DateTime.UtcNow.Ticks);
		Game1.gameMap.theme.UpdateColors();
		float num7 = 0f;
		if (Game1.transMgr.inFrame > 0f || Game1.transMgr.outFrame > 0f)
		{
			num7 = ((Game1.transMgr.inFrame > Game1.transMgr.outFrame) ? Game1.transMgr.inFrame : (1f - Game1.transMgr.outFrame));
			if ((Game1.netSession.IsHost() || Game1.netSession.IsClient()) && Game1.transMgr.inFrame > Game1.transMgr.outFrame)
			{
				num7 = Game1.transMgr.inFrame * 3f;
			}
		}
		try
		{
			filterRender.Draw(dev, Game1.refractTarg, Game1.mainTarg, sprite);
			if (feedbackMode)
			{
				SpriteTools.BeginAdditive();
				SpriteTools.sprite.Draw(Game1.feedbackTarg[feedbackIdx], new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, 0.5f));
				SpriteTools.End();
			}
		}
		catch
		{
		}
		DebugManager.PerfSnap(8, DateTime.UtcNow.Ticks);
		RenderTarget2D goalTarg = null;
		if (threedee > -1)
		{
			goalTarg = ((!flag3) ? Game1.threeDeeTarg[threedee] : Game1.auxTarg);
		}
		else if (flag3)
		{
			goalTarg = Game1.auxTarg;
		}
		switch (Game1.gameMap.beadTheme)
		{
		case GameMap.BeadTheme.Contrast:
		case GameMap.BeadTheme.Zune:
		case GameMap.BeadTheme.ThreeDee:
			bloomComponent.Draw(goalTarg, Game1.mapTarg);
			break;
		default:
			bloomComponent.Draw(goalTarg, Game1.mapTarg);
			break;
		}
		if (gameMap.water)
		{
			float y = ScrollManager.GetScreenLoc(new Vector2(0f, gameMap.waterLev), 1f).Y;
			if (gameMap.theme.theme == Themes.ThemeType.Dish)
			{
				SpriteTools.BeginAlpha();
				sprite.Draw(Game1.hGradTex, new Rectangle(0, (int)y - 64, (int)ScrollManager.screenSize.X, 64), Color.White);
				sprite.Draw(Game1.hGradTex, new Rectangle(0, (int)y, (int)ScrollManager.screenSize.X, 64), new Rectangle(0, 0, 4, 32), Color.White, 0f, default, SpriteEffects.FlipVertically, 1f);
				sprite.Draw(Game1.nullTex, new Rectangle(0, (int)y, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y - (int)y), new Color(0f, 0f, 0f, 0.5f));
				SpriteTools.End();
			}
			else
			{
				SpriteTools.BeginAlpha();
				sprite.Draw(Game1.hGradTex, new Rectangle(0, (int)y - 64, (int)ScrollManager.screenSize.X, 64), Color.White);
				sprite.Draw(Game1.hGradTex, new Rectangle(0, (int)y, (int)ScrollManager.screenSize.X, 64), new Rectangle(0, 0, 4, 32), Color.White, 0f, default, SpriteEffects.FlipVertically, 1f);
				SpriteTools.End();
				waterRender.DrawGlowlets(sprite);
			}
		}
		if (Game1.transMgr.levelInFrame > 0f && Game1.transMgr.levelInFrame > num7)
		{
			num7 = Game1.transMgr.levelInFrame;
		}
		if (Game1.transMgr.pauseResumeFrame > 0f && Game1.transMgr.pauseResumeFrame > num7)
		{
			num7 = Game1.transMgr.pauseResumeFrame;
		}
		if (flag3)
		{
			switch (threedee)
			{
			case -1:
				dev.GraphicsDevice.SetRenderTarget(null);
				dev.GraphicsDevice.Clear(Color.Black);
				BurstRender.Draw(sprite, Game1.auxTarg);
				break;
			case 0:
			case 1:
				dev.GraphicsDevice.SetRenderTarget(Game1.threeDeeTarg[threedee]);
				dev.GraphicsDevice.Clear(Color.Black);
				BurstRender.Draw(sprite, Game1.auxTarg);
				break;
			}
		}
		if (!(MainPlayer.uberDyingFrame > 1f))
		{
			SpriteTools.BeginAlpha();
			Game1.hud.Draw(sprite, threedee);
			SpriteTools.End();
		}
		if (num7 > 0f)
		{
			SpriteTools.BeginAlpha();
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(new Vector4(0f, 0f, 0f, num7)));
			SpriteTools.End();
		}
		DebugManager.PerfSnap(9, DateTime.UtcNow.Ticks);
		DebugManager.PerfFinish(ticks);
		DrawOverlay(sprite, graphics, threedee);
	}

	internal static void DrawOverlay(SpriteBatch spriteBatch, GraphicsDeviceManager graphics, int threedee)
	{
		if (Game1.sceneMgr.playing && Game1.sceneMgr.reading)
		{
			Game1.sceneMgr.DrawLoader(spriteBatch);
		}
		if (MainPlayer.uberDyingFrame > 1f)
		{
			Game1.menuMgr.Draw(graphics, spriteBatch);
		}
		if (Game1.hud.IsEndLevel())
		{
			Game1.hud.DrawEndLevel(spriteBatch, threedee);
		}
		if (Game1.hud.arcadeIn.active)
		{
			Game1.hud.DrawArcadeIn(spriteBatch, threedee);
		}
		if (Game1.soloMgr.active)
		{
			Game1.soloMgr.Draw(spriteBatch, threedee);
		}
		if (Game1.sceneMgr.playing && Game1.sceneMgr.overlay)
		{
			Game1.sceneMgr.DrawOverlay(spriteBatch, threedee);
		}
	}
}
