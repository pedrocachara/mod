using director;
using Microsoft.Xna.Framework;

namespace Yuki_Win.gameRender;

internal class GlowLet
{
	public Vector2 loc;

	public float frame;

	public GlowLet()
	{
		loc = Rand.GetRandomVec2(-100f, ScrollManager.screenSize.X + 100f, 0f, 300f);
		frame = Rand.GetRandomFloat(0f, 6.28f);
	}
}
