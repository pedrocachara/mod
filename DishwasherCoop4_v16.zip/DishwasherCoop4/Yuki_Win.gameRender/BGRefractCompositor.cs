using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender;

internal class BGRefractCompositor
{
	private Effect bgRefractEffect;

	private EffectPass pass;

	public BGRefractCompositor(ContentManager Content)
	{
		bgRefractEffect = Content.Load<Effect>("fx/bgrefract");
	}

	internal void Draw(RenderTarget2D mapTarg, SpriteBatch sprite)
	{
		bgRefractEffect.Parameters["wid"].SetValue(0.04f * ScrollManager.zoom);
		SpriteTools.BeginAlpha(bgRefractEffect);
		sprite.Draw(mapTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
		SpriteTools.End();
	}
}
