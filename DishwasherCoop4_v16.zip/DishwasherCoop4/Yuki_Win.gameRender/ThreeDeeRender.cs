using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender;

internal class ThreeDeeRender
{
	private Effect threeDeeEffect;

	private EffectPass pass;

	public ThreeDeeRender(ContentManager Content)
	{
		threeDeeEffect = Content.Load<Effect>("fx/threedee");
	}

	internal void Draw(GraphicsDeviceManager dev, RenderTarget2D targ1, RenderTarget2D targ2, SpriteBatch sprite)
	{
		dev.GraphicsDevice.Textures[1] = targ2;
		SpriteTools.BeginAdditive(threeDeeEffect);
		sprite.Draw(targ1, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
		SpriteTools.End();
		dev.GraphicsDevice.Textures[1] = null;
	}
}
