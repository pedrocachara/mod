using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender;

internal class FadeRender
{
	private Effect fadeEffect;

	private EffectPass pass;

	private Texture2D drawTex;

	public bool readyToDraw;

	public FadeRender(ContentManager Content)
	{
		fadeEffect = Content.Load<Effect>("fx/fade");
	}

	public void Draw(SpriteBatch sprite, RenderTarget2D backTarg)
	{
		if (!readyToDraw)
		{
			drawTex = backTarg;
			readyToDraw = true;
		}
		fadeEffect.Parameters["v"].SetValue((GameRender.fadingBackgroundMode == GameRender.FadingBackgroundMode.MidLevelsHeavy) ? 0.01f : 0.01f);
		fadeEffect.Parameters["contrast"].SetValue(GameRender.fadingBackgroundContrast);
		fadeEffect.Parameters["brite"].SetValue(GameRender.fadingBackgroundBrite);
		SpriteTools.BeginAlpha(fadeEffect);
		sprite.Draw(drawTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 0f, 0f, 1f));
		SpriteTools.End();
	}
}
