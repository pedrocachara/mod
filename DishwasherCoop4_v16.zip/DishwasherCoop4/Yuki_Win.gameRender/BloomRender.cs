using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.maps;
using Yuki_Win.player;

namespace Yuki_Win.gameRender;

internal class BloomRender
{
	private Effect bloomEffect;

	private EffectPass pass;

	public bool canDrawFeedback;

	public float val;

	public float alpha;

	public float sat = 0.25f;

	private Texture2D drawTex;

	public bool readyToDraw;

	public BloomRender(ContentManager Content)
	{
		bloomEffect = Content.Load<Effect>("fx/bloom");
	}

	internal void Draw(RenderTarget2D feedbackTarg, SpriteBatch sprite)
	{
		if ((!(Game1.gameMap.CrazyTransitionInFrame > 0f) || !(Game1.gameMap.CrazyTransitionInFrame < 1f)) && !(Game1.gameMap.CrazyTransitionOutFrame > 0f) && (Game1.gameMap.theme.theme != Themes.ThemeType.Asylum || GameSettings.difficulty == 0) && !(MainPlayer.uberDyingFrame > 1f) && Game1.gameMap.theme.theme != Themes.ThemeType.Church)
		{
			_ = GameRender.filterRender.newVersion;
		}
		if (!readyToDraw)
		{
			drawTex = feedbackTarg;
			readyToDraw = true;
		}
		bloomEffect.Parameters["v"].SetValue(val);
		Rectangle destinationRectangle = new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		bloomEffect.Parameters["a"].SetValue(alpha);
		sat = 0f;
		bloomEffect.Parameters["sat"].SetValue(sat);
		bloomEffect.Parameters["r"].SetValue(value: false);
		if (Game1.gameMap.water)
		{
			Vector2 screenLoc = ScrollManager.GetScreenLoc(new Vector2(0f, Game1.gameMap.waterLev), 1f);
			screenLoc.Y -= 70f;
			bloomEffect.Parameters["waterLev"].SetValue(screenLoc.Y / ScrollManager.screenSize.Y);
		}
		else
		{
			bloomEffect.Parameters["waterLev"].SetValue(0f);
		}
		SpriteTools.BeginAdditive(bloomEffect);
		sprite.Draw(drawTex, destinationRectangle, new Color(1f, 0.15f, 0.7f, 0.3f));
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Asylum)
		{
			for (int i = 1; i < 4; i++)
			{
				sprite.Draw(drawTex, new Rectangle(-32 * i, -16 * i, (int)ScrollManager.screenSize.X + 72 * i, (int)ScrollManager.screenSize.Y + 32 * i), new Color(new Vector4(1f, 1f, 1f, 0.3f)));
			}
			if (Rand.CointToss(0.1f))
			{
				int randomInt = Rand.GetRandomInt(1, 6);
				for (int j = 0; j < randomInt; j++)
				{
					sprite.Draw(drawTex, new Rectangle(-32 * j, -16 * j, (int)ScrollManager.screenSize.X + 72 * j, (int)ScrollManager.screenSize.Y + 32 * j), new Color(new Vector4(1f, 1f, 1f, 0.3f)));
				}
			}
		}
		else
		{
			float num = 0f;
			if (Game1.gameMap.CrazyTransitionInFrame > 0f && Game1.gameMap.CrazyTransitionInFrame < 1f)
			{
				num = 1f - Game1.gameMap.CrazyTransitionInFrame;
			}
			if (Game1.gameMap.CrazyTransitionOutFrame > 0f)
			{
				num = Game1.gameMap.CrazyTransitionOutFrame;
			}
			if (num > 0f)
			{
				int randomInt2 = Rand.GetRandomInt(1, (int)(6f * num));
				for (int k = 0; k < randomInt2; k++)
				{
					sprite.Draw(drawTex, new Rectangle(-32 * k + Rand.GetRandomInt(-10, 10), -16 * k + Rand.GetRandomInt(-10, 10), (int)ScrollManager.screenSize.X + 72 * k, (int)ScrollManager.screenSize.Y + 32 * k), new Color(new Vector4(1f, 1f, 1f, 0.3f)));
				}
			}
		}
		SpriteTools.End();
		if (MainPlayer.uberDyingFrame > 1f)
		{
			bloomEffect.Parameters["v"].SetValue(0.007f);
			float num2 = MainPlayer.uberDyingFrame - 1f;
			if (num2 > 0.9f)
			{
				num2 = 0.9f;
			}
			bloomEffect.Parameters["a"].SetValue(num2);
			bloomEffect.Parameters["r"].SetValue(value: true);
			bloomEffect.Parameters["waterLev"].SetValue(0f);
			SpriteTools.BeginAlpha(bloomEffect);
			sprite.Draw(drawTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 0f, 0f, 1f));
			SpriteTools.End();
		}
	}
}
