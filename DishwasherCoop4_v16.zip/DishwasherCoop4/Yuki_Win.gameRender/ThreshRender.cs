using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.maps;
using Yuki_Win.player;

namespace Yuki_Win.gameRender;

internal class ThreshRender
{
	private Effect threshEffect;

	private Effect rainbowThreshEffect;

	private EffectPass pass;

	public Vector2 tL = default;

	public Vector2 bR = default;

	public bool canDraw;

	private Texture2D drawTex;

	public bool readyToDraw;

	public void AddPoint(Vector2 point, float wid)
	{
		wid *= 4f;
		if (!canDraw)
		{
			tL.X = point.X - wid;
			tL.Y = point.Y - wid;
			bR.X = point.X + wid;
			bR.Y = point.Y + wid;
			canDraw = true;
			return;
		}
		if (point.X - wid < tL.X)
		{
			tL.X = point.X - wid;
		}
		if (point.Y - wid < tL.Y)
		{
			tL.Y = point.Y - wid;
		}
		if (point.X + wid > bR.X)
		{
			bR.X = point.X + wid;
		}
		if (point.Y + wid > bR.Y)
		{
			bR.Y = point.Y + wid;
		}
	}

	public ThreshRender(ContentManager Content)
	{
		threshEffect = Content.Load<Effect>("fx/thresh");
		rainbowThreshEffect = Content.Load<Effect>("fx/rainbowthresh");
	}

	internal void Draw(RenderTarget2D threshTarg, SpriteBatch sprite)
	{
		float num = 0f;
		canDraw = false;
		if (!readyToDraw)
		{
			drawTex = threshTarg;
			readyToDraw = true;
		}
		if (tL.X < 0f)
		{
			tL.X = 0f;
		}
		if (tL.Y < 0f)
		{
			tL.Y = 0f;
		}
		if (bR.X > ScrollManager.screenSize.X)
		{
			bR.X = ScrollManager.screenSize.X;
		}
		if (bR.Y > ScrollManager.screenSize.Y)
		{
			bR.Y = ScrollManager.screenSize.Y;
		}
		if (GameSettings.difficulty == 0)
		{
			GameRender.bloodR = 1f;
			GameRender.bloodG = 0.5f;
			GameRender.bloodB = 0.7f;
		}
		else
		{
			GameRender.bloodR = 0.4f;
			GameRender.bloodG = 0f;
			GameRender.bloodB = 0f;
			if (Game1.killManager.killVal > 0f)
			{
				num += Game1.killManager.killVal * 0.1f;
				GameRender.bloodR += Game1.killManager.killVal * 0.1f;
			}
			if (Game1.gameMap.lichFreakoutMode)
			{
				GameRender.bloodR = (GameRender.bloodB = (GameRender.bloodG = 0f));
			}
			if (Game1.gameMap.beadTheme == GameMap.BeadTheme.Contrast)
			{
				GameRender.bloodR = 1f;
				num += 0.5f;
			}
		}
		if (GameSettings.difficulty == 0)
		{
			SpriteTools.BeginAlpha(rainbowThreshEffect);
			sprite.Draw(drawTex, tL * 4f, new Rectangle((int)tL.X, (int)tL.Y, (int)(bR.X - tL.X), (int)(bR.Y - tL.Y)), Color.White, 0f, default, 4f, SpriteEffects.None, 1f);
			SpriteTools.End();
			return;
		}
		threshEffect.Parameters["bloodr"].SetValue(GameRender.bloodR * 0.5f);
		threshEffect.Parameters["bloodbump"].SetValue(num);
		threshEffect.Parameters["bloodg"].SetValue(GameRender.bloodG);
		threshEffect.Parameters["bloodb"].SetValue(GameRender.bloodB);
		threshEffect.Parameters["whiter"].SetValue(1f);
		threshEffect.Parameters["whiteg"].SetValue(0.9f);
		threshEffect.Parameters["whiteb"].SetValue(1f);
		SpriteTools.BeginAlpha(threshEffect);
		sprite.Draw(drawTex, new Vector2((int)tL.X, (int)tL.Y), new Rectangle((int)tL.X, (int)tL.Y, (int)(bR.X - tL.X), (int)(bR.Y - tL.Y)), Color.White, 0f, default, 1f, SpriteEffects.None, 1f);
		SpriteTools.End();
	}
}
