using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.director;

namespace Yuki_Win.gameRender;

public class BurstRender
{
	private const int BURST_NORMAL = 0;

	private const int BURST_KILL = 1;

	public static Effect[] burstEffect;

	private static EffectPass pass;

	public static bool IsActive()
	{
		return QuakeManager.burst > 0f;
	}

	public static void Initialize(ContentManager Content)
	{
		burstEffect = new Effect[2]
		{
			Content.Load<Effect>("fx/burst"),
			Content.Load<Effect>("fx/killburst")
		};
	}

	public static void Draw(SpriteBatch sprite, Texture2D drawTex)
	{
		float burst = QuakeManager.burst;
		burst *= 0.8f;
		if (Game1.camMgr.twoPlayers)
		{
			burst *= 0.4f;
		}
		int num = (Game1.hud.WaveDefeated() ? 1 : 0);
		burstEffect[num].Parameters["val"].SetValue(burst);
		burstEffect[num].Parameters["centerX"].SetValue(QuakeManager.burstVec.X);
		burstEffect[num].Parameters["centerY"].SetValue(QuakeManager.burstVec.Y);
		SpriteTools.BeginAlpha(burstEffect[num]);
		sprite.Draw(drawTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
		SpriteTools.End();
	}
}
