using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender;

public class ToastRender
{
	public static Effect toastEffect;

	public static EffectPass pass;

	public static void Initialize(ContentManager Content)
	{
		toastEffect = Content.Load<Effect>("fx/toast");
	}

	public static void Draw(SpriteBatch sprite)
	{
		toastEffect.Parameters["burn"].SetValue(Rand.GetRandomFloat(1.7f, 1.9f));
		float num = 0f;
		float frame = Game1.camMgr.bossToast.frame;
		if (Game1.camMgr.bossToast.frame < 1f)
		{
			num = (1f - Game1.camMgr.bossToast.frame) * 2f;
		}
		num += 0.1f;
		if (frame > 4f)
		{
			num += Rand.GetRandomFloat(0f, (frame - 4f) * 0.25f);
		}
		if (frame > 4.75f)
		{
			num += (frame - 4.75f) * 5f;
		}
		toastEffect.Parameters["brite"].SetValue(num);
		SpriteTools.BeginOpaque(toastEffect);
		float num2 = (Rand.CointToss(0.01f) ? Rand.GetRandomInt(0, 20) : 0);
		float randomFloat = Rand.GetRandomFloat(0.9f, 1f);
		sprite.Draw(Game1.threeDeeTarg[0], ScrollManager.screenSize / 2f + new Vector2(0f, 0f - num2), new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f * randomFloat, 0.99f * randomFloat, 0.9f * randomFloat, 1f), (Game1.camMgr.bossToast.frame - 0.1f) * 0.02f, ScrollManager.screenSize / 2f, 1.1f + Game1.camMgr.bossToast.frame * 0.05f, SpriteEffects.None, 1f);
		SpriteTools.End();
		Text.DrawBlockyTwoLines(sprite, new Vector2(ScrollManager.screenSize.X - 880f, ScrollManager.screenSize.Y - 400f - num2), 700f, Game1.camMgr.bossToast.s1, Game1.camMgr.bossToast.s2, 1f);
		SpriteTools.BeginAlpha();
		for (int i = 0; i < 32; i++)
		{
			sprite.Draw(Game1.spritesTex, Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, 0f, ScrollManager.screenSize.Y), new Rectangle(384 + Rand.GetRandomInt(0, 6) * 64, 320, 64, 64), new Color(0f, 0f, 0f, Rand.GetRandomFloat(0f, 0.15f)), Rand.GetRandomFloat(0f, 6.28f), new Vector2(32f, 32f), Rand.GetRandomFloat(0f, 1f), SpriteEffects.None, 1f);
			sprite.Draw(Game1.spritesTex, Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, ScrollManager.screenSize.Y / 2f, ScrollManager.screenSize.Y / 2f), new Rectangle(128, Rand.GetRandomInt(0, 3) * 32, 128, 32), new Color(0f, 0f, 0f, Rand.GetRandomFloat(0f, 0.45f)), 1.57f, new Vector2(62f, 16f), new Vector2(8f, 0.2f), SpriteEffects.None, 1f);
		}
		sprite.End();
	}
}
