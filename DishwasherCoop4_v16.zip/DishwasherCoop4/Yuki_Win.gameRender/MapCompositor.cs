using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.maps;

namespace Yuki_Win.gameRender;

internal class MapCompositor
{
	private Effect mapEffect;

	private EffectPass pass;

	private Texture2D drawTex;

	public bool readyToDraw;

	public float hazeVal;

	public MapCompositor(ContentManager Content)
	{
		mapEffect = Content.Load<Effect>("fx/map");
	}

	internal void Draw(RenderTarget2D mapTarg, SpriteBatch sprite)
	{
		if (!readyToDraw)
		{
			drawTex = mapTarg;
		}
		Vector4 vector = Game1.gameMap.CurMap().layer[2].color.ToVector4();
		mapEffect.Parameters["r"].SetValue(vector.X);
		mapEffect.Parameters["g"].SetValue(vector.Y);
		mapEffect.Parameters["b"].SetValue(vector.Z);
		mapEffect.Parameters["haze"].SetValue(hazeVal);
		float num = 0.4f;
		if (Game1.killManager.killVal > 0f)
		{
			num += Game1.killManager.killVal * 0.1f;
			if (num > 1f)
			{
				num = 1f;
			}
		}
		if (Game1.gameMap.beadTheme == GameMap.BeadTheme.Contrast)
		{
			num = 0f;
		}
		if (flibitPort.CurrentBlood == 1)
		{
			num = 1f;
		}
		mapEffect.Parameters["bR"].SetValue(num);
		mapEffect.Parameters["bG"].SetValue(1f);
		mapEffect.Parameters["bB"].SetValue(1f);
		SpriteTools.BeginAlpha(mapEffect);
		sprite.Draw(drawTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
		SpriteTools.End();
	}
}
