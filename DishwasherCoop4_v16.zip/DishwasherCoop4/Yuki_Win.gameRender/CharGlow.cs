using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender;

public class CharGlow
{
	private float r;

	private float g;

	private float b;

	private float size;

	private Vector2 loc;

	public void Draw(SpriteBatch sprite)
	{
		sprite.Draw(Game1.spritesTex, loc, new Rectangle(320, 0, 128, 128), new Color(r, g, b, 1f), 0f, new Vector2(64f, 64f), size, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, loc, new Rectangle(320, 0, 128, 128), new Color(r, g, b, 0.4f), 0f, new Vector2(64f, 64f), new Vector2(1f, 0.005f) * size * 10f, SpriteEffects.None, 1f);
	}

	public void Init(Vector2 loc, float r, float g, float b, float size)
	{
		this.loc = loc;
		this.r = r;
		this.g = g;
		this.b = b;
		this.size = size * 15f;
	}
}
