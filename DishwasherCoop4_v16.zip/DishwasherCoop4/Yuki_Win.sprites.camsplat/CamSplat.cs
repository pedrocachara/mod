using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;

namespace Yuki_Win.sprites.camsplat;

public class CamSplat
{
	public enum CamSplatType
	{
		Blood,
		Water,
		Dust
	}

	public Vector2 loc;

	public int idx;

	public float r;

	public float frame;

	public bool exists;

	public float size;

	public CamSplatType type;

	public bool refract;

	public void Init(Vector2 loc, CamSplatType type)
	{
		this.loc = loc;
		idx = Rand.GetRandomInt(0, 6);
		r = Rand.GetRandomFloat(0f, 6.28f);
		frame = 0f - Rand.GetRandomFloat(0f, 0.5f);
		exists = true;
		size = Rand.GetRandomFloat(2f, 4f);
		this.type = type;
		switch (type)
		{
		case CamSplatType.Dust:
			refract = false;
			break;
		case CamSplatType.Water:
			size = 1f;
			refract = true;
			break;
		default:
			refract = true;
			break;
		}
	}

	public void Update()
	{
		float num = frame;
		frame += FMan.frameTime;
		if (num < 0f && frame >= 0f)
		{
			if (Game1.gameMap.goresploded <= 0f && type == CamSplatType.Blood)
			{
				Sound.PlaySnd(Sound.Category.FX, "splat");
			}
			if (type != CamSplatType.Water)
			{
				ScrollManager.scroll += Rand.GetRandomVec2(-10f, 10f, -10f, 10f);
			}
		}
		if (frame > 0.3f && frame < 4f)
		{
			frame = 4f;
		}
		if (frame > 5f)
		{
			exists = false;
		}
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		if (frame < 0f)
		{
			return;
		}
		float num = 1f;
		if (frame > 4f)
		{
			num = 5f - frame;
		}
		float num2 = size;
		if (frame < 0.2f)
		{
			num2 = size * (frame * 5f);
		}
		float num3 = (ScrollManager.screenSize / 2f - loc).LengthSquared();
		if (num3 < 90000f)
		{
			num *= num3 / 90000f;
		}
		Vector2 vector = default;
		if (threedee == 0)
		{
			vector.X = 8f;
		}
		if (threedee == 1)
		{
			vector.X = -8f;
		}
		switch (type)
		{
		case CamSplatType.Dust:
			sprite.Draw(Game1.spritesTex, loc + vector, new Rectangle(256 + 64 * (idx % 4), 128, 64, 64), new Color(0f, 0f, 0f, num * 0.25f), r, new Vector2(32f, 32f), num2 + 1f, SpriteEffects.None, 1f);
			break;
		case CamSplatType.Water:
		{
			if (Game1.gameMap.water)
			{
				float waterLev = Game1.gameMap.waterLev;
				waterLev = ScrollManager.GetScreenLoc(new Vector2(0f, waterLev), 1f).Y;
				if (loc.Y > waterLev)
				{
					exists = false;
				}
			}
			float num5 = num * 0.5f;
			if (num5 > 0.35f)
			{
				num5 = 0.35f;
			}
			sprite.Draw(Game1.spritesTex, loc + vector, new Rectangle(320, 0, 128, 128), new Color(0f, 1f, 0f, num5), r, new Vector2(64f, 64f), num2 * 0.25f, SpriteEffects.None, 1f);
			break;
		}
		case CamSplatType.Blood:
		{
			float g = 0.75f;
			if (Game1.gameMap.water)
			{
				g = 0f;
			}
			sprite.Draw(Game1.spritesTex, loc + vector, new Rectangle(384 + 64 * idx, 320, 64, 64), new Color(1f, g, 0f, num * 0.5f), r, new Vector2(32f, 32f), num2, SpriteEffects.None, 1f);
			float num4 = frame - 0.2f;
			if (num4 > 1.8f)
			{
				num4 = 1.8f;
			}
			if (num4 > 0f)
			{
				sprite.Draw(Game1.spritesTex, loc + vector, new Rectangle(448 + 32 * (idx % 4), 192, 32, 32), new Color(1f, g, 0f, num * 0.5f), 0f, new Vector2(16f, 0f), new Vector2(num2, num4 * num2) * 2f, SpriteEffects.None, 1f);
			}
			break;
		}
		}
	}
}
