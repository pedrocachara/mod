using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.zaps;

public class ZapBallSrc : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.frame = 0.1f;
		p.loc = loc;
		p.traj = traj;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.flags = Rand.GetRandomInt(0, 3);
		p.rDir = Rand.GetRandomFloat(-4f, 4f);
		p.g = Rand.GetRandomFloat(0.5f, 1f);
		p.alpha = true;
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = (0.1f - p.frame) * 100f;
		if (num > 1f)
		{
			num = 1f;
		}
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(896, p.flags * 128, 128, 128), new Color(0.5f, p.g, 1f, p.frame * 8f * num), p.rotation, new Vector2(64f, 16f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
		base.Draw(p, sprite, spritesTex);
	}
}
