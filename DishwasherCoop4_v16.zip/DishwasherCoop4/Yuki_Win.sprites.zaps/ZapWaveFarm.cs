using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.zaps;

public class ZapWaveFarm : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.traj.Y = 0f;
		p.owner = owner;
		p.alpha = false;
		p.frame = 2f;
		p.hitter = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		base.Update(p, spriteMan);
		if ((int)(p.frame * 60f) != (int)(frame * 60f))
		{
			spriteMan.AddSprite(84, p.loc, p.traj * 0.15f, Rand.GetRandomFloat(0.7f, 1.5f), 0, 0);
			spriteMan.AddRefractSprite(85, p.loc + Rand.GetRandomVec2(-20f, 20f, -200f, -20f), Rand.GetRandomVec2(-50f, 50f, -200f, 50f), Rand.GetRandomFloat(3f, 4f), 0, 0);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
	}
}
