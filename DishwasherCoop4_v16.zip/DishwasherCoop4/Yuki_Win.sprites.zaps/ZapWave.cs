using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.zaps;

public class ZapWave : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = -traj;
		p.owner = owner;
		p.alpha = true;
		p.frame = 0.25f;
		if (traj.X < 0f)
		{
			p.rotation = -0.5f;
		}
		else
		{
			p.rotation = 0.5f;
		}
		p.rotation -= 1.57f;
		p.rotation += Rand.GetRandomFloat(-0.15f, 0.15f);
		p.flags = Rand.GetRandomInt(0, 4);
		p.g = Rand.GetRandomFloat(0.5f, 1f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		base.Update(p, spriteMan);
		if (p.flags == 0)
		{
			p.frame = frame - FMan.frameTime / 4f;
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = (0.25f - p.frame) * 40f;
		if (num > 15f)
		{
			num = 15f;
		}
		float y = (1f - p.frame) * 2f;
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(p.flags * 128 + 512, 960, 128, 64), new Color(0.6f, p.g, 1f, p.frame * 3f), p.rotation, new Vector2(10f, 32f), ScrollManager.cannedDepth[0] * new Vector2(num, y), SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(320, 0, 128, 128), new Color(0.6f, p.g, 1f, p.frame * 1f), 0f, new Vector2(10f, 32f), ScrollManager.cannedDepth[0] * new Vector2(2f, 0.5f), SpriteEffects.None, 1f);
		base.Draw(p, sprite, spritesTex);
	}
}
