using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.director;

namespace Yuki_Win.sprites.zaps;

public class ZapBall : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.traj.Y = 0f;
		p.owner = owner;
		p.alpha = false;
		p.frame = 3f;
		p.hitter = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		base.Update(p, spriteMan);
		if ((int)(p.frame * 60f) != (int)(frame * 60f))
		{
			for (int i = 0; i < 3; i++)
			{
				spriteMan.AddSprite(81, p.loc, p.traj * 0.15f, Rand.GetRandomFloat(0.7f, 1.5f), 0, 0);
			}
			spriteMan.AddRefractSprite(69, p.loc, p.traj, 4f, 0, 0);
		}
		if (p.frame > 0.5f)
		{
			QuakeManager.SetQuake(0.2f);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(320, 0, 128, 128), new Color(0f, 0f, 0f, p.frame * 2f), 0f, new Vector2(64f, 64f), ScrollManager.cannedDepth[0] * 1.5f, SpriteEffects.None, 1f);
		base.Draw(p, sprite, spritesTex);
	}
}
