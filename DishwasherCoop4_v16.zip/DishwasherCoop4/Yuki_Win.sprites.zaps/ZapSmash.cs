using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.director;

namespace Yuki_Win.sprites.zaps;

public class ZapSmash : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = default;
		p.alpha = true;
		p.owner = owner;
		p.frame = 0.3f;
		p.flags = Rand.GetRandomInt(-2, 3);
		p.hitter = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.frame < 0.2f)
		{
			p.hitter = false;
		}
		QuakeManager.SetBright(0.5f);
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 vector = new Vector2((float)p.flags * (0.3f - p.frame) * 300f, 0f);
		Vector2 vector2 = p.loc + Rand.GetRandomVec2(-50f, 50f, 0f, 0f) + vector;
		Vector2 vector3 = vector2;
		for (int i = 1; i < 16; i++)
		{
			vector2 = p.loc - new Vector2(0f, (float)i * 50f) + Rand.GetRandomVec2(-40f, 40f, -40f, 40f) + vector;
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc((vector2 + vector3) / 2f, 1f), new Rectangle(448, 32, 128, 32), new Color(0.5f, 0.5f, 1f, p.frame * 6f), Trig.GetAngle(vector2, vector3), new Vector2(64f, 16f), new Vector2(Trig.GetDist(vector2, vector3) / 100f, 1f + (0.3f - p.frame) * 5f) * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
			vector3 = vector2;
		}
		float num = p.frame;
		if (num > 0.125f)
		{
			num = 0.125f;
		}
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(320, 0, 128, 128), new Color(0.5f, 0.5f, 1f, num), 0f, new Vector2(64f, 64f), new Vector2(5f, 1f), SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(320, 0, 128, 128), new Color(0.5f, 0.5f, 1f, num), 0f, new Vector2(64f, 64f), new Vector2(5f, 1f), SpriteEffects.None, 1f);
	}
}
