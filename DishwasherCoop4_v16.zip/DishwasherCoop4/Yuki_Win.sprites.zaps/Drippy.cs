using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.zaps;

public class Drippy : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.frame = 0.2f;
		p.loc = loc;
		p.traj = traj;
		p.flags = Rand.GetRandomInt(0, 3);
		p.g = Rand.GetRandomFloat(0.5f, 1f);
		p.alpha = true;
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.traj.Y += FMan.frameTime * 500f;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(128, p.flags * 32, 128, 32), new Color(1f, 1f, 1f, p.frame * 4f), 1.57f, new Vector2(64f, 16f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
		base.Draw(p, sprite, spritesTex);
	}
}
