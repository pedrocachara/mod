using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.zaps;

public class ZapSrc : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.frame = 0.2f;
		p.loc = loc;
		p.traj = traj;
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.flags = Rand.GetRandomInt(0, 3);
		p.g = Rand.GetRandomFloat(0.5f, 1f);
		p.alpha = true;
		p.size = size;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(896, p.flags * 128, 128, 128), new Color(0.5f, p.g, 1f, p.frame * 4f), p.rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
		base.Draw(p, sprite, spritesTex);
	}
}
