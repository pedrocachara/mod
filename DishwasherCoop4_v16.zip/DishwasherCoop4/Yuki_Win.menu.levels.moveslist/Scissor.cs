using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Scissor : MovesListBase
{
	public Scissor()
	{
		weapon = YukiText.theGuillotine;
		name = InvCatalog.InvItemName.TheGuillotine;
		move = new Move[16]
		{
			new Move(YukiText.scissor_reignOfTerror, "[x] [x] [x] [x]"),
			new Move(YukiText.scissor_laRevolution, "[x] [x] [x] [d][x]"),
			new Move(YukiText.scissor_bastille, "[x] [y]"),
			new Move(YukiText.scissor_straightRazor, "[y]"),
			new Move(YukiText.scissor_ciseux, "[u][y]"),
			new Move(YukiText.scissor_cutCut, "[u][y] [x] [y] [x] [y]..."),
			new Move(YukiText.scissor_voiesDeFait, "[x] [x] [x] [y] [x] [y] [x] [y]..."),
			new Move(YukiText.scissor_skymower, "[x] [x] [x]"),
			new Move(YukiText.scissor_deathSpike, "[y]"),
			new Move(YukiText.scissor_deathSquare, "[y] " + YukiText.movesListTapYOnLanding),
			new Move(YukiText.scissor_rollingSpike, "[x]"),
			new Move(YukiText.scissor_rollingPiercer, "[x] (" + YukiText.movesListTapY + ")"),
			new Move(YukiText.scissor_clouDeCercueil, "[x]"),
			new Move(YukiText.scissor_masterImpaler, "[x]"),
			new Move(YukiText.scissor_deathRazor, "[x]"),
			new Move(YukiText.scissor_decapitator, "[b]")
		};
	}
}
