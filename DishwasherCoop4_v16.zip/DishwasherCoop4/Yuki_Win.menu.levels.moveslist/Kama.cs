using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Kama : MovesListBase
{
	public Kama()
	{
		weapon = YukiText.kamakazi;
		name = InvCatalog.InvItemName.Kamakazi;
		move = new Move[15]
		{
			new Move(YukiText.kama_ourobouros, "[x] [x] [x] [x]"),
			new Move(YukiText.kama_venomFlurry, "[x] [x] [u][x] [x]"),
			new Move(YukiText.kama_ironFlurry, "[x] [x] [u][x] [y]"),
			new Move(YukiText.kama_mulcherClaw, "[x] [x] [x] [d][x]"),
			new Move(YukiText.kama_danceOfFangs, "[x] [x] [x] [b]"),
			new Move(YukiText.kama_serpentKick, "[x] [x]"),
			new Move(YukiText.kama_serpentStrangle, "[x] [b]"),
			new Move(YukiText.kama_flyingViperBarrage, "[x] [u][x] [u][x]"),
			new Move(YukiText.kama_flyingCobraSlam, "[x] [u][x] [x]"),
			new Move(YukiText.kama_flyingBoaStrangle, "[x] [u][x] [b]"),
			new Move(YukiText.kama_suicideTrap, "[x]"),
			new Move(YukiText.kama_homicideTrap, "[x]"),
			new Move(YukiText.kama_serpentSlash, "[x]"),
			new Move(YukiText.kama_serpentsFang, "[b] [x]"),
			new Move(YukiText.kama_viperChop, "[b]")
		};
	}
}
