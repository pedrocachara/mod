using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Claws : MovesListBase
{
	public Claws()
	{
		weapon = YukiText.claws;
		name = InvCatalog.InvItemName.Claws;
		move = new Move[7]
		{
			new Move(YukiText.claws_clawBarrage, "[x] [x] [x] [x]"),
			new Move(YukiText.claws_creatureKick, "[x] [x] [d][x]"),
			new Move(YukiText.claws_airBarrage, "[x] [x] [x]"),
			new Move(YukiText.claws_corkscrew, "[x]"),
			new Move(YukiText.claws_bloodhawk, "[x]"),
			new Move(YukiText.claws_rager, "[x] " + YukiText.movesListOr + " [b]"),
			new Move(YukiText.claws_feralSplit, "[b] [b]")
		};
	}
}
