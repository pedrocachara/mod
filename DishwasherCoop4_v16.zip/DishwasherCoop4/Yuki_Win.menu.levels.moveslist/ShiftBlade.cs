using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class ShiftBlade : MovesListBase
{
	public ShiftBlade()
	{
		weapon = YukiText.shiftBlade;
		name = InvCatalog.InvItemName.ShiftBlade;
		move = new Move[16]
		{
			new Move(YukiText.shift_dishKick, "[x] [x] [x] [x]"),
			new Move(YukiText.shift_shiftLifter, "[x] [x] [x] [d][x]"),
			new Move(YukiText.shift_bladeSmash, "[x] [x] [x] [u][x]"),
			new Move(YukiText.shift_splitterSlash, "[y]"),
			new Move(YukiText.shift_shadowSlash, "[x] [x] [x] [y]"),
			new Move(YukiText.shift_shadowLift, "[x] [x] [x] [y] [x]"),
			new Move(YukiText.shift_splitterDrop, "[y]"),
			new Move(YukiText.shift_defierSlam, "[x] [x] [x] [x]"),
			new Move(YukiText.shift_rapidLaunch, "[x] [u][x]"),
			new Move(YukiText.shift_defierLaunch, "[x] [x] [x] [u][x]"),
			new Move(YukiText.shift_airShadowSlash, "[x] [x] [x] [y]"),
			new Move(YukiText.shift_airShadowLift, "[x] [x] [x] [y] [x]"),
			new Move(YukiText.shift_acroDrop, "[x]"),
			new Move(YukiText.shift_predatorDrop, "[x]"),
			new Move(YukiText.shift_cleanSplitter, "[x]"),
			new Move(YukiText.shift_messySever, "[b]")
		};
	}
}
