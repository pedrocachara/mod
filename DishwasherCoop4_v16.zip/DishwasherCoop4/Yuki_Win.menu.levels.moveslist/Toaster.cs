using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Toaster : MovesListBase
{
	public Toaster()
	{
		weapon = YukiText.dekkentozter;
		name = InvCatalog.InvItemName.Dekkentozter;
		move = new Move[10]
		{
			new Move(YukiText.toaster_kitchenCombo, "[x] [x] [x] [x]"),
			new Move(YukiText.toaster_electricUppercut, "[x] [x] [x] [d][x]"),
			new Move(YukiText.toaster_toasterInTheTub, "[d][x]"),
			new Move(YukiText.toaster_aerialAppliance, "[x] [x] [x]"),
			new Move(YukiText.toaster_breakfastBash, "[x]"),
			new Move(YukiText.toaster_airpliance, "[x]"),
			new Move(YukiText.toaster_superSoak, "[y]"),
			new Move(YukiText.toaster_flyingSoak, "[y]"),
			new Move(YukiText.toaster_clobber, "[b]"),
			new Move(YukiText.toaster_razorCord, "[x]")
		};
	}
}
