using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Hammer : MovesListBase
{
	public Hammer()
	{
		weapon = YukiText.violenceHammer;
		name = InvCatalog.InvItemName.ViolenceHammer;
		move = new Move[15]
		{
			new Move(YukiText.hammer_pulverize, "[x] [x] [x]"),
			new Move(YukiText.hammer_mayhemLaunch, "[x] [y]"),
			new Move(YukiText.hammer_carcassLaunch, "[x] [x] [d][x]"),
			new Move(YukiText.hammer_meatPummel, "[x] [x] [y]"),
			new Move(YukiText.hammer_smashingPummel, "[x] [x] [x] [y]"),
			new Move(YukiText.hammer_fracasCrash, "[x] [x] [x] [d][x]"),
			new Move(YukiText.hammer_brainsmash, "[y]"),
			new Move(YukiText.hammer_meatapult, "[d][y]"),
			new Move(YukiText.hammer_skySmasher, "[x] [x] [x]"),
			new Move(YukiText.hammer_violenceDrop, "[y]"),
			new Move(YukiText.hammer_facePummel, "[x]"),
			new Move(YukiText.hammer_scatterCrash, "[x]"),
			new Move(YukiText.hammer_ultimateDoom, "[b]"),
			new Move(YukiText.hammer_clawHammer, "[x]"),
			new Move(YukiText.hammer_skyHammer, "[x]")
		};
	}
}
