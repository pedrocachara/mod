using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Cleaver : MovesListBase
{
	public Cleaver()
	{
		weapon = YukiText.meatCleavers;
		name = InvCatalog.InvItemName.MeatCleavers;
		move = new Move[20]
		{
			new Move(YukiText.cleavers_ochoSlam, "[x] [x] [x] [x] [x]"),
			new Move(YukiText.cleavers_dishiuken, "[x] [x] [x] [d][x]"),
			new Move(YukiText.cleavers_ochodishiuken, "[x] [x] [x] [x] [d][x]"),
			new Move(YukiText.cleavers_crossSlash, "[x] [x] [y]"),
			new Move(YukiText.cleavers_crossedEight, "[x] [x] [x] [y]"),
			new Move(YukiText.cleavers_perfectChop, "[x] [x] [x] [x] [y]"),
			new Move(YukiText.cleavers_dishkick, "[x] [x] [u][x]"),
			new Move(YukiText.cleavers_dishKickCombo, "[x] [x] [x] [u][x]"),
			new Move(YukiText.cleavers_trickyDishKick, "[x] [y]"),
			new Move(YukiText.cleavers_finisher, "[y]"),
			new Move(YukiText.cleavers_kitchenSploder, "[y] [x]"),
			new Move(YukiText.cleavers_aerator, "[x] [x] [x] [x]"),
			new Move(YukiText.cleavers_aerialEight, "[x] [x] [x] [y]"),
			new Move(YukiText.cleavers_cleaverDrop, "[y]"),
			new Move(YukiText.cleavers_rollingBlades, "[x] [x]"),
			new Move(YukiText.cleavers_rollingLaunch, "[x] [d][x]"),
			new Move(YukiText.cleavers_cleaverBlast, "[x]"),
			new Move(YukiText.cleavers_cleaverKill, "[x]"),
			new Move(YukiText.cleavers_cleaverHackNSlash, "[b]"),
			new Move(YukiText.cleavers_birdOfPrey, "[x]")
		};
	}
}
