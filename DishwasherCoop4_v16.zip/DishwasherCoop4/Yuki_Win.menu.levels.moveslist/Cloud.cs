using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Cloud : MovesListBase
{
	public Cloud()
	{
		weapon = YukiText.cloudSword;
		name = InvCatalog.InvItemName.CloudSword;
		move = new Move[16]
		{
			new Move(YukiText.cloud_hurricane, "[x] [x] [x] [x]"),
			new Move(YukiText.cloud_risingTyphoon, "[x] [x] [x] [d][x]"),
			new Move(YukiText.cloud_doomingStorm, "[x] [x] [x] [u][x]"),
			new Move(YukiText.cloud_chaosFlood, "[x] [x] [x] [u][x] [y]"),
			new Move(YukiText.cloud_bloodGeyser, "[x] [y]"),
			new Move(YukiText.cloud_bloodHurricane, "[x] [x] [x] [y]"),
			new Move(YukiText.cloud_lightningSpear, "[b]"),
			new Move(YukiText.cloud_heavyCut, "[y]"),
			new Move(YukiText.cloud_righteousShockwave, YukiText.movesListHoldYRelease),
			new Move(YukiText.cloud_metalSky, "[x] [x] [x] [x]"),
			new Move(YukiText.cloud_thunderCrash, "[y]"),
			new Move(YukiText.cloud_thunderSpear, "[b]"),
			new Move(YukiText.cloud_arcBlade, "[x]"),
			new Move(YukiText.cloud_skyBlade, "[x]"),
			new Move(YukiText.cloud_visceraStorm, "[b]"),
			new Move(YukiText.cloud_finalCut, "[x]")
		};
	}
}
