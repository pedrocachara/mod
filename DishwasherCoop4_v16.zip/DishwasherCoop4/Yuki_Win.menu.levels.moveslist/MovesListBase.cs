using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class MovesListBase
{
	public string weapon;

	public InvCatalog.InvItemName name;

	public Move[] move;

	public int GetLength()
	{
		return 3 + move.Length * 3;
	}
}
