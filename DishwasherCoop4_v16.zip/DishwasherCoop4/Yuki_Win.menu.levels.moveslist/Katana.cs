using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Katana : MovesListBase
{
	public Katana()
	{
		weapon = YukiText.conviction;
		name = InvCatalog.InvItemName.Conviction;
		move = new Move[15]
		{
			new Move(YukiText.conviction_murderBarrage, "[x] [x] [x] [x]"),
			new Move(YukiText.conviction_sickLaunch, "[x] [x] [x] [d][x]"),
			new Move(YukiText.conviction_murderGrab, "[x] [x] [x] [b]"),
			new Move(YukiText.conviction_vultureSmash, "[x] [x] [x] [x]"),
			new Move(YukiText.conviction_vultureGrab, "[x] [x] [x] [b]"),
			new Move(YukiText.conviction_vultureBarrage, "[x] [x] [x] [u][x]"),
			new Move(YukiText.conviction_skewerDrop, "[u][x]"),
			new Move(YukiText.conviction_skewerSlash, "[x] [x]"),
			new Move(YukiText.conviction_bloodAngel, "[x]"),
			new Move(YukiText.conviction_severSlash, "[x]"),
			new Move(YukiText.conviction_impalerSlash, "[b] [x]"),
			new Move(YukiText.conviction_gallowsSlash, "[b]"),
			new Move(YukiText.conviction_machineBlast, "[x] [y]"),
			new Move(YukiText.conviction_metalBarrage, "[x] [x] [x] [y]"),
			new Move(YukiText.conviction_machineScatter, "[x] [y]")
		};
	}
}
