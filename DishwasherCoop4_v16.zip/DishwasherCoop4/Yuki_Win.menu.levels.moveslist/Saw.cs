using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Saw : MovesListBase
{
	public Saw()
	{
		weapon = YukiText.machineArmSaw;
		name = InvCatalog.InvItemName.UpgradeChainsaw;
		move = new Move[6]
		{
			new Move(YukiText.saw_machineBarrage, "[y] [y] [y]"),
			new Move(YukiText.saw_machineAssault, "[d][y]"),
			new Move(YukiText.saw_machineDestroyer, "[u]" + YukiText.movesListTapY),
			new Move(YukiText.saw_machineSplitter, "[y] " + YukiText.movesListTapYOnLanding),
			new Move(YukiText.saw_machineExecution, "[y]"),
			new Move(YukiText.saw_machineGrindhaus, "[b] [y]")
		};
	}
}
