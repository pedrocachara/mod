using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Syringe : MovesListBase
{
	public Syringe()
	{
		weapon = YukiText.painkiller;
		name = InvCatalog.InvItemName.Painkiller;
		move = new Move[22]
		{
			new Move(YukiText.syringe_sterlize, "[x] [x] [x] [x]"),
			new Move(YukiText.syringe_straightShot, "[x] [y] [y]"),
			new Move(YukiText.syringe_sterilUppercut, "[x] [x] [x] [d][x]"),
			new Move(YukiText.syringe_straightShot, "[x] [x] [x] [d][x] [y]"),
			new Move(YukiText.syringe_hypodermicRain, "[x] [x] [u][x] [x]"),
			new Move(YukiText.syringe_immunoUppercut, "[x] [x] [u][x] [d][x]"),
			new Move(YukiText.syringe_clinicalShot, "[x] [x] [u][x] [d][x] [y]"),
			new Move(YukiText.syringe_addictsImpaler, "[x] [x] [u][x] [u][x]"),
			new Move(YukiText.syringe_morbidDrain, "[x] [x] [x] [y]"),
			new Move(YukiText.syringe_numbingDrain, "[x] [x] [u][x] [y]"),
			new Move(YukiText.syringe_eyestabber, "[y]"),
			new Move(YukiText.syringe_bonePunch, "[b]"),
			new Move(YukiText.syringe_viciousStab, "[u][y]"),
			new Move(YukiText.syringe_quickShot, "[d][y]"),
			new Move(YukiText.syringe_plasticDevour, "[x] [x] [x]"),
			new Move(YukiText.syringe_hypodermicStorm, "[x] [u][x] [x]"),
			new Move(YukiText.syringe_plungerDrop, "[y]"),
			new Move(YukiText.syringe_airPunch, "[b]"),
			new Move(YukiText.syringe_wallPlunger, "[x]"),
			new Move(YukiText.syringe_skyPlunger, "[x]"),
			new Move(YukiText.syringe_bloodCocktail, "[x]"),
			new Move(YukiText.syringe_finalDrain, "[b]")
		};
	}
}
