namespace Yuki_Win.menu.levels.moveslist;

public class Move
{
	public string name;

	public string desc;

	public Move(string name, string desc)
	{
		this.name = name;
		this.desc = desc;
	}
}
