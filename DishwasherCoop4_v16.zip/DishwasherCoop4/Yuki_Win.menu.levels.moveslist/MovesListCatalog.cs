namespace Yuki_Win.menu.levels.moveslist;

public class MovesListCatalog
{
	public const int WEAPON_KATANA = 0;

	public const int WEAPON_SAW = 1;

	public const int WEAPON_KAMA = 2;

	public const int WEAPON_GUN = 3;

	public const int WEAPON_SHIFT_BLADE = 4;

	public const int WEAPON_HAMMER = 5;

	public const int WEAPON_CLEAVER = 6;

	public const int WEAPON_SCISSOR = 7;

	public const int WEAPON_CLOUD = 8;

	public const int WEAPON_SYRINGE = 9;

	public const int WEAPON_TOASTER = 10;

	public const int WEAPON_CLAWS = 11;

	public MovesListBase[] movesList;

	public MovesListCatalog()
	{
		movesList = new MovesListBase[12]
		{
			new Katana(),
			new Saw(),
			new Kama(),
			new Gun(),
			new ShiftBlade(),
			new Hammer(),
			new Cleaver(),
			new Scissor(),
			new Cloud(),
			new Syringe(),
			new Toaster(),
			new Claws()
		};
	}
}
