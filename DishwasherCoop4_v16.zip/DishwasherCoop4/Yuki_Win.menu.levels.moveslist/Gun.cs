using Yuki_Win.player;

namespace Yuki_Win.menu.levels.moveslist;

public class Gun : MovesListBase
{
	public Gun()
	{
		weapon = YukiText.machineArmGun;
		name = InvCatalog.InvItemName.GunArm;
		move = new Move[2]
		{
			new Move(YukiText.gun_machineGun, "[R]"),
			new Move(YukiText.gun_firingSquad, "[b] [R]")
		};
	}
}
