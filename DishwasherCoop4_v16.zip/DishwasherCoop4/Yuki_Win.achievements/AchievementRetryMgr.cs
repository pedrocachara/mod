using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.guidestuff;

namespace Yuki_Win.achievements;

public class AchievementRetryMgr
{
	public struct AchieveRetry
	{
		public const int TYPE_ACHIEVEMENT = 0;

		public const int TYPE_GAMERPIC = 1;

		public int type;

		public int idx;
	}

	private Queue<AchieveRetry> retry;

	private float checkFrame;

	private int ID;

	private bool active;

	public AchievementRetryMgr(int ID)
	{
		this.ID = ID;
		retry = new Queue<AchieveRetry>();
	}

	public void Add(int type, int idx)
	{
		AchieveRetry item = new AchieveRetry
		{
			idx = idx,
			type = type
		};
		active = false;
		checkFrame = 1f;
		retry.Enqueue(item);
	}

	public void Update()
	{
		if (active && !Game1.menuMgr.messageMgr.GetActive())
		{
			Reget();
		}
	}

	private void Reget()
	{
		if (retry.Count > 0)
		{
			SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[ID]);
			if (signedInGamerAtIndex != null)
			{
				bool flag = false;
				while (!flag)
				{
					AchieveRetry achieveRetry = retry.Peek();
					switch (achieveRetry.type)
					{
					case 0:
						try
						{
							signedInGamerAtIndex.AwardAchievement(AchievementDef.achievementStr[achieveRetry.idx]);
							retry.Dequeue();
						}
						catch (Exception)
						{
							Game1.menuMgr.messageMgr.AddMsg(YukiText.epicFail, new string[3]
							{
								YukiText.achievementFailed1,
								YukiText.achievementFailed2,
								YukiText.achievementFailed3
							}, clear: false, weak: false, 0, 4);
							Game1.achievementMgr.playerAchievements[ID].Retry(0, achieveRetry.idx);
							active = false;
							return;
						}
						break;
					case 1:
						try
						{
							retry.Dequeue();
						}
						catch (Exception)
						{
							Game1.menuMgr.messageMgr.AddMsg(YukiText.epicFail, new string[3]
							{
								YukiText.gamerpicFailed1,
								YukiText.achievementFailed2,
								YukiText.achievementFailed3
							}, clear: false, weak: false, 0, 4);
							Game1.achievementMgr.playerAchievements[ID].Retry(1, achieveRetry.idx);
							active = false;
							return;
						}
						break;
					}
					if (retry.Count <= 0)
					{
						flag = true;
					}
				}
			}
		}
		active = false;
	}

	internal void Retry()
	{
		active = true;
	}

	internal void Reset()
	{
		active = false;
		retry = new Queue<AchieveRetry>();
	}
}
