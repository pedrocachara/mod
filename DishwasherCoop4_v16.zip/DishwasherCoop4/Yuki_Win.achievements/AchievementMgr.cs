namespace Yuki_Win.achievements;

public class AchievementMgr
{
	public PlayerAchievements[] playerAchievements;

	private float achievementUpdateFrame;

	public AchievementMgr()
	{
		playerAchievements = new PlayerAchievements[4];
		for (int i = 0; i < playerAchievements.Length; i++)
		{
			playerAchievements[i] = new PlayerAchievements(i);
		}
	}

	public void PurchaseUnlock()
	{
		for (int i = 0; i < playerAchievements.Length; i++)
		{
			playerAchievements[i].PurchaseUnlock();
		}
	}

	public void Update()
	{
		achievementUpdateFrame += FMan.frameTime;
		if (achievementUpdateFrame > 1f)
		{
			achievementUpdateFrame--;
			for (int i = 0; i < playerAchievements.Length; i++)
			{
				playerAchievements[i].Update();
			}
		}
	}

	internal void RetryAllAchievements()
	{
		for (int i = 0; i < playerAchievements.Length; i++)
		{
			playerAchievements[i].PushRetry();
		}
	}
}
