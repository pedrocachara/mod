using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.guidestuff;

namespace Yuki_Win.achievements;

public class AchievementDef
{
	public bool unlocked;

	public bool unlockUponPurchase;

	private int purchaseGoFrame;

	public static string[] achievementStr = new string[12]
	{
		"ACHIEVEMENT_01", "ACHIEVEMENT_02", "ACHIEVEMENT_03", "ACHIEVEMENT_04", "ACHIEVEMENT_05", "ACHIEVEMENT_06", "ACHIEVEMENT_07", "ACHIEVEMENT_08", "ACHIEVEMENT_09", "ACHIEVEMENT_10",
		"ACHIEVEMENT_11", "ACHIEVEMENT_12"
	};

	public static string[] gamerPicStr = new string[2] { "Gamerpic1", "Gamerpic2" };

	public int ID;

	public int playerIdx;

	private IAsyncResult getResult;

	private bool pendingList;

	private IAsyncResult awardResult;

	private bool pendingAward;

	private IAsyncResult gamerpicResult;

	private bool pendingPic;

	public virtual void Write(BinaryWriter writer)
	{
		writer.Write(value: false);
	}

	public virtual void Read(BinaryReader reader)
	{
		unlocked = reader.ReadBoolean();
		if (unlocked)
		{
			Unlock(overRide: true);
		}
	}

	public virtual void Unlock(bool overRide)
	{
		if (unlocked)
		{
			return;
		}
		unlocked = true;
		if (GuideStuff.GetTrial())
		{
			unlocked = false;
			unlockUponPurchase = true;
			return;
		}
		for (int i = 0; i < Gamer.SignedInGamers.Count; i++)
		{
			if (Gamer.SignedInGamers[i].PlayerIndex == (PlayerIndex)Game1.mainPlayer[PlayerIndex()])
			{
				Gamer.SignedInGamers[i].AwardAchievement(achievementStr[ID]);
			}
		}
	}

	private int PlayerIndex()
	{
		if (Game1.netSession.IsClient())
		{
			return 0;
		}
		return playerIdx;
	}

	public void Update()
	{
		if (pendingAward && awardResult.IsCompleted)
		{
			pendingAward = false;
			SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[PlayerIndex()]);
			if (signedInGamerAtIndex != null)
			{
				try
				{
					signedInGamerAtIndex.EndAwardAchievement(awardResult);
				}
				catch (Exception)
				{
					Game1.menuMgr.messageMgr.AddMsg(YukiText.epicFail, new string[3]
					{
						YukiText.achievementFailed1,
						YukiText.achievementFailed2,
						YukiText.achievementFailed3
					}, clear: false, weak: false, 0, 4);
					Game1.achievementMgr.playerAchievements[PlayerIndex()].Retry(0, ID);
				}
			}
		}
		if (pendingPic && gamerpicResult.IsCompleted)
		{
			pendingPic = false;
			for (int i = 0; i < Gamer.SignedInGamers.Count; i++)
			{
				if (Gamer.SignedInGamers[i].PlayerIndex == (PlayerIndex)Game1.mainPlayer[PlayerIndex()])
				{
				}
			}
		}
		if (!unlockUponPurchase || GuideStuff.GetTrial() || purchaseGoFrame >= 4)
		{
			return;
		}
		purchaseGoFrame++;
		if (purchaseGoFrame < 4)
		{
			return;
		}
		unlockUponPurchase = false;
		unlocked = true;
		purchaseGoFrame = 0;
		for (int j = 0; j < Gamer.SignedInGamers.Count; j++)
		{
			if (Gamer.SignedInGamers[j].PlayerIndex == (PlayerIndex)Game1.mainPlayer[PlayerIndex()])
			{
				Gamer.SignedInGamers[j].AwardAchievement(achievementStr[ID]);
			}
		}
	}

	internal virtual void Copy(AchievementDef src)
	{
		unlocked = src.unlocked;
	}
}
