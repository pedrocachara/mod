using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.achievements.cheevos;
using Yuki_Win.guidestuff;

namespace Yuki_Win.achievements;

public class PlayerAchievements
{
	public enum AchievementName
	{
		WinLevelOne,
		WinYukiCampaign,
		WinDishCampaign,
		WinSamuraiAny,
		WinArcade,
		GetAllAchievables,
		BloodyThePaintings,
		CollectAllBeads,
		ChainsawDuels,
		KillYourSelf,
		UnlockPrettyPrincess,
		Separate100Dudes
	}

	public Dictionary<int, AchievementDef> achievementList;

	private AchievementRetryMgr achievementRetryMgr;

	private bool checkingPrettyPrincess;

	private IAsyncResult prettyPrincessResult;

	private int ID;

	public void Copy(PlayerAchievements src)
	{
		foreach (KeyValuePair<int, AchievementDef> achievement in achievementList)
		{
			achievementList[achievement.Key].Copy(achievement.Value);
		}
	}

	public void Retry(int type, int idx)
	{
		achievementRetryMgr.Add(type, idx);
	}

	public PlayerAchievements(int playerIdx)
	{
		achievementRetryMgr = new AchievementRetryMgr(playerIdx);
		ID = playerIdx;
		achievementList = new Dictionary<int, AchievementDef>();
		achievementList.Add(0, new AchievementDef());
		achievementList.Add(1, new AchievementDef());
		achievementList.Add(2, new AchievementDef());
		achievementList.Add(3, new AchievementDef());
		achievementList.Add(4, new AchievementDef());
		achievementList.Add(5, new GetAllAchievables());
		achievementList.Add(6, new BloodyPaintings());
		achievementList.Add(7, new AchievementDef());
		achievementList.Add(8, new ChainsawDuels());
		achievementList.Add(9, new AchievementDef());
		achievementList.Add(10, new AchievementDef());
		achievementList.Add(11, new Separate100Dudes());
		for (int i = 0; i < achievementList.Count; i++)
		{
			achievementList[i].ID = i;
			achievementList[i].playerIdx = playerIdx;
		}
	}

	public void Write(BinaryWriter writer)
	{
		foreach (KeyValuePair<int, AchievementDef> achievement in achievementList)
		{
			writer.Write(achievement.Key);
			achievement.Value.Write(writer);
		}
	}

	public void Read(BinaryReader reader)
	{
		for (int i = 0; i < achievementList.Count; i++)
		{
			int key = reader.ReadInt32();
			achievementList[key].Read(reader);
		}
		achievementRetryMgr.Reset();
		if (!checkingPrettyPrincess)
		{
			checkingPrettyPrincess = true;
			prettyPrincessResult = GuideStuff.GetSignedInGamerAtIndex(ID).BeginGetAchievements(null, null);
		}
	}

	internal void PurchaseUnlock()
	{
		for (int i = 0; i < achievementList.Count; i++)
		{
		}
	}

	internal void Update()
	{
		achievementRetryMgr.Update();
		for (int i = 0; i < achievementList.Count; i++)
		{
			achievementList[i].Update();
		}
		if (!checkingPrettyPrincess || !prettyPrincessResult.IsCompleted)
		{
			return;
		}
		SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(ID);
		if (signedInGamerAtIndex != null)
		{
			try
			{
				AchievementCollection achievementCollection = signedInGamerAtIndex.EndGetAchievements(prettyPrincessResult);
				foreach (Achievement item in achievementCollection)
				{
					if (item.Key == AchievementDef.achievementStr[10] && item.IsEarned)
					{
						Game1.gamePlayerMgr.gamePlayer[ID].prettyPrincessUnlock = true;
					}
				}
			}
			catch
			{
				Game1.gamePlayerMgr.gamePlayer[ID].prettyPrincessUnlock = false;
			}
		}
		checkingPrettyPrincess = false;
	}

	internal void PushRetry()
	{
		achievementRetryMgr.Retry();
	}
}
