namespace Yuki_Win.storage;

public class LevelTrackData
{
	public LevelData[] levelData;

	public LevelTrackData(int levels)
	{
		levelData = new LevelData[levels];
		for (int i = 0; i < levelData.Length; i++)
		{
			levelData[i] = new LevelData();
		}
	}
}
