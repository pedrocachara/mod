using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.hud;

namespace Yuki_Win.storage;

public class PlayerLevelData
{
	public enum LevelTrack
	{
		PrettyPrincessYuki,
		EasyYuki,
		NormalYuki,
		NinjaYuki,
		SamuraiYuki,
		TourneyYuki,
		PrettyPrincessDish,
		EasyDish,
		NormalDish,
		NinjaDish,
		SamuraiDish,
		TourneyDish,
		PrettyPrincessCoop,
		EasyCoop,
		NormalCoop,
		NinjaCoop,
		SamuraiCoop,
		TourneyCoop,
		Arcade,
		ArcadeCoop
	}

	private const int YUKI_LEVEL_COUNT = 13;

	private const int DISH_LEVEL_COUNT = 12;

	private const int COOP_LEVEL_COUNT = 12;

	private const int ARCADE_LEVEL_COUNT = 50;

	public Dictionary<int, LevelTrackData> levelData;

	public bool wonGame;

	public List<string> uberFlags;

	public PlayerLevelData()
	{
		levelData = new Dictionary<int, LevelTrackData>();
		uberFlags = new List<string>();
		levelData.Add(0, new LevelTrackData(13));
		levelData.Add(1, new LevelTrackData(13));
		levelData.Add(2, new LevelTrackData(13));
		levelData.Add(3, new LevelTrackData(13));
		levelData.Add(4, new LevelTrackData(13));
		levelData.Add(5, new LevelTrackData(13));
		levelData.Add(6, new LevelTrackData(12));
		levelData.Add(7, new LevelTrackData(12));
		levelData.Add(8, new LevelTrackData(12));
		levelData.Add(9, new LevelTrackData(12));
		levelData.Add(10, new LevelTrackData(12));
		levelData.Add(11, new LevelTrackData(12));
		levelData.Add(12, new LevelTrackData(12));
		levelData.Add(13, new LevelTrackData(12));
		levelData.Add(14, new LevelTrackData(12));
		levelData.Add(15, new LevelTrackData(12));
		levelData.Add(16, new LevelTrackData(12));
		levelData.Add(17, new LevelTrackData(12));
		levelData.Add(18, new LevelTrackData(50));
		levelData.Add(19, new LevelTrackData(50));
	}

	public void DrawScoreCard(SpriteBatch sprite, int track, int level, Vector2 loc, float alpha, int threedee)
	{
		if (level > -1 && level < levelData[track].levelData.Length && !(levelData[track].levelData[level].time <= 0f))
		{
			long score = levelData[track].levelData[level].score;
			StringBuilder stime = levelData[track].levelData[level].stime;
			float damage = levelData[track].levelData[level].damage;
			int maxCombo = levelData[track].levelData[level].maxCombo;
			int kills = levelData[track].levelData[level].kills;
			switch (threedee)
			{
			case 0:
				loc.X++;
				break;
			case 1:
				loc.X--;
				break;
			}
			for (int i = 0; i < 2; i++)
			{
				sprite.Draw(Game1.spritesTex, loc, new Rectangle(640, 384, 256, 64), new Color(0f, 0f, 0f, alpha * 0.5f), 0f, default, new Vector2(1.5f, 3.4f), (i == 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
			}
			float num = 0.7f;
			float num2 = 25f;
			float num3 = 40f;
			float num4 = 190f;
			float maxWidth = 140f;
			Text.DrawCText(sprite, loc + new Vector2(30f, num3 + 0f * num2), EndLevel.timeStr, new Color(1f, 1f, 1f, alpha), num, 0, blur: false, maxWidth);
			Text.DrawCText(sprite, loc + new Vector2(30f, num3 + 1f * num2), EndLevel.scoreStr, new Color(1f, 1f, 1f, alpha), num, 0, blur: false, maxWidth);
			Text.DrawCText(sprite, loc + new Vector2(30f, num3 + 2f * num2), EndLevel.killsStr, new Color(1f, 1f, 1f, alpha), num, 0, blur: false, maxWidth);
			Text.DrawCText(sprite, loc + new Vector2(30f, num3 + 3f * num2), EndLevel.maxComboStr, new Color(1f, 1f, 1f, alpha), num, 0, blur: false, maxWidth);
			Text.DrawCText(sprite, loc + new Vector2(30f, num3 + 4f * num2), EndLevel.damageStr, new Color(1f, 0.3f, 0.3f, alpha), num, 0, blur: false, maxWidth);
			Text.DrawCText(sprite, loc + new Vector2(num4, num3 + 0f * num2), stime, new Color(1f, 1f, 1f, alpha), num, 0);
			Text.DrawScore((int)(loc.X + num4), (int)(loc.Y + num3 + 1f * num2), score, new Color(1f, 1f, 1f, alpha), sprite, flip: true, 0f, num);
			Text.DrawScore((int)(loc.X + num4), (int)(loc.Y + num3 + 2f * num2), kills, new Color(1f, 1f, 1f, alpha), sprite, flip: true, 0f, num);
			Text.DrawScore((int)(loc.X + num4), (int)(loc.Y + num3 + 3f * num2), maxCombo, new Color(1f, 1f, 1f, alpha), sprite, flip: true, 0f, num);
			Text.DrawScore((int)(loc.X + num4), (int)(loc.Y + num3 + 4f * num2), (long)damage, new Color(1f, 0.3f, 0.3f, alpha), sprite, flip: true, 0f, num);
		}
	}

	public static LevelTrack GetTrackFromDifficulty(int ltrack, int difficulty)
	{
		LevelTrack result = LevelTrack.Arcade;
		switch (ltrack)
		{
		case 0:
			switch (difficulty)
			{
			case 0:
				result = LevelTrack.PrettyPrincessYuki;
				break;
			case 1:
				result = LevelTrack.EasyYuki;
				break;
			case 2:
				result = LevelTrack.NormalYuki;
				break;
			case 3:
				result = LevelTrack.NinjaYuki;
				break;
			case 4:
				result = LevelTrack.SamuraiYuki;
				break;
			case 5:
				result = LevelTrack.TourneyYuki;
				break;
			}
			break;
		case 1:
			switch (difficulty)
			{
			case 0:
				result = LevelTrack.PrettyPrincessDish;
				break;
			case 1:
				result = LevelTrack.EasyDish;
				break;
			case 2:
				result = LevelTrack.NormalDish;
				break;
			case 3:
				result = LevelTrack.NinjaDish;
				break;
			case 4:
				result = LevelTrack.SamuraiDish;
				break;
			case 5:
				result = LevelTrack.TourneyDish;
				break;
			}
			break;
		case 2:
			switch (difficulty)
			{
			case 0:
				result = LevelTrack.PrettyPrincessCoop;
				break;
			case 1:
				result = LevelTrack.EasyCoop;
				break;
			case 2:
				result = LevelTrack.NormalCoop;
				break;
			case 3:
				result = LevelTrack.NinjaCoop;
				break;
			case 4:
				result = LevelTrack.SamuraiCoop;
				break;
			case 5:
				result = LevelTrack.TourneyCoop;
				break;
			}
			break;
		case 3:
			result = ((Game1.arcade.players != 1) ? LevelTrack.ArcadeCoop : LevelTrack.Arcade);
			break;
		}
		return result;
	}

	public void CopyData(PlayerLevelData src)
	{
		foreach (KeyValuePair<int, LevelTrackData> levelDatum in src.levelData)
		{
			for (int i = 0; i < levelDatum.Value.levelData.Length; i++)
			{
				levelData[levelDatum.Key].levelData[i].damage = levelDatum.Value.levelData[i].damage;
				levelData[levelDatum.Key].levelData[i].kills = levelDatum.Value.levelData[i].kills;
				levelData[levelDatum.Key].levelData[i].maxCombo = levelDatum.Value.levelData[i].maxCombo;
				levelData[levelDatum.Key].levelData[i].score = levelDatum.Value.levelData[i].score;
				levelData[levelDatum.Key].levelData[i].stime = levelDatum.Value.levelData[i].stime;
				levelData[levelDatum.Key].levelData[i].time = levelDatum.Value.levelData[i].time;
			}
		}
	}

	public void Read(BinaryReader reader, int ID)
	{
		int num = reader.ReadInt32();
		uberFlags.Clear();
		wonGame = false;
		for (int i = 0; i < num; i++)
		{
			uberFlags.Add(reader.ReadString());
		}
		for (int j = 0; j < levelData.Count; j++)
		{
			for (int k = 0; k < levelData[j].levelData.Length; k++)
			{
				levelData[j].levelData[k].score = reader.ReadInt64();
				levelData[j].levelData[k].SetTime(reader.ReadSingle());
				levelData[j].levelData[k].maxCombo = reader.ReadInt32();
				levelData[j].levelData[k].damage = reader.ReadSingle();
				levelData[j].levelData[k].kills = reader.ReadInt32();
			}
		}
		if (levelData[1].levelData[12].score > 0 || levelData[2].levelData[12].score > 0 || levelData[3].levelData[12].score > 0)
		{
			wonGame = true;
		}
	}

	public void Write(BinaryWriter writer, int ID)
	{
		writer.Write(uberFlags.Count);
		foreach (string uberFlag in uberFlags)
		{
			writer.Write(uberFlag);
		}
		for (int i = 0; i < levelData.Count; i++)
		{
			for (int j = 0; j < levelData[i].levelData.Length; j++)
			{
				writer.Write(levelData[i].levelData[j].score);
				writer.Write(levelData[i].levelData[j].time);
				writer.Write(levelData[i].levelData[j].maxCombo);
				writer.Write(levelData[i].levelData[j].damage);
				writer.Write(levelData[i].levelData[j].kills);
			}
		}
	}
}
