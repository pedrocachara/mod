using System.Text;

namespace Yuki_Win.storage;

public class LevelData
{
	public long score;

	public float time;

	public float damage;

	public int maxCombo;

	public int kills;

	public StringBuilder stime;

	public void SetTime(float time)
	{
		this.time = time;
		string text = "";
		int num = (int)time;
		int num2 = num % 60;
		text = num2.ToString();
		if (num2 < 10)
		{
			text = "0" + text;
		}
		text = num / 60 + ":" + text;
		stime = new StringBuilder(text);
	}
}
