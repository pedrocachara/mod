namespace Yuki_Win.storage;

public class StorageMgr
{
	public Storage[] storage = new Storage[4];

	public PlayerLevelData[] playerData = new PlayerLevelData[4];

	public StorageMgr()
	{
		for (int i = 0; i < storage.Length; i++)
		{
			storage[i] = new Storage();
		}
		for (int j = 0; j < playerData.Length; j++)
		{
			playerData[j] = new PlayerLevelData();
		}
		storage[1].Init(1, 1);
	}
}
