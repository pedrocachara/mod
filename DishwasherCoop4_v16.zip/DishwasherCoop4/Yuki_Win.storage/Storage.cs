using System;
using System.IO;
using Microsoft.Xna.Framework.Storage;
using SDL2;
using Yuki_Win.achievements;
using Yuki_Win.player;
using Yuki_Win.player.beads;
using Yuki_Win.player.inventory;

namespace Yuki_Win.storage;

public class Storage
{
	private const int GAMESAVE_VERSION = 101;

	private const int SETTINGS_VERSION = 104;

	public const int DEVICE_EMPTY = 0;

	public const int DEVICE_GETTING_DEVICE = 1;

	public const int DEVICE_CONNECTED = 2;

	public const int DEVICE_ERROR = 3;

	public const int DEVICE_DISCONNECTED = 4;

	public const int DATA_GAMESAVE = 1;

	public const int DATA_SETTINGS = 0;

	private const int MIN_FREESPACE = 262144;

	private StorageDevice device;

	private StorageContainer container;

	private IAsyncResult deviceResult;

	public int controllerIdx;

	public int mainPlayerIdx;

	private bool containerOpen;

	public int state;

	public bool retryOnceInGamePlay;

	public string[] dataStr = new string[3] { "settings.slv", "save.slv", "savecoop.slv" };

	public static readonly string SaveDir = GetSaveDir();

	public void Init(int controllerIdx, int mainPlayerIdx)
	{
		this.controllerIdx = controllerIdx;
		this.mainPlayerIdx = mainPlayerIdx;
		state = 0;
		device = null;
	}

	public int Read(int type)
	{
		if (type == 0)
		{
			return 0;
		}
		if (!File.Exists(Path.Combine(SaveDir, dataStr[type << mainPlayerIdx])))
		{
			ResetFile(type);
			Write(type);
		}
		else
		{
			BinaryReader binaryReader = new BinaryReader(File.Open(Path.Combine(SaveDir, dataStr[type << mainPlayerIdx]), FileMode.Open, FileAccess.Read));
			ReadData(binaryReader, type);
			binaryReader.Close();
		}
		return 0;
	}

	public int Write(int type)
	{
		if (type == 0)
		{
			return 0;
		}
		BinaryWriter binaryWriter = new BinaryWriter(File.Open(Path.Combine(SaveDir, dataStr[type << mainPlayerIdx]), FileMode.OpenOrCreate, FileAccess.Write));
		WriteData(binaryWriter, type);
		binaryWriter.Close();
		return 0;
	}

	public void ReadData(BinaryReader reader, int type)
	{
		if (type == 1)
		{
			int num = reader.ReadInt32();
			if (num != 101)
			{
				Game1.menuMgr.messageMgr.AddMsg(YukiText.readFail, new string[2]
				{
					YukiText.saveDataWrongVersion1,
					YukiText.saveDataWrongVersion2
				}, clear: true, weak: true, 0, 3);
				ResetFile(1);
			}
			else
			{
				Game1.storageMgr.playerData[mainPlayerIdx].Read(reader, mainPlayerIdx);
				Game1.gamePlayerMgr.gamePlayer[mainPlayerIdx].Read(reader, mainPlayerIdx);
				Game1.achievementMgr.playerAchievements[mainPlayerIdx].Read(reader);
				Game1.hud.invMgr.inv[mainPlayerIdx].Read(reader);
			}
		}
	}

	public void WriteData(BinaryWriter writer, int type)
	{
		if (type == 1)
		{
			writer.Write(101);
			if (Game1.netSession.IsClient())
			{
				Game1.storageMgr.playerData[1].Write(writer, 1);
				Game1.gamePlayerMgr.gamePlayer[1].Write(writer, 1);
				Game1.achievementMgr.playerAchievements[1].Write(writer);
				Game1.hud.invMgr.inv[1].Write(writer);
			}
			else
			{
				Game1.storageMgr.playerData[mainPlayerIdx].Write(writer, mainPlayerIdx);
				Game1.gamePlayerMgr.gamePlayer[mainPlayerIdx].Write(writer, mainPlayerIdx);
				Game1.achievementMgr.playerAchievements[mainPlayerIdx].Write(writer);
				Game1.hud.invMgr.inv[mainPlayerIdx].Write(writer);
			}
		}
	}

	private void ResetFile(int type)
	{
		if (type == 1)
		{
			Game1.storageMgr.playerData[mainPlayerIdx] = new PlayerLevelData();
			Game1.gamePlayerMgr.gamePlayer[mainPlayerIdx] = new GamePlayer(mainPlayerIdx);
			Game1.achievementMgr.playerAchievements[mainPlayerIdx] = new PlayerAchievements(mainPlayerIdx);
			Game1.hud.invMgr.inv[mainPlayerIdx] = new Inv(mainPlayerIdx);
			Game1.beadMgr.beads[mainPlayerIdx] = new Beads();
		}
	}

	internal void ReadAll()
	{
		Read(1);
		Read(0);
	}

	private static string GetSaveDir()
	{
		string text = SDL.SDL_GetPlatform();
		string text2;
		if (text.Equals("Linux"))
		{
			text2 = Environment.GetEnvironmentVariable("XDG_DATA_HOME");
			if (string.IsNullOrEmpty(text2))
			{
				text2 = Environment.GetEnvironmentVariable("HOME");
				if (string.IsNullOrEmpty(text2))
				{
					return ".";
				}
				text2 = Path.Combine(text2, ".local/share");
			}
			text2 = Path.Combine(text2, "VampireSmile");
		}
		else if (text.Equals("Mac OS X"))
		{
			text2 = Environment.GetEnvironmentVariable("HOME");
			if (string.IsNullOrEmpty(text2))
			{
				return ".";
			}
			text2 = Path.Combine(text2, "Library/Application Support/VampireSmile");
		}
		else
		{
			if (!text.Equals("Windows"))
			{
				throw new NotSupportedException("Unhandled SDL2 platform!");
			}
			text2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "VampireSmile");
		}
		if (!Directory.Exists(text2))
		{
			Directory.CreateDirectory(text2);
		}
		return text2;
	}
}
