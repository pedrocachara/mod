using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.netplay;

namespace Yuki_Win.sprites;

public class NetSprite
{
	private int idx;

	private Vector2 loc;

	private Vector2 traj;

	private float size;

	private int flags;

	private int owner;

	public bool exists;

	public void Init(int idx, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		this.idx = idx;
		this.loc = loc;
		this.traj = traj;
		this.size = size;
		this.flags = flags;
		this.owner = owner;
		exists = true;
	}

	public void Write(PacketWriter writer)
	{
		NetPacker.WriteByte(writer, 1);
		NetPacker.WriteByte(writer, idx);
		NetPacker.WriteVec2(writer, loc);
		if (idx == 12)
		{
			NetPacker.WriteTinyVec2(writer, traj);
		}
		else
		{
			NetPacker.WriteVec2(writer, traj);
		}
		NetPacker.WriteSmallFloat(writer, size);
		NetPacker.WriteSByte(writer, flags);
		NetPacker.WriteSByte(writer, owner);
		exists = false;
	}

	public static void Read(PacketReader reader)
	{
		int num = NetPacker.ReadByte(reader);
		Vector2 location = NetPacker.ReadVec2(reader);
		Vector2 vector = default;
		vector = ((num != 12) ? NetPacker.ReadVec2(reader) : NetPacker.ReadTinyVec2(reader));
		float num2 = NetPacker.ReadSmallFloat(reader);
		int num3 = NetPacker.ReadSByte(reader);
		int num4 = NetPacker.ReadSByte(reader);
		Game1.spriteMan.AddSprite(num, location, vector, num2, num3, num4, netInduced: true);
		int num5 = num;
		if (num5 == 101 && num4 > -1 && num4 < 4)
		{
			Game1.spriteMan.MakeLaserGlow(location, vector / 800f);
		}
	}
}
