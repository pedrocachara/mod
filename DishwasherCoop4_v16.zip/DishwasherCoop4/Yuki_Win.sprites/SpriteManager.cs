using System;
using System.Threading;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.debug;
using Yuki_Win.director;
using Yuki_Win.gameRender;
using Yuki_Win.hud;
using Yuki_Win.maps;
using Yuki_Win.sprites.camsplat;
using Yuki_Win.sprites.gibs;
using Yuki_Win.sprites.goreInstance;
using Yuki_Win.sprites.hit;
using Yuki_Win.sprites.wallblood;

namespace Yuki_Win.sprites;

public class SpriteManager
{
	public struct AddSpriteStruct
	{
		public int idx;

		public Vector2 loc;

		public Vector2 traj;

		public float size;

		public int flags;

		public int owner;

		public bool netInduced;
	}

	public const int MAX_SRITES = 2048;

	public const int MAX_REFRACT_SPRITES = 32;

	public const bool THREADED = false;

	private Sprite[] sprite;

	private HitManager hitManager;

	public WallBlood[] wallBlood;

	private Sprite[] refractSprite;

	public GoreInstanceMgr goreInstanceMgr;

	private CamSplat[] camSplat;

	private float camSplatRecharge;

	public SpriteCatalog catalog;

	public Gib[] gib;

	public int totalSprites;

	public bool canBloodArc;

	private NetSprite[] netSprite;

	public Thread spriteThread;

	public float spriteThreadFrame;

	public SpriteRand spriteRand;

	private AddSpriteStruct[] addSprite = new AddSpriteStruct[256];

	public void KickBurst(Vector2 loc, int owner, int victim)
	{
		hitManager.KickBurst(loc, owner, victim);
	}

	public void KickBurst(Vector2 loc, int owner, int victim, float val)
	{
		hitManager.KickBurst(loc, owner, victim, val);
	}

	public void TrimSprite(Sprite s)
	{
		if (totalSprites > 200)
		{
			s.frame -= FMan.frameTime;
		}
		if (totalSprites > 250)
		{
			s.frame -= FMan.frameTime;
		}
		if (totalSprites > 300)
		{
			s.frame -= FMan.frameTime;
		}
		if (totalSprites > 350)
		{
			s.frame -= FMan.frameTime;
		}
	}

	public bool CheckVis(Vector2 i, Vector2 j, Map map)
	{
		j -= new Vector2(0f, 30f);
		i -= new Vector2(0f, 30f);
		Vector2 vector = j - i;
		int num = (int)(vector.Length() / 20f) + 2;
		for (int k = 1; k < num; k++)
		{
			float num2 = (float)k / (float)num;
			Vector2 v = i + vector * num2;
			if (map.TestCol(v))
			{
				return false;
			}
		}
		return true;
	}

	private int CheckDrip(Vector2 loc, Map map)
	{
		for (int num = map.layer[2].segment.Length - 1; num >= 0; num--)
		{
			if (map.layer[2].segment[num] != null)
			{
				Rectangle rect = map.layer[2].segment[num].rect;
				if (loc.X > (float)rect.X && loc.Y > (float)rect.Y && loc.X < (float)rect.Right && loc.Y < (float)rect.Bottom)
				{
					switch (Game1.segDefMgr.segDef[map.layer[2].segment[num].idx].flags)
					{
					case 64:
					case 65:
					case 66:
						Game1.gameMap.SplashPortrait(Game1.segDefMgr.segDef[map.layer[2].segment[num].idx].flags);
						return 2;
					case 1:
					case 9:
					case 10:
					case 11:
					case 13:
					case 16:
					case 17:
					case 22:
					case 56:
					case 57:
					case 58:
					case 59:
					case 60:
						return 2;
					default:
						return 1;
					}
				}
			}
		}
		return 1;
	}

	private void ThreadedUpdate()
	{
		while (!Game1.mustExit)
		{
			if (spriteThreadFrame > 0f)
			{
				try
				{
					lock (sprite)
					{
						UpdateSprites(Game1.character, Game1.gameMap.CurMap());
						UpdateCharacterThreadables();
					}
				}
				catch (Exception ex)
				{
					Printf.WriteLine(ex.StackTrace);
				}
				Thread.Sleep((int)(spriteThreadFrame * 1000f));
			}
			else
			{
				Thread.Sleep(10);
			}
		}
	}

	private void UpdateCharacterThreadables()
	{
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (!Game1.character[i].exists)
			{
				continue;
			}
			lock (Game1.character[i])
			{
				Game1.character[i].charAnim.UpdateThreadables(Game1.character[i]);
				if (Game1.character[i].charUpdate.thermop <= 0f)
				{
					Game1.character[i].CalculateShadows();
				}
				Game1.character[i].UpdateRects();
			}
		}
	}

	public void Update(Character[] c, Map map)
	{
		UpdateSprites(c, map);
		hitManager.Update(this, sprite, c, map);
		spriteThreadFrame = FMan.realTime;
	}

	private void UpdateSprites(Character[] c, Map map)
	{
		canBloodArc = true;
		ProcessAddSprites();
		if (Game1.hud.IsEndLevel() || Game1.hud.IsArcadeIn())
		{
			return;
		}
		if (Game1.gameMap.wallBlood)
		{
			AddWallblood(Rand.GetRandomVec2(-600f, 600f, -400f, 400f) + ScrollManager.scroll);
		}
		totalSprites = 0;
		for (int i = 0; i < sprite.Length; i++)
		{
			if (sprite[i].exists)
			{
				totalSprites++;
				catalog.spriteDef[sprite[i].type].Update(sprite[i], this);
				if (sprite[i].frame <= 0f)
				{
					sprite[i].exists = false;
				}
			}
		}
		for (int j = 0; j < refractSprite.Length; j++)
		{
			if (refractSprite[j].exists)
			{
				catalog.spriteDef[refractSprite[j].type].Update(refractSprite[j], this);
				if (refractSprite[j].frame <= 0f)
				{
					refractSprite[j].exists = false;
				}
			}
		}
		DebugManager.totalSprites = totalSprites;
		if (camSplatRecharge > 0f)
		{
			camSplatRecharge -= FMan.frameTime;
		}
		for (int k = 0; k < camSplat.Length; k++)
		{
			camSplat[k].Update();
		}
		int num = 0;
		lock (gib)
		{
			for (int l = 0; l < gib.Length; l++)
			{
				if (gib[l].exists)
				{
					gib[l].Update(this);
					if (gib[l].frame > 1f)
					{
						num++;
					}
				}
			}
		}
		if (num > gib.Length / 2)
		{
			int randomInt = Rand.GetRandomInt(0, gib.Length);
			if (gib[randomInt].exists && gib[randomInt].frame > 1f)
			{
				gib[randomInt].frame = 1f;
			}
		}
		int num2 = 0;
		for (int m = 0; m < wallBlood.Length; m++)
		{
			if (wallBlood[m].exists)
			{
				num2++;
			}
		}
		bool flag = false;
		for (int n = 4; n < Game1.character.Length; n++)
		{
			if (Game1.character[n].exists)
			{
				flag = true;
				break;
			}
		}
		for (int num3 = 0; num3 < wallBlood.Length; num3++)
		{
			if (!wallBlood[num3].exists)
			{
				continue;
			}
			if (wallBlood[num3].dripTest == 0)
			{
				wallBlood[num3].dripTest = 1;
				if (CheckDrip(wallBlood[num3].loc, map) == 2)
				{
					wallBlood[num3].dripTest = 2;
					if (CheckDrip(wallBlood[num3].loc + new Vector2(0f, 50f), map) == 2)
					{
						wallBlood[num3].dripTest = 3;
					}
				}
			}
			if (flag)
			{
				if (num2 < wallBlood.Length / 2)
				{
					if (num3 % 2 == 0)
					{
						if (wallBlood[num3].frame < 1f || wallBlood[num3].frame > 3f)
						{
							wallBlood[num3].Update();
						}
					}
					else
					{
						wallBlood[num3].Update();
					}
				}
				else
				{
					wallBlood[num3].Update();
				}
			}
			else if (wallBlood[num3].frame < 1f || wallBlood[num3].frame > 3f)
			{
				wallBlood[num3].Update();
			}
		}
	}

	public void GoreSplode(Vector2 location, int ID)
	{
		Game1.gameMap.goresploded = 0.995f;
		for (int i = 0; i < 10; i++)
		{
			Vector2 randomVec = Rand.GetRandomVec2(-1100f, 1100f, -1100f, 1100f);
			AddSprite(7, location + randomVec * 0.04f, randomVec, 11f, Rand.CointToss(0.95f) ? 1 : 0, ID);
		}
		for (int j = 0; j < 20; j++)
		{
			Vector2 randomVec = Rand.GetRandomVec2(-1100f, 1100f, -1100f, 1100f);
			AddSprite(31, location + randomVec * 0.04f, randomVec, Rand.GetRandomFloat(1f, 3f), Rand.CointToss(0.85f) ? 1 : 0, ID);
		}
		for (int k = 0; k < 20; k++)
		{
			Vector2 randomVec = Rand.GetRandomVec2(-1500f, 1500f, -1500f, 1500f);
			AddSprite(8, location + randomVec * 0.04f, randomVec, Rand.GetRandomFloat(1f, 3f), Rand.CointToss(0.85f) ? 1 : 0, ID);
		}
		for (int l = 0; l < 30; l++)
		{
			Vector2 randomVec = Rand.GetRandomVec2(-1800f, 1800f, -1800f, 1800f);
			AddSprite(9, location + randomVec * 0.04f, randomVec, Rand.GetRandomFloat(0.1f, 2f), Rand.CointToss(0.55f) ? 1 : 0, ID);
		}
	}

	public void DrawWallBlood(SpriteBatch spriteBatch, Texture2D spritesTex)
	{
		for (int i = 0; i < wallBlood.Length; i++)
		{
			if (wallBlood[i].exists)
			{
				wallBlood[i].Draw(spriteBatch, spritesTex);
			}
		}
		if (Game1.gameMap.CurMap().isBlood)
		{
			Game1.gameMap.CurMap().DrawMapBlood(spriteBatch, Game1.mapsTex);
		}
		if (Game1.gameMap.goresploded >= 1f)
		{
			spriteBatch.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(new Vector2((float)Game1.gameMap.CurMap().xSize * 64f * 0.5f, (float)Game1.gameMap.CurMap().ySize * 64f * 0.5f), 1f), new Rectangle(768, 256, 128, 128), new Color(1f, 0f, 0f, 1f), 1f, new Vector2(64f, 64f), 16f * ScrollManager.zoom, SpriteEffects.None, 1f);
			spriteBatch.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(new Vector2((float)Game1.gameMap.CurMap().xSize * 64f * 0.5f, (float)Game1.gameMap.CurMap().ySize * 64f * 0.5f), 1f), new Rectangle(0, 0, 128, 64), new Color(1f, 0f, 0f, 1f), 0f, new Vector2(64f, 32f), new Vector2(12f, 32f) * ScrollManager.zoom, SpriteEffects.None, 1f);
		}
	}

	public void DrawCamsplats(SpriteBatch spriteBatch, int threedee)
	{
		for (int i = 0; i < camSplat.Length; i++)
		{
			if (camSplat[i].exists && camSplat[i].refract)
			{
				camSplat[i].Draw(spriteBatch, threedee);
			}
		}
		if (Game1.gameMap.goresploded >= 1f && Game1.gameMap.goresploded < 2f)
		{
			spriteBatch.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f + new Vector2(0f, (Game1.gameMap.goresploded - 1f) * 280f), new Rectangle(768, 256, 128, 128), new Color(1f, 0f, 0f, (2f - Game1.gameMap.goresploded) * 2f), 0f, new Vector2(64f, 64f), new Vector2(5f, 5f + (Game1.gameMap.goresploded - 1f) * 2f) * 4f, SpriteEffects.None, 1f);
		}
	}

	public void DrawAlphaCamsplats(SpriteBatch spriteBatch, int threedee)
	{
		for (int i = 0; i < camSplat.Length; i++)
		{
			if (camSplat[i].exists && !camSplat[i].refract)
			{
				camSplat[i].Draw(spriteBatch, threedee);
			}
		}
		if (Game1.gameMap.goresploded >= 1f && Game1.gameMap.goresploded < 2f)
		{
			spriteBatch.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f + new Vector2(0f, (Game1.gameMap.goresploded - 1f) * 280f), new Rectangle(768, 256, 128, 128), new Color(0.8f, 0f, 0f, (2f - Game1.gameMap.goresploded) * 1f), 0f, new Vector2(64f, 64f), new Vector2(5f, 5f + (Game1.gameMap.goresploded - 1f) * 2f) * 4f, SpriteEffects.None, 1f);
		}
	}

	public void Draw(SpriteBatch spriteBatch, Texture2D spritesTex)
	{
		for (int i = 0; i < sprite.Length; i++)
		{
			if (sprite[i].exists && !sprite[i].alpha && !sprite[i].thresh && !sprite[i].subtractive)
			{
				catalog.spriteDef[sprite[i].type].Draw(sprite[i], spriteBatch, spritesTex);
			}
		}
	}

	public void DrawSubtract(SpriteBatch spriteBatch, Texture2D spritesTex)
	{
		for (int i = 0; i < sprite.Length; i++)
		{
			if (sprite[i].exists && !sprite[i].alpha && !sprite[i].thresh && sprite[i].subtractive)
			{
				catalog.spriteDef[sprite[i].type].Draw(sprite[i], spriteBatch, spritesTex);
			}
		}
	}

	public void DrawGibs(SpriteBatch spriteBatch, Texture2D spritesTex, bool grounded)
	{
		lock (gib)
		{
			for (int i = 0; i < gib.Length; i++)
			{
				if (gib[i].exists && gib[i].grounded == grounded)
				{
					gib[i].Draw(spriteBatch, spritesTex);
				}
			}
		}
	}

	public void DrawGibTrails(SpriteBatch spriteBatch, Texture2D spritesTex)
	{
		for (int i = 0; i < gib.Length; i++)
		{
			if (gib[i].exists)
			{
				gib[i].DrawTrail(spriteBatch, spritesTex);
			}
		}
	}

	public void AddWallblood(Vector2 loc)
	{
		AddWallblood(loc, splatNow: false);
	}

	public void AddWallblood(Vector2 loc, bool splatNow)
	{
		for (int i = 0; i < wallBlood.Length; i++)
		{
			if (wallBlood[i].exists && (loc - wallBlood[i].loc).LengthSquared() < 800f)
			{
				return;
			}
		}
		for (int j = 0; j < wallBlood.Length; j++)
		{
			if (!wallBlood[j].exists)
			{
				wallBlood[j].Init(loc);
				if (splatNow)
				{
					wallBlood[j].frame = 9.8f;
				}
				break;
			}
		}
	}

	public void MakeMiniBloodSplode(Vector2 loc, int owner)
	{
		for (int i = 0; i < 8; i++)
		{
			Vector2 randomVec = Rand.GetRandomVec2(-600f, 600f, -600f, 600f);
			AddSprite(31, loc + randomVec * 0.01f, randomVec, Rand.GetRandomFloat(1f, 3f), i % 2, owner);
			Vector2 randomVec2 = Rand.GetRandomVec2(-600f, 600f, -600f, 600f);
			AddSprite(8, loc + randomVec2 * 0.04f, randomVec2, Rand.GetRandomFloat(0.5f, 1f), i % 2, owner);
		}
		for (int j = 0; j < 2; j++)
		{
			AddGib(loc + new Vector2(0f, 30f), Rand.GetRandomVec2(-700f, 700f, -700f, 400f), 0, 0, 0, 0, 0, 0, null, null, 0.35f, Game1.gameMap.CurMap(), 4, 0, owner, -1);
		}
	}

	public void DrawAlpha(SpriteBatch spriteBatch, Texture2D spritesTex)
	{
		for (int i = 0; i < sprite.Length; i++)
		{
			if (sprite[i].exists && sprite[i].alpha && !sprite[i].thresh)
			{
				catalog.spriteDef[sprite[i].type].Draw(sprite[i], spriteBatch, spritesTex);
			}
		}
	}

	public void DrawThresh(SpriteBatch spriteBatch, Texture2D spritesTex)
	{
		for (int i = 0; i < sprite.Length; i++)
		{
			if (sprite[i].exists && sprite[i].thresh)
			{
				catalog.spriteDef[sprite[i].type].Draw(sprite[i], spriteBatch, spritesTex);
				int type = sprite[i].type;
				if (type != 13 && type != 16)
				{
					GameRender.threshRender.AddPoint(ScrollManager.GetScreenLoc(sprite[i].loc, 1f), 20f);
				}
			}
		}
		DrawGibTrails(spriteBatch, spritesTex);
		lock (Game1.character)
		{
			Character[] character = Game1.character;
			foreach (Character character2 in character)
			{
				if (character2.exists && character2.charAnim.charTrigs.hasGibSpray && (character2.charAnim.charTrigs.sprayType == CharTrigs.SprayType.Blood || character2.charAnim.charTrigs.sprayType == CharTrigs.SprayType.Giantblood || character2.charAnim.charTrigs.sprayType == CharTrigs.SprayType.WeaponSpray) && !character2.charUpdate.charGrab.grabbing)
				{
					character2.charAnim.DrawCharGiblets(spriteBatch, thresh: true);
				}
			}
		}
	}

	public SpriteManager()
	{
		goreInstanceMgr = new GoreInstanceMgr();
		sprite = new Sprite[2048];
		refractSprite = new Sprite[32];
		netSprite = new NetSprite[64];
		for (int i = 0; i < netSprite.Length; i++)
		{
			netSprite[i] = new NetSprite();
		}
		for (int j = 0; j < addSprite.Length; j++)
		{
			addSprite[j].idx = -1;
		}
		spriteRand = new SpriteRand();
		wallBlood = new WallBlood[256];
		gib = new Gib[32];
		hitManager = new HitManager();
		catalog = new SpriteCatalog();
		camSplat = new CamSplat[64];
		for (int k = 0; k < camSplat.Length; k++)
		{
			camSplat[k] = new CamSplat();
		}
		for (int l = 0; l < wallBlood.Length; l++)
		{
			wallBlood[l] = new WallBlood();
			wallBlood[l].exists = false;
		}
		for (int m = 0; m < sprite.Length; m++)
		{
			sprite[m] = new Sprite();
			sprite[m].exists = false;
		}
		for (int n = 0; n < refractSprite.Length; n++)
		{
			refractSprite[n] = new Sprite();
			refractSprite[n].exists = false;
		}
		for (int num = 0; num < gib.Length; num++)
		{
			gib[num] = new Gib(num);
		}
	}

	public void AddCamsplat(CamSplat.CamSplatType type)
	{
		for (int i = 0; i < 32; i++)
		{
			if (!camSplat[i].exists)
			{
				Vector2 randomVec = Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, 0f, ScrollManager.screenSize.Y);
				if (!((randomVec - ScrollManager.screenSize / 2f).LengthSquared() < 50000f))
				{
					camSplat[i].Init(Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, 0f, ScrollManager.screenSize.Y), type);
					camSplatRecharge = Rand.GetRandomFloat(0f, 0.1f);
				}
				break;
			}
		}
	}

	public int AddGib(Vector2 loc, Vector2 traj, int face, int headTex, int torsoTex, int legsTex, int weaponTex, int charDef, string flyAnim, string landAnim, float size, Map map, int gibType, int sparks, int owner, int hitOwner)
	{
		if (sparks == 2)
		{
			for (int i = 0; i < 3; i++)
			{
				Game1.spriteMan.AddCamsplat(CamSplat.CamSplatType.Dust);
			}
		}
		else
		{
			switch (gibType)
			{
			default:
				if (loc.X > ScrollManager.GetRealLoc(default, 1f).X && loc.X < ScrollManager.GetRealLoc(ScrollManager.screenSize, 1f).X)
				{
					for (int j = 0; j < 3; j++)
					{
						Game1.spriteMan.AddCamsplat(CamSplat.CamSplatType.Blood);
					}
				}
				break;
			case 5:
			case 6:
				break;
			}
		}
		for (int k = 0; k < gib.Length; k++)
		{
			if (!gib[k].exists)
			{
				lock (gib[k])
				{
					gib[k].Init(loc, traj, face, headTex, torsoTex, legsTex, weaponTex, charDef, flyAnim, landAnim, size, map, gibType, sparks, owner, hitOwner);
					return k;
				}
			}
		}
		return -1;
	}

	public void AddNetSprite(int idx, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		for (int i = 0; i < netSprite.Length; i++)
		{
			if (!netSprite[i].exists)
			{
				netSprite[i].Init(idx, loc, traj, size, flags, owner);
				break;
			}
		}
	}

	public void WriteNetSprites(PacketWriter writer)
	{
		if (Game1.netSession.netGame.IsPanic())
		{
			for (int i = 0; i < netSprite.Length; i++)
			{
				netSprite[i].exists = false;
			}
			return;
		}
		for (int j = 0; j < netSprite.Length; j++)
		{
			if (netSprite[j].exists)
			{
				netSprite[j].Write(writer);
			}
		}
	}

	public void AddSprite(int idx, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		AddSprite(idx, loc, traj, size, flags, owner, netInduced: false);
	}

	public void AddSprite(int idx, Vector2 loc, Vector2 traj, float size, int flags, int owner, bool netInduced)
	{
		if (Game1.hud.IsEndLevel() || Game1.hud.IsArcadeIn())
		{
			return;
		}
		for (int i = 0; i < addSprite.Length; i++)
		{
			if (addSprite[i].idx == -1)
			{
				addSprite[i].idx = idx;
				addSprite[i].loc = loc;
				addSprite[i].traj = traj;
				addSprite[i].size = size;
				addSprite[i].flags = flags;
				addSprite[i].owner = owner;
				addSprite[i].netInduced = netInduced;
				break;
			}
		}
	}

	private void ProcessAddSprites()
	{
		for (int i = 0; i < addSprite.Length; i++)
		{
			if (addSprite[i].idx <= -1)
			{
				continue;
			}
			int idx = addSprite[i].idx;
			Vector2 loc = addSprite[i].loc;
			Vector2 traj = addSprite[i].traj;
			float size = addSprite[i].size;
			int flags = addSprite[i].flags;
			int owner = addSprite[i].owner;
			bool netInduced = addSprite[i].netInduced;
			addSprite[i].idx = -1;
			bool flag = true;
			if (idx == 4)
			{
				if (!canBloodArc)
				{
					flag = false;
				}
				canBloodArc = false;
			}
			if (!flag)
			{
				continue;
			}
			for (int j = 0; j < sprite.Length; j++)
			{
				if (sprite[j].exists)
				{
					continue;
				}
				sprite[j].thresh = false;
				sprite[j].alpha = false;
				sprite[j].hitter = false;
				sprite[j].netIgnore = true;
				sprite[j].subtractive = true;
				catalog.spriteDef[idx].Init(sprite[j], loc, traj, size, flags, owner);
				sprite[j].exists = true;
				sprite[j].type = idx;
				if (sprite[j].hitter)
				{
					sprite[j].netIgnore = false;
				}
				if (sprite[j].netIgnore || netInduced)
				{
					break;
				}
				if (Game1.netSession.IsHost())
				{
					if (owner != 1 && owner != 3)
					{
						AddNetSprite(idx, loc, traj, size, flags, owner);
					}
					else
					{
						sprite[j].exists = false;
					}
				}
				else if (Game1.netSession.IsClient())
				{
					if (owner == 1 || owner == 3)
					{
						AddNetSprite(idx, loc, traj, size, flags, owner);
					}
					else
					{
						sprite[j].exists = false;
					}
				}
				break;
			}
		}
	}

	public void AddRefractSprite(int idx, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		for (int i = 0; i < refractSprite.Length; i++)
		{
			if (!refractSprite[i].exists)
			{
				refractSprite[i].thresh = false;
				refractSprite[i].alpha = false;
				refractSprite[i].hitter = false;
				catalog.spriteDef[idx].Init(refractSprite[i], loc, traj, size, flags, owner);
				refractSprite[i].exists = true;
				refractSprite[i].type = idx;
				break;
			}
		}
	}

	public void MakeHitSplash(Vector2 loc, Vector2 traj, float mag)
	{
		traj.Normalize();
		traj *= 8f;
		Game1.killManager.doBits(mag);
	}

	public Vector2 GetTrajFromFaceRot(int face, float rotation)
	{
		if (face == 1)
		{
			return new Vector2((float)Math.Cos(rotation) * 32f, (float)Math.Sin(rotation) * 32f);
		}
		return new Vector2((float)Math.Cos(rotation) * -32f, (float)Math.Sin(rotation) * -32f);
	}

	public void MakeSplatter(Vector2 location, float rotation, int reps, int sparks, int owner)
	{
		MakeSplatter(location, rotation, reps, sparks, hammerStuff: false, owner);
	}

	public void MakeSplatter(Vector2 location, float rotation, int reps, int sparks, bool hammerStuff, int owner)
	{
		MakeSquirt(location + Rand.GetRandomVec2(-18f, 18f, -18f, 18f), GetTrajFromFaceRot(Rand.GetRandomInt(0, 2), rotation) * Rand.GetRandomFloat(0f, 0.25f) + Rand.GetRandomVec2(-1f, 1f, -1f, 1f), sparks, owner);
		for (int i = 0; i < reps; i++)
		{
			MakeJunk(location + Rand.GetRandomVec2(-18f, 18f, -18f, 18f), GetTrajFromFaceRot(Rand.GetRandomInt(0, 2), rotation) * Rand.GetRandomFloat(0f, 0.25f) + Rand.GetRandomVec2(-1f, 1f, -1f, 1f), sparks, owner);
			if (hammerStuff)
			{
				AddSprite(46, location + Rand.GetRandomVec2(-12f, 12f, -12f, 12f), GetTrajFromFaceRot(Rand.GetRandomInt(0, 2), rotation) * Rand.GetRandomFloat(0f, 30f) + Rand.GetRandomVec2(-1f, 1f, -1f, 1f), 0f, 0, 1);
			}
		}
	}

	public void MakeSquirt(Vector2 location, Vector2 traj, int owner)
	{
		MakeSquirt(location, traj, 0, owner);
	}

	public void MakeSquirt(Vector2 location, Vector2 traj, int spark, int owner)
	{
		MakeSquirt(location, traj, spark, 3, owner);
	}

	public void MakeSquirt(Vector2 location, Vector2 traj, int spark, int reps, int owner)
	{
		if (spark == 3)
		{
			return;
		}
		for (int i = 0; i < reps; i++)
		{
			if (spark == 2)
			{
				AddSprite(0, location, traj * Rand.GetRandomFloat(50f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.5f, 1f), 1, owner);
				AddSprite(0, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 0.8f), 1, owner);
				AddSprite(0, location, traj * Rand.GetRandomFloat(10f, 100f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 0.4f), 1, owner);
				AddSprite(18, location, traj * Rand.GetRandomFloat(10f, 50f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.3f, 0.8f), 1, owner);
				AddSprite(0, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 1.2f), 0, owner);
				continue;
			}
			AddSprite(9, location, traj * Rand.GetRandomFloat(50f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.5f, 1f), Rand.CointToss(0.25f) ? 1 : 0, owner);
			AddSprite(8, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 0.8f), Rand.CointToss(0.25f) ? 1 : 0, owner);
			AddSprite(5, location, traj * Rand.GetRandomFloat(10f, 100f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 0.4f), 1, owner);
			AddSprite(6, location, traj * Rand.GetRandomFloat(10f, 50f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.3f, 0.8f), 0, owner);
			AddSprite(8, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 1.2f), 0, owner);
			if (Rand.CointToss(0.7f))
			{
				AddSprite(7, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.5f, 3f), 1, owner);
			}
		}
		if (spark != 1)
		{
			return;
		}
		Vector2 vector = traj;
		vector.Normalize();
		vector *= 8f;
		for (int j = 0; j < 3; j++)
		{
			if (Rand.GetRandomFloat(0f, 1f) < 0.4f)
			{
				AddSprite(0, location + vector * Rand.GetRandomFloat(2f, 4f), vector * Rand.GetRandomFloat(20f, 150f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.3f, 0.8f), 1, owner);
			}
		}
	}

	public void MakeJunk(Vector2 location, Vector2 traj, int spark, int owner)
	{
		MakeJunk(location, traj, spark, 1f, owner);
	}

	public void MakeJunk(Vector2 location, Vector2 traj, int spark, float size, int owner)
	{
		if (spark == 2)
		{
			AddSprite(0, location, traj * Rand.GetRandomFloat(50f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.5f, 1f), 1, owner);
			AddSprite(0, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 0.8f), 1, owner);
			AddSprite(0, location, traj * Rand.GetRandomFloat(10f, 100f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 0.4f), 1, owner);
			AddSprite(18, location, traj * Rand.GetRandomFloat(10f, 50f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.3f, 0.8f), 1, owner);
			AddSprite(0, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 1.2f), 0, owner);
		}
		else
		{
			AddSprite(9, location, traj * Rand.GetRandomFloat(50f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.5f, 1f) * size, 0, owner);
			if (Rand.CointToss(0.1f))
			{
				AddSprite(8, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 0.8f) * size, Rand.CointToss(0.25f) ? 1 : 0, owner);
			}
			if (Rand.CointToss(0.1f))
			{
				AddSprite(5, location, traj * Rand.GetRandomFloat(10f, 100f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 0.4f), 1, owner);
			}
			if (Rand.CointToss(0.1f))
			{
				AddSprite(6, location, traj * Rand.GetRandomFloat(10f, 50f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.3f, 0.8f), 0, owner);
			}
			if (Rand.CointToss(0.4f))
			{
				AddSprite(8, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.2f, 1.2f) * size, 0, owner);
			}
			if (Rand.CointToss(0.15f))
			{
				AddSprite(7, location, traj * Rand.GetRandomFloat(10f, 200f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.5f, 3f) * size, 1, owner);
			}
			AddSprite(31, location, traj * Rand.GetRandomFloat(50f, 100f) + Rand.GetRandomVec2(-50f, 50f, -50f, 50f), Rand.GetRandomFloat(0.5f, 1.2f) * size, 1, owner);
			AddSprite(31, location, traj * Rand.GetRandomFloat(50f, 100f) + Rand.GetRandomVec2(-50f, 50f, -50f, 50f), Rand.GetRandomFloat(0.5f, 1.5f) * size, 0, owner);
		}
		if (spark == 1)
		{
			Vector2 vector = traj;
			vector.Normalize();
			vector *= 8f;
			if (Rand.GetRandomFloat(0f, 1f) < 0.4f)
			{
				AddSprite(0, location + vector * Rand.GetRandomFloat(2f, 4f), vector * Rand.GetRandomFloat(20f, 50f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.3f, 0.8f), 1, owner);
			}
		}
	}

	public void MakeMuzzleFlash(Vector2 location, Vector2 traj, int owner)
	{
		for (int i = 0; i < 10; i++)
		{
			AddSprite(10, location + traj * i * 0.15f, traj * (12f - (float)i), (1f - (float)i / 13f) * 0.45f, 0, owner);
		}
	}

	internal void AddGib(Vector2 loc, int face, int headTex, int torsoTex, int legsTex, int weaponTex, int charDef, string flyAnim, int landAnim, float size, Map map, int owner)
	{
		for (int i = 0; i < gib.Length; i++)
		{
			if (!gib[i].exists)
			{
				lock (gib[i])
				{
					gib[i].Init(loc, face, headTex, torsoTex, legsTex, weaponTex, charDef, flyAnim, landAnim, size, map, owner);
					break;
				}
			}
		}
	}

	internal void Reset()
	{
		for (int i = 0; i < sprite.Length; i++)
		{
			sprite[i].exists = false;
		}
		for (int j = 0; j < wallBlood.Length; j++)
		{
			wallBlood[j].exists = false;
		}
		for (int k = 0; k < gib.Length; k++)
		{
			gib[k].exists = false;
		}
		for (int l = 0; l < addSprite.Length; l++)
		{
			addSprite[l].idx = -1;
		}
		goreInstanceMgr.RestoreInstances();
	}

	internal void MakeExplosion(Vector2 loc, int owner, float mag, bool splash)
	{
		if (splash)
		{
			AddSprite(20, loc, default, 150f, 0, owner);
		}
		QuakeManager.SetBright(0.1f + mag / 30f);
		Vector2 screenLoc = ScrollManager.GetScreenLoc(loc, 1f);
		if (screenLoc.X > 0f && screenLoc.Y > 0f && screenLoc.X < ScrollManager.screenSize.X && screenLoc.Y < ScrollManager.screenSize.Y)
		{
			QuakeManager.SetBurst(mag * 0.15f, screenLoc);
		}
		for (int i = 0; i < 3; i++)
		{
			AddSprite(16, loc, spriteRand.GetRandomVec2(-500f, 500f, -400f, 400f) * (mag / 3f), spriteRand.GetRandomFloat(mag, mag * 2f) * 0.7f, 0, owner);
		}
		for (int j = 0; j < 6 + (int)(mag * 4f); j++)
		{
			for (int k = 0; k < 3; k++)
			{
				float randomFloat = Rand.GetRandomFloat(0f, 6.28f);
				float num = Rand.GetRandomFloat(0f, 1200f * ((1f + mag) / 6f)) * (1f + (float)k / 4f);
				AddSprite(99, loc, new Vector2((float)Math.Cos(randomFloat) * num, (float)Math.Sin(randomFloat) * num), (k == 0) ? (Rand.GetRandomFloat(0.125f, 0.25f) + (mag + 1f) / 10f) : (Rand.GetRandomFloat(0.125f, 0.25f) + (mag + 1f) / 50f), 0, owner);
			}
		}
		for (int l = 0; l < 24; l++)
		{
			AddSprite(0, loc, Rand.GetRandomVec2(-1000f, 1000f, -900f, 900f), Rand.GetRandomFloat(2f, 5f), 0, owner);
		}
		AddCamsplat(CamSplat.CamSplatType.Dust);
		if (mag > 2f)
		{
			for (int m = 0; m < 4; m++)
			{
				AddCamsplat(CamSplat.CamSplatType.Dust);
			}
			for (int n = 0; n < 8; n++)
			{
				AddGib(loc, Rand.GetRandomVec2(-500f, 500f, -1600f, 100f), 0, 0, 0, 0, 0, 1, null, null, 0f, Game1.gameMap.CurMap(), 5, 0, owner, -1);
			}
		}
		for (int num2 = 0; num2 < 3; num2++)
		{
			AddSprite(100, loc + Rand.GetRandomVec2(-10f, 10f, -10f, 10f) * mag, Rand.GetRandomVec2(-10f, 10f, -200f, 0f), Rand.GetRandomFloat(mag * 0.5f, mag), 0, owner);
		}
		QuakeManager.SetQuake(mag * 0.1f);
		Sound.PlaySnd(Sound.Category.FX, "bomb");
		Sound.PlaySnd(Sound.Category.FX, "bass");
	}

	internal void DrawRefract(SpriteBatch sprite)
	{
		for (int i = 0; i < refractSprite.Length; i++)
		{
			if (refractSprite[i].exists)
			{
				catalog.spriteDef[refractSprite[i].type].Draw(refractSprite[i], sprite, Game1.spritesTex);
			}
		}
	}

	internal void StopGib(int p)
	{
		if (gib[p].exists)
		{
			gib[p].hitOwner = -1;
			gib[p].traj.X *= -0.1f;
			gib[p].traj.Y = Rand.GetRandomFloat(-300f, 0f);
		}
	}

	internal void MakeLaserGlow(Vector2 location, Vector2 straj)
	{
		Game1.spriteMan.AddSprite(102, location, straj * 50f, 0.5f, 0, 0);
		Game1.spriteMan.AddSprite(102, location, straj * 150f, 0.15f, 0, 0);
		Sound.PlaySnd(Sound.Category.FX, "plasma");
	}

	internal void DrawSub(SpriteBatch sprite, Texture2D spritesTex)
	{
		DrawSubtract(sprite, spritesTex);
		for (int i = 0; i < gib.Length; i++)
		{
			if (gib[i].exists)
			{
				gib[i].DrawSubTrail(sprite, spritesTex);
			}
		}
	}
}
