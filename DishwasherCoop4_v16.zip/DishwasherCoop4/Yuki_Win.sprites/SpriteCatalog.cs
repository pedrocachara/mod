using Yuki_Win.sprites.bombs;
using Yuki_Win.sprites.debris;
using Yuki_Win.sprites.env;
using Yuki_Win.sprites.explosions;
using Yuki_Win.sprites.freakingLasers;
using Yuki_Win.sprites.glow;
using Yuki_Win.sprites.gore;
using Yuki_Win.sprites.guns;
using Yuki_Win.sprites.hit;
using Yuki_Win.sprites.items;
using Yuki_Win.sprites.magic;
using Yuki_Win.sprites.refract;
using Yuki_Win.sprites.rockets;
using Yuki_Win.sprites.rocks;
using Yuki_Win.sprites.thrown;
using Yuki_Win.sprites.triggers;
using Yuki_Win.sprites.warp;
using Yuki_Win.sprites.zaps;

namespace Yuki_Win.sprites;

public class SpriteCatalog
{
	public const int SPARK = 0;

	public const int BLASTBIT = 1;

	public const int BLASTINK = 2;

	public const int GLOW = 3;

	public const int BLOODARC = 4;

	public const int DROP = 5;

	public const int GLOB = 6;

	public const int GRISTLE = 7;

	public const int SPURT = 8;

	public const int SQUIRT = 9;

	public const int MUZZLEFLASH = 10;

	public const int VULCAN = 11;

	public const int HIT = 12;

	public const int WARPBIT = 13;

	public const int WARPSMOKEOUT = 14;

	public const int WHITESMOKE = 15;

	public const int EXPLODEFIRE = 16;

	public const int GRENADE = 17;

	public const int BLACKSMOKE = 18;

	public const int SMOKEFARM = 19;

	public const int SPLASH = 20;

	public const int BULLET = 21;

	public const int SPARKARC = 22;

	public const int ROCKET = 23;

	public const int HOMER = 24;

	public const int CYSPARK = 25;

	public const int FOG = 26;

	public const int DRIP = 27;

	public const int ENVGLOW = 28;

	public const int ASH = 29;

	public const int RAIN = 30;

	public const int JET = 31;

	public const int DISHWARPOUT = 32;

	public const int DISHWARPSMOKE = 33;

	public const int DISHWARPIN = 34;

	public const int BRASS = 35;

	public const int SHELL = 36;

	public const int SHOTTY = 37;

	public const int DRUM_MAG = 38;

	public const int UZI_MAG = 39;

	public const int FEATHER = 40;

	public const int CLOUDARC = 41;

	public const int CLOUDZAP = 42;

	public const int MIST = 43;

	public const int CIRCULARSAW = 44;

	public const int THROWNSHOTTY = 45;

	public const int HAMMERSTUFF = 46;

	public const int PICKUP = 47;

	public const int PICKUPBIT = 48;

	public const int CONFETTI = 49;

	public const int ICE = 50;

	public const int BLADEFARM = 51;

	public const int BLADE = 52;

	public const int SCYTHE = 53;

	public const int SCYTHETRAIL = 54;

	public const int GLASS = 55;

	public const int GLASS_SMOKE = 56;

	public const int MAGIC_SMASH = 57;

	public const int MAGIC_GLOW = 58;

	public const int MAGIC_LIGHTNING = 59;

	public const int MAGIC_CROSS = 60;

	public const int MAGIC_CROSS_FARM = 61;

	public const int MAGIC_SLASH = 62;

	public const int MAGIC_SLASH_FARM = 63;

	public const int MAGIC_HEALTH = 64;

	public const int MAGIC_HEALTH_GLOW = 65;

	public const int DRAGON_SPARK = 66;

	public const int GOLD = 67;

	public const int GOLD_FARM = 68;

	public const int REFRACT_CLOUD = 69;

	public const int REFRACT_DISHWARP = 70;

	public const int HEART = 71;

	public const int HEART_TRAIL = 72;

	public const int HEART_FARM = 73;

	public const int REFRACT_DISHWARPOUT = 74;

	public const int SKULL = 75;

	public const int SKULL_TRAIL = 76;

	public const int YUKI_WARP_REFRACT = 77;

	public const int YUKI_BLOOD_WARP = 78;

	public const int ZAP_SRC = 79;

	public const int ZAP_BALL = 80;

	public const int ZAP_BALL_SRC = 81;

	public const int ZAP_SMASH = 82;

	public const int ZAP_WAVE_FARM = 83;

	public const int ZAP_WAVE = 84;

	public const int REFRACT_ZAP = 85;

	public const int REFRACT_SHOCKWAVE = 86;

	public const int DRIPPY = 87;

	public const int REFRACT_DRIPPY = 88;

	public const int TANK_SMOKE = 89;

	public const int MOON_ROCK_FARM = 90;

	public const int MOON_ROCK = 91;

	public const int MOON_ROCK_BIT = 92;

	public const int CRYPT_ROCK_FARM = 93;

	public const int CRYPT_ROCK = 94;

	public const int CRYPT_ROCK_BIT = 95;

	public const int DAGGER = 96;

	public const int REFRACT_BLAST_GOO = 97;

	public const int GIB_HIT = 98;

	public const int STAR = 99;

	public const int DARK_SMOKE = 100;

	public const int LASER = 101;

	public const int LASER_SRC = 102;

	public const int DIRT_WALK_SMOKE = 103;

	public SpriteDef[] spriteDef = new SpriteDef[104]
	{
		new Spark(),
		new BlastBit(),
		new BlastInk(),
		new Glow(),
		new BloodArc(),
		new Drop(),
		new Glob(),
		new Gristle(),
		new Spurt(),
		new Squirt(),
		new MuzzleFlash(),
		new Vulcan(),
		new Hit(),
		new WarpBit(),
		new WarpSmokeOut(),
		new WhiteSmoke(),
		new ExplodeFire(),
		new Grenade(),
		new BlackSmoke(),
		new SmokeFarm(),
		new Splash(),
		new Bullet(),
		new SparkArc(),
		new Rocket(),
		new Homer(),
		new CySpark(),
		new Fog(),
		new Drip(),
		new EnvGlow(),
		new Ash(),
		null,
		new Jet(),
		new DishWarpOut(),
		new DishWarpSmoke(),
		new DishWarpIn(),
		new Brass(),
		new Shell(),
		new Shotty(),
		new DrumClip(),
		new UziMag(),
		new Feather(),
		new CloudArc(),
		new CloudZap(),
		new Mist(),
		new CircularSaw(),
		new ThrownShotty(),
		new HammerStuff(),
		new Pickup(),
		new PickupBit(),
		new Confetti(),
		new Ice(),
		new BladeFarm(),
		new Blade(),
		new Scythe(),
		new ScytheTrail(),
		new Glass(),
		new GlassSmoke(),
		new Smasher(),
		new Magicglow(),
		new MagicLightning(),
		new MagicCross(),
		new MagicCrossFarm(),
		new MagicSlash(),
		new MagicSlashFarm(),
		new MagicHealth(),
		new MagicHealthGlow(),
		new DragonSpark(),
		new Gold(),
		new GoldFarm(),
		new Cloud(),
		new DishWarpRefract(),
		new Heart(),
		new HeartTrail(),
		new HeartFarm(),
		new DishWarpOutRefract(),
		new Skull(),
		new SkullTrail(),
		new YukiWarpRefract(),
		new WarpBlood(),
		new ZapSrc(),
		new ZapBall(),
		new ZapBallSrc(),
		new ZapSmash(),
		new ZapWaveFarm(),
		new ZapWave(),
		new Zap(),
		new ShockWave(),
		new Drippy(),
		new Drippy(),
		new TankSmoke(),
		new MoonRockFarm(),
		new MoonRock(),
		new MoonRockBit(),
		new CryptRockFarm(),
		new CryptRock(),
		new CryptRockBit(),
		new Dagger(),
		new BlastGoo(),
		new GibHit(),
		new Star(),
		new DarkSmoke(),
		new Laser(),
		new LaserSrc(),
		new DirtWalkSmoke()
	};
}
