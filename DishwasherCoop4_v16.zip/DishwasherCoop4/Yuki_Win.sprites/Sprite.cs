using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites;

public class Sprite
{
	public bool exists;

	public int type;

	public Vector2 loc;

	public Vector2 traj;

	public Vector2 scaling;

	public float rotation;

	public float frame;

	public float size;

	public float z;

	public float r;

	public float g;

	public float b;

	public bool alpha;

	public bool thresh;

	public bool subtractive;

	public int flags;

	public float rDir;

	public int face;

	public int owner = -1;

	public bool wallFree;

	public bool hitter;

	public bool netIgnore = true;

	public bool needsNetSend;

	public virtual void Update(SpriteManager spriteMan)
	{
		frame -= FMan.frameTime;
		loc += traj * FMan.frameTime;
	}

	public virtual Vector2 GetLoc()
	{
		return loc;
	}

	public virtual Vector2 GetTraj()
	{
		return traj;
	}

	public virtual void Draw(SpriteBatch sprite, Texture2D spritesTex)
	{
	}
}
