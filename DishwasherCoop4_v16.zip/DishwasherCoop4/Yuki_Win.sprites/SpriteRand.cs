using System;
using Microsoft.Xna.Framework;

namespace Yuki_Win.sprites;

public class SpriteRand
{
	public Random rand;

	public SpriteRand()
	{
		rand = new Random();
	}

	public int GetRandomInt(int min, int max)
	{
		return min + (int)(rand.NextDouble() * (double)(max - min));
	}

	public Vector2 GetRandomVec2(float xMin, float xMax, float yMin, float yMax)
	{
		return new Vector2(GetRandomFloat(xMin, xMax), GetRandomFloat(yMin, yMax));
	}

	public Vector3 GetRandomVec3(float xMin, float xMax, float yMin, float yMax, float zMin, float zMax)
	{
		return new Vector3(GetRandomFloat(xMin, xMax), GetRandomFloat(yMin, yMax), GetRandomFloat(zMin, zMax));
	}

	public Vector4 GetRandomVec4(float xMin, float xMax, float yMin, float yMax, float zMin, float zMax, float wMin, float wMax)
	{
		return new Vector4(GetRandomFloat(xMin, xMax), GetRandomFloat(yMin, yMax), GetRandomFloat(zMin, zMax), GetRandomFloat(wMin, wMax));
	}

	public float GetRandomFloat(float min, float max)
	{
		return min + (float)(rand.NextDouble() * (double)(max - min));
	}

	public double GetRandomDouble(double min, double max)
	{
		return min + rand.NextDouble() * (max - min);
	}

	public bool CointToss(float chanceToSucceed)
	{
		if (GetRandomFloat(0f, 1f) < chanceToSucceed)
		{
			return true;
		}
		return false;
	}
}
