using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites;

public class SpriteDef
{
	public virtual void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.exists = true;
		p.subtractive = false;
	}

	public virtual void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.frameTime;
		p.loc += p.traj * FMan.frameTime;
	}

	public virtual void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
	}

	public virtual Vector2 GetLoc(Sprite p)
	{
		return p.loc;
	}

	public virtual Vector2 GetTraj(Sprite p)
	{
		return p.traj;
	}
}
