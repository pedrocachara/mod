using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;
using Yuki_Win.audio;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.sprites;
using Yuki_Win.world;

namespace Yuki_Win.chars;

public class CharAnim
{
	public int anim;

	public string animName;

	public int frameIdx;

	public float frame;

	private int key;

	public int charDef;

	public CharTrigs charTrigs;

	public CharScript charScript;

	public int charMeta;

	public float speedFac = 1f;

	public bool canCancel;

	public float smokeMachineFrame;

	public float smokeMachineLife;

	public float smokePlayFrame;

	private float sparkFrame;

	private float streamFrame;

	private float laserFrame;

	public int GetKey()
	{
		return key;
	}

	public CharAnim(int ID)
	{
		charTrigs = new CharTrigs(ID);
		charScript = new CharScript();
	}

	public void Init(int charDef, int cMeta, int ID)
	{
		this.charDef = charDef;
		charMeta = cMeta;
		sparkFrame = 0f;
		streamFrame = 0f;
		smokeMachineFrame = 0f;
		smokeMachineLife = 0f;
		smokePlayFrame = 0f;
		frameIdx = 0;
		frame = 0f;
		key = 0;
		anim = 0;
		charScript.Init();
		charTrigs.Init();
	}

	public void DrawCharGiblets(SpriteBatch sprite, bool thresh)
	{
		if (charTrigs.hasGibSpray && (charTrigs.sprayType == CharTrigs.SprayType.Blood || charTrigs.sprayType == CharTrigs.SprayType.Giantblood || charTrigs.sprayType == CharTrigs.SprayType.WeaponSpray))
		{
			charTrigs.DrawGiblets(sprite, thresh);
		}
	}

	public void Update(Character c, SpriteManager spriteMan, Map map)
	{
		if ((Game1.transMgr.outFrame > 0f && Game1.transMgr.direction != TransitionManager.TransitionDirection.Warp) || (Game1.transMgr.inFrame > 0f && (Game1.netSession.IsHost() || Game1.netSession.IsClient())))
		{
			return;
		}
		CharUpdate charUpdate = c.charUpdate;
		CharKeys charKeys = c.charKeys;
		CharMeta charMeta = Game1.charMeta[c.charMeta];
		charScript.UpdateGotos(c);
		Animation animation = Game1.charDef[charDef].GetAnimation(anim);
		if (animation == null)
		{
			animation = Game1.charDef[charDef].GetAnimation(0);
			key = 0;
			animName = animation.name;
			frame = 0f;
		}
		KeyFrame keyFrame = animation.GetKeyFrame(key);
		KeyFrame keyFrame2 = animation.GetKeyFrame(key);
		if (c.charUpdate.wait > 0f)
		{
			c.charUpdate.wait -= FMan.frameTime;
			return;
		}
		float num = speedFac;
		if ((charMeta.isSpeeder || charMeta.isBigSpeeder) && c.charUpdate.charGrab.grabbedByChar < 0)
		{
			float num2 = 1f - c.charUpdate.hp / c.charUpdate.mhp;
			if (num2 < 0f)
			{
				num2 = 0f;
			}
			if (num2 > 1f)
			{
				num2 = 1f;
			}
			num = ((!charMeta.isBigSpeeder) ? (num + num2 * 0.2f) : (num + num2 * 0.5f));
		}
		frame += FMan.frameTime * 30f * num;
		bool flag = false;
		int num3 = key - 1;
		if (c.charUpdate.charGrab.grabbedByChar > -1)
		{
			charTrigs.UpdateGrabberLoc(charUpdate.loc, 0.35f, 1 - charUpdate.face, c, charDef, GetCurFrame());
		}
		streamFrame -= FMan.frameTime;
		if (Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim) == null)
		{
			SetAnim(c.GetMeta().idle_anim, c.charUpdate, overRide: true);
		}
		if (Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(c.charAnim.GetKey()).lerp)
		{
			int num4 = c.charAnim.GetKey() + 1;
			if (num4 >= Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).getKeyFrameArray().Length)
			{
				num4 = 0;
			}
			else if (Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(num4) == null)
			{
				num4 = 0;
			}
			else if (Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(num4).duration <= 0)
			{
				num4 = 0;
			}
			_ = Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(num4).frameRef;
		}
		UpdateThreadables(c);
		if (frame > (float)keyFrame2.duration)
		{
			if (charUpdate.dyingFrame > 0f)
			{
				frame = keyFrame2.duration;
			}
			else
			{
				flag = true;
				charTrigs.UpdateTrigs(charUpdate.loc, 0.35f, charUpdate.face, GetCurFrame(), c, spriteMan, c.ID, map);
				frame -= keyFrame2.duration;
				key++;
				keyFrame2 = animation.GetKeyFrame(key);
				if (key >= animation.getKeyFrameArray().Length)
				{
					key = 0;
				}
				if (keyFrame2 != null)
				{
					charTrigs.CheckHasGibs(c.cDef, GetCurFrame());
				}
			}
		}
		if (keyFrame2 == null)
		{
			bool ethereal = c.charUpdate.ethereal;
			int num5 = anim;
			c.charUpdate.ethereal = false;
			key = 0;
			frame = 0f;
			if (!charScript.DoScript(keyFrame, this, charUpdate, this.charMeta, charKeys, c.ID))
			{
				EndAnim(charUpdate, charKeys);
			}
			else if (key != 0 && anim == num5)
			{
				c.charUpdate.ethereal = ethereal;
			}
			charScript.ClearGotos();
			if (charUpdate.dyingFrame > 0f)
			{
				key = num3;
			}
			charTrigs.CheckHasGibs(c.cDef, GetCurFrame());
		}
		else if (num3 > -1 && flag)
		{
			float dyingFrame = charUpdate.dyingFrame;
			charScript.DoScript(keyFrame, this, charUpdate, this.charMeta, charKeys, c.ID);
			if (charUpdate.dyingFrame >= 1f && dyingFrame <= 0f)
			{
				key = num3;
			}
		}
	}

	public void UpdateThreadables(Character c)
	{
		int next = -1;
		CharMeta meta = c.GetMeta();
		CharUpdate charUpdate = c.charUpdate;
		if (Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(c.charAnim.GetKey()).lerp)
		{
			int num = c.charAnim.GetKey() + 1;
			if (num >= Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).getKeyFrameArray().Length)
			{
				num = 0;
			}
			else if (Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(num) == null)
			{
				num = 0;
			}
			else if (Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(num).duration <= 0)
			{
				num = 0;
			}
			next = Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(num).frameRef;
		}
		if (streamFrame < 0f)
		{
			charTrigs.streamOffset += Rand.GetRandomFloat(0.1f, 0.5f);
			if (charTrigs.streamOffset > 6.28f)
			{
				charTrigs.streamOffset -= 6.28f;
			}
			streamFrame = 0.02f;
			charTrigs.CheckStream(charUpdate.loc, 0.35f, 1 - charUpdate.face, c, charDef, GetCurFrame(), next);
			if (c.charUpdate.drippy > 0f)
			{
				charTrigs.CheckDrips(charUpdate.loc, 0.35f, 1 - charUpdate.face, c, charDef, GetCurFrame(), next);
			}
		}
		if (c.GetMeta().isNeko || c.GetMeta().isCrow)
		{
			if (laserFrame <= 0f && c.charKeys.rVec.LengthSquared() > 0.09f)
			{
				charTrigs.CheckLasers(charUpdate.loc, 0.35f, 1 - charUpdate.face, c, charDef, GetCurFrame(), next);
				laserFrame = 0.2f;
			}
			laserFrame -= FMan.frameTime;
		}
		if (meta.isRobot)
		{
			charTrigs.hasGibSpray = false;
		}
		if (charTrigs.hasGibSpray)
		{
			charTrigs.UpdateGiblets(charDef, GetCurFrame(), 0.35f, charUpdate.loc, 1 - charUpdate.face, next, c);
		}
		if (meta.isDish)
		{
			charTrigs.CheckHeadTop(charUpdate.loc, 0.35f, 1 - charUpdate.face, c, charDef, GetCurFrame(), next);
		}
		if (meta.isGhost)
		{
			sparkFrame -= FMan.frameTime;
			if (sparkFrame < 0f)
			{
				sparkFrame = Rand.GetRandomFloat(0f, 0.1f);
				charTrigs.CheckGhostSmoke(charUpdate.loc, 0.35f, 1 - charUpdate.face, c, charDef, GetCurFrame());
			}
		}
		if (meta.isRobot || meta.isCyborg || meta.isJuicyRobot)
		{
			bool flag = false;
			if (meta.isJuggernaut)
			{
				if (c.charUpdate.hp <= 0f || c.charUpdate.giantVulnTimer > 0f)
				{
					flag = true;
				}
			}
			else if (c.charUpdate.hp < c.charUpdate.mhp / 4f)
			{
				flag = true;
			}
			if (flag)
			{
				float num2 = sparkFrame;
				sparkFrame -= FMan.frameTime;
				if (sparkFrame < 0f)
				{
					sparkFrame = Rand.GetRandomFloat(0f, 0.2f);
					charTrigs.CheckSparks(charUpdate.loc, 0.35f, 1 - charUpdate.face, c, charDef, GetCurFrame());
				}
				if ((int)(num2 * 40f) != (int)(sparkFrame * 40f) && c.charUpdate.dehealthified && !meta.isRobot && !meta.isJuicyRobot && c.charUpdate.state == CharUpdate.State.Airborne)
				{
					for (int i = 0; i < 5; i++)
					{
						Game1.spriteMan.AddSprite(7, c.charUpdate.loc + Rand.GetRandomVec2(-50f, 50f, -80f, -40f), Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(2f, 3f), Rand.CointToss(0.5f) ? 1 : 0, 0);
					}
				}
			}
		}
		if (smokeMachineLife > 0f && smokeMachineFrame <= 0f && charTrigs.CheckMachineSmoke(charUpdate.loc, 0.35f, 1 - charUpdate.face, c, charDef, GetCurFrame()))
		{
			smokeMachineFrame = Rand.GetRandomFloat(0.05f, 0.1f);
			if (smokePlayFrame <= 0f)
			{
				Sound.PlaySnd(Sound.Category.FX, "chainidle");
				smokePlayFrame = 1f;
			}
		}
		if (smokePlayFrame > 0f)
		{
			smokePlayFrame -= FMan.frameTime;
		}
	}

	public void NullUpdate(CharDef charDef)
	{
		Animation animation = charDef.GetAnimation(anim);
		KeyFrame keyFrame = animation.GetKeyFrame(key);
		KeyFrame keyFrame2 = animation.GetKeyFrame(key);
		frame += FMan.frameTime * 30f * speedFac;
		bool flag = false;
		int num = key - 1;
		streamFrame -= FMan.frameTime;
		if (frame > (float)keyFrame2.duration)
		{
			flag = true;
			frame -= keyFrame2.duration;
			key++;
			keyFrame2 = animation.GetKeyFrame(key);
			if (key >= animation.getKeyFrameArray().Length)
			{
				key = 0;
			}
		}
		if (keyFrame2 == null)
		{
			key = 0;
			frame = 0f;
			charScript.DoNullScript(keyFrame);
		}
		else if (num > -1 && flag)
		{
			charScript.DoNullScript(keyFrame);
		}
	}

	public void GotoFrame(int i)
	{
		charScript.ClearGotos();
		key = i;
		frame = 0f;
		canCancel = false;
	}

	public void JoyJump(CharKeys charKeys, CharUpdate charUpdate)
	{
		CharMeta charMeta = Game1.charMeta[this.charMeta];
		if (charKeys.keyRight)
		{
			charUpdate.traj.X = charMeta.speed;
		}
		if (charKeys.keyLeft)
		{
			charUpdate.traj.X = 0f - charMeta.speed;
		}
		charUpdate.traj.Y = 0f - charMeta.jump;
		charUpdate.state = CharUpdate.State.Airborne;
		charUpdate.traj.Y *= 1.2f;
	}

	private void EndAnim(CharUpdate charUpdate, CharKeys charKeys)
	{
		CharMeta charMeta = Game1.charMeta[this.charMeta];
		if (animName == charMeta.runstart_anim || animName == charMeta.altRunStart_anim)
		{
			if (charKeys.keyWalk)
			{
				SetAnim(charMeta.walk_anim, charUpdate);
			}
			else if (charKeys.keyJog)
			{
				SetAnim(charMeta.jog_anim, charUpdate);
			}
			else
			{
				SetAnim(charMeta.run_anim, charUpdate);
			}
		}
		else if (animName == charMeta.fturn_anim)
		{
			if (charMeta.isNeko || charMeta.isCrow)
			{
				SetAnim(charMeta.hover_anim, charUpdate);
			}
			else
			{
				SetAnim(charMeta.fly_anim, charUpdate);
			}
		}
		else if (animName == charMeta.runend_anim)
		{
			SetAnim(charMeta.idle_anim, charUpdate);
		}
		else if (animName == charMeta.land_anim)
		{
			SetAnim(charMeta.idle_anim, charUpdate);
		}
		else if (animName == charMeta.jump_anim)
		{
			SetAnim(charMeta.fly_anim, charUpdate);
			JoyJump(charKeys, charUpdate);
		}
		else if (animName == charMeta.hit_anim)
		{
			SetAnim(charMeta.idle_anim, charUpdate);
		}
		else if (animName == charMeta.takeoff_anim)
		{
			SetAnim(charMeta.hover_anim, charUpdate);
		}
		else if (animName == charMeta.launch_anim)
		{
			SetAnim(charMeta.flight_anim, charUpdate);
		}
		else if (animName == charMeta.fturn_anim)
		{
			SetAnim(charMeta.launch_anim, charUpdate);
		}
		else if (animName == charMeta.turn_anim || animName == charMeta.altturn_anim)
		{
			if (charUpdate.face == 1 && charKeys.keyRight)
			{
				if (CheckAnim(charMeta.runstart_anim) > -1)
				{
					SetAnim(charMeta.runstart_anim, charUpdate);
				}
				else
				{
					SetAnim(charMeta.run_anim, charUpdate);
				}
			}
			else if (charUpdate.face == 0 && charKeys.keyLeft)
			{
				if (CheckAnim(charMeta.runstart_anim) > -1)
				{
					SetAnim(charMeta.runstart_anim, charUpdate);
				}
				else
				{
					SetAnim(charMeta.run_anim, charUpdate);
				}
			}
			else
			{
				SetAnim(charMeta.idle_anim, charUpdate);
				SetAnim(charMeta.run_anim, charUpdate);
				SetAnim(charMeta.runend_anim, charUpdate);
			}
		}
		else if (animName == "lie")
		{
			WorldManager.curWorld = Game1.gameMap.scriptDestWorld;
			Game1.gameMap.SetMap(Game1.gameMap.scriptDestMap);
			for (int i = 0; i < Game1.character.Length; i++)
			{
				if (Game1.character[i].exists && Game1.character[i].team != Character.Team.GoodGuys)
				{
					Game1.character[i].exists = false;
				}
			}
			Game1.character[charUpdate.ID].charMeta = (this.charMeta = 8);
			Game1.character[charUpdate.ID].cDef = (charDef = 6);
			SetAnim("liefall", charUpdate);
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
		}
		else if (animName == "rockout")
		{
			Game1.soloMgr.Finish();
			SetAnim(charMeta.idle_anim, charUpdate);
		}
		else if (animName == "armsit")
		{
			WorldManager.curWorld = Game1.gameMap.scriptDestWorld;
			Game1.gameMap.SetMap(Game1.gameMap.scriptDestMap);
			for (int j = 0; j < Game1.character.Length; j++)
			{
				if (Game1.character[j].exists && Game1.character[j].team != Character.Team.GoodGuys)
				{
					Game1.character[j].exists = false;
				}
			}
			Game1.character[charUpdate.ID].charMeta = (this.charMeta = 0);
			Game1.character[charUpdate.ID].cDef = (charDef = 0);
			SetAnim("armsit2", charUpdate, overRide: true);
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
		}
		else if (animName == "handoff")
		{
			WorldManager.curWorld = Game1.gameMap.scriptDestWorld;
			Game1.gameMap.SetMap(Game1.gameMap.scriptDestMap);
			Game1.spriteMan.Reset();
			for (int k = 0; k < Game1.character.Length; k++)
			{
				if (Game1.character[k].exists && Game1.character[k].team != Character.Team.GoodGuys)
				{
					Game1.character[k].exists = false;
				}
			}
			Game1.character[charUpdate.ID].charMeta = (this.charMeta = 22);
			Game1.character[charUpdate.ID].cDef = (charDef = 6);
			SetAnim("armgetup", charUpdate);
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
		}
		else if (animName == "chairscream")
		{
			WorldManager.curWorld = Game1.gameMap.scriptDestWorld;
			Game1.levelMgr.SetGlobalFlag("scream");
			Game1.gameMap.SetMap(Game1.gameMap.scriptDestMap);
			Game1.character[charUpdate.ID].charMeta = (this.charMeta = 78);
			Game1.character[charUpdate.ID].cDef = (charDef = 0);
			SetAnim("screamup", charUpdate);
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "slash1");
			Sound.PlaySnd(Sound.Category.FX, "chunk");
			Sound.PlaySnd(Sound.Category.FX, "crunch");
			Sound.PlaySnd(Sound.Category.FX, "crush");
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			for (int l = 0; l < 128; l++)
			{
				Game1.spriteMan.AddWallblood(Game1.character[charUpdate.ID].charUpdate.loc + Rand.GetRandomVec2(-500f, 500f, -300f, 0f), splatNow: true);
			}
			int num = Game1.spawnMgr.SpawnMonster(Game1.character[charUpdate.ID].charUpdate.loc + new Vector2(250f, 0f), 0, null);
			if (num > -1)
			{
				Game1.character[num].charUpdate.face = 0;
				Game1.character[num].charUpdate.state = CharUpdate.State.Grounded;
				Game1.character[num].charAnim.SetAnim("exe2", Game1.character[num].charUpdate);
			}
			for (int m = 0; m < 5; m++)
			{
				Game1.spriteMan.AddGib(Game1.character[charUpdate.ID].charUpdate.loc + Rand.GetRandomVec2(-500f, 500f, 16f, 48f), Rand.GetRandomInt(0, 2), 1, 1, 1, 1, 1, "topland", Rand.GetRandomInt(1, 4), 0.35f, Game1.gameMap.CurMap(), -1);
				Game1.spriteMan.AddGib(Game1.character[charUpdate.ID].charUpdate.loc + Rand.GetRandomVec2(-500f, 500f, 16f, 48f), Rand.GetRandomInt(0, 2), 1, 1, 1, 1, 1, "bottomland", Rand.GetRandomInt(1, 4), 0.35f, Game1.gameMap.CurMap(), -1);
				Game1.spriteMan.AddGib(Game1.character[charUpdate.ID].charUpdate.loc + Rand.GetRandomVec2(-500f, 500f, 16f, 48f), Rand.GetRandomInt(0, 2), 1, 1, 1, 1, 1, "splitlegsland", Rand.GetRandomInt(4, 6), 0.35f, Game1.gameMap.CurMap(), -1);
				Game1.spriteMan.AddGib(Game1.character[charUpdate.ID].charUpdate.loc + Rand.GetRandomVec2(-500f, 500f, 16f, 48f), Rand.GetRandomInt(0, 2), 1, 1, 1, 1, 1, "armland", Rand.GetRandomInt(0, 2), 0.35f, Game1.gameMap.CurMap(), -1);
			}
		}
		else if (animName == "jmid")
		{
			SetAnim("jfall", charUpdate);
		}
		else if (animName == "jfall")
		{
			if (charUpdate.state == CharUpdate.State.Grounded)
			{
				charUpdate.state = CharUpdate.State.Airborne;
			}
		}
		else if (animName == charMeta.inactive_anim)
		{
			charUpdate.ethereal = true;
		}
	}

	public int GetCurFrame()
	{
		return Game1.charDef[charDef].GetAnimation(anim).GetKeyFrame(key).frameRef;
	}

	public void SetAnim(string newAnim, CharUpdate charUpdate)
	{
		SetAnim(newAnim, charUpdate, overRide: false);
	}

	public void SetAnim(string newAnim, CharUpdate charUpdate, bool overRide)
	{
		_ = newAnim == "dying";
		switch (newAnim)
		{
		case "run":
			newAnim = Game1.charMeta[charMeta].run_anim;
			break;
		case "runstart":
			newAnim = Game1.charMeta[charMeta].runstart_anim;
			if (charUpdate.runStartAnim != null)
			{
				newAnim = charUpdate.runStartAnim;
				charUpdate.runStartAnim = null;
			}
			break;
		case "runend":
			newAnim = Game1.charMeta[charMeta].runend_anim;
			break;
		case "switch":
			newAnim = Game1.charMeta[charMeta].switch_anim;
			break;
		case "fswitch":
			newAnim = Game1.charMeta[charMeta].fswitch_anim;
			break;
		case "idle":
			newAnim = Game1.charMeta[charMeta].idle_anim;
			break;
		case "hit":
			newAnim = Game1.charMeta[charMeta].hit_anim;
			break;
		case "idlet":
			newAnim = Game1.charMeta[charMeta].idlet_anim;
			break;
		case "attack":
			newAnim = Game1.charMeta[charMeta].attack_anim;
			break;
		case "strong":
			newAnim = Game1.charMeta[charMeta].strong_anim;
			break;
		case "dying":
			newAnim = Game1.charMeta[charMeta].dying_anim;
			break;
		case "fly":
			newAnim = Game1.charMeta[charMeta].fly_anim;
			break;
		case "flip":
			newAnim = Game1.charMeta[charMeta].flip_anim;
			break;
		case "jump":
			newAnim = Game1.charMeta[charMeta].jump_anim;
			break;
		case "land":
			newAnim = Game1.charMeta[charMeta].land_anim;
			break;
		}
		if (newAnim == Game1.charMeta[charMeta].turn_anim)
		{
			if (charUpdate.altRunStart)
			{
				newAnim = Game1.charMeta[charMeta].altturn_anim;
				charUpdate.altRunStart = false;
			}
		}
		else if (newAnim == Game1.charMeta[charMeta].runstart_anim)
		{
			if (charUpdate.altRunStart)
			{
				newAnim = Game1.charMeta[charMeta].altRunStart_anim;
				charUpdate.altRunStart = false;
			}
		}
		else if (newAnim == Game1.charMeta[charMeta].walk_anim && charUpdate.altRunStart)
		{
			newAnim = Game1.charMeta[charMeta].altRunStart_anim;
			charUpdate.altRunStart = false;
		}
		if (!(newAnim != animName) && !overRide)
		{
			return;
		}
		if (charUpdate != null)
		{
			if (charUpdate.landAnim != null)
			{
				charUpdate.landAnim = null;
			}
			if (charUpdate.runStartAnim != null)
			{
				charUpdate.runStartAnim = null;
			}
			if (Game1.charMeta[charMeta].altdefault)
			{
				charUpdate.altRunStart = true;
			}
			else
			{
				charUpdate.altRunStart = false;
			}
			if (newAnim == Game1.charMeta[charMeta].idle_anim || newAnim == Game1.charMeta[charMeta].idlet_anim)
			{
				if (charUpdate.hp < 0f && CheckAnim(Game1.charMeta[charMeta].dying_anim) > -1)
				{
					newAnim = Game1.charMeta[charMeta].dying_anim;
				}
				_ = charUpdate.charGrab.grabbedByChar;
				_ = -1;
			}
		}
		int num = CheckAnim(newAnim);
		if (num <= -1)
		{
			return;
		}
		speedFac = 1f;
		if (charUpdate != null)
		{
			charUpdate.wait = 0f;
		}
		charScript.ClearGotos();
		canCancel = false;
		if (charUpdate != null)
		{
			charUpdate.floating = false;
			charUpdate.ethereal = false;
			charUpdate.wcharge = 0f;
			charUpdate.magic = 0f;
			charUpdate.block = CharUpdate.Block.Normal;
			charUpdate.getsAllGrabInput = false;
			charUpdate.getsExeGrabInput = false;
		}
		anim = num;
		animName = newAnim;
		frame = 0f;
		key = 0;
		if (charUpdate != null)
		{
			charScript.DoScript(Game1.charDef[charDef].GetAnimation(anim).GetKeyFrame(0), this, charUpdate, Game1.character[charUpdate.ID].charMeta, Game1.character[charUpdate.ID].charKeys, charUpdate.ID);
			charTrigs.CheckHasGibs(charDef, Game1.charDef[charDef].GetAnimation(anim).GetKeyFrame(key).frameRef);
			if (Game1.IsPlayerChar(charUpdate.ID) && (animName == Game1.charMeta[charMeta].switch_anim || animName == Game1.charMeta[charMeta].fswitch_anim) && Game1.beadMgr.beads[charUpdate.ID].HasBead(InvCatalog.InvItemName.CatBead) && speedFac < 2f)
			{
				speedFac = 2f;
			}
		}
	}

	public void SetKey(int key)
	{
		this.key = key;
		if (Game1.charDef[charDef].GetAnimation(anim) != null)
		{
			if (Game1.charDef[charDef].GetAnimation(anim).GetKeyFrame(key) == null)
			{
				this.key = 0;
			}
			else if (Game1.charDef[charDef].GetAnimation(anim).GetKeyFrame(key).duration <= 0)
			{
				this.key = 0;
			}
		}
	}

	public float GetFrame()
	{
		return frame;
	}

	public void SetFrame(float frame)
	{
		this.frame = frame;
	}

	public int CheckAnim(string name)
	{
		for (int i = 0; i < Game1.charDef[charDef].GetAnimationArray().Length; i++)
		{
			Animation animation = Game1.charDef[charDef].GetAnimation(i);
			if (animation != null && animation.name == name)
			{
				return i;
			}
		}
		return -1;
	}
}
