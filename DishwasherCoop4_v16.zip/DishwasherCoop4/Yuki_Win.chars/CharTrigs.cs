using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;
using Yuki_Win.audio;
using Yuki_Win.director;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.sprites;
using Yuki_Win.sprites.camsplat;
using Yuki_Win.sprites.gibs;

namespace Yuki_Win.chars;

public class CharTrigs
{
	public enum SprayType
	{
		Blood,
		Flame,
		NullFlame,
		Giantblood,
		DragonFlame,
		NullDragonFlame,
		SquirtGun,
		WeaponSpray
	}

	public Vector2 grabberLoc;

	public int grabberFace;

	public float streamOffset;

	private CharGibSpray[] charGibSpray = new CharGibSpray[2];

	public bool hasGibSpray;

	public bool freshblood;

	public SprayType sprayType;

	public CharTrigs(int ID)
	{
		for (int i = 0; i < charGibSpray.Length; i++)
		{
			charGibSpray[i] = new CharGibSpray(ID);
		}
	}

	public void UpdateGrabberLoc(Vector2 loc, float scale, int face, Character c, int cDef, int frameIdx)
	{
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx >= 2000 && c.charUpdate.charGrab.grabbedByChar > -1)
			{
				int num = face;
				if (part.flip == 1)
				{
					num = 1 - num;
				}
				Vector2 location = part.location;
				if (face == 0)
				{
					location.X -= part.location.X * 2f;
				}
				grabberLoc = location * scale + loc;
				grabberFace = num;
			}
		}
	}

	public void CheckGhostSmoke(Vector2 loc, float scale, int face, Character c, int cDef, int frameIdx)
	{
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		Vector2 loc2 = default;
		float num = 0f;
		float num2 = 0f;
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx <= -1 || part.idx >= 1000)
			{
				continue;
			}
			Vector2 vector = part.location * scale + loc;
			Vector2 vector2 = part.scaling * scale;
			if (face == 0)
			{
				vector.X -= part.location.X * 2f * scale;
			}
			num2++;
			if (Rand.CointToss(1f / num2))
			{
				int num3 = part.idx / 64;
				Rectangle rectangle = default;
				CharMeta charMeta = Game1.charMeta[c.charMeta];
				switch (num3)
				{
				case 0:
					rectangle = Game1.headTexMeta[charMeta.headTex].GetRect(part.idx);
					break;
				case 1:
					rectangle = Game1.torsoTexMeta[charMeta.torsoTex].GetRect(part.idx - 64);
					break;
				case 2:
					rectangle = Game1.legsTexMeta[charMeta.legsTex].GetRect(part.idx - 128);
					break;
				case 3:
					rectangle = Game1.weaponTexMeta[charMeta.weapTex].GetRect(part.idx - 192);
					break;
				case 4:
					rectangle = Game1.auxTexMeta[charMeta.weapTex].GetRect(part.idx - 192);
					break;
				}
				if (rectangle.Width > 0)
				{
					loc2 = vector;
					num = (vector2.X + vector2.Y) / 3f * ((float)rectangle.Width + (float)rectangle.Height) / 3f;
					num /= 64f;
				}
			}
		}
		if (num > 0f)
		{
			Game1.spriteMan.AddSprite(18, loc2, new Vector2(0f, -50f), num * 2f, 0, 0);
		}
	}

	public void CheckDrips(Vector2 loc, float scale, int face, Character c, int cDef, int frameIdx, int next)
	{
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		Vector2 loc2 = default;
		float num = 0f;
		float num2 = 0f;
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx <= -1 || part.idx >= 1000)
			{
				continue;
			}
			Vector2 vector = part.location * scale + loc;
			Vector2 vector2 = part.scaling * scale;
			if (face == 0)
			{
				vector.X -= part.location.X * 2f * scale;
			}
			num2++;
			if (Rand.CointToss(1f / num2))
			{
				int num3 = part.idx / 64;
				Rectangle rectangle = default;
				CharMeta charMeta = Game1.charMeta[c.charMeta];
				switch (num3)
				{
				case 0:
					rectangle = Game1.headTexMeta[charMeta.headTex].GetRect(part.idx);
					break;
				case 1:
					rectangle = Game1.torsoTexMeta[charMeta.torsoTex].GetRect(part.idx - 64);
					break;
				case 2:
					rectangle = Game1.legsTexMeta[charMeta.legsTex].GetRect(part.idx - 128);
					break;
				case 3:
					rectangle = Game1.weaponTexMeta[charMeta.weapTex].GetRect(part.idx - 192);
					break;
				case 4:
					rectangle = Game1.auxTexMeta[charMeta.weapTex].GetRect(part.idx - 192);
					break;
				}
				if (rectangle.Width > 0)
				{
					loc2 = vector;
					num = (vector2.X + vector2.Y) / 3f * ((float)rectangle.Width + (float)rectangle.Height) / 3f;
					num /= 64f;
				}
			}
		}
		if (num > 0f)
		{
			Game1.spriteMan.AddSprite(87, loc2, new Vector2(0f, 100f), Rand.GetRandomFloat(0.15f, 0.2f), 0, 0);
		}
	}

	public void CheckSparks(Vector2 loc, float scale, int face, Character c, int cDef, int frameIdx)
	{
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		Vector2 loc2 = default;
		float num = 0f;
		float num2 = 0f;
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx <= -1 || part.idx >= 1000)
			{
				continue;
			}
			Vector2 vector = part.location * scale + loc;
			Vector2 vector2 = part.scaling * scale;
			if (face == 0)
			{
				vector.X -= part.location.X * 2f * scale;
			}
			num2++;
			if (Rand.CointToss(1f / num2))
			{
				int num3 = part.idx / 64;
				Rectangle rectangle = default;
				CharMeta charMeta = Game1.charMeta[c.charMeta];
				switch (num3)
				{
				case 0:
					rectangle = Game1.headTexMeta[charMeta.headTex].GetRect(part.idx);
					break;
				case 1:
					rectangle = Game1.torsoTexMeta[charMeta.torsoTex].GetRect(part.idx - 64);
					break;
				case 2:
					rectangle = Game1.legsTexMeta[charMeta.legsTex].GetRect(part.idx - 128);
					break;
				case 3:
					rectangle = Game1.weaponTexMeta[charMeta.weapTex].GetRect(part.idx - 192);
					break;
				case 4:
					rectangle = Game1.auxTexMeta[charMeta.weapTex].GetRect(part.idx - 192);
					break;
				}
				if (rectangle.Width > 0)
				{
					loc2 = vector;
					num = (vector2.X + vector2.Y) / 3f * ((float)rectangle.Width + (float)rectangle.Height) / 3f;
					num /= 64f;
				}
			}
		}
		if (num > 0f)
		{
			Game1.spriteMan.AddSprite(25, loc2, default, num, 0, 0);
			Game1.spriteMan.AddSprite(18, loc2, new Vector2(0f, -100f), num * 2f, 0, 0);
		}
	}

	public void DrawGiblets(SpriteBatch sprite, bool thresh)
	{
		for (int i = 0; i < charGibSpray.Length; i++)
		{
			if (charGibSpray[i].active && i % 2 == 0 == thresh)
			{
				charGibSpray[i].Draw(sprite, sprayType, thresh);
			}
		}
	}

	public void DrawFlameSpray(SpriteBatch sprite)
	{
		sprite.End();
		SpriteTools.BeginAdditive();
		for (int i = 0; i < charGibSpray.Length; i++)
		{
			if (charGibSpray[i].active)
			{
				charGibSpray[i].DrawFlame(sprite, sprayType);
			}
		}
		sprite.End();
		SpriteTools.BeginAlpha();
	}

	public void DrawSquirtGun(SpriteBatch sprite, bool refract)
	{
		for (int i = 0; i < charGibSpray.Length; i++)
		{
			if (charGibSpray[i].active)
			{
				charGibSpray[i].DrawSquirtGun(sprite, sprayType, refract);
			}
		}
	}

	public void UpdateGiblets(int cDef, int frameIdx, float scale, Vector2 loc, int face, int next, Character c)
	{
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		for (int i = 0; i < charGibSpray.Length; i++)
		{
			charGibSpray[i].justUpdated = false;
		}
		for (int j = 0; j < frame.GetPartArray().Length; j++)
		{
			Frame.Part part = frame.GetPart(j);
			if (part.idx < 1000 || part.idx >= 2000)
			{
				continue;
			}
			switch (part.idx - 1000)
			{
			case 7:
			case 44:
			case 85:
			case 86:
			case 87:
			case 118:
			{
				if (part.idx - 1000 == 118)
				{
					sprayType = SprayType.SquirtGun;
				}
				else if (part.idx - 1000 == 86)
				{
					sprayType = SprayType.Flame;
					if (c.GetMeta().isDragon)
					{
						sprayType = SprayType.DragonFlame;
						QuakeManager.SetQuake(0.3f);
						QuakeManager.SetBright(0.1f);
					}
				}
				else if (part.idx - 1000 == 87)
				{
					sprayType = SprayType.NullFlame;
					if (c.GetMeta().isDragon)
					{
						sprayType = SprayType.NullDragonFlame;
					}
				}
				else
				{
					sprayType = SprayType.Blood;
					if (c.GetMeta().isGiant && !c.GetMeta().issmallblood)
					{
						sprayType = SprayType.Giantblood;
					}
					if (Game1.IsPlayerChar(c.ID))
					{
						sprayType = SprayType.WeaponSpray;
					}
				}
				bool flag = true;
				if (part.idx - 1000 == 85)
				{
					if (!freshblood)
					{
						flag = false;
					}
					if (c.charUpdate.charGrab.grabbing)
					{
						flag = false;
					}
				}
				if (!flag)
				{
					break;
				}
				_ = new Vector2((float)Math.Cos((double)streamOffset + (double)c.ID), (float)Math.Sin((double)streamOffset + (double)c.ID)) * 0.2f;
				float num = part.rotation;
				Vector2 vector = part.location * scale + loc;
				_ = part.scaling * scale;
				if (face == 0)
				{
					num = 0f - num;
					vector.X -= part.location.X * scale * 2f;
				}
				if ((face != 1 || part.flip != 0) && face == 0)
				{
					_ = part.flip;
					_ = 1;
				}
				if (next > -1)
				{
					Frame frame2 = Game1.charDef[cDef].GetFrame(next);
					if (Frame.CanLerp(frame, frame2, j))
					{
						Frame.Part part2 = frame2.GetPart(j);
						Animation animation = Game1.charDef[cDef].GetAnimation(c.charAnim.anim);
						KeyFrame keyFrame = animation.GetKeyFrame(c.charAnim.GetKey());
						float progress = c.charAnim.frame / (float)keyFrame.duration;
						Vector2 location = part.location;
						Vector2 location2 = part2.location;
						float num2 = part.rotation;
						float num3 = part2.rotation;
						if (face == 0)
						{
							num2 = 0f - num2;
							num3 = 0f - num3;
							location.X -= part.location.X * 2f;
							location2.X -= part2.location.X * 2f;
						}
						vector = Frame.LerpLoc(location, location2, progress) * scale + loc;
						num = Frame.LerpRotation(num2, num3, progress);
						_ = Frame.LerpScale(part.scaling, part2.scaling, progress) * scale;
					}
				}
				Vector2 vector2 = new Vector2((float)Math.Cos(streamOffset), (float)Math.Sin(streamOffset)) * 1f;
				_ = Game1.charMeta[c.charMeta];
				float num4 = 5f;
				switch (part.idx)
				{
				case 1086:
				case 1087:
					num4 = 10f;
					break;
				default:
					num4 = 10f;
					break;
				}
				Vector2 vector3 = vector2 + Game1.spriteMan.GetTrajFromFaceRot(face, num) * num4 * part.scaling.X * Rand.GetRandomFloat(0.5f, 2f);
				if (sprayType == SprayType.Blood || sprayType == SprayType.Giantblood || sprayType == SprayType.WeaponSpray)
				{
					vector3 += Rand.GetRandomVec2(-110f, 110f, -110f, 110f);
				}
				if (part.flip == 1)
				{
					vector3 = -vector3;
				}
				for (int k = 0; k < charGibSpray.Length; k++)
				{
					if (!charGibSpray[k].active)
					{
						charGibSpray[k].Init(vector, vector3);
						charGibSpray[k].justUpdated = true;
						break;
					}
					if (!charGibSpray[k].justUpdated)
					{
						charGibSpray[k].Update(vector, sprayType, c);
						charGibSpray[k].justUpdated = true;
						if (charGibSpray[k].addFrame <= 0f)
						{
							charGibSpray[k].Add(vector, vector3);
						}
						break;
					}
				}
				hasGibSpray = true;
				break;
			}
			}
		}
		hasGibSpray = false;
		for (int l = 0; l < charGibSpray.Length; l++)
		{
			if (charGibSpray[l].active)
			{
				if (!charGibSpray[l].justUpdated)
				{
					charGibSpray[l].Update(sprayType, c);
				}
				hasGibSpray = true;
			}
		}
	}

	public void CheckHasGibs(int cDef, int frameIdx)
	{
		if (hasGibSpray)
		{
			return;
		}
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx < 1000 || part.idx >= 2000)
			{
				continue;
			}
			switch (part.idx - 1000)
			{
			case 85:
				if (freshblood)
				{
					hasGibSpray = true;
					return;
				}
				break;
			case 7:
			case 44:
			case 86:
			case 87:
			case 118:
				hasGibSpray = true;
				return;
			}
		}
	}

	public void CheckStream(Vector2 loc, float scale, int face, Character c, int cDef, int frameIdx, int next)
	{
		streamOffset += FMan.frameTime;
		if (streamOffset > 6.28f)
		{
			streamOffset -= 6.28f;
		}
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx < 1000 || part.idx >= 2000)
			{
				continue;
			}
			switch (part.idx - 1000)
			{
			case 7:
			case 44:
			case 55:
			case 63:
			{
				Vector2 vector = new Vector2((float)Math.Cos((double)streamOffset + (double)c.ID), (float)Math.Sin((double)streamOffset + (double)c.ID)) * 0.2f;
				float num = part.rotation;
				Vector2 vector2 = part.location * scale + loc;
				_ = part.scaling * scale;
				if (face == 0)
				{
					num = 0f - num;
					vector2.X -= part.location.X * scale * 2f;
				}
				if ((face != 1 || part.flip != 0) && face == 0)
				{
					_ = part.flip;
					_ = 1;
				}
				if (next > -1)
				{
					Frame frame2 = Game1.charDef[cDef].GetFrame(next);
					if (Frame.CanLerp(frame, frame2, i))
					{
						Frame.Part part2 = frame2.GetPart(i);
						Animation animation = Game1.charDef[cDef].GetAnimation(c.charAnim.anim);
						KeyFrame keyFrame = animation.GetKeyFrame(c.charAnim.GetKey());
						float progress = c.charAnim.frame / (float)keyFrame.duration;
						Vector2 location = part.location;
						Vector2 location2 = part2.location;
						float num2 = part.rotation;
						float num3 = part2.rotation;
						if (face == 0)
						{
							num2 = 0f - num2;
							num3 = 0f - num3;
							location.X -= part.location.X * 2f;
							location2.X -= part2.location.X * 2f;
						}
						vector2 = Frame.LerpLoc(location, location2, progress) * scale + loc;
						num = Frame.LerpRotation(num2, num3, progress);
						_ = Frame.LerpScale(part.scaling, part2.scaling, progress) * scale;
					}
				}
				int num4 = part.idx - 1000;
				Vector2 vector3 = new Vector2((float)Math.Cos(streamOffset), (float)Math.Sin(streamOffset)) * 1f;
				CharMeta charMeta = Game1.charMeta[c.charMeta];
				switch (num4)
				{
				case 55:
					Game1.spriteMan.MakeJunk(vector2, vector3 / 10f + Game1.spriteMan.GetTrajFromFaceRot(face, num) * 0.1f * part.scaling.X * Rand.GetRandomFloat(0.25f, 1f), charMeta.GetSpark(), 0.4f, c.ID);
					break;
				case 7:
					if (c.charUpdate.charGrab.grabbedByChar > -1)
					{
						Game1.spriteMan.KickBurst(vector2, c.charUpdate.charGrab.grabbedByChar, c.ID, 0.3f);
					}
					if (c.GetMeta().isRobot)
					{
						Game1.spriteMan.MakeJunk(vector2, vector3 + Game1.spriteMan.GetTrajFromFaceRot(face, num) * 0.1f * part.scaling.X * Rand.GetRandomFloat(0.5f, 2f), c.GetMeta().isJuicyRobot ? 1 : charMeta.GetSpark(), c.ID);
					}
					else
					{
						hasGibSpray = true;
						if (c.GetMeta().isCyborg && Rand.CointToss(0.5f))
						{
							Game1.spriteMan.AddSprite(0, vector2, vector3 + Game1.spriteMan.GetTrajFromFaceRot(face, num) * 15f * part.scaling.X * Rand.GetRandomFloat(0.5f, 2f), 1f, 0, c.ID);
						}
					}
					if (loc.X > ScrollManager.GetRealLoc(default, 1f).X && loc.X < ScrollManager.GetRealLoc(ScrollManager.screenSize, 1f).X && Rand.CointToss(0.1f))
					{
						if (c.GetMeta().isRobot)
						{
							Game1.spriteMan.AddCamsplat(CamSplat.CamSplatType.Dust);
						}
						else
						{
							Game1.spriteMan.AddCamsplat(CamSplat.CamSplatType.Blood);
						}
					}
					break;
				case 44:
					Game1.spriteMan.MakeSquirt(vector2, vector3 + vector + Game1.spriteMan.GetTrajFromFaceRot(face, num) * 0.1f * part.scaling.X, charMeta.GetSpark(), c.ID);
					if (Rand.CointToss(0.1f) && !c.GetMeta().isRobot)
					{
						Game1.spriteMan.AddCamsplat(CamSplat.CamSplatType.Blood);
					}
					break;
				case 63:
				{
					Vector2 vector4 = vector3 * 0.02f + Game1.spriteMan.GetTrajFromFaceRot(face, num) * 0.1f;
					Math.Sin(streamOffset);
					Game1.spriteMan.AddSprite(8, vector2, vector4 * Rand.GetRandomFloat(5f, 10f) + Rand.GetRandomVec2(-5f, 5f, -5f, 5f), Rand.GetRandomFloat(0.1f, 0.2f), 0, c.ID);
					Game1.spriteMan.AddSprite(5, vector2, vector4 * Rand.GetRandomFloat(5f, 10f) + Rand.GetRandomVec2(-5f, 5f, -5f, 5f), Rand.GetRandomFloat(0.1f, 0.2f), 0, c.ID);
					break;
				}
				}
				break;
			}
			}
		}
	}

	public void CheckHeadTop(Vector2 loc, float scale, int face, Character c, int cDef, int frameIdx, int next)
	{
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx < 0 || part.idx >= 64)
			{
				continue;
			}
			float num = part.rotation;
			Vector2 vector = part.location * scale + loc;
			_ = part.scaling * scale;
			while (num > 6.28f)
			{
				num -= 6.28f;
			}
			for (; num < 0f; num += 6.28f)
			{
			}
			if ((num > 1f && num < 5.28f) || c.charUpdate.traj.X > 1000f || c.charUpdate.traj.X < -1000f)
			{
				c.charUpdate.headTop.X = -1000f;
				continue;
			}
			if (face == 0)
			{
				num = 0f - num;
				vector.X -= part.location.X * scale * 2f;
			}
			if (next > -1)
			{
				Frame frame2 = Game1.charDef[cDef].GetFrame(next);
				if (Frame.CanLerp(frame, frame2, i))
				{
					Frame.Part part2 = frame2.GetPart(i);
					Animation animation = Game1.charDef[cDef].GetAnimation(c.charAnim.anim);
					KeyFrame keyFrame = animation.GetKeyFrame(c.charAnim.GetKey());
					float progress = c.charAnim.frame / (float)keyFrame.duration;
					Vector2 location = part.location;
					Vector2 location2 = part2.location;
					float num2 = part.rotation;
					float num3 = part2.rotation;
					if (face == 0)
					{
						num2 = 0f - num2;
						num3 = 0f - num3;
						location.X -= part.location.X * 2f;
						location2.X -= part2.location.X * 2f;
					}
					vector = Frame.LerpLoc(location, location2, progress) * scale + loc;
					num = Frame.LerpRotation(num2, num3, progress);
					_ = Frame.LerpScale(part.scaling, part2.scaling, progress) * scale;
				}
			}
			num -= 1.57f;
			c.charUpdate.headTop = vector + new Vector2((float)Math.Cos(num), (float)Math.Sin(num)) * 11f;
		}
	}

	public bool CheckMachineSmoke(Vector2 loc, float scale, int face, Character c, int cDef, int frameIdx)
	{
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx >= 2000)
			{
				if (c.charUpdate.charGrab.grabbedByChar > -1)
				{
					int num = face;
					if ((face == 1 && part.flip == 0) || (face == 0 && part.flip == 1))
					{
						num = 1 - num;
					}
					Vector2 location = part.location;
					if (face == 0)
					{
						location.X -= part.location.X * 2f;
					}
					grabberLoc = location * scale + loc;
					return CheckMachineSmoke(location * scale + loc, scale, num, Game1.character[c.charUpdate.charGrab.grabbedByChar], Game1.character[c.charUpdate.charGrab.grabbedByChar].cDef, part.idx - 2000);
				}
			}
			else
			{
				if (part.idx <= -1)
				{
					continue;
				}
				float num2 = part.rotation;
				Vector2 vector = part.location * scale + loc;
				_ = part.scaling * scale;
				if (face == 0)
				{
					num2 = 0f - num2;
					vector.X -= part.location.X * scale * 2f;
				}
				bool flag = false;
				if ((face == 1 && part.flip == 0) || (face == 0 && part.flip == 1))
				{
					flag = true;
				}
				CharMeta charMeta = Game1.charMeta[c.charMeta];
				int num3 = part.idx / 64;
				if ((num3 != 3 && num3 != 4) || charMeta.weapTex != 0)
				{
					continue;
				}
				switch (part.idx % 64)
				{
				case 8:
				case 9:
				case 10:
				case 11:
				case 12:
				case 13:
				case 14:
				case 15:
				case 16:
				case 17:
				case 18:
				case 19:
				case 20:
				case 21:
				case 22:
				case 23:
				case 28:
				case 29:
				case 30:
				case 31:
				{
					if (face == 1)
					{
						new Vector2((float)Math.Cos(num2), (float)Math.Sin(num2));
					}
					else
					{
						new Vector2((float)Math.Cos(num2) * -1f, (float)Math.Sin(num2) * -1f);
					}
					Vector2 vector2 = default;
					switch (part.idx % 64)
					{
					case 8:
					case 9:
					case 10:
					case 12:
					case 16:
					case 17:
					case 18:
					case 20:
					case 28:
						vector2 = new Vector2(51f, 0f);
						break;
					case 11:
					case 19:
						vector2 = default;
						break;
					case 13:
					case 21:
					case 29:
						vector2 = new Vector2(37f, 18f);
						break;
					case 14:
					case 22:
					case 30:
						vector2 = new Vector2(-7f, 25f);
						break;
					case 15:
					case 23:
					case 31:
						vector2 = new Vector2(-40f, -7f);
						break;
					}
					Vector2 loc2 = vector;
					vector2 *= scale;
					if (!flag)
					{
						vector2.X = 0f - vector2.X;
					}
					loc2 += new Vector2((float)Math.Cos(num2), (float)Math.Sin(num2)) * vector2.X;
					loc2 -= new Vector2((float)Math.Sin(num2), (float)Math.Cos(num2)) * vector2.Y;
					Game1.spriteMan.AddSprite(18, loc2, Rand.GetRandomVec2(-10f, 10f, -40f, 0f), Rand.GetRandomFloat(0.4f, 0.5f), 0, 0);
					return true;
				}
				}
			}
		}
		return false;
	}

	public void UpdateTrigs(Vector2 loc, float scale, int face, int frameIdx, Character c, SpriteManager spriteMan, int ID, Map map)
	{
		CharDef charDef = Game1.charDef[c.cDef];
		face = 1 - face;
		if (charDef == null)
		{
			return;
		}
		Frame frame = charDef.GetFrame(frameIdx);
		bool flag = false;
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx <= -1)
			{
				continue;
			}
			float num = part.rotation;
			Vector2 vector = part.location * scale + loc;
			Vector2 traj = part.scaling * scale;
			if (face == 0)
			{
				num = 0f - num;
				vector.X -= part.location.X * scale * 2f;
			}
			bool flag2 = false;
			if ((face == 1 && part.flip == 0) || (face == 0 && part.flip == 1))
			{
				flag2 = true;
			}
			CharMeta charMeta = Game1.charMeta[c.charMeta];
			if (part.idx >= 2000)
			{
				c.charUpdate.charGrab.grabberLoc = vector;
			}
			else
			{
				if (part.idx < 1000)
				{
					continue;
				}
				float y = 0f;
				if (c.charAnim.animName == "explode")
				{
					y = c.charUpdate.traj.Y;
				}
				int num2 = part.idx - 1000;
				Vector2 vector2 = default;
				switch (num2)
				{
				case 0:
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 9:
				case 11:
				case 16:
				case 18:
				case 19:
				case 20:
				case 21:
				case 22:
				case 23:
				case 25:
				case 41:
				case 42:
				case 47:
				case 48:
				case 49:
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 64:
				case 65:
				case 66:
				case 67:
				case 68:
				case 69:
				case 74:
				case 77:
				case 78:
				case 79:
				case 82:
				case 84:
				case 89:
				case 90:
				case 91:
				case 92:
				case 93:
				case 94:
				case 108:
				case 117:
				case 119:
				case 120:
				case 121:
				case 123:
				case 126:
				case 127:
				case 128:
				case 129:
				case 134:
				case 135:
					spriteMan.AddSprite(12, vector, new Vector2(flag2 ? traj.X : (0f - traj.X), (face == 1) ? traj.Y : (0f - traj.Y)), num, num2, ID);
					switch (num2)
					{
					case 9:
					case 16:
					case 20:
					case 25:
					case 68:
						if (Game1.player.yukiPhase >= 6)
						{
							c.charAnim.smokeMachineLife = 10f;
						}
						break;
					case 18:
					case 19:
						if (charMeta.special != 3 && charMeta.special != 4 && Game1.player.yukiPhase >= 6)
						{
							c.charAnim.smokeMachineLife = 10f;
						}
						break;
					case 42:
						if (charMeta.special == 3 && c.charUpdate.cloudCharge > 0.5f)
						{
							if (c.charUpdate.cloudCharge > 3f)
							{
								Sound.PlaySnd(Sound.Category.FX, "zexplode");
							}
							else
							{
								Sound.PlaySnd(Sound.Category.FX, "zbomb");
							}
							Sound.silenceFrame = 0.5f;
							spriteMan.AddSprite(41, vector, traj, num, flag2 ? 1 : 0, 0);
							int num17 = 5;
							num17 += (int)(c.charUpdate.cloudCharge * 3f);
							for (int num18 = 0; num18 < num17 / 4; num18++)
							{
								spriteMan.AddSprite(42, vector + Rand.GetRandomVec2(-50f, 50f, 0f, 50f), Rand.GetRandomVec2(100f, 4000f, -500f, 100f) * new Vector2((float)c.charUpdate.face - 0.5f, 1f), Rand.GetRandomFloat(0.5f, 2f), 0, ID);
								spriteMan.AddSprite(18, vector + Rand.GetRandomVec2(100f, 400f, -5f, 50f) * new Vector2((float)c.charUpdate.face - 0.5f, 1f), Rand.GetRandomVec2(100f, 1000f, -50f, 20f) * new Vector2((float)c.charUpdate.face - 0.5f, 1f), Rand.GetRandomFloat(1f, 3f), 0, ID);
							}
						}
						break;
					}
					break;
				case 95:
				{
					for (int num5 = 0; num5 < 500; num5++)
					{
						float randomFloat = Rand.GetRandomFloat(0f, 3.14f);
						float randomFloat2 = Rand.GetRandomFloat(100f, 700f);
						spriteMan.AddSprite(49, vector + Rand.GetRandomVec2(-40f, 40f, -40f, 40f), new Vector2((float)Math.Cos(randomFloat) * randomFloat2, (float)Math.Sin(randomFloat) * (0f - randomFloat2)), 1f, 0, 0);
					}
					break;
				}
				case 110:
					Game1.camMgr.SetGrabVec(vector);
					break;
				case 109:
					if (c.charUpdate.charGrab.grabbedByChar > -1)
					{
						Game1.character[c.charUpdate.charGrab.grabbedByChar].charAnim.SetAnim("grabend", Game1.character[c.charUpdate.charGrab.grabbedByChar].charUpdate);
						Game1.character[c.charUpdate.charGrab.grabbedByChar].charUpdate.etherealFrame = 1f;
						Game1.character[c.charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
						Game1.character[c.charUpdate.charGrab.grabbedByChar].charUpdate.loc = c.charUpdate.loc;
						c.charUpdate.charGrab.grabbedByChar = -1;
					}
					if (!Game1.gameMap.CurMap().TestCol(vector))
					{
						c.charUpdate.loc = vector;
					}
					c.charAnim.SetAnim("jhit", c.charUpdate, overRide: true);
					c.charUpdate.traj = new Vector2(0f, -30f);
					c.charUpdate.state = CharUpdate.State.Airborne;
					break;
				case 132:
					if (Game1.petPlayerMgr.GetPuke(ID) == 0)
					{
						if (Game1.petPlayerMgr.UseChow(ID, 3f))
						{
							for (int num11 = 0; num11 < 5; num11++)
							{
								spriteMan.AddSprite(72, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.5f, 0.5f)) * Rand.GetRandomFloat(1f, 4f), 0.1f, 0, c.ID - 2);
							}
							for (int num12 = 0; num12 < 5; num12++)
							{
								spriteMan.AddSprite(71, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.5f, 0.5f)), 0f, 0, c.ID - 2);
							}
						}
					}
					else if (Game1.petPlayerMgr.UseChow(ID, 7f))
					{
						for (int num13 = 0; num13 < 5; num13++)
						{
							spriteMan.AddSprite(76, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.5f, 0.5f)) * Rand.GetRandomFloat(1f, 4f), 0.1f, 0, c.ID - 2);
						}
						spriteMan.AddSprite(75, vector, spriteMan.GetTrajFromFaceRot(face, num), 0f, 0, c.ID - 2);
					}
					break;
				case 131:
				{
					bool flag3 = false;
					for (int num19 = 0; num19 < Game1.spriteMan.gib.Length; num19++)
					{
						Gib gib = Game1.spriteMan.gib[num19];
						if (gib.exists)
						{
							switch (gib.type)
							{
							case 0:
							case 1:
							case 2:
							case 3:
								if (!gib.isDragon && !gib.isMask && gib.loc.X > vector.X - 40f && gib.loc.X < vector.X + 40f && gib.loc.Y > vector.Y - 20f && gib.loc.Y < vector.Y + 20f)
								{
									gib.exists = false;
									for (int num20 = 0; num20 < 7; num20++)
									{
										spriteMan.MakeJunk(gib.loc + Rand.GetRandomVec2(-30f, 30f, 0f, 0f), Rand.GetRandomVec2(-2f, 2f, -2f, 0f), 0, 0.9f, c.ID);
									}
									Sound.PlayChunk();
									flag3 = true;
									Game1.petPlayerMgr.AddChow(ID);
								}
								break;
							}
						}
						if (flag3)
						{
							break;
						}
					}
					break;
				}
				case 100:
				{
					Vector2 traj2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.5f, 0.5f)) * 10f;
					Sound.PlaySnd(Sound.Category.FX, "sword1");
					if (c.ai != null && c.ai.targ > -1)
					{
						Character character = Game1.character[c.ai.targ];
						if (character.exists && ((c.charUpdate.face == 0 && character.charUpdate.loc.X < c.charUpdate.loc.X) || (c.charUpdate.face == 1 && character.charUpdate.loc.X > c.charUpdate.loc.X)))
						{
							traj2 = character.charUpdate.loc - c.charUpdate.loc;
							traj2.Normalize();
							traj2 *= 900f;
							traj2 += Rand.GetRandomVec2(-100f, 100f, -100f, 100f);
						}
					}
					spriteMan.AddSprite(53, vector, traj2, 0f, 0, ID);
					break;
				}
				case 99:
					spriteMan.AddSprite(51, vector, spriteMan.GetTrajFromFaceRot(face, num) * 30f, 0f, 0, ID);
					break;
				case 7:
					if (Rand.CointToss(0.02f))
					{
						spriteMan.MakeSquirt(vector, spriteMan.GetTrajFromFaceRot(face, num) * 0.1f * part.scaling.X, charMeta.GetSpark(), 1, c.ID);
					}
					break;
				case 88:
				{
					for (int num10 = 0; num10 < 2; num10++)
					{
						spriteMan.AddSprite(46, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-1f, 1f)) * Rand.GetRandomFloat(7f, 13f) * part.scaling.X, 0f, 0, 0);
						spriteMan.AddSprite(18, vector, Rand.GetRandomVec2(-50f, 50f, -50f, 50f), Rand.GetRandomFloat(1f, 2f), 0, 0);
					}
					if (c.charUpdate.hammerSmashFrame <= 0f)
					{
						Sound.PlaySnd(Sound.Category.FX, "junk");
						ScrollManager.scroll.Y += 15f;
					}
					break;
				}
				case 76:
					if (c.charUpdate.charGrab.grabbedByChar > -1)
					{
						Game1.spriteMan.KickBurst(vector, c.charUpdate.charGrab.grabbedByChar, c.ID, 0.3f);
					}
					if (charMeta.isRobot)
					{
						spriteMan.AddSprite(18, vector, spriteMan.GetTrajFromFaceRot(face, num) * Rand.GetRandomFloat(0f, 2f) + Rand.GetRandomVec2(-40f, 40f, -40f, 40f), Rand.GetRandomFloat(0.4f, 0.5f), 0, 0);
					}
					else
					{
						spriteMan.AddSprite(43, vector, spriteMan.GetTrajFromFaceRot(face, num) * Rand.GetRandomFloat(0f, 2f) + Rand.GetRandomVec2(-40f, 40f, -40f, 40f), Rand.GetRandomFloat(1.2f, 1.5f), 0, 0);
					}
					break;
				case 43:
				{
					for (int n = 0; n < 10; n++)
					{
						spriteMan.AddSprite(0, vector, Rand.GetRandomVec2(-200f, 200f, -200f, 200f), 1f, 0, 0);
						spriteMan.AddSprite(0, vector, Rand.GetRandomVec2(-1200f, 1200f, -1200f, 1200f), 1f, 0, 0);
					}
					break;
				}
				case 106:
					if (!charMeta.isRobot)
					{
						Game1.spriteMan.MakeMiniBloodSplode(vector, c.charUpdate.lastHitBy);
					}
					break;
				case 107:
				{
					int num4 = Game1.spawnMgr.SpawnMonster(vector, 38, "engie");
					if (num4 > -1)
					{
						Game1.character[num4].FloorMe(Game1.character[num4].charUpdate.loc);
						Game1.character[num4].charUpdate.face = c.charUpdate.face;
						Game1.character[num4].charAnim.SetAnim(Game1.character[num4].GetMeta().activate_anim, Game1.character[num4].charUpdate);
						if (Game1.character[num4].GetMeta().toast1 != null)
						{
							Game1.camMgr.bossToast.Init(Game1.character[num4].GetMeta().toast1, Game1.character[num4].GetMeta().toast2, num4);
						}
					}
					break;
				}
				case 101:
					Game1.gameMap.DoLichFreakout(netInduced: false);
					break;
				case 34:
					spriteMan.AddSprite(24, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 10f, 0f, 0, ID);
					Sound.PlaySnd(Sound.Category.FX, "launch");
					break;
				case 113:
					spriteMan.AddSprite(79, vector, default, Rand.GetRandomFloat(0.6f, 0.7f), 0, ID);
					break;
				case 116:
					spriteMan.AddSprite(82, vector, default, 0f, 0, ID);
					break;
				case 114:
					spriteMan.AddSprite(80, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 10f, 0f, 0, ID);
					QuakeManager.SetBright(0.4f);
					break;
				case 115:
					spriteMan.AddSprite(83, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 30f, 0f, 0, ID);
					QuakeManager.SetBright(0.4f);
					Sound.PlaySnd(Sound.Category.FX, "flame");
					break;
				case 80:
					spriteMan.AddSprite(44, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 70f, 0f, 0, ID);
					Sound.PlaySnd(Sound.Category.FX, "throw");
					break;
				case 122:
					spriteMan.AddSprite(96, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 30f, 0f, 0, ID);
					break;
				case 81:
					spriteMan.AddSprite(45, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 70f, 0f, 0, ID);
					Sound.PlaySnd(Sound.Category.FX, "throw");
					break;
				case 35:
					spriteMan.AddSprite(23, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 20f, 0f, 0, ID);
					Sound.PlaySnd(Sound.Category.FX, "launch");
					break;
				case 112:
					spriteMan.AddSprite(23, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 20f, 0f, 0, ID);
					Sound.PlaySnd(Sound.Category.FX, "flame");
					break;
				case 17:
					if (c.charUpdate.ammo > 0 || c.charUpdate.charGrab.grabbedByChar > -1)
					{
						vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
						spriteMan.MakeMuzzleFlash(vector, spriteMan.GetTrajFromFaceRot(face, num), ID);
						spriteMan.AddSprite(11, vector - vector2 * 0.01f, vector2, 0f, 0, ID);
						if (Rand.CointToss(0.5f))
						{
							Game1.spriteMan.AddSprite(18, vector + spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * Rand.GetRandomFloat(0f, 1f), Rand.GetRandomVec2(-10f, 10f, -40f, 0f), Rand.GetRandomFloat(0.4f, 0.6f), 0, ID);
						}
						Sound.PlaySnd(Sound.Category.FX, "shotgun");
						QuakeManager.SetBright(0.1f);
						if (c.charUpdate.charGrab.grabbedByChar < 0)
						{
							c.charUpdate.ammo--;
						}
					}
					else
					{
						c.charUpdate.charInput.Reload(c.charAnim, c.charUpdate);
					}
					break;
				case 105:
				{
					for (int num6 = 0; num6 < 3; num6++)
					{
						spriteMan.AddSprite(15, vector + Rand.GetRandomVec2(-30f, 30f, -30f, 30f), Rand.GetRandomVec2(-20f, 20f, -100f, -50f), Rand.GetRandomFloat(1f, 2f), 0, 0);
					}
					break;
				}
				case 33:
					vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
					spriteMan.MakeMuzzleFlash(vector, spriteMan.GetTrajFromFaceRot(face, num), ID);
					spriteMan.AddSprite(21, vector - vector2 * 0.01f, vector2, 0f, 0, ID);
					Sound.PlaySnd(Sound.Category.FX, "auto");
					QuakeManager.SetBright(0.1f);
					break;
				case 61:
					if (c.charUpdate.ammo > 0)
					{
						vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
						spriteMan.MakeMuzzleFlash(vector, spriteMan.GetTrajFromFaceRot(face, num), ID);
						spriteMan.AddSprite(11, vector - vector2 * 0.01f, vector2, 0f, 0, ID);
						Sound.PlaySnd(Sound.Category.FX, "auto");
						QuakeManager.SetBright(0.1f);
						if (Rand.CointToss(0.5f))
						{
							Game1.spriteMan.AddSprite(18, vector + spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * Rand.GetRandomFloat(0f, 1f), Rand.GetRandomVec2(-10f, 10f, -40f, 0f), Rand.GetRandomFloat(0.4f, 0.6f), 0, 0);
						}
						c.charUpdate.ammo--;
					}
					else
					{
						c.charUpdate.charInput.Reload(c.charAnim, c.charUpdate);
					}
					break;
				case 60:
				{
					vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
					spriteMan.MakeMuzzleFlash(vector, spriteMan.GetTrajFromFaceRot(face, num), ID);
					spriteMan.AddSprite(12, vector, new Vector2(flag2 ? traj.X : (0f - traj.X), (face == 1) ? traj.Y : (0f - traj.Y)), num, 6, ID);
					for (int m = 0; m < 10; m++)
					{
						spriteMan.AddSprite(37, vector - vector2 * 0.01f, vector2 + Rand.GetRandomVec2(-300f, 300f, -300f, 300f), 0f, 0, ID);
						spriteMan.AddSprite(0, vector - vector2 * 0.01f, vector2 * 0.5f + Rand.GetRandomVec2(-300f, 300f, -300f, 300f), 0f, 0, ID);
					}
					Sound.PlaySnd(Sound.Category.FX, "shotty");
					QuakeManager.SetBright(0.1f);
					QuakeManager.SetContrast(0.2f);
					QuakeManager.SetQuake(0.1f);
					break;
				}
				case 46:
					vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
					spriteMan.MakeMuzzleFlash(vector, spriteMan.GetTrajFromFaceRot(face, num), ID);
					spriteMan.AddSprite(21, vector - vector2 * 0.01f, vector2, 0f, 0, ID);
					Sound.PlaySnd(Sound.Category.FX, "silen");
					QuakeManager.SetBright(0.1f);
					break;
				case 31:
					vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
					spriteMan.MakeMuzzleFlash(vector, spriteMan.GetTrajFromFaceRot(face, num), ID);
					spriteMan.AddSprite(21, vector - vector2 * 0.01f, vector2, 0f, 0, ID);
					Sound.PlaySnd(Sound.Category.FX, "pistol");
					QuakeManager.SetBright(0.1f);
					break;
				case 32:
					spriteMan.AddSprite(17, vector, spriteMan.GetTrajFromFaceRot(face, num), 1f, 0, ID);
					break;
				case 98:
				{
					spriteMan.AddSprite(17, vector, spriteMan.GetTrajFromFaceRot(face, num) * 40f, 1f, 0, ID);
					for (int num30 = 0; num30 < 3; num30++)
					{
						spriteMan.AddSprite(50, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.5f, 0.5f)) * Rand.GetRandomFloat(1f, 5f), Rand.GetRandomFloat(0.1f, 0.35f), 0, 0);
					}
					break;
				}
				case 96:
				{
					for (int num29 = 0; num29 < 3; num29++)
					{
						spriteMan.AddSprite(50, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.5f, 0.5f)) * Rand.GetRandomFloat(1f, 10f), Rand.GetRandomFloat(0.15f, 0.5f), 0, 0);
					}
					break;
				}
				case 97:
				{
					for (int num28 = 0; num28 < 8; num28++)
					{
						spriteMan.AddSprite(50, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-1f, 1f)) * Rand.GetRandomFloat(1f, 10f), Rand.GetRandomFloat(0.15f, 0.5f), 0, 0);
					}
					break;
				}
				case 133:
				{
					for (int num27 = 0; num27 < 4; num27++)
					{
						spriteMan.AddSprite(103, vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-1f, 1f)) * Rand.GetRandomFloat(0.1f, 2f), Rand.GetRandomFloat(0.35f, 0.6f), 0, 0);
					}
					break;
				}
				case 29:
				{
					spriteMan.MakeMuzzleFlash(vector, spriteMan.GetTrajFromFaceRot(face, num), ID);
					Sound.PlaySnd(Sound.Category.FX, "shotgun");
					for (int num21 = 0; num21 < 6; num21++)
					{
						spriteMan.AddSprite(15, vector, spriteMan.GetTrajFromFaceRot(face, num) * Rand.GetRandomFloat(0.1f, 5f) + Rand.GetRandomVec2(-20f, 20f, -20f, 20f), Rand.GetRandomFloat(0.8f, 2f), 0, 0);
					}
					break;
				}
				case 15:
					if (c.GetMeta().isRobot)
					{
						spriteMan.AddSprite(22, vector, traj, num, flag2 ? 1 : 0, 0);
					}
					else
					{
						spriteMan.AddSprite(4, vector, traj, num, flag2 ? 1 : 0, 0);
					}
					break;
				case 12:
				{
					int num3 = spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y), face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, c.cDef, "headfall", "headland", 0.35f, map, 0, charMeta.GetSparks(), c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					if (charMeta.isDragon && num3 > -1)
					{
						spriteMan.gib[num3].isDragon = true;
					}
					if (charMeta.headTex == 42 && num3 > -1 && !CheckAlreadyMask())
					{
						spriteMan.gib[num3].isMask = true;
						if (Game1.netSession.IsClient() || Game1.netSession.IsHost())
						{
							Game1.netSession.netGame.SendMask(Game1.netSession.session, vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y));
						}
					}
					if (charMeta.isRobot)
					{
						Sound.PlayExplode();
					}
					else
					{
						Sound.PlaySpray();
						Sound.PlayChunk();
						Sound.PlayCrush();
						if (!charMeta.isZombie)
						{
							spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 15f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y) + Rand.GetRandomVec2(-500f, 500f, -500f, 500f), 0, 0, 0, 0, 0, c.cDef, null, null, 0.35f, map, 4, 0, c.ID, c.charUpdate.lastHitBy);
						}
					}
					QuakeManager.SetContrast(0.25f);
					ScrollManager.scroll += Rand.GetRandomVec2(-20f, 20f, -20f, 20f);
					break;
				}
				case 70:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y), face, Game1.charMeta[17].headTex, Game1.charMeta[17].torsoTex, Game1.charMeta[17].legsTex, Game1.charMeta[17].weapTex, 1, "headfall", "headland", 0.35f, map, 0, 0, c.charUpdate.lastHitBy, -1);
					if (Rand.CointToss(0.5f))
					{
						Sound.PlaySpray();
					}
					if (Rand.CointToss(0.5f))
					{
						Sound.PlayChunk();
					}
					if (Rand.CointToss(0.5f))
					{
						Sound.PlayCrush();
					}
					break;
				case 71:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y), face, Game1.charMeta[17].headTex, Game1.charMeta[17].torsoTex, Game1.charMeta[17].legsTex, Game1.charMeta[17].weapTex, 1, "armfall", "armland", 0.35f, map, 0, 0, c.charUpdate.lastHitBy, -1);
					if (Rand.CointToss(0.5f))
					{
						Sound.PlaySpray();
					}
					if (Rand.CointToss(0.5f))
					{
						Sound.PlayChunk();
					}
					if (Rand.CointToss(0.5f))
					{
						Sound.PlayCrush();
					}
					break;
				case 73:
					spriteMan.GoreSplode(vector, ID);
					break;
				case 72:
				{
					int randomInt = Rand.GetRandomInt(1, 4);
					for (int num22 = 0; num22 < randomInt; num22++)
					{
						int monster = 6;
						if (GameSettings.difficulty >= 2)
						{
							switch (GameSettings.difficulty)
							{
							case 2:
								if (Rand.CointToss(0.2f))
								{
									monster = 46;
								}
								break;
							case 3:
								if (Rand.CointToss(0.5f))
								{
									monster = 46;
								}
								break;
							case 4:
								if (Rand.CointToss(0.9f))
								{
									monster = 46;
								}
								break;
							case 5:
								if (Rand.CointToss(0.7f))
								{
									monster = 46;
								}
								break;
							}
						}
						int num23 = Game1.spawnMgr.SpawnMonster(vector, monster, null);
						if (num23 > -1)
						{
							Game1.character[num23].charUpdate.traj = spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y);
							if (Game1.character[num23].charUpdate.traj.X < 0f)
							{
								Game1.character[num23].charUpdate.face = 1;
							}
							else
							{
								Game1.character[num23].charUpdate.face = 0;
							}
							Game1.character[num23].charUpdate.traj += Rand.GetRandomVec2(-300f, 300f, -300f, 300f);
							Game1.character[num23].charUpdate.state = CharUpdate.State.Airborne;
							Game1.character[num23].charAnim.SetAnim("jmid", Game1.character[num23].charUpdate);
							Game1.character[num23].charUpdate.loc = vector;
							Game1.character[num23].charUpdate.ethereal = true;
						}
					}
					int num24 = 0;
					for (int num25 = 0; num25 < Game1.character.Length; num25++)
					{
						if (Game1.character[num25].exists && (Game1.character[num25].charMeta == 17 || Game1.character[num25].charMeta == 77))
						{
							num24++;
						}
					}
					for (int num26 = 0; num26 < Game1.character.Length; num26++)
					{
						if (Game1.character[num26].exists && Game1.character[num26].charUpdate.spawnFrame < 0.5f && (Game1.character[num26].charMeta == 17 || Game1.character[num26].charMeta == 77) && num24 > 5)
						{
							num24--;
							Game1.character[num26].charUpdate.hp = -10f;
						}
					}
					break;
				}
				case 125:
					spriteMan.AddSprite(0, vector, Rand.GetRandomVec2(-300f, 300f, -500f, 0f), 0f, 0, c.ID);
					break;
				case 104:
					DoMagic(c, spriteMan, vector, netInduced: false);
					c.charUpdate.mp--;
					break;
				case 75:
				{
					int num14 = Game1.spawnMgr.SpawnMonster(vector, 11, null);
					if (num14 <= -1)
					{
						break;
					}
					Game1.character[num14].charUpdate.traj = spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y);
					if (Game1.character[num14].charUpdate.traj.X < 0f)
					{
						Game1.character[num14].charUpdate.face = 1;
					}
					else
					{
						Game1.character[num14].charUpdate.face = 0;
					}
					Game1.character[num14].charUpdate.state = CharUpdate.State.Airborne;
					Game1.character[num14].charAnim.SetAnim("launch", Game1.character[num14].charUpdate);
					Game1.character[num14].charUpdate.loc = vector;
					Game1.character[num14].charUpdate.ethereal = true;
					int num15 = 0;
					for (int num16 = 0; num16 < Game1.character.Length; num16++)
					{
						if (num16 == num14 || !Game1.character[num16].exists || Game1.character[num16].charMeta != 40)
						{
							continue;
						}
						num15++;
						if (num15 > 1)
						{
							Game1.character[num16].charUpdate.hp = -10f;
							if (Game1.character[num16].charUpdate.state == CharUpdate.State.Airborne && Game1.character[num16].charUpdate.charGrab.grabbedByChar < 0)
							{
								Game1.character[num16].charAnim.SetAnim("jhit", Game1.character[num16].charUpdate);
							}
						}
					}
					break;
				}
				case 130:
				{
					int num7 = Game1.spawnMgr.SpawnMonster(vector, 49, null);
					if (num7 <= -1)
					{
						break;
					}
					Game1.character[num7].charUpdate.traj = spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y);
					if (Game1.character[num7].charUpdate.traj.X < 0f)
					{
						Game1.character[num7].charUpdate.face = 1;
					}
					else
					{
						Game1.character[num7].charUpdate.face = 0;
					}
					Game1.character[num7].charUpdate.state = CharUpdate.State.Airborne;
					Game1.character[num7].charAnim.SetAnim("fly", Game1.character[num7].charUpdate);
					Game1.character[num7].charUpdate.loc = vector;
					Game1.character[num7].charUpdate.ethereal = true;
					int num8 = 0;
					for (int num9 = 0; num9 < Game1.character.Length; num9++)
					{
						if (num9 == num7 || !Game1.character[num9].exists || Game1.character[num9].charMeta != 82)
						{
							continue;
						}
						num8++;
						if (num8 > 1)
						{
							Game1.character[num9].charUpdate.hp = -10f;
							if (Game1.character[num9].charUpdate.state == CharUpdate.State.Airborne && Game1.character[num9].charUpdate.charGrab.grabbedByChar < 0)
							{
								Game1.character[num9].charAnim.SetAnim("jhit", Game1.character[num9].charUpdate);
							}
						}
					}
					break;
				}
				case 13:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y), face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, c.cDef, "topfall", "topland", 0.35f, map, 1, charMeta.GetSparks(), c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					if (charMeta.isRobot)
					{
						Sound.PlayExplode();
					}
					else
					{
						Sound.PlaySpray();
						Sound.PlayChunk();
						Sound.PlayCrush();
					}
					QuakeManager.SetContrast(0.25f);
					ScrollManager.scroll += Rand.GetRandomVec2(-20f, 20f, -20f, 20f);
					break;
				case 14:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y), face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, c.cDef, "bottomfall", "bottomland", 0.35f, map, 2, charMeta.GetSparks(), c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					if (charMeta.isRobot)
					{
						Sound.PlayExplode();
						break;
					}
					Sound.PlaySpray();
					Sound.PlayChunk();
					Sound.PlayCrush();
					break;
				case 26:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-1f, 1f)) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y), face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, c.cDef, "splitlegsfall", "splitlegsland", 0.35f, map, 1, charMeta.GetSparks(), c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					if (charMeta.isRobot)
					{
						Sound.PlayExplode();
						break;
					}
					Sound.PlaySpray();
					Sound.PlayChunk();
					Sound.PlayCrush();
					break;
				case 83:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-1f, 1f)) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y), face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, c.cDef, "splittopfall", "splittopland", 0.35f, map, 1, charMeta.GetSparks(), c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					if (charMeta.isRobot)
					{
						Sound.PlayExplode();
					}
					else
					{
						Sound.PlaySpray();
						Sound.PlayChunk();
						Sound.PlayCrush();
					}
					QuakeManager.SetContrast(0.25f);
					ScrollManager.scroll += Rand.GetRandomVec2(-20f, 20f, -20f, 20f);
					break;
				case 27:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y) + Rand.GetRandomVec2(-200f, 200f, -200f, 200f), 1 - face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, c.cDef, "armfall", "armland", 0.35f, map, 1, charMeta.GetSparks(), c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					if (charMeta.isRobot)
					{
						Sound.PlayExplode();
						break;
					}
					Sound.PlaySpray();
					Sound.PlayChunk();
					Sound.PlayCrush();
					if (!charMeta.isZombie)
					{
						spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 15f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y) + Rand.GetRandomVec2(-500f, 500f, -500f, 500f), 0, 0, 0, 0, 0, c.cDef, null, null, 0.35f, map, 4, 0, c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					}
					break;
				case 45:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y), 1 - face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, c.cDef, "spinhit", "armland", 0.35f, map, 1, charMeta.GetSparks(), c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					if (charMeta.isRobot)
					{
						Sound.PlayExplode();
						break;
					}
					Sound.PlaySpray();
					Sound.PlayChunk();
					Sound.PlayCrush();
					break;
				case 28:
					spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 5f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y) + Rand.GetRandomVec2(-200f, 200f, -200f, 200f), face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, c.cDef, "armfall", "armland", 0.35f, map, 1, charMeta.GetSparks(), c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					if (charMeta.isRobot)
					{
						Sound.PlayExplode();
						break;
					}
					Sound.PlaySpray();
					Sound.PlayChunk();
					Sound.PlayCrush();
					if (!charMeta.isZombie)
					{
						spriteMan.AddGib(vector, spriteMan.GetTrajFromFaceRot(face, num) * 15f * part.scaling.X + new Vector2(c.charUpdate.traj.X, y) + Rand.GetRandomVec2(-500f, 500f, -500f, 500f), 0, 0, 0, 0, 0, c.cDef, null, null, 0.35f, map, 4, 0, c.charUpdate.lastHitBy, c.charUpdate.lastHitBy);
					}
					break;
				case 40:
				{
					spriteMan.AddSprite(20, vector, default, 100f, 20, ID);
					for (int j = 0; j < 7; j++)
					{
						Game1.spriteMan.AddGib(vector, Rand.GetRandomVec2(-700f, 700f, -700f, 100f), 0, 0, 0, 0, 0, 1, null, null, 0f, Game1.gameMap.CurMap(), 6, 0, c.ID, -1);
					}
					for (int k = 0; k < 32; k++)
					{
						spriteMan.AddSprite(0, vector, Rand.GetRandomVec2(-800f, 800f, -1200f, 0f), 0f, 0, 0);
					}
					for (int l = 0; l < 3; l++)
					{
						spriteMan.AddSprite(18, vector + Rand.GetRandomVec2(-80f, 80f, -80f, 80f), Rand.GetRandomVec2(-10f, 10f, -200f, 0f), Rand.GetRandomFloat(1f, 2f), 0, 0);
					}
					if (!flag)
					{
						ScrollManager.scroll.Y += 30f;
						QuakeManager.SetQuake(0.5f);
						Sound.PlaySnd(Sound.Category.FX, "bomb");
						Sound.PlaySnd(Sound.Category.FX, "explode");
						flag = true;
					}
					break;
				}
				case 36:
					spriteMan.MakeExplosion(vector, c.ID, 1f, splash: false);
					break;
				case 37:
					spriteMan.MakeExplosion(vector, c.ID, 2f, splash: false);
					break;
				case 38:
					spriteMan.MakeExplosion(vector, c.ID, 3f, splash: false);
					break;
				case 39:
					spriteMan.MakeExplosion(vector, c.ID, 5f, splash: false);
					break;
				case 124:
					spriteMan.MakeExplosion(vector, c.ID, 5f, splash: true);
					break;
				case 56:
					vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
					spriteMan.AddSprite(35, vector, vector2 * Rand.GetRandomFloat(0.05f, 0.15f), 0f, 0, ID);
					break;
				case 57:
					Sound.PlaySnd(Sound.Category.FX, "cockit");
					vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
					spriteMan.AddSprite(36, vector, vector2 * Rand.GetRandomFloat(0.05f, 0.15f), 0f, 0, ID);
					break;
				case 59:
					Sound.PlaySnd(Sound.Category.FX, "click3");
					vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
					spriteMan.AddSprite(38, vector, vector2 * Rand.GetRandomFloat(0.05f, 0.15f), 0f, 0, ID);
					break;
				case 58:
					Sound.PlaySnd(Sound.Category.FX, "click3");
					vector2 = spriteMan.GetTrajFromFaceRot(face, num + Rand.GetRandomFloat(-0.1f, 0.1f)) * 50f;
					spriteMan.AddSprite(39, vector, vector2 * Rand.GetRandomFloat(0.05f, 0.15f), 0f, 0, ID);
					break;
				}
			}
		}
	}

	public static bool CheckAlreadyMask()
	{
		for (int i = 0; i < Game1.spriteMan.gib.Length; i++)
		{
			if (Game1.spriteMan.gib[i].exists && Game1.spriteMan.gib[i].isMask)
			{
				return true;
			}
		}
		return false;
	}

	public void DoMagic(Character c, SpriteManager spriteMan, Vector2 location, bool netInduced)
	{
		if ((Game1.netSession.IsHost() && c.ID == 1 && !netInduced) || (Game1.netSession.IsClient() && c.ID == 0 && !netInduced))
		{
			return;
		}
		if ((Game1.netSession.IsClient() || Game1.netSession.IsHost()) && !netInduced)
		{
			Game1.netSession.netGame.AddMagic(c, location);
		}
		c.charUpdate.magicOut = 1f;
		Sound.PlaySnd(Sound.Category.FX, "gitwarp");
		QuakeManager.SetBurst(0.5f, ScrollManager.GetScreenLoc(location, 1f));
		switch (c.charUpdate.magicType)
		{
		case CharUpdate.Magictype.Grab:
			spriteMan.AddSprite(57, location, default, 0f, 0, c.ID);
			break;
		case CharUpdate.Magictype.Attack:
		{
			for (int j = 0; j < 4; j++)
			{
				float randomFloat = Rand.GetRandomFloat(0f, 6.28f);
				spriteMan.AddSprite(59, location, new Vector2((float)Math.Cos(randomFloat), (float)Math.Sin(randomFloat)) * 1000f, 0f, 0, c.ID);
			}
			c.charUpdate.DischargeZap(c, continuation: false);
			QuakeManager.worldStatic = 0f;
			Sound.PlaySnd(Sound.Category.FX, "zbomb");
			break;
		}
		case CharUpdate.Magictype.Jump:
			spriteMan.AddSprite(61, location + new Vector2(0f, -50f), default, 0.4f, 0, c.ID);
			break;
		case CharUpdate.Magictype.Strong:
		{
			for (int i = 0; i < 3; i++)
			{
				spriteMan.AddSprite(63, location, new Vector2((c.charUpdate.face == 1) ? 1f : (-1f), -0.4f + (float)i * 0.2f) * 1000f, 0f, 0, c.ID);
			}
			break;
		}
		}
	}

	internal void Init()
	{
		for (int i = 0; i < charGibSpray.Length; i++)
		{
			charGibSpray[i].Reset();
		}
		freshblood = false;
		hasGibSpray = false;
		streamOffset = 0f;
	}

	internal void CheckLasers(Vector2 loc, float scale, int face, Character c, int cDef, int frameIdx, int next)
	{
		Frame frame = Game1.charDef[cDef].GetFrame(frameIdx);
		int cols = Game1.headTexMeta[c.GetMeta().headTex].cols;
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx >= cols || part.idx <= -1)
			{
				continue;
			}
			float rotation = part.rotation;
			Vector2 vector = part.location * scale + loc;
			_ = part.scaling * scale;
			if (face == 0)
			{
				rotation = 0f - rotation;
				vector.X -= part.location.X * scale * 2f;
			}
			if ((face != 1 || part.flip != 0) && face == 0)
			{
				_ = part.flip;
				_ = 1;
			}
			if (next > -1)
			{
				Frame frame2 = Game1.charDef[cDef].GetFrame(next);
				if (Frame.CanLerp(frame, frame2, i))
				{
					Frame.Part part2 = frame2.GetPart(i);
					Animation animation = Game1.charDef[cDef].GetAnimation(c.charAnim.anim);
					KeyFrame keyFrame = animation.GetKeyFrame(c.charAnim.GetKey());
					float progress = c.charAnim.frame / (float)keyFrame.duration;
					Vector2 location = part.location;
					Vector2 location2 = part2.location;
					float num = part.rotation;
					float num2 = part2.rotation;
					if (face == 0)
					{
						num = 0f - num;
						num2 = 0f - num2;
						location.X -= part.location.X * 2f;
						location2.X -= part2.location.X * 2f;
					}
					vector = Frame.LerpLoc(location, location2, progress) * scale + loc;
					rotation = Frame.LerpRotation(num, num2, progress);
					_ = Frame.LerpScale(part.scaling, part2.scaling, progress) * scale;
				}
			}
			Vector2 vector2 = new Vector2((float)Math.Cos(streamOffset), (float)Math.Sin(streamOffset)) * 1f;
			_ = Game1.charMeta[c.charMeta];
			vector2 = c.charKeys.rVec;
			vector2.Normalize();
			Game1.spriteMan.AddSprite(101, vector + vector2 * 1f, vector2 * 800f, 1f, 0, c.ID);
			Game1.spriteMan.MakeLaserGlow(vector, vector2);
			break;
		}
	}
}
