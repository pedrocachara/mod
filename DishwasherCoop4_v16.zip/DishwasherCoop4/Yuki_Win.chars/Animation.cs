using xCharEdit.Character;

namespace Yuki_Win.chars;

public class Animation
{
	public string name;

	private KeyFrame[] keyFrame;

	public Animation()
	{
		name = "";
		keyFrame = new KeyFrame[256];
	}

	public void ClearKey(int idx)
	{
		keyFrame[idx] = new KeyFrame();
	}

	public KeyFrame GetKeyFrame(int idx)
	{
		if (idx < 0)
		{
			idx = 0;
		}
		return keyFrame[idx];
	}

	public int FixKeyFrame(int idx)
	{
		if (keyFrame[idx] == null)
		{
			int num = idx;
			bool flag = false;
			while (!flag)
			{
				num--;
				if (num < 0)
				{
					flag = true;
				}
				else if (keyFrame[num] != null)
				{
					return num;
				}
			}
			return 0;
		}
		return idx;
	}

	public void SetKeyFrame(int idx, KeyFrame _keyFrame)
	{
		if (keyFrame[idx] == null)
		{
			keyFrame[idx] = new KeyFrame();
		}
		keyFrame[idx] = _keyFrame;
	}

	public KeyFrame[] getKeyFrameArray()
	{
		return keyFrame;
	}
}
