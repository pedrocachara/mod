using System;
using director;
using Microsoft.Xna.Framework;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.chars.update;
using Yuki_Win.debug;
using Yuki_Win.director;
using Yuki_Win.levels;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.sprites;
using Yuki_Win.world;

namespace Yuki_Win.chars;

public class CharUpdate
{
	public enum State
	{
		Grounded,
		Airborne
	}

	public enum Block
	{
		Normal,
		NoBlock,
		AllBlock
	}

	public enum Magictype
	{
		Jump,
		Attack,
		Strong,
		Grab
	}

	public const int TRYWARP_NONE = 0;

	public const int TRYWARP_WARP = 1;

	public const int TRYWARP_ROLL = 2;

	public Vector2 cPreLoc;

	public Vector2 loc;

	public Vector2 traj;

	public Vector2 netLoc;

	public float colVal;

	public Vector2 warpVec;

	public float warpFrame;

	public float warpRecover;

	public int face;

	public bool floating;

	public float totalHang;

	public float wcharge;

	public CharGrab charGrab;

	public CharInput charInput;

	public float fire;

	public float mhp;

	public float hp;

	public float dyingFrame;

	public int killsToHealth;

	public int killsToMagic;

	public bool isHalfed;

	public int lastHitBy;

	public bool dehealthified;

	public bool ethereal;

	public float thermop;

	public Vector2 airJuggleVec;

	public float airJuggleFrame;

	public float breakJuggleFrame;

	public Vector2 realWarpVec;

	public bool canGrabCancel;

	public int lastSpecial = 1;

	public string landAnim;

	public string runStartAnim;

	public int ID;

	public bool canDoubleJump;

	public float giantShrugDamage;

	public float giantVulnTimer;

	public int mmp;

	public int mp;

	public float healthRegen;

	public int ammo;

	public int ammoMax = 42;

	public Vector2 headTop;

	public float crowFrame;

	public float slow;

	public float wait;

	public float etherealFrame;

	public float secondaryFrame;

	public float weapFreshBloodFrame;

	public float delta;

	public float magic;

	public float magicOut;

	public float zapCharged;

	public CharPrompt charPrompt;

	public float clientOwned;

	public float scratchRecoverFrame;

	public Block block;

	public State state;

	public bool nomusic;

	public bool getsExeGrabInput;

	public bool getsAllGrabInput;

	public bool inactive;

	public float cloudCharge;

	// Parry
	public float parryFrame;

	public float parryCool;

	public float parryFlash;

	public float dodgeTap;

	public float dodgeCool;

	// modelo/animacoes do Dishwasher emprestados temporariamente
	public bool borrowed;

	public int borrowDef;

	public int borrowMeta;

	public string borrowAnim;

	public float borrowTime;

	public float npcHitFrame;

	public float hammerSmashFrame;

	public float weaponStain;

	public float bodyStain;

	public float chainsawStain;

	public float specialStain;

	public bool locked;

	public Vector2 lockVec = default;

	public bool isSuicidal;

	public float slammedFrame;

	public float spawnFrame;

	public CharCols charCols;

	public bool altRunStart;

	public float drippy;

	public float reviveFrame;

	public Magictype magicType;

	public void SetNetLoc(Vector2 loc)
	{
		netLoc = loc;
	}

	public bool GetCanScratch()
	{
		return scratchRecoverFrame <= 0f;
	}

	public void SetScratch()
	{
		scratchRecoverFrame = 2f;
	}

	public void ResetKillstoHealth(Character me)
	{
		killsToHealth = 7;
		if (Game1.IsPlayerChar(me.ID) && Game1.beadMgr.beads[me.ID].HasBead(InvCatalog.InvItemName.HeartBead))
		{
			killsToHealth--;
		}
	}

	public void ResetKillstoMagic(Character me)
	{
		killsToMagic = 12;
		if (Game1.IsPlayerChar(me.ID) && Game1.beadMgr.beads[me.ID].HasBead(InvCatalog.InvItemName.SkullBead))
		{
			killsToMagic--;
		}
	}

	public CharUpdate(int ID)
	{
		charGrab = new CharGrab();
		charCols = new CharCols();
		charInput = new CharInput();
		this.ID = ID;
		charPrompt = new CharPrompt();
	}

	public void LockChar(Vector2 lockVec)
	{
		locked = true;
		this.lockVec = lockVec;
	}

	public void GrabbingUpdate(Map map, Character me, Character[] c)
	{
		CharAnim charAnim = me.charAnim;
		CharMeta meta = me.GetMeta();
		Vector2 pLoc = loc;
		ethereal = true;
		int num = -1;
		for (int i = 0; i < c.Length; i++)
		{
			if (c[i] != null && c[i].charUpdate.charGrab.grabbedByChar > -1 && c[i].charUpdate.charGrab.grabbedByChar == me.ID)
			{
				num = i;
				break;
			}
		}
		if (num < 0)
		{
			return;
		}
		Vector2 grabberLoc = c[num].charUpdate.charGrab.grabberLoc;
		if (!(grabberLoc.X > 0f))
		{
			return;
		}
		me.charUpdate.traj.X = (grabberLoc.X - me.charUpdate.loc.X) * FMan.frameTime * 500f;
		me.charUpdate.colVal = 0f;
		if (state == State.Grounded)
		{
			xMove(pLoc, map, charAnim, meta, me.charKeys);
			if (TestCol(loc + new Vector2(0f, 10f), map))
			{
				loc.Y = map.GetMinY(loc + new Vector2(0f, 10f));
			}
		}
	}

	public void ClearGrabs()
	{
		if (charGrab.grabbedByChar > -1)
		{
			Game1.character[charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
			charGrab.grabbedByChar = -1;
		}
	}

	public int TryWarp(Character c)
	{
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Asylum)
		{
			return 0;
		}
		if (hp < 0f)
		{
			return 0;
		}
		int result = 0;
		Vector2 rVec = c.charKeys.rVec;
		CharMeta meta = c.GetMeta();
		if (meta.isNeko || meta.isCrow)
		{
			return 0;
		}
		if (rVec.Length() > 0.4f)
		{
			rVec.Normalize();
			bool flag = false;
			if (meta.isYuki && Game1.player.yukiPhase >= 3)
			{
				flag = true;
			}
			if (meta.isDish)
			{
				if (!meta.isRoller)
				{
					flag = true;
				}
				if ((meta.warpcleavers || meta.warpscissors) && (rVec.Y > 0.3f || state == State.Airborne))
				{
					flag = true;
				}
			}
			if (flag)
			{
				if (meta.isYuki)
				{
					warpFrame = 0.25f;
				}
				else
				{
					warpFrame = 0.4f;
				}
				warpVec = rVec;
				warpVec.Y = 0f - warpVec.Y;
				canDoubleJump = true;
				canGrabCancel = true;
				if (state == State.Grounded && c.charAnim.CheckAnim(meta.flip_anim) > -1)
				{
					c.charAnim.SetAnim(meta.flip_anim, this);
					loc.Y -= 2f;
					state = State.Airborne;
					traj = default;
					airJuggleFrame = -1f;
				}
				Sound.PlaySnd(Sound.Category.FX, "warpout");
				ethereal = true;
				result = 1;
				if (etherealFrame < 0.1f)
				{
					etherealFrame = 0.1f;
				}
				if (meta.warpcleavers || meta.warpscissors)
				{
					c.charAnim.SetAnim(meta.warp_anim, this);
				}
			}
			else if (state == State.Grounded)
			{
				if (c.charAnim.CheckAnim(meta.flip_anim) > -1)
				{
					if (Math.Abs(rVec.X) > Math.Abs(rVec.Y))
					{
						if (rVec.X < 0f)
						{
							face = 0;
						}
						if (rVec.X > 0f)
						{
							face = 1;
						}
						c.charAnim.SetAnim(meta.roll_anim, this);
						ethereal = true;
						result = 2;
						if (etherealFrame < 0.1f)
						{
							etherealFrame = 0.1f;
						}
					}
					else if (rVec.Y > 0f)
					{
						c.charAnim.SetAnim(meta.flip_anim, this);
						loc.Y -= 2f;
						state = State.Airborne;
						traj = new Vector2(rVec.X * meta.speed, -600f);
						airJuggleFrame = -1f;
						Sound.PlaySnd(Sound.Category.FX, "swing");
						ethereal = true;
						result = 2;
						if (etherealFrame < 0.1f)
						{
							etherealFrame = 0.1f;
						}
					}
				}
			}
			else if (state == State.Airborne)
			{
				if (Math.Abs(rVec.X) > Math.Abs(rVec.Y))
				{
					if (c.charAnim.animName != meta.flip_anim)
					{
						if (rVec.X < 0f)
						{
							face = 0;
						}
						if (rVec.X > 0f)
						{
							face = 1;
						}
						c.charAnim.SetAnim(meta.flip_anim, this);
						if (rVec.X < 0f)
						{
							traj.X = (0f - meta.speed) * 1.5f;
						}
						else
						{
							traj.X = meta.speed * 1.5f;
						}
						Sound.PlaySnd(Sound.Category.FX, "swing");
						ethereal = true;
						result = 2;
						if (etherealFrame < 0.1f)
						{
							etherealFrame = 0.1f;
						}
					}
				}
				else if (rVec.Y > 0f && canDoubleJump)
				{
					c.charAnim.SetAnim(meta.flip_anim, this);
					c.charAnim.JoyJump(c.charKeys, this);
					canDoubleJump = false;
					Sound.PlaySnd(Sound.Category.FX, "swing");
					ethereal = true;
					result = 2;
					if (etherealFrame < 0.1f)
					{
						etherealFrame = 0.1f;
					}
				}
			}
		}
		return result;
	}

	private void WarpUpdate(Character c, Map map, SpriteManager spriteMan, float frameTime)
	{
		Vector2 vector = loc;
		Vector2 vector2 = loc;
		CharAnim charAnim = c.charAnim;
		_ = c.charKeys;
		CharMeta meta = c.GetMeta();
		if (Game1.gameMap.fakeCeiling > -1f && loc.Y < Game1.gameMap.fakeCeiling && warpVec.Y < 0f)
		{
			warpVec.Y = 0f;
			if (warpVec.X == 0f)
			{
				if (face == 1)
				{
					warpVec.X = 0.1f;
				}
				else
				{
					warpVec.X = -0.1f;
				}
			}
		}
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 2; j++)
			{
				float num = 500f;
				if (!meta.isYuki)
				{
					num = 350f;
				}
				if (Game1.gameMap.theme.theme != Themes.ThemeType.Asylum)
				{
					num *= 0.8f;
				}
				if (j == 0)
				{
					loc.Y += warpVec.Y * frameTime * num;
				}
				else
				{
					loc.X += warpVec.X * frameTime * num;
				}
				if (loc.X < 8f)
				{
					loc.X = 8f;
				}
				if (loc.X > (float)map.xSize * 64f - 8f)
				{
					loc.X = (float)map.xSize * 64f - 8f;
				}
				if (loc.Y < 8f)
				{
					loc.Y = 8f;
				}
				if (loc.Y > (float)map.ySize * 64f - 8f)
				{
					loc.Y = (float)map.ySize * 64f - 8f;
				}
				float x = 0f;
				float x2 = 0f;
				if (warpVec.X < 0f)
				{
					x = -30f;
				}
				if (warpVec.X > 0f)
				{
					x2 = 30f;
				}
				bool flag = false;
				bool flag2 = false;
				if (!DebugManager.noclipwarp)
				{
					if (TestCol(loc + new Vector2(x, 0f), map, falling: false, warping: true) || TestCol(loc + new Vector2(x2, 0f), map, falling: false, warping: true))
					{
						flag = true;
					}
					if (TestCol(loc + new Vector2(x, -70f), map, falling: false, warping: true) || TestCol(loc + new Vector2(x2, -70f), map, falling: false, warping: true))
					{
						flag2 = true;
					}
					if (TestCol(loc + new Vector2(x, -40f), map, falling: false, warping: true) || TestCol(loc + new Vector2(x2, -40f), map, falling: false, warping: true))
					{
						flag2 = true;
					}
					bool flag3 = false;
					if (flag && !flag2 && !TestCol(loc + new Vector2(x, -16f), map, falling: false, warping: true) && !TestCol(loc + new Vector2(x2, -16f), map, falling: false, warping: true))
					{
						loc.Y -= (float)Math.Abs((double)warpVec.X * (double)frameTime * 550.0);
						vector2 = loc;
					}
					if (flag || flag2)
					{
						flag3 = true;
						loc = vector2;
					}
					vector2 = loc;
					if (!flag3 && (TestCol(loc + new Vector2(x, 0f), map) || TestCol(loc + new Vector2(x2, 0f), map) || TestCol(loc + new Vector2(x, -70f), map) || TestCol(loc + new Vector2(x2, -70f), map)) && warpFrame < 0.05f)
					{
						warpFrame += 0.05f;
					}
				}
			}
		}
		float num2 = warpFrame;
		warpFrame -= frameTime * 2f;
		if (num2 >= 0.25f && warpFrame < 0.25f && c.GetMeta().isYuki)
		{
			for (int k = 0; k < 20; k++)
			{
				spriteMan.AddSprite(13, loc, warpVec, 0f, 0, c.ID);
			}
		}
		bool flag4 = !c.GetMeta().isYuki && (c.GetMeta().warpcleavers || c.GetMeta().warphammer || c.GetMeta().warpscissors);
		if (!c.GetMeta().isYuki && !flag4)
		{
			if (num2 >= 0.39f && warpFrame < 0.39f)
			{
				for (int l = 0; l < 48; l++)
				{
					spriteMan.AddSprite(32, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), warpVec * Rand.GetRandomFloat(400f, 1600f) + Rand.GetRandomVec2(-400f, 400f, -400f, 400f), 0f, 0, c.ID);
				}
			}
			if (num2 >= 0.05f && warpFrame < 0.05f)
			{
				for (int m = 0; m < 16; m++)
				{
					spriteMan.AddSprite(32, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), warpVec * Rand.GetRandomFloat(-400f, 400f) + Rand.GetRandomVec2(-400f, 400f, -400f, 400f), 0f, 0, c.ID);
				}
			}
		}
		if ((int)(num2 * 30f) != (int)(warpFrame * 30f))
		{
			if (c.GetMeta().isYuki)
			{
				spriteMan.AddSprite(14, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), realWarpVec * Rand.GetRandomFloat(0f, 100f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), 0f, 0, c.ID);
				for (int n = 0; n < 2; n++)
				{
					spriteMan.AddRefractSprite(77, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), realWarpVec, 1f, 0, c.ID);
					spriteMan.AddSprite(78, loc + new Vector2(0f, -40f) + Rand.GetRandomVec2(-20f, 20f, -20f, 20f), realWarpVec, 1f, 0, c.ID);
				}
			}
			else if (flag4)
			{
				if (c.GetMeta().warpcleavers)
				{
					for (int num3 = 0; num3 < 3; num3++)
					{
						spriteMan.AddSprite(1, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), warpVec * Rand.GetRandomFloat(40f, 200f) + 20f * Rand.GetRandomVec2(-1f, 1f, -1f, 1f), Rand.GetRandomFloat(0.1f, 0.6f), 0, c.ID);
					}
				}
				else
				{
					spriteMan.AddSprite(54, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), 10f * Rand.GetRandomVec2(-1f, 1f, -1f, 1f), 0f, 0, c.ID);
				}
			}
			else
			{
				spriteMan.AddSprite(32, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), warpVec * Rand.GetRandomFloat(0f, 2000f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), 0f, 0, c.ID);
				spriteMan.AddRefractSprite(74, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), warpVec * Rand.GetRandomFloat(0f, 2000f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), 0f, 0, c.ID);
			}
		}
		if (num2 > 0.2f && warpFrame <= 0.2f && !flag4)
		{
			c.charAnim.SetAnim(meta.flip_anim, this);
		}
		if (warpFrame > 0.05f)
		{
			if (warpVec.X > 0f)
			{
				face = 1;
			}
			if (warpVec.X < 0f)
			{
				face = 0;
			}
		}
		if (loc.Y > (float)map.ySize * 64f - 16f)
		{
			loc.Y = (float)map.ySize * 64f - 16f;
		}
		if (num2 >= 0.01f && warpFrame < 0.01f)
		{
			if (TestCol(loc + new Vector2(0f, 10f), map))
			{
				loc.Y += 10f;
				warpVec.Y = 0f;
				Land(charAnim, meta, map, c.ID);
			}
			else
			{
				state = State.Airborne;
			}
			airJuggleFrame = -1f;
		}
		if (warpFrame <= 0f)
		{
			traj = warpVec * 200f;
			warpRecover = 0.2f;
			if (flag4 && state != State.Grounded)
			{
				c.charAnim.SetAnim(meta.flip_anim, this);
			}
		}
		if (warpFrame < 0.05f)
		{
			realWarpVec = warpVec;
		}
		else
		{
			realWarpVec = (loc - vector) / (frameTime * 60f);
		}
		if (meta.isYuki)
		{
			if (warpFrame > 0.2f && (int)(num2 * 60f) != (int)(warpFrame * 60f))
			{
				for (int num4 = 0; num4 < 7; num4++)
				{
					spriteMan.AddSprite(14, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), realWarpVec * Rand.GetRandomFloat(0f, 110f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), 0f, 0, c.ID);
				}
			}
		}
		else if (!flag4 && (int)(num2 * 60f) != (int)(warpFrame * 60f))
		{
			if (warpFrame > 0.2f)
			{
				for (int num5 = 0; num5 < 5; num5++)
				{
					spriteMan.AddSprite(33, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), warpVec * Rand.GetRandomFloat(100f, 2000f) + Rand.GetRandomVec2(-150f, 150f, -150f, 150f), 0f, 0, c.ID);
					spriteMan.AddRefractSprite(70, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), warpVec * Rand.GetRandomFloat(100f, 2000f) + Rand.GetRandomVec2(-150f, 150f, -150f, 150f), 0f, 0, c.ID);
				}
			}
			spriteMan.AddSprite(18, loc + Rand.GetRandomVec2(-30f, 30f, -70f, 0f), Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.4f, 0.6f), 0, c.ID);
		}
		if (warpFrame < 0.01f)
		{
			JuggleStick(c.ID, warp: true);
		}
		else
		{
			c.charPhysics.ResetRope();
		}
	}

	public void JuggleStick(int ID, bool warp)
	{
		if (state != State.Airborne)
		{
			return;
		}
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (!Game1.character[i].exists)
			{
				continue;
			}
			Character character = Game1.character[ID];
			if (Game1.character[i].team != character.team && !Game1.character[i].GetMeta().isGiant && Game1.character[i].charUpdate.state == State.Airborne && Game1.character[i].charUpdate.dyingFrame <= 0f && Game1.character[i].charUpdate.charGrab.grabbedByChar < 0 && Game1.character[i].charUpdate.traj.Y < 800f)
			{
				Vector2 vector = loc;
				if (warp)
				{
					vector += warpVec * 50f;
				}
				Vector2 vector2 = Game1.character[i].charUpdate.loc + new Vector2(-40f, 0f);
				Vector2 vector3 = Game1.character[i].charUpdate.loc + new Vector2(40f, 0f);
				float num = (vector2 - vector).LengthSquared();
				float num2 = (vector3 - vector).LengthSquared();
				Vector2 vector4 = new Vector2(0f, warp ? 0f : (-50f));
				if (num < num2 && num < 20000f)
				{
					airJuggleVec = vector2 + vector4;
					airJuggleFrame = 0.5f;
					face = 1;
					Game1.character[i].charUpdate.airJuggleVec = Game1.character[i].charUpdate.loc + vector4;
					Game1.character[i].charUpdate.airJuggleFrame = 0.5f;
				}
				else if (num2 < num && num2 < 20000f)
				{
					airJuggleVec = vector3 + vector4;
					airJuggleFrame = 0.5f;
					face = 0;
					Game1.character[i].charUpdate.airJuggleVec = Game1.character[i].charUpdate.loc + vector4;
					Game1.character[i].charUpdate.airJuggleFrame = 0.5f;
				}
				if (Game1.character[ID].charMeta == 91 && Game1.character[ID].ai != null)
				{
					Game1.character[ID].ai.targ = i;
				}
			}
		}
	}

	public void FreshenWeapBlood(int sparks)
	{
		if (sparks != 2)
		{
			weapFreshBloodFrame = 0.25f;
		}
	}

	public void StainWeapon(int sparks)
	{
		if (sparks != 2)
		{
			weaponStain = 20f;
		}
	}

	public void StainChainsaw(int sparks)
	{
		if (sparks != 2)
		{
			chainsawStain = 20f;
		}
	}

	public void StainBody(int sparks)
	{
		if (sparks != 2)
		{
			StainWeapon(sparks);
			bodyStain = 20f;
		}
	}

	public void StainSpecial(int sparks)
	{
		if (sparks != 2)
		{
			specialStain = 20f;
		}
	}

	public void Update(Map map, Character c, Character[] cArray, SpriteManager spriteMan)
	{
		if (Game1.soloMgr.active && Game1.IsPlayerChar(c.ID))
		{
			return;
		}
		if (Game1.IsPlayerChar(c.ID))
		{
			charPrompt.Update(cArray, c.ID);
		}
		if ((DebugManager.godMode || Game1.levelMgr.currentTrack == 6 || Game1.levelMgr.currentTrack == 5) && c.team == Character.Team.GoodGuys)
		{
			hp = mhp;
			mp = mmp;
		}
		if (c.ID < 4)
		{
			if (Game1.gameMap.xmax > -1f && loc.X > Game1.gameMap.xmax)
			{
				loc.X = Game1.gameMap.xmax;
			}
			if (Game1.gameMap.xmin > -1f && loc.X < Game1.gameMap.xmin)
			{
				loc.X = Game1.gameMap.xmin;
			}
			if (hp < 0f)
			{
				if (Game1.GetPlayers() >= 2)
				{
					bool mateAlive = false;
					for (int pn = 0; pn < 4; pn++)
					{
						if (pn != c.ID && Game1.IsPlayerChar(pn) && Game1.character[pn].exists && Game1.character[pn].charUpdate.hp >= 0f)
						{
							mateAlive = true;
						}
					}
					if (mateAlive)
					{
						reviveFrame += FMan.frameTime;
						if (reviveFrame > 10f)
						{
							reviveFrame = 0f;
							hp = 25f;
						}
					}
					else
					{
						reviveFrame = 0f;
					}
				}
				else
				{
					reviveFrame = 0f;
				}
			}
			else
			{
				reviveFrame = 0f;
			}
		}
		if (scratchRecoverFrame > 0f)
		{
			scratchRecoverFrame -= FMan.realTime;
		}
		if (c.team == Character.Team.BadGuys && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.NomNom || Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.CrackingSkull) && hp < mhp / 8f)
		{
			hp = mhp / 8f;
		}
		if (spawnFrame > 0f)
		{
			spawnFrame -= FMan.frameTime;
		}
		if (drippy > 0f)
		{
			drippy -= FMan.frameTime;
		}
		if (clientOwned > 0f)
		{
			clientOwned -= FMan.frameTime;
		}
		if (c.GetMeta().isBoss && Game1.gameMap.lichFreakoutMode)
		{
			return;
		}
		if (c.GetMeta().isHatless)
		{
			hp = mhp;
		}
		if (weapFreshBloodFrame > 0f)
		{
			weapFreshBloodFrame -= FMan.frameTime;
			c.charAnim.charTrigs.freshblood = true;
		}
		else
		{
			c.charAnim.charTrigs.freshblood = false;
		}
		if (hammerSmashFrame > 0f)
		{
			hammerSmashFrame -= FMan.frameTime;
		}
		if (weaponStain > 0f)
		{
			weaponStain -= FMan.frameTime;
		}
		if (bodyStain > 0f)
		{
			bodyStain -= FMan.frameTime;
		}
		if (specialStain > 0f)
		{
			specialStain -= FMan.frameTime;
		}
		if (chainsawStain > 0f)
		{
			chainsawStain -= FMan.frameTime;
		}
		if (npcHitFrame > 0f)
		{
			npcHitFrame -= FMan.frameTime;
		}
		if (fire > 0f)
		{
			fire -= FMan.frameTime;
		}
		if (magic > 0f)
		{
			magic += FMan.frameTime;
			if (magicOut > 0f)
			{
				magicOut -= FMan.frameTime * 5f;
				if (magicOut <= 0f)
				{
					magic = 0f;
				}
			}
		}
		if (zapCharged > 0f)
		{
			zapCharged -= FMan.frameTime;
			if (zapCharged <= 0.8f)
			{
				DischargeZap(c, continuation: true);
			}
		}
		if (Game1.camMgr.bossToast.IsActive() && c.team == Character.Team.GoodGuys)
		{
			warpVec.X = 0f;
			traj.X = 0f;
		}
		if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
		{
			if (Game1.netSession.IsHost() && (ID == 0 || charGrab.grabbedByChar == 0))
			{
				netLoc = loc;
			}
			else if (Game1.netSession.IsClient() && (ID == 1 || charGrab.grabbedByChar == 1))
			{
				netLoc = loc;
			}
			else
			{
				netLoc += (loc - netLoc) * FMan.frameTime * 30f;
				if (Game1.transMgr.inFrame > 0f || Game1.transMgr.outFrame > 0f)
				{
					netLoc = loc;
				}
				if ((netLoc - loc).LengthSquared() > 40000f)
				{
					netLoc = loc;
				}
			}
		}
		else
		{
			netLoc = loc;
		}
		if (slammedFrame > 0f)
		{
			float num2 = slammedFrame;
			if (slammedFrame > 7f)
			{
				if (c.charUpdate.charGrab.grabbedByChar < 0)
				{
					c.charAnim.SetAnim("jhit", this);
					state = State.Airborne;
					traj = Rand.GetRandomVec2(-100f, 100f, -200f, -50f);
					hp -= FMan.frameTime * 30f;
					if (lastHitBy < 2 && Game1.beadMgr.beads[lastHitBy].HasBead(InvCatalog.InvItemName.PlateBead))
					{
						hp -= FMan.frameTime * 60f;
					}
				}
			}
			else if (c.charAnim.animName == "jfall")
			{
				Sound.PlaySnd(Sound.Category.FX, "crush");
				spriteMan.AddSprite(21, loc + Rand.GetRandomVec2(-10f, 10f, -60f, -10f), Rand.GetRandomVec2(-10f, 10f, -10f, 10f), 0f, 0, lastHitBy);
				slammedFrame = 0f;
			}
			slammedFrame -= FMan.frameTime;
			if ((int)(num2 * 20f) != (int)(slammedFrame * 20f))
			{
				spriteMan.AddSprite(58, loc + Rand.GetRandomVec2(-50f, 50f, -100f, 10f), traj + Rand.GetRandomVec2(-20f, 20f, -100f, 100f), Rand.GetRandomFloat(0.5f, 2f), 0, lastHitBy);
			}
		}
		if (c.GetMeta().isForce)
		{
			traj.X = 0f;
			colVal = 0f;
			if (!ethereal)
			{
				Game1.gameMap.forceX = loc.X + 80f * ((face == 0) ? 1f : (-1f));
				Game1.gameMap.forceY = loc.Y;
				Game1.gameMap.forceFrame = 0.5f;
			}
		}
		if (c.team == Character.Team.BadGuys && !isHalfed && hp < mhp / 2f && c.tag != "")
		{
			Game1.gameMap.CurMap().scriptMgr.SetFlag(c.tag + "half");
			isHalfed = true;
		}
		if (healthRegen > 0f)
		{
			UpdateHealthRegen();
		}
		if (c.team == Character.Team.GoodGuys)
		{
			FixGoodguyGrabKill(c);
		}
		if (c.charMeta == 88)
		{
			c.charUpdate.face = 0;
		}
		if (c.GetMeta().isGuitar || c.GetMeta().isViolin)
		{
			inactive = true;
		}
		delta += FMan.frameTime;
		if (delta > 1f)
		{
			delta--;
		}
		if ((Game1.transMgr.outFrame > 0f && Game1.transMgr.direction != TransitionManager.TransitionDirection.Warp) || (Game1.transMgr.inFrame > 0f && FixNetTransitionIn(c)) || Game1.transMgr.pauseResumeFrame > 0f)
		{
			return;
		}
		Vector2 vector = loc;
		if (etherealFrame > 0f)
		{
			etherealFrame -= FMan.frameTime;
		}
		if (dehealthified)
		{
			ethereal = true;
		}
		CharAnim charAnim = c.charAnim;
		CharKeys charKeys = c.charKeys;
		CharMeta meta = c.GetMeta();
		_ = vector.X / 64f;
		_ = vector.Y / 32f;
		cPreLoc = loc;
		charCols.TestCollision(c, cArray, this);
		if (dyingFrame > 0f)
		{
			UpdateDyingFrame(c);
		}
		if (meta.isPuppet && map.GetCol(loc) == Map.Collision.Null)
		{
			loc.Y += 128f;
		}
		if (c.charMeta == 42)
		{
			UpdateSlava(c);
		}
		if (c.charMeta == 83)
		{
			hp = mhp;
		}
		if (c.charMeta == 22)
		{
			if (warpFrame > 0f)
			{
				warpFrame = 0f;
			}
			if (Game1.gameMap.slavachase)
			{
				if (charAnim.animName == meta.idle_anim)
				{
					charAnim.SetAnim("armpanic", this);
				}
				if (charAnim.animName == "armpanic")
				{
					traj.X = 45f;
					if (charKeys.keyJump)
					{
						loc.X += 3.4f;
						QuakeManager.SetBright(0.05f);
						QuakeManager.SetQuake(0.1f);
					}
				}
				else
				{
					traj.X = 0f;
				}
			}
		}
		if (giantVulnTimer > 0f)
		{
			giantVulnTimer -= FMan.frameTime;
			if (giantVulnTimer <= 0f)
			{
				giantShrugDamage = 0f;
			}
		}
		if (giantShrugDamage > 0f)
		{
			giantShrugDamage -= FMan.frameTime;
		}
		if (meta.isChair)
		{
			for (int i = 0; i < cArray.Length; i++)
			{
				if (i != ID && cArray[i].exists && cArray[i].charMeta == 8 && cArray[i].charUpdate.loc.X > loc.X - 50f)
				{
					cArray[i].charUpdate.loc = loc;
					cArray[i].charMeta = 9;
					cArray[i].charAnim.SetAnim("chairboard", this);
					cArray[i].charUpdate.face = face;
					c.exists = false;
				}
			}
		}
		if (meta.isKnife)
		{
			for (int j = 0; j < cArray.Length; j++)
			{
				if (j != ID && cArray[j].exists && cArray[j].charMeta == 85 && cArray[j].charUpdate.loc.X > loc.X - 10f)
				{
					cArray[j].charMeta = 86;
					cArray[j].charAnim.SetAnim("knifeget", this);
				}
			}
		}
		if (warpFrame <= 0f)
		{
			if (warpRecover > 0f)
			{
				warpRecover -= FMan.frameTime;
			}
			else if (c.charAnim.animName == meta.idle_anim || c.charAnim.animName == meta.idlet_anim || c.charAnim.animName == meta.run_anim || c.charAnim.animName == meta.runstart_anim || c.charAnim.animName == meta.altRunStart_anim || c.charAnim.animName == meta.runend_anim || c.charAnim.animName == meta.wall_anim || c.charAnim.animName == meta.fly_anim || c.charAnim.animName == meta.flip_anim || c.charAnim.animName == meta.hit_anim || c.charAnim.animName == meta.switch_anim || c.charAnim.animName == meta.fswitch_anim || c.charAnim.animName == "jhit" || c.charAnim.animName == "jmid" || c.charAnim.animName == "jfall" || c.charAnim.animName == meta.hitland_anim)
			{
				TryWarp(c);
			}
		}
		if (Game1.gameMap.lichFreakoutMode && c.team == Character.Team.GoodGuys)
		{
			Vector2 realLoc = ScrollManager.GetRealLoc(default, 1f);
			Vector2 realLoc2 = ScrollManager.GetRealLoc(ScrollManager.screenSize, 1f);
			bool flag = true;
			if (Game1.netSession.IsHost() && c.ID == 1)
			{
				flag = false;
			}
			if (Game1.netSession.IsClient() && c.ID == 0)
			{
				flag = false;
			}
			if (flag)
			{
				if (loc.X < realLoc.X + 100f)
				{
					if (traj.X < -200f)
					{
						colVal = 0f - traj.X;
					}
					else
					{
						colVal = 200f;
					}
				}
				if (loc.X > realLoc2.X - 100f)
				{
					if (traj.X > 200f)
					{
						colVal = 0f - traj.X;
					}
					else
					{
						colVal = -200f;
					}
				}
			}
		}
		if (c.GetMeta().isPuppet && Game1.gameMap.isPuppeteer)
		{
			loc.X += (Game1.gameMap.fingerVec[ID % 4].X - loc.X) * FMan.frameTime * 20f;
		}
		if (warpFrame > 0f)
		{
			float frameTime = FMan.frameTime;
			int num3 = 1;
			if (frameTime > 1f / 60f)
			{
				num3 = (int)(frameTime / (1f / 60f)) + 1;
			}
			frameTime /= (float)num3;
			for (int k = 0; k < num3; k++)
			{
				WarpUpdate(c, map, spriteMan, frameTime);
				if (warpFrame <= 0f)
				{
					break;
				}
			}
		}
		else if (inactive)
		{
			if (c.charMeta == 91)
			{
				face = 1;
			}
		}
		else
		{
			charInput.InputToAnimation(map, c, cArray, this);
			if (charAnim.animName == "dueled")
			{
				Game1.gameMap.chainMash = true;
			}
			if (meta.isCrow)
			{
				UpdateCrow(c, charAnim, cArray, meta);
			}
			else if (meta.isNeko && charAnim.animName == meta.takeoff_anim)
			{
				state = State.Airborne;
				traj = new Vector2(((float)face - 0.5f) * 100f, -100f);
			}
			if (state == State.Airborne)
			{
				if (traj.Y > -100f && traj.Y < 100f)
				{
					traj.Y += FMan.frameTime * 2500f / 2f;
				}
				else
				{
					traj.Y += FMan.frameTime * 2500f;
				}
				if (Game1.gameMap.fakeCeiling > -1f && loc.Y < Game1.gameMap.fakeCeiling && traj.Y < 0f)
				{
					traj.Y = 0f;
				}
				if (traj.Y > 2000f)
				{
					traj.Y = 2000f;
				}
				if (floating)
				{
					totalHang += FMan.frameTime;
					float num4 = totalHang * 150f;
					if (num4 < 50f)
					{
						num4 = 50f;
					}
					if (traj.Y > num4)
					{
						traj.Y = num4;
					}
					if (traj.X > 50f)
					{
						traj.X = 50f;
					}
					if (traj.X < -50f)
					{
						traj.X = -50f;
					}
				}
				if (breakJuggleFrame > 0f)
				{
					breakJuggleFrame -= FMan.frameTime;
				}
				else if (airJuggleFrame > 0f)
				{
					airJuggleFrame -= FMan.frameTime;
					traj.X = (airJuggleVec.X - loc.X) * 6f;
					traj.Y = (airJuggleVec.Y - loc.Y) * 6f;
					if (c.team == Character.Team.GoodGuys)
					{
						for (int l = 0; l < Game1.character.Length; l++)
						{
							if (l == c.ID || !Game1.character[l].exists || !(Game1.character[l].charUpdate.airJuggleFrame > 0f) || !((Game1.character[l].charUpdate.airJuggleVec - airJuggleVec).LengthSquared() < 10000f))
							{
								continue;
							}
							if (loc.X < Game1.character[l].charUpdate.loc.X)
							{
								if (charKeys.keyLeft)
								{
									airJuggleFrame = 0f;
								}
								else
								{
									face = 1;
								}
							}
							else if (charKeys.keyRight)
							{
								airJuggleFrame = 0f;
							}
							else
							{
								face = 0;
							}
						}
					}
				}
				xMove(vector, map, charAnim, meta, charKeys);
				float num5 = traj.Y * FMan.frameTime;
				int num6 = (int)(num5 / 30f) + 1;
				num5 /= (float)num6;
				for (int m = 0; m < num6; m++)
				{
					loc.Y += num5;
					if (charGrab.grabbedByChar > -1)
					{
						if (loc.Y < charGrab.minY)
						{
							charGrab.minY = loc.Y;
						}
						if (loc.Y > charGrab.maxY)
						{
							charGrab.maxY = loc.Y;
						}
						if (loc.Y > (float)map.ySize * 64f)
						{
							loc.Y = (float)map.ySize * 64f;
						}
					}
					else
					{
						charGrab.ResetYDif(loc.Y);
					}
					if (meta.isCrow || (meta.isNeko && (charAnim.animName == meta.hover_anim || charAnim.animName == meta.flight_anim)))
					{
						if (traj.Y > 0f && TestCol(loc, map) && !TestCol(loc + new Vector2(0f, -30f), map) && !TestCol(loc + new Vector2(30f, -30f), map) && !TestCol(loc + new Vector2(-30f, -30f), map))
						{
							Land(charAnim, meta, map, c.ID);
						}
					}
					else if (traj.Y > 0f)
					{
						if (TestCol(loc, map, falling: true, warping: false))
						{
							if (map.GetCol(loc) == Map.Collision.Ledge)
							{
								if (map.GetCol(vector) == Map.Collision.None && !Game1.gameMap.goryoMode)
								{
									Land(charAnim, meta, map, c.ID);
								}
							}
							else
							{
								Land(charAnim, meta, map, c.ID);
							}
						}
					}
					else if (TestCol(loc - new Vector2(0f, 80f + (float)meta.mapHeightBuffer), map))
					{
						traj.Y = 1f;
						loc.Y = map.GetMaxY(loc - new Vector2(0f, 80f)) + 80f;
					}
					if (state != State.Airborne)
					{
						break;
					}
				}
				if (charAnim.animName == "jhit" && traj.Y > -100f)
				{
					charAnim.SetAnim("jmid", this);
				}
			}
			else if (state == State.Grounded)
			{
				charGrab.ResetYDif(loc.Y);
				canDoubleJump = true;
				canGrabCancel = true;
				airJuggleFrame = 0f;
				totalHang = 0f;
				xMove(vector, map, charAnim, meta, charKeys);
				if (traj.X > 0f)
				{
					traj.X -= FMan.frameTime * 1800f;
					if (traj.X < 0f)
					{
						traj.X = 0f;
					}
				}
				if (traj.X < 0f)
				{
					traj.X += FMan.frameTime * 1800f;
					if (traj.X > 0f)
					{
						traj.X = 0f;
					}
				}
				if (state != State.Airborne)
				{
					if (TestCol(loc + new Vector2(0f, 10f), map, falling: true, warping: false))
					{
						loc.Y = map.GetMinY(loc + new Vector2(0f, 10f));
						if (map.GetCol(loc + new Vector2(0f, 10f)) == Map.Collision.Ledge && c.charKeys.keyDown && (c.charAnim.animName == meta.idle_anim || c.charAnim.animName == meta.run_anim || c.charAnim.animName == meta.runstart_anim || c.charAnim.animName == meta.runend_anim))
						{
							charAnim.SetAnim(meta.fly_anim, this);
							state = State.Airborne;
							traj.Y = 1f;
							loc.Y += 10f;
						}
					}
					else if (charAnim.animName == meta.run_anim || charAnim.animName == meta.runstart_anim || charAnim.animName == meta.altRunStart_anim)
					{
						charAnim.SetAnim(meta.fly_anim, this);
						state = State.Airborne;
						traj.Y = -1f;
					}
					else
					{
						loc.X = vector.X;
					}
				}
			}
		}
		if (colVal > 0f)
		{
			if (colVal > 1000f)
			{
				colVal = 1000f;
			}
			colVal -= FMan.frameTime * 1000f;
			if (colVal < 0f)
			{
				colVal = 0f;
			}
		}
		if (colVal < 0f)
		{
			if (colVal < -1000f)
			{
				colVal = 1000f;
			}
			colVal += FMan.frameTime * 1000f;
			if (colVal < 0f)
			{
				colVal = 0f;
			}
		}
		if (Game1.gameMap.forceFrame > 0f && !meta.isNeko && !meta.isCrow && loc.Y <= Game1.gameMap.forceY + 20f && loc.Y > Game1.gameMap.forceY - 200f && loc.X > Game1.gameMap.forceX - 50f && loc.X < Game1.gameMap.forceX + 50f)
		{
			if (loc.X < Game1.gameMap.forceX)
			{
				traj.X = -500f;
				face = 1;
				if (vector.X < Game1.gameMap.forceX)
				{
					loc.X = vector.X;
				}
			}
			else
			{
				traj.X = 500f;
				face = 0;
				if (vector.X > Game1.gameMap.forceX)
				{
					loc.X = vector.X;
				}
			}
			c.charAnim.SetAnim("jhit", this);
			c.charUpdate.state = State.Airborne;
			traj.Y = -500f;
			if (QuakeManager.bright < 0.2f)
			{
				QuakeManager.SetBright(0.4f);
				QuakeManager.SetContrast(0.4f);
			}
			Sound.PlaySnd(Sound.Category.FX, "zap");
			Sound.PlaySnd(Sound.Category.FX, "tase");
		}
		if (locked)
		{
			loc = lockVec;
			traj = default;
		}
		if (Game1.camMgr.bossToast.frame > 0f && c.team == Character.Team.GoodGuys)
		{
			loc.X = vector.X;
		}
	}

	private bool FixNetTransitionIn(Character c)
	{
		if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
		{
			if (Game1.netSession.IsClient() && ID < 2 && Game1.transMgr.mapsSynced)
			{
				loc = Game1.character[0].charUpdate.loc;
				state = Game1.character[0].charUpdate.state;
				face = Game1.character[0].charUpdate.face;
				switch (state)
				{
				case State.Airborne:
					c.charAnim.SetAnim(c.GetMeta().fly_anim, this);
					break;
				case State.Grounded:
					c.charAnim.SetAnim(c.GetMeta().idle_anim, this);
					break;
				}
			}
			return true;
		}
		return false;
	}

	private void UpdateSlava(Character c)
	{
		if (Game1.gameMap.slavachase)
		{
			traj.X = 80f;
			face = 1;
			if (c.charUpdate.loc.X > Game1.character[0].charUpdate.loc.X - 50f)
			{
				Game1.character[0].charUpdate.charGrab.grabbedByChar = c.ID;
				charGrab.grabbing = true;
				Game1.character[0].charAnim.SetAnim("panicdie", Game1.character[0].charUpdate);
				Game1.gameMap.slavachase = false;
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
			}
		}
		if (!Game1.gameMap.slavapounce)
		{
			return;
		}
		traj.X = 0f;
		face = 0;
		loc.X = Game1.character[0].charUpdate.loc.X + 30f;
		traj.Y = 1000f;
		if (loc.Y > Game1.character[0].charUpdate.loc.Y - 100f)
		{
			FMan.slowFrame = 0.1f;
		}
		if (loc.Y > Game1.character[0].charUpdate.loc.Y - 40f)
		{
			FMan.slowFrame = 0f;
			WorldManager.curWorld = Game1.gameMap.scriptDestWorld;
			Game1.levelMgr.SetGlobalFlag("pounced");
			Game1.gameMap.SetMap(Game1.gameMap.scriptDestMap);
			Character character = Game1.character[0];
			switch (Game1.gamePlayerMgr.gamePlayer[0].loadOut[character.loadOut].weapon[character.weapIdx])
			{
			case InvCatalog.InvItemName.Claws:
				character.charMeta = (character.charAnim.charMeta = 78);
				break;
			case InvCatalog.InvItemName.Conviction:
				character.charMeta = (character.charAnim.charMeta = 0);
				break;
			case InvCatalog.InvItemName.Kamakazi:
				character.charMeta = (character.charAnim.charMeta = 2);
				break;
			case InvCatalog.InvItemName.CloudSword:
				character.charMeta = (character.charAnim.charMeta = 25);
				break;
			case InvCatalog.InvItemName.Painkiller:
				character.charMeta = (character.charAnim.charMeta = 46);
				break;
			default:
				character.charMeta = (character.charAnim.charMeta = 0);
				break;
			}
			character.cDef = (character.charAnim.charDef = 0);
			character.charAnim.SetAnim("narfed", character.charUpdate, overRide: true);
			character.charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
			character.charUpdate.charGrab.grabbedByChar = ID;
			character.charUpdate.lastSpecial = 1;
			charGrab.grabbing = true;
			Game1.gameMap.slavapounce = false;
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
		}
	}

	private void UpdateDyingFrame(Character c)
	{
		if (c.team == Character.Team.GoodGuys)
		{
			dyingFrame = 1f;
			if (c.charUpdate.hp >= 0f)
			{
				dyingFrame = 0f;
			}
		}
		else
		{
			dyingFrame += FMan.frameTime;
		}
	}

	private void FixGoodguyGrabKill(Character c)
	{
		if (hp < 0f && charGrab.grabbedByChar < 0 && Game1.gameMap.theme.theme != Themes.ThemeType.Asylum && c.charAnim.animName != c.GetMeta().hitland_anim && c.charAnim.animName != "jhit" && c.charAnim.animName != "jmid" && c.charAnim.animName != "jfall" && state == State.Grounded)
		{
			c.charAnim.SetAnim("jmid", this);
			state = State.Airborne;
			traj.Y = -300f;
		}
	}

	private void UpdateHealthRegen()
	{
		float num = healthRegen;
		healthRegen -= FMan.frameTime;
		hp += 10f * FMan.frameTime;
		if (hp > mhp)
		{
			hp = mhp;
		}
		if ((int)(num * 60f) != (int)(healthRegen * 60f))
		{
			Game1.spriteMan.AddSprite(72, loc + Rand.GetRandomVec2(-30f, 30f, -100f, 0f), Rand.GetRandomVec2(-20f, 20f, -100f, -20f), Rand.GetRandomFloat(0.1f, 0.2f), 0, ID);
		}
	}

	public void DischargeZap(Character me, bool continuation)
	{
		zapCharged = 0f;
		if (QuakeManager.worldStatic > 4f)
		{
			return;
		}
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (!Game1.character[i].exists || ((!continuation || Game1.character[i].team != me.team) && (continuation || Game1.character[i].team == me.team)) || me.ID == i || !(Game1.character[i].charUpdate.hp > 0f) || Game1.character[i].charUpdate.ethereal || Game1.character[i].charUpdate.inactive || !(Game1.character[i].charUpdate.spawnFrame < 0.5f) || Game1.character[i].charUpdate.charGrab.grabbedByChar >= 0)
			{
				continue;
			}
			for (int j = 0; j < 2; j++)
			{
				Game1.character[j].charUpdate.etherealFrame = 1f;
			}
			QuakeManager.worldStatic++;
			if (continuation)
			{
				Game1.character[i].charUpdate.lastHitBy = lastHitBy;
			}
			else
			{
				Game1.character[i].charUpdate.lastHitBy = me.ID;
			}
			Game1.character[i].charUpdate.zapCharged = 1f;
			Game1.spriteMan.AddSprite(59, loc + new Vector2(0f, -45f), Game1.character[i].charUpdate.loc - loc, 0f, 0, continuation ? lastHitBy : me.ID);
			if (FMan.slowFrame < 0.04f)
			{
				FMan.slowFrame = 0.04f;
			}
			Game1.killManager.DoKill(i);
			float num = (Game1.character[i].GetMeta().isMagicSponge ? Rand.GetRandomFloat(1f, 10f) : Rand.GetRandomFloat(10f, 50f));
			if (lastHitBy < 2 && Game1.beadMgr.beads[lastHitBy].HasBead(InvCatalog.InvItemName.CloudBead))
			{
				num += 20f;
			}
			Game1.character[i].charUpdate.hp -= num;
			_ = me.ID;
			if (Game1.character[i].charUpdate.hp <= 0f && Game1.character[i].charAnim.CheckAnim("explode") > -1)
			{
				Game1.character[i].charUpdate.state = State.Airborne;
				Game1.character[i].charUpdate.traj.X = Rand.GetRandomFloat(-400f, 400f);
				Game1.character[i].charUpdate.traj.Y = -100f;
				Game1.character[i].charAnim.SetAnim("explode", Game1.character[i].charUpdate, overRide: true);
				Game1.character[i].charUpdate.ethereal = true;
				Game1.character[i].charAnim.frame = 1.99f;
			}
			if (continuation)
			{
				if (Rand.CointToss(0.5f))
				{
					Sound.PlaySnd(Sound.Category.FX, "zbomb");
				}
				else
				{
					Sound.PlaySnd(Sound.Category.FX, "zexplode");
				}
			}
			QuakeManager.SetBright(0.5f);
			break;
		}
	}

	private void UpdateCrow(Character c, CharAnim charAnim, Character[] cArray, CharMeta charMeta)
	{
		if (Game1.netSession.IsClient() || Game1.netSession.IsHost())
		{
			clientOwned = 1f;
		}
		if (c.ai.mount)
		{
			if (charAnim.animName != charMeta.land_anim && charAnim.animName != charMeta.idle_anim && charAnim.animName != charMeta.turn_anim)
			{
				c.ai.mount = false;
				state = State.Airborne;
			}
			else if (cArray[c.ai.owner].charUpdate.headTop.X < 0f || cArray[c.ai.owner].charUpdate.charGrab.grabbing || cArray[c.ai.owner].charUpdate.traj.X > 1000f || cArray[c.ai.owner].charUpdate.traj.X < -1000f || (cArray[c.ai.owner].charUpdate.state == State.Airborne && (cArray[c.ai.owner].charUpdate.traj.Y > 1000f || cArray[c.ai.owner].charUpdate.traj.Y < -1000f)))
			{
				c.ai.mount = false;
				state = State.Airborne;
				charAnim.SetAnim(charMeta.takeoff_anim, this);
			}
			else
			{
				traj = default;
				Vector2 vector = loc;
				loc = (netLoc = cArray[c.ai.owner].charUpdate.headTop);
				if ((loc - vector).LengthSquared() > 2500f && Game1.transMgr.inFrame <= 0f)
				{
					c.ai.mount = false;
					state = State.Airborne;
					charAnim.SetAnim(charMeta.takeoff_anim, this);
				}
			}
		}
		else
		{
			if (state == State.Airborne)
			{
				crowFrame -= FMan.frameTime;
				if (crowFrame < 0f)
				{
					crowFrame = Rand.GetRandomFloat(0.01f, 0.1f);
					Game1.spriteMan.AddSprite(40, loc + Rand.GetRandomVec2(-20f, 20f, -20f, 0f), Rand.GetRandomVec2(-5f, 5f, 0f, 30f), 0f, 0, 0);
				}
			}
			if (charAnim.animName == charMeta.takeoff_anim)
			{
				state = State.Airborne;
				traj = new Vector2(((float)face - 0.5f) * 100f, -100f);
			}
			else if (!(charAnim.animName == charMeta.hover_anim) && !(charAnim.animName == charMeta.launch_anim) && !(charAnim.animName == charMeta.flight_anim))
			{
				_ = charAnim.animName == charMeta.fturn_anim;
			}
		}
		if (traj.Y > 1500f)
		{
			traj.Y = 1500f;
		}
	}

	public int GetClosestEnemy(Character me, Character[] c)
	{
		int num = -1;
		float num2 = 0f;
		for (int i = 0; i < c.Length; i++)
		{
			if (c[i].exists && me.ID != c[i].ID && me.team != c[i].team && !c[i].charUpdate.ethereal && c[i].charUpdate.etherealFrame <= 0f)
			{
				float num3 = (me.charUpdate.loc - c[i].charUpdate.loc).LengthSquared();
				if (num == -1)
				{
					num2 = num3;
					num = i;
				}
				else if (num3 < num2)
				{
					num2 = num3;
					num = i;
				}
			}
		}
		return num;
	}

	public void CheckSec(CharAnim charAnim, CharKeys charKeys, bool overRide)
	{
		bool flag = false;
		bool flag2 = false;
		bool flag3 = false;
		bool flag4 = false;
		if (charKeys.shootVec.Y > 0.3f)
		{
			flag = true;
		}
		if (charKeys.shootVec.Y < -0.3f)
		{
			flag3 = true;
		}
		if (charKeys.shootVec.X < -0.3f)
		{
			flag2 = true;
		}
		if (charKeys.shootVec.X > 0.3f)
		{
			flag4 = true;
		}
		if (ammo <= 0)
		{
			charInput.Reload(charAnim, this);
			return;
		}
		bool flag5 = false;
		if (charKeys.keySec)
		{
			Game1.practice.SetKey(9, ID);
			if (state == State.Grounded)
			{
				if (flag && (flag4 || flag2))
				{
					charAnim.SetAnim("gunu", this, overRide);
					flag5 = true;
				}
				else if (flag)
				{
					charAnim.SetAnim("gunuu", this, overRide);
					flag5 = true;
				}
				else
				{
					charAnim.SetAnim("gun", this, overRide);
					flag5 = true;
				}
			}
			if (state == State.Airborne)
			{
				if (flag && (flag4 || flag2))
				{
					charAnim.SetAnim("fgunu", this, overRide);
					flag5 = true;
				}
				else if (flag)
				{
					charAnim.SetAnim("fgunuu", this, overRide);
					flag5 = true;
				}
				else if (flag3 && (flag4 || flag2))
				{
					charAnim.SetAnim("fgund", this, overRide);
					flag5 = true;
				}
				else if (flag3)
				{
					charAnim.SetAnim("fgundd", this, overRide);
					flag5 = true;
				}
				else
				{
					charAnim.SetAnim("fgun", this, overRide);
					flag5 = true;
				}
			}
		}
		if (flag5)
		{
			if (flag4)
			{
				face = 1;
			}
			if (flag2)
			{
				face = 0;
			}
			lastSpecial = 2;
			charAnim.smokeMachineLife = 10f;
		}
	}

	public void Jump()
	{
		state = State.Airborne;
	}

	public void CheckWalled(Vector2 loc, Map map, CharAnim charAnim, CharMeta charMeta)
	{
		if (face == 0 && (!TestCol(loc + new Vector2(-40f, -25f), map) || !TestCol(loc + new Vector2(-40f, -55f), map)))
		{
			charAnim.SetAnim(charMeta.flip_anim, this);
			if (traj.Y < 0f)
			{
				charAnim.SetAnim(charMeta.wall_flip_anim, this);
			}
			else
			{
				traj.X = 30f;
			}
		}
		if (face == 1 && (!TestCol(loc + new Vector2(40f, -25f), map) || !TestCol(loc + new Vector2(40f, -55f), map)))
		{
			charAnim.SetAnim(charMeta.flip_anim, this);
			if (traj.Y < 0f)
			{
				charAnim.SetAnim(charMeta.wall_flip_anim, this);
			}
			else
			{
				traj.X = -30f;
			}
		}
	}

	private void xMove(Vector2 pLoc, Map map, CharAnim charAnim, CharMeta charMeta, CharKeys charKeys)
	{
		if (dyingFrame > 0f)
		{
			return;
		}
		if (charMeta.isBox)
		{
			traj.X = 0f;
			colVal = 0f;
		}
		if (traj.X > 2000f)
		{
			traj.X = 2000f;
		}
		if (traj.X < -2000f)
		{
			traj.X = -2000f;
		}
		float num = traj.X + colVal;
		int value = (int)(num / 250f);
		value = Math.Abs(value) + 1;
		num /= (float)value;
		float num2 = 30f;
		if (charMeta.isGiant)
		{
			num2 = 80f;
		}
		if (charMeta.mapWidthBuffer > 0)
		{
			num2 = charMeta.mapWidthBuffer;
		}
		float y = -75f;
		for (int i = 0; i < value; i++)
		{
			if (num > 0f)
			{
				loc.X += num * FMan.frameTime;
				if ((!charMeta.isCrow || state != State.Airborne) && (!charMeta.isNeko || (!(charAnim.animName == charMeta.hover_anim) && !(charAnim.animName == charMeta.flight_anim))) && (TestCol(loc + new Vector2(num2, -20f), map) || TestCol(loc + new Vector2(num2, y), map)))
				{
					loc.X = pLoc.X;
					if (traj.X > 500f && (charAnim.animName == "jhit" || charAnim.animName == "jmid" || charAnim.animName == "jfall" || charAnim.animName == "spinhit"))
					{
						if (!dehealthified && map.GetCol(loc + new Vector2(40f, -20f)) != Map.Collision.Null)
						{
							charAnim.SetAnim(charMeta.wall_slam_anim, this);
						}
						loc.X = (float)((int)(pLoc.X / 64f) * 64) + 30f;
						traj.Y = -50f;
						traj.X = 0f;
					}
					if (charAnim.animName == "jkatdart")
					{
						charAnim.SetAnim("jkatwallslam", this);
						loc.X = (float)((int)(pLoc.X / 64f) * 64) + 30f;
						traj.Y = 0f;
						traj.X = 0f;
					}
					if (charAnim.animName == charMeta.ceilrun_anim)
					{
						charAnim.SetAnim(charMeta.ceildrop_anim, this);
						traj.Y = 0f;
						traj.X /= 2f;
					}
					traj.X = 0f;
					if ((charAnim.animName == charMeta.fly_anim || charAnim.animName == charMeta.wall_jump_anim || charAnim.animName == charMeta.ceilrun_anim || (charAnim.animName == charMeta.run_anim && charKeys.keyUp) || (charAnim.animName == charMeta.altRunStart_anim && charKeys.keyUp)) && TestCol(loc + new Vector2(num2 + 10f, -25f), map) && TestCol(loc + new Vector2(num2 + 10f, -55f), map) && charAnim.CheckAnim(charMeta.wall_anim) > -1 && map.GetCol(loc + new Vector2(num2 + 10f, -55f)) != Map.Collision.Null && map.GetCol(loc + new Vector2(num2 + 10f, -25f)) != Map.Collision.Null)
					{
						traj = default;
						if (state == State.Grounded)
						{
							state = State.Airborne;
							traj.Y = -200f;
						}
						face = 1;
						totalHang = 0f;
						charAnim.SetAnim(charMeta.wall_anim, this);
						canGrabCancel = true;
						loc.X = (float)((int)(pLoc.X / 64f) * 64) + 30f;
					}
				}
			}
			if (num < 0f)
			{
				loc.X += num * FMan.frameTime;
				if ((!charMeta.isCrow || state != State.Airborne) && (!charMeta.isNeko || (!(charAnim.animName == charMeta.hover_anim) && !(charAnim.animName == charMeta.flight_anim))) && (TestCol(loc + new Vector2(0f - num2, -20f), map) || TestCol(loc + new Vector2(0f - num2, y), map)))
				{
					loc.X = pLoc.X;
					if (traj.X < -500f && (charAnim.animName == "jhit" || charAnim.animName == "jmid" || charAnim.animName == "jfall" || charAnim.animName == "spinhit"))
					{
						if (!dehealthified && map.GetCol(loc + new Vector2(-40f, -20f)) != Map.Collision.Null)
						{
							charAnim.SetAnim(charMeta.wall_slam_anim, this);
						}
						traj.Y = -50f;
						loc.X = (float)((int)(pLoc.X / 64f) * 64) + 64f - 30f;
						traj.X = 0f;
					}
					if (charAnim.animName == "jkatdart")
					{
						charAnim.SetAnim("jkatwallslam", this);
						loc.X = (float)((int)(pLoc.X / 64f) * 64) + 64f - 30f;
						traj.Y = 0f;
						traj.X = 0f;
					}
					if (charAnim.animName == charMeta.ceilrun_anim)
					{
						charAnim.SetAnim(charMeta.ceildrop_anim, this);
						traj.Y = 0f;
						traj.X /= 2f;
					}
					traj.X = 0f;
					if ((charAnim.animName == charMeta.fly_anim || charAnim.animName == charMeta.wall_jump_anim || charAnim.animName == charMeta.ceilrun_anim || (charAnim.animName == charMeta.run_anim && charKeys.keyUp) || (charAnim.animName == charMeta.altRunStart_anim && charKeys.keyUp)) && TestCol(loc + new Vector2(0f - num2 - 10f, -25f), map) && TestCol(loc + new Vector2(0f - num2 - 10f, -55f), map) && charAnim.CheckAnim(charMeta.wall_anim) > -1 && map.GetCol(loc + new Vector2(0f - num2 - 10f, -55f)) != Map.Collision.Null && map.GetCol(loc + new Vector2(0f - num2 - 10f, -25f)) != Map.Collision.Null)
					{
						traj = default;
						if (state == State.Grounded)
						{
							state = State.Airborne;
							traj.Y = -200f;
						}
						face = 0;
						totalHang = 0f;
						charAnim.SetAnim(charMeta.wall_anim, this);
						canGrabCancel = true;
						loc.X = (float)((int)(pLoc.X / 64f) * 64) + 64f - 30f;
					}
				}
			}
			if (loc.X != pLoc.X && state == State.Grounded && TestCol(loc + new Vector2(0f, 10f), map))
			{
				loc.Y = map.GetMinY(loc + new Vector2(0f, 10f));
			}
			pLoc.X = loc.X;
			if (loc.X < 8f)
			{
				loc.X = 8f;
			}
			if (loc.X > (float)map.xSize * 64f - 8f)
			{
				loc.X = (float)map.xSize * 64f - 8f;
			}
		}
	}

	public void TrySlow(int n, float val)
	{
		if (Game1.camMgr.CanSlowAll())
		{
			FMan.Slow(val);
			return;
		}
		Slow(val);
		if (n > -1 && Game1.character[n].exists)
		{
			Game1.character[n].charUpdate.Slow(val);
		}
	}

	private void Land(CharAnim charAnim, CharMeta charMeta, Map map, int ID)
	{
		if (dyingFrame > 0f)
		{
			state = State.Grounded;
			return;
		}
		bool flag = false;
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.NomNom || Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.CrackingSkull))
		{
			flag = true;
		}
		if (Game1.IsPlayerChar(ID) && Game1.soloMgr.active)
		{
			Game1.soloMgr.active = false;
		}
		state = State.Grounded;
		if (landAnim != null)
		{
			bool flag2 = false;
			if (landAnim == charMeta.groundsplode_anim)
			{
				flag2 = true;
			}
			charAnim.SetAnim(landAnim, this);
			if (flag2 && !flag && charGrab.grabbedByChar > -1)
			{
				Game1.spriteMan.KickBurst(loc, charGrab.grabbedByChar, ID);
				Game1.character[charGrab.grabbedByChar].charUpdate.traj = new Vector2(0f, traj.Y * -0.4f);
				if (Game1.character[charGrab.grabbedByChar].charUpdate.traj.Y < -1400f)
				{
					Game1.character[charGrab.grabbedByChar].charUpdate.traj.Y = -1400f;
				}
				if (Game1.character[charGrab.grabbedByChar].charUpdate.traj.Y > -700f)
				{
					Game1.character[charGrab.grabbedByChar].charUpdate.traj.Y = -700f;
				}
				Game1.character[charGrab.grabbedByChar].charUpdate.airJuggleFrame = 0f;
				Game1.character[charGrab.grabbedByChar].charUpdate.loc = loc;
				Game1.character[charGrab.grabbedByChar].charAnim.SetAnim(Game1.character[charGrab.grabbedByChar].GetMeta().flip_anim, Game1.character[charGrab.grabbedByChar].charUpdate);
				Game1.character[charGrab.grabbedByChar].charUpdate.etherealFrame = 0.2f;
				Game1.character[charGrab.grabbedByChar].charUpdate.state = State.Airborne;
				Game1.character[charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				TrySlow(charGrab.grabbedByChar, 0.02f);
				TrySlow(ID, 0.02f);
				charGrab.grabbedByChar = -1;
				Game1.killManager.doBits(0.8f);
				charAnim.frame = 1.1f;
				Game1.character[ID].effectivelyDead = true;
				Game1.hud.ResetWaveDefeatedOkFrame();
				ethereal = true;
				Sound.PlaySnd(Sound.Category.FX, "crunch");
				Sound.PlaySnd(Sound.Category.FX, "bass");
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.scroll.Y += 30f;
			}
			else
			{
				charAnim.frame = 0.95f;
			}
		}
		else
		{
			cloudCharge = 0f;
			if (charGrab.grabbedByChar > -1)
			{
				float num = charGrab.maxY - charGrab.minY;
				Game1.spriteMan.KickBurst(loc, charGrab.grabbedByChar, ID);
				if (num > 200f)
				{
					Game1.spriteMan.AddSprite(12, loc + new Vector2(32f, -32f), new Vector2(1f, 0f), 1f, 24, charGrab.grabbedByChar);
					Game1.spriteMan.AddSprite(12, loc + new Vector2(-32f, -32f), new Vector2(-1f, 0f), 1f, 24, charGrab.grabbedByChar);
				}
				if (!flag && (charMeta.autoGroundSplode || (hp < mhp / 4f && charAnim.CheckAnim(charMeta.groundsplode_anim) > -1)))
				{
					charAnim.SetAnim(charMeta.groundsplode_anim, this);
					charAnim.frame = 1.1f;
					TrySlow(charGrab.grabbedByChar, 0.02f);
					TrySlow(ID, 0.02f);
					Game1.character[ID].effectivelyDead = true;
					Game1.hud.ResetWaveDefeatedOkFrame();
				}
				else
				{
					hp -= 5f;
					if (num > 200f)
					{
						hp -= 10f;
						TrySlow(charGrab.grabbedByChar, 0.02f);
						TrySlow(ID, 0.02f);
						Sound.PlaySnd(Sound.Category.FX, "crush");
					}
					if (num > 400f)
					{
						hp -= 10f;
						TrySlow(charGrab.grabbedByChar, 0.04f);
						TrySlow(ID, 0.04f);
					}
					charAnim.SetAnim("bounce", this);
				}
				Game1.character[charGrab.grabbedByChar].charUpdate.traj = new Vector2(((face == 0) ? (-1f) : 1f) * 200f, traj.Y * -0.4f);
				if (Game1.character[charGrab.grabbedByChar].charUpdate.traj.Y < -1400f)
				{
					Game1.character[charGrab.grabbedByChar].charUpdate.traj.Y = -1400f;
				}
				if (Game1.character[charGrab.grabbedByChar].charUpdate.traj.Y > -700f)
				{
					Game1.character[charGrab.grabbedByChar].charUpdate.traj.Y = -700f;
				}
				Game1.character[charGrab.grabbedByChar].charUpdate.airJuggleFrame = 0f;
				Game1.character[charGrab.grabbedByChar].charUpdate.loc = loc;
				Game1.character[charGrab.grabbedByChar].charAnim.SetAnim(Game1.character[charGrab.grabbedByChar].GetMeta().flip_anim, Game1.character[charGrab.grabbedByChar].charUpdate);
				Game1.character[charGrab.grabbedByChar].charUpdate.etherealFrame = 0.2f;
				Game1.character[charGrab.grabbedByChar].charAnim.animName = "flipx";
				Game1.character[charGrab.grabbedByChar].charUpdate.state = State.Airborne;
				Game1.character[charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				charGrab.grabbedByChar = -1;
				Game1.killManager.doBits(0.8f);
				ethereal = true;
				Sound.PlaySnd(Sound.Category.FX, "crunch");
				Sound.PlaySnd(Sound.Category.FX, "bass");
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.scroll.Y += 30f;
			}
			else if (charAnim.animName == "jhit" || charAnim.animName == "jmid" || charAnim.animName == "jfall" || charAnim.animName == "bounce" || charAnim.animName == "spinhit")
			{
				if (hp < 0f && charMeta.autoGroundSplode && !flag)
				{
					charAnim.SetAnim(charMeta.groundsplode_anim, this);
					charAnim.frame = 0.95f;
				}
				else if (hp < 0f && slammedFrame > 0f && !flag)
				{
					charAnim.SetAnim(charMeta.groundsplode_anim, this);
					charAnim.frame = 0.95f;
					Sound.PlaySnd(Sound.Category.FX, "bass");
					Sound.PlaySnd(Sound.Category.FX, "thud");
					Sound.PlaySnd(Sound.Category.FX, "crunch");
				}
				else if (traj.Y > 900f && charAnim.CheckAnim("bounce") > -1)
				{
					charAnim.SetAnim("bounce", this);
					Sound.PlaySnd(Sound.Category.FX, "bass");
					Sound.PlaySnd(Sound.Category.FX, "thud");
					Sound.PlaySnd(Sound.Category.FX, "crunch");
					if (hp < 0f - mhp && charAnim.CheckAnim(charMeta.groundsplode_anim) > -1)
					{
						charAnim.SetAnim(charMeta.groundsplode_anim, this);
						charAnim.frame = 0.95f;
					}
				}
				else
				{
					charAnim.SetAnim(charMeta.hitland_anim, this);
					Sound.PlaySnd(Sound.Category.FX, "bass");
					Sound.PlaySnd(Sound.Category.FX, "thud");
				}
			}
			else
			{
				if (charMeta.isFlyingLanding)
				{
					int key = charAnim.GetKey();
					float frame = charAnim.GetFrame();
					charAnim.SetAnim(charMeta.land_anim, this);
					charAnim.SetKey(key);
					charAnim.SetFrame(frame);
				}
				else
				{
					charAnim.SetAnim(charMeta.land_anim, this);
				}
				Sound.PlaySnd(Sound.Category.FX, "land");
			}
		}
		loc.Y = map.GetMinY(loc);
		if (map.TestCol(loc - new Vector2(0f, 10f)))
		{
			loc.Y = map.GetMinY(loc - new Vector2(0f, 10f));
		}
		slammedFrame = 0f;
	}

	private bool TestCol(Vector2 v, Map map)
	{
		return charCols.TestCol(v, map, falling: false, warping: false);
	}

	private bool TestCol(Vector2 v, Map map, bool falling, bool warping)
	{
		return charCols.TestCol(v, map, falling, warping);
	}

	internal void Slow(float val)
	{
		if (Game1.camMgr.CanSlowAll())
		{
			FMan.Slow(val);
		}
		else if (val > slow)
		{
			slow = val;
		}
	}

	internal void ForceWarp()
	{
		warpFrame = 0.25f;
		warpVec.X = -1f;
		warpVec.Y = 0f;
	}

	internal void FixNetLoc()
	{
		netLoc = loc;
	}
}
