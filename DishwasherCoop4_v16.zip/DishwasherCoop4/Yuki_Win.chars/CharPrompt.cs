using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.chars;

public class CharPrompt
{
	private const int PROMPT_X = 0;

	private const int PROMPT_Y = 1;

	private const int PROMPT_B = 2;

	public bool promptX;

	public bool promptY;

	public bool promptB;

	private float frame;

	private int[] allPrompts = new int[3];

	public void Draw(Character me, SpriteBatch sprite, int threedee)
	{
		if (Game1.hud.shopMgr.IsActive())
		{
			return;
		}
		if (me.charUpdate.charGrab.grabbing)
		{
			promptX = false;
			promptB = false;
			promptY = false;
		}
		int num = 0;
		if (promptX)
		{
			allPrompts[num] = 0;
			num++;
		}
		if (promptY)
		{
			allPrompts[num] = 1;
			num++;
		}
		if (promptB)
		{
			allPrompts[num] = 2;
			num++;
		}
		if (num > 0)
		{
			int num2 = allPrompts[(int)(frame * 6f) % num];
			num = 1;
			Vector2 screenLoc = ScrollManager.GetScreenLoc(me.charUpdate.loc, 1f);
			screenLoc.X -= (float)(num - 1) * 32f;
			screenLoc.Y += 32f;
			float num3 = 0.6f;
			float num4 = frame * 6f - (float)(int)(frame * 6f);
			num4 -= 0.6f;
			if (num4 < 0f)
			{
				num4 = 0f;
			}
			num4 *= 0.5f;
			switch (threedee)
			{
			case 0:
				screenLoc.X++;
				break;
			case 1:
				screenLoc.X--;
				break;
			}
			Color color = new Color(1f, 1f, 1f, 0.7f);
			for (int i = 0; i < 2; i++)
			{
				sprite.Draw(Game1.spritesTex, screenLoc, new Rectangle(256 + Rand.GetRandomInt(0, 3) * 64, 192, 64, 64), new Color(1f, 1f, 1f, 0.3f), Rand.GetRandomFloat(0f, 6.28f), new Vector2(32f, 32f), num3 * 1.65f, SpriteEffects.None, 1f);
			}
			flibitPort.RenderingPlayer = Game1.mainPlayer[Math.Max(me.ID, 0)];
			if (num2 == 0)
			{
				flibitPort.DrawButtonAttrib('X', screenLoc, color, 0f, new Vector2(32f, 32f), num3 + num4, SpriteEffects.None, 1f);
			}
			if (num2 == 1)
			{
				flibitPort.DrawButtonAttrib('Y', screenLoc, color, 0f, new Vector2(32f, 32f), num3 + num4, SpriteEffects.None, 1f);
			}
			if (num2 == 2)
			{
				flibitPort.DrawButtonAttrib('B', screenLoc, color, 0f, new Vector2(32f, 32f), num3 + num4, SpriteEffects.None, 1f);
			}
			flibitPort.RenderingPlayer = 0;
			if ((int)(frame * 24f) % 2 == 0)
			{
				sprite.Draw(Game1.spritesTex, screenLoc, new Rectangle(800, 1088, 64, 64), new Color(1f, 1f, 1f, 0.5f), 0f, new Vector2(32f, 32f), num3 + num4, SpriteEffects.None, 1f);
			}
		}
	}

	public void Update(Character[] c, int ID)
	{
		promptX = false;
		promptY = false;
		promptB = false;
		frame += FMan.realTime;
		if (frame > 100f)
		{
			frame -= 100f;
		}
		if (c[ID].charUpdate.charGrab.CheckExeKillable(c[ID].charUpdate, c))
		{
			promptX = true;
			if (c[ID].charUpdate.state != CharUpdate.State.Grounded)
			{
				promptX = false;
			}
		}
		bool canGroundsplode = true;
		if (c[ID].GetMeta().isYuki && c[ID].charRender.melee != 1 && c[ID].charRender.melee != 2 && c[ID].charRender.melee != 5)
		{
			canGroundsplode = false;
		}
		if (c[ID].charUpdate.charGrab.CheckGrabKillable(c[ID].charUpdate, c, canGroundsplode))
		{
			promptB = true;
		}
		else
		{
			for (int i = 0; i < Game1.character.Length; i++)
			{
				if (!Game1.character[i].exists)
				{
					continue;
				}
				if (Game1.character[i].GetMeta().isShop)
				{
					Vector2 vector = c[ID].charUpdate.loc + new Vector2(((float)c[ID].charUpdate.face - 0.5f) * 100f, -70f);
					if (vector.X > Game1.character[i].charUpdate.loc.X - 70f && vector.X < Game1.character[i].charUpdate.loc.X + 70f && vector.Y > Game1.character[i].charUpdate.loc.Y - 90f && vector.Y < Game1.character[i].charUpdate.loc.Y + 5f)
					{
						promptB = true;
					}
				}
				else if (((Game1.character[ID].GetMeta().isYuki && Game1.character[i].GetMeta().isViolin) || (Game1.character[ID].GetMeta().isDish && Game1.character[i].GetMeta().isGuitar)) && !Game1.levelMgr.guitarEmpty)
				{
					Vector2 vector2 = c[ID].charUpdate.loc + new Vector2(((float)c[ID].charUpdate.face - 0.5f) * 100f, -70f);
					if (vector2.X > Game1.character[i].charUpdate.loc.X - 70f && vector2.X < Game1.character[i].charUpdate.loc.X + 70f && vector2.Y > Game1.character[i].charUpdate.loc.Y - 90f && vector2.Y < Game1.character[i].charUpdate.loc.Y + 5f)
					{
						promptB = true;
					}
				}
			}
		}
		if (c[ID].GetMeta().special != 3 && c[ID].GetMeta().special != 4 && (c[ID].GetMeta().isMara || c[ID].GetMeta().isYuki) && c[ID].charUpdate.charGrab.CheckSawKillable(c[ID].charUpdate, c))
		{
			promptY = true;
			if (Game1.player.yukiPhase < 6)
			{
				promptY = false;
			}
			if (c[ID].charUpdate.state == CharUpdate.State.Airborne)
			{
				promptY = false;
			}
		}
	}
}
