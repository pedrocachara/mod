using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;

namespace Yuki_Win.chars;

public class CharRect
{
	public enum RectHitType
	{
		None,
		Normal,
		MetalLegs
	}

	public Rectangle[] hitRect;

	public int[] rectType;

	public Vector2 baseSize;

	public CharRect()
	{
		hitRect = new Rectangle[16];
		for (int i = 0; i < hitRect.Length; i++)
		{
			hitRect[i] = default;
		}
		rectType = new int[16];
	}

	public void Draw(SpriteBatch sprite)
	{
		for (int i = 0; i < hitRect.Length; i++)
		{
			if (hitRect[i].Width > 0)
			{
				sprite.Draw(Game1.nullTex, ScrollManager.GetScreenLoc(new Vector2(hitRect[i].X, hitRect[i].Y), 1f), new Rectangle(0, 0, 1, 1), new Color(1f, 0f, 0f, 0.5f), 0f, new Vector2(0f, 0f), new Vector2(hitRect[i].Width, hitRect[i].Height) * ScrollManager.zoom, SpriteEffects.None, 1f);
			}
		}
	}

	public Vector2 GetSize()
	{
		Vector2 vector = new Vector2(hitRect[0].X, hitRect[0].Y);
		Vector2 vector2 = new Vector2(hitRect[0].Right, hitRect[0].Bottom);
		for (int i = 0; i < hitRect.Length; i++)
		{
			if (hitRect[i].Width > 0)
			{
				if ((float)hitRect[i].Left < vector.X)
				{
					vector.X = hitRect[i].Left;
				}
				if ((float)hitRect[i].Right > vector2.X)
				{
					vector2.X = hitRect[i].Right;
				}
				if ((float)hitRect[i].Top < vector.Y)
				{
					vector.Y = hitRect[i].Top;
				}
				if ((float)hitRect[i].Bottom > vector2.Y)
				{
					vector2.Y = hitRect[i].Bottom;
				}
			}
		}
		return vector2 - vector;
	}

	public int CheckHit(Vector2 loc, bool wide)
	{
		return CheckHit(loc, wide, 0);
	}

	public int CheckHit(Vector2 loc, bool wide, int playercol)
	{
		int num = (int)loc.X;
		int num2 = (int)loc.Y;
		int num3 = (wide ? 50 : 0);
		num3 += playercol;
		for (int i = 0; i < hitRect.Length; i++)
		{
			if (hitRect[i].Width > 0 && num > hitRect[i].X - num3 && num2 > hitRect[i].Y && num < hitRect[i].Right + num3 && num2 < hitRect[i].Bottom)
			{
				return rectType[i];
			}
		}
		return -1;
	}

	public void UpdateRects(Vector2 loc, float scale, int face, int frameIdx, Character c, int ID, int next)
	{
		CharDef charDef = Game1.charDef[c.cDef];
		int num = 0;
		face = 1 - face;
		Rectangle rectangle = default;
		if (charDef == null)
		{
			return;
		}
		Frame frame = charDef.GetFrame(frameIdx);
		for (int i = 0; i < hitRect.Length; i++)
		{
			hitRect[i].Width = 0;
		}
		for (int j = 0; j < frame.GetPartArray().Length; j++)
		{
			Frame.Part part = frame.GetPart(j);
			if (part.idx <= -1 || part.idx >= 1000)
			{
				continue;
			}
			rectangle.Width = 0;
			float rotation = part.rotation;
			Vector2 vector = part.location * scale + loc;
			Vector2 vector2 = part.scaling * scale;
			if (face == 0)
			{
				rotation = 0f - rotation;
				vector.X -= part.location.X * scale * 2f;
			}
			if (next > -1)
			{
				Frame frame2 = charDef.GetFrame(next);
				if (Frame.CanLerp(frame, frame2, j))
				{
					Frame.Part part2 = frame2.GetPart(j);
					Animation animation = charDef.GetAnimation(c.charAnim.anim);
					KeyFrame keyFrame = animation.GetKeyFrame(c.charAnim.GetKey());
					float num2 = c.charAnim.frame / (float)keyFrame.duration;
					if (MainPlayer.uberDyingFrame >= 1f && Game1.gameMap.lichFreakoutMode)
					{
						num2 = (float)(int)(num2 * (float)keyFrame.duration) / (float)keyFrame.duration;
					}
					Vector2 location = part.location;
					Vector2 location2 = part2.location;
					float num3 = part.rotation;
					float num4 = part2.rotation;
					if (face == 0)
					{
						num3 = 0f - num3;
						num4 = 0f - num4;
						location.X -= part.location.X * 2f;
						location2.X -= part2.location.X * 2f;
					}
					vector = Frame.LerpLoc(location, location2, num2) * scale + loc;
					rotation = Frame.LerpRotation(num3, num4, num2);
					vector2 = Frame.LerpScale(part.scaling, part2.scaling, num2) * scale;
				}
			}
			if (c.GetMeta().isPuppeteer)
			{
				Game1.gameMap.isPuppeteer = true;
				if (part.idx / 64 == 2 && part.idx % 2 == 1 && num < 4)
				{
					Game1.gameMap.fingerVec[num] = vector;
					num++;
				}
			}
			int num5 = part.idx / 64;
			CharMeta meta = c.GetMeta();
			switch (num5)
			{
			case 0:
				rectangle = Game1.headTexMeta[meta.headTex].GetRect(part.idx);
				break;
			case 1:
				rectangle = Game1.torsoTexMeta[meta.torsoTex].GetRect(part.idx - 64);
				break;
			case 2:
				rectangle = Game1.legsTexMeta[meta.legsTex].GetRect(part.idx - 128);
				break;
			case 3:
				rectangle = Game1.weaponTexMeta[meta.weapTex].GetRect(part.idx - 192);
				break;
			case 4:
				rectangle = Game1.auxTexMeta[meta.weapTex].GetRect(part.idx - 192);
				break;
			}
			float num6 = (vector2.X + vector2.Y) / 2f;
			hitRect[j] = rectangle;
			hitRect[j].Width = (hitRect[j].Width + hitRect[j].Height) / 2;
			num6 *= 0.7f;
			hitRect[j].Width = (int)((float)hitRect[j].Width * num6);
			hitRect[j].Height = hitRect[j].Width;
			hitRect[j].X = (int)vector.X - hitRect[j].Width / 2;
			hitRect[j].Y = (int)vector.Y - hitRect[j].Height / 2;
			rectType[j] = num5;
			if (num5 == 2 && meta.isNoLegs)
			{
				hitRect[j].Width = 0;
			}
		}
		if (baseSize.X <= 0f)
		{
			baseSize = GetSize();
		}
	}

	public void UpdateRects(Vector2 loc, float scale, int face, int frameIdx, Character c, int ID)
	{
		CharDef charDef = Game1.charDef[c.cDef];
		face = 1 - face;
		Rectangle rectangle = default;
		if (charDef == null)
		{
			return;
		}
		Frame frame = charDef.GetFrame(frameIdx);
		for (int i = 0; i < hitRect.Length; i++)
		{
			hitRect[i].Width = 0;
		}
		for (int j = 0; j < frame.GetPartArray().Length; j++)
		{
			Frame.Part part = frame.GetPart(j);
			if (part.idx > -1 && part.idx < 1000)
			{
				rectangle.Width = 0;
				float rotation = part.rotation;
				Vector2 vector = part.location * scale + loc;
				Vector2 vector2 = part.scaling * scale;
				if (face == 0)
				{
					rotation = 0f - rotation;
					vector.X -= part.location.X * scale * 2f;
				}
				int num = part.idx / 64;
				CharMeta meta = c.GetMeta();
				switch (num)
				{
				case 0:
					rectangle = Game1.headTexMeta[meta.headTex].GetRect(part.idx);
					break;
				case 1:
					rectangle = Game1.torsoTexMeta[meta.torsoTex].GetRect(part.idx - 64);
					break;
				case 2:
					rectangle = Game1.legsTexMeta[meta.legsTex].GetRect(part.idx - 128);
					break;
				case 3:
					rectangle = Game1.weaponTexMeta[meta.weapTex].GetRect(part.idx - 192);
					break;
				case 4:
					rectangle = Game1.auxTexMeta[meta.weapTex].GetRect(part.idx - 192);
					break;
				}
				float num2 = (vector2.X + vector2.Y) / 2f;
				hitRect[j] = rectangle;
				hitRect[j].Width = (hitRect[j].Width + hitRect[j].Height) / 2;
				num2 *= 0.7f;
				hitRect[j].Width = (int)((float)hitRect[j].Width * num2);
				hitRect[j].Height = hitRect[j].Width;
				hitRect[j].X = (int)vector.X - hitRect[j].Width / 2;
				hitRect[j].Y = (int)vector.Y - hitRect[j].Height / 2;
				rectType[j] = num;
				if (num == 2 && meta.isNoLegs)
				{
					hitRect[j].Width = 0;
				}
			}
		}
		if (baseSize.X <= 0f)
		{
			baseSize = GetSize();
		}
	}
}
