using System.IO;
using xCharEdit.Character;

namespace Yuki_Win.chars;

public class CharDef
{
	public const int DEF_YUKI = 0;

	public const int DEF_HUMAN = 1;

	public const int DEF_TANK = 2;

	public const int DEF_DISH = 3;

	public const int DEF_BLADE = 4;

	public const int DEF_NEKO = 5;

	public const int DEF_GOWN = 6;

	public const int DEF_PRISON = 7;

	public const int DEF_POD = 8;

	public const int DEF_CROW = 9;

	public const int DEF_CRETIN = 10;

	public const int DEF_LICH = 11;

	public const int DEF_WARDEN = 12;

	public const int DEF_GOREFACE = 13;

	public const int DEF_SLAVA = 14;

	public const int DEF_SKELETANK = 15;

	public const int DEF_FORCE = 16;

	public const int DEF_BOX = 17;

	public const int DEF_MURDERFLY = 18;

	public const int DEF_HOCKEY = 19;

	public const int DEF_DRAGON = 20;

	public const int DEF_INVALID = 21;

	public const int DEF_SHOP = 22;

	public const int DEF_SAMURAI = 23;

	public const int DEF_SHARK = 24;

	public const int DEF_SQUID = 25;

	public const int DEF_ENGINEER = 26;

	public const int DEF_PUPPET = 27;

	public const int DEF_BIGENGIE = 28;

	public const int DEF_HORSE = 29;

	public const int DEF_MIDENGIE = 30;

	public const int DEF_SWORDSMAN = 31;

	public const int DEF_CHEF = 32;

	public const int DEF_RAVEN = 33;

	public const int DEF_TRANSMARA = 34;

	public const int DEF_HYPNO = 35;

	public const int DEF_ASSASSIN = 36;

	private Animation[] animation;

	private Frame[] frame;

	public string path;

	public int headIdx;

	public int torsoIdx;

	public int legsIdx;

	public int weaponIdx;

	public int auxIdx;

	public CharDef()
	{
		path = "char";
	}

	public CharDef(string path)
	{
		animation = new Animation[256];
		frame = new Frame[2048];
		this.path = path;
		ReadShort(abs: true);
	}

	public CharDef(BinaryReader reader)
	{
		animation = new Animation[256];
		frame = new Frame[2048];
		ReadFatShort(reader);
	}

	public Animation GetAnimation(int idx)
	{
		if (idx < animation.Length)
		{
			return animation[idx];
		}
		return null;
	}

	public void SetAnimation(int idx, Animation _animation)
	{
		animation[idx] = _animation;
	}

	public Animation[] GetAnimationArray()
	{
		return animation;
	}

	public Frame GetFrame(int idx)
	{
		if (idx < 0)
		{
			idx = 0;
		}
		if (idx < frame.Length)
		{
			return frame[idx];
		}
		return frame[0];
	}

	public void SetFrame(int idx, Frame _frame)
	{
		frame[idx] = _frame;
	}

	public Frame[] GetFrameArray()
	{
		return frame;
	}

	public void Read()
	{
		Read(abs: false);
	}

	public void Read(bool abs)
	{
		BinaryReader binaryReader = (abs ? new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read)) : new BinaryReader(File.Open("data/" + path + ".zmx", FileMode.Open, FileAccess.Read)));
		path = binaryReader.ReadString();
		headIdx = binaryReader.ReadInt32();
		torsoIdx = binaryReader.ReadInt32();
		legsIdx = binaryReader.ReadInt32();
		weaponIdx = binaryReader.ReadInt32();
		for (int i = 0; i < animation.Length; i++)
		{
			animation[i] = new Animation();
			animation[i].name = binaryReader.ReadString();
			if (!(animation[i].name != ""))
			{
				continue;
			}
			int num = binaryReader.ReadInt32();
			for (int j = 0; j < num; j++)
			{
				animation[i].getKeyFrameArray()[j] = new KeyFrame();
				KeyFrame keyFrame = animation[i].GetKeyFrame(j);
				keyFrame.frameRef = binaryReader.ReadInt32();
				keyFrame.duration = binaryReader.ReadInt32();
				keyFrame.getScriptArray();
				byte b = binaryReader.ReadByte();
				for (byte b2 = 0; b2 < b; b2++)
				{
					keyFrame.SetScript(b2, binaryReader.ReadString());
				}
			}
		}
		for (int k = 0; k < frame.Length; k++)
		{
			frame[k] = new Frame();
			frame[k].name = binaryReader.ReadString();
			if (frame[k].name != "")
			{
				for (int l = 0; l < frame[k].GetPartArray().Length; l++)
				{
					frame[k].GetPart(l);
					binaryReader.ReadInt32();
					binaryReader.ReadSingle();
					binaryReader.ReadSingle();
					binaryReader.ReadSingle();
					binaryReader.ReadSingle();
					binaryReader.ReadSingle();
					binaryReader.ReadInt32();
				}
			}
		}
		binaryReader.Close();
	}

	public void ReadFatShort(BinaryReader b)
	{
		path = b.ReadString();
		headIdx = b.ReadInt32();
		torsoIdx = b.ReadInt32();
		legsIdx = b.ReadInt32();
		weaponIdx = b.ReadInt32();
		int num = b.ReadInt32();
		animation = new Animation[num];
		for (int i = 0; i < num; i++)
		{
			animation[i] = new Animation();
			animation[i].name = b.ReadString();
			if (!(animation[i].name != ""))
			{
				continue;
			}
			int num2 = b.ReadInt32();
			for (int j = 0; j < num2; j++)
			{
				animation[i].getKeyFrameArray()[j] = new KeyFrame();
				KeyFrame keyFrame = animation[i].GetKeyFrame(j);
				keyFrame.frameRef = b.ReadInt32();
				keyFrame.duration = b.ReadInt32();
				keyFrame.lerp = b.ReadBoolean();
				keyFrame.getScriptArray();
				byte b2 = b.ReadByte();
				for (byte b3 = 0; b3 < b2; b3++)
				{
					keyFrame.SetScriptCommand(b3, b);
				}
			}
		}
		int num3 = b.ReadInt32();
		frame = new Frame[num3];
		for (int k = 0; k < frame.Length; k++)
		{
			if (b.ReadBoolean())
			{
				frame[k] = new Frame();
				frame[k].parts = b.ReadInt32();
				for (int l = 0; l < frame[k].parts; l++)
				{
					frame[k].part[l].idx = b.ReadInt32();
					frame[k].part[l].location.X = b.ReadSingle();
					frame[k].part[l].location.Y = b.ReadSingle();
					frame[k].part[l].rotation = b.ReadSingle();
					frame[k].part[l].scaling.X = b.ReadSingle();
					frame[k].part[l].scaling.Y = b.ReadSingle();
					frame[k].part[l].flip = b.ReadInt32();
				}
			}
		}
	}

	public void ReadShort(bool abs)
	{
		BinaryReader binaryReader = (abs ? new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read)) : new BinaryReader(File.Open("data/" + path + ".zmx", FileMode.Open, FileAccess.Read)));
		path = binaryReader.ReadString();
		headIdx = binaryReader.ReadInt32();
		torsoIdx = binaryReader.ReadInt32();
		legsIdx = binaryReader.ReadInt32();
		weaponIdx = binaryReader.ReadInt32();
		int num = binaryReader.ReadInt32();
		animation = new Animation[num];
		for (int i = 0; i < num; i++)
		{
			animation[i] = new Animation();
			animation[i].name = binaryReader.ReadString();
			if (!(animation[i].name != ""))
			{
				continue;
			}
			int num2 = binaryReader.ReadInt32();
			for (int j = 0; j < num2; j++)
			{
				animation[i].getKeyFrameArray()[j] = new KeyFrame();
				KeyFrame keyFrame = animation[i].GetKeyFrame(j);
				keyFrame.frameRef = binaryReader.ReadInt32();
				keyFrame.duration = binaryReader.ReadInt32();
				keyFrame.lerp = binaryReader.ReadBoolean();
				keyFrame.getScriptArray();
				byte b = binaryReader.ReadByte();
				for (byte b2 = 0; b2 < b; b2++)
				{
					keyFrame.SetScriptCommand(b2, binaryReader);
				}
			}
		}
		int num3 = binaryReader.ReadInt32();
		frame = new Frame[num3];
		for (int k = 0; k < frame.Length; k++)
		{
			if (binaryReader.ReadBoolean())
			{
				frame[k] = new Frame();
				frame[k].parts = binaryReader.ReadInt32();
				for (int l = 0; l < frame[k].parts; l++)
				{
					frame[k].part[l].idx = binaryReader.ReadInt32();
					frame[k].part[l].location.X = binaryReader.ReadSingle();
					frame[k].part[l].location.Y = binaryReader.ReadSingle();
					frame[k].part[l].rotation = binaryReader.ReadSingle();
					frame[k].part[l].scaling.X = binaryReader.ReadSingle();
					frame[k].part[l].scaling.Y = binaryReader.ReadSingle();
					frame[k].part[l].flip = binaryReader.ReadInt32();
				}
			}
		}
		binaryReader.Close();
	}
}
