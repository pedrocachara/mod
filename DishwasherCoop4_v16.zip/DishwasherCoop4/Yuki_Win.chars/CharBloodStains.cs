using System.Collections.Generic;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.chars;

public class CharBloodStains
{
	public enum CharBloodStainType
	{
		DishWeapon,
		YukiWeapon,
		YukiTorso,
		YukiBiteFace,
		YukiBiteChest,
		YukiHead,
		DishTorso,
		DishHead,
		DishSmash,
		YukiWeapon2,
		YukiWeapon3,
		DishWeapon2,
		DishWeapon3
	}

	public Dictionary<int, Texture2D> charBloodTexture;

	public void Init(ContentManager Content)
	{
		charBloodTexture = new Dictionary<int, Texture2D>();
		charBloodTexture.Add(0, Content.Load<Texture2D>("gfx/blood/dish"));
		charBloodTexture.Add(1, Content.Load<Texture2D>("gfx/blood/yuki"));
		charBloodTexture.Add(9, Content.Load<Texture2D>("gfx/blood/yuki2"));
		charBloodTexture.Add(10, Content.Load<Texture2D>("gfx/blood/yuki3"));
		charBloodTexture.Add(11, Content.Load<Texture2D>("gfx/blood/dish2"));
		charBloodTexture.Add(12, Content.Load<Texture2D>("gfx/blood/dish3"));
		charBloodTexture.Add(2, Content.Load<Texture2D>("gfx/blood/yukitorso"));
		charBloodTexture.Add(3, Content.Load<Texture2D>("gfx/blood/yukifacebite"));
		charBloodTexture.Add(4, Content.Load<Texture2D>("gfx/blood/yukibitechest"));
		charBloodTexture.Add(5, Content.Load<Texture2D>("gfx/blood/yukihead"));
		charBloodTexture.Add(6, Content.Load<Texture2D>("gfx/blood/dishtorso"));
		charBloodTexture.Add(7, Content.Load<Texture2D>("gfx/blood/dishhead"));
		charBloodTexture.Add(8, Content.Load<Texture2D>("gfx/blood/dishsmash"));
	}
}
