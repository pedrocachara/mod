using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;
using Yuki_Win.player;
using Yuki_Win.sprites.gibs;

namespace Yuki_Win.chars;

public class CharGibSpray
{
	private Giblet[] giblet;

	private int curGiblet;

	private int gibletCount;

	private Vector2 tetherVec;

	private Vector2 tetherGoal;

	private bool tether;

	public bool active;

	public bool justUpdated;

	public float addFrame;

	public int ID;

	public void Update(Vector2 tether, CharTrigs.SprayType sprayType, Character c)
	{
		Update(istether: true, tether, sprayType, c);
	}

	public void Update(CharTrigs.SprayType sprayType, Character c)
	{
		Update(istether: false, default, sprayType, c);
	}

	private void Update(bool istether, Vector2 tetherVec, CharTrigs.SprayType sprayType, Character c)
	{
		active = false;
		if ((sprayType == CharTrigs.SprayType.Blood || sprayType == CharTrigs.SprayType.WeaponSpray) && addFrame > 0.02f)
		{
			addFrame = 0.02f;
		}
		if (addFrame >= 0f)
		{
			addFrame -= FMan.frameTime;
		}
		if (istether)
		{
			tether = true;
			tetherGoal = tetherVec;
			this.tetherVec = tetherVec;
		}
		else if (tether)
		{
			tether = false;
			Add(tetherGoal, giblet[curGiblet].traj + Rand.GetRandomVec2(-100f, 100f, -100f, 100f));
		}
		for (int i = 0; i < giblet.Length; i++)
		{
			if (!(giblet[i].frame > 0f))
			{
				continue;
			}
			float frame = giblet[i].frame;
			switch (sprayType)
			{
			case CharTrigs.SprayType.Flame:
			case CharTrigs.SprayType.NullFlame:
			case CharTrigs.SprayType.DragonFlame:
			case CharTrigs.SprayType.NullDragonFlame:
				_ = giblet[i].loc;
				if (sprayType == CharTrigs.SprayType.NullFlame && !c.GetMeta().isGiant)
				{
					giblet[i].Update(-100f, c.ID, (istether && i == curGiblet) ? tetherVec : GetNext(giblet, i));
				}
				else
				{
					giblet[i].Update(-1200f, c.ID, (istether && i == curGiblet) ? tetherVec : GetNext(giblet, i));
				}
				if (Game1.gameMap.CurMap().TestCol(giblet[i].loc))
				{
					giblet[i].traj.Y *= -0.1f;
					giblet[i].traj.X *= 0.8f;
				}
				if ((sprayType == CharTrigs.SprayType.Flame || sprayType == CharTrigs.SprayType.DragonFlame) && giblet[i].frame > 0.4f)
				{
					Game1.spriteMan.AddSprite(12, giblet[i].loc, -giblet[i].traj, 0f, 86, ID);
				}
				if (sprayType == CharTrigs.SprayType.DragonFlame && giblet[i].frame > 0.4f && (int)(giblet[i].frame * 40f) != (int)(frame * 40f))
				{
					for (int k = 0; k < 2; k++)
					{
						Game1.spriteMan.AddSprite(66, giblet[i].loc + Rand.GetRandomVec2(-50f, 50f, -50f, 50f), default, (giblet[i].frame - 0.3f) * 1.5f, Rand.GetRandomInt(0, 3), 0);
					}
				}
				break;
			case CharTrigs.SprayType.SquirtGun:
				giblet[i].Update(800f, c.ID, (istether && i == curGiblet) ? tetherVec : GetNext(giblet, i));
				if (Game1.gameMap.CurMap().TestCol(giblet[i].loc))
				{
					giblet[i].frame -= FMan.frameTime * 20f;
				}
				giblet[i].frame -= FMan.frameTime * 0.4f;
				if (giblet[i].frame > 0.4f)
				{
					Game1.spriteMan.AddSprite(12, giblet[i].loc, default, 0f, 118, ID);
				}
				break;
			default:
			{
				giblet[i].Update(1200f, c.ID, 1.8f, (istether && i == curGiblet) ? tetherVec : GetNext(giblet, i));
				if (Game1.gameMap.CurMap().TestCol(giblet[i].loc))
				{
					giblet[i].frame -= FMan.frameTime * 4f;
				}
				if (sprayType == CharTrigs.SprayType.Blood || sprayType == CharTrigs.SprayType.WeaponSpray)
				{
					giblet[i].frame -= FMan.frameTime * 0.4f;
				}
				if (Rand.CointToss(0.1f))
				{
					Game1.spriteMan.AddWallblood(giblet[i].loc);
				}
				if ((sprayType == CharTrigs.SprayType.Blood || sprayType == CharTrigs.SprayType.Giantblood) && (int)(frame * 30f) != (int)(giblet[i].frame * 30f) && Rand.CointToss(0.1f))
				{
					Game1.spriteMan.AddSprite(7, giblet[i].loc, giblet[i].traj * 0.1f, 1f, -1, c.ID);
				}
				for (int j = 0; j < 2; j++)
				{
					if (Game1.character[j].exists)
					{
						Vector2 loc = Game1.character[j].charUpdate.loc;
						if (giblet[i].loc.X > loc.X - 50f && giblet[i].loc.X < loc.X + 50f && giblet[i].loc.Y > loc.Y - 100f && giblet[i].loc.Y < loc.Y)
						{
							Game1.character[j].charUpdate.StainBody(0);
						}
					}
				}
				break;
			}
			}
			active = true;
		}
	}

	private Vector2 GetNext(Giblet[] giblet, int i)
	{
		if (i < giblet.Length - 1)
		{
			return giblet[i + 1].loc;
		}
		return new Vector2(-1000f, -1000f);
	}

	internal void Draw(SpriteBatch sprite, CharTrigs.SprayType sprayType, bool thresh)
	{
		int num = 0;
		Vector2 vector = ScrollManager.GetScreenLoc(giblet[curGiblet].loc, 1f);
		GameRender.threshRender.AddPoint(vector, 10f);
		int num2 = curGiblet;
		if (tether)
		{
			num2 = (num2 + 1) % giblet.Length;
			vector = ScrollManager.GetScreenLoc(tetherVec, 1f);
		}
		else
		{
			num = 1;
		}
		Vector2 vector2 = vector;
		float num3 = 1f;
		for (int i = num; i < gibletCount; i++)
		{
			num2 = (num2 + (giblet.Length - 1)) % giblet.Length;
			vector2 = ScrollManager.GetScreenLoc(giblet[num2].loc, 1f);
			GameRender.threshRender.AddPoint(vector2, 10f);
			float num4 = ((sprayType == CharTrigs.SprayType.Blood) ? 1.2f : 2.8f);
			float num5 = ((sprayType == CharTrigs.SprayType.Blood) ? 0.4f : 0.6f);
			float num6 = (vector - vector2).Length();
			int y = ((sprayType == CharTrigs.SprayType.Blood) ? 1024 : 960);
			if (sprayType == CharTrigs.SprayType.WeaponSpray)
			{
				y = 960;
				num4 = 1f;
				num5 = 0.3f;
			}
			if (sprayType == CharTrigs.SprayType.Giantblood && num6 > 0f)
			{
				float num7 = ScrollManager.cannedDepth[0];
				float num8 = num4 * num7 / num6;
				float num9 = 0.05f;
				if (num8 > num9)
				{
					num8 = num9;
					num4 = num8 * num6 / num7;
				}
			}
			if (sprayType == CharTrigs.SprayType.Blood && num6 > 0f)
			{
				float num10 = ScrollManager.cannedDepth[0];
				float num11 = num4 * num10 / num6;
				float num12 = 0.05f;
				if (num11 > num12)
				{
					num11 = num12;
					num4 = num11 * num6 / num10;
				}
			}
			if (GameSettings.difficulty == 0)
			{
				sprite.Draw(Game1.spritesTex, (vector + vector2) / (num3 * 2f), new Rectangle(1025, 961 - num2 % 3 * 32, 62, 30), new Color(1f, 1f, 1f, giblet[num2].frame * num5 * 0.8f), giblet[num2].rotation, new Vector2(31f, 15f), new Vector2(num6 / 40f, num4 * ScrollManager.cannedDepth[0] * (0.95f - giblet[num2].frame)) / num3, SpriteEffects.None, 1f);
			}
			else if (Game1.gameMap.goryoAlpha > 0f)
			{
				sprite.Draw(Game1.spritesTex, (vector + vector2) / (num3 * 2f), new Rectangle(512, 960, 128, 64), new Color(1f, 1f, 1f, giblet[num2].frame * num5 * 0.9f), giblet[num2].rotation, new Vector2(64f, 32f), new Vector2(num6 / 110f, num4 * ScrollManager.cannedDepth[0] * (0.95f - giblet[num2].frame) * 0.6f) / num3, SpriteEffects.None, 1f);
			}
			else
			{
				float num13 = GameRender.bloodR;
				if (giblet[num2].frame > 0.5f)
				{
					num13 -= giblet[num2].frame - 0.5f;
					if (num13 < 0f)
					{
						num13 = 0f;
					}
				}
				if (num13 > 0f)
				{
					sprite.Draw(Game1.spritesTex, (vector + vector2) / (num3 * 2f), new Rectangle(num2 % 4 * 96, y, 96, 64), new Color(num13, num13, num13, giblet[num2].frame * num5 * 5f * (thresh ? 2f : 1f)), giblet[num2].rotation, new Vector2(48f, 32f), new Vector2(num6 / 80f, num4 * ScrollManager.cannedDepth[0] * (0.95f - giblet[num2].frame)) / num3, SpriteEffects.None, 1f);
				}
			}
			vector = vector2;
		}
	}

	internal void DrawSquirtGun(SpriteBatch sprite, CharTrigs.SprayType sprayType, bool refract)
	{
		int num = 0;
		Vector2 vector = ScrollManager.GetScreenLoc(giblet[curGiblet].loc, 1f);
		int num2 = curGiblet;
		if (tether)
		{
			num2 = (num2 + 1) % giblet.Length;
			vector = ScrollManager.GetScreenLoc(tetherVec, 1f);
		}
		else
		{
			num = 1;
		}
		Vector2 vector2 = vector;
		for (int i = num; i < gibletCount; i++)
		{
			num2 = (num2 + (giblet.Length - 1)) % giblet.Length;
			vector2 = ScrollManager.GetScreenLoc(giblet[num2].loc, 1f);
			float num3 = (giblet[num2].frame - 0.3f) * 0.95f;
			float num4 = 1f * ScrollManager.cannedDepth[0] * (0.85f - giblet[num2].frame);
			if (num4 > 4f)
			{
				num4 = 8f - num4;
			}
			float num5 = (vector - vector2).Length() / 120f;
			if (giblet[num2].frame < 0.25f)
			{
				num5 *= giblet[num2].frame * 4f;
			}
			if (num5 > 80f)
			{
				num5 = 80f;
			}
			if (num5 < num4 * 0.4f)
			{
				num4 *= num5 / (num4 * 0.4f);
			}
			if (refract)
			{
				sprite.Draw(Game1.spritesTex, (vector + vector2) / 2f, new Rectangle(num2 % 4 * 128 + 512, 960, 128, 64), new Color(num3, num3, num3, 0.2f), giblet[num2].rotation, new Vector2(64f, 32f), new Vector2(num5, num4 * 0.5f), SpriteEffects.None, 1f);
				sprite.Draw(Game1.spritesTex, (vector + vector2) / 2f, new Rectangle(num2 % 4 * 128 + 512, 960, 128, 64), new Color(num3, num3, num3, 0.5f), giblet[num2].rotation, new Vector2(64f, 32f), new Vector2(num5, num4 * 0.15f), SpriteEffects.None, 1f);
			}
			else
			{
				sprite.Draw(Game1.spritesTex, (vector + vector2) / 2f, new Rectangle(num2 % 4 * 128 + 512, 960, 128, 64), new Color(1f, 1f, 1f, num3), giblet[num2].rotation, new Vector2(64f, 32f), new Vector2(num5, num4 * 0.6f), SpriteEffects.None, 1f);
			}
			vector = vector2;
		}
	}

	internal void DrawFlame(SpriteBatch sprite, CharTrigs.SprayType sprayType)
	{
		int num = 0;
		Vector2 vector = ScrollManager.GetScreenLoc(giblet[curGiblet].loc, 1f);
		int num2 = curGiblet;
		if (tether)
		{
			num2 = (num2 + 1) % giblet.Length;
			vector = ScrollManager.GetScreenLoc(tetherVec, 1f);
			PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(tetherVec, 1f), 1f, 0.8f, 0.6f, 0.3f, Rand.GetRandomFloat(0.1f, 1.1f), 0f);
		}
		else
		{
			num = 1;
		}
		Vector2 vector2 = vector;
		for (int i = num; i < gibletCount; i++)
		{
			num2 = (num2 + (giblet.Length - 1)) % giblet.Length;
			vector2 = ScrollManager.GetScreenLoc(giblet[num2].loc, 1f);
			float r = giblet[num2].frame * 1.5f;
			float num3 = (giblet[num2].frame - 0.3f) * 2f;
			float num4 = (giblet[num2].frame - 0.6f) * 4f;
			if (num3 < 0f)
			{
				num3 = 0f;
			}
			if (num4 < 0f)
			{
				num4 = 0f;
			}
			float num5 = 5f * ScrollManager.cannedDepth[0] * (0.85f - giblet[num2].frame);
			float num6 = num5 - 4f;
			if (num5 > 4f)
			{
				num5 = 8f - num5;
			}
			float num7 = (vector - vector2).Length() / 120f;
			if (giblet[num2].frame < 0.25f)
			{
				num7 *= giblet[num2].frame * 4f;
			}
			if (num7 > 80f)
			{
				num7 = 80f;
			}
			if (num7 < num5 * 0.4f)
			{
				num5 *= num7 / (num5 * 0.4f);
			}
			if (sprayType == CharTrigs.SprayType.DragonFlame || sprayType == CharTrigs.SprayType.NullDragonFlame)
			{
				if (sprayType == CharTrigs.SprayType.DragonFlame)
				{
					num5 *= 2.5f;
				}
				num4 = giblet[num2].frame * 1.5f;
				num3 = (giblet[num2].frame - 0.3f) * 2f;
				r = (giblet[num2].frame - 0.6f) * 4f;
			}
			sprite.Draw(Game1.spritesTex, (vector + vector2) / 2f, new Rectangle(num2 % 4 * 128 + 512, 960, 128, 64), new Color(r, num3, num4, 0.7f), giblet[num2].rotation, new Vector2(64f, 32f), new Vector2(num7, num5), SpriteEffects.None, 1f);
			if (num6 > 0f)
			{
				if (giblet[num2].frame < 0.1f)
				{
					num6 *= giblet[num2].frame * 10f;
				}
				if (num6 > 0.1f)
				{
					PostGlowMgr.AddGlow((vector + vector2) / 2f, r, num3, num4, num6 * 0.95f * ((sprayType == CharTrigs.SprayType.NullFlame || sprayType == CharTrigs.SprayType.NullDragonFlame) ? 0.25f : 1f), Rand.GetRandomFloat(0.1f, 1.1f), 0f);
				}
			}
			vector = vector2;
		}
	}

	public CharGibSpray(int ID)
	{
		this.ID = ID;
		giblet = new Giblet[20];
		for (int i = 0; i < giblet.Length; i++)
		{
			giblet[i] = new Giblet();
		}
	}

	public void Add(Vector2 loc, Vector2 traj)
	{
		if (giblet[curGiblet].frame < 0.7f && gibletCount > 0)
		{
			giblet[curGiblet].frame = 0f;
			curGiblet = (curGiblet + 1) % giblet.Length;
		}
		Vector2 traj2 = giblet[curGiblet].traj;
		curGiblet = (curGiblet + 1) % giblet.Length;
		if (gibletCount < giblet.Length)
		{
			gibletCount++;
		}
		traj = (traj2 + traj) / 2f;
		giblet[curGiblet].Snap(loc, traj);
		addFrame = Rand.GetRandomFloat(0.04f, 0.05f);
	}

	public void Init(Vector2 loc, Vector2 traj)
	{
		tetherVec = (tetherGoal = loc);
		gibletCount = 0;
		Add(loc, traj);
		active = true;
		addFrame = Rand.GetRandomFloat(0.04f, 0.05f);
	}

	internal void Reset()
	{
		active = false;
		for (int i = 0; i < giblet.Length; i++)
		{
			giblet[i].frame = -1f;
		}
	}
}
