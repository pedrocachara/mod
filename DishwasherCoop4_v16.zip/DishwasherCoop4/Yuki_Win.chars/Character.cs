using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;
using Yuki_Win.achievements.cheevos;
using Yuki_Win.ai;
using Yuki_Win.arcade;
using Yuki_Win.debug;
using Yuki_Win.levels;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.sprites;

namespace Yuki_Win.chars;

public class Character
{
	public enum Reward
	{
		None,
		Pickup,
		Health,
		Gold
	}

	public enum Team
	{
		GoodGuys,
		BadGuys
	}

	public CharRender charRender;

	public CharUpdate charUpdate;

	public CharAnim charAnim;

	public CharKeys charKeys;

	public int cDef;

	public int charMeta;

	public CharRect charRect;

	public ComboProfile comboProfile;

	public CharPhysics charPhysics;

	public AI ai;

	public int ID;

	public string tag;

	public bool exists;

	public CharNetUpdate netUpdate;

	public bool effectivelyDead;

	public Reward reward;

	public int loadOut;

	public int weapIdx;

	public Team team;

	public CharMeta GetMeta()
	{
		return Game1.charMeta[charMeta];
	}

	public Character(int ID)
	{
		this.ID = ID;
		ai = new AI(-1, ID);
		exists = false;
		charRender = new CharRender();
		charKeys = new CharKeys();
		charUpdate = new CharUpdate(ID);
		charRect = new CharRect();
		comboProfile = new ComboProfile();
		charPhysics = new CharPhysics();
		charAnim = new CharAnim(ID);
		netUpdate = new CharNetUpdate(ID);
	}

	public bool GetGrabbable()
	{
		return GetGrabbable(dummy: false);
	}

	public bool GetGrabbable(bool dummy)
	{
		CharMeta charMeta = Game1.charMeta[this.charMeta];
		if (charMeta.isunaware)
		{
			return true;
		}
		if (charUpdate.ethereal)
		{
			return false;
		}
		if (charMeta.isJuggernaut)
		{
			if (charUpdate.state == CharUpdate.State.Grounded && (charUpdate.hp <= 0f || charUpdate.giantVulnTimer > 0f || charMeta.isQuickGrabbable) && charAnim.CheckAnim(charMeta.katgrabbed_anim) > -1 && charAnim.CheckAnim(charMeta.kamgrabbed_anim) > -1)
			{
				return true;
			}
		}
		else
		{
			if (dummy)
			{
				return false;
			}
			if (charUpdate.state == CharUpdate.State.Grounded && charAnim.CheckAnim(charMeta.katgrabbed_anim) > -1 && charAnim.CheckAnim(charMeta.kamgrabbed_anim) > -1)
			{
				return true;
			}
			if (charUpdate.state == CharUpdate.State.Airborne && charAnim.CheckAnim(charMeta.jkatgrabbed_anim) > -1 && charAnim.CheckAnim(charMeta.jkamgrabbed_anim) > -1)
			{
				return true;
			}
		}
		return false;
	}

	public bool GetSawable()
	{
		if (GetMeta().autoGroundSplode)
		{
			return false;
		}
		if (GetMeta().isSawer)
		{
			if (charUpdate.hp > charUpdate.mhp / 2f)
			{
				return false;
			}
		}
		else if (charUpdate.hp > charUpdate.mhp / 4f)
		{
			return false;
		}
		if (charUpdate.ethereal)
		{
			return false;
		}
		if (charAnim.animName != "sawkill" && charAnim.animName != "sawkill2" && charAnim.CheckAnim("sawkill") > -1 && charAnim.CheckAnim("sawkill2") > -1)
		{
			return true;
		}
		return false;
	}

	public void Init(int cDef, Vector2 loc, int charMeta, int inputIdx, Team team, int ai)
	{
		Init(cDef, loc, charMeta, inputIdx, team, ai, null);
	}

	public void Init(int cDef, Vector2 loc, int charMeta, int inputIdx, Team team, int ai, string tag)
	{
		this.cDef = cDef;
		this.charMeta = charMeta;
		this.team = team;
		this.ai.type = ai;
		this.ai.mount = false;
		this.ai.frame = 0f;
		this.tag = tag;
		charUpdate.hp = Game1.charMeta[charMeta].mHP;
		charUpdate.mhp = Game1.charMeta[charMeta].mHP;
		if (GetMeta().ishypno)
		{
			switch (GameSettings.difficulty)
			{
			case 0:
				charUpdate.mhp *= 1.5f;
				break;
			case 1:
				charUpdate.mhp *= 1.3f;
				break;
			case 2:
				charUpdate.mhp *= 1.2f;
				break;
			case 3:
				charUpdate.mhp *= 1.1f;
				break;
			case 4:
				charUpdate.mhp *= 1f;
				break;
			case 5:
				charUpdate.mhp *= 1f;
				break;
			}
			charUpdate.hp = charUpdate.mhp;
			charRender.machine = 2;
		}
		else if (Game1.charMeta[charMeta].isBoss)
		{
			switch (GameSettings.difficulty)
			{
			case 3:
				charUpdate.mhp *= 1.2f;
				charUpdate.hp = charUpdate.mhp;
				break;
			case 4:
				charUpdate.mhp *= 1.5f;
				charUpdate.hp = charUpdate.mhp;
				break;
			}
			if (Game1.GetPlayers() >= 2)
			{
				charUpdate.mhp *= 1.5f;
				charUpdate.hp = charUpdate.mhp;
			}
		}
		else if (team == Team.BadGuys)
		{
			switch (GameSettings.difficulty)
			{
			case 0:
				charUpdate.mhp *= 0.5f;
				break;
			case 1:
				charUpdate.mhp *= 0.6f;
				break;
			case 2:
				charUpdate.mhp *= 0.7f;
				break;
			case 3:
				charUpdate.mhp *= 0.8f;
				break;
			case 4:
				charUpdate.mhp *= 0.9f;
				break;
			case 5:
				charUpdate.mhp *= 0.8f;
				break;
			}
			charUpdate.hp = charUpdate.mhp;
		}
		charUpdate.isSuicidal = false;
		if (GetMeta().suicide_anim != "" && Rand.CointToss(0.5f))
		{
			charUpdate.isSuicidal = true;
		}
		charRender.charShadows.vis = false;
		effectivelyDead = false;
		charUpdate.ammo = charUpdate.ammoMax;
		charUpdate.charGrab.grabbedByChar = -1;
		charUpdate.charGrab.grabbing = false;
		charUpdate.inactive = false;
		charUpdate.airJuggleFrame = -1f;
		charUpdate.isHalfed = false;
		charUpdate.cloudCharge = 0f;
		charUpdate.locked = false;
		reward = Reward.None;
		charUpdate.magic = 0f;
		charUpdate.magicOut = 0f;
		charUpdate.slammedFrame = 0f;
		charUpdate.zapCharged = 0f;
		charUpdate.spawnFrame = 1f;
		charUpdate.fire = 0f;
		charUpdate.mmp = (charUpdate.mp = 3);
		charUpdate.nomusic = false;
		charRect.baseSize = default;
		charUpdate.healthRegen = 0f;
		charUpdate.giantShrugDamage = 0f;
		charUpdate.giantVulnTimer = 0f;
		charUpdate.drippy = 0f;
		charUpdate.thermop = 0f;
		if (Game1.charMeta[charMeta].isThermop)
		{
			charUpdate.thermop = charUpdate.hp;
		}
		charUpdate.ResetKillstoHealth(this);
		charUpdate.ResetKillstoMagic(this);
		charUpdate.bodyStain = 0f;
		charUpdate.specialStain = 0f;
		charUpdate.weaponStain = 0f;
		charUpdate.chainsawStain = 0f;
		charUpdate.reviveFrame = 0f;
		if (GetMeta().isInvalid)
		{
			Game1.gameMap.invalidPhase = GameMap.InvalidPhase.Intro;
		}
		charAnim.Init(cDef, charMeta, ID);
		charPhysics.Init(this);
		charUpdate.loc = loc;
		charUpdate.traj = default;
		charUpdate.state = CharUpdate.State.Airborne;
		charUpdate.warpFrame = 0f;
		charUpdate.dyingFrame = 0f;
		charUpdate.dehealthified = false;
		charUpdate.lastSpecial = 0;
		charKeys.idx = inputIdx;
		charAnim.SetAnim(Game1.charMeta[charMeta].fly_anim, charUpdate, overRide: true);
		if (charAnim.CheckAnim(Game1.charMeta[charMeta].spawn_anim) > -1)
		{
			charAnim.SetAnim(Game1.charMeta[charMeta].spawn_anim, charUpdate, overRide: true);
		}
		exists = true;
		if (Game1.charMeta[charMeta].isZombie && !Game1.charMeta[charMeta].isJuggernaut && !Game1.charMeta[charMeta].nogroundzombie)
		{
			bool flag = false;
			while (!flag)
			{
				charUpdate.loc.Y += 16f;
				if (Game1.gameMap.CurMap().TestCol(charUpdate.loc))
				{
					charUpdate.loc.Y = Game1.gameMap.CurMap().GetMinY(charUpdate.loc);
					charUpdate.state = CharUpdate.State.Grounded;
					flag = true;
					break;
				}
				if (charUpdate.loc.Y > 50000f)
				{
					flag = true;
					exists = false;
				}
			}
		}
		if (!Game1.charMeta[charMeta].isBoss && !charUpdate.inactive && tag == null)
		{
			Vector2 screenLoc = ScrollManager.GetScreenLoc(loc, 1f);
			if ((screenLoc.X > ScrollManager.screenSize.X + 100f || screenLoc.X < -100f) && !Game1.netSession.IsHost() && !Game1.netSession.IsClient())
			{
				bool flag2 = false;
				while (!flag2)
				{
					charUpdate.loc.Y += 16f;
					if (Game1.gameMap.CurMap().GetCol(charUpdate.loc) != Map.Collision.Ceiling && Game1.gameMap.CurMap().GetCol(charUpdate.loc) != Map.Collision.CeilingFall && Game1.gameMap.CurMap().GetCol(charUpdate.loc) != Map.Collision.CeilingRise && Game1.gameMap.CurMap().TestCol(charUpdate.loc))
					{
						charUpdate.loc.Y = Game1.gameMap.CurMap().GetMinY(charUpdate.loc);
						charUpdate.state = CharUpdate.State.Grounded;
						charAnim.SetAnim(Game1.charMeta[charMeta].idle_anim, charUpdate);
						flag2 = true;
						break;
					}
					if (charUpdate.loc.Y > 50000f)
					{
						flag2 = true;
						exists = false;
					}
				}
			}
		}
		if (GetMeta().isViolin || GetMeta().isGuitar)
		{
			FloorMe(loc);
			if (Game1.levelMgr.guitarEmpty)
			{
				charAnim.SetAnim("ampempty", charUpdate);
			}
		}
		if (GetMeta().isPuppet && Game1.gameMap.isPuppeteer)
		{
			int num = ID % 4;
			charUpdate.loc = Game1.gameMap.fingerVec[num];
		}
		if (GetMeta().burnentry)
		{
			charUpdate.fire = 0.5f;
		}
		if (team == Team.BadGuys && Game1.GetPlayers() >= 2)
		{
			charUpdate.mhp *= 1.5f;
			charUpdate.hp = charUpdate.mhp;
		}
		if (charMeta == 91)
		{
			charUpdate.face = 1;
		}
	}

	public CharUpdate GetCharUpdate()
	{
		return charUpdate;
	}

	public CharAnim GetCharAnim()
	{
		return charAnim;
	}

	public void FloorMe(Vector2 loc)
	{
		Map map = Game1.gameMap.CurMap();
		while (!map.TestCol(loc, ceils: false, shadow: false, ledge: true))
		{
			loc.Y += 16f;
			if (loc.Y > (float)map.ySize * 64f)
			{
				return;
			}
		}
		loc.Y = map.GetMinY(loc);
		charUpdate.loc = loc;
		charAnim.SetAnim(Game1.charMeta[charMeta].idle_anim, charUpdate);
		charUpdate.state = CharUpdate.State.Grounded;
	}

	public void SetMeta()
	{
	}

	public void SetUpgradeHealth(bool fill)
	{
		charUpdate.mhp = 90f + (float)Game1.gamePlayerMgr.GamePlayer(ID).upgrades[0].lev * 10f;
		if (fill)
		{
			charUpdate.hp = charUpdate.mhp;
		}
	}

	public void SetUpgradeMagic(bool fill)
	{
		charUpdate.mmp = Game1.gamePlayerMgr.GamePlayer(ID).upgrades[1].lev;
		if (fill)
		{
			charUpdate.mp = charUpdate.mmp;
		}
	}

	public void Update(Map map, SpriteManager spriteMan, Character[] c)
	{
		if (DebugManager.hideChars || Game1.gameMap.theme.theme == Themes.ThemeType.EscapeOut || (Game1.gameMap.psychoTVAlpha > 0f && (GetMeta().isCrow || GetMeta().isNeko)))
		{
			return;
		}
		if (team == Team.BadGuys && GameState.flowerFrame <= 0f)
		{
			GameState.flowerFrame = 1f;
		}
		float frameTime = FMan.frameTime;
		if (Game1.gameMap.lichFreakoutMode)
		{
			if (GetMeta().isBoss)
			{
				return;
			}
			if (team == Team.GoodGuys || (team == Team.BadGuys && charUpdate.charGrab.grabbedByChar > -1))
			{
				FMan.frameTime = FMan.freakoutFreeTime;
			}
			else
			{
				FMan.frameTime /= 0.8f;
			}
		}
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && (team == Team.GoodGuys || charUpdate.charGrab.grabbedByChar > -1) && Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.Slow)
		{
			FMan.frameTime *= Game1.arcade.slowVal;
		}
		if (charUpdate.slow > 0f)
		{
			FMan.frameTime /= 10f;
			charUpdate.slow -= FMan.frameTime;
		}
		if (Game1.hud.IsEndLevel() || Game1.hud.IsArcadeIn())
		{
			charKeys.Update(ai, c, this);
			FMan.frameTime = frameTime;
			return;
		}
		charUpdate.charGrab.CheckGrabbing(c, ID);
		comboProfile.Update();
		bool flag = false;
		if (Game1.IsPlayerChar(ID))
		{
			try
			{
				if (Game1.hud.shopMgr.shop[ID].alpha > 0f)
				{
					flag = true;
				}
				if (Game1.hud.invMgr.inv[ID].alpha > 0f)
				{
					flag = true;
				}
			}
			catch
			{
			}
		}
		if (!flag)
		{
			charKeys.Update(ai, c, this);
		}
		if (charUpdate.charGrab.grabbing || charUpdate.charGrab.grabbedByChar > -1)
		{
			if (charUpdate.warpFrame > 0f)
			{
				charUpdate.warpFrame = 0f;
			}
			if (charUpdate.warpRecover < 0.5f)
			{
				charUpdate.warpRecover = 0.5f;
			}
		}
		CharMeta charMeta = Game1.charMeta[this.charMeta];
		if (charMeta.isYuki)
		{
			if (Game1.player.yukiPhase < 6)
			{
				charRender.machine = 0;
				charUpdate.lastSpecial = 0;
			}
			else
			{
				if (charMeta.isYuki && charRender.machine == 0)
				{
					charRender.machine = 1;
				}
				if (charAnim.smokeMachineLife > 0f)
				{
					if (charAnim.smokeMachineFrame > 0f)
					{
						charAnim.smokeMachineFrame -= FMan.frameTime;
					}
					charAnim.smokeMachineLife -= FMan.frameTime;
				}
			}
		}
		if (charUpdate.charGrab.grabbing)
		{
			charUpdate.GrabbingUpdate(map, this, c);
			FMan.frameTime = frameTime;
			return;
		}
		Animation animation = Game1.charDef[charAnim.charDef].GetAnimation(charAnim.anim);
		if (animation != null)
		{
			charAnim.SetKey(Game1.charDef[cDef].GetAnimation(charAnim.anim).FixKeyFrame(charAnim.GetKey()));
			KeyFrame keyFrame = animation.GetKeyFrame(charAnim.GetKey());
			if (keyFrame != null)
			{
				charUpdate.Update(map, this, c, spriteMan);
				charAnim.charMeta = this.charMeta;
				charAnim.Update(this, spriteMan, map);
			}
		}
		else if (charUpdate.state == CharUpdate.State.Airborne)
		{
			charAnim.SetAnim(GetMeta().fly_anim, charUpdate, overRide: true);
		}
		else
		{
			charAnim.SetAnim(GetMeta().idle_anim, charUpdate, overRide: true);
		}
		if (!charUpdate.charGrab.grabbing)
		{
			if (!Game1.netSession.IsHost() && !Game1.netSession.IsClient())
			{
				charUpdate.FixNetLoc();
			}
			charAnim.SetKey(Game1.charDef[cDef].GetAnimation(charAnim.anim).FixKeyFrame(charAnim.GetKey()));
			Animation animation2 = Game1.charDef[charAnim.charDef].GetAnimation(charAnim.anim);
			if (animation2 != null)
			{
				KeyFrame keyFrame2 = animation2.GetKeyFrame(charAnim.GetKey());
				if (keyFrame2 != null)
				{
					if (keyFrame2.lerp)
					{
						int num = charAnim.GetKey() + 1;
						if (num >= Game1.charDef[cDef].GetAnimation(charAnim.anim).getKeyFrameArray().Length)
						{
							num = 0;
						}
						else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num) == null)
						{
							num = 0;
						}
						else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num).duration <= 0)
						{
							num = 0;
						}
						charPhysics.Update(this, charUpdate.netLoc, charUpdate.face, charAnim.GetCurFrame(), Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num).frameRef);
					}
					else
					{
						charPhysics.Update(this, charUpdate.netLoc, charUpdate.face, charAnim.GetCurFrame(), -1);
					}
				}
			}
			else if (charUpdate.state == CharUpdate.State.Airborne)
			{
				charAnim.SetAnim(GetMeta().fly_anim, charUpdate, overRide: true);
			}
			else
			{
				charAnim.SetAnim(GetMeta().idle_anim, charUpdate, overRide: true);
			}
		}
		if (charUpdate.charGrab.grabbedByChar > -1)
		{
			charPhysics.UpdateGrabberPhysics(this);
		}
		if (charUpdate.loc.X > 200000f || charUpdate.loc.X < -200000f)
		{
			charUpdate.loc.X = 160f;
			charUpdate.traj.X = 0f;
		}
		if (charUpdate.dyingFrame >= 1f)
		{
			if (team != Team.GoodGuys)
			{
				spriteMan.AddGib(charUpdate.loc, 1 - charUpdate.face, charMeta.headTex, charMeta.torsoTex, charMeta.legsTex, charMeta.weapTex, cDef, charAnim.animName, charAnim.GetKey(), 0.35f, map, ID);
				KillMe();
			}
			charUpdate.dyingFrame = 3f;
		}
		else
		{
			UpdateRects();
		}
		FMan.frameTime = frameTime;
	}

	public void KillMe()
	{
		if (!(MainPlayer.uberDyingFrame >= 1f) && tag != null)
		{
			Game1.gameMap.CurMap().scriptMgr.SetFlag(tag);
		}
		if (charUpdate.zapCharged > 0f)
		{
			charUpdate.DischargeZap(this, continuation: true);
		}
		CharMeta meta = GetMeta();
		SpriteManager spriteMan = Game1.spriteMan;
		if (charMeta == 65 && charUpdate.lastHitBy < 2 && Game1.beadMgr.beads[charUpdate.lastHitBy].HasBead(InvCatalog.InvItemName.AchievablesBead))
		{
			GetAllAchievables getAllAchievables = (GetAllAchievables)Game1.achievementMgr.playerAchievements[charUpdate.lastHitBy].achievementList[5];
			if (!getAllAchievables.killSquid)
			{
				getAllAchievables.killSquid = true;
				getAllAchievables.Unlock(overRide: false);
			}
		}
		if (charMeta == 48 && charUpdate.lastHitBy < 2 && Game1.beadMgr.beads[charUpdate.lastHitBy].HasBead(InvCatalog.InvItemName.AchievablesBead))
		{
			GetAllAchievables getAllAchievables2 = (GetAllAchievables)Game1.achievementMgr.playerAchievements[charUpdate.lastHitBy].achievementList[5];
			if (!getAllAchievables2.openPresents)
			{
				getAllAchievables2.openPresents = true;
				getAllAchievables2.Unlock(overRide: false);
			}
		}
		if (!Game1.gameMap.lichFreakoutMode && Game1.levelMgr.currentTrack != 5 && Game1.levelMgr.currentTrack != 6 && !GetMeta().isNoGold && charUpdate.lastHitBy > -1 && charUpdate.lastHitBy < 2 && !Game1.gameMap.noprize && Game1.gameMap.theme.theme != Themes.ThemeType.Asylum)
		{
			if (Game1.character[charUpdate.lastHitBy].charUpdate.killsToHealth > 0)
			{
				Game1.character[charUpdate.lastHitBy].charUpdate.killsToHealth--;
			}
			if (Game1.character[charUpdate.lastHitBy].charUpdate.killsToMagic > 0)
			{
				Game1.character[charUpdate.lastHitBy].charUpdate.killsToMagic--;
			}
			if ((meta.isCyborg || meta.isZombie || meta.isJuicyRobot) && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off && Game1.gameMap.theme.theme != Themes.ThemeType.Dish)
			{
				spriteMan.AddSprite(68, charUpdate.loc + new Vector2(0f, -40f), default, charUpdate.mhp * 0.1f, 0, charUpdate.lastHitBy);
			}
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
			{
				if (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.Blitz)
				{
					Game1.arcade.blitzFrame += 2f;
					if (Game1.arcade.blitzFrame > 120f)
					{
						Game1.arcade.blitzFrame = 120f;
					}
				}
				else if (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.TurboBlitz)
				{
					Game1.arcade.blitzFrame++;
					if (Game1.arcade.blitzFrame > 60f)
					{
						Game1.arcade.blitzFrame = 60f;
					}
				}
			}
			if (Game1.character[charUpdate.lastHitBy].charUpdate.killsToHealth <= 0 && !meta.isBoss)
			{
				spriteMan.AddSprite(73, charUpdate.loc + new Vector2(0f, -40f), default, 5f, 0, charUpdate.lastHitBy);
				Game1.character[charUpdate.lastHitBy].charUpdate.ResetKillstoHealth(Game1.character[charUpdate.lastHitBy]);
			}
			if (Game1.character[charUpdate.lastHitBy].charUpdate.killsToMagic <= 0 || (Game1.character[charUpdate.lastHitBy].charUpdate.killsToMagic < 10 && Game1.gameMap.skullFarm))
			{
				bool flag = true;
				if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
				{
					if (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].magic == Level.ArcadeMagic.None)
					{
						flag = false;
					}
				}
				else if (Game1.character[0].GetMeta().isDish)
				{
					if (Game1.player.dishPhase < 4)
					{
						flag = false;
					}
				}
				else if (Game1.player.yukiPhase < 9)
				{
					flag = false;
				}
				if (flag && !meta.isBoss)
				{
					spriteMan.AddSprite(75, charUpdate.loc + new Vector2(0f, -40f), Rand.GetRandomVec2(-100f, 100f, -100f, 100f), 1f, 0, charUpdate.lastHitBy);
					Game1.character[charUpdate.lastHitBy].charUpdate.ResetKillstoMagic(Game1.character[charUpdate.lastHitBy]);
				}
			}
		}
		if (this.reward == Reward.None)
		{
			return;
		}
		Reward reward = this.reward;
		if (reward == Reward.Pickup && !Game1.netSession.IsClient())
		{
			if (tag.Contains("-"))
			{
				int num = tag.IndexOf('-');
				spriteMan.AddSprite(47, charUpdate.loc, default, 0f, (int)Game1.invCatalog.GetNameFromName(tag.Substring(0, num)), (int)Game1.invCatalog.GetNameFromName(tag.Substring(num + 1, tag.Length - num - 1)));
			}
			else
			{
				spriteMan.AddSprite(47, charUpdate.loc, default, 0f, (int)Game1.invCatalog.GetNameFromName(tag), -1);
			}
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.SendPickupSprite(Game1.netSession.session, charUpdate.loc);
			}
		}
	}

	public void UpdateRects()
	{
		CharMeta meta = GetMeta();
		if (meta.isGiant)
		{
			if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(charAnim.GetKey()).lerp)
			{
				int num = charAnim.GetKey() + 1;
				if (num >= Game1.charDef[cDef].GetAnimation(charAnim.anim).getKeyFrameArray().Length)
				{
					num = 0;
				}
				else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num) == null)
				{
					num = 0;
				}
				else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num).duration <= 0)
				{
					num = 0;
				}
				charRect.UpdateRects(charUpdate.loc, 0.35f, charUpdate.face, charAnim.GetCurFrame(), this, ID, Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num).frameRef);
			}
			else
			{
				charRect.UpdateRects(charUpdate.loc, 0.35f, charUpdate.face, charAnim.GetCurFrame(), this, ID);
			}
		}
		else
		{
			charRect.UpdateRects(charUpdate.loc, 0.35f, charUpdate.face, charAnim.GetCurFrame(), this, ID);
		}
	}

	public CharRect.RectHitType CheckHit(Vector2 hit, bool wide)
	{
		if (Game1.charMeta[charMeta].isGiant)
		{
			int num = charRect.CheckHit(hit, wide);
			if (num > -1)
			{
				if (num == 2 && GetMeta().isMetalLegs)
				{
					return CharRect.RectHitType.MetalLegs;
				}
				return CharRect.RectHitType.Normal;
			}
			if (GetMeta().isInnerRect)
			{
				float num2 = (wide ? 50f : 50f);
				Vector2 loc = charUpdate.loc;
				if (hit.X > loc.X - num2 && hit.X < loc.X + num2 && hit.Y < loc.Y + 10f && hit.Y > loc.Y - 120f)
				{
					return CharRect.RectHitType.Normal;
				}
			}
		}
		else
		{
			float num3 = (wide ? 50f : 30f);
			float num4;
			if (team != Team.GoodGuys)
			{
				num4 = (wide ? 120f : 90f);
			}
			else
			{
				num4 = 100f;
			}
			Vector2 loc2 = charUpdate.loc;
			if (hit.X > loc2.X - num3 && hit.X < loc2.X + num3 && hit.Y < loc2.Y + 10f && hit.Y > loc2.Y - num4)
			{
				return CharRect.RectHitType.Normal;
			}
		}
		return CharRect.RectHitType.None;
	}

	public void CalculateShadows()
	{
		if (DebugManager.hideChars || charUpdate.charGrab.grabbing)
		{
			return;
		}
		if (charUpdate.charGrab.grabbedByChar > -1)
		{
			charRender.charShadows.CalculateShadows(charUpdate.netLoc, charUpdate.face, charAnim.GetCurFrame(), Game1.charDef[cDef], Game1.charMeta[charMeta], Game1.charDef[Game1.character[charUpdate.charGrab.grabbedByChar].cDef], Game1.charMeta[Game1.character[charUpdate.charGrab.grabbedByChar].charMeta], charUpdate, this, -1);
		}
		else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(charAnim.GetKey()).lerp)
		{
			int num = charAnim.GetKey() + 1;
			if (num >= Game1.charDef[cDef].GetAnimation(charAnim.anim).getKeyFrameArray().Length)
			{
				num = 0;
			}
			else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num) == null)
			{
				num = 0;
			}
			else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num).duration <= 0)
			{
				num = 0;
			}
			charRender.charShadows.CalculateShadows(charUpdate.netLoc, charUpdate.face, charAnim.GetCurFrame(), Game1.charDef[cDef], Game1.charMeta[charMeta], null, null, charUpdate, this, Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num).frameRef);
		}
		else
		{
			charRender.charShadows.CalculateShadows(charUpdate.netLoc, charUpdate.face, charAnim.GetCurFrame(), Game1.charDef[cDef], Game1.charMeta[charMeta], null, null, charUpdate, this, -1);
		}
	}

	public void Draw(SpriteBatch sprite, bool grabberOnly)
	{
		if (DebugManager.hideChars || charUpdate.charGrab.grabbing || ((GetMeta().isViolin || GetMeta().isGuitar) && Game1.soloMgr.active))
		{
			return;
		}
		if (charUpdate.lastSpecial != 0)
		{
			charRender.machine = charUpdate.lastSpecial;
		}
		if (charUpdate.charGrab.grabbedByChar > -1)
		{
			charRender.melee = Game1.character[charUpdate.charGrab.grabbedByChar].charRender.melee;
		}
		else
		{
			charRender.melee = Game1.charMeta[charMeta].special;
		}
		charAnim.SetKey(Game1.charDef[cDef].GetAnimation(charAnim.anim).FixKeyFrame(charAnim.GetKey()));
		if (!Game1.netSession.IsHost() && !Game1.netSession.IsClient())
		{
			charUpdate.netLoc = charUpdate.loc;
		}
		Vector2 screenLoc = ScrollManager.GetScreenLoc(charUpdate.netLoc, 1f);
		float scale = ScrollManager.cannedDepth[0] * 0.35f;
		if (charUpdate.charGrab.grabbedByChar > -1)
		{
			if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(charAnim.GetKey()).lerp)
			{
				int num = charAnim.GetKey() + 1;
				if (num >= Game1.charDef[cDef].GetAnimation(charAnim.anim).getKeyFrameArray().Length)
				{
					num = 0;
				}
				else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num) == null)
				{
					num = 0;
				}
				else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num).duration <= 0)
				{
					num = 0;
				}
				charRender.DrawCharacter(sprite, screenLoc, scale, charUpdate.face, charAnim.GetCurFrame(), Game1.charDef[cDef], Game1.charMeta[charMeta], Game1.charDef[Game1.character[charUpdate.charGrab.grabbedByChar].cDef], Game1.charMeta[Game1.character[charUpdate.charGrab.grabbedByChar].charMeta], charUpdate, this, Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num).frameRef, grabberOnly);
			}
			else
			{
				charRender.DrawCharacter(sprite, screenLoc, scale, charUpdate.face, charAnim.GetCurFrame(), Game1.charDef[cDef], Game1.charMeta[charMeta], Game1.charDef[Game1.character[charUpdate.charGrab.grabbedByChar].cDef], Game1.charMeta[Game1.character[charUpdate.charGrab.grabbedByChar].charMeta], charUpdate, this, -1, grabberOnly);
			}
		}
		else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(charAnim.GetKey()).lerp)
		{
			int num2 = charAnim.GetKey() + 1;
			if (num2 >= Game1.charDef[cDef].GetAnimation(charAnim.anim).getKeyFrameArray().Length)
			{
				num2 = 0;
			}
			else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num2) == null)
			{
				num2 = 0;
			}
			else if (Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num2).duration <= 0)
			{
				num2 = 0;
			}
			charRender.DrawCharacter(sprite, screenLoc, scale, charUpdate.face, charAnim.GetCurFrame(), Game1.charDef[cDef], Game1.charMeta[charMeta], null, null, charUpdate, this, Game1.charDef[cDef].GetAnimation(charAnim.anim).GetKeyFrame(num2).frameRef, grabberOnly);
		}
		else
		{
			charRender.DrawCharacter(sprite, screenLoc, scale, charUpdate.face, charAnim.GetCurFrame(), Game1.charDef[cDef], Game1.charMeta[charMeta], charUpdate, this);
		}
		if (charAnim.charTrigs.hasGibSpray)
		{
			if (charAnim.charTrigs.sprayType == CharTrigs.SprayType.Flame || charAnim.charTrigs.sprayType == CharTrigs.SprayType.NullFlame || charAnim.charTrigs.sprayType == CharTrigs.SprayType.DragonFlame || charAnim.charTrigs.sprayType == CharTrigs.SprayType.NullDragonFlame)
			{
				charAnim.charTrigs.DrawFlameSpray(sprite);
			}
			else if (charAnim.charTrigs.sprayType == CharTrigs.SprayType.SquirtGun)
			{
				charAnim.charTrigs.DrawSquirtGun(sprite, refract: false);
			}
		}
	}

	internal bool GetExeable()
	{
		if (GetMeta().isZombie)
		{
			return false;
		}
		if (charUpdate.ethereal)
		{
			return false;
		}
		if (charAnim.animName != GetMeta().exe_anim && charAnim.animName != "exe2" && charAnim.animName != "exe3")
		{
			if (charAnim.CheckAnim(GetMeta().exe_anim) > -1)
			{
				return true;
			}
			if (GetMeta().turnexetograb)
			{
				return true;
			}
		}
		return false;
	}

	internal void DrawShadows(SpriteBatch sprite)
	{
		charRender.charShadows.DrawShadows(sprite);
	}
}
