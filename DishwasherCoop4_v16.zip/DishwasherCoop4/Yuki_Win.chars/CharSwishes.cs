using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.chars;

public class CharSwishes
{
	public struct Swish
	{
		public Vector2 loc;

		public bool flip;

		public Vector2 scale;

		public float rotation;

		public Rectangle sRect;

		public int tex;
	}

	public static Swish[] swish;

	private static int swishCount = 0;

	public static void Init()
	{
		swish = new Swish[8];
	}

	public static void Add(Vector2 loc, int idx, Rectangle sRect, bool flip, Vector2 scale, float rotation, int tex)
	{
		int num = swishCount;
		if (num < swish.Length && TryAdd(idx, tex))
		{
			swish[num].loc = loc;
			swish[num].flip = flip;
			swish[num].scale = scale;
			swish[num].tex = tex;
			swish[num].rotation = rotation;
			swish[num].sRect = sRect;
			swishCount++;
		}
	}

	private static bool TryAdd(int idx, int tex)
	{
		idx %= 64;
		switch (tex)
		{
		case 0:
			switch (idx)
			{
			case 24:
			case 25:
			case 26:
			case 27:
			case 48:
			case 49:
			case 50:
			case 51:
			case 52:
			case 53:
			case 54:
			case 55:
				return true;
			}
			break;
		case 1:
			switch (idx)
			{
			case 10:
			case 14:
			case 15:
				return true;
			}
			break;
		case 2:
		case 9:
		case 13:
		case 15:
		case 17:
		{
			int num = idx;
			if (num == 2)
			{
				return true;
			}
			break;
		}
		case 4:
		case 16:
			switch (idx)
			{
			case 20:
			case 21:
				return true;
			}
			break;
		case 5:
			switch (idx)
			{
			case 20:
			case 21:
			case 22:
			case 23:
			case 33:
			case 34:
			case 35:
			case 52:
			case 53:
			case 54:
			case 55:
				return true;
			}
			break;
		case 8:
			switch (idx)
			{
			case 8:
			case 9:
			case 10:
			case 11:
				return true;
			}
			break;
		case 19:
			switch (idx)
			{
			case 12:
			case 13:
			case 14:
			case 15:
				return true;
			}
			break;
		}
		return false;
	}

	public static void Draw(SpriteBatch sprite)
	{
		for (int i = 0; i < swishCount; i++)
		{
			sprite.Draw(Game1.weaponTex[swish[i].tex], swish[i].loc, swish[i].sRect, new Color(0f, 0f, 0.15f, 1f), swish[i].rotation, new Vector2((float)swish[i].sRect.Width / 2f, (float)swish[i].sRect.Height / 2f), swish[i].scale * 1.1f, (!swish[i].flip) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
		}
		swishCount = 0;
	}
}
