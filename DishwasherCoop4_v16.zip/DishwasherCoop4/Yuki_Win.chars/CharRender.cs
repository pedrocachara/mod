using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;
using Yuki_Win.debug;
using Yuki_Win.gameRender;
using Yuki_Win.hud;
using Yuki_Win.maps;
using Yuki_Win.player;

namespace Yuki_Win.chars;

public class CharRender
{
	public const int FACE_LEFT = 0;

	public const int FACE_RIGHT = 1;

	public const int NET_UPGRADE_MAIN = 0;

	public const int NET_UPGRADE_GUN = 1;

	public const int NET_UPGRADE_SAW = 2;

	public int melee;

	public int machine;

	public int[] netLev;

	public CharShadows charShadows;

	public CharRender()
	{
		netLev = new int[3];
		charShadows = new CharShadows();
	}

	public void DrawCharacter(SpriteBatch spriteBatch, Vector2 loc, float scale, int face, int frameIdx, CharDef cDef, CharMeta cMeta, CharUpdate charUpdate, Character c)
	{
		DrawCharacter(spriteBatch, loc, scale, face, frameIdx, cDef, cMeta, null, null, charUpdate, c, -1, grabberOnly: false);
	}

	public void DrawCharacter(SpriteBatch spriteBatch, Vector2 loc, float scale, int face, int frameIdx, CharDef cDef, CharMeta cMeta, CharDef actorDef, CharMeta actorMeta, CharUpdate charUpdate, Character c)
	{
		DrawCharacter(spriteBatch, loc, scale, face, frameIdx, cDef, cMeta, actorDef, actorMeta, charUpdate, c, -1, grabberOnly: false);
	}

	private void DrawCharacterEyes(SpriteBatch sprite, Character c, CharMeta cMeta, Vector2 loc, int face, float angle)
	{
		if ((cMeta.redEyes || cMeta.blueEyes || cMeta.greenEyes) && !(Game1.gameMap.goryoAlpha > 0f))
		{
			Vector2 vector = new Vector2(-19f, 19f) * ScrollManager.cannedDepth[0] * 0.35f;
			if (face == 0)
			{
				vector.X = 0f - vector.X;
			}
			Vector2 loc2 = loc + new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * vector.X + new Vector2((float)Math.Cos(angle + 1.57f), (float)Math.Sin(angle + 1.57f)) * vector.Y;
			float num = 1f;
			float num2 = 1f;
			float num3 = 1f;
			if (cMeta.redEyes)
			{
				num2 = 0.1f;
				num3 = 0.1f;
			}
			else if (cMeta.greenEyes)
			{
				num = 0.1f;
				num3 = 0.1f;
			}
			else if (cMeta.blueEyes)
			{
				num = 0.1f;
				num2 = 0.1f;
			}
			num *= 0.125f;
			num2 *= 0.125f;
			num3 *= 0.125f;
			PostGlowMgr.AddCharGlow(loc2, num, num2, num3, 0.05f);
		}
	}

	public void DrawCharacter(SpriteBatch spriteBatch, Vector2 loc, float scale, int face, int frameIdx, CharDef cDef, CharMeta cMeta, CharDef actorDef, CharMeta actorMeta, CharUpdate charUpdate, Character c, int next, bool grabberOnly)
	{
		if (c.ID < 2 && ((Game1.netSession.IsHost() && c.ID == 0) || (Game1.netSession.IsClient() && c.ID == 1)))
		{
			for (int i = 0; i < netLev.Length; i++)
			{
				netLev[i] = -1;
			}
		}
		if (c.charMeta == 94 && Game1.gameMap.yukiDeathFocus && Game1.gameMap.yukiDeathFrame > 0f)
		{
			spriteBatch.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Rectangle(0, 0, 1, 1), new Color(1f, 1f, 1f, Game1.gameMap.yukiDeathFrame));
		}
		if (Game1.gameMap.theme.theme == Themes.ThemeType.EscapeOut || (cMeta.isBoss && Game1.gameMap.lichFreakoutMode) || ((Game1.gameMap.psychoTVAlpha > 0f || Game1.gameMap.theme.theme == Themes.ThemeType.Asylum) && (cMeta.isCrow || cMeta.isNeko)))
		{
			return;
		}
		if (DebugManager.showHitRects)
		{
			c.charRect.Draw(spriteBatch);
		}
		face = 1 - face;
		Rectangle rectangle = default;
		if (cDef == null)
		{
			return;
		}
		Frame frame = cDef.GetFrame(frameIdx);
		bool flag = false;
		bool flag2 = false;
		bool flag3 = false;
		for (int j = 0; j < frame.GetPartArray().Length; j++)
		{
			Frame.Part part = frame.GetPart(j);
			if (part.idx > -1)
			{
				int num = (part.idx - 192) / 4;
				if (num == 0 || num == 1)
				{
					flag3 = true;
				}
				if (num == 8 || num == 9 || num == 10 || num == 11)
				{
					flag2 = true;
				}
			}
		}
		if (flag2 && flag3)
		{
			flag = true;
		}
		if (cMeta.isGlowyBlue)
		{
			PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(c.charUpdate.loc + new Vector2(0f, -40f), 1f), 0.2f, 0.2f, 1f, 2f, 0.4f, 0f);
		}
		if (cMeta.warpcleavers && charUpdate != null && charUpdate.warpFrame > 0f)
		{
			for (int k = 0; k < 2; k++)
			{
				float num2 = ((charUpdate.warpFrame > 0.2f) ? (0.4f - charUpdate.warpFrame) : charUpdate.warpFrame) * 5f;
				if (k == 2)
				{
					num2 /= 2f;
				}
				spriteBatch.Draw(Game1.weaponTex[5], ScrollManager.GetScreenLoc(c.charUpdate.loc + new Vector2(0f, -40f), 1f), new Rectangle(400, 768, 200, 96), new Color(1f, 1f, 1f, num2), Trig.GetAngle(default, charUpdate.warpVec), new Vector2(100f, 48f), new Vector2(2f + num2 + ((k == 2) ? (num2 * 2f) : 0f), (k == 0) ? 1.5f : 0.75f) * ScrollManager.cannedDepth[0] * 0.8f, SpriteEffects.None, 1f);
			}
		}
		for (int l = 0; l < frame.GetPartArray().Length; l++)
		{
			Frame.Part part2 = frame.GetPart(l);
			if (part2.idx <= -1)
			{
				continue;
			}
			bool flag4 = false;
			float num3 = part2.rotation;
			Vector2 vector = part2.location * scale + loc;
			Vector2 vector2 = part2.scaling * scale;
			if (face == 0)
			{
				num3 = 0f - num3;
				vector.X -= part2.location.X * scale * 2f;
			}
			if (next > -1)
			{
				Frame frame2 = cDef.GetFrame(next);
				if (Frame.CanLerp(frame, frame2, l))
				{
					Frame.Part part3 = frame2.GetPart(l);
					Animation animation = cDef.GetAnimation(c.charAnim.anim);
					KeyFrame keyFrame = animation.GetKeyFrame(c.charAnim.GetKey());
					float num4 = c.charAnim.frame / (float)keyFrame.duration;
					if (MainPlayer.uberDyingFrame >= 1f || Game1.gameMap.lichFreakoutMode)
					{
						num4 = (float)(int)(num4 * (float)keyFrame.duration) / (float)keyFrame.duration;
					}
					else
					{
						num4 = (float)(int)(num4 * (float)keyFrame.duration) / (float)keyFrame.duration;
						if (keyFrame.duration > 8)
						{
							num4 = (float)(int)(num4 * ((float)keyFrame.duration / 2f)) / ((float)keyFrame.duration / 2f);
						}
					}
					if (num4 > 1f)
					{
						num4 = 1f;
					}
					Vector2 location = part2.location;
					Vector2 location2 = part3.location;
					float num5 = part2.rotation;
					float num6 = part3.rotation;
					if (face == 0)
					{
						num5 = 0f - num5;
						num6 = 0f - num6;
						location.X -= part2.location.X * 2f;
						location2.X -= part3.location.X * 2f;
					}
					vector = Frame.LerpLoc(location, location2, num4) * scale + loc;
					num3 = Frame.LerpRotation(num5, num6, num4);
					vector2 = Frame.LerpScale(part2.scaling, part3.scaling, num4) * scale;
				}
			}
			if (part2.idx >= 2000)
			{
				if (actorDef == null || (c.charUpdate.thermop > 0f && !grabberOnly))
				{
					continue;
				}
				int num7 = 1 - face;
				if (num7 == 1)
				{
					if (part2.flip == 1)
					{
						num7 = 1 - num7;
					}
				}
				else if (part2.flip == 1)
				{
					num7 = 1 - num7;
				}
				machine = charUpdate.lastSpecial;
				DrawCharacter(spriteBatch, vector, scale, num7, part2.idx - 2000, actorDef, actorMeta, null, Game1.character[c.charUpdate.charGrab.grabbedByChar].GetMeta(), Game1.character[c.charUpdate.charGrab.grabbedByChar].charUpdate, Game1.character[c.charUpdate.charGrab.grabbedByChar]);
			}
			else if (part2.idx - 1000 == 30)
			{
				spriteBatch.Draw(Game1.nullTex, new Rectangle((int)vector.X - 1, 0, 2, (int)vector.Y), new Color(0f, 0f, 0f, Rand.GetRandomFloat(0.7f, 1f)));
			}
			else
			{
				if (part2.idx >= 1000)
				{
					continue;
				}
				int num8 = -1;
				int num9 = part2.idx / 64;
				int num10 = -1;
				if (Game1.gameMap.goryoAlpha > 0.5f && c != null && c.ID >= 4 && !c.GetMeta().isBoss && cMeta.headTex != 18 && Game1.gameMap.goryoAlpha > 0.5f)
				{
					num10 = (int)(Game1.gameMap.tvFrame * 800f + (float)c.ID) % 3;
				}
				Texture2D texture2D;
				switch (num9)
				{
				case 0:
					texture2D = Game1.headTex[cMeta.headTex];
					rectangle = Game1.headTexMeta[cMeta.headTex].GetRect(part2.idx);
					if (cMeta.headTex == 50 && part2.idx >= 4)
					{
						int num14 = (int)(c.charUpdate.delta * 60f) % 3;
						rectangle.Y += num14 * 160;
					}
					DrawCharacterEyes(spriteBatch, c, cMeta, vector, ((face == 1 && part2.flip == 0) || (face == 0 && part2.flip == 1)) ? 1 : 0, num3);
					if (num10 > -1)
					{
						texture2D = Game1.headTex[55 + num10];
						rectangle = Game1.headTexMeta[55 + num10].GetRect(part2.idx);
						rectangle.Y = 0;
					}
					if (!cMeta.isGiant && !cMeta.isBoss)
					{
						vector2 *= 1.1f;
					}
					if (Game1.IsPlayerChar(c.ID) && Game1.beadMgr.beads[c.ID].HasBead(InvCatalog.InvItemName.BrainBead))
					{
						vector2 *= 1.1f;
					}
					break;
				case 1:
				{
					int torsoTex = cMeta.torsoTex;
					texture2D = Game1.torsoTex[torsoTex];
					rectangle = Game1.torsoTexMeta[torsoTex].GetRect(part2.idx - 64);
					if (num10 > -1)
					{
						texture2D = Game1.torsoTex[44 + num10];
						rectangle = Game1.torsoTexMeta[44 + num10].GetRect(part2.idx - 64);
					}
					break;
				}
				case 2:
				{
					int num15 = cMeta.legsTex;
					if (num15 == 6 && Game1.player.yukiPhase < 6)
					{
						num15 = 0;
					}
					texture2D = Game1.legsTex[num15];
					rectangle = Game1.legsTexMeta[num15].GetRect(part2.idx - 128);
					if (num10 > -1)
					{
						texture2D = Game1.legsTex[34 + num10];
						rectangle = Game1.legsTexMeta[34 + num10].GetRect(part2.idx - 128);
					}
					break;
				}
				case 3:
				{
					texture2D = Game1.weaponTex[cMeta.weapTex];
					rectangle = Game1.weaponTexMeta[cMeta.weapTex].GetRect(part2.idx - 192);
					if (cMeta.isPumpkin)
					{
						int num11 = 0;
						switch (part2.idx)
						{
						case 192:
							num11 = (int)(c.charUpdate.delta * 60f) % 3;
							if (num11 > 0)
							{
								rectangle.Y += 160 + num11 * 80;
							}
							break;
						case 193:
							num11 = (int)(c.charUpdate.delta * 60f) % 3;
							if (num11 > 0)
							{
								rectangle.Y += 240 + num11 * 80;
							}
							break;
						}
					}
					if (cMeta.isYuki)
					{
						int num12 = 0;
						switch ((part2.idx - 192) / 4)
						{
						case 0:
						case 1:
							num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Murderblade);
							break;
						case 2:
						case 3:
							num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Gunarm);
							num12 = 1;
							break;
						case 4:
						case 5:
						case 7:
							num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Chainsaw);
							num12 = 2;
							break;
						case 8:
						case 9:
						case 10:
						case 11:
							num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Kamakazi);
							break;
						case 14:
							num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Cloud);
							break;
						case 15:
							num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Painkiller);
							break;
						}
						if (num8 > -1)
						{
							texture2D = Game1.upgradeTex[num8];
							if ((Game1.netSession.IsHost() && c.ID == 0) || (Game1.netSession.IsClient() && c.ID == 1))
							{
								netLev[num12] = num8;
							}
						}
						if ((Game1.netSession.IsHost() && c.ID == 1) || (Game1.netSession.IsClient() && c.ID == 0))
						{
							num8 = netLev[num12];
							if (num8 > -1)
							{
								texture2D = Game1.upgradeTex[num8];
							}
						}
					}
					if (!cMeta.isDish)
					{
						break;
					}
					int num13 = 0;
					switch ((part2.idx - 192) / 4)
					{
					case 0:
					case 1:
						num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Shiftblade);
						break;
					case 2:
					case 3:
					case 4:
						num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Hammer);
						break;
					case 6:
					case 7:
					case 8:
						num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Cleavers);
						break;
					case 9:
						num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Uzi);
						num13 = 1;
						break;
					case 10:
					case 11:
					case 12:
						num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Guillotine);
						break;
					case 14:
						num8 = Game1.gamePlayerMgr.GetUpgrade(c.ID, GamePlayer.UpName.Dekkentozter);
						break;
					}
					if (num8 > -1)
					{
						texture2D = Game1.upgradeTex[num8 + 2];
						if ((Game1.netSession.IsHost() && c.ID == 0) || (Game1.netSession.IsClient() && c.ID == 1))
						{
							netLev[num13] = num8;
						}
					}
					if ((Game1.netSession.IsHost() && c.ID == 1) || (Game1.netSession.IsClient() && c.ID == 0))
					{
						num8 = netLev[num13];
						if (num8 > -1)
						{
							texture2D = Game1.upgradeTex[num8 + 2];
						}
					}
					break;
				}
				default:
					texture2D = null;
					break;
				}
				float charBrite = GameRender.filterRender.charBrite;
				float charBrite2 = GameRender.filterRender.charBrite;
				float charBrite3 = GameRender.filterRender.charBrite;
				Color color = new Color(charBrite, charBrite2, charBrite3, 1f);
				if (c.charUpdate.thermop > 0f)
				{
					color = new Color(0f, 0f, Rand.GetRandomFloat(0.1f, 0.125f), 1f);
				}
				if (grabberOnly && c.charUpdate.thermop > 0f)
				{
					flag4 = true;
				}
				if (cMeta.isGhost)
				{
					color = new Color(charBrite, charBrite2, charBrite3, Rand.GetRandomFloat(0.7f, 0.8f));
					vector += Rand.GetRandomVec2(-1f, 1f, -1f, 1f);
					if (num9 == 0)
					{
						Vector2 vector3 = vector - new Vector2((float)Math.Cos(num3 - 1.57f), (float)Math.Sin(num3 - 1.57f)) * 32f * scale;
						vector = vector3;
						num3 += Rand.GetRandomFloat(-1.5f, 1.5f);
						vector = vector3 - new Vector2((float)Math.Cos(num3 + 1.57f), (float)Math.Sin(num3 + 1.57f)) * 32f * scale;
					}
					else
					{
						num3 += Rand.GetRandomFloat(-0.03f, 0.03f);
					}
				}
				if (charUpdate != null)
				{
					if (charUpdate.dyingFrame > 1.5f && c.team != Character.Team.GoodGuys)
					{
						color = new Color(new Vector4(charBrite, charBrite2, charBrite3, (2f - charUpdate.dyingFrame) * 2f));
					}
					if (charUpdate.fire > 0f)
					{
						color = new Color(charBrite - charUpdate.fire * 2f, charBrite2 - charUpdate.fire * 2f, charBrite3 - charUpdate.fire * 2f, 1f);
					}
					if (charUpdate.warpFrame > 0f && !cMeta.warpscissors && !cMeta.warpcleavers && !cMeta.warphammer)
					{
						float warpFrame = charUpdate.warpFrame;
						float num16 = 0f;
						if (cMeta.isYuki)
						{
							if (warpFrame > 0.15f)
							{
								num16 = (warpFrame - 0.15f) * 10f;
							}
						}
						else if (warpFrame > 0.3f)
						{
							num16 = (warpFrame - 0.3f) * 10f;
						}
						if (warpFrame < 0.1f)
						{
							num16 = (0.1f - warpFrame) * 10f;
						}
						color = new Color(new Vector4(charBrite * (num16 * 4f - 3f), charBrite2 * (num16 * 4f - 3f), charBrite3 * (num16 * 4f - 3f), num16));
					}
				}
				if (num9 == 3)
				{
					int num17 = (part2.idx - 192) / 4;
					if (cDef.weaponIdx == 0)
					{
						if (machine == 2)
						{
							if (num17 == 4 || num17 == 5)
							{
								rectangle = Game1.weaponTexMeta[cDef.weaponIdx].GetRect(part2.idx - 192 - 8);
							}
							if (num17 == 7)
							{
								rectangle = Game1.weaponTexMeta[cDef.weaponIdx].GetRect(part2.idx - 192 - 16);
							}
						}
						if (c.charMeta == 91)
						{
							machine = 1;
						}
						if (c.charMeta == 90)
						{
							machine = 2;
						}
						if (machine == 1 && (num17 == 2 || num17 == 3))
						{
							rectangle = Game1.weaponTexMeta[cDef.weaponIdx].GetRect(part2.idx - 192 + 8);
						}
						if (machine == 0 && (num17 == 2 || num17 == 3 || num17 == 4 || num17 == 5 || num17 == 7))
						{
							color = new Color(new Vector4(1f, 1f, 1f, 0.05f));
						}
						if (flag)
						{
							if (melee == 3 || melee == 4)
							{
								if (num17 == 0 || num17 == 1)
								{
									flag4 = true;
								}
								if (num17 == 8 || num17 == 9 || num17 == 10)
								{
									flag4 = true;
								}
							}
							if (melee == 2 && (num17 == 0 || num17 == 1))
							{
								flag4 = true;
							}
							if (melee == 1 && (num17 == 8 || num17 == 9 || num17 == 10))
							{
								flag4 = true;
							}
						}
						if ((flag2 || flag3) && melee == 5 && c.ID < 4)
						{
							if (num17 == 0 || num17 == 1)
							{
								flag4 = true;
							}
							if (num17 == 8 || num17 == 9 || num17 == 10 || num17 == 11)
							{
								flag4 = true;
							}
						}
					}
				}
				bool flag5 = false;
				if ((face == 1 && part2.flip == 0) || (face == 0 && part2.flip == 1))
				{
					flag5 = true;
				}
				if (texture2D == null || flag4)
				{
					continue;
				}
				try
				{
					if (cMeta.isPuppet && part2.idx / 64 != 3)
					{
						float num18 = 0.4f;
						if (Game1.gameMap.isPuppeteer)
						{
							num18 = (c.charUpdate.loc.Y - Game1.gameMap.fingerVec[c.ID % 4].Y) * 0.0005f;
						}
						spriteBatch.Draw(Game1.spritesTex, vector, new Rectangle(448, 0, 256, 32), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.2f, 0.3f)), -1.57f, new Vector2(0f, 16f), new Vector2(5f, 0.3f) * ScrollManager.cannedDepth[0] * num18, SpriteEffects.None, 1f);
					}
					if (cMeta.isTVCrazy && part2.idx / 64 == 0)
					{
						rectangle.Y += Rand.GetRandomInt(0, 4) * Game1.headTexMeta[cMeta.headTex].GetRect(part2.idx).Height;
					}
					if (Game1.gameMap.goryoMode)
					{
						switch (cMeta.headTex)
						{
						case 11:
							if (num9 == 0)
							{
								if (part2.idx < 3)
								{
									spriteBatch.Draw(Game1.waterTex, vector, new Rectangle(256, 0, 128, 128), color, num3, new Vector2((float)rectangle.Width / 2f, (float)rectangle.Height / 2f), vector2 * 0.9f * 2f, (!flag5) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
								}
								rectangle.Width = 0;
							}
							break;
						case 31:
							if (num9 == 0)
							{
								if (part2.idx < 2)
								{
									spriteBatch.Draw(Game1.waterTex, vector, new Rectangle(384, 128, 128, 128), color, num3, new Vector2((float)rectangle.Width / 2f, (float)rectangle.Height / 2f), vector2 * 0.9f * 2f, (!flag5) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
								}
								rectangle.Width = 0;
							}
							break;
						case 25:
							if (num9 == 0)
							{
								if (part2.idx == 0)
								{
									spriteBatch.Draw(Game1.waterTex, vector, new Rectangle(256, 128, 128, 128), color, num3, new Vector2((float)rectangle.Width / 2f, (float)rectangle.Height / 2f), vector2 * 0.9f * 2f, (!flag5) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
								}
								rectangle.Width = 0;
							}
							break;
						}
					}
					spriteBatch.Draw(texture2D, vector, rectangle, color, num3, new Vector2((float)rectangle.Width / 2f, (float)rectangle.Height / 2f), vector2, (!flag5) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
					if (num9 == 3)
					{
						CharSwishes.Add(vector, part2.idx, rectangle, flag5, vector2, num3, cMeta.weapTex);
					}
					if (cMeta.isDragon && GameRender.filterRender.charBrite < 1f)
					{
						PostGlowMgr.AddGlow(vector, 0.8f, 0.9f, 1f, 1f, 0.3f, 1f);
					}
					if (charUpdate != null)
					{
						Themes.ThemeType theme = Game1.gameMap.theme.theme;
						if (theme != Themes.ThemeType.Asylum)
						{
							if (num9 == 1)
							{
								if (cMeta.isMara || cMeta.isYuki)
								{
									if (charUpdate.bodyStain > 0f)
									{
										DrawBloodstain(2, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.bodyStain);
									}
									if (charUpdate.specialStain > 0f)
									{
										DrawBloodstain(4, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.specialStain);
									}
								}
								if (cMeta.isDish)
								{
									if (charUpdate.bodyStain > 0f)
									{
										DrawBloodstain(6, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.bodyStain);
									}
									if (charUpdate.specialStain > 0f)
									{
										DrawBloodstain(8, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.specialStain);
									}
								}
							}
							if (num9 == 0)
							{
								if (cMeta.isMara || cMeta.isYuki)
								{
									if (charUpdate.bodyStain > 0f)
									{
										DrawBloodstain(5, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.bodyStain);
									}
									if (charUpdate.specialStain > 0f)
									{
										DrawBloodstain(3, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.specialStain);
									}
								}
								if (cMeta.isDish && !cMeta.isLoic && !cMeta.isHargreaves && !cMeta.isHatless && charUpdate.bodyStain > 0f)
								{
									DrawBloodstain(7, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.bodyStain);
								}
							}
							if (num9 == 3)
							{
								if (cMeta.weapTex == 5 && charUpdate.weaponStain > 0f && charUpdate.weaponStain > 0f)
								{
									switch (num8)
									{
									case 1:
										DrawBloodstain(12, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.weaponStain);
										break;
									case 0:
										DrawBloodstain(11, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.weaponStain);
										break;
									default:
										DrawBloodstain(0, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.weaponStain);
										break;
									}
								}
								if (cMeta.weapTex == 0)
								{
									int num19 = (part2.idx - 192) / 4;
									if (num19 == 4 || num19 == 5 || num19 == 7)
									{
										if (charUpdate.chainsawStain > 0f)
										{
											switch (num8)
											{
											case 1:
												DrawBloodstain(10, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.chainsawStain);
												break;
											case 0:
												DrawBloodstain(9, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.chainsawStain);
												break;
											default:
												DrawBloodstain(1, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.chainsawStain);
												break;
											}
										}
									}
									else if (charUpdate.weaponStain > 0f)
									{
										switch (num8)
										{
										case 1:
											DrawBloodstain(10, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.weaponStain);
											break;
										case 0:
											DrawBloodstain(9, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.weaponStain);
											break;
										default:
											DrawBloodstain(1, spriteBatch, vector, rectangle, charUpdate, num3, vector2, flag5, charUpdate.weaponStain);
											break;
										}
									}
								}
							}
						}
					}
					if (!cMeta.isYuki || num9 != 3 || (part2.idx - 192) / 4 != 14 || !(c.charUpdate.cloudCharge > 0f))
					{
						continue;
					}
					float cloudCharge = c.charUpdate.cloudCharge;
					cloudCharge -= 0.5f;
					if (cloudCharge > 0f)
					{
						if (cloudCharge > 5f)
						{
							cloudCharge = 5f;
						}
						int num20 = (int)(cloudCharge / 1f);
						spriteBatch.Draw(texture2D, vector, rectangle, new Color(0f, 0f, 0f, cloudCharge), num3, new Vector2((float)rectangle.Width / 2f, (float)rectangle.Height / 2f), vector2, (!flag5) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
						spriteBatch.End();
						SpriteTools.BeginAdditive();
						for (int m = 0; m < num20 + 1; m++)
						{
							spriteBatch.Draw(texture2D, vector, rectangle, new Color(0.5f, 0.5f, 1f, Rand.GetRandomFloat(0.25f, 0.5f)), num3, new Vector2((float)rectangle.Width / 2f, (float)rectangle.Height / 2f), vector2 * Rand.GetRandomVec2(1f, 1.2f, 1f, 2f), (!flag5) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
							for (int n = 0; n < 3; n++)
							{
								float randomFloat = Rand.GetRandomFloat(-80f, 80f);
								Vector2 vector4 = vector + new Vector2((float)Math.Cos(num3), (float)Math.Sin(num3)) * randomFloat * vector2.X * scale;
								if (n == 0)
								{
									PostGlowMgr.AddGlow(vector4, 0.5f, 0.5f, 1f, Rand.GetRandomFloat(0f, 1f + cloudCharge * 0.1f), 0.1f, 1f);
								}
								spriteBatch.Draw(Game1.spritesTex, vector4, new Rectangle(896, 128 * Rand.GetRandomInt(0, 3), 128, 128), new Color(0.5f, 0.5f, 1f, Rand.GetRandomFloat(0.125f, 0.5f)), Rand.GetRandomFloat(0f, 6.28f), new Vector2(64f, 64f), vector2 * Rand.GetRandomVec2(0.5f, cloudCharge * 0.3f + 0.7f, 0.5f, cloudCharge * 0.3f + 0.7f), SpriteEffects.None, 1f);
							}
						}
					}
					SpriteTools.End();
					SpriteTools.BeginAlpha();
				}
				catch (Exception ex)
				{
					Printf.WriteLine(ex.Message);
				}
			}
		}
		if (c.charUpdate.wcharge > 0f)
		{
			SpriteTools.End();
			SpriteTools.BeginAdditive();
			for (int num21 = 0; num21 < frame.GetPartArray().Length; num21++)
			{
				Frame.Part part4 = frame.GetPart(num21);
				if (part4.idx <= -1)
				{
					continue;
				}
				float rotation = part4.rotation;
				Vector2 position = part4.location * scale + loc;
				Vector2 scale2 = part4.scaling * scale;
				if (face == 0)
				{
					rotation = 0f - rotation;
					position.X -= part4.location.X * scale * 2f;
				}
				if (next > -1)
				{
					Frame frame3 = cDef.GetFrame(next);
					if (Frame.CanLerp(frame, frame3, num21))
					{
						Frame.Part part5 = frame3.GetPart(num21);
						Animation animation2 = cDef.GetAnimation(c.charAnim.anim);
						KeyFrame keyFrame2 = animation2.GetKeyFrame(c.charAnim.GetKey());
						float progress = c.charAnim.frame / (float)keyFrame2.duration;
						Vector2 location3 = part4.location;
						Vector2 location4 = part5.location;
						float num22 = part4.rotation;
						float num23 = part5.rotation;
						if (face == 0)
						{
							num22 = 0f - num22;
							num23 = 0f - num23;
							location3.X -= part4.location.X * 2f;
							location4.X -= part5.location.X * 2f;
						}
						position = Frame.LerpLoc(location3, location4, progress) * scale + loc;
						rotation = Frame.LerpRotation(num22, num23, progress);
						scale2 = Frame.LerpScale(part4.scaling, part5.scaling, progress) * scale;
					}
				}
				for (int num24 = 0; num24 < 2; num24++)
				{
					spriteBatch.Draw(Game1.spritesTex, position, new Rectangle(896, 128 * Rand.GetRandomInt(0, 3), 128, 128), new Color(0.5f, 0.5f, 1f, charUpdate.wcharge), Rand.GetRandomFloat(0f, 6.28f), new Vector2(64f, 64f), scale2, SpriteEffects.None, 1f);
				}
			}
			SpriteTools.End();
			SpriteTools.BeginAlpha();
		}
		if (!(c.charUpdate.warpFrame > 0f))
		{
			c.charPhysics.Draw(spriteBatch);
		}
		if (c.charAnim.charTrigs.hasGibSpray && (c.charAnim.charTrigs.sprayType == CharTrigs.SprayType.Blood || c.charAnim.charTrigs.sprayType == CharTrigs.SprayType.Giantblood || c.charAnim.charTrigs.sprayType == CharTrigs.SprayType.WeaponSpray) && !charUpdate.charGrab.grabbing)
		{
			c.charAnim.DrawCharGiblets(spriteBatch, thresh: false);
		}
	}

	public void DrawForeCharacter(SpriteBatch spriteBatch, Vector2 loc, float scale, int face, int frameIdx, CharDef cDef, CharMeta cMeta, CharAnim charAnim, int next)
	{
		face = 1 - face;
		Rectangle value = default;
		if (cDef == null)
		{
			return;
		}
		Frame frame = cDef.GetFrame(frameIdx);
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx <= -1)
			{
				continue;
			}
			bool flag = false;
			float num = part.rotation;
			Vector2 position = part.location * scale + loc;
			Vector2 scale2 = part.scaling * scale;
			if (face == 0)
			{
				num = 0f - num;
				position.X -= part.location.X * scale * 2f;
			}
			if (next > -1)
			{
				Frame frame2 = cDef.GetFrame(next);
				if (Frame.CanLerp(frame, frame2, i))
				{
					Frame.Part part2 = frame2.GetPart(i);
					Animation animation = cDef.GetAnimation(charAnim.anim);
					KeyFrame keyFrame = animation.GetKeyFrame(charAnim.GetKey());
					float num2 = charAnim.frame / (float)keyFrame.duration;
					if (MainPlayer.uberDyingFrame >= 1f || Game1.gameMap.lichFreakoutMode)
					{
						num2 = (float)(int)(num2 * (float)keyFrame.duration) / (float)keyFrame.duration;
					}
					Vector2 location = part.location;
					Vector2 location2 = part2.location;
					float num3 = part.rotation;
					float num4 = part2.rotation;
					if (face == 0)
					{
						num3 = 0f - num3;
						num4 = 0f - num4;
						location.X -= part.location.X * 2f;
						location2.X -= part2.location.X * 2f;
					}
					position = Frame.LerpLoc(location, location2, num2) * scale + loc;
					num = Frame.LerpRotation(num3, num4, num2);
					scale2 = Frame.LerpScale(part.scaling, part2.scaling, num2) * scale;
				}
			}
			if (part.idx >= 1000)
			{
				continue;
			}
			Texture2D texture2D;
			switch (part.idx / 64)
			{
			case 0:
				texture2D = Game1.headTex[cMeta.headTex];
				value = Game1.headTexMeta[cMeta.headTex].GetRect(part.idx);
				break;
			case 1:
			{
				int torsoTex = cMeta.torsoTex;
				texture2D = Game1.torsoTex[torsoTex];
				value = Game1.torsoTexMeta[torsoTex].GetRect(part.idx - 64);
				break;
			}
			case 2:
			{
				int num5 = cMeta.legsTex;
				if (num5 == 6 && Game1.player.yukiPhase < 6)
				{
					num5 = 0;
				}
				texture2D = Game1.legsTex[num5];
				value = Game1.legsTexMeta[num5].GetRect(part.idx - 128);
				break;
			}
			case 3:
				texture2D = Game1.weaponTex[cMeta.weapTex];
				value = Game1.weaponTexMeta[cMeta.weapTex].GetRect(part.idx - 192);
				break;
			default:
				texture2D = null;
				break;
			}
			float charBrite = GameRender.filterRender.charBrite;
			float charBrite2 = GameRender.filterRender.charBrite;
			float charBrite3 = GameRender.filterRender.charBrite;
			charBrite = (charBrite2 = (charBrite3 = 0f));
			Color color = new Color(charBrite, charBrite2, charBrite3, 1f);
			bool flag2 = false;
			if ((face == 1 && part.flip == 0) || (face == 0 && part.flip == 1))
			{
				flag2 = true;
			}
			if (texture2D != null && !flag)
			{
				try
				{
					spriteBatch.Draw(texture2D, position, value, color, num, new Vector2((float)value.Width / 2f, (float)value.Height / 2f), scale2, (!flag2) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
				}
				catch (Exception ex)
				{
					Printf.WriteLine(ex.Message);
				}
			}
		}
	}

	private void DrawBloodstain(int type, SpriteBatch spriteBatch, Vector2 location, Rectangle sRect, CharUpdate charUpdate, float rotation, Vector2 scaling, bool flip, float stain)
	{
		if (flibitPort.CurrentBlood != 1)
		{
			spriteBatch.Draw(Game1.charBloodStains.charBloodTexture[type], location, sRect, new Color(0.5f, 0f, 0f, stain), rotation, new Vector2((float)sRect.Width / 2f, (float)sRect.Height / 2f), scaling, (!flip) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
		}
	}

	public void DrawMagic(Character c, float magic, float magicOut, SpriteBatch sprite)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(c.charUpdate.loc + new Vector2(0f, -32f), 1f);
		for (int i = 0; i < 2; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				float num = magic;
				if (i == 0)
				{
					num /= 2f;
				}
				float num2 = magic - 0.1f;
				num2 -= (float)j / 10f;
				num2 *= 5f;
				if (num2 > 1f)
				{
					num2 = 1f;
				}
				switch (j)
				{
				case 1:
					num = 0f - num;
					break;
				case 2:
					num /= 2f;
					break;
				}
				float num3 = 1f;
				if (magicOut > 0f)
				{
					num3 += (1f - magicOut) * 5f;
					num2 *= magicOut;
				}
				sprite.Draw(Game1.magicTex, screenLoc, new Rectangle(j * 320, 0, 320, 320), c.GetMeta().isDish ? new Color(0.2f, 1f, 0.2f, num2) : new Color(1f, 0.2f, 0.2f, num2), num, new Vector2(160f, 160f), ScrollManager.zoom * new Vector2(num3, 1f) * ((i == 0) ? 0.32f : 0.7f), SpriteEffects.None, 1f);
			}
		}
	}
}
