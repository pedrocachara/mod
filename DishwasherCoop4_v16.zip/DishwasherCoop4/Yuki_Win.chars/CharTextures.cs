using Microsoft.Xna.Framework.Content;

namespace Yuki_Win.chars;

internal class CharTextures
{
	public static void Load(ContentManager Content)
	{
	}
}
