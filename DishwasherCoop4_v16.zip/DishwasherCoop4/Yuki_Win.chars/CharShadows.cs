using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;
using Yuki_Win.hud;
using Yuki_Win.maps;

namespace Yuki_Win.chars;

public class CharShadows
{
	public struct CharShadow
	{
		public Vector2 loc;

		public Vector2 size;

		public float alpha;
	}

	public CharShadow[] charShadow;

	public bool vis;

	public CharShadows()
	{
		charShadow = new CharShadow[16];
	}

	public void CalculateShadows(Vector2 loc, int face, int frameIdx, CharDef cDef, CharMeta cMeta, CharDef actorDef, CharMeta actorMeta, CharUpdate charUpdate, Character c, int next)
	{
		if ((Game1.gameMap.psychoTVAlpha > 0f || Game1.gameMap.theme.theme == Themes.ThemeType.Asylum) && (cMeta.isCrow || cMeta.isNeko))
		{
			return;
		}
		face = 1 - face;
		Rectangle rectangle = default;
		if (cDef == null)
		{
			return;
		}
		Frame frame = cDef.GetFrame(frameIdx);
		if (next > -1)
		{
			cDef.GetFrame(next);
		}
		float num = 0.35f;
		lock (charShadow)
		{
			for (int i = 0; i < charShadow.Length; i++)
			{
				charShadow[i].alpha = 0f;
			}
			for (int j = 0; j < frame.GetPartArray().Length; j++)
			{
				Frame.Part part = frame.GetPart(j);
				if (part.idx <= -1)
				{
					continue;
				}
				float rotation = part.rotation;
				Vector2 vector = part.location * num + loc;
				Vector2 vector2 = part.scaling * num;
				if (face == 0)
				{
					rotation = 0f - rotation;
					vector.X -= part.location.X * num * 2f;
				}
				if (next > -1)
				{
					Frame frame2 = cDef.GetFrame(next);
					if (Frame.CanLerp(frame, frame2, j))
					{
						Frame.Part part2 = frame2.GetPart(j);
						Animation animation = cDef.GetAnimation(c.charAnim.anim);
						KeyFrame keyFrame = animation.GetKeyFrame(c.charAnim.GetKey());
						float progress = c.charAnim.frame / (float)keyFrame.duration;
						Vector2 orig = part.location * num + loc;
						Vector2 next2 = part2.location * num + loc;
						float num2 = part.rotation;
						float num3 = part2.rotation;
						if (face == 0)
						{
							num2 = 0f - num2;
							num3 = 0f - num3;
							orig.X -= part.location.X * 2f * num;
							next2.X -= part2.location.X * 2f * num;
						}
						vector = Frame.LerpLoc(orig, next2, progress);
						rotation = Frame.LerpRotation(num2, num3, progress);
						vector2 = Frame.LerpScale(part.scaling, part2.scaling, progress) * num;
					}
				}
				bool flag = false;
				if (part.idx >= 2000)
				{
					if (actorDef == null)
					{
						continue;
					}
					int num4 = 1 - face;
					if (num4 == 1)
					{
						if (part.flip == 1)
						{
							num4 = 1 - num4;
						}
					}
					else if (part.flip == 1)
					{
						num4 = 1 - num4;
					}
					CalculateShadows(vector, num4, part.idx - 2000, actorDef, actorMeta, null, null, null, Game1.character[c.charUpdate.charGrab.grabbedByChar], -1);
				}
				else
				{
					if (part.idx - 1000 == 30 || part.idx >= 1000)
					{
						continue;
					}
					switch (part.idx / 64)
					{
					case 0:
						rectangle = Game1.headTexMeta[cMeta.headTex].GetRect(part.idx);
						break;
					case 1:
						rectangle = Game1.torsoTexMeta[cMeta.torsoTex].GetRect(part.idx - 64);
						break;
					case 2:
						rectangle = Game1.legsTexMeta[cMeta.legsTex].GetRect(part.idx - 128);
						break;
					case 3:
						flag = true;
						break;
					}
					if (flag)
					{
						continue;
					}
					Vector2 v = vector;
					Vector2 vector3 = vector;
					vector3.Y = Game1.gameMap.CurMap().GetMaxY(v);
					bool flag2 = false;
					flag = false;
					for (int k = 0; k < 20; k++)
					{
						vector3.Y += 24f;
						if (Game1.gameMap.CurMap().TestCol(vector3, ceils: false, shadow: true))
						{
							vector3.Y = Game1.gameMap.CurMap().GetMinY(vector3);
							flag2 = true;
							if (Game1.gameMap.CurMap().TestCol(vector3 + new Vector2(0f, -32f)))
							{
								flag = true;
							}
							break;
						}
					}
					if (!flag2 || flag)
					{
						continue;
					}
					float num5 = vector3.Y - v.Y;
					if (num5 < 200f)
					{
						float alpha = 1f;
						if (num5 > 150f)
						{
							alpha = (200f - num5) / 50f;
						}
						try
						{
							charShadow[j].loc = vector3;
							charShadow[j].size = ((float)rectangle.Width + (float)rectangle.Height) * (vector2.X + vector2.Y) * new Vector2(0.2f, 0.05f) * 0.015f;
							charShadow[j].alpha = alpha;
						}
						catch (Exception ex)
						{
							Printf.WriteLine(ex.Message);
						}
					}
				}
			}
		}
		vis = true;
	}

	public void DrawShadows(SpriteBatch spriteBatch)
	{
		if (!vis)
		{
			return;
		}
		lock (charShadow)
		{
			for (int i = 0; i < charShadow.Length; i++)
			{
				if (charShadow[i].alpha > 0f)
				{
					spriteBatch.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(charShadow[i].loc, 1f), new Rectangle(i / 2 % 2 * 192, 448, 192, 192), new Color(0f, 0f, 0f, 0.3f * charShadow[i].alpha), 0f, new Vector2(96f, 96f), charShadow[i].size * ScrollManager.cannedDepth[0], (i % 3 == 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
				}
			}
		}
	}
}
