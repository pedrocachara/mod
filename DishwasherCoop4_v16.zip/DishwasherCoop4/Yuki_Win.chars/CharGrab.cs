using Microsoft.Xna.Framework;
using Yuki_Win.arcade;
using Yuki_Win.levels;

namespace Yuki_Win.chars;

public class CharGrab
{
	public int grabbedByChar = -1;

	public bool grabbing;

	public Vector2 grabberLoc;

	public float minY;

	public float maxY;

	public bool grabAttack;

	public bool grabChop;

	public int duelCount;

	public void ResetYDif(float y)
	{
		minY = (maxY = y);
	}

	public void CheckGrabbing(Character[] c, int ID)
	{
		grabbing = false;
		for (int i = 0; i < c.Length; i++)
		{
			if (c[i].exists && c[i].charUpdate.charGrab.grabbedByChar > -1 && c[i].charUpdate.charGrab.grabbedByChar == ID)
			{
				grabbing = true;
			}
		}
	}

	internal bool CheckSawKillable(CharUpdate charUpdate, Character[] cArray)
	{
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.NomNom || Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.CrackingSkull))
		{
			return false;
		}
		for (int i = 0; i < cArray.Length; i++)
		{
			if (!cArray[i].exists || cArray[i].charUpdate.state != CharUpdate.State.Grounded || !cArray[i].GetSawable())
			{
				continue;
			}
			float num = cArray[i].charUpdate.mhp / 4f;
			if (cArray[i].GetMeta().isSawer)
			{
				num = cArray[i].charUpdate.mhp / 2f;
			}
			if (charUpdate.face == 1)
			{
				if (cArray[i].charUpdate.loc.X > charUpdate.loc.X && cArray[i].charUpdate.loc.X < charUpdate.loc.X + 150f && cArray[i].charUpdate.hp < num && cArray[i].charUpdate.dyingFrame <= 0f && !cArray[i].GetMeta().isGiant)
				{
					return true;
				}
			}
			else if (cArray[i].charUpdate.loc.X < charUpdate.loc.X && cArray[i].charUpdate.loc.X > charUpdate.loc.X - 150f && cArray[i].charUpdate.hp < num && cArray[i].charUpdate.dyingFrame <= 0f && !cArray[i].GetMeta().isGiant)
			{
				return true;
			}
		}
		return false;
	}

	internal bool CheckExeKillable(CharUpdate charUpdate, Character[] cArray)
	{
		return CheckExeKillable(charUpdate, cArray, 0f);
	}

	internal bool CheckExeKillable(CharUpdate charUpdate, Character[] cArray, float nw)
	{
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.NomNom || Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.CrackingSkull))
		{
			return false;
		}
		for (int i = 0; i < cArray.Length; i++)
		{
			if (!cArray[i].exists || !cArray[i].GetExeable())
			{
				continue;
			}
			float num = 150f;
			if (cArray[i].GetMeta().isGiant)
			{
				num += 100f;
			}
			num += nw;
			if (!(cArray[i].charUpdate.loc.Y > charUpdate.loc.Y - 100f))
			{
				continue;
			}
			if (charUpdate.face == 1)
			{
				if (cArray[i].charUpdate.loc.X > charUpdate.loc.X && cArray[i].charUpdate.loc.X < charUpdate.loc.X + num && ((cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.hp < 0f) || (!cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.hp < cArray[i].charUpdate.mhp / 4f && cArray[i].charUpdate.dyingFrame <= 0f) || Game1.gameMap.firstExe))
				{
					return true;
				}
			}
			else if (cArray[i].charUpdate.loc.X < charUpdate.loc.X && cArray[i].charUpdate.loc.X > charUpdate.loc.X - num && ((cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.hp < 0f) || (!cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.hp < cArray[i].charUpdate.mhp / 4f && cArray[i].charUpdate.dyingFrame <= 0f) || Game1.gameMap.firstExe))
			{
				return true;
			}
		}
		return false;
	}

	internal bool CheckGrabKillable(CharUpdate charUpdate, Character[] cArray, bool canGroundsplode)
	{
		for (int i = 0; i < cArray.Length; i++)
		{
			if (!cArray[i].exists || !cArray[i].GetGrabbable())
			{
				continue;
			}
			float num = 150f;
			if (cArray[i].GetMeta().isGiant)
			{
				num += 100f;
			}
			num -= 50f;
			float num2 = 80f;
			if (cArray[i].GetMeta().isGiant)
			{
				for (int j = 0; j < cArray[i].charRect.hitRect.Length; j++)
				{
					Rectangle rectangle = cArray[i].charRect.hitRect[j];
					if (rectangle.Width > 0)
					{
						float num3 = cArray[i].charUpdate.loc.Y - (float)rectangle.Y;
						if (num3 > (float)(int)num2)
						{
							num2 = num3;
						}
					}
				}
				num2 -= 40f;
			}
			if (!(charUpdate.loc.Y <= cArray[i].charUpdate.loc.Y + 80f) || !(charUpdate.loc.Y > cArray[i].charUpdate.loc.Y - num2))
			{
				continue;
			}
			if (charUpdate.face == 1)
			{
				if (cArray[i].charUpdate.loc.X > charUpdate.loc.X && cArray[i].charUpdate.loc.X < charUpdate.loc.X + num && ((cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.hp < 0f) || (!cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.hp < cArray[i].charUpdate.mhp / 4f && cArray[i].charUpdate.dyingFrame <= 0f) || (canGroundsplode && cArray[i].GetMeta().autoGroundSplode) || (cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.giantVulnTimer > 0f)))
				{
					return true;
				}
			}
			else if (cArray[i].charUpdate.loc.X < charUpdate.loc.X && cArray[i].charUpdate.loc.X > charUpdate.loc.X - num && ((cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.hp < 0f) || (!cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.hp < cArray[i].charUpdate.mhp / 4f && cArray[i].charUpdate.dyingFrame <= 0f) || (canGroundsplode && cArray[i].GetMeta().autoGroundSplode) || (cArray[i].GetMeta().isJuggernaut && cArray[i].charUpdate.giantVulnTimer > 0f)))
			{
				return true;
			}
		}
		return false;
	}
}
