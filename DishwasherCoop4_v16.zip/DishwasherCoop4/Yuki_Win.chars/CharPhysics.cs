using System;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;
using Yuki_Win.debug;
using Yuki_Win.physics;

namespace Yuki_Win.chars;

public class CharPhysics
{
	public Rope[] rope;

	private int def;

	public CharPhysics()
	{
		def = -1;
	}

	internal void Init(Character c)
	{
		if (c.charMeta != def)
		{
			switch (c.charMeta)
			{
			case 0:
			case 2:
			case 8:
			case 9:
			case 10:
			case 11:
			case 22:
			case 25:
			case 37:
			case 38:
			case 39:
			case 46:
			case 76:
			case 78:
			{
				rope = new Rope[4];
				for (int i = 0; i < rope.Length; i++)
				{
					rope[i] = new Rope(6, 7f);
				}
				break;
			}
			case 5:
			case 15:
			case 16:
			case 24:
			case 26:
			case 27:
			case 28:
			case 29:
			case 30:
			case 31:
			case 32:
			case 33:
			case 34:
			case 35:
			case 36:
			case 92:
			case 93:
			{
				rope = new Rope[4];
				for (int j = 0; j < rope.Length; j++)
				{
					rope[j] = new Rope(6, 7f);
				}
				break;
			}
			default:
				if (rope != null)
				{
					rope = null;
				}
				break;
			}
		}
		def = c.charMeta;
	}

	public void UpdateGrabberPhysics(Character c)
	{
		int curFrame = c.charAnim.GetCurFrame();
		Frame frame = Game1.charDef[c.cDef].GetFrame(curFrame);
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx < 2000)
			{
				continue;
			}
			int num = 1 - c.charUpdate.face;
			if (num == 1)
			{
				if (part.flip == 1)
				{
					num = 1 - num;
				}
			}
			else if (part.flip == 1)
			{
				num = 1 - num;
			}
			Vector2 location = part.location;
			if (c.charUpdate.face == 1)
			{
				location.X *= -1f;
			}
			Vector2 loc = location * 0.35f + c.charUpdate.loc;
			Game1.character[c.charUpdate.charGrab.grabbedByChar].charPhysics.Update(Game1.character[c.charUpdate.charGrab.grabbedByChar], loc, 1 - num, part.idx - 2000, -1);
		}
	}

	public void ResetRope()
	{
		if (rope == null)
		{
			return;
		}
		for (int i = 0; i < rope.Length; i++)
		{
			if (rope[i] != null)
			{
				rope[i].Reset();
			}
		}
	}

	public void Update(Character c, Vector2 loc, int face, int frameIdx, int next)
	{
		if (rope == null)
		{
			return;
		}
		Frame frame = Game1.charDef[c.cDef].GetFrame(frameIdx);
		switch (c.charMeta)
		{
		case 0:
		case 2:
		case 8:
		case 9:
		case 10:
		case 11:
		case 22:
		case 25:
		case 37:
		case 38:
		case 39:
		case 46:
		case 76:
		case 78:
		case 79:
		case 85:
		case 86:
		{
			for (int j = 0; j < frame.GetPartArray().Length; j++)
			{
				Frame.Part part2 = frame.GetPart(j);
				if (part2.idx <= -1 || part2.idx >= 64)
				{
					continue;
				}
				Vector2 vector2 = part2.location;
				float angle2 = part2.rotation;
				if (next > -1)
				{
					Frame frame3 = Game1.charDef[c.cDef].GetFrame(next);
					float progress2 = c.charAnim.frame / (float)Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(c.charAnim.GetKey()).duration;
					if (Frame.CanLerp(frame, frame3, j))
					{
						vector2 = Frame.LerpLoc(part2.location, frame3.GetPart(j).location, progress2);
						angle2 = Frame.LerpRotation(part2.rotation, frame3.GetPart(j).rotation, progress2);
					}
				}
				switch (part2.idx % 6)
				{
				case 0:
					SetRope(0, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-22f, 7f));
					SetRope(1, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-15f, -10f));
					SetRope(2, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(16f, -11f));
					SetRope(3, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(21f, 5f));
					break;
				case 1:
					SetRope(0, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-31f, -7f));
					SetRope(1, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-15f, -5f));
					SetRope(2, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(20f, 5f));
					SetRope(3, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(24f, -2f));
					break;
				case 2:
					SetRope(0, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-34f, -4f));
					SetRope(1, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-15f, -10f));
					SetRope(2, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(21f, 4f));
					SetRope(3, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(21f, -7f));
					break;
				case 3:
					SetRope(1, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(1f, -9f));
					SetRope(2, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(22f, -5f));
					SetRope(3, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(34f, 7f));
					switch (c.charMeta)
					{
					case 37:
					case 38:
					case 39:
						SetRope(0, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-13f, -2f));
						break;
					default:
						SetRope(0, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-33f, -2f));
						break;
					}
					break;
				case 4:
					SetRope(0, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-34f, -7f));
					SetRope(1, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-15f, -1f));
					SetRope(2, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(21f, -12f));
					SetRope(3, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(32f, -1f));
					break;
				case 5:
					SetRope(0, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-22f, 7f));
					SetRope(1, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(-15f, -10f));
					SetRope(2, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(16f, -11f));
					SetRope(3, loc, face, part2.flip, vector2 * 0.35f, angle2, new Vector2(21f, 5f));
					break;
				}
			}
			break;
		}
		case 5:
		case 15:
		case 16:
		case 24:
		case 26:
		case 27:
		case 28:
		case 29:
		case 30:
		case 31:
		case 32:
		case 33:
		case 34:
		case 35:
		case 36:
		case 92:
		case 93:
		{
			for (int i = 0; i < frame.GetPartArray().Length; i++)
			{
				Frame.Part part = frame.GetPart(i);
				if (part.idx <= -1 || part.idx >= 64)
				{
					continue;
				}
				Vector2 vector = part.location;
				float angle = part.rotation;
				if (next > -1)
				{
					Frame frame2 = Game1.charDef[c.cDef].GetFrame(next);
					float progress = c.charAnim.frame / (float)Game1.charDef[c.cDef].GetAnimation(c.charAnim.anim).GetKeyFrame(c.charAnim.GetKey()).duration;
					if (Frame.CanLerp(frame, frame2, i))
					{
						vector = Frame.LerpLoc(part.location, frame2.GetPart(i).location, progress);
						angle = Frame.LerpRotation(part.rotation, frame2.GetPart(i).rotation, progress);
					}
				}
				switch (part.idx % 6)
				{
				case 0:
					SetRope(0, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-31f, -7f));
					SetRope(1, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-31f, -10f));
					SetRope(2, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-25f, -11f));
					SetRope(3, loc, face, part.flip, vector * 0.35f, angle, new Vector2(26f, -5f));
					break;
				case 1:
					SetRope(0, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-33f, -1f));
					SetRope(1, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-25f, -5f));
					SetRope(2, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-16f, -1f));
					switch (c.charMeta)
					{
					case 27:
					case 28:
					case 29:
					case 30:
					case 31:
						SetRope(3, loc, face, part.flip, vector * 0.35f, angle, new Vector2(31f, -2f), -1f);
						break;
					default:
						SetRope(3, loc, face, part.flip, vector * 0.35f, angle, new Vector2(20f, -2f), -1f);
						break;
					}
					break;
				case 2:
					SetRope(0, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-34f, -4f));
					SetRope(1, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-22f, -8f));
					SetRope(2, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-9f, -8f));
					SetRope(3, loc, face, part.flip, vector * 0.35f, angle, new Vector2(1f, -7f));
					break;
				case 3:
					SetRope(0, loc, face, part.flip, vector * 0.35f, angle, new Vector2(-33f, -2f));
					SetRope(1, loc, face, part.flip, vector * 0.35f, angle, new Vector2(1f, -9f));
					SetRope(2, loc, face, part.flip, vector * 0.35f, angle, new Vector2(22f, -5f));
					SetRope(3, loc, face, part.flip, vector * 0.35f, angle, new Vector2(34f, 7f));
					break;
				}
			}
			break;
		}
		}
	}

	private void SetRope(int rIdx, Vector2 orig, int face, int flip, Vector2 loc, float angle, Vector2 offset)
	{
		SetRope(rIdx, orig, face, flip, loc, angle, offset, 0f);
	}

	private void SetRope(int rIdx, Vector2 orig, int face, int flip, Vector2 loc, float angle, Vector2 offset, float lim)
	{
		Vector2 orig2 = orig;
		if (face == 1)
		{
			orig2.X -= loc.X;
		}
		else
		{
			orig2.X += loc.X;
		}
		orig2.Y += loc.Y;
		float num = ((flip == face) ? (-1f) : 1f);
		if (flip == face)
		{
			lim = 0f - lim;
		}
		offset *= 0.35f;
		offset *= 1.1f;
		if (flip == 1)
		{
			angle = 3.14f - angle;
		}
		orig2 += new Vector2((float)Math.Cos(angle) * offset.X * num, (float)Math.Sin(angle) * (0f - offset.X));
		orig2 += new Vector2((float)Math.Cos(angle + 1.57f) * offset.Y * num, (float)Math.Sin(angle + 1.57f) * (0f - offset.Y));
		rope[rIdx].SetOrig(orig2);
		rope[rIdx].Update(lim);
	}

	public void Draw(SpriteBatch sprite)
	{
		if (rope == null)
		{
			return;
		}
		for (int i = 0; i < rope.Length; i++)
		{
			if (i > 0)
			{
				rope[i].DrawHair(sprite, 2);
			}
			else
			{
				rope[i].DrawHair(sprite, i % 2);
			}
			if (DebugManager.ropeTest)
			{
				for (int j = 0; j < rope[i].node.Length; j++)
				{
					StringBuilder text = new StringBuilder((int)rope[i].node[j].traj.X + ", " + (int)rope[i].node[j].traj.Y);
					Text.DrawCText(sprite, new Vector2(200f + (float)i * 200f, 100f + (float)j * 20f) + new Vector2(1f, 1f), text, Color.Black, 0.8f, 0);
					Text.DrawCText(sprite, new Vector2(200f + (float)i * 200f, 100f + (float)j * 20f), text, Color.White, 0.8f, 0);
				}
			}
		}
	}
}
