using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.ai;
using Yuki_Win.arcade;
using Yuki_Win.netplay;

namespace Yuki_Win.chars;

public class CharNetUpdate
{
	private NetBool alpha;

	private NetBool brava;

	private NetBool charlie;

	private NetBool mainPlayerBool;

	public int ID;

	public CharNetUpdate(int ID)
	{
		alpha = new NetBool();
		brava = new NetBool();
		charlie = new NetBool();
		mainPlayerBool = new NetBool();
		this.ID = ID;
	}

	public void Read(PacketReader reader, bool spawnFrame)
	{
		lock (Game1.character[ID])
		{
			bool flag = !Game1.character[ID].exists;
			if (!Game1.character[ID].exists || Game1.character[ID].charUpdate.dyingFrame > 0f)
			{
				Game1.character[ID].charUpdate.clientOwned = 0f;
			}
			Character character = ((!Game1.netSession.IsClient() || !(Game1.character[ID].charUpdate.clientOwned > 0f) || spawnFrame) ? Game1.character[ID] : Game1.netSession.netGame.dummyChar);
			if (Game1.netSession.IsHost() && ID >= 4)
			{
				Game1.character[ID].charUpdate.clientOwned = 0.5f;
			}
			CharUpdate.State state = character.charUpdate.state;
			character.charKeys.ClearKeys();
			int charMeta = character.charMeta;
			character.charMeta = (character.charAnim.charMeta = NetPacker.ReadByte(reader));
			character.cDef = (character.charAnim.charDef = NetPacker.ReadByte(reader));
			float num = NetPacker.ReadSmallInt(reader);
			if (Game1.netSession.IsHost())
			{
				if (ID >= 4 && !flag && num > character.charUpdate.hp + 10f)
				{
					num = character.charUpdate.hp;
				}
			}
			else if (character.ID >= 4 && num > character.charUpdate.mhp)
			{
				character.charUpdate.mhp = num;
			}
			character.charUpdate.hp = num;
			character.charUpdate.spawnFrame = (spawnFrame ? 0.5f : 0f);
			if (character.ID < 2)
			{
				character.charUpdate.mhp = NetPacker.ReadSmallInt(reader);
				character.charUpdate.mp = NetPacker.ReadByte(reader);
				character.charUpdate.mmp = NetPacker.ReadByte(reader);
				character.charRender.netLev[0] = NetPacker.ReadSByte(reader);
				character.charRender.netLev[1] = NetPacker.ReadSByte(reader);
				character.charRender.netLev[2] = NetPacker.ReadSByte(reader);
			}
			if (ID < 2 && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off)
			{
				if (Game1.gameMap.curMap == null)
				{
					reader.ReadInt16();
				}
				else
				{
					Game1.transMgr.mapsSynced = Game1.gameMap.CurMap().scriptMgr.CheckHashTagMatch(reader.ReadInt16());
				}
			}
			Vector2 loc = NetPacker.ReadVec2(reader);
			if (!Game1.netSession.IsHost() || !(Game1.transMgr.inFrame > 0f))
			{
				character.charUpdate.loc = loc;
			}
			character.charUpdate.traj = NetPacker.ReadVec2(reader);
			if (!character.exists || character.charMeta != charMeta)
			{
				character.Init(character.cDef, character.charUpdate.loc, character.charMeta, -1, (character.ID >= 4) ? Character.Team.BadGuys : Character.Team.GoodGuys, -1);
				switch (character.charMeta)
				{
				case 18:
					character.ai.type = 5;
					break;
				case 7:
					character.ai.type = 3;
					break;
				}
			}
			if (character.GetMeta().isShop || character.GetMeta().isViolin || character.GetMeta().isGuitar)
			{
				character.charUpdate.inactive = true;
			}
			int num2 = NetPacker.ReadSmallInt(reader);
			int num3 = NetPacker.ReadByte(reader);
			float frame = NetPacker.ReadSmallFloat(reader);
			bool flag2 = false;
			if (Game1.charDef[character.cDef].GetAnimation(num2) != null && (Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().run_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().runstart_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().runend_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().idle_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().idlet_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().turn_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().altRunStart_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().altturn_anim) && Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim) != null && (Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim).name == character.GetMeta().run_anim || Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim).name == character.GetMeta().runstart_anim || Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim).name == character.GetMeta().runend_anim || Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim).name == character.GetMeta().idle_anim || Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim).name == character.GetMeta().idlet_anim || Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim).name == character.GetMeta().turn_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().altRunStart_anim || Game1.charDef[character.cDef].GetAnimation(num2).name == character.GetMeta().altturn_anim))
			{
				flag2 = true;
			}
			if (!flag2 && Game1.charDef[character.cDef].GetAnimation(num2) != null)
			{
				int anim = character.charAnim.anim;
				character.charAnim.anim = num2;
				character.charAnim.animName = Game1.charDef[character.cDef].GetAnimation(num2).name;
				if (Game1.charDef[character.cDef].GetAnimation(num2).GetKeyFrame(num3) == null)
				{
					num3 = 0;
				}
				int key = character.charAnim.GetKey();
				if (num3 < key - 2 || num3 > key + 2 || anim != num2)
				{
					character.charAnim.SetKey(num3);
					character.charAnim.SetFrame(frame);
				}
			}
			if (Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim) == null)
			{
				character.charAnim.anim = 0;
				character.charAnim.animName = Game1.charDef[character.cDef].GetAnimation(character.charAnim.anim).name;
			}
			alpha.Read(reader);
			brava.Read(reader);
			charlie.Read(reader);
			if (alpha.val[0])
			{
				character.charUpdate.face = 1;
			}
			else
			{
				character.charUpdate.face = 0;
			}
			if (alpha.val[1])
			{
				character.team = Character.Team.GoodGuys;
			}
			else
			{
				character.team = Character.Team.BadGuys;
			}
			if (alpha.val[2])
			{
				character.charUpdate.state = CharUpdate.State.Airborne;
			}
			else
			{
				character.charUpdate.state = CharUpdate.State.Grounded;
				if (state == CharUpdate.State.Airborne)
				{
					character.charUpdate.FixNetLoc();
				}
			}
			bool flag3 = alpha.val[3];
			bool flag4 = alpha.val[4];
			bool grabbing = character.charUpdate.charGrab.grabbing;
			character.charUpdate.charGrab.grabbing = alpha.val[5];
			if (grabbing && !character.charUpdate.charGrab.grabbing)
			{
				character.charUpdate.FixNetLoc();
			}
			bool flag5 = alpha.val[6];
			if (charlie.val[3])
			{
				Game1.gamePlayerMgr.gamePlayer[ID].gold = reader.ReadSingle();
				Game1.gamePlayerMgr.gamePlayer[ID].picks = NetPacker.ReadByte(reader);
				Game1.hud.invMgr.inv[ID].NetRead(reader);
				Game1.hud.invMgr.inv[ID].active = true;
			}
			else if (ID < 2)
			{
				Game1.hud.invMgr.inv[ID].active = false;
			}
			if (flag3)
			{
				float warpFrame = NetPacker.ReadTinyFloat(reader);
				if (character.charUpdate.warpFrame < 0f)
				{
					if (character.GetMeta().isDish)
					{
						character.charUpdate.warpFrame = 0.4f;
					}
					else
					{
						character.charUpdate.warpFrame = 0.25f;
					}
				}
				else
				{
					character.charUpdate.warpFrame = warpFrame;
				}
				character.charUpdate.warpVec = NetPacker.ReadNormalizedVec2(reader);
			}
			else
			{
				character.charUpdate.warpFrame = 0f;
			}
			if (flag4)
			{
				character.charUpdate.dyingFrame = NetPacker.ReadTinyFloat(reader);
			}
			if (flag5)
			{
				character.charUpdate.charGrab.grabbedByChar = NetPacker.ReadByte(reader);
			}
			else
			{
				character.charUpdate.charGrab.grabbedByChar = -1;
			}
			if (charlie.val[4])
			{
				character.charUpdate.slow = NetPacker.ReadTinyFloat(reader);
			}
			character.charKeys.keyRight = alpha.val[7];
			character.charKeys.keyLeft = brava.val[0];
			character.charKeys.keyUp = brava.val[1];
			character.charKeys.keyDown = brava.val[2];
			character.charKeys.IsSawDown = brava.val[3];
			character.charKeys.keySec = brava.val[4];
			character.charUpdate.floating = brava.val[5];
			character.charKeys.keyJog = brava.val[6];
			if (character.charMeta == 7)
			{
				character.charKeys.keyWalk = brava.val[7];
			}
			else if (character.charMeta == 18 && character.ai != null)
			{
				character.ai.mount = brava.val[7];
			}
			character.charUpdate.inactive = charlie.val[0];
			character.charUpdate.locked = charlie.val[1];
			bool flag6 = charlie.val[2];
			if (Game1.netSession.IsClient() && charlie.val[5] && Game1.hud.arcadeIn.active && Game1.hud.arcadeIn.active && Game1.hud.arcadeIn.elapsedFrame >= 1f)
			{
				Game1.hud.arcadeIn.GetHostArcadeGoSignal();
			}
			if (character.charKeys.keySec)
			{
				character.charKeys.shootVec = default;
				if (character.charKeys.keyLeft)
				{
					character.charKeys.shootVec.X = -1f;
				}
				if (character.charKeys.keyRight)
				{
					character.charKeys.shootVec.X = 1f;
				}
				if (character.charKeys.keyUp)
				{
					character.charKeys.shootVec.Y = 1f;
				}
				if (character.charKeys.keyDown)
				{
					character.charKeys.shootVec.Y = -1f;
				}
			}
			if (character.team == Character.Team.BadGuys)
			{
				int num4 = NetPacker.ReadByte(reader);
				if (character.ai == null)
				{
					character.ai = new AI(num4, character.ID);
				}
				if (character.ai.type != num4)
				{
					character.ai.type = num4;
				}
				character.ai.job = NetPacker.ReadByte(reader);
				character.ai.targ = NetPacker.ReadByte(reader);
			}
			if (character.team == Character.Team.GoodGuys)
			{
				character.charUpdate.magic = NetPacker.ReadTinyFloat(reader);
			}
			if (character.charUpdate.locked)
			{
				character.charUpdate.lockVec = NetPacker.ReadVec2(reader);
			}
			if (flag6)
			{
				character.charUpdate.airJuggleFrame = NetPacker.ReadSmallFloat(reader);
				character.charUpdate.airJuggleVec = NetPacker.ReadVec2(reader);
			}
		}
	}

	public void Write(PacketWriter writer)
	{
		lock (Game1.character[ID])
		{
			Character character = Game1.character[ID];
			NetPacker.WriteByte(writer, 0);
			int num = character.ID;
			if (Game1.netSession.IsHost() && character.charUpdate.spawnFrame > 0f)
			{
				num += 100;
			}
			NetPacker.WriteByte(writer, num);
			NetPacker.WriteByte(writer, character.charMeta);
			NetPacker.WriteByte(writer, character.cDef);
			NetPacker.WriteSmallInt(writer, (int)character.charUpdate.hp);
			if (character.ID < 2)
			{
				NetPacker.WriteSmallInt(writer, (int)character.charUpdate.mhp);
				NetPacker.WriteByte(writer, character.charUpdate.mp);
				NetPacker.WriteByte(writer, character.charUpdate.mmp);
				NetPacker.WriteSByte(writer, character.charRender.netLev[0]);
				NetPacker.WriteSByte(writer, character.charRender.netLev[1]);
				NetPacker.WriteSByte(writer, character.charRender.netLev[2]);
			}
			if (character.ID < 2 && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off)
			{
				writer.Write(Game1.gameMap.CurMap().scriptMgr.GetHashTag());
			}
			NetPacker.WriteVec2(writer, character.charUpdate.loc);
			NetPacker.WriteVec2(writer, character.charUpdate.traj);
			NetPacker.WriteSmallInt(writer, character.charAnim.anim);
			NetPacker.WriteByte(writer, character.charAnim.GetKey());
			NetPacker.WriteSmallFloat(writer, character.charAnim.GetFrame());
			alpha.val[0] = character.charUpdate.face == 1;
			alpha.val[1] = character.team == Character.Team.GoodGuys;
			alpha.val[2] = character.charUpdate.state == CharUpdate.State.Airborne;
			alpha.val[3] = character.charUpdate.warpFrame > 0f;
			alpha.val[4] = character.charUpdate.dyingFrame > 0f;
			alpha.val[5] = character.charUpdate.charGrab.grabbing;
			alpha.val[6] = character.charUpdate.charGrab.grabbedByChar > -1;
			if (Game1.hud.invMgr.IsActive())
			{
				alpha.val[7] = false;
				brava.val[0] = false;
				brava.val[1] = false;
				brava.val[2] = false;
			}
			else
			{
				alpha.val[7] = character.charKeys.keyRight;
				brava.val[0] = character.charKeys.keyLeft;
				brava.val[1] = character.charKeys.keyUp;
				brava.val[2] = character.charKeys.keyDown;
			}
			brava.val[3] = character.charKeys.IsSawDown;
			brava.val[4] = character.charKeys.keySec;
			brava.val[5] = character.charUpdate.floating;
			brava.val[6] = character.charKeys.keyJog;
			if (character.charMeta == 7)
			{
				brava.val[7] = character.charKeys.keyWalk;
			}
			else if (character.charMeta == 18 && character.ai != null)
			{
				brava.val[7] = character.ai.mount;
			}
			charlie.val[0] = character.charUpdate.inactive;
			charlie.val[1] = character.charUpdate.locked;
			charlie.val[2] = character.charUpdate.airJuggleFrame > 0f;
			int num2 = -1;
			if (ID < 2)
			{
				charlie.val[3] = Game1.hud.invMgr.inv[ID].active;
				if (Game1.hud.invMgr.inv[ID].active)
				{
					num2 = ID;
				}
			}
			else
			{
				charlie.val[3] = false;
			}
			charlie.val[4] = character.charUpdate.slow > 0f;
			charlie.val[5] = false;
			if (Game1.netSession.IsHost() && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
			{
				charlie.val[5] = !Game1.hud.arcadeIn.active;
			}
			alpha.Write(writer);
			brava.Write(writer);
			charlie.Write(writer);
			if (num2 > -1)
			{
				writer.Write(Game1.gamePlayerMgr.gamePlayer[ID].gold);
				NetPacker.WriteByte(writer, Game1.gamePlayerMgr.gamePlayer[ID].picks);
				Game1.hud.invMgr.inv[num2].NetWrite(writer);
			}
			if (character.charUpdate.warpFrame > 0f)
			{
				NetPacker.WriteTinyFloat(writer, character.charUpdate.warpFrame);
				NetPacker.WriteNormalizedVec2(writer, character.charUpdate.warpVec);
			}
			if (character.charUpdate.dyingFrame > 0f)
			{
				NetPacker.WriteTinyFloat(writer, character.charUpdate.dyingFrame);
			}
			if (character.charUpdate.charGrab.grabbedByChar > -1)
			{
				NetPacker.WriteByte(writer, character.charUpdate.charGrab.grabbedByChar);
			}
			if (character.charUpdate.slow > 0f)
			{
				NetPacker.WriteTinyFloat(writer, character.charUpdate.slow);
			}
			if (character.team == Character.Team.BadGuys)
			{
				if (character.ai == null)
				{
					NetPacker.WriteByte(writer, 0);
					NetPacker.WriteByte(writer, 0);
					NetPacker.WriteByte(writer, 0);
				}
				else
				{
					NetPacker.WriteByte(writer, character.ai.type);
					NetPacker.WriteByte(writer, character.ai.job);
					NetPacker.WriteByte(writer, character.ai.targ);
				}
			}
			if (character.team == Character.Team.GoodGuys)
			{
				NetPacker.WriteTinyFloat(writer, character.charUpdate.magic);
			}
			if (character.charUpdate.locked)
			{
				NetPacker.WriteVec2(writer, character.charUpdate.lockVec);
			}
			if (character.charUpdate.airJuggleFrame > 0f)
			{
				NetPacker.WriteSmallFloat(writer, character.charUpdate.airJuggleFrame);
				NetPacker.WriteVec2(writer, character.charUpdate.airJuggleVec);
			}
		}
	}
}
