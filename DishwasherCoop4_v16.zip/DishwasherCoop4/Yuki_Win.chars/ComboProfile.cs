namespace Yuki_Win.chars;

public class ComboProfile
{
	private CharScript.GotoKey[] history;

	private int inKeyCount;

	private float frame;

	public void Update()
	{
		if (inKeyCount > 0)
		{
			frame -= FMan.frameTime;
			if (frame < 0f)
			{
				inKeyCount--;
				frame = 1f;
			}
		}
	}

	public void DoKey(CharScript.GotoKey inKey)
	{
		for (int num = history.Length - 1; num > 0; num--)
		{
			history[num] = history[num - 1];
		}
		history[0] = inKey;
		frame = 1f;
		if (inKeyCount < history.Length - 1)
		{
			inKeyCount++;
		}
	}

	public ComboProfile()
	{
		history = new CharScript.GotoKey[8];
	}

	public float GetStaleness()
	{
		if (inKeyCount <= 1)
		{
			return 0f;
		}
		float num = 0f;
		for (int i = 0; i < inKeyCount - 1; i++)
		{
			if (history[i] == history[i + 1])
			{
				num += 0.1f;
			}
		}
		return num;
	}
}
