using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Yuki_Win.ai;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.debug;
using Yuki_Win.eightbit;
using Yuki_Win.levels;
using Yuki_Win.maps;
using Yuki_Win.player;

namespace Yuki_Win.chars;

public class CharKeys
{
	public bool keyLeft;

	public bool keyRight;

	public bool keyUp;

	public bool keyDown;

	public bool keyAttack;

	public bool keyStrong;

	public bool keyJump;

	public bool keyGrab;

	public bool keySec;

	public bool keyReload;

	public bool keyShotty;

	public bool keyWalk;

	public bool keyJog;

	public bool keyDLeft;

	public bool keyDRight;

	public bool keyDUp;

	public bool keyDDown;

	public bool IsSawDown;

	public bool keyJumpMagic;

	public bool keyAttackMagic;

	public bool keyGrabMagic;

	public bool keyStrongMagic;

	public Vector2 rVec;

	public int idx;

	private bool queueSwitch;

	public Vector2 shootVec;

	public void ClearKeys()
	{
		keyLeft = false;
		keyRight = false;
		keyUp = false;
		keyDown = false;
		keyDLeft = false;
		keyDRight = false;
		keyDUp = false;
		keyDDown = false;
		keyAttack = false;
		keyStrong = false;
		keyJump = false;
		keyGrab = false;
		keySec = false;
		keyAttackMagic = false;
		keyStrongMagic = false;
		keyGrabMagic = false;
		keyJumpMagic = false;
		keyReload = false;
		keyShotty = false;
		keyWalk = false;
		keyJog = false;
		IsSawDown = false;
		rVec = default;
	}

	public void Update(AI ai, Character[] c, Character me)
	{
		if (me.ID == 0 && ai == null)
		{
			ai = new AI(6, me.ID);
		}
		if ((!Game1.netSession.IsHost() || me.ID != 1) && (!Game1.netSession.IsClient() || me.ID != 0) && (!Game1.netSession.IsClient() || me.ID < 2 || !(me.charUpdate.clientOwned <= 0f)) && (!Game1.netSession.IsHost() || me.ID < 2 || !(me.charUpdate.clientOwned > 0f)))
		{
			ClearKeys();
		}
		CharMeta charMeta = Game1.charMeta[me.charMeta];
		if (me.charUpdate.charGrab.grabbedByChar > -1 && !Game1.hud.IsEndLevel())
		{
			bool flag = false;
			bool flag2 = false;
			if (me.charUpdate.getsExeGrabInput && me.charUpdate.hp < me.charUpdate.mhp / 4f)
			{
				flag = true;
			}
			else if (me.charUpdate.getsAllGrabInput)
			{
				flag = true;
			}
			else if (me.charUpdate.getsExeGrabInput && me.charUpdate.hp > 0f)
			{
				flag2 = true;
			}
			if (Game1.character[me.charUpdate.charGrab.grabbedByChar].charKeys.keyStrong && me.GetMeta().isSawer && me.charAnim.animName == "dueled")
			{
				me.charUpdate.charGrab.duelCount++;
			}
			if (flag || flag2)
			{
				Character character = Game1.character[me.charUpdate.charGrab.grabbedByChar];
				if (flag)
				{
					keyStrong = character.charKeys.keyStrong;
					keyGrab = character.charKeys.keyGrab;
					keySec = character.charKeys.keySec;
					keyAttack = character.charKeys.keyAttack;
					keyJump = character.charKeys.keyJump;
				}
				keyLeft = character.charKeys.keyLeft;
				keyRight = character.charKeys.keyRight;
				keyUp = character.charKeys.keyUp;
				keyDown = character.charKeys.keyDown;
			}
		}
		else if (Game1.transMgr.outFrame > 0f || Game1.gameMap.lockCharMode || (Game1.sceneMgr.playing && Game1.sceneMgr.overlay && Game1.sceneMgr.transInFrame > 0f) || Game1.gameMap.DoorFocus() > -1)
		{
			if (idx > -1 && MainPlayer.uberDyingFrame < 1f && me.charUpdate.dyingFrame <= 0f && Game1.sceneMgr.playing && flibitPort.GetInputClicked(idx, flibitPort.InputAction.JumpAccept))
			{
				keyJump = true;
			}
		}
		else
		{
			if ((Game1.netSession.IsHost() && me.ID == 1) || (Game1.netSession.IsClient() && me.ID == 0))
			{
				return;
			}
			int num = idx;
			if (Game1.netSession.IsClient() && me.ID == 1)
			{
				num = Game1.character[0].charKeys.idx;
			}
			if (num > -1)
			{
				if (DebugManager.netLackeyMode)
				{
					if (ai == null)
					{
						ai = new AI(15, me.ID);
					}
					ai.type = 15;
					ai.Update(c);
					if (flibitPort.GetInputDigital(num, flibitPort.InputAction.PauseConfirm))
					{
						DebugManager.netLackeyMode = false;
					}
				}
				else
				{
					if (!(MainPlayer.uberDyingFrame < 1f) || !(me.charUpdate.dyingFrame <= 0f) || !(Game1.camMgr.bossToast.frame <= 0f) || Game1.gameMap.yukiDeathFocus)
					{
						return;
					}
					Vector2 vector = default;
					Vector2 inputStick = flibitPort.GetInputStick(num, flibitPort.InputAction.Move);
					if (inputStick.X < -0.3f)
					{
						keyLeft = true;
					}
					if (inputStick.X > 0.3f)
					{
						keyRight = true;
					}
					if (inputStick.Y < -0.3f)
					{
						keyDown = true;
					}
					if (inputStick.Y > 0.3f)
					{
						keyUp = true;
					}
					flibitPort.GetInputDPad(num, out keyDUp, out keyDDown, out keyDLeft, out keyDRight);
					if ((flibitPort.GetInputClicked(num, flibitPort.InputAction.PauseConfirm) || Guide.IsVisible || Game1.menuMgr.messageMgr.GetActive()) && DebugManager.playMode != DebugManager.PlayMode.Step && !(MainPlayer.uberDyingFrame >= 1f) && !Game1.sceneMgr.playing && GameState.state == GameState.State.Playing && !Game1.sceneMgr.playing && !Game1.hud.IsArcadeIn() && !Game1.hud.IsEndLevel())
					{
						if (Game1.gameMap.nekoToastyFrame > 0f)
						{
							Game1.gameMap.CurMap().scriptMgr.ClickNekoToasty();
						}
						else
						{
							Game1.menuMgr.Pause(me.ID);
						}
					}
					if (flibitPort.GetInputClicked(num, flibitPort.InputAction.Inventory) && !DebugManager.stepMode && !EightBitGame.enabled && !Game1.hud.PickupsActive() && !Game1.hud.GetIsTutActive() && !Game1.soloMgr.active && !(MainPlayer.uberDyingFrame >= 1f) && !Game1.hud.IsEndLevel() && !Game1.sceneMgr.playing && Game1.IsPlayerChar(me.ID) && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off && Game1.gameMap.theme.theme != Themes.ThemeType.Church && Game1.gameMap.theme.theme != Themes.ThemeType.Asylum && !Game1.hud.shopMgr.shop[me.ID].active)
					{
						Game1.hud.invMgr.Init(me.ID);
					}
					if (flibitPort.GetInputClicked(num, flibitPort.InputAction.Attack))
					{
						keyAttack = true;
					}
					if (flibitPort.GetInputClicked(num, flibitPort.InputAction.StrongSaw))
					{
						keyStrong = true;
					}
					if (flibitPort.GetInputDigital(num, flibitPort.InputAction.StrongSaw))
					{
						IsSawDown = true;
					}
					if (flibitPort.GetInputClicked(num, flibitPort.InputAction.JumpAccept))
					{
						keyJump = true;
					}
					if (flibitPort.GetInputClicked(num, flibitPort.InputAction.GrabCancel))
					{
						keyGrab = true;
					}
					if (Game1.IsPlayerChar(me.ID))
					{
						if (flibitPort.GetInputClicked(num, flibitPort.InputAction.StrongSaw))
						{
							keyShotty = true;
						}
						if (flibitPort.GetInputClicked(num, flibitPort.InputAction.GrabCancel))
						{
							keyReload = true;
						}
						rVec = flibitPort.GetInputStick(num, flibitPort.InputAction.WarpRoll);
						if (vector.X != 0f || vector.Y != 0f)
						{
							rVec = vector;
						}
						if (flibitPort.GetInputAnalog(num, flibitPort.InputAction.Gun) > 0.3f)
						{
							keySec = true;
							shootVec = flibitPort.GetInputAim(num, ScrollManager.GetScreenLoc(me.charUpdate.loc, 0));
						}
						if (flibitPort.GetInputAnalog(num, flibitPort.InputAction.Magic) > 0.3f)
						{
							if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
							{
								if (keyAttack || keyJump || keyGrab || keyStrong)
								{
									switch (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].magic)
									{
									case Level.ArcadeMagic.Electric:
										keyAttackMagic = true;
										break;
									case Level.ArcadeMagic.Steel:
										keyStrongMagic = true;
										break;
									case Level.ArcadeMagic.Devouring:
										keyGrabMagic = true;
										break;
									case Level.ArcadeMagic.Holy:
										keyJumpMagic = true;
										break;
									}
								}
							}
							else
							{
								int num2 = Game1.player.yukiPhase;
								int num3 = Game1.player.dishPhase;
								if (charMeta.isYuki)
								{
									if (num2 >= 6 && Game1.gamePlayerMgr.GamePlayer(me.ID).highestYukiPhase >= 9)
									{
										num2 = Game1.gamePlayerMgr.GamePlayer(me.ID).highestYukiPhase;
									}
								}
								else if (Game1.gamePlayerMgr.GamePlayer(me.ID).highestDishPhase >= 4)
								{
									num3 = Game1.gamePlayerMgr.GamePlayer(me.ID).highestDishPhase;
								}
								if (keyAttack)
								{
									if (charMeta.isDish && num3 >= 4)
									{
										keyAttackMagic = true;
									}
									if (charMeta.isYuki && num2 >= 9)
									{
										keyAttackMagic = true;
									}
								}
								if (keyJump)
								{
									if (charMeta.isDish && num3 >= 10)
									{
										keyJumpMagic = true;
									}
									if (charMeta.isYuki && num2 >= 15)
									{
										keyJumpMagic = true;
									}
								}
								if (keyGrab)
								{
									if (charMeta.isDish && num3 >= 8)
									{
										keyGrabMagic = true;
									}
									if (charMeta.isYuki && num2 >= 13)
									{
										keyGrabMagic = true;
									}
								}
								if (keyStrong)
								{
									if (charMeta.isDish && num3 >= 6)
									{
										keyStrongMagic = true;
									}
									if (charMeta.isYuki && num2 >= 11)
									{
										keyStrongMagic = true;
									}
								}
							}
						}
						if (Game1.hud.shopMgr.shop[me.ID].active)
						{
							rVec = default;
						}
					}
					if ((keyStrong || me.charAnim.charScript.lastKey == CharScript.GotoKey.Saw || me.charAnim.charScript.lastKey == CharScript.GotoKey.SawUpper || me.charAnim.charScript.lastKey == CharScript.GotoKey.SawLower) && (me.charAnim.animName == "cockit" || me.charAnim.animName == "fcockit"))
					{
						keySec = false;
					}
					if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
					{
						if (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].gunMode == Level.GunMode.None)
						{
							keySec = false;
						}
					}
					else
					{
						int num4 = Game1.player.yukiPhase;
						int num5 = Game1.player.dishPhase;
						if (charMeta.isYuki)
						{
							if (num4 >= 6 && Game1.gamePlayerMgr.GamePlayer(me.ID).highestYukiPhase >= 8)
							{
								num4 = Game1.gamePlayerMgr.GamePlayer(me.ID).highestYukiPhase;
							}
						}
						else if (Game1.gamePlayerMgr.GamePlayer(me.ID).highestDishPhase >= 3)
						{
							num5 = Game1.gamePlayerMgr.GamePlayer(me.ID).highestDishPhase;
						}
						if (Game1.levelMgr.currentTrack == 0 && Game1.player.yukiPhase == 0)
						{
							num5 = 1;
						}
						if (charMeta.isYuki)
						{
							if (num4 < 6)
							{
								keyStrong = false;
							}
							if (num4 < 8)
							{
								keySec = false;
							}
						}
						if (charMeta.isDish && num5 < 3)
						{
							keySec = false;
						}
						if (Game1.gameMap.theme.theme == Themes.ThemeType.Asylum)
						{
							keySec = false;
							keyStrong = false;
						}
					}
					if (Game1.IsPlayerChar(me.ID) && (me.charUpdate.parryFrame > 0f || me.charUpdate.borrowed))
					{
						keyAttack = false;
						keyStrong = false;
						keyJump = false;
						keyGrab = false;
						keySec = false;
						keyShotty = false;
						keyAttackMagic = false;
						keyStrongMagic = false;
						keyGrabMagic = false;
						keyJumpMagic = false;
						if (me.charUpdate.borrowed)
						{
							keyLeft = false;
							keyRight = false;
						}
					}
					if (keyAttack)
					{
						if (keyUp)
						{
							me.comboProfile.DoKey(CharScript.GotoKey.Lower);
						}
						else if (keyDown)
						{
							me.comboProfile.DoKey(CharScript.GotoKey.Upper);
						}
						else
						{
							me.comboProfile.DoKey(CharScript.GotoKey.Attack);
						}
					}
					if (keyStrong)
					{
						if (keyUp)
						{
							me.comboProfile.DoKey(CharScript.GotoKey.SawLower);
						}
						else if (keyDown)
						{
							me.comboProfile.DoKey(CharScript.GotoKey.SawUpper);
						}
						else
						{
							me.comboProfile.DoKey(CharScript.GotoKey.Saw);
						}
					}
					if (keyGrab)
					{
						me.comboProfile.DoKey(CharScript.GotoKey.Grab);
					}
					if (Game1.IsPlayerChar(me.ID) && Game1.hud.invMgr.inv[0].alpha <= 0f && Game1.hud.invMgr.inv[1].alpha <= 0f)
					{
						SwitchCheck(charMeta, num, me);
						ParryTick(me);
					}
					if (Game1.gameMap.psychoTVAlpha > 0.1f && !EightBitGame.enabled)
					{
						keyStrong = false;
						keyJump = false;
						rVec = default;
						keyGrab = false;
						keyAttack = false;
						keySec = false;
						keyAttackMagic = false;
						keyJumpMagic = false;
						keyGrabMagic = false;
						keyStrongMagic = false;
					}
				}
			}
			else if (Game1.petPlayerMgr.GetOwned(me.ID))
			{
				Game1.petPlayerMgr.GetPlayer(me.ID).SetCharKeys(me, this);
			}
			else if (Game1.levelMgr.currentTrack != 5 && Game1.levelMgr.currentTrack != 6 && ai.type > -1)
			{
				ai.Update(c);
			}
		}
	}

	private void ClearNonMoveKeys()
	{
		keyDLeft = false;
		keyDRight = false;
		keyDUp = false;
		keyDDown = false;
		keyAttack = false;
		keyStrong = false;
		keyJump = false;
		keyGrab = false;
		keySec = false;
		keyAttackMagic = false;
		keyStrongMagic = false;
		keyGrabMagic = false;
		keyJumpMagic = false;
		keyReload = false;
		keyShotty = false;
		keyWalk = false;
		keyJog = false;
		IsSawDown = false;
		rVec = default;
	}

	// Parry: R1 (sem segurar para baixo). Para trocar de arma: segure para baixo + R1.
	private bool TryStartParry(Character me)
	{
		CharUpdate u = me.charUpdate;
		if (u.state != CharUpdate.State.Grounded || u.hp < 0f || u.charGrab.grabbedByChar > -1)
		{
			return false;
		}
		if (u.parryFrame > 0f || u.parryCool > 0f)
		{
			return true;
		}
		u.parryFrame = Game1.parryWindow;
		u.parryCool = Game1.parryCooldown;
		u.traj.X = 0f;
		PlayParryPose(me);
		Sound.PlaySnd(Sound.Category.FX, "click1");
		return true;
	}

	// Pose do parry: usa a animacao "parry" se existir; senao a animacao de troca de arma do personagem
	// (a mesma da troca de katana/arma); senao fica parado.
	public static void PlayParryPose(Character me)
	{
		CharUpdate u = me.charUpdate;
		string pose = null;
		if (me.charAnim.CheckAnim("parry") > -1)
		{
			pose = "parry";
		}
		else if (!me.GetMeta().isDish && BorrowDishAnim(me, Game1.charMeta[Game1.borrowDishMeta].switch_anim, Game1.parryWindow + 0.1f))
		{
			return;
		}
		else
		{
			string sw = me.GetMeta().switch_anim;
			if (sw != null && me.charAnim.CheckAnim(sw) > -1)
			{
				pose = sw;
			}
		}
		if (pose == null)
		{
			me.charAnim.SetAnim("idle", u, overRide: true);
		}
		else
		{
			me.charAnim.SetAnim(pose, u, overRide: true);
		}
	}

	// true se o charDef do Dishwasher tem uma animacao com esse nome
	private static bool DishAnimExists(string name)
	{
		if (name == null || Game1.charDef[Game1.borrowDishDef] == null)
		{
			return false;
		}
		var arr = Game1.charDef[Game1.borrowDishDef].GetAnimationArray();
		for (int i = 0; i < arr.Length; i++)
		{
			if (arr[i] != null && arr[i].name == name)
			{
				return true;
			}
		}
		return false;
	}

	// Troca temporariamente o modelo do personagem pelo do Dishwasher (katana) e toca a animacao dele
	public static bool BorrowDishAnim(Character me, string name, float maxTime)
	{
		CharUpdate u = me.charUpdate;
		if (!DishAnimExists(name))
		{
			return false;
		}
		if (!u.borrowed)
		{
			u.borrowDef = me.cDef;
			u.borrowMeta = me.charMeta;
			u.borrowed = true;
		}
		me.cDef = Game1.borrowDishDef;
		me.charAnim.charDef = Game1.borrowDishDef;
		me.charMeta = Game1.borrowDishMeta;
		me.charAnim.charMeta = Game1.borrowDishMeta;
		u.borrowAnim = name;
		u.borrowTime = maxTime;
		me.charAnim.SetAnim(name, u, overRide: true);
		return true;
	}

	// Devolve o modelo original do personagem
	public static void EndBorrow(Character me)
	{
		CharUpdate u = me.charUpdate;
		if (!u.borrowed)
		{
			return;
		}
		string cur = me.charAnim.animName;
		string borrowedAnim = u.borrowAnim;
		u.borrowed = false;
		u.borrowAnim = null;
		me.cDef = u.borrowDef;
		me.charAnim.charDef = u.borrowDef;
		me.charMeta = u.borrowMeta;
		me.charAnim.charMeta = u.borrowMeta;
		if (cur != null && cur != borrowedAnim && u.hp >= 0f && me.charAnim.CheckAnim(cur) > -1)
		{
			me.charAnim.SetAnim(cur, u, overRide: true);
		}
		else
		{
			me.charAnim.SetAnim("idle", u, overRide: true);
		}
	}

	// Esquiva: rolamento do Dishwasher. Dishwashers usam o proprio; os outros emprestam o do Dishwasher.
	private bool TryDodge(Character me)
	{
		CharUpdate u = me.charUpdate;
		if (u.state != CharUpdate.State.Grounded || u.hp < 0f || u.charGrab.grabbedByChar > -1 || u.dodgeCool > 0f || u.borrowed || u.parryFrame > 0f)
		{
			return false;
		}
		CharMeta meta = me.GetMeta();
		if (keyLeft && !keyRight)
		{
			u.face = 0;
		}
		else if (keyRight && !keyLeft)
		{
			u.face = 1;
		}
		bool ok;
		if (meta.isDish && me.charAnim.CheckAnim(meta.roll_anim) > -1)
		{
			me.charAnim.SetAnim(meta.roll_anim, u, overRide: true);
			ok = true;
		}
		else
		{
			ok = BorrowDishAnim(me, Game1.charMeta[Game1.borrowDishMeta].roll_anim, Game1.dodgeBorrowTime);
		}
		if (!ok)
		{
			return false;
		}
		u.ethereal = true;
		if (u.etherealFrame < Game1.dodgeIFrames)
		{
			u.etherealFrame = Game1.dodgeIFrames;
		}
		u.dodgeCool = Game1.dodgeCooldown;
		Sound.PlaySnd(Sound.Category.FX, "swing");
		return true;
	}

	private void ParryTick(Character me)
	{
		CharUpdate u = me.charUpdate;
		if (u.dodgeCool > 0f)
		{
			u.dodgeCool -= FMan.frameTime;
		}
		if (u.dodgeTap > 0f)
		{
			u.dodgeTap -= FMan.frameTime;
		}
		if (u.borrowed)
		{
			CharMeta dm = Game1.charMeta[Game1.borrowDishMeta];
			u.borrowTime -= FMan.frameTime;
			string an = me.charAnim.animName;
			if (me.cDef != Game1.borrowDishDef)
			{
				u.borrowed = false;
			}
			else if (u.borrowTime <= 0f || u.hp < 0f || an == dm.idle_anim || an == dm.idlet_anim || an == dm.run_anim)
			{
				EndBorrow(me);
			}
		}
		if (u.parryCool > 0f)
		{
			u.parryCool -= FMan.frameTime;
		}
		if (u.parryFlash > 0f)
		{
			u.parryFlash -= FMan.frameTime;
		}
		if (u.parryFrame <= 0f)
		{
			return;
		}
		u.parryFrame -= FMan.frameTime;
		if (u.hp < 0f || u.state != CharUpdate.State.Grounded)
		{
			u.parryFrame = 0f;
			return;
		}
		keyLeft = false;
		keyRight = false;
		keyAttack = false;
		keyStrong = false;
		keyJump = false;
		keyGrab = false;
		keySec = false;
		keyShotty = false;
		keyAttackMagic = false;
		keyStrongMagic = false;
		keyGrabMagic = false;
		keyJumpMagic = false;
		rVec = default;
	}

	private void SwitchCheck(CharMeta charMeta, int tIdx, Character me)
	{
		SwitchCheck(charMeta, tIdx, me, force: false);
	}

	public void SwitchCheck(CharMeta charMeta, int tIdx, Character me, bool force)
	{
		InvCatalog.InvItemName invItemName = Game1.gamePlayerMgr.GamePlayer(me.ID).loadOut[me.loadOut].weapon[me.weapIdx];
		if (Game1.soloMgr.active || Game1.sceneMgr.playing || Game1.gameMap.theme.theme == Themes.ThemeType.Escape || Game1.gameMap.theme.theme == Themes.ThemeType.EscapeOut)
		{
			return;
		}
		bool flag = false;
		bool flag2 = false;
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off)
		{
			if (Game1.levelMgr.currentTrack == 0)
			{
				switch (Game1.player.yukiPhase)
				{
				case 0:
					flag = true;
					break;
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
					flag = true;
					flag2 = true;
					break;
				default:
					if (Game1.gamePlayerMgr.GamePlayer(me.ID).highestYukiPhase < 7)
					{
						flag2 = true;
						flag = true;
					}
					break;
				}
			}
		}
		else if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.gamePlayerMgr.gamePlayer[me.ID].loadOut[0].weapon[1] == InvCatalog.InvItemName.None)
		{
			flag2 = true;
		}
		if (!force && !queueSwitch && Game1.parryEnabled && !keyDown && Game1.IsPlayerChar(me.ID) && flibitPort.GetInputClicked(tIdx, flibitPort.InputAction.SwitchWeapons) && TryStartParry(me))
		{
		}
		else if (!force && (queueSwitch || flibitPort.GetInputClicked(tIdx, flibitPort.InputAction.SwitchWeapons)))
		{
			_ = Game1.gamePlayerMgr.GamePlayer(me.ID).loadOut[me.loadOut].weapon[1 - me.weapIdx];
			if (!flag2)
			{
				me.weapIdx = 1 - me.weapIdx;
				Game1.hud.playerHUD[me.ID].SwitchWeaps();
			}
		}
		if (!force && Game1.dodgeEnabled && Game1.IsPlayerChar(me.ID) && !keyDown && flibitPort.GetInputClicked(tIdx, flibitPort.InputAction.SwitchLoadouts))
		{
			if (me.charUpdate.dodgeTap > 0f)
			{
				me.charUpdate.dodgeTap = 0f;
				TryDodge(me);
			}
			else
			{
				me.charUpdate.dodgeTap = Game1.dodgeDoubleTap;
			}
		}
		if (!force && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off && !flag && flibitPort.GetInputClicked(tIdx, flibitPort.InputAction.SwitchLoadouts) && (!Game1.dodgeEnabled || !Game1.IsPlayerChar(me.ID) || keyDown))
		{
			me.loadOut = 1 - me.loadOut;
			Game1.hud.playerHUD[me.ID].SwitchLoadouts();
			Sound.PlaySnd(Sound.Category.FX, "click1");
		}
		InvCatalog.InvItemName invItemName2 = Game1.gamePlayerMgr.GamePlayer(me.ID).loadOut[me.loadOut].weapon[me.weapIdx];
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.HotPotato)
		{
			if (Game1.arcade.hotPotatoFrame[me.ID, 0] > 10f)
			{
				me.weapIdx = 1 - me.weapIdx;
				Game1.hud.playerHUD[me.ID].SwitchWeaps();
				invItemName2 = Game1.gamePlayerMgr.GamePlayer(me.ID).loadOut[me.loadOut].weapon[me.weapIdx];
			}
			if (invItemName2 != invItemName)
			{
				float num = Game1.arcade.hotPotatoFrame[me.ID, 0];
				Game1.arcade.hotPotatoFrame[me.ID, 0] = Game1.arcade.hotPotatoFrame[me.ID, 1];
				Game1.arcade.hotPotatoFrame[me.ID, 1] = num;
			}
		}
		if (invItemName2 == invItemName && !force)
		{
			return;
		}
		if (charMeta.isHatless)
		{
			switch (invItemName2)
			{
			case InvCatalog.InvItemName.ShiftBlade:
				me.charMeta = (me.charAnim.charMeta = 92);
				break;
			case InvCatalog.InvItemName.MeatCleavers:
				me.charMeta = (me.charAnim.charMeta = 93);
				break;
			}
		}
		else if (charMeta.isMara)
		{
			switch (invItemName2)
			{
			case InvCatalog.InvItemName.Conviction:
				me.charMeta = (me.charAnim.charMeta = 37);
				break;
			case InvCatalog.InvItemName.CloudSword:
				me.charMeta = (me.charAnim.charMeta = 39);
				break;
			case InvCatalog.InvItemName.Kamakazi:
				me.charMeta = (me.charAnim.charMeta = 38);
				break;
			case InvCatalog.InvItemName.Painkiller:
				me.charMeta = (me.charAnim.charMeta = 76);
				break;
			case InvCatalog.InvItemName.Claws:
				me.charMeta = (me.charAnim.charMeta = 79);
				break;
			}
		}
		else if (charMeta.isYuki)
		{
			switch (invItemName2)
			{
			case InvCatalog.InvItemName.Conviction:
				me.charMeta = (me.charAnim.charMeta = 0);
				break;
			case InvCatalog.InvItemName.CloudSword:
				me.charMeta = (me.charAnim.charMeta = 25);
				break;
			case InvCatalog.InvItemName.Kamakazi:
				me.charMeta = (me.charAnim.charMeta = 2);
				break;
			case InvCatalog.InvItemName.Painkiller:
				me.charMeta = (me.charAnim.charMeta = 46);
				break;
			case InvCatalog.InvItemName.Claws:
				me.charMeta = (me.charAnim.charMeta = 78);
				break;
			}
		}
		else if (charMeta.isHargreaves)
		{
			switch (invItemName2)
			{
			case InvCatalog.InvItemName.ShiftBlade:
				me.charMeta = (me.charAnim.charMeta = 32);
				break;
			case InvCatalog.InvItemName.MeatCleavers:
				me.charMeta = (me.charAnim.charMeta = 34);
				break;
			case InvCatalog.InvItemName.ViolenceHammer:
				me.charMeta = (me.charAnim.charMeta = 33);
				break;
			case InvCatalog.InvItemName.TheGuillotine:
				me.charMeta = (me.charAnim.charMeta = 35);
				break;
			case InvCatalog.InvItemName.Dekkentozter:
				me.charMeta = (me.charAnim.charMeta = 36);
				break;
			}
		}
		else if (charMeta.isLoic)
		{
			switch (invItemName2)
			{
			case InvCatalog.InvItemName.ShiftBlade:
				me.charMeta = (me.charAnim.charMeta = 27);
				break;
			case InvCatalog.InvItemName.MeatCleavers:
				me.charMeta = (me.charAnim.charMeta = 29);
				break;
			case InvCatalog.InvItemName.ViolenceHammer:
				me.charMeta = (me.charAnim.charMeta = 28);
				break;
			case InvCatalog.InvItemName.TheGuillotine:
				me.charMeta = (me.charAnim.charMeta = 30);
				break;
			case InvCatalog.InvItemName.Dekkentozter:
				me.charMeta = (me.charAnim.charMeta = 31);
				break;
			}
		}
		else if (charMeta.isDish)
		{
			switch (invItemName2)
			{
			case InvCatalog.InvItemName.ShiftBlade:
				me.charMeta = (me.charAnim.charMeta = 5);
				break;
			case InvCatalog.InvItemName.MeatCleavers:
				me.charMeta = (me.charAnim.charMeta = 16);
				break;
			case InvCatalog.InvItemName.ViolenceHammer:
				me.charMeta = (me.charAnim.charMeta = 15);
				break;
			case InvCatalog.InvItemName.TheGuillotine:
				me.charMeta = (me.charAnim.charMeta = 24);
				break;
			case InvCatalog.InvItemName.Dekkentozter:
				me.charMeta = (me.charAnim.charMeta = 26);
				break;
			}
		}
		charMeta = me.GetMeta();
		me.charUpdate.weaponStain = 0f;
		if (me.charUpdate.state == CharUpdate.State.Grounded)
		{
			me.charAnim.SetAnim(charMeta.switch_anim, me.charUpdate);
		}
		else
		{
			me.charAnim.SetAnim(charMeta.fswitch_anim, me.charUpdate);
		}
	}
}
