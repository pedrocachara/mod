using System;
using System.IO;
using Yuki_Win.chars.charMeta;

namespace Yuki_Win.chars;

public class CharMeta
{
	public const int None = -1;

	public const int Yuki_Katana = 0;

	public const int Guard = 1;

	public const int Yuki_Kama = 2;

	public const int Swat = 3;

	public const int Tank = 4;

	public const int Dish = 5;

	public const int Blade = 6;

	public const int Neko = 7;

	public const int Gown_Crawl = 8;

	public const int Gown_Chair = 9;

	public const int Gown_Walk = 10;

	public const int Prison = 11;

	public const int Chaironly = 12;

	public const int Pod = 13;

	public const int Ninja = 14;

	public const int Dish_Hammer = 15;

	public const int Dish_Cleaver = 16;

	public const int Zombie = 17;

	public const int Crow = 18;

	public const int Cretin = 19;

	public const int Warden = 20;

	public const int Lich = 21;

	public const int Gown_Arm = 22;

	public const int Goreface = 23;

	public const int Dish_Scissor = 24;

	public const int Yuki_Cloud = 25;

	public const int Dish_Toaster = 26;

	public const int Loic_Katana = 27;

	public const int Loic_Hammer = 28;

	public const int Loic_Cleaver = 29;

	public const int Loic_Scissors = 30;

	public const int Loic_Toaster = 31;

	public const int Hargreaves_Katana = 32;

	public const int Hargreaves_Hammer = 33;

	public const int Hargreaves_Cleaver = 34;

	public const int Hargreaves_Scissors = 35;

	public const int Hargreaves_Toaster = 36;

	public const int Mara_Katana = 37;

	public const int Mara_Kama = 38;

	public const int Mara_Cloud = 39;

	public const int Apple2 = 40;

	public const int PodBot = 41;

	public const int Slava = 42;

	public const int Pumpkinhead = 43;

	public const int Skeletank = 44;

	public const int Banker = 45;

	public const int Yuki_Syringe = 46;

	public const int Force = 47;

	public const int Box = 48;

	public const int Murderfly = 49;

	public const int Warclone = 50;

	public const int Pyro = 51;

	public const int General = 52;

	public const int Goon = 53;

	public const int Freak = 54;

	public const int Hockey = 55;

	public const int Ghost = 56;

	public const int Mook = 57;

	public const int Shark = 58;

	public const int Dragon = 59;

	public const int DragonClaw = 60;

	public const int SackBoy = 61;

	public const int Invalid = 62;

	public const int Shop = 63;

	public const int Samurai = 64;

	public const int SquidFace = 65;

	public const int Corpse = 66;

	public const int Judge = 67;

	public const int Engineer = 68;

	public const int GoonPuppet = 69;

	public const int SwatPuppet = 70;

	public const int BigEngie = 71;

	public const int Horse = 72;

	public const int Engie2 = 73;

	public const int MidEngie = 74;

	public const int Murderbug = 75;

	public const int Mara_Syringe = 76;

	public const int Ghoul = 77;

	public const int Yuki_Claws = 78;

	public const int Mara_Claws = 79;

	public const int Swordsman = 80;

	public const int Thug = 81;

	public const int Hackbot = 82;

	public const int Chef = 83;

	public const int KnifeOnly = 84;

	public const int Gown_Hobble = 85;

	public const int Gown_Knife = 86;

	public const int USlava = 87;

	public const int Raven = 88;

	public const int Transmara = 89;

	public const int Hypno = 90;

	public const int YukiNPC = 91;

	public const int Dish_Hatless = 92;

	public const int Dishc_Hatless = 93;

	public const int Assassin = 94;

	public const int GUITAR = 95;

	public const int VIOLIN = 96;

	public const int PREDATOR = 97;

	public const int RAPTOR = 98;

	public const int INMATE = 99;

	public const int SPARKS_FULL = 2;

	public const int SPARKS_CYBLOOD = 1;

	public const int SPARKS_BLOOD = 0;

	public const int SPARKS_NULL = 3;

	public float mHP;

	public float speed;

	public float jump;

	public float damage = 1f;

	public string name = "";

	public string suicide_anim = "";

	public bool isThermop;

	public string fly_anim = "fly";

	public string idle_anim = "idle";

	public string run_anim = "run";

	public string runend_anim = "runend";

	public string runstart_anim = "runstart";

	public string jump_anim = "jump";

	public string idlet_anim = "idlet";

	public string land_anim = "land";

	public string fatk_anim = "fatk";

	public string hit_anim = "hit";

	public string grab_anim = "grab";

	public string attack_anim = "attack";

	public string strong_anim = "strong";

	public string secondary_anim = "sec";

	public string strong_kill_anim = "strongkill";

	public string strong_kill2_anim = "strongkill";

	public string wall_anim = "wall";

	public string wall_jump_anim = "walljump";

	public string wall_run_anim = "wallrun";

	public string flip_anim = "flip";

	public string wall_flip_anim = "wallflip";

	public string wall_slide_anim = "wallslide";

	public string wall_slam_anim = "wallslam";

	public string fstrong_anim = "fstrong";

	public string jgrab_anim = "jgrab";

	public string dying_anim = "dying";

	public string block_anim = "block";

	public string katgrabbed_anim = "katgrabbed";

	public string kamgrabbed_anim = "kamgrabbed";

	public string exer_anim = "exer";

	public string walk_anim = "walk";

	public string jog_anim = "jog";

	public string ceilrun_anim = "ceilrun";

	public string ceildrop_anim = "ceildrop";

	public string wallatk_anim = "wallatk";

	public string ceilatk_anim = "ceilatk";

	public string turn_anim = "turn";

	public string altturn_anim = "turn";

	public string spawn_anim = "spawn";

	public string jkatgrabbed_anim = "jkatgrabbed";

	public string jkamgrabbed_anim = "jkamgrabbed";

	public string roll_anim = "roll";

	public string lock_anim = "lock";

	public string lockdie_anim = "lockdie";

	public string altRunStart_anim = "runstart";

	public int heightMinus;

	public bool altdefault;

	public string dishgrabbed_anim = "dishgrabbed";

	public string dishbladegrabbed_anim = "dishgrabbed";

	public string dishkamagrabbed_anim = "dishgrabbed";

	public string dishsawgrabbed_anim = "dishgrabbed";

	public string dishhammergrabbed_anim = "dishgrabbed";

	public string dishhold2grabbed_anim = "dishgrabbed";

	public string switch_anim = "switch";

	public string fswitch_anim = "fswitch";

	public string inactive_anim = "inactive";

	public string groundsplode_anim = "groundsplode";

	public string groundsmashsplode_anim = "groundsplode";

	public string dishwalled_anim = "dishwalled";

	public string yukiwalled_anim = "yukiwalled";

	public string vampslammed_anim = "vampslammed";

	public string wall_land_anim = "wallland";

	public string dishslammed_anim = "dishslammed";

	public string activate_anim = "activate";

	public string hitland_anim = "hitland";

	public string exe_anim = "exe";

	public string painsnd = "";

	public string diesnd = "";

	public string jabsnd = "";

	public string fiercesnd = "";

	public string laughsnd = "";

	public string growlsnd = "";

	public string screamsnd = "";

	public string launch_anim = "launch";

	public string fturn_anim = "fturn";

	public string hover_anim = "hover";

	public string takeoff_anim = "takeoff";

	public string flight_anim = "flight";

	public string warp_anim = "warp";

	public int widthbuffer;

	public int mapWidthBuffer;

	public int mapHeightBuffer;

	public bool isunaware;

	public bool nogroundzombie;

	public bool nomusic;

	public bool nobossmusic;

	public bool inactiveFaceCenter;

	public bool isMagicSponge;

	public bool isTVCrazy;

	public bool isPuppet;

	public bool isDragon;

	public bool isRobot;

	public bool isZombie;

	public bool isGhost;

	public bool isBoss;

	public bool isBlocker;

	public bool isHeavy;

	public bool isGiant;

	public bool isCyborg;

	public bool isNeko;

	public bool alwaysRight;

	public bool isChair;

	public bool isCrow;

	public bool isKnife;

	public bool isJuggernaut;

	public bool isRoller;

	public bool isLoic;

	public bool isHargreaves;

	public bool isMara;

	public bool isPumpkin;

	public bool isJuicyRobot;

	public bool isMetalLegs;

	public bool isNoLegs;

	public bool isQuickGrabbable;

	public bool isInnerRect;

	public bool isBreaker;

	public bool isBox;

	public bool isForce;

	public bool isGlowyBlue;

	public float fakeCeiling = -1f;

	public float fakeTop = -1f;

	public int headTex;

	public int torsoTex;

	public int legsTex;

	public int weapTex;

	public float introyadd;

	public bool isYuki;

	public bool isDish;

	public bool isstopbeforeattack;

	public bool autoGroundSplode;

	public bool issmallblood;

	public bool turnexetograb;

	public bool isFlyingLanding;

	public bool isInvalid;

	public bool isShop;

	public bool isPuppeteer;

	public bool burnentry;

	public bool isfists;

	public bool isfriendly;

	public bool isHatless;

	public bool warpcleavers;

	public bool warphammer;

	public bool warpscissors;

	public bool isGuitar;

	public bool isViolin;

	public bool greenEyes;

	public bool blueEyes;

	public bool redEyes;

	public bool isKatana;

	public bool isKama;

	public bool isCloud;

	public bool isSyringe;

	public bool ishypno;

	public bool isCleaver;

	public bool isHammer;

	public bool isScissors;

	public bool isToaster;

	public bool isSpeeder;

	public bool isBigSpeeder;

	public bool isSawer;

	public bool isNoGold;

	public int special;

	public string toast1;

	public string toast2;

	public int GetSpark()
	{
		if (isRobot || isJuicyRobot)
		{
			return 2;
		}
		if (isCyborg)
		{
			return 1;
		}
		return 0;
	}

	private void DoCommand(int idx, string p)
	{
		switch ((CharMetaCommands.Command)idx)
		{
		case CharMetaCommands.Command.speeder:
			isSpeeder = true;
			break;
		case CharMetaCommands.Command.bigspeeder:
			isBigSpeeder = true;
			break;
		case CharMetaCommands.Command.nogold:
			isNoGold = true;
			break;
		case CharMetaCommands.Command.speed:
			speed = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.mhp:
			mHP = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.jump:
			jump = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.fatk_anim:
			fatk_anim = p;
			break;
		case CharMetaCommands.Command.hit_anim:
			hit_anim = p;
			break;
		case CharMetaCommands.Command.name:
			name = p;
			break;
		case CharMetaCommands.Command.fly_anim:
			fly_anim = p;
			break;
		case CharMetaCommands.Command.idle_anim:
			idle_anim = p;
			break;
		case CharMetaCommands.Command.jump_anim:
			jump_anim = p;
			break;
		case CharMetaCommands.Command.isinnerrect:
			isInnerRect = true;
			break;
		case CharMetaCommands.Command.run_anim:
			run_anim = p;
			break;
		case CharMetaCommands.Command.walk_anim:
			walk_anim = p;
			break;
		case CharMetaCommands.Command.jog_anim:
			jog_anim = p;
			break;
		case CharMetaCommands.Command.runend_anim:
			runend_anim = p;
			break;
		case CharMetaCommands.Command.lock_anim:
			lock_anim = p;
			break;
		case CharMetaCommands.Command.lockdie_anim:
			lockdie_anim = p;
			break;
		case CharMetaCommands.Command.runstart_anim:
			runstart_anim = p;
			break;
		case CharMetaCommands.Command.idlet_anim:
			idlet_anim = p;
			break;
		case CharMetaCommands.Command.altturn_anim:
			altturn_anim = p;
			break;
		case CharMetaCommands.Command.land_anim:
			land_anim = p;
			break;
		case CharMetaCommands.Command.grab_anim:
			grab_anim = p;
			break;
		case CharMetaCommands.Command.jgrab_anim:
			jgrab_anim = p;
			break;
		case CharMetaCommands.Command.attack_anim:
			attack_anim = p;
			break;
		case CharMetaCommands.Command.strong_anim:
			strong_anim = p;
			break;
		case CharMetaCommands.Command.secondary_anim:
			secondary_anim = p;
			break;
		case CharMetaCommands.Command.turn_anim:
			turn_anim = p;
			break;
		case CharMetaCommands.Command.switch_anim:
			switch_anim = p;
			break;
		case CharMetaCommands.Command.fswitch_anim:
			fswitch_anim = p;
			break;
		case CharMetaCommands.Command.groundsplode_anim:
			groundsplode_anim = p;
			break;
		case CharMetaCommands.Command.nobossmusic:
			nobossmusic = true;
			break;
		case CharMetaCommands.Command.dishwalled_anim:
			dishwalled_anim = p;
			break;
		case CharMetaCommands.Command.yukiwalled_anim:
			yukiwalled_anim = p;
			break;
		case CharMetaCommands.Command.hitland_anim:
			hitland_anim = p;
			break;
		case CharMetaCommands.Command.vampslammed_anim:
			vampslammed_anim = p;
			break;
		case CharMetaCommands.Command.dishslammed_anim:
			dishslammed_anim = p;
			break;
		case CharMetaCommands.Command.strong_kill_anim:
			strong_kill_anim = p;
			break;
		case CharMetaCommands.Command.strong_kill2_anim:
			strong_kill2_anim = p;
			break;
		case CharMetaCommands.Command.block_anim:
			block_anim = p;
			break;
		case CharMetaCommands.Command.warpscissors:
			warpscissors = true;
			warp_anim = "warps";
			break;
		case CharMetaCommands.Command.warphammer:
			warphammer = true;
			warp_anim = "warph";
			break;
		case CharMetaCommands.Command.warpcleavers:
			warpcleavers = true;
			warp_anim = "warpc";
			break;
		case CharMetaCommands.Command.wall_anim:
			wall_anim = p;
			break;
		case CharMetaCommands.Command.wall_jump_anim:
			wall_jump_anim = p;
			break;
		case CharMetaCommands.Command.exer_anim:
			exer_anim = p;
			break;
		case CharMetaCommands.Command.wall_run_anim:
			wall_run_anim = p;
			break;
		case CharMetaCommands.Command.flip_anim:
			flip_anim = p;
			break;
		case CharMetaCommands.Command.wall_flip_anim:
			wall_flip_anim = p;
			break;
		case CharMetaCommands.Command.wall_slide_anim:
			wall_slide_anim = p;
			break;
		case CharMetaCommands.Command.wall_land_anim:
			wall_land_anim = p;
			break;
		case CharMetaCommands.Command.isunaware:
			isunaware = true;
			break;
		case CharMetaCommands.Command.wall_slam_anim:
			wall_slam_anim = p;
			break;
		case CharMetaCommands.Command.fstrong_anim:
			fstrong_anim = p;
			break;
		case CharMetaCommands.Command.special:
			switch (p)
			{
			case "katana":
				special = 1;
				break;
			case "kama":
				special = 2;
				break;
			case "cloud":
				special = 3;
				break;
			case "other":
				special = 4;
				break;
			case "fists":
				special = 5;
				break;
			}
			break;
		case CharMetaCommands.Command.fturn_anim:
			fturn_anim = p;
			break;
		case CharMetaCommands.Command.isfriendly:
			isfriendly = true;
			break;
		case CharMetaCommands.Command.isknife:
			isKnife = true;
			break;
		case CharMetaCommands.Command.activate_anim:
			activate_anim = p;
			break;
		case CharMetaCommands.Command.suicide_anim:
			suicide_anim = p;
			break;
		case CharMetaCommands.Command.head_tex:
			headTex = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.torso_tex:
			torsoTex = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.legs_tex:
			legsTex = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.weap_tex:
			weapTex = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.widthbuffer:
			widthbuffer = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.fakeceiling:
			fakeCeiling = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.faketop:
			fakeTop = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.mapwidthbuffer:
			mapWidthBuffer = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.mapheightbuffer:
			mapHeightBuffer = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.isflyinglanding:
			isFlyingLanding = true;
			break;
		case CharMetaCommands.Command.ispuppeteer:
			isPuppeteer = true;
			break;
		case CharMetaCommands.Command.dying_anim:
			dying_anim = p;
			break;
		case CharMetaCommands.Command.isrobot:
			isRobot = true;
			break;
		case CharMetaCommands.Command.iszombie:
			isZombie = true;
			break;
		case CharMetaCommands.Command.isdragon:
			isDragon = true;
			break;
		case CharMetaCommands.Command.ispuppet:
			isPuppet = true;
			break;
		case CharMetaCommands.Command.isghost:
			isGhost = true;
			break;
		case CharMetaCommands.Command.isboss:
			isBoss = true;
			isMagicSponge = true;
			break;
		case CharMetaCommands.Command.ismetallegs:
			isMetalLegs = true;
			break;
		case CharMetaCommands.Command.isquickgrabbable:
			isQuickGrabbable = true;
			break;
		case CharMetaCommands.Command.isnolegs:
			isNoLegs = true;
			break;
		case CharMetaCommands.Command.isblocker:
			isBlocker = true;
			break;
		case CharMetaCommands.Command.isjuggernaut:
			isJuggernaut = true;
			break;
		case CharMetaCommands.Command.iscyborg:
			isCyborg = true;
			break;
		case CharMetaCommands.Command.alwaysright:
			alwaysRight = true;
			break;
		case CharMetaCommands.Command.isRoller:
			isRoller = true;
			break;
		case CharMetaCommands.Command.ispumpkin:
			isPumpkin = true;
			break;
		case CharMetaCommands.Command.isGuitar:
			isGuitar = true;
			break;
		case CharMetaCommands.Command.isViolin:
			isViolin = true;
			break;
		case CharMetaCommands.Command.isThermop:
			isThermop = true;
			break;
		case CharMetaCommands.Command.isNeko:
			isNeko = true;
			break;
		case CharMetaCommands.Command.isCrow:
			isCrow = true;
			break;
		case CharMetaCommands.Command.isheavy:
			isHeavy = true;
			break;
		case CharMetaCommands.Command.isgiant:
			isGiant = true;
			isJuggernaut = true;
			break;
		case CharMetaCommands.Command.kamgrabbed_anim:
			kamgrabbed_anim = p;
			break;
		case CharMetaCommands.Command.katgrabbed_anim:
			katgrabbed_anim = p;
			break;
		case CharMetaCommands.Command.jkamgrabbed_anim:
			jkamgrabbed_anim = p;
			break;
		case CharMetaCommands.Command.jkatgrabbed_anim:
			jkatgrabbed_anim = p;
			break;
		case CharMetaCommands.Command.ceilrun_anim:
			ceilrun_anim = p;
			break;
		case CharMetaCommands.Command.ceildrop_anim:
			ceildrop_anim = p;
			break;
		case CharMetaCommands.Command.wallatk_anim:
			wallatk_anim = p;
			break;
		case CharMetaCommands.Command.ceilatk_anim:
			ceilatk_anim = p;
			break;
		case CharMetaCommands.Command.ischair:
			isChair = true;
			break;
		case CharMetaCommands.Command.isyuki:
			isYuki = true;
			break;
		case CharMetaCommands.Command.isdish:
			isDish = true;
			break;
		case CharMetaCommands.Command.ismara:
			isMara = true;
			break;
		case CharMetaCommands.Command.ishargreaves:
			isHargreaves = true;
			break;
		case CharMetaCommands.Command.isloic:
			isLoic = true;
			break;
		case CharMetaCommands.Command.isjuicyrobot:
			isJuicyRobot = true;
			break;
		case CharMetaCommands.Command.spawn_anim:
			spawn_anim = p;
			break;
		case CharMetaCommands.Command.autogroundsplode:
			autoGroundSplode = true;
			break;
		case CharMetaCommands.Command.damage:
			damage = (float)Convert.ToInt32(p) / 100f;
			break;
		case CharMetaCommands.Command.roll_anim:
			roll_anim = p;
			break;
		case CharMetaCommands.Command.isstopbeforeattack:
			isstopbeforeattack = true;
			break;
		case CharMetaCommands.Command.issmallblood:
			issmallblood = true;
			break;
		case CharMetaCommands.Command.dishgrabbed_anim:
			dishgrabbed_anim = p;
			break;
		case CharMetaCommands.Command.dishbladegrabbed_anim:
			dishbladegrabbed_anim = p;
			break;
		case CharMetaCommands.Command.dishkamagrabbed_anim:
			dishkamagrabbed_anim = p;
			break;
		case CharMetaCommands.Command.dishsawgrabbed_anim:
			dishsawgrabbed_anim = p;
			break;
		case CharMetaCommands.Command.dishhammergrabbed_anim:
			dishhammergrabbed_anim = p;
			break;
		case CharMetaCommands.Command.dishhold2grabbed_anim:
			dishhold2grabbed_anim = p;
			break;
		case CharMetaCommands.Command.altrunstart_anim:
			altRunStart_anim = p;
			break;
		case CharMetaCommands.Command.painsnd:
			painsnd = p;
			break;
		case CharMetaCommands.Command.greeneyes:
			greenEyes = true;
			break;
		case CharMetaCommands.Command.redeyes:
			redEyes = true;
			break;
		case CharMetaCommands.Command.ishypno:
			ishypno = true;
			break;
		case CharMetaCommands.Command.blueeyes:
			blueEyes = true;
			break;
		case CharMetaCommands.Command.diesnd:
			diesnd = p;
			break;
		case CharMetaCommands.Command.fiercesnd:
			fiercesnd = p;
			break;
		case CharMetaCommands.Command.jabsnd:
			jabsnd = p;
			break;
		case CharMetaCommands.Command.laughsnd:
			laughsnd = p;
			break;
		case CharMetaCommands.Command.growlsnd:
			growlsnd = p;
			break;
		case CharMetaCommands.Command.screamsnd:
			screamsnd = p;
			break;
		case CharMetaCommands.Command.inactive_anim:
			inactive_anim = p;
			break;
		case CharMetaCommands.Command.nomusic:
			nomusic = true;
			break;
		case CharMetaCommands.Command.isbreaker:
			isBreaker = true;
			break;
		case CharMetaCommands.Command.isbox:
			isBox = true;
			break;
		case CharMetaCommands.Command.isforce:
			isForce = true;
			break;
		case CharMetaCommands.Command.isglowyblue:
			isGlowyBlue = true;
			break;
		case CharMetaCommands.Command.isinvalid:
			isInvalid = true;
			break;
		case CharMetaCommands.Command.isshop:
			isShop = true;
			break;
		case CharMetaCommands.Command.toast1:
			toast1 = p;
			break;
		case CharMetaCommands.Command.toast2:
			toast2 = p;
			break;
		case CharMetaCommands.Command.introyadd:
			introyadd = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.exe_anim:
			exe_anim = p;
			break;
		case CharMetaCommands.Command.turnexetograb:
			turnexetograb = true;
			break;
		case CharMetaCommands.Command.heightminus:
			heightMinus = Convert.ToInt32(p);
			break;
		case CharMetaCommands.Command.burnentry:
			burnentry = true;
			break;
		case CharMetaCommands.Command.istvcrazy:
			isTVCrazy = true;
			break;
		case CharMetaCommands.Command.iskatana:
			isKatana = true;
			break;
		case CharMetaCommands.Command.iskama:
			isKama = true;
			break;
		case CharMetaCommands.Command.isfists:
			isfists = true;
			break;
		case CharMetaCommands.Command.iscloud:
			isCloud = true;
			break;
		case CharMetaCommands.Command.issyringe:
			isSyringe = true;
			break;
		case CharMetaCommands.Command.iscleavers:
			isCleaver = true;
			break;
		case CharMetaCommands.Command.ishammer:
			isHammer = true;
			break;
		case CharMetaCommands.Command.isscissors:
			isScissors = true;
			break;
		case CharMetaCommands.Command.istoaster:
			isToaster = true;
			break;
		case CharMetaCommands.Command.ismagicsponge:
			isMagicSponge = true;
			break;
		case CharMetaCommands.Command.inactivefacecenter:
			inactiveFaceCenter = true;
			break;
		case CharMetaCommands.Command.nogroundzombie:
			nogroundzombie = true;
			break;
		case CharMetaCommands.Command.issawer:
			isSawer = true;
			break;
		case CharMetaCommands.Command.ishatless:
			isHatless = true;
			break;
		case CharMetaCommands.Command.altdefault:
			altdefault = true;
			break;
		}
	}

	public CharMeta(string path)
	{
		StreamReader streamReader = new StreamReader("chars/charMeta/" + path + ".zex");
		while (!streamReader.EndOfStream)
		{
			string text = streamReader.ReadLine();
			for (int i = 0; i < CharMetaCommands.command.Length; i++)
			{
				CharMetaCommand charMetaCommand = CharMetaCommands.command[i];
				if (charMetaCommand != null && charMetaCommand.name.Length <= text.Length && text.Substring(0, charMetaCommand.name.Length) == charMetaCommand.name)
				{
					int num = charMetaCommand.name.Length + 1;
					if (num > text.Length)
					{
						DoCommand(i, null);
					}
					else
					{
						DoCommand(i, text.Substring(num));
					}
					break;
				}
			}
		}
	}

	public CharMeta(BinaryReader reader)
	{
		bool flag = false;
		while (!flag)
		{
			if (reader.ReadBoolean())
			{
				DoCommand(reader.ReadInt32(), reader.ReadString());
				continue;
			}
			int num = reader.ReadInt32();
			if (num < 0)
			{
				flag = true;
				break;
			}
			DoCommand(num, null);
		}
	}

	internal int GetSparks()
	{
		if (isRobot)
		{
			return 2;
		}
		if (isCyborg)
		{
			return 1;
		}
		return 0;
	}
}
