using director;
using Microsoft.Xna.Framework;
using xCharEdit.Character;
using Yuki_Win.achievements.cheevos;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.chars.script;
using Yuki_Win.director;
using Yuki_Win.maps;
using Yuki_Win.menu;
using Yuki_Win.player;

namespace Yuki_Win.chars;

public class CharScript
{
	public enum GotoKey
	{
		None,
		Attack,
		Upper,
		Lower,
		Saw,
		SawUpper,
		SawLower,
		Sec,
		SecUpper,
		SecLower,
		Grab,
		Jump
	}

	public int[] gotos = new int[16];

	public GotoKey lastKey;

	public CharScript()
	{
		for (int i = 0; i < gotos.Length; i++)
		{
			gotos[i] = -1;
		}
	}

	public void UpdateGotos(Character c)
	{
		CharKeys charKeys = c.charKeys;
		CharAnim charAnim = c.charAnim;
		CharUpdate charUpdate = c.charUpdate;
		if (charKeys.keyAttack)
		{
			lastKey = GotoKey.Attack;
		}
		if (charKeys.keyAttack && charKeys.keyDown)
		{
			lastKey = GotoKey.Upper;
		}
		if (charKeys.keyAttack && charKeys.keyUp)
		{
			lastKey = GotoKey.Lower;
		}
		if (charKeys.keyStrong)
		{
			lastKey = GotoKey.Saw;
		}
		if (charKeys.keyStrong && charKeys.keyDown)
		{
			lastKey = GotoKey.SawUpper;
		}
		if (charKeys.keyStrong && charKeys.keyUp)
		{
			lastKey = GotoKey.SawLower;
		}
		if (charKeys.keySec)
		{
			lastKey = GotoKey.Sec;
		}
		if (charKeys.keyGrab)
		{
			lastKey = GotoKey.Grab;
		}
		if (charKeys.keyJump)
		{
			lastKey = GotoKey.Jump;
		}
		if (lastKey == GotoKey.None || gotos[(int)lastKey] <= -1)
		{
			return;
		}
		if (c.charUpdate.charGrab.grabbedByChar < 0 && !c.GetMeta().isGiant)
		{
			if (charKeys.keyLeft)
			{
				charUpdate.face = 0;
			}
			if (charKeys.keyRight)
			{
				charUpdate.face = 1;
			}
		}
		int iD = c.ID;
		if (c.charUpdate.charGrab.grabbedByChar > -1)
		{
			iD = c.charUpdate.charGrab.grabbedByChar;
		}
		switch (lastKey)
		{
		case GotoKey.SawUpper:
			if (gotos[4] != gotos[5])
			{
				Game1.practice.SetKey(4, iD);
			}
			Game1.practice.SetKey(1, iD);
			break;
		case GotoKey.SawLower:
			if (gotos[4] != gotos[6])
			{
				Game1.practice.SetKey(5, iD);
			}
			Game1.practice.SetKey(1, iD);
			break;
		case GotoKey.Upper:
			if (gotos[1] != gotos[2])
			{
				Game1.practice.SetKey(4, iD);
			}
			Game1.practice.SetKey(0, iD);
			break;
		case GotoKey.Lower:
			if (gotos[1] != gotos[3])
			{
				Game1.practice.SetKey(5, iD);
			}
			Game1.practice.SetKey(0, iD);
			break;
		case GotoKey.Attack:
			Game1.practice.SetKey(0, iD);
			break;
		case GotoKey.Grab:
			Game1.practice.SetKey(3, iD);
			break;
		case GotoKey.Saw:
			Game1.practice.SetKey(1, iD);
			break;
		case GotoKey.Sec:
			Game1.practice.SetKey(9, iD);
			break;
		}
		charAnim.GotoFrame(gotos[(int)lastKey]);
	}

	public void ClearGotos()
	{
		lastKey = GotoKey.None;
		for (int i = 0; i < gotos.Length; i++)
		{
			gotos[i] = -1;
		}
	}

	public bool DoNullScript(KeyFrame k)
	{
		bool flag = false;
		bool result = false;
		for (int i = 0; i < k.GetScriptCommandArray().Length; i++)
		{
			ScriptCommand scriptCommand = k.GetScriptCommand(i);
			if (scriptCommand != null)
			{
				result = true;
				switch (scriptCommand.command)
				{
				case ScriptCommandParser.Command.Play:
					Sound.PlaySnd(Sound.Category.FX, scriptCommand.sParam);
					break;
				case ScriptCommandParser.Command.Quake:
					QuakeManager.SetQuake((float)scriptCommand.iParam / 10f);
					break;
				}
			}
			if (flag)
			{
				break;
			}
		}
		return result;
	}

	private bool CanExecute(ScriptCommand s, int ID, bool netInduced)
	{
		if (Game1.netSession.IsHost())
		{
			Game1.netSession.netGame.SendCharScript(Game1.netSession.session, s, ID);
			return true;
		}
		if (Game1.netSession.IsClient())
		{
			return netInduced;
		}
		return true;
	}

	public bool ExecuteCommand(ScriptCommand s, CharAnim charAnim, CharUpdate charUpdate, int charMeta, CharKeys charKeys, int ID, bool netInduced)
	{
		bool result = false;
		switch (s.command)
		{
		case ScriptCommandParser.Command.BossKill:
		{
			if (Game1.netSession.IsHost() || Game1.netSession.IsClient() || !Game1.charMeta[charMeta].isBoss)
			{
				break;
			}
			bool flag2 = false;
			for (int l = 4; l < Game1.character.Length; l++)
			{
				if (l != ID && Game1.character[l].exists && Game1.character[l].GetMeta().isBoss)
				{
					flag2 = true;
				}
			}
			if (!flag2)
			{
				for (int m = 4; m < Game1.character.Length; m++)
				{
					if (m != ID && !Game1.character[m].GetMeta().isBoss && Game1.character[m].exists)
					{
						Game1.character[m].exists = false;
					}
				}
				Game1.gameMap.bucket.BossKillBucket();
				Game1.hud.ResetWaveDefeatedOkFrame();
				Game1.hud.DefeatWave();
			}
			else
			{
				Game1.hud.ResetWaveDefeatedOkFrame();
				Game1.hud.DefeatWave();
			}
			break;
		}
		case ScriptCommandParser.Command.CleanKilled:
		case ScriptCommandParser.Command.RendKilled:
		case ScriptCommandParser.Command.SmashKilled:
		case ScriptCommandParser.Command.SlasherKilled:
		case ScriptCommandParser.Command.BlastKilled:
			if (charUpdate.lastHitBy >= Game1.gamePlayerMgr.gamePlayer.Length)
			{
				break;
			}
			if (charUpdate.lastHitBy < 2 && !Game1.achievementMgr.playerAchievements[charUpdate.lastHitBy].achievementList[11].unlocked)
			{
				Separate100Dudes separate100Dudes = (Separate100Dudes)Game1.achievementMgr.playerAchievements[charUpdate.lastHitBy].achievementList[11];
				separate100Dudes.dudesChopped++;
				separate100Dudes.Unlock(overRide: false);
			}
			Game1.character[ID].effectivelyDead = true;
			Game1.hud.ResetWaveDefeatedOkFrame();
			if (Game1.gamePlayerMgr.gamePlayer[charUpdate.lastHitBy].active)
			{
				Game1.gamePlayerMgr.gamePlayer[charUpdate.lastHitBy].DoHit(s.iParam, grab: true);
				switch (s.command)
				{
				case ScriptCommandParser.Command.RendKilled:
					Game1.gamePlayerMgr.gamePlayer[charUpdate.lastHitBy].DoRendKill();
					break;
				case ScriptCommandParser.Command.SlasherKilled:
					Game1.gamePlayerMgr.gamePlayer[charUpdate.lastHitBy].DoSlasherKill();
					break;
				case ScriptCommandParser.Command.SmashKilled:
					Game1.gamePlayerMgr.gamePlayer[charUpdate.lastHitBy].DoSmashKill();
					break;
				case ScriptCommandParser.Command.CleanKilled:
					Game1.gamePlayerMgr.gamePlayer[charUpdate.lastHitBy].DoCleanKill();
					break;
				case ScriptCommandParser.Command.BlastKilled:
					Game1.gamePlayerMgr.gamePlayer[charUpdate.lastHitBy].DoBlastKill();
					break;
				}
			}
			break;
		case ScriptCommandParser.Command.DeHealthify:
			if (charUpdate.hp > charUpdate.mhp / -4f)
			{
				charUpdate.hp = charUpdate.mhp / -4f;
			}
			charUpdate.dehealthified = true;
			break;
		case ScriptCommandParser.Command.JoyJump:
			charAnim.JoyJump(charKeys, charUpdate);
			break;
		case ScriptCommandParser.Command.SetAnim:
			charAnim.SetAnim(s.sParam, charUpdate);
			break;
		case ScriptCommandParser.Command.GotoFrame:
			charAnim.GotoFrame(s.iParam);
			result = true;
			break;
		case ScriptCommandParser.Command.JudgeRise:
			if (CanExecute(s, ID, netInduced))
			{
				Game1.gameMap.CurMap().scriptMgr.SetFlag("judgerise");
			}
			break;
		case ScriptCommandParser.Command.JoyTurn:
			if (Game1.character[ID].charKeys.keyLeft)
			{
				charUpdate.face = 0;
			}
			if (Game1.character[ID].charKeys.keyRight)
			{
				charUpdate.face = 1;
			}
			break;
		case ScriptCommandParser.Command.KillInactives:
		{
			for (int j = 0; j < Game1.character.Length; j++)
			{
				if (Game1.character[j].exists && Game1.character[j].charUpdate.inactive)
				{
					Game1.character[j].exists = false;
				}
			}
			break;
		}
		case ScriptCommandParser.Command.GroundCheck:
			if (charUpdate.state == CharUpdate.State.Grounded)
			{
				charAnim.SetAnim(Game1.charMeta[charMeta].hitland_anim, charUpdate);
			}
			break;
		case ScriptCommandParser.Command.IfDuelFailGoto:
			if (charUpdate.charGrab.duelCount < 3)
			{
				charAnim.GotoFrame(s.iParam);
				if (Game1.character[ID].charUpdate.hp < 5f)
				{
					Game1.character[ID].charUpdate.hp = 5f;
				}
			}
			else if (charUpdate.charGrab.grabbedByChar > -1 && charUpdate.charGrab.grabbedByChar < 2 && !Game1.achievementMgr.playerAchievements[charUpdate.charGrab.grabbedByChar].achievementList[8].unlocked)
			{
				ChainsawDuels chainsawDuels = (ChainsawDuels)Game1.achievementMgr.playerAchievements[charUpdate.charGrab.grabbedByChar].achievementList[8];
				chainsawDuels.duelsWon++;
				chainsawDuels.Unlock(overRide: false);
			}
			break;
		case ScriptCommandParser.Command.Engied:
			if (CanExecute(s, ID, netInduced) && !Game1.gameMap.engied)
			{
				Game1.gameMap.CurMap().scriptMgr.SetFlag("engied");
				Game1.gameMap.engied = true;
				Game1.gameMap.engiedFrame = 0f;
			}
			break;
		case ScriptCommandParser.Command.TargFace:
			if (Game1.character[ID].ai != null && Game1.character[ID].ai.targ > -1)
			{
				if (charUpdate.loc.X > Game1.character[Game1.character[ID].ai.targ].charUpdate.loc.X)
				{
					charUpdate.face = 0;
				}
				if (charUpdate.loc.X < Game1.character[Game1.character[ID].ai.targ].charUpdate.loc.X)
				{
					charUpdate.face = 1;
				}
			}
			break;
		case ScriptCommandParser.Command.GroundWarp:
		{
			Vector2 v = new Vector2(Rand.GetRandomFloat(128f, (float)Game1.gameMap.CurMap().xSize * 64f - 128f), charUpdate.loc.Y - 8f);
			if (Game1.gameMap.CurMap().TestCol(v))
			{
				break;
			}
			charUpdate.loc = new Vector2(v.X, charUpdate.loc.Y);
			if (Game1.character[ID].ai != null && Game1.character[ID].ai.targ > -1)
			{
				if (charUpdate.loc.X > Game1.character[Game1.character[ID].ai.targ].charUpdate.loc.X)
				{
					charUpdate.face = 0;
				}
				if (charUpdate.loc.X < Game1.character[Game1.character[ID].ai.targ].charUpdate.loc.X)
				{
					charUpdate.face = 1;
				}
			}
			break;
		}
		case ScriptCommandParser.Command.SpecialStain:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.StainSpecial(0);
			}
			break;
		case ScriptCommandParser.Command.DeInit:
			Game1.character[ID].exists = false;
			break;
		case ScriptCommandParser.Command.LiftStop:
			if (CanExecute(s, ID, netInduced))
			{
				Game1.gameMap.liftStopMode = true;
				QuakeManager.SetQuake(0.5f);
				Sound.PlaySnd(Sound.Category.FX, "liftstop");
			}
			break;
		case ScriptCommandParser.Command.LiftFree:
			if (CanExecute(s, ID, netInduced))
			{
				Game1.gameMap.liftStopMode = false;
				QuakeManager.SetQuake(0.2f);
				Sound.PlaySnd(Sound.Category.FX, "liftstart");
			}
			break;
		case ScriptCommandParser.Command.LiftSmash:
			if (CanExecute(s, ID, netInduced))
			{
				Game1.gameMap.SmashWindow(charUpdate.loc);
			}
			break;
		case ScriptCommandParser.Command.CeilingSmash:
			if (CanExecute(s, ID, netInduced))
			{
				Game1.gameMap.SmashCeiling(charUpdate.loc);
			}
			break;
		case ScriptCommandParser.Command.ShoulderWarp:
		case ScriptCommandParser.Command.RandomShoulderWarp:
		{
			int targ = Game1.character[ID].ai.targ;
			if (targ > -1 && ((s.command == ScriptCommandParser.Command.RandomShoulderWarp && (Rand.CointToss(0.25f) || Game1.character[targ].charUpdate.loc.Y < charUpdate.loc.Y)) || s.command == ScriptCommandParser.Command.ShoulderWarp) && Game1.character[targ].exists)
			{
				Vector2 vector2 = Game1.character[targ].charUpdate.loc + Rand.GetRandomVec2(-100f, 100f, -200f, -150f);
				Map map = Game1.gameMap.CurMap();
				if (!map.TestCol(vector2) && !map.TestCol(vector2 + new Vector2(-50f, 0f)) && !map.TestCol(vector2 + new Vector2(50f, 0f)) && !map.TestCol(vector2 + new Vector2(-50f, -80f)) && !map.TestCol(vector2 + new Vector2(50f, -80f)) && vector2.Y > 64f && vector2.X > 64f && vector2.X < (float)map.xSize * 64f)
				{
					charUpdate.loc = vector2;
					charUpdate.state = CharUpdate.State.Airborne;
					charUpdate.traj.Y = -20f;
				}
			}
			break;
		}
		case ScriptCommandParser.Command.BreakJuggle:
			charUpdate.airJuggleFrame = 0f;
			charUpdate.breakJuggleFrame = 0.5f;
			break;
		case ScriptCommandParser.Command.IfNoSawGoto:
			if (!charKeys.IsSawDown)
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		case ScriptCommandParser.Command.IfDyingGoto:
			if (charUpdate.hp < 0f)
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		case ScriptCommandParser.Command.IfCloseGoto:
		{
			bool flag3 = false;
			for (int num4 = 0; num4 < 2; num4++)
			{
				if (Game1.character[num4].exists && Game1.character[num4].team != Game1.character[ID].team)
				{
					Vector2 vector = Game1.character[num4].charUpdate.loc - charUpdate.loc;
					if (vector.X > -200f && vector.X < 200f)
					{
						flag3 = true;
					}
				}
			}
			if (flag3)
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		}
		case ScriptCommandParser.Command.IfNotDyingGoto:
			if (charUpdate.hp >= 0f)
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		case ScriptCommandParser.Command.SetRunStartAnim:
			charUpdate.runStartAnim = s.sParam;
			break;
		case ScriptCommandParser.Command.SetAltRunStart:
			charUpdate.altRunStart = true;
			break;
		case ScriptCommandParser.Command.SetNAltRunStart:
			charUpdate.altRunStart = false;
			break;
		case ScriptCommandParser.Command.CryptRocks:
			Game1.spriteMan.AddSprite(93, charUpdate.loc, default, 0f, 0, ID);
			break;
		case ScriptCommandParser.Command.MoonRocks:
			Game1.spriteMan.AddSprite(90, charUpdate.loc, default, 0f, 0, ID);
			break;
		case ScriptCommandParser.Command.IfEdgeGoto:
		{
			if (!Game1.IsPlayerChar(charUpdate.ID))
			{
				break;
			}
			Map map2 = Game1.gameMap.CurMap();
			switch (map2.GetCol(charUpdate.loc))
			{
			case Map.Collision.Rise:
			case Map.Collision.Fall:
				charAnim.GotoFrame(s.iParam);
				break;
			}
			if (map2.GetCol(charUpdate.loc + new Vector2(16f, 16f)) == Map.Collision.None || map2.GetCol(charUpdate.loc + new Vector2(-16f, 16f)) == Map.Collision.None)
			{
				charAnim.GotoFrame(s.iParam);
			}
			if (Game1.camMgr.twoPlayers)
			{
				int mateId = ((charUpdate.ID < 2) ? (1 - charUpdate.ID) : 0);
				Vector2 vector3 = Game1.character[mateId].charUpdate.loc - charUpdate.loc;
				if (Game1.character[mateId].charUpdate.face != charUpdate.face && vector3.Y > -20f && vector3.Y < 20f && vector3.X > -50f && vector3.X < 50f)
				{
					charAnim.GotoFrame(s.iParam);
				}
			}
			break;
		}
		case ScriptCommandParser.Command.IfHealthyGoto:
			if (charUpdate.hp >= charUpdate.mhp / 4f)
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		case ScriptCommandParser.Command.IfR25Goto:
			if (Rand.CointToss(0.25f))
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		case ScriptCommandParser.Command.IfR50Goto:
			if (Rand.CointToss(0.5f))
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		case ScriptCommandParser.Command.IfR75Goto:
			if (Rand.CointToss(0.75f))
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		case ScriptCommandParser.Command.IfFallGoto:
			if (charUpdate.traj.Y > -100f)
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
			}
			break;
		case ScriptCommandParser.Command.JuggleStick:
			charUpdate.JuggleStick(ID, warp: false);
			break;
		case ScriptCommandParser.Command.AboutFace:
			charUpdate.face = 1 - charUpdate.face;
			break;
		case ScriptCommandParser.Command.IfUpGoto:
			if (charKeys.keyUp)
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
				Game1.practice.SetKey(5, ID);
			}
			break;
		case ScriptCommandParser.Command.IfDownGoto:
			if (charKeys.keyDown)
			{
				charAnim.GotoFrame(s.iParam);
				result = true;
				Game1.practice.SetKey(4, ID);
			}
			break;
		case ScriptCommandParser.Command.ClearGotos:
			ClearGotos();
			break;
		case ScriptCommandParser.Command.Float:
			charUpdate.floating = true;
			break;
		case ScriptCommandParser.Command.Unfloat:
			charUpdate.floating = false;
			break;
		case ScriptCommandParser.Command.WCharge:
			charUpdate.wcharge = (float)s.iParam / 10f;
			break;
		case ScriptCommandParser.Command.SetJump:
		{
			float num6 = 1f;
			if (Game1.charMeta[charMeta].fakeCeiling > 0f && charUpdate.loc.Y < Game1.charMeta[charMeta].fakeCeiling)
			{
				num6 = (charUpdate.loc.Y - (Game1.charMeta[charMeta].fakeCeiling - 200f)) / 200f;
				if (num6 < 0f)
				{
					num6 = 0f;
				}
			}
			charUpdate.traj.Y = -1f * (float)s.iParam;
			charUpdate.state = CharUpdate.State.Airborne;
			charUpdate.traj.Y *= 1.2f * num6;
			break;
		}
		case ScriptCommandParser.Command.SetFall:
			charUpdate.traj.Y = s.iParam;
			charUpdate.traj.Y *= 1.2f;
			if (charUpdate.airJuggleFrame > 0f)
			{
				charUpdate.airJuggleFrame = 0f;
			}
			break;
		case ScriptCommandParser.Command.SetGrabGoto:
			gotos[10] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetJumpGoto:
			gotos[11] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetAnyGoto:
			gotos[1] = s.iParam;
			gotos[2] = s.iParam;
			gotos[3] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetAtkGoto:
			gotos[1] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetLowerGoto:
			gotos[3] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetUpperGoto:
			gotos[2] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetSawAnyGoto:
		case ScriptCommandParser.Command.SetStrongAnyGoto:
			gotos[4] = s.iParam;
			gotos[5] = s.iParam;
			gotos[6] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetSawUpperGoto:
		case ScriptCommandParser.Command.SetStrongUpperGoto:
			gotos[5] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetSawLowerGoto:
		case ScriptCommandParser.Command.SetStrongLowerGoto:
			gotos[6] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetSecAnyGoto:
			gotos[7] = s.iParam;
			gotos[8] = s.iParam;
			gotos[9] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetSecUpperGoto:
			gotos[8] = s.iParam;
			break;
		case ScriptCommandParser.Command.SetSecLowerGoto:
			gotos[9] = s.iParam;
			break;
		case ScriptCommandParser.Command.Slide:
			if (charUpdate.face == 1)
			{
				charUpdate.traj.X = s.iParam;
			}
			else
			{
				charUpdate.traj.X = 0f - (float)s.iParam;
			}
			break;
		case ScriptCommandParser.Command.Backup:
			if (charUpdate.face == 1)
			{
				charUpdate.traj.X = 0f - (float)s.iParam;
			}
			else
			{
				charUpdate.traj.X = s.iParam;
			}
			break;
		case ScriptCommandParser.Command.SetGrabber:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charAnim.SetAnim(s.sParam, Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.etherealFrame = 1f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.FixNetLoc();
				charUpdate.charGrab.grabbedByChar = -1;
			}
			break;
		case ScriptCommandParser.Command.SetGroundedGrabber:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charAnim.SetAnim(s.sParam, Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.etherealFrame = 1f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.loc = charUpdate.loc;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.FixNetLoc();
				charUpdate.charGrab.grabbedByChar = -1;
			}
			break;
		case ScriptCommandParser.Command.RSetGrabber:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.face = 1 - Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.face;
				Game1.character[charUpdate.charGrab.grabbedByChar].charAnim.SetAnim(s.sParam, Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.etherealFrame = 1f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.FixNetLoc();
				charUpdate.charGrab.grabbedByChar = -1;
			}
			break;
		case ScriptCommandParser.Command.SetAirGrabber:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charAnim.SetAnim(s.sParam, Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.etherealFrame = 1f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.state = CharUpdate.State.Airborne;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.loc = charUpdate.loc;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.FixNetLoc();
				charUpdate.charGrab.grabbedByChar = -1;
			}
			break;
		case ScriptCommandParser.Command.ShowGrabber:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charAnim.SetAnim(Game1.character[charUpdate.charGrab.grabbedByChar].GetMeta().idle_anim, Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.etherealFrame = 1f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.FixNetLoc();
				charUpdate.charGrab.grabbedByChar = -1;
			}
			break;
		case ScriptCommandParser.Command.ShowGrabberHit:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charAnim.SetAnim(Game1.character[charUpdate.charGrab.grabbedByChar].GetMeta().idle_anim, Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.etherealFrame = -1f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.ethereal = false;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.FixNetLoc();
				charUpdate.charGrab.grabbedByChar = -1;
			}
			break;
		case ScriptCommandParser.Command.ShowAirGrabber:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charAnim.SetAnim(Game1.charMeta[Game1.character[charUpdate.charGrab.grabbedByChar].charMeta].fly_anim, Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.etherealFrame = 1f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.state = CharUpdate.State.Airborne;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.traj.X = 0f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.traj.Y = 0f;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.loc = GetSafeVec(charUpdate, charAnim);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.FixNetLoc();
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.face = charAnim.charTrigs.grabberFace;
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.charGrab.grabbing = false;
				charUpdate.charGrab.grabbedByChar = -1;
			}
			break;
		case ScriptCommandParser.Command.Ethereal:
			charUpdate.ethereal = true;
			break;
		case ScriptCommandParser.Command.Solid:
			charUpdate.ethereal = false;
			break;
		case ScriptCommandParser.Command.GetKnife:
		{
			for (int k = 0; k < Game1.character.Length; k++)
			{
				if (Game1.character[k].exists && Game1.character[k].charMeta == 84)
				{
					Game1.character[k].exists = false;
				}
			}
			break;
		}
		case ScriptCommandParser.Command.StabbedEnd:
			Game1.gameMap.CurMap().scriptMgr.SetFlag("stabbedend");
			break;
		case ScriptCommandParser.Command.RavenEnd:
			Game1.gameMap.CurMap().scriptMgr.SetFlag("ravenend");
			break;
		case ScriptCommandParser.Command.KillMe:
			if (charUpdate.dyingFrame < 0.1f)
			{
				charUpdate.dyingFrame = 0.1f;
			}
			break;
		case ScriptCommandParser.Command.Quirk:
		{
			float quirk = (float)s.iParam / 100f;
			QuakeManager.SetQuirk(quirk);
			break;
		}
		case ScriptCommandParser.Command.KillMeNow:
			if (charUpdate.dyingFrame < 0.1f)
			{
				charUpdate.dyingFrame = 0.1f;
			}
			if (charUpdate.state == CharUpdate.State.Airborne)
			{
				charUpdate.floating = true;
			}
			break;
		case ScriptCommandParser.Command.CheckSec:
			charUpdate.CheckSec(charAnim, charKeys, overRide: false);
			break;
		case ScriptCommandParser.Command.OverSec:
			charUpdate.CheckSec(charAnim, charKeys, overRide: true);
			if (lastKey == GotoKey.Saw || lastKey == GotoKey.SawUpper || lastKey == GotoKey.SawLower)
			{
				if (charUpdate.state == CharUpdate.State.Airborne)
				{
					charUpdate.charInput.DoFShotty(charKeys, charAnim, charUpdate, Game1.character[ID]);
				}
				else
				{
					charUpdate.charInput.DoShotty(charKeys, charAnim, charUpdate, Game1.character[ID]);
				}
			}
			break;
		case ScriptCommandParser.Command.SetSawSpecial:
			charUpdate.lastSpecial = 1;
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.lastSpecial = charUpdate.lastSpecial;
			}
			break;
		case ScriptCommandParser.Command.SetGunSpecial:
			charUpdate.lastSpecial = 2;
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.lastSpecial = charUpdate.lastSpecial;
			}
			break;
		case ScriptCommandParser.Command.WallJump:
			if (charUpdate.face == 1)
			{
				charUpdate.traj.X = -400f;
			}
			else
			{
				charUpdate.traj.X = 400f;
			}
			charUpdate.traj.Y = -900f;
			break;
		case ScriptCommandParser.Command.SetLandAnim:
			charUpdate.landAnim = s.sParam;
			break;
		case ScriptCommandParser.Command.DeathCheck:
			if (charUpdate.hp < 0f && charUpdate.dyingFrame < 1f)
			{
				charUpdate.dyingFrame = 1f;
			}
			break;
		case ScriptCommandParser.Command.CloudCharge:
		{
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				float cloudCharge = Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.cloudCharge;
				if (cloudCharge <= 0f)
				{
					Sound.PlaySnd(Sound.Category.FX, "zcharge");
				}
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.cloudCharge += 0.15f;
				if (Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.cloudCharge > 5f)
				{
					Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.cloudCharge = 5f;
				}
				break;
			}
			float cloudCharge2 = charUpdate.cloudCharge;
			if (charUpdate.cloudCharge >= 5f)
			{
				charUpdate.cloudCharge += 0.01f;
			}
			else
			{
				charUpdate.cloudCharge += 0.15f;
				if (charUpdate.cloudCharge > 5f)
				{
					charUpdate.cloudCharge = 5f;
				}
			}
			if (cloudCharge2 <= 0f && charUpdate.state == CharUpdate.State.Grounded)
			{
				Sound.PlaySnd(Sound.Category.FX, "zcharge1");
			}
			if (cloudCharge2 < 2.25f && charUpdate.cloudCharge >= 2.25f)
			{
				Sound.PlaySnd(Sound.Category.FX, "zcharge2");
			}
			if (cloudCharge2 < 4.5f && charUpdate.cloudCharge >= 4.5f)
			{
				Sound.PlaySnd(Sound.Category.FX, "zcharge3");
			}
			if (charUpdate.cloudCharge > 5.1f)
			{
				Sound.PlaySnd(Sound.Category.FX, "zchargeloop");
				charUpdate.cloudCharge = 5f;
			}
			break;
		}
		case ScriptCommandParser.Command.Decharge:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.cloudCharge = 0f;
			}
			else
			{
				charUpdate.cloudCharge = 0f;
			}
			break;
		case ScriptCommandParser.Command.SpeedFac:
			charAnim.speedFac = (float)s.iParam / 100f;
			break;
		case ScriptCommandParser.Command.GunIdle:
			if (Game1.charMeta[charMeta].special == 3 || Game1.charMeta[charMeta].special == 4)
			{
				charAnim.SetAnim(Game1.charMeta[charMeta].switch_anim, charUpdate);
			}
			else
			{
				charAnim.SetAnim(Game1.charMeta[charMeta].idle_anim, charUpdate);
			}
			break;
		case ScriptCommandParser.Command.GunFly:
			if (Game1.charMeta[charMeta].special == 3 || Game1.charMeta[charMeta].special == 4)
			{
				charAnim.SetAnim(Game1.charMeta[charMeta].fswitch_anim, charUpdate);
			}
			else
			{
				charAnim.SetAnim(Game1.charMeta[charMeta].fly_anim, charUpdate);
			}
			break;
		case ScriptCommandParser.Command.KillMonsters:
		{
			for (int num5 = 0; num5 < Game1.character.Length; num5++)
			{
				if (Game1.character[num5].exists && Game1.character[num5].team == Character.Team.BadGuys && Game1.character[num5].charUpdate.hp > -1f)
				{
					Game1.character[num5].charUpdate.hp = -1f;
				}
			}
			break;
		}
		case ScriptCommandParser.Command.Killfx:
			Game1.killManager.DoKill(charUpdate.ID);
			break;
		case ScriptCommandParser.Command.Hitfx:
			Game1.killManager.doBits(0.8f);
			break;
		case ScriptCommandParser.Command.Slow:
			charUpdate.Slow((float)s.iParam / 100f);
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.Slow((float)s.iParam / 100f);
			}
			break;
		case ScriptCommandParser.Command.Play:
			Sound.PlaySnd(Sound.Category.FX, s.sParam);
			break;
		case ScriptCommandParser.Command.ZoomBump:
			if (!Game1.camMgr.twoPlayers)
			{
				ScrollManager.zoom += 0.2f;
			}
			break;
		case ScriptCommandParser.Command.KeyTurn:
			if (charKeys.keyLeft)
			{
				charUpdate.face = 0;
			}
			if (charKeys.keyRight)
			{
				charUpdate.face = 1;
			}
			break;
		case ScriptCommandParser.Command.Vox:
			Sound.PlayVox(charMeta, s.sParam);
			break;
		case ScriptCommandParser.Command.GVox:
			if (charUpdate.charGrab.grabbedByChar > -1)
			{
				Sound.PlayVox(Game1.character[charUpdate.charGrab.grabbedByChar].charMeta, s.sParam);
			}
			break;
		case ScriptCommandParser.Command.CanCancel:
			charAnim.canCancel = true;
			break;
		case ScriptCommandParser.Command.Quake:
			QuakeManager.SetQuake((float)s.iParam / 10f);
			break;
		case ScriptCommandParser.Command.NoBlock:
			charUpdate.block = CharUpdate.Block.NoBlock;
			break;
		case ScriptCommandParser.Command.AllBlock:
			charUpdate.block = CharUpdate.Block.AllBlock;
			break;
		case ScriptCommandParser.Command.GetsExeGrab:
			charUpdate.getsExeGrabInput = true;
			break;
		case ScriptCommandParser.Command.GetsAllGrab:
			charUpdate.getsAllGrabInput = true;
			break;
		case ScriptCommandParser.Command.Reload:
			charUpdate.ammo = charUpdate.ammoMax;
			break;
		case ScriptCommandParser.Command.YukiDies:
		{
			for (int num3 = 0; num3 < 4; num3++)
			{
				if (Game1.character[num3].exists && Game1.character[num3].team == Character.Team.GoodGuys)
				{
					Game1.character[num3].charUpdate.hp = -1f;
					Game1.character[num3].charAnim.SetAnim("jhit", Game1.character[num3].charUpdate);
					Game1.character[num3].charUpdate.traj = new Vector2(0f, -100f);
					Game1.character[num3].charUpdate.state = CharUpdate.State.Airborne;
				}
			}
			MainPlayer.uberDyingFrame = 1f;
			Game1.hud.PickupDeath();
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
			{
				Game1.menuMgr.SetLevel(MenuManager.LevelTitle.ArcadeYouAreDead);
				Game1.menuMgr.levels[16].alpha = 0f;
			}
			else
			{
				Game1.menuMgr.SetLevel(MenuManager.LevelTitle.YouAreDead);
				Game1.menuMgr.levels[7].alpha = 0f;
			}
			break;
		}
		case ScriptCommandParser.Command.WaitIfNotAlone:
		{
			int num2 = 0;
			for (int n = 4; n < Game1.character.Length; n++)
			{
				if (Game1.character[n].exists && Game1.character[n].team == Character.Team.BadGuys)
				{
					num2++;
				}
			}
			if (num2 > 1)
			{
				charUpdate.wait = 15f;
			}
			break;
		}
		case ScriptCommandParser.Command.HypnoGrabbed:
			if (Game1.gameMap.hypnograbbed < 3)
			{
				Game1.gameMap.hypnograbbed++;
				if (Game1.gameMap.hypnograbbed >= 3)
				{
					Game1.gameMap.CurMap().scriptMgr.SetFlag("hypnograbbed");
				}
				else
				{
					charAnim.GotoFrame(charAnim.GetKey() + 2);
				}
			}
			break;
		case ScriptCommandParser.Command.YukiDeath:
			Game1.gameMap.yukiDeathFocus = true;
			Game1.gameMap.yukiDeathFrame = 0f;
			break;
		case ScriptCommandParser.Command.SetKatPhase:
			Game1.player.SetYukiPhase(4);
			Game1.character[0].charRender.melee = 1;
			Game1.character[0].charMeta = (charMeta = (Game1.character[0].charAnim.charMeta = 0));
			Game1.character[0].weapIdx = 0;
			Game1.character[0].loadOut = 0;
			Game1.gamePlayerMgr.gamePlayer[0].loadOut[0].weapon[0] = InvCatalog.InvItemName.Conviction;
			break;
		case ScriptCommandParser.Command.HealthSap:
		{
			float num = s.iParam;
			if (charUpdate.charGrab.grabbedByChar >= 4)
			{
				switch (GameSettings.difficulty)
				{
				case 0:
					num *= 0.1f;
					break;
				case 1:
					num *= 0.35f;
					break;
				case 2:
					num *= 0.7f;
					break;
				case 3:
					num *= 1f;
					break;
				case 4:
					num *= 1.5f;
					break;
				case 5:
					num *= 1f;
					break;
				}
			}
			charUpdate.hp -= num;
			if (charUpdate.charGrab.grabbedByChar > -1 && charUpdate.charGrab.grabbedByChar < 2)
			{
				Game1.gamePlayerMgr.gamePlayer[charUpdate.charGrab.grabbedByChar].DoHit(s.iParam, grab: true);
				Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.StainWeapon(Game1.charMeta[charMeta].isRobot ? 2 : 0);
				if (charUpdate.lastSpecial != 0)
				{
					Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.StainChainsaw(Game1.charMeta[charMeta].isRobot ? 2 : 0);
				}
			}
			if (!Game1.IsPlayerChar(charUpdate.ID) || !(charUpdate.hp < 0f))
			{
				break;
			}
			bool flag = true;
			if (Game1.GetPlayers() >= 2)
			{
				for (int i = 0; i < 4; i++)
				{
					if (Game1.IsPlayerChar(i) && Game1.character[i].team == Character.Team.GoodGuys && Game1.character[i].exists && Game1.character[i].charUpdate.hp >= 0f)
					{
						flag = false;
					}
				}
			}
			if (flag)
			{
				Game1.killManager.DoUberDeath();
			}
			break;
		}
		}
		return result;
	}

	public bool DoScript(KeyFrame k, CharAnim charAnim, CharUpdate charUpdate, int charMeta, CharKeys charKeys, int ID)
	{
		bool flag = false;
		bool result = false;
		for (int i = 0; i < k.GetScriptCommandArray().Length; i++)
		{
			ScriptCommand scriptCommand = k.GetScriptCommand(i);
			if (scriptCommand != null)
			{
				result = true;
				flag = ExecuteCommand(scriptCommand, charAnim, charUpdate, charMeta, charKeys, ID, netInduced: false);
			}
			if (flag)
			{
				break;
			}
		}
		return result;
	}

	private Vector2 GetSafeVec(CharUpdate charUpdate, CharAnim charAnim)
	{
		Vector2 grabberLoc = charAnim.charTrigs.grabberLoc;
		Map map = Game1.gameMap.CurMap();
		if (map.TestCol(grabberLoc + new Vector2(-30f, 0f)) || map.TestCol(grabberLoc + new Vector2(30f, 0f)))
		{
			return new Vector2(Game1.character[charUpdate.charGrab.grabbedByChar].charUpdate.loc.X, grabberLoc.Y);
		}
		return grabberLoc;
	}

	internal void Init()
	{
		ClearGotos();
	}
}
