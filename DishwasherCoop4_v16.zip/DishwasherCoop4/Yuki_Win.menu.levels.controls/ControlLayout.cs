using System.Text;

namespace Yuki_Win.menu.levels.controls;

public class ControlLayout
{
	public StringBuilder AString;

	public StringBuilder BString;

	public StringBuilder XString;

	public StringBuilder YString;

	public StringBuilder StartString;

	public StringBuilder BackString;

	public StringBuilder LeftStickString;

	public StringBuilder RightStickString;

	public StringBuilder LeftTriggerString;

	public StringBuilder RightTriggerString;

	public StringBuilder LeftShoulderString;

	public StringBuilder RightShoulderString;

	public ControlLayout(string aString, string bString, string xString, string yString, string startString, string backString, string leftStickString, string rightStickString, string leftTriggerString, string rightTriggerString, string leftShoulderString, string rightShoulderString)
	{
		AString = new StringBuilder(aString);
		BString = new StringBuilder(bString);
		XString = new StringBuilder(xString);
		YString = new StringBuilder(yString);
		StartString = new StringBuilder(startString);
		BackString = new StringBuilder(backString);
		LeftStickString = new StringBuilder(leftStickString);
		RightStickString = new StringBuilder(rightStickString);
		LeftTriggerString = new StringBuilder(leftTriggerString);
		RightTriggerString = new StringBuilder(rightTriggerString);
		LeftShoulderString = new StringBuilder(leftShoulderString);
		RightShoulderString = new StringBuilder(rightShoulderString);
	}
}
