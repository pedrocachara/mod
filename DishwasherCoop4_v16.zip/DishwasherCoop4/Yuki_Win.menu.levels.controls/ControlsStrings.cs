using System.Collections.Generic;

namespace Yuki_Win.menu.levels.controls;

public class ControlsStrings
{
	public enum ControlLayoutType
	{
		Original,
		Swapped
	}

	public Dictionary<int, ControlLayout> controlLayouts;

	public ControlsStrings()
	{
		controlLayouts = new Dictionary<int, ControlLayout>();
		controlLayouts.Add(0, new ControlLayout("[A] " + YukiText.jumpAccept, "[B] " + YukiText.grabCancel, "[X] " + YukiText.attack, "[Y] " + YukiText.strongSaw, "[g] " + YukiText.pause, "[f] " + YukiText.inventory, "[S] " + YukiText.move, "[s] " + YukiText.warpRoll, "[L] " + YukiText.magic + " (+[X][Y][A][B])", "[R] " + YukiText.gun + " (+[Y][B])", "[l] " + YukiText.switchLoadouts, "[r] " + YukiText.switchWeapons));
		controlLayouts.Add(1, new ControlLayout("[A] " + YukiText.jumpAccept, "[B] " + YukiText.grabCancel, "[X] " + YukiText.attack, "[Y] " + YukiText.strongSaw, "[g] " + YukiText.pause, "[f] " + YukiText.inventory, "[S] " + YukiText.move, "[s] " + YukiText.gun + " (+[R][L])", "[L] " + YukiText.warpRoll + " (+[S])", "[R] " + YukiText.magic + " (+[X][Y][A][B])", "[l] " + YukiText.switchLoadouts, "[r] " + YukiText.switchWeapons));
	}
}
