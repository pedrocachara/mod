using System.IO;

namespace GuitarEdit.guitar;

public class Node
{
	public enum Event
	{
		A,
		B,
		X,
		Y,
		NoLights,
		WhiteLights,
		RedLights,
		BlueLights,
		Fire,
		BlueSparks,
		StrobeLights,
		Pose1,
		Pose2,
		Pose3,
		Pose4
	}

	public Event eventType;

	public int beats;

	public void Set(int beats, Event e)
	{
		this.beats = beats;
		eventType = e;
	}

	public Node(int beats, Event e)
	{
		this.beats = beats;
		eventType = e;
	}

	public Node(BinaryReader reader)
	{
		beats = reader.ReadInt32();
		eventType = (Event)reader.ReadInt32();
	}

	public void Read(BinaryReader reader)
	{
		beats = reader.ReadInt32();
		eventType = (Event)reader.ReadInt32();
	}

	public void Write(BinaryWriter writer)
	{
		writer.Write(beats);
		writer.Write((int)eventType);
	}
}
