using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.director;
using Yuki_Win.player;

namespace Yuki_Win.maps.script;

public class Bucket
{
	public List<BucketItem> items;

	public bool active;

	public bool done;

	public int lim;

	public int addIdx;

	public Bucket()
	{
		items = new List<BucketItem>();
	}

	public void Init(int lim, bool fix)
	{
		items.Clear();
		addIdx = 0;
		active = true;
		done = false;
		this.lim = lim;
		if (Game1.GetPlayers() >= 2 && !fix && this.lim < 3)
		{
			this.lim++;
		}
	}

	public void Clear()
	{
		active = false;
	}

	public void BossKillBucket()
	{
		active = false;
		done = true;
	}

	public void AddItem(Vector2 loc, int monster)
	{
		bool flag = false;
		if (!Game1.gameMap.goryoMode)
		{
			switch (GameSettings.difficulty)
			{
			case 3:
				switch (monster)
				{
				case 23:
					if (addIdx % 6 == 0)
					{
						monster = 2;
					}
					break;
				case 27:
					if (addIdx % 4 == 0)
					{
						monster = 5;
					}
					break;
				case 48:
					if (addIdx % 2 == 0)
					{
						monster = 27;
					}
					break;
				case 24:
					if (addIdx % 8 == 0)
					{
						monster = 34;
						flag = true;
					}
					break;
				case 12:
					if (addIdx % 8 == 0)
					{
						monster = 34;
						flag = true;
					}
					break;
				case 4:
					if (addIdx % 4 == 0)
					{
						monster = 11;
					}
					break;
				case 5:
					if (addIdx % 2 == 0)
					{
						monster = 59;
					}
					break;
				}
				break;
			case 4:
				switch (monster)
				{
				case 23:
					if (addIdx % 2 == 0)
					{
						monster = 2;
					}
					break;
				case 0:
					if (addIdx % 2 == 0)
					{
						monster = 27;
					}
					break;
				case 48:
					monster = 24;
					break;
				case 27:
					if (addIdx % 2 == 0)
					{
						monster = 60;
					}
					break;
				case 1:
					if (addIdx % 2 == 0)
					{
						monster = 24;
					}
					break;
				case 24:
					if (addIdx % 4 == 0)
					{
						monster = 34;
						flag = true;
					}
					else
					{
						monster = 60;
					}
					break;
				case 2:
					if (addIdx % 4 == 0)
					{
						monster = 21;
					}
					break;
				case 46:
					if (addIdx % 4 == 0)
					{
						monster = 14;
					}
					break;
				case 21:
					if (addIdx % 4 == 0)
					{
						monster = 20;
						flag = true;
					}
					break;
				case 12:
					if (addIdx % 4 == 0)
					{
						monster = 34;
						flag = true;
					}
					break;
				case 4:
					if (addIdx % 2 == 0)
					{
						monster = 11;
					}
					break;
				case 5:
					if (addIdx % 4 == 0)
					{
						monster = 31;
						flag = true;
					}
					break;
				}
				break;
			}
		}
		if (Game1.gameMap.goryoMode && Game1.gameMap.theme.theme == Themes.ThemeType.Aquarium)
		{
			flag = true;
		}
		addIdx = (addIdx + 1) % 10;
		items.Add(new BucketItem(loc, monster));
		if (Game1.GetPlayers() >= 2 && addIdx % 2 == 0)
		{
			items.Add(new BucketItem(loc, monster));
		}
		if (flag)
		{
			return;
		}
		switch (GameSettings.difficulty)
		{
		case 3:
			if (addIdx % 6 == 0)
			{
				items.Add(new BucketItem(loc, monster));
			}
			break;
		case 4:
		case 5:
			if (addIdx % 3 == 0)
			{
				items.Add(new BucketItem(loc, monster));
			}
			break;
		}
	}

	public bool IsDone()
	{
		if (done)
		{
			for (int i = 0; i < Game1.character.Length; i++)
			{
				if (Game1.character[i].exists && Game1.character[i].team == Character.Team.BadGuys && !Game1.character[i].GetMeta().isPuppeteer && !Game1.character[i].charUpdate.inactive)
				{
					return false;
				}
			}
			return true;
		}
		return false;
	}

	public void Update()
	{
		if ((Game1.levelMgr.currentTrack == 6 || Game1.levelMgr.currentTrack == 5) && !Game1.character[4].exists)
		{
			int randomInt = Rand.GetRandomInt(0, 5);
			int monster = 27;
			switch (randomInt)
			{
			case 0:
				monster = 23;
				break;
			case 1:
				monster = 27;
				break;
			case 2:
				monster = 5;
				break;
			case 3:
				monster = 0;
				break;
			case 4:
				monster = 48;
				break;
			}
			Game1.spawnMgr.SpawnMonster(Rand.GetRandomVec2(100f, 500f, 128f, 128f), monster, null);
		}
		if (active)
		{
			int num = 0;
			int num2 = 0;
			for (int i = 0; i < Game1.character.Length; i++)
			{
				if (Game1.character[i].exists && !Game1.character[i].charUpdate.inactive && !Game1.character[i].effectivelyDead && (Game1.character[i].charUpdate.hp >= 0f || Game1.character[i].charUpdate.slammedFrame > 0f || Game1.character[i].GetMeta().isPuppet) && Game1.character[i].team == Character.Team.BadGuys)
				{
					num++;
					if (Game1.character[i].GetMeta().isBoss && Game1.gameMap.lichFreakoutMode)
					{
						num--;
					}
					else if (Game1.character[i].GetMeta().isPuppeteer)
					{
						num--;
					}
				}
				if (Game1.character[i].exists && !Game1.character[i].effectivelyDead && !Game1.character[i].charUpdate.inactive && Game1.character[i].team == Character.Team.BadGuys)
				{
					num2++;
					if (Game1.character[i].GetMeta().isBoss && Game1.gameMap.lichFreakoutMode)
					{
						num2--;
					}
					else if (Game1.character[i].GetMeta().isPuppeteer)
					{
						num2--;
					}
				}
			}
			if (num < lim)
			{
				if (items.Count > 0)
				{
					int num3 = items.Count;
					if (num3 > 6)
					{
						num3 = 6;
					}
					int randomInt2 = Rand.GetRandomInt(0, num3);
					Game1.spawnMgr.SpawnMonster(items[randomInt2].loc, items[randomInt2].monster, null);
					items.Remove(items[randomInt2]);
				}
				else if (num2 == 0)
				{
					active = false;
					done = true;
					Game1.hud.DefeatWave();
					if (!Game1.gameMap.lichFreakoutMode)
					{
						Game1.ReviveChars();
					}
				}
			}
		}
		if (!Game1.netSession.IsClient() && !active && Game1.gameMap.lichFreakoutMode)
		{
			Game1.gameMap.lichFreakoutMode = false;
			QuakeManager.SetBright(1f);
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			Game1.spriteMan.Reset();
			RepairLich();
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.EndLichFreakout(Game1.netSession.session);
			}
		}
	}

	private void RepairLich()
	{
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (Game1.character[i].exists && Game1.character[i].charMeta == 21)
			{
				Character character = Game1.character[i];
				character.exists = true;
				if (character.charUpdate.loc.Y > (float)Game1.gameMap.CurMap().ySize * 64f)
				{
					character.charUpdate.loc.Y = (float)Game1.gameMap.CurMap().ySize * 64f / 2f;
				}
				if (character.charUpdate.loc.Y < 0f)
				{
					character.charUpdate.loc.Y = (float)Game1.gameMap.CurMap().ySize * 64f / 2f;
				}
				if (character.charUpdate.loc.X > (float)Game1.gameMap.CurMap().xSize * 64f)
				{
					character.charUpdate.loc.X = (float)Game1.gameMap.CurMap().xSize * 64f / 2f;
				}
				if (character.charUpdate.loc.X < 0f)
				{
					character.charUpdate.loc.X = (float)Game1.gameMap.CurMap().xSize * 64f / 2f;
				}
				return;
			}
		}
		Game1.spawnMgr.SpawnMonster(new Vector2((float)Game1.gameMap.CurMap().xSize * 64f / 2f, (float)Game1.gameMap.CurMap().ySize * 64f / 2f), 9, "lich");
	}

	internal void KillBucket()
	{
		Game1.gameMap.bucketKillMode = true;
		for (int i = 0; i < Game1.character.Length; i++)
		{
			Character character = Game1.character[i];
			if (character.team != Character.Team.BadGuys || character.tag != null)
			{
				continue;
			}
			if (character.charUpdate.hp > -10f)
			{
				character.charUpdate.hp = -10f;
			}
			if (!character.charUpdate.ethereal && character.charUpdate.charGrab.grabbedByChar < 0)
			{
				if (character.charAnim.CheckAnim("jhit") > -1)
				{
					character.charAnim.SetAnim("jhit", character.charUpdate, overRide: true);
					character.charUpdate.traj = Rand.GetRandomVec2(-50f, 50f, -600f, -500f);
					character.charUpdate.state = CharUpdate.State.Airborne;
				}
				else if (character.charAnim.CheckAnim("exe") > -1)
				{
					character.charAnim.SetAnim("exe", character.charUpdate, overRide: true);
				}
			}
		}
		done = true;
		active = false;
	}
}
