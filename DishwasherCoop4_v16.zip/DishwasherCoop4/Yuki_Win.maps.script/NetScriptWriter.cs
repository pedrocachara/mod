using Microsoft.Xna.Framework.Net;
using Yuki_Win.netplay;

namespace Yuki_Win.maps.script;

public class NetScriptWriter
{
	public int[] lineToWrite;

	public int totalLines;

	public NetScriptWriter()
	{
		lineToWrite = new int[128];
	}

	public void AddLine(int i)
	{
		if (totalLines < lineToWrite.Length)
		{
			lineToWrite[totalLines] = i;
			totalLines++;
		}
	}

	public bool CanWrite()
	{
		return totalLines > 0;
	}

	internal bool NetWrite(PacketWriter writer)
	{
		if (totalLines > 0)
		{
			NetPacker.WriteByte(writer, 13);
			writer.Write(Game1.gameMap.curMap);
			NetPacker.WriteByte(writer, totalLines);
			for (int i = 0; i < totalLines; i++)
			{
				NetPacker.WriteByte(writer, lineToWrite[i]);
			}
			totalLines = 0;
			return true;
		}
		return false;
	}
}
