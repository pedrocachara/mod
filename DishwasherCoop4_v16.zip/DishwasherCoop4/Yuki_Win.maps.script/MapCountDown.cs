namespace Yuki_Win.maps.script;

public class MapCountDown
{
	public const int STATE_INACTIVE = 0;

	public const int STATE_COUNTING = 1;

	public const int STATE_SUCCESS = 2;

	public const int STATE_FAIL = 3;

	public float countDownFrame;

	public int state;

	public void Reset()
	{
		state = 0;
	}

	public void Start(float time)
	{
		state = 1;
		countDownFrame = time;
	}

	public bool GetActive()
	{
		return state == 1;
	}

	public void Update()
	{
		if (state == 0 || Game1.hud.IsEndLevel() || Game1.hud.IsArcadeIn() || GameState.state == GameState.State.Menu || Game1.sceneMgr.playing || Game1.hud.invMgr.IsActive() || Game1.hud.shopMgr.IsActive())
		{
			return;
		}
		int num = state;
		if (num == 1)
		{
			countDownFrame -= FMan.frameTime;
			if (countDownFrame < 0f)
			{
				state = 3;
			}
		}
	}

	public void EndCountDown()
	{
		if (state == 1)
		{
			state = 2;
		}
	}

	public bool GetSuccess()
	{
		return state == 2;
	}

	public bool GetFail()
	{
		return state == 3;
	}
}
