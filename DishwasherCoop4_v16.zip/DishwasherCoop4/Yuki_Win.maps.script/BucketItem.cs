using Microsoft.Xna.Framework;

namespace Yuki_Win.maps.script;

public class BucketItem
{
	public const int GUARD = 0;

	public const int SWAT = 1;

	public const int BLADE = 2;

	public const int TANK = 3;

	public const int POD = 4;

	public const int NINJA = 5;

	public const int ZOMBIE = 6;

	public const int CRETIN = 7;

	public const int WARDEN = 8;

	public const int LICH = 9;

	public const int GOREFACE = 10;

	public const int APPLE2 = 11;

	public const int PODBOT = 12;

	public const int SLAVA = 13;

	public const int PUMPKINHEAD = 14;

	public const int SKELETANK = 15;

	public const int BANKER = 16;

	public const int FORCE = 17;

	public const int BOX = 18;

	public const int MURDERFLY = 19;

	public const int WARCLONE = 20;

	public const int PYRO = 21;

	public const int GENERAL = 22;

	public const int GOON = 23;

	public const int FREAK = 24;

	public const int HOCKEY = 25;

	public const int GHOST = 26;

	public const int MOOK = 27;

	public const int SHARK = 28;

	public const int DRAGON = 29;

	public const int DRAGONCLAW = 30;

	public const int SACKBOY = 31;

	public const int INVALID = 32;

	public const int SHOP = 33;

	public const int SAMURAI = 34;

	public const int SQUID = 35;

	public const int CORPSE = 36;

	public const int JUDGE = 37;

	public const int ENGINEER = 38;

	public const int GOONPUPPET = 39;

	public const int SWATPUPPET = 40;

	public const int BIGENGIE = 41;

	public const int HORSE = 42;

	public const int ENGIE2 = 43;

	public const int MIDENGIE = 44;

	public const int MURDERBUG = 45;

	public const int GHOUL = 46;

	public const int SWORDSMAN = 47;

	public const int THUG = 48;

	public const int HACKBOT = 49;

	public const int CHEF = 50;

	public const int USLAVA = 51;

	public const int RAVEN = 52;

	public const int TRANSMARA = 53;

	public const int HYPNO = 54;

	public const int YUKINPC = 55;

	public const int ASSASSIN = 56;

	public const int GUITAR = 57;

	public const int VIOLIN = 58;

	public const int PREDATOR = 59;

	public const int RAPTOR = 60;

	public const int INMATE = 61;

	public Vector2 loc;

	public int monster;

	public BucketItem(Vector2 loc, int monster)
	{
		this.loc = loc;
		this.monster = monster;
	}
}
