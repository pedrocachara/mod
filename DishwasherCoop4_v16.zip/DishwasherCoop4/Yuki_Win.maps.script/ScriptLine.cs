using System;
using Yuki_Win.hud;

namespace Yuki_Win.maps.script;

public class ScriptLine
{
	public string[] line;

	public int[] iParam;

	public ScriptLine(string s)
	{
		line = s.Split(' ');
		iParam = new int[line.Length];
		for (int i = 0; i < iParam.Length; i++)
		{
			iParam[i] = int.MinValue;
		}
	}

	public int GetIParam(int i)
	{
		if (i < line.Length)
		{
			try
			{
				if (iParam[i] == int.MinValue)
				{
					iParam[i] = Convert.ToInt32(line[i]);
				}
				return iParam[i];
			}
			catch (Exception ex)
			{
				Printf.WriteLine(ex.ToString());
				return 0;
			}
		}
		return 0;
	}

	public string GetSParam(int i)
	{
		if (i < line.Length)
		{
			return line[i];
		}
		return "";
	}
}
