using System;
using System.Collections.Generic;
using System.IO;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.director;
using Yuki_Win.gameRender;
using Yuki_Win.hud;
using Yuki_Win.player;
using Yuki_Win.world;

namespace Yuki_Win.maps.script;

public class ScriptManager
{
	private List<ScriptLine> scriptLine;

	public int curLine;

	public float wait;

	public bool reading;

	private List<string> flags;

	public bool resetNecessary;

	private NetScriptWriter netScriptWriter;

	private NetScriptReader netScriptReader;

	private short mapHash;

	public MapCountDown mapCountDown;

	public bool mapHasZombiesInIt;

	public ScriptManager()
	{
		scriptLine = new List<ScriptLine>();
		flags = new List<string>();
		netScriptWriter = new NetScriptWriter();
		netScriptReader = new NetScriptReader();
		mapCountDown = new MapCountDown();
	}

	public void Reset()
	{
		reading = false;
		mapCountDown.Reset();
		if (scriptLine != null && scriptLine.Count > 0)
		{
			curLine = 0;
			wait = 0f;
			reading = true;
		}
		flags.Clear();
	}

	public void Init(BinaryReader reader)
	{
		scriptLine.Clear();
		flags.Clear();
		wait = 0f;
		curLine = 0;
		mapCountDown.Reset();
		for (int i = 0; i < 1024; i++)
		{
			string text = reader.ReadString();
			if (text != null && text != "")
			{
				scriptLine.Add(new ScriptLine(text));
				reading = true;
				if (text == "setmaptheme descent")
				{
					resetNecessary = true;
				}
				if (text == "startlift")
				{
					resetNecessary = true;
				}
				if (text.StartsWith("addbucket zombie") || text.StartsWith("addbucket ghoul"))
				{
					mapHasZombiesInIt = true;
				}
			}
		}
	}

	public void SetFlag(string s)
	{
		if (!flags.Contains(s))
		{
			flags.Add(s);
		}
	}

	public bool GetFlag(string s)
	{
		return flags.Contains(s);
	}

	public string AutoDesylum()
	{
		for (int i = 0; i < scriptLine.Count; i++)
		{
			if (scriptLine[i].line[0] == "desylum")
			{
				return scriptLine[i].line[1];
			}
		}
		return "";
	}

	private bool GotoTag(string tag)
	{
		for (int i = 0; i < scriptLine.Count; i++)
		{
			if (scriptLine[i].line[0] == "#tag" && scriptLine[i].line[1] == tag)
			{
				curLine = i;
				return true;
			}
		}
		return false;
	}

	private bool AdvanceToEnd(string end)
	{
		bool flag = false;
		while (!flag)
		{
			curLine++;
			if (curLine >= scriptLine.Count)
			{
				reading = false;
				flag = true;
				return false;
			}
			if (scriptLine[curLine].line[0] == end)
			{
				return true;
			}
		}
		return false;
	}

	private bool CanExecute(int line, bool netInduced)
	{
		if (Game1.netSession.IsHost())
		{
			netScriptWriter.AddLine(line);
			return true;
		}
		if (Game1.netSession.IsClient())
		{
			return netInduced;
		}
		return true;
	}

	public bool ExecuteLine(int line)
	{
		return ExecuteLine(line, netInduced: false);
	}

	public bool ExecuteLine(int line, bool netInduced)
	{
		bool result = false;
		int num = -1;
		switch (scriptLine[line].line[0])
		{
		case "#ifneeds":
		{
			bool flag3 = true;
			for (int num25 = 0; num25 < Game1.GetPlayers(); num25++)
			{
				if (Game1.character[num25].exists && Game1.hud.invMgr.inv[num25].GetItemCount(Game1.invCatalog.GetNameFromName(scriptLine[line].GetSParam(1))) <= 0)
				{
					flag3 = false;
				}
			}
			if (Game1.netSession.IsClient())
			{
				flag3 = false;
			}
			if (Game1.netSession.IsHost())
			{
				flag3 = Game1.levelMgr.GetGlobalFlag("netbead" + scriptLine[line].GetSParam(1).ToLower());
			}
			if (flag3 && !AdvanceToEnd("#endif"))
			{
				result = true;
			}
			break;
		}
		case "#dish":
			if (!Game1.levelMgr.GetGlobalFlag("dish") && !AdvanceToEnd("#enddish"))
			{
				result = true;
			}
			break;
		case "#coop":
			if (!Game1.levelMgr.GetGlobalFlag("coop") && !AdvanceToEnd("#endcoop"))
			{
				result = true;
			}
			break;
		case "#solo":
			if (Game1.levelMgr.GetGlobalFlag("coop") && !AdvanceToEnd("#endsolo"))
			{
				result = true;
			}
			break;
		case "#yuki":
			if (!Game1.levelMgr.GetGlobalFlag("yuki") && !AdvanceToEnd("#endyuki"))
			{
				result = true;
			}
			break;
		case "setflag":
			if (CanExecute(line, netInduced))
			{
				SetFlag(scriptLine[line].GetSParam(1));
			}
			break;
		case "setglobalflag":
			if (CanExecute(line, netInduced))
			{
				Game1.levelMgr.SetGlobalFlag(scriptLine[line].GetSParam(1));
			}
			break;
		case "setuberflag":
			if (CanExecute(line, netInduced))
			{
				MainPlayer.SetUberFlag(scriptLine[line].GetSParam(1));
			}
			break;
		case "setyukiphase":
			if (CanExecute(line, netInduced))
			{
				Game1.player.SetYukiPhase(scriptLine[line].GetSParam(1));
			}
			break;
		case "yukigetup":
			Game1.player.SetYukiPhase(1);
			Game1.character[0].charMeta = (Game1.character[0].charAnim.charMeta = 11);
			Game1.character[0].cDef = (Game1.character[0].charAnim.charDef = 7);
			Game1.character[0].charAnim.SetAnim("getup", Game1.character[0].charUpdate);
			Game1.character[0].charUpdate.face = 1;
			Game1.character[0].loadOut = 0;
			break;
		case "arrowsoff":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.arrowsOff = true;
			}
			break;
		case "arrowson":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.arrowsOff = false;
			}
			break;
		case "faceleft":
		{
			for (int j = 0; j < 4; j++)
			{
				if (Game1.character[j].exists)
				{
					Game1.character[j].charUpdate.face = 0;
				}
			}
			break;
		}
		case "guitar":
			switch (Game1.levelMgr.currentTrack)
			{
			case 0:
				Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), 58, scriptLine[line].GetSParam(1));
				break;
			case 1:
				Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), 57, scriptLine[line].GetSParam(1));
				break;
			case 2:
			{
				float num4 = 30f;
				Game1.spawnMgr.SpawnMonster(new Vector2((float)scriptLine[line].GetIParam(2) - num4, scriptLine[line].GetIParam(3)), 58, scriptLine[line].GetSParam(1));
				Game1.spawnMgr.SpawnMonster(new Vector2((float)scriptLine[line].GetIParam(2) + num4, scriptLine[line].GetIParam(3)), 57, scriptLine[line].GetSParam(1));
				break;
			}
			}
			break;
		case "beatdown":
		{
			Vector2 loc = new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3));
			int num28 = Game1.spawnMgr.SpawnMonster(loc, SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)), "");
			int num29 = Game1.spawnMgr.SpawnMonster(loc, 61, "");
			if (num28 > -1 && num29 > -1)
			{
				Game1.character[num28].FloorMe(loc);
				Game1.character[num29].FloorMe(loc);
				Game1.character[num28].charAnim.SetAnim(scriptLine[line].GetSParam(4), Game1.character[num28].charUpdate);
				Game1.character[num28].charUpdate.charGrab.grabbedByChar = num29;
				Game1.character[num29].charUpdate.charGrab.grabbing = true;
				Game1.character[num28].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				Game1.character[num29].charUpdate.face = Rand.GetRandomInt(0, 2);
				Game1.character[num28].charUpdate.face = 1 - Game1.character[num29].charUpdate.face;
			}
			break;
		}
		case "setdishphase":
			if (CanExecute(line, netInduced))
			{
				Game1.player.SetDishPhase(scriptLine[line].GetSParam(1));
			}
			break;
		case "ground":
		{
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			for (int num23 = 0; num23 < 2; num23++)
			{
				if (Game1.character[num23].exists)
				{
					Game1.character[num23].FloorMe(Game1.character[num23].charUpdate.loc);
				}
			}
			break;
		}
		case "slavachase":
		{
			Game1.gameMap.slavachase = true;
			int num17 = Game1.spawnMgr.SpawnMonster(new Vector2(0f, Game1.character[0].charUpdate.loc.Y), 13, "chase");
			if (num17 > -1)
			{
				Game1.character[num17].FloorMe(Game1.character[num17].charUpdate.loc);
				Game1.character[num17].charAnim.SetAnim("chase", Game1.character[num17].charUpdate);
			}
			break;
		}
		case "facedown":
		{
			for (int num12 = 0; num12 < 2; num12++)
			{
				if (Game1.character[num12].exists)
				{
					Game1.character[num12].FloorMe(Game1.character[num12].charUpdate.loc);
					Character character3 = Game1.character[num12];
					character3.charAnim.SetAnim("desylum", character3.charUpdate);
					for (int num13 = 0; num13 < 30; num13++)
					{
						float randomFloat = Rand.GetRandomFloat(0f, 6.28f);
						Vector2 vector = new Vector2((float)Math.Cos(randomFloat), (float)Math.Sin(randomFloat)) * 600f;
						Game1.spriteMan.AddSprite(59, Game1.character[num12].charUpdate.loc - vector, Game1.character[num12].charUpdate.loc + vector, 1f, 0, num12);
						Game1.gameMap.electricInFrame = 1f;
						QuakeManager.SetBright(0.5f);
					}
					Sound.PlaySnd(Sound.Category.FX, "zexplode");
					FMan.slowFrame = 0.1f;
				}
			}
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			break;
		}
		case "larry":
			if (CanExecute(line, netInduced))
			{
				Sound.PlayLarry();
			}
			break;
		case "moaner":
			Game1.gameMap.moaner = true;
			Game1.gameMap.moanframe = 0f;
			break;
		case "musicramp":
			Game1.gameMap.musicRamp = true;
			Game1.gameMap.musicRampMin = scriptLine[line].GetIParam(1);
			Game1.gameMap.musicRampMax = scriptLine[line].GetIParam(2);
			break;
		case "foremonster":
			Game1.gameMap.foregroundMgr.AddCharacter(scriptLine[line].GetSParam(1), new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), scriptLine[line].GetIParam(4));
			break;
		case "starttrans":
			Game1.transMgr.DoTrans("prison1", new Vector2(100f, 300f));
			break;
		case "xtrap":
		{
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			bool flag4 = false;
			for (int num33 = 0; num33 < 2; num33++)
			{
				if (!Game1.character[num33].exists)
				{
					continue;
				}
				float x2 = Game1.character[num33].charUpdate.loc.X;
				if (!(x2 > (float)scriptLine[line].GetIParam(1)) || !(x2 < (float)scriptLine[line].GetIParam(2)))
				{
					continue;
				}
				if (Game1.character[1 - num33].exists)
				{
					ClickToLoc(num33);
					if (num33 == 0 && Game1.netSession.IsHost())
					{
						Game1.netSession.netGame.SendClickToHostLoc(Game1.netSession.session);
					}
				}
				flag4 = true;
			}
			if (!flag4)
			{
				if (!netInduced)
				{
					curLine--;
				}
				result = true;
			}
			break;
		}
		case "skullfarm":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.skullFarm = true;
			}
			break;
		case "ytrap":
		{
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			bool flag2 = false;
			for (int num20 = 0; num20 < 2; num20++)
			{
				if (!Game1.character[num20].exists)
				{
					continue;
				}
				float y2 = Game1.character[num20].charUpdate.loc.Y;
				if (y2 > (float)scriptLine[line].GetIParam(1) && y2 < (float)scriptLine[line].GetIParam(2))
				{
					if (Game1.character[1 - num20].exists)
					{
						Game1.character[1 - num20].charUpdate.loc = Game1.character[num20].charUpdate.loc;
						Game1.character[1 - num20].charUpdate.state = CharUpdate.State.Airborne;
						Game1.character[1 - num20].charAnim.SetAnim(Game1.character[1 - num20].GetMeta().flip_anim, Game1.character[1 - num20].charUpdate);
					}
					flag2 = true;
				}
			}
			if (!flag2)
			{
				if (!netInduced)
				{
					curLine--;
				}
				result = true;
			}
			break;
		}
		case "xytrap":
		{
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			bool flag = false;
			for (int num8 = 0; num8 < 2; num8++)
			{
				if (!Game1.character[num8].exists)
				{
					continue;
				}
				float x = Game1.character[num8].charUpdate.loc.X;
				if (!(x > (float)scriptLine[line].GetIParam(1)) || !(x < (float)scriptLine[line].GetIParam(2)))
				{
					continue;
				}
				float y = Game1.character[num8].charUpdate.loc.Y;
				if (y > (float)scriptLine[line].GetIParam(3) && y < (float)scriptLine[line].GetIParam(4))
				{
					if (Game1.character[1 - num8].exists)
					{
						Game1.character[1 - num8].charUpdate.loc = Game1.character[num8].charUpdate.loc;
						Game1.character[1 - num8].charUpdate.state = CharUpdate.State.Airborne;
						Game1.character[1 - num8].charAnim.SetAnim(Game1.character[1 - num8].GetMeta().flip_anim, Game1.character[1 - num8].charUpdate);
					}
					flag = true;
				}
			}
			if (!flag)
			{
				if (!netInduced)
				{
					curLine--;
				}
				result = true;
			}
			break;
		}
		case "transmap":
			if (CanExecute(line, netInduced))
			{
				Game1.transMgr.DoTrans(scriptLine[line].GetSParam(1), new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)));
			}
			break;
		case "open":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().layer[2].segment[scriptLine[line].GetIParam(1)].open = true;
				Game1.gameMap.CurMap().layer[2].segment[scriptLine[line].GetIParam(1)].frame = 1f;
			}
			break;
		case "close":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().layer[2].segment[scriptLine[line].GetIParam(1)].open = false;
				Game1.gameMap.CurMap().layer[2].segment[scriptLine[line].GetIParam(1)].frame = 1f;
			}
			break;
		case "setopen":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().layer[2].segment[scriptLine[line].GetIParam(1)].open = true;
			}
			break;
		case "setclose":
		case "setclosed":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().layer[2].segment[scriptLine[line].GetIParam(1)].open = false;
			}
			break;
		case "alert":
			Game1.gameMap.alert = true;
			break;
		case "imonster":
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			num = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)), scriptLine[line].GetSParam(4));
			if (num <= -1)
			{
				break;
			}
			Game1.character[num].FloorMe(Game1.character[num].charUpdate.loc);
			Game1.character[num].charAnim.SetAnim(Game1.character[num].GetMeta().inactive_anim, Game1.character[num].charUpdate);
			Game1.character[num].charUpdate.inactive = true;
			if (Game1.character[num].charUpdate.loc.X > Game1.character[0].charUpdate.loc.X)
			{
				Game1.character[num].charUpdate.face = 0;
			}
			else
			{
				Game1.character[num].charUpdate.face = 1;
			}
			if (Game1.character[num].GetMeta().alwaysRight)
			{
				Game1.character[num].charUpdate.face = 1;
			}
			if (Game1.character[num].GetMeta().inactiveFaceCenter)
			{
				if (Game1.character[num].charUpdate.loc.X > (float)Game1.gameMap.CurMap().xSize * 64f * 0.5f)
				{
					Game1.character[num].charUpdate.face = 0;
				}
				else
				{
					Game1.character[num].charUpdate.face = 1;
				}
			}
			break;
		case "lmonster":
			if (CanExecute(line, netInduced))
			{
				Game1.spawnMgr.SpawnLockedMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)), scriptLine[line].GetSParam(4));
			}
			break;
		case "nosplatter":
			Game1.gameMap.nosplatter = true;
			break;
		case "pickup":
			if (CanExecute(line, netInduced))
			{
				num = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)), scriptLine[line].GetSParam(4));
				if (num > -1)
				{
					Game1.character[num].reward = Character.Reward.Pickup;
				}
			}
			break;
		case "noprize":
			Game1.gameMap.noprize = true;
			break;
		case "crazyin":
			Game1.gameMap.CrazyTransitionInFrame = 5f;
			ScrollManager.zoom = 0.01f;
			break;
		case "finaltrans":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.dishTransOutFrame = 1f;
				Game1.gameMap.dishTransOutDest = "final";
			}
			break;
		case "judgetrans":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.dishTransOutFrame = 1f;
				Game1.gameMap.dishTransOutDest = "judge";
			}
			break;
		case "gpickup":
			if (CanExecute(line, netInduced))
			{
				num = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)), scriptLine[line].GetSParam(4));
				if (num > -1)
				{
					Game1.character[num].reward = Character.Reward.Pickup;
					Game1.character[num].FloorMe(Game1.character[num].charUpdate.loc);
				}
			}
			break;
		case "monster":
			if (CanExecute(line, netInduced))
			{
				num = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)), scriptLine[line].GetSParam(4));
				if (num > -1 && (!(ScrollManager.GetScreenLoc(Game1.character[num].charUpdate.loc, 1f).X > 0f) || !(ScrollManager.GetScreenLoc(Game1.character[num].charUpdate.loc, 1f).X < ScrollManager.screenSize.X)))
				{
					Game1.character[num].FloorMe(Game1.character[num].charUpdate.loc);
				}
			}
			break;
		case "amonster":
			if (Game1.netSession.IsClient())
			{
				break;
			}
			num = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)), scriptLine[line].GetSParam(4));
			if (num > -1)
			{
				Game1.character[num].charAnim.SetAnim(Game1.character[num].GetMeta().activate_anim, Game1.character[num].charUpdate);
				if (Game1.character[num].charUpdate.loc.X > Game1.character[0].charUpdate.loc.X)
				{
					Game1.character[num].charUpdate.face = 0;
				}
				else
				{
					Game1.character[num].charUpdate.face = 1;
				}
				if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off && Game1.character[num].GetMeta().toast1 != null)
				{
					Game1.camMgr.bossToast.Init(Game1.character[num].GetMeta().toast1, Game1.character[num].GetMeta().toast2, num);
				}
			}
			break;
		case "end":
			reading = false;
			result = true;
			break;
		case "hideseg":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().layer[2].segment[scriptLine[line].GetIParam(1)].hidden = true;
			}
			break;
		case "showseg":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().layer[2].segment[scriptLine[line].GetIParam(1)].hidden = false;
			}
			break;
		case "hideforeseg":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().layer[3].segment[scriptLine[line].GetIParam(1)].hidden = true;
			}
			break;
		case "showforeseg":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().layer[3].segment[scriptLine[line].GetIParam(1)].hidden = false;
			}
			break;
		case "killcol":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().collision[scriptLine[line].GetIParam(1), scriptLine[line].GetIParam(2)] = Map.Collision.None;
			}
			break;
		case "setcol":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().collision[scriptLine[line].GetIParam(1), scriptLine[line].GetIParam(2)] = Map.Collision.Full;
			}
			break;
		case "killycol":
			if (CanExecute(line, netInduced))
			{
				int iParam3 = scriptLine[line].GetIParam(1);
				int iParam4 = scriptLine[line].GetIParam(2);
				int num3 = scriptLine[line].GetIParam(3) + 1;
				for (int m = iParam4; m < num3; m++)
				{
					Game1.gameMap.CurMap().collision[iParam3, m] = Map.Collision.None;
				}
			}
			break;
		case "setycol":
			if (CanExecute(line, netInduced))
			{
				int iParam = scriptLine[line].GetIParam(1);
				int iParam2 = scriptLine[line].GetIParam(2);
				int num2 = scriptLine[line].GetIParam(3) + 1;
				for (int l = iParam2; l < num2; l++)
				{
					Game1.gameMap.CurMap().collision[iParam, l] = Map.Collision.Full;
				}
			}
			break;
		case "setpipe":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.CurMap().collision[scriptLine[line].GetIParam(1), scriptLine[line].GetIParam(2)] = Map.Collision.Pipe;
			}
			break;
		case "ifubertruegoto":
			if (!Game1.netSession.IsClient() && MainPlayer.GetUberFlag(scriptLine[line].GetSParam(1)))
			{
				GotoTag(scriptLine[line].GetSParam(2));
			}
			break;
		case "ifuberfalsegoto":
			if (!Game1.netSession.IsClient() && !MainPlayer.GetUberFlag(scriptLine[line].GetSParam(1)))
			{
				GotoTag(scriptLine[line].GetSParam(2));
			}
			break;
		case "ifglobaltruegoto":
			if (!Game1.netSession.IsClient() && Game1.levelMgr.GetGlobalFlag(scriptLine[line].GetSParam(1)))
			{
				GotoTag(scriptLine[line].GetSParam(2));
			}
			break;
		case "ifglobalfalsegoto":
			if (!Game1.netSession.IsClient() && !Game1.levelMgr.GetGlobalFlag(scriptLine[line].GetSParam(1)))
			{
				GotoTag(scriptLine[line].GetSParam(2));
			}
			break;
		case "iftruegoto":
			if (!Game1.netSession.IsClient() && GetFlag(scriptLine[line].GetSParam(1)))
			{
				GotoTag(scriptLine[line].GetSParam(2));
			}
			break;
		case "ifcountdowngoto":
			if (!Game1.netSession.IsClient() && mapCountDown.GetSuccess())
			{
				GotoTag(scriptLine[line].GetSParam(1));
			}
			break;
		case "ifcountfailgoto":
			if (!Game1.netSession.IsClient() && mapCountDown.GetFail())
			{
				GotoTag(scriptLine[line].GetSParam(1));
			}
			break;
		case "iffalsegoto":
			if (!Game1.netSession.IsClient() && !GetFlag(scriptLine[line].GetSParam(1)))
			{
				GotoTag(scriptLine[line].GetSParam(2));
			}
			break;
		case "goto":
			if (!Game1.netSession.IsClient())
			{
				GotoTag(scriptLine[line].GetSParam(1));
			}
			break;
		case "use":
			if (CanExecute(line, netInduced))
			{
				Game1.hud.DoPickups(scriptLine[line].GetSParam(1), used: true);
			}
			break;
		case "cscream":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.chairScreamMode = true;
				Game1.gameMap.scriptTrigX = scriptLine[line].GetIParam(1);
				Game1.gameMap.scriptDestMap = scriptLine[line].GetSParam(2);
				Game1.gameMap.scriptDestWorld = scriptLine[line].GetSParam(3);
			}
			break;
		case "setscriptdest":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.scriptDestMap = scriptLine[line].GetSParam(1);
				Game1.gameMap.scriptDestWorld = scriptLine[line].GetSParam(2);
			}
			break;
		case "killmonsters":
		{
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			for (int num16 = 0; num16 < Game1.character.Length; num16++)
			{
				if (Game1.character[num16].exists && Game1.character[num16].team == Character.Team.BadGuys && Game1.character[num16].charUpdate.hp > -1f)
				{
					Game1.character[num16].charUpdate.hp = -1f;
				}
			}
			break;
		}
		case "activate":
		{
			if (Game1.netSession.IsClient())
			{
				break;
			}
			for (int num15 = 0; num15 < Game1.character.Length; num15++)
			{
				if (Game1.character[num15].exists && Game1.character[num15].tag != null && Game1.character[num15].tag == scriptLine[line].GetSParam(1))
				{
					Game1.character[num15].charUpdate.inactive = false;
					Game1.character[num15].charAnim.SetAnim(Game1.character[num15].GetMeta().idle_anim, Game1.character[num15].charUpdate);
					Game1.character[num15].charAnim.SetAnim(Game1.character[num15].GetMeta().activate_anim, Game1.character[num15].charUpdate);
					if (Game1.character[num15].charUpdate.loc.X > Game1.character[0].charUpdate.loc.X)
					{
						Game1.character[num15].charUpdate.face = 0;
					}
					else
					{
						Game1.character[num15].charUpdate.face = 1;
					}
					Game1.character[num15].charUpdate.nomusic = false;
					if (Game1.character[num15].GetMeta().toast1 != null)
					{
						Game1.camMgr.bossToast.Init(Game1.character[num15].GetMeta().toast1, Game1.character[num15].GetMeta().toast2, num15);
					}
				}
			}
			break;
		}
		case "redlights":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.redlights = true;
			}
			break;
		case "quirk":
		{
			float quirk = (float)scriptLine[line].GetIParam(1) / 100f;
			QuakeManager.SetQuirk(quirk);
			break;
		}
		case "normallights":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.redlights = false;
				Game1.gameMap.actuallyBlueLights = false;
			}
			break;
		case "quietactivate":
		{
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			for (int num9 = 0; num9 < Game1.character.Length; num9++)
			{
				if (Game1.character[num9].exists && Game1.character[num9].tag != null && Game1.character[num9].tag == scriptLine[line].GetSParam(1))
				{
					Game1.character[num9].charUpdate.inactive = false;
					Game1.character[num9].charAnim.SetAnim(Game1.character[num9].GetMeta().idle_anim, Game1.character[num9].charUpdate);
					Game1.character[num9].charAnim.SetAnim(Game1.character[num9].GetMeta().activate_anim, Game1.character[num9].charUpdate);
					if (Game1.character[num9].charUpdate.loc.X > Game1.character[0].charUpdate.loc.X)
					{
						Game1.character[num9].charUpdate.face = 0;
					}
					else
					{
						Game1.character[num9].charUpdate.face = 1;
					}
				}
			}
			break;
		}
		case "chair":
		{
			for (int num7 = 4; num7 < Game1.character.Length; num7++)
			{
				if (!Game1.character[num7].exists)
				{
					Game1.character[num7].Init(6, Game1.character[0].charUpdate.loc + new Vector2(scriptLine[line].GetIParam(1), 0f), 12, -1, Character.Team.GoodGuys, -1);
					Game1.character[num7].charUpdate.state = CharUpdate.State.Grounded;
					Game1.character[num7].charAnim.SetAnim("chaironly", Game1.character[num7].charUpdate);
					Game1.character[num7].charUpdate.face = 0;
					break;
				}
			}
			break;
		}
		case "knife":
		{
			if (Game1.character[0].charMeta == 86)
			{
				break;
			}
			for (int num6 = 4; num6 < Game1.character.Length; num6++)
			{
				if (!Game1.character[num6].exists)
				{
					Game1.character[num6].Init(6, new Vector2(scriptLine[line].GetIParam(1), Game1.character[0].charUpdate.loc.Y), 84, -1, Character.Team.GoodGuys, -1);
					Game1.character[num6].charUpdate.state = CharUpdate.State.Grounded;
					Game1.character[num6].charAnim.SetAnim("knifeonly", Game1.character[num6].charUpdate, overRide: true);
					Game1.character[num6].charUpdate.face = 0;
					break;
				}
			}
			break;
		}
		case "quirksylum":
			QuakeManager.SetQuirk(0.1f);
			wait = 0.05f;
			result = true;
			break;
		case "asylum":
		{
			for (int n = 0; n < Game1.character.Length; n++)
			{
				if (Game1.character[n].exists && Game1.character[n].team != Character.Team.GoodGuys)
				{
					Game1.character[n].exists = false;
				}
			}
			Character character2 = Game1.character[0];
			character2.charMeta = (character2.charAnim.charMeta = 10);
			if (Game1.player.yukiPhase >= 6)
			{
				character2.charMeta = (character2.charAnim.charMeta = 22);
			}
			if (Game1.player.yukiPhase >= 13)
			{
				character2.charMeta = (character2.charAnim.charMeta = 85);
			}
			character2.cDef = (character2.charAnim.charDef = 6);
			character2.FloorMe(character2.charUpdate.loc);
			if (Game1.player.yukiPhase >= 6)
			{
				character2.charAnim.SetAnim("armasylum", character2.charUpdate, overRide: true);
			}
			else
			{
				character2.charAnim.SetAnim("asylum", character2.charUpdate, overRide: true);
			}
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			Game1.gameMap.SetMap(scriptLine[line].GetSParam(1));
			break;
		}
		case "uslava":
			if (CanExecute(line, netInduced))
			{
				int num5 = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(1), Game1.character[0].charUpdate.loc.Y), 51, "uslava");
				if (num5 > -1)
				{
					Game1.character[num5].charUpdate.state = CharUpdate.State.Grounded;
					Game1.character[num5].charUpdate.face = 0;
					Game1.character[num5].charAnim.SetAnim("unawares", Game1.character[num5].charUpdate);
				}
			}
			break;
		case "wasylum":
		{
			for (int k = 0; k < Game1.character.Length; k++)
			{
				if (Game1.character[k].exists && Game1.character[k].team != Character.Team.GoodGuys)
				{
					Game1.character[k].exists = false;
				}
			}
			Character character = Game1.character[0];
			character.charMeta = (character.charAnim.charMeta = 10);
			if (Game1.player.yukiPhase >= 6)
			{
				character.charMeta = (character.charAnim.charMeta = 22);
			}
			if (Game1.player.yukiPhase >= 13)
			{
				character.charMeta = (character.charAnim.charMeta = 85);
			}
			if (Game1.player.yukiPhase >= 14)
			{
				character.charMeta = (character.charAnim.charMeta = 86);
			}
			character.cDef = (character.charAnim.charDef = 6);
			character.FloorMe(character.charUpdate.loc);
			if (Game1.player.yukiPhase >= 6)
			{
				character.charAnim.SetAnim("armasylum", character.charUpdate, overRide: true);
			}
			else
			{
				character.charAnim.SetAnim("asylum", character.charUpdate, overRide: true);
			}
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			WorldManager.curWorld = "asylum";
			Game1.gameMap.SetMap(scriptLine[line].GetSParam(1));
			Game1.spriteMan.Reset();
			break;
		}
		case "lockchars":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.lockCharMode = true;
			}
			break;
		case "unlockchars":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.lockCharMode = false;
			}
			break;
		case "nekotoasty":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.nekoToasty = true;
			}
			break;
		case "goryoon":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.goryoMode = true;
			}
			break;
		case "goryooff":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.goryoMode = false;
			}
			break;
		case "scatter":
		{
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			int num30 = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)), "");
			if (num30 > -1)
			{
				for (int num31 = 0; num31 < 2; num31++)
				{
					Game1.spriteMan.AddGib(Game1.character[num30].charUpdate.loc + Rand.GetRandomVec2(-100f, 100f, -2f, 20f), Rand.GetRandomInt(0, 2), Game1.character[num30].GetMeta().headTex, Game1.character[num30].GetMeta().legsTex, Game1.character[num30].GetMeta().torsoTex, Game1.character[num30].GetMeta().weapTex, Game1.character[num30].cDef, "armland", Rand.GetRandomInt(0, 2), 0.35f, Game1.gameMap.CurMap(), num30);
				}
				Game1.spriteMan.AddGib(Game1.character[num30].charUpdate.loc + Rand.GetRandomVec2(-100f, 100f, -2f, 20f), Rand.GetRandomInt(0, 2), Game1.character[num30].GetMeta().headTex, Game1.character[num30].GetMeta().legsTex, Game1.character[num30].GetMeta().torsoTex, Game1.character[num30].GetMeta().weapTex, Game1.character[num30].cDef, "splitlegsland", Rand.GetRandomInt(4, 6), 0.35f, Game1.gameMap.CurMap(), num30);
				Game1.spriteMan.AddGib(Game1.character[num30].charUpdate.loc + Rand.GetRandomVec2(-100f, 100f, -2f, 20f), Rand.GetRandomInt(0, 2), Game1.character[num30].GetMeta().headTex, Game1.character[num30].GetMeta().legsTex, Game1.character[num30].GetMeta().torsoTex, Game1.character[num30].GetMeta().weapTex, Game1.character[num30].cDef, "headland", Rand.GetRandomInt(0, 2), 0.35f, Game1.gameMap.CurMap(), num30);
				for (int num32 = 0; num32 < 128; num32++)
				{
					Game1.spriteMan.AddWallblood(Game1.character[num30].charUpdate.loc + Rand.GetRandomVec2(-200f, 200f, -400f, 0f), splatNow: true);
				}
				Game1.character[num30].exists = false;
			}
			break;
		}
		case "desylum":
		{
			for (int num27 = 0; num27 < Game1.character.Length; num27++)
			{
				if (Game1.character[num27].exists && Game1.character[num27].team != Character.Team.GoodGuys)
				{
					Game1.character[num27].exists = false;
				}
			}
			Character character6 = Game1.character[0];
			switch (Game1.player.yukiPhase)
			{
			}
			if (Game1.player.yukiPhase < 4)
			{
				character6.charMeta = (character6.charAnim.charMeta = 78);
			}
			else
			{
				switch (Game1.gamePlayerMgr.gamePlayer[0].loadOut[character6.loadOut].weapon[character6.weapIdx])
				{
				case InvCatalog.InvItemName.Claws:
					character6.charMeta = (character6.charAnim.charMeta = 78);
					break;
				case InvCatalog.InvItemName.Conviction:
					character6.charMeta = (character6.charAnim.charMeta = 0);
					break;
				case InvCatalog.InvItemName.Kamakazi:
					character6.charMeta = (character6.charAnim.charMeta = 2);
					break;
				case InvCatalog.InvItemName.CloudSword:
					character6.charMeta = (character6.charAnim.charMeta = 25);
					break;
				case InvCatalog.InvItemName.Painkiller:
					character6.charMeta = (character6.charAnim.charMeta = 46);
					break;
				default:
					if (Game1.player.yukiPhase >= 4)
					{
						character6.charMeta = (character6.charAnim.charMeta = 0);
					}
					else
					{
						character6.charMeta = (character6.charAnim.charMeta = 78);
					}
					break;
				}
			}
			character6.cDef = (character6.charAnim.charDef = 0);
			character6.charUpdate.warpFrame = 0f;
			character6.FloorMe(character6.charUpdate.loc);
			character6.charAnim.SetAnim("desylum", character6.charUpdate);
			Game1.gameMap.trapWarpFrame = 0f;
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			Game1.gameMap.SetMap(scriptLine[line].GetSParam(1));
			break;
		}
		case "chairsylum":
		{
			for (int num26 = 0; num26 < Game1.character.Length; num26++)
			{
				if (Game1.character[num26].exists && Game1.character[num26].team != Character.Team.GoodGuys)
				{
					Game1.character[num26].exists = false;
				}
			}
			Character character5 = Game1.character[0];
			character5.charMeta = (character5.charAnim.charMeta = 22);
			character5.cDef = (character5.charAnim.charDef = 6);
			character5.FloorMe(character5.charUpdate.loc);
			character5.charAnim.SetAnim("armsit2", character5.charUpdate, overRide: true);
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			Game1.gameMap.SetMap(scriptLine[line].GetSParam(1));
			break;
		}
		case "endlevel":
			if (!Game1.netSession.IsClient())
			{
				Game1.hud.EndLevel();
			}
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.SendEndLevel(Game1.netSession.session);
			}
			break;
		case "tut":
			if (CanExecute(line, netInduced))
			{
				Game1.hud.DoTut(scriptLine[line].GetSParam(1));
				result = true;
			}
			break;
		case "stabbedend":
		{
			for (int num24 = 0; num24 < Game1.character.Length; num24++)
			{
				if (Game1.character[num24].exists && Game1.character[num24].team != Character.Team.GoodGuys)
				{
					Game1.character[num24].exists = false;
				}
			}
			Character character4 = Game1.character[0];
			switch (Game1.gamePlayerMgr.gamePlayer[0].loadOut[character4.loadOut].weapon[character4.weapIdx])
			{
			case InvCatalog.InvItemName.Claws:
				character4.charMeta = (character4.charAnim.charMeta = 78);
				break;
			case InvCatalog.InvItemName.Conviction:
				character4.charMeta = (character4.charAnim.charMeta = 0);
				break;
			case InvCatalog.InvItemName.Kamakazi:
				character4.charMeta = (character4.charAnim.charMeta = 2);
				break;
			case InvCatalog.InvItemName.CloudSword:
				character4.charMeta = (character4.charAnim.charMeta = 25);
				break;
			case InvCatalog.InvItemName.Painkiller:
				character4.charMeta = (character4.charAnim.charMeta = 46);
				break;
			default:
				character4.charMeta = (character4.charAnim.charMeta = 0);
				break;
			}
			character4.cDef = (character4.charAnim.charDef = 0);
			character4.charUpdate.warpFrame = 0f;
			character4.FloorMe(character4.charUpdate.loc);
			character4.charAnim.SetAnim("stabber", character4.charUpdate);
			Game1.character[4].Init(3, character4.charUpdate.loc + new Vector2(80f, 0f), 5, -1, Character.Team.GoodGuys, 10, "dish");
			Game1.character[4].charUpdate.face = 0;
			Game1.character[4].charAnim.SetAnim("stabbed", Game1.character[4].charUpdate);
			Game1.character[4].charUpdate.state = CharUpdate.State.Grounded;
			Game1.gameMap.trapWarpFrame = 0f;
			Game1.gameMap.CrazyTransitionInFrame = 0f;
			Game1.gameMap.CrazyTransitionOutFrame = 1f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			string curMap = Game1.gameMap.curMap;
			string curWorld = WorldManager.curWorld;
			WorldManager.curWorld = scriptLine[line].GetSParam(2);
			Game1.gameMap.SetMap(scriptLine[line].GetSParam(1));
			Game1.transMgr.enterMap = curMap;
			Game1.transMgr.enterWorld = curWorld;
			QuakeManager.SetBright(0.5f);
			FMan.slowFrame = 0.01f;
			Sound.PlaySnd(Sound.Category.FX, "lieend");
			break;
		}
		case "dentistchair":
			Game1.gameMap.dentistChairMode = true;
			Game1.gameMap.scriptTrigX = scriptLine[line].GetIParam(1);
			Game1.gameMap.scriptDestMap = scriptLine[line].GetSParam(2);
			Game1.gameMap.scriptDestWorld = scriptLine[line].GetSParam(3);
			Game1.gameMap.zapchairmode = false;
			break;
		case "zapchair":
			Game1.gameMap.dentistChairMode = true;
			Game1.gameMap.scriptTrigX = scriptLine[line].GetIParam(1);
			Game1.gameMap.scriptDestMap = scriptLine[line].GetSParam(2);
			Game1.gameMap.scriptDestWorld = scriptLine[line].GetSParam(3);
			Game1.gameMap.zapchairmode = true;
			break;
		case "bed":
			Game1.gameMap.bedMode = true;
			Game1.gameMap.scriptTrigX = scriptLine[line].GetIParam(1);
			Game1.gameMap.scriptDestMap = scriptLine[line].GetSParam(2);
			Game1.gameMap.scriptDestWorld = scriptLine[line].GetSParam(3);
			break;
		case "cache":
			Game1.gameMap.CacheMap(scriptLine[line].GetSParam(1));
			break;
		case "fog":
			Game1.gameMap.fog = true;
			GameRender.fogRender.Reset();
			break;
		case "haze":
			Game1.gameMap.haze = true;
			break;
		case "halfhaze":
			Game1.gameMap.halfhaze = true;
			break;
		case "glows":
			Game1.gameMap.glows = true;
			break;
		case "wallblood":
			Game1.gameMap.wallBlood = true;
			break;
		case "drips":
			Game1.gameMap.drips = true;
			break;
		case "ashes":
			Game1.gameMap.ashes = true;
			break;
		case "strobe":
			Game1.gameMap.strobe = true;
			break;
		case "nostrobe":
			Game1.gameMap.strobe = false;
			break;
		case "rain":
			Game1.gameMap.rain = true;
			break;
		case "wait":
			if (!Game1.netSession.IsClient())
			{
				wait = scriptLine[line].GetIParam(1);
				result = true;
			}
			break;
		case "tickwait":
			if (!Game1.netSession.IsClient())
			{
				wait = (float)scriptLine[line].GetIParam(1) / 10f;
				result = true;
			}
			break;
		case "slavapounce":
		{
			int num22 = Game1.spawnMgr.SpawnMonster(new Vector2(Game1.character[0].charUpdate.loc.X + 200f, Game1.character[0].charUpdate.loc.Y - 800f), 13, "slava");
			if (num22 > -1)
			{
				Game1.character[num22].charAnim.SetAnim("pounce", Game1.character[num22].charUpdate);
				Game1.character[num22].charUpdate.face = 0;
				Game1.character[num22].charUpdate.state = CharUpdate.State.Airborne;
				Game1.character[num22].charUpdate.nomusic = true;
			}
			break;
		}
		case "chefleave":
		{
			for (int num21 = 0; num21 < Game1.character.Length; num21++)
			{
				if (Game1.character[num21].charMeta == 83)
				{
					if (Game1.character[num21].charUpdate.state != CharUpdate.State.Grounded)
					{
						Game1.character[num21].FloorMe(Game1.character[num21].charUpdate.loc);
					}
					Game1.character[num21].charAnim.SetAnim("leave", Game1.character[num21].charUpdate);
				}
			}
			break;
		}
		case "comic":
		case "scene":
			Game1.sceneMgr.Play("scene/data/" + scriptLine[line].GetSParam(1) + ".zcx");
			result = true;
			break;
		case "raven":
		{
			int num18 = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(1), Game1.character[0].charUpdate.loc.Y), 26, "");
			if (num18 > -1)
			{
				int num19 = Game1.spawnMgr.SpawnMonster(Game1.character[num18].charUpdate.loc, 52, "");
				if (num18 > -1)
				{
					Game1.character[num19].FloorMe(Game1.character[num19].charUpdate.loc);
					Game1.character[num18].FloorMe(Game1.character[num18].charUpdate.loc);
					Game1.character[num18].charUpdate.spawnFrame = 0f;
					Game1.character[num19].charAnim.SetAnim("blast", Game1.character[num19].charUpdate, overRide: true);
					Game1.character[num19].charUpdate.charGrab.grabbedByChar = num18;
					Game1.character[num18].charUpdate.charGrab.grabbing = true;
					Game1.character[num19].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				}
			}
			break;
		}
		case "firstexe":
			Game1.gameMap.firstExe = true;
			break;
		case "transcomic":
		case "transscene":
			if (CanExecute(line, netInduced))
			{
				Game1.sceneMgr.TransPlay("scene/data/" + scriptLine[line].GetSParam(1) + ".zcx");
				result = true;
			}
			break;
		case "xmax":
			Game1.gameMap.xmax = scriptLine[line].GetIParam(1);
			break;
		case "xmin":
			Game1.gameMap.xmin = scriptLine[line].GetIParam(1);
			break;
		case "noxmax":
			Game1.gameMap.xmax = -1f;
			break;
		case "noxmin":
			Game1.gameMap.xmin = -1f;
			break;
		case "setmaptheme":
			switch (scriptLine[line].GetSParam(1))
			{
			case "marble":
				Game1.gameMap.theme.theme = Themes.ThemeType.Marble;
				break;
			case "asylum":
				Game1.gameMap.theme.theme = Themes.ThemeType.Asylum;
				break;
			case "prison":
				Game1.gameMap.theme.theme = Themes.ThemeType.Prison;
				break;
			case "prisonout":
				Game1.gameMap.theme.theme = Themes.ThemeType.PrisonOut;
				break;
			case "escape":
				Game1.gameMap.theme.theme = Themes.ThemeType.Escape;
				break;
			case "escapeout":
				Game1.gameMap.theme.theme = Themes.ThemeType.EscapeOut;
				break;
			case "moon":
				Game1.gameMap.theme.theme = Themes.ThemeType.Moon;
				break;
			case "moondark":
				Game1.gameMap.theme.theme = Themes.ThemeType.MoonDark;
				break;
			case "dark":
				Game1.gameMap.theme.theme = Themes.ThemeType.Dark;
				break;
			case "descent":
				Game1.gameMap.theme.theme = Themes.ThemeType.Descent;
				Game1.gameMap.descentFrame = 4f;
				Game1.levelMgr.guitarEmpty = false;
				Sound.PlaySnd(Sound.Category.FX, "shuttlecrank");
				break;
			case "ascent":
				Game1.gameMap.theme.theme = Themes.ThemeType.Ascent;
				Game1.gameMap.descentFrame = 0f;
				break;
			case "swamp":
				Game1.gameMap.theme.theme = Themes.ThemeType.Swamp;
				break;
			case "tank":
				Game1.gameMap.theme.theme = Themes.ThemeType.Tank;
				break;
			case "tankbrite":
				Game1.gameMap.theme.theme = Themes.ThemeType.TankBrite;
				break;
			case "moondoors":
				Game1.gameMap.theme.theme = Themes.ThemeType.Moondoors;
				break;
			case "marblemoon":
				Game1.gameMap.theme.theme = Themes.ThemeType.MarbleMoon;
				break;
			case "elite":
				Game1.gameMap.theme.theme = Themes.ThemeType.Elite;
				break;
			case "rush":
				Game1.gameMap.theme.theme = Themes.ThemeType.Rush;
				break;
			case "elitedark":
				Game1.gameMap.theme.theme = Themes.ThemeType.EliteDark;
				break;
			case "judge":
				Game1.gameMap.theme.theme = Themes.ThemeType.Judge;
				break;
			case "elitedarkquiet":
				Game1.gameMap.theme.theme = Themes.ThemeType.EliteDarkQuiet;
				break;
			case "lift":
				Game1.gameMap.theme.theme = Themes.ThemeType.Lift;
				break;
			case "aqua":
			case "aquarium":
				Game1.gameMap.theme.theme = Themes.ThemeType.Aquarium;
				break;
			case "fishlessaquarium":
			case "fishlessaqua":
				Game1.gameMap.theme.theme = Themes.ThemeType.FishlessAquarium;
				break;
			case "elitelobby":
				Game1.gameMap.theme.theme = Themes.ThemeType.EliteLobby;
				break;
			case "maproom":
				Game1.gameMap.theme.theme = Themes.ThemeType.MapRoom;
				break;
			case "cache":
				Game1.gameMap.theme.theme = Themes.ThemeType.Cache;
				break;
			case "lobby":
				Game1.gameMap.theme.theme = Themes.ThemeType.Lobby;
				break;
			case "church":
				Game1.gameMap.theme.theme = Themes.ThemeType.Church;
				break;
			case "lobbychute":
				Game1.gameMap.theme.theme = Themes.ThemeType.LobbyChute;
				break;
			case "closet":
				Game1.gameMap.theme.theme = Themes.ThemeType.Closet;
				break;
			case "gearcloset":
				Game1.gameMap.theme.theme = Themes.ThemeType.GearCloset;
				break;
			case "terror":
				Game1.gameMap.theme.theme = Themes.ThemeType.Terror;
				break;
			case "dish":
				Game1.gameMap.theme.theme = Themes.ThemeType.Dish;
				break;
			case "final":
				Game1.gameMap.theme.theme = Themes.ThemeType.Final;
				break;
			case "crypt":
				Game1.gameMap.theme.theme = Themes.ThemeType.Crypt;
				break;
			case "bigcloset":
				Game1.gameMap.theme.theme = Themes.ThemeType.BigCloset;
				break;
			default:
				Printf.WriteLine("Unrecognized theme: " + scriptLine[line].GetSParam(1));
				break;
			}
			if (Game1.gameMap.theme.pTheme != Game1.gameMap.theme.theme)
			{
				if (Game1.gameMap.theme.pTheme == Themes.ThemeType.Lobby)
				{
					Sound.ExitLobby();
				}
				if (Game1.gameMap.theme.theme == Themes.ThemeType.Lobby)
				{
					Sound.EnterLobby();
				}
			}
			switch (Game1.gameMap.theme.theme)
			{
			case Themes.ThemeType.Dish:
			case Themes.ThemeType.Final:
			{
				for (int num14 = 0; num14 < Game1.character.Length; num14++)
				{
					if (Game1.character[num14].exists && (Game1.character[num14].GetMeta().isNeko || Game1.character[num14].GetMeta().isCrow))
					{
						Game1.character[num14].exists = false;
					}
				}
				break;
			}
			}
			Game1.gameMap.theme.pTheme = Game1.gameMap.theme.theme;
			break;
		case "fakeceiling":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.fakeCeiling = scriptLine[line].GetIParam(1);
			}
			break;
		case "setanim":
		{
			if (!CanExecute(line, netInduced))
			{
				break;
			}
			for (int num11 = 0; num11 < Game1.character.Length; num11++)
			{
				if (Game1.character[num11].exists && Game1.character[num11].tag == scriptLine[line].GetSParam(1))
				{
					Game1.character[num11].charAnim.SetAnim(scriptLine[line].GetSParam(2), Game1.character[num11].charUpdate, overRide: true);
					break;
				}
			}
			break;
		}
		case "bluelights":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.actuallyBlueLights = true;
			}
			break;
		case "slippywalls":
			Game1.gameMap.slippyWalls = true;
			break;
		case "warptrap":
			Game1.gameMap.warpTrap = true;
			Game1.gameMap.warpTrapX = scriptLine[line].GetIParam(1);
			break;
		case "shop":
			if (CanExecute(line, netInduced))
			{
				int num10 = Game1.spawnMgr.SpawnMonster(new Vector2(scriptLine[line].GetIParam(1), scriptLine[line].GetIParam(2)), 33, "");
				if (num10 > -1)
				{
					Game1.character[num10].FloorMe(Game1.character[num10].charUpdate.loc);
					Game1.character[num10].charUpdate.inactive = true;
				}
			}
			break;
		case "blackenlift":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.liftBlack = true;
			}
			Game1.gameMap.liftBlackFrame = 0f;
			break;
		case "dragonready":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.dragonReady = true;
			}
			break;
		case "startlift":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.dragonReady = false;
				Game1.gameMap.liftOn = true;
				Game1.gameMap.liftFrame = 4.5f;
				Game1.gameMap.liftSpeed = 0f;
				Game1.gameMap.liftBlack = false;
				Game1.gameMap.liftBlackFrame = 0f;
				Sound.PlaySnd(Sound.Category.FX, "liftstart");
			}
			break;
		case "countdown":
			if (CanExecute(line, netInduced))
			{
				mapCountDown.Start(scriptLine[line].GetIParam(1));
			}
			break;
		case "endcountdown":
			if (CanExecute(line, netInduced))
			{
				mapCountDown.EndCountDown();
			}
			break;
		case "greensensors":
		case "greensensor":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.rightgreensensors = true;
				Game1.gameMap.leftgreensensors = true;
			}
			break;
		case "rightgreensensors":
		case "rightgreensensor":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.rightgreensensors = true;
			}
			break;
		case "leftgreensensors":
		case "leftgreensensor":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.leftgreensensors = true;
			}
			break;
		case "fadingblackscreen":
			Game1.gameMap.fadingblackscreen = true;
			break;
		case "blackscreen":
			Game1.gameMap.blackscreen = true;
			break;
		case "makebucket":
			if (!Game1.netSession.IsClient())
			{
				Game1.gameMap.bucket.Init(scriptLine[line].GetIParam(1), fix: false);
			}
			break;
		case "fixedbucket":
		case "fixbucket":
			if (!Game1.netSession.IsClient())
			{
				Game1.gameMap.bucket.Init(scriptLine[line].GetIParam(1), fix: true);
			}
			break;
		case "addbucket":
			if (!Game1.netSession.IsClient())
			{
				Game1.gameMap.bucket.AddItem(new Vector2(scriptLine[line].GetIParam(2), scriptLine[line].GetIParam(3)), SpawnManager.StringToMonster(scriptLine[line].GetSParam(1)));
			}
			break;
		case "water":
			Game1.gameMap.water = true;
			Game1.gameMap.waterLev = (float)scriptLine[line].GetIParam(1) - 20f;
			break;
		case "doorfocus":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.doorFocus = scriptLine[line].GetIParam(1);
				Game1.gameMap.doorFocusFrame = 1f;
				Sound.PlaySnd(Sound.Category.FX, "swing");
			}
			break;
		case "stonedoorfocus":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.doorFocus = scriptLine[line].GetIParam(1);
				Game1.gameMap.doorFocusFrame = 1f;
				if (Game1.gameMap.CurMap().layer[2].segment[Game1.gameMap.doorFocus].open)
				{
					Sound.PlaySnd(Sound.Category.FX, "stoneopen");
				}
				else
				{
					Sound.PlaySnd(Sound.Category.FX, "stoneclose");
				}
				Sound.PlaySnd(Sound.Category.FX, "swing");
			}
			break;
		case "metaldoorfocus":
			if (CanExecute(line, netInduced))
			{
				Game1.gameMap.doorFocus = scriptLine[line].GetIParam(1);
				Game1.gameMap.doorFocusFrame = 1f;
				if (Game1.gameMap.CurMap().layer[2].segment[Game1.gameMap.doorFocus].open)
				{
					Sound.PlaySnd(Sound.Category.FX, "metalopen");
				}
				else
				{
					Sound.PlaySnd(Sound.Category.FX, "metalclose");
				}
				Sound.PlaySnd(Sound.Category.FX, "swing");
			}
			break;
		case "bucketwait":
			if (!Game1.netSession.IsClient() && !Game1.gameMap.bucket.IsDone())
			{
				if (!netInduced)
				{
					curLine--;
				}
				result = true;
			}
			break;
		case "scenewait":
			if (!Game1.netSession.IsClient() && Game1.sceneMgr.playing)
			{
				if (!netInduced)
				{
					curLine--;
				}
				result = true;
				wait = 1f;
			}
			break;
		case "flagwait":
			if (!Game1.netSession.IsClient() && !GetFlag(scriptLine[line].GetSParam(1)))
			{
				if (!netInduced)
				{
					curLine--;
				}
				result = true;
				wait = 1f;
			}
			break;
		case "killbucket":
			if (!Game1.netSession.IsClient())
			{
				Game1.gameMap.bucket.KillBucket();
			}
			break;
		case "bloodyback":
			if (CanExecute(line, netInduced))
			{
				for (int i = 0; i < 64; i++)
				{
					Game1.spriteMan.AddWallblood(new Vector2((float)Game1.gameMap.CurMap().xSize * 64f * 0.5f, (float)Game1.gameMap.CurMap().ySize * 64f) + Rand.GetRandomVec2(-600f, 600f, -600f, -100f));
				}
			}
			break;
		}
		return result;
	}

	public static void ClickToLoc(int i)
	{
		for (int pn = 0; pn < 4; pn++)
		{
			if (pn == i || !Game1.IsPlayerChar(pn))
			{
				continue;
			}
			{
		Game1.character[pn].charUpdate.loc = Game1.character[i].charUpdate.loc;
		if (Game1.character[i].charUpdate.state == CharUpdate.State.Airborne)
		{
			Game1.character[pn].charUpdate.state = CharUpdate.State.Airborne;
			Game1.character[pn].charAnim.SetAnim(Game1.character[pn].GetMeta().flip_anim, Game1.character[pn].charUpdate);
		}
		else
		{
			Game1.character[pn].charUpdate.state = CharUpdate.State.Airborne;
			Game1.character[pn].charAnim.SetAnim(Game1.character[pn].GetMeta().idle_anim, Game1.character[pn].charUpdate);
		}
				}
		}
	}

	public void Update()
	{
		if (Game1.gameMap.lichFreakoutMode || MainPlayer.uberDyingFrame >= 1f || ((Game1.netSession.IsHost() || Game1.netSession.IsClient()) && Game1.netSession.netGame.IsPanic()))
		{
			return;
		}
		mapCountDown.Update();
		bool flag = false;
		if (scriptLine.Count <= 0 || !reading)
		{
			return;
		}
		if (wait > 0f)
		{
			if (!Game1.hud.arcadeIn.IsActive())
			{
				wait -= FMan.frameTime;
			}
			return;
		}
		while (!flag)
		{
			flag = ExecuteLine(curLine);
			curLine++;
			if (curLine >= scriptLine.Count)
			{
				reading = false;
				flag = true;
			}
		}
	}

	internal void ClientProcess()
	{
		netScriptReader.Process(this);
	}

	internal void ReadNetScript(PacketReader reader)
	{
		netScriptReader.NetRead(reader, this);
	}

	internal bool WriteNetScript(PacketWriter writer)
	{
		return netScriptWriter.NetWrite(writer);
	}

	internal void SetHashTag()
	{
		long num = 0L;
		for (int i = 0; i < Game1.gameMap.curMap.Length; i++)
		{
			num = (num + (byte)Game1.gameMap.curMap[i] * i * 256) % 32767;
		}
		mapHash = (short)num;
	}

	internal bool CheckHashTagMatch(short checkTag)
	{
		return mapHash == checkTag;
	}

	internal void ClickNekoToasty()
	{
		for (int i = 4; i < Game1.character.Length; i++)
		{
			if (Game1.character[i].exists)
			{
				Game1.character[i].exists = false;
			}
		}
		Game1.gameMap.bucket.KillBucket();
		Sound.PlaySnd(Sound.Category.FX, "sword1");
		Game1.gameMap.nekoToastyFrame = 0f;
		QuakeManager.SetBright(0.5f);
		GotoTag("nekotoasty");
	}

	internal short GetHashTag()
	{
		return mapHash;
	}
}
