using System.Collections.Generic;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.netplay;

namespace Yuki_Win.maps.script;

public class NetScriptReader
{
	public Dictionary<string, List<int>> scriptToExecute;

	public NetScriptReader()
	{
		scriptToExecute = new Dictionary<string, List<int>>();
	}

	internal void NetRead(PacketReader reader, ScriptManager scriptManager)
	{
		string text = reader.ReadString();
		int num = NetPacker.ReadByte(reader);
		if (text == Game1.gameMap.curMap)
		{
			for (int i = 0; i < num; i++)
			{
				scriptManager.ExecuteLine(NetPacker.ReadByte(reader), netInduced: true);
			}
			return;
		}
		if (scriptToExecute.ContainsKey(text))
		{
			scriptToExecute.Remove(text);
		}
		List<int> list = new List<int>();
		for (int j = 0; j < num; j++)
		{
			list.Add(NetPacker.ReadByte(reader));
		}
		scriptToExecute.Add(text, list);
	}

	internal void Process(ScriptManager scriptManager)
	{
		if (scriptToExecute.Count > 0 && scriptToExecute.ContainsKey(Game1.gameMap.curMap))
		{
			List<int> list = scriptToExecute[Game1.gameMap.curMap];
			for (int i = 0; i < list.Count; i++)
			{
				scriptManager.ExecuteLine(list[i], netInduced: true);
			}
			scriptToExecute.Remove(Game1.gameMap.curMap);
		}
	}
}
