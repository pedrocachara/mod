using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.chars;

namespace Yuki_Win.maps.foreground;

public class ForeGroundChar
{
	public bool exists;

	public Vector2 loc;

	public float depth;

	public int charMeta;

	public CharAnim charAnim;

	public CharRender charRender;

	public int ID;

	public int charDef;

	public int face;

	private Vector2 traj;

	public ForeGroundChar()
	{
		exists = false;
		charRender = new CharRender();
		charAnim = new CharAnim(ID);
	}

	public void Init(int def, int charMeta, Vector2 loc, int face, Vector2 traj, string anim)
	{
		this.charMeta = charMeta;
		charDef = def;
		charAnim.Init(def, charMeta, ID);
		charAnim.SetAnim(anim, null, overRide: true);
		this.face = face;
		this.loc = loc;
		this.traj = traj;
		exists = true;
	}

	public void Update()
	{
		charAnim.NullUpdate(Game1.charDef[charDef]);
		loc += traj * FMan.frameTime;
		if (traj.X > 0f)
		{
			if (loc.X > (float)Game1.gameMap.CurMap().xSize * 64f)
			{
				exists = false;
			}
		}
		else if (loc.X < 0f)
		{
			exists = false;
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		CharDef charDef = Game1.charDef[this.charDef];
		float num = 1.25f;
		Vector2 screenLoc = ScrollManager.GetScreenLoc(loc, num);
		num *= ScrollManager.GetSize(num) * 0.35f;
		if (charDef.GetAnimation(charAnim.anim).GetKeyFrame(charAnim.GetKey()).lerp)
		{
			int num2 = charAnim.GetKey() + 1;
			if (num2 >= charDef.GetAnimation(charAnim.anim).getKeyFrameArray().Length)
			{
				num2 = 0;
			}
			else if (charDef.GetAnimation(charAnim.anim).GetKeyFrame(num2) == null)
			{
				num2 = 0;
			}
			else if (charDef.GetAnimation(charAnim.anim).GetKeyFrame(num2).duration <= 0)
			{
				num2 = 0;
			}
			charRender.DrawForeCharacter(sprite, screenLoc, num, face, charAnim.GetCurFrame(), charDef, Game1.charMeta[charMeta], charAnim, charDef.GetAnimation(charAnim.anim).GetKeyFrame(num2).frameRef);
		}
		else
		{
			charRender.DrawForeCharacter(sprite, screenLoc, num, face, charAnim.GetCurFrame(), charDef, Game1.charMeta[charMeta], charAnim, -1);
		}
	}
}
