using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.maps.foreground;

public class ForeGroundMgr
{
	public enum ForeGroundDef
	{
		Swat,
		Dragon
	}

	public ForeGroundChar[] character;

	public bool needsDraw;

	public ForeGroundMgr()
	{
		character = new ForeGroundChar[4];
		for (int i = 0; i < character.Length; i++)
		{
			character[i] = new ForeGroundChar();
		}
	}

	internal void Update()
	{
		needsDraw = false;
		for (int i = 0; i < character.Length; i++)
		{
			if (character[i].exists)
			{
				character[i].Update();
				needsDraw = true;
			}
		}
	}

	internal void Draw(SpriteBatch sprite)
	{
		for (int i = 0; i < character.Length; i++)
		{
			if (character[i].exists)
			{
				character[i].Draw(sprite);
			}
		}
	}

	internal void Reset()
	{
		for (int i = 0; i < character.Length; i++)
		{
			character[i].exists = false;
		}
	}

	internal void AddCharacter(string def, Vector2 loc, int face)
	{
		ForeGroundDef def2 = ForeGroundDef.Swat;
		switch (def)
		{
		case "swat":
			def2 = ForeGroundDef.Swat;
			break;
		case "dragon":
			def2 = ForeGroundDef.Dragon;
			break;
		}
		AddCharacter(def2, loc, face);
	}

	internal void AddCharacter(ForeGroundDef def, Vector2 loc, int face)
	{
		int def2 = 1;
		int charMeta = 3;
		Vector2 traj = default;
		string anim = "run";
		switch (def)
		{
		case ForeGroundDef.Swat:
			traj = new Vector2(220f, 0f);
			break;
		case ForeGroundDef.Dragon:
			charMeta = 59;
			def2 = 20;
			anim = "forefly";
			traj = new Vector2(400f, -50f);
			break;
		}
		if (face == 0)
		{
			traj.X = 0f - traj.X;
		}
		for (int i = 0; i < character.Length; i++)
		{
			if (!character[i].exists)
			{
				character[i].Init(def2, charMeta, loc, face, traj, anim);
				break;
			}
		}
	}
}
