using System;
using Microsoft.Xna.Framework;

namespace Yuki_Win.sprites.hit;

internal class Hit : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.scaling = traj;
		if (p.scaling.X < 0f)
		{
			p.scaling.X = 0f - p.scaling.X;
		}
		if (p.scaling.Y < 0f)
		{
			p.scaling.Y = 0f - p.scaling.Y;
		}
		p.flags = flags;
		p.face = ((traj.X > 0f) ? 1 : 0);
		p.owner = owner;
		p.frame = 1f;
		p.hitter = true;
		p.rotation = size;
		p.traj = new Vector2((traj.Y < 0f) ? 1f : (-1f), 0f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
	}

	public override Vector2 GetLoc(Sprite p)
	{
		switch (p.flags)
		{
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 23:
		case 42:
		case 52:
		case 53:
		case 54:
		case 67:
		case 68:
		case 69:
		case 84:
		case 135:
			if (p.face == 1)
			{
				return p.loc + new Vector2((float)Math.Cos(p.rotation) * p.scaling.X * 32f, (float)Math.Sin(p.rotation) * p.scaling.Y * 32f);
			}
			return p.loc + new Vector2((float)Math.Cos(p.rotation) * p.scaling.X * -32f, (float)Math.Sin(p.rotation) * p.scaling.Y * -32f);
		default:
			return p.loc;
		}
	}

	public override Vector2 GetTraj(Sprite p)
	{
		switch (p.flags)
		{
		case 5:
		case 6:
		case 9:
		case 11:
		case 20:
		case 21:
		case 23:
		case 64:
		case 65:
		case 66:
		case 67:
		case 68:
		case 82:
		case 108:
		case 117:
		case 126:
		case 128:
		case 129:
			if (p.face == 1)
			{
				return new Vector2((float)Math.Cos(p.rotation) * p.scaling.X * 32f, (float)Math.Sin(p.rotation) * p.scaling.Y * 32f);
			}
			return new Vector2((float)Math.Cos(p.rotation) * p.scaling.X * -32f, (float)Math.Sin(p.rotation) * p.scaling.Y * -32f);
		case 4:
			if (p.face == 1)
			{
				return new Vector2((float)Math.Cos(p.rotation) * 32f, (float)Math.Sin(p.rotation) * 32f);
			}
			return new Vector2((float)Math.Cos(p.rotation) * -32f, (float)Math.Sin(p.rotation) * -32f);
		default:
			return p.traj;
		}
	}
}
