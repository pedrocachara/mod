using Microsoft.Xna.Framework;

namespace Yuki_Win.sprites.hit;

internal class GibHit : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.scaling = traj;
		if (p.scaling.X < 0f)
		{
			p.scaling.X = 0f - p.scaling.X;
		}
		if (p.scaling.Y < 0f)
		{
			p.scaling.Y = 0f - p.scaling.Y;
		}
		p.flags = flags;
		p.face = ((traj.X > 0f) ? 1 : 0);
		p.owner = owner;
		p.frame = 1f;
		p.hitter = true;
		p.rotation = size;
		p.traj = new Vector2((traj.Y < 0f) ? 1f : (-1f), 0f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
	}
}
