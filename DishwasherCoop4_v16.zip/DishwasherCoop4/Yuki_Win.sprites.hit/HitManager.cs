using director;
using Microsoft.Xna.Framework;
using Yuki_Win.achievements.cheevos;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.debug;
using Yuki_Win.director;
using Yuki_Win.gameRender;
using Yuki_Win.levels;
using Yuki_Win.maps;
using Yuki_Win.player;

namespace Yuki_Win.sprites.hit;

internal class HitManager
{
	private const float GIANT_SHRUG_THRESH = 80f;

	public const int SPECIAL_TRIG_MAGICSLASH = 7;

	public const int SPECIAL_TRIG_HEALTHPUNCH = 8;

	public void DoGiantDamage(Character c)
	{
	}

	private void KickBurst(Sprite s, int victim)
	{
		KickBurst(s.loc, s.owner, victim);
	}

	public void KickBurst(Vector2 loc, int owner, int victim)
	{
		KickBurst(loc, owner, victim, 0.4f);
	}

	public void KickBurst(Vector2 loc, int owner, int victim, float val)
	{
		if (!Game1.camMgr.twoPlayers && owner >= 0 && (owner < 2 || victim < 2) && (!Game1.netSession.IsHost() || (owner != 1 && victim != 1)) && (!Game1.netSession.IsClient() || (owner != 0 && victim != 0)))
		{
			QuakeManager.SetBurst(val, ScrollManager.GetScreenLoc(loc, 1f));
		}
	}

	public void Update(SpriteManager spriteMan, Sprite[] sprite, Character[] c, Map map)
	{
		bool flag = false;
		CharRect.RectHitType rectHitType = CharRect.RectHitType.None;
		bool flag2 = false;
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.NomNom || Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.CrackingSkull))
		{
			flag2 = true;
		}
		if ((Game1.netSession.IsClient() || Game1.netSession.IsHost()) && Game1.netSession.netGame.IsPanic())
		{
			return;
		}
		for (int i = 0; i < sprite.Length; i++)
		{
			if (!sprite[i].exists || !sprite[i].hitter)
			{
				continue;
			}
			int num = -1;
			bool wide = false;
			int type = sprite[i].type;
			if (type == 12)
			{
				wide = true;
			}
			if (sprite[i].type == 12)
			{
				switch (sprite[i].flags)
				{
				case 11:
				case 16:
				case 22:
				case 25:
				case 47:
				case 48:
				case 49:
				case 50:
				case 51:
				case 74:
				case 77:
				case 117:
				case 123:
				{
					int num2 = -1;
					float num3 = -1f;
					for (int j = 0; j < c.Length; j++)
					{
						if (!c[j].exists || sprite[i].owner == j || c[j].charUpdate.ethereal || !(c[j].charUpdate.etherealFrame <= 0f) || !(c[j].charUpdate.warpFrame <= 0f) || !(sprite[i].frame > 0f) || (c[j].charUpdate.charGrab.grabbedByChar != -1 && c[j].charMeta != 88) || c[j].team != Character.Team.BadGuys || (c[j].GetMeta().isBoss && Game1.gameMap.lichFreakoutMode) || (c[j].GetMeta().isJuggernaut && (c[j].charUpdate.state != CharUpdate.State.Grounded || (!(c[j].charUpdate.hp <= 0f) && !(c[j].charUpdate.giantVulnTimer > 0f)))))
						{
							continue;
						}
						Vector2 loc = spriteMan.catalog.spriteDef[sprite[i].type].GetLoc(sprite[i]);
						if (c[j].CheckHit(loc, wide) != CharRect.RectHitType.None)
						{
							if (num2 == -1)
							{
								num2 = j;
								num3 = c[j].charUpdate.hp;
							}
							else if (c[j].charUpdate.hp < num3)
							{
								num2 = j;
								num3 = c[j].charUpdate.hp;
							}
						}
					}
					num = num2;
					break;
				}
				}
			}
			int num4 = 0;
			int num5 = c.Length;
			if (num > -1)
			{
				num4 = num;
				num5 = num + 1;
			}
			for (int k = num4; k < num5; k++)
			{
				if (!c[k].exists)
				{
					continue;
				}
				CharMeta charMeta = Game1.charMeta[c[k].charMeta];
				if (Game1.pvpMatch && sprite[i].owner > -1 && sprite[i].owner != k && Game1.IsPlayerChar(sprite[i].owner) && Game1.IsPlayerChar(k))
				{
					PvpLog(sprite, i, c, k, spriteMan.catalog.spriteDef[sprite[i].type].GetLoc(sprite[i]));
				}
				if (charMeta.isShop || charMeta.isGuitar || charMeta.isViolin || sprite[i].owner == k || c[k].charUpdate.inactive || c[k].charUpdate.ethereal || !(c[k].charUpdate.etherealFrame <= 0f) || !(c[k].charUpdate.warpFrame <= 0f) || !(sprite[i].frame > 0f) || (c[k].charUpdate.charGrab.grabbedByChar != -1 && c[k].charMeta != 88) || charMeta.isNeko || charMeta.isCrow || c[k].charUpdate.dehealthified || !(c[k].charUpdate.dyingFrame <= 0f) || (c[sprite[i].owner].team == c[k].team && c[sprite[i].owner].team != Character.Team.BadGuys && c[k].team != Character.Team.BadGuys && !(Game1.pvpMode && Game1.IsPlayerChar(sprite[i].owner) && Game1.IsPlayerChar(k))) || (c[sprite[i].owner].team == Character.Team.BadGuys && c[k].charUpdate.npcHitFrame > 0f) || (c[k].GetMeta().isBoss && Game1.gameMap.lichFreakoutMode))
				{
					continue;
				}
				bool flag3 = false;
				int num6 = 0;
				bool isGiant = charMeta.isGiant;
				bool isJuggernaut = charMeta.isJuggernaut;
				_ = c[k].charUpdate.loc;
				CharUpdate.State state = c[k].charUpdate.state;
				Vector2 traj = c[k].charUpdate.traj;
				int face = c[k].charUpdate.face;
				num6 = charMeta.GetSpark();
				Vector2 loc2 = spriteMan.catalog.spriteDef[sprite[i].type].GetLoc(sprite[i]);
				switch (sprite[i].type)
				{
				case 20:
					if ((c[k].charUpdate.loc - sprite[i].loc).Length() < sprite[i].size)
					{
						flag3 = true;
					}
					break;
				case 80:
					if ((c[k].charUpdate.loc - sprite[i].loc).Length() < 120f)
					{
						flag3 = true;
					}
					break;
				case 82:
					if (c[k].charUpdate.loc.X > sprite[i].loc.X - 140f && c[k].charUpdate.loc.X < sprite[i].loc.X + 140f && c[k].charUpdate.loc.Y < sprite[i].loc.Y + 50f)
					{
						flag3 = true;
					}
					break;
				case 83:
				{
					float num7 = sprite[i].loc.Y - c[k].charUpdate.loc.Y;
					num7 = ((!(sprite[i].traj.X < 0f)) ? (num7 * 0.12f) : (num7 * -0.12f));
					if (c[k].charUpdate.loc.X > sprite[i].loc.X - 80f + num7 && c[k].charUpdate.loc.X < sprite[i].loc.X + 80f + num7 && c[k].charUpdate.loc.Y < sprite[i].loc.Y + 50f && c[k].charUpdate.loc.Y > sprite[i].loc.Y - 500f)
					{
						flag3 = true;
					}
					break;
				}
				default:
					if (sprite[i].type == 12 && sprite[i].flags == 86)
					{
						rectHitType = c[k].CheckHit(loc2, wide: false);
						if (c[k].charUpdate.fire > 0f)
						{
							rectHitType = CharRect.RectHitType.None;
						}
					}
					else
					{
						rectHitType = c[k].CheckHit(loc2, wide);
					}
					if (rectHitType != CharRect.RectHitType.None)
					{
						flag3 = true;
					}
					if (!flag3 && sprite[i].type == 12)
					{
						rectHitType = c[k].CheckHit((c[sprite[i].owner].charUpdate.loc + new Vector2(0f, -30f) + sprite[i].loc) / 2f, wide: true);
						if (rectHitType == CharRect.RectHitType.None && sprite[i].flags == 42 && c[sprite[i].owner].GetMeta().special == 3 && c[sprite[i].owner].charUpdate.cloudCharge > 1f)
						{
							rectHitType = c[k].CheckHit(sprite[i].loc + new Vector2(((sprite[i].traj.X > 0f) ? 1f : (-1f)) * 80f, 0f), wide: true);
						}
						if (rectHitType != CharRect.RectHitType.None)
						{
							flag3 = true;
						}
					}
					break;
				}
				if (!flag3)
				{
					continue;
				}
				if (rectHitType == CharRect.RectHitType.MetalLegs && num6 != 2)
				{
					num6 = 2;
				}
				bool flag4 = false;
				if (charMeta.isBlocker && c[k].charUpdate.block != CharUpdate.Block.NoBlock && c[k].charUpdate.state == CharUpdate.State.Grounded)
				{
					float num8 = c[sprite[i].owner].comboProfile.GetStaleness();
					switch (GameSettings.difficulty)
					{
					case 3:
						num8 *= 1.2f;
						break;
					case 4:
						num8 *= 1.5f;
						break;
					}
					switch (sprite[i].type)
					{
					case 12:
						switch (sprite[i].flags)
						{
						case 47:
						case 48:
						case 49:
						case 50:
						case 51:
						case 74:
						case 77:
							num8 = 0f;
							break;
						case 118:
							num8 = 0f;
							break;
						case 9:
							num8 = 0f;
							break;
						case 52:
							num8 = 0.1f;
							break;
						case 53:
						case 54:
						case 69:
							num8 = 0.05f;
							break;
						case 3:
						case 18:
						case 135:
							num8 = 0.1f;
							break;
						case 7:
						case 41:
						case 90:
						case 93:
						case 127:
							num8 = 0.1f;
							if (c[k].charUpdate.hp < c[k].charUpdate.mhp / 4f)
							{
								num8 = 0f;
							}
							break;
						case 2:
						case 23:
						case 67:
						case 68:
						case 84:
							num8 = 0f;
							break;
						case 119:
						case 120:
						case 121:
							if (c[k].charUpdate.drippy > 0f)
							{
								num8 = 0f;
							}
							break;
						case 19:
							num8 = 0f;
							break;
						case 4:
							num8 = 0.1f;
							break;
						case 11:
						case 22:
						case 117:
						case 123:
							num8 = 0f;
							break;
						case 16:
						case 25:
						case 42:
						case 91:
							if (c[k].charUpdate.hp < c[k].charUpdate.mhp / 4f)
							{
								num8 = 0f;
							}
							if (sprite[i].flags == 91)
							{
								num8 = 0.1f;
							}
							if (c[sprite[i].owner].GetMeta().special == 3 && c[sprite[i].owner].charUpdate.cloudCharge > 0.5f)
							{
								num8 = 0f;
							}
							break;
						case 86:
							num8 = 0f;
							break;
						case 89:
							num8 /= 2f;
							break;
						case 94:
							num8 = 0.01f;
							break;
						}
						break;
					case 11:
						num8 = 0.5f;
						break;
					case 21:
					case 101:
						num8 = 0.8f;
						break;
					}
					if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.Instakill)
					{
						num8 /= 5f;
					}
					if ((sprite[i].traj.X > 0f && c[k].charUpdate.face == 1) || (sprite[i].traj.X < 0f && c[k].charUpdate.face == 0))
					{
						num8 = 0f;
					}
					if (c[k].charUpdate.block == CharUpdate.Block.AllBlock)
					{
						switch (sprite[i].flags)
						{
						default:
							num8 = (((!(sprite[i].traj.X > 0f) || c[k].charUpdate.face != 1) && (!(sprite[i].traj.X < 0f) || c[k].charUpdate.face != 0)) ? Rand.GetRandomFloat(0.7f, 1f) : 0f);
							break;
						case 11:
						case 22:
						case 47:
						case 48:
						case 49:
						case 50:
						case 51:
						case 74:
						case 77:
						case 117:
						case 118:
						case 123:
							break;
						}
					}
					if (num8 > 0f && isGiant && c[k].charUpdate.giantVulnTimer > 0f)
					{
						num8 = 0f;
					}
					if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.EyeBead))
					{
						num8 *= 0.9f;
					}
					if (Rand.CointToss(num8))
					{
						flag4 = true;
					}
					if (c[k].charUpdate.hp < 0f)
					{
						flag4 = false;
					}
				}
				if (!isJuggernaut && !charMeta.isBox && (sprite[i].type != 12 || (sprite[i].flags != 117 && sprite[i].flags != 118)))
				{
					if (sprite[i].traj.X > 0f)
					{
						c[k].charUpdate.face = 0;
					}
					else
					{
						c[k].charUpdate.face = 1;
					}
				}
				if (charMeta.ishypno && sprite[i].flags == 118 && c[k].charUpdate.state == CharUpdate.State.Grounded)
				{
					c[k].charUpdate.giantVulnTimer = 3f;
					c[k].charAnim.SetAnim("bighit", c[k].charUpdate);
					c[k].charUpdate.face = 1 - c[sprite[i].owner].charUpdate.face;
				}
				if (charMeta.isBreaker)
				{
					flag4 = ((sprite[i].type != 12 || (sprite[i].flags != 53 && sprite[i].flags != 69 && sprite[i].flags != 54 && (sprite[i].flags != 42 || c[sprite[i].owner].GetMeta().special != 3 || !(c[sprite[i].owner].charUpdate.cloudCharge > 0.5f)))) ? true : false);
					if (Game1.gameMap.forceFrame > 0f)
					{
						if (c[sprite[i].owner].charUpdate.loc.X > Game1.gameMap.forceX && c[k].charUpdate.loc.X < Game1.gameMap.forceX)
						{
							flag4 = true;
						}
						if (c[sprite[i].owner].charUpdate.loc.X < Game1.gameMap.forceX && c[k].charUpdate.loc.X > Game1.gameMap.forceX)
						{
							flag4 = true;
						}
					}
				}
				if (flag4)
				{
					if (!flag)
					{
						Sound.PlaySnd(Sound.Category.FX, "block");
						flag = true;
					}
					int num9 = 10;
					if (sprite[i].type == 37)
					{
						num9 = 3;
					}
					for (int l = 0; l < num9; l++)
					{
						spriteMan.AddSprite(0, loc2, Rand.GetRandomVec2(-200f, 200f, -200f, 200f), 1f, 0, 0);
						spriteMan.AddSprite(0, loc2, Rand.GetRandomVec2(-1200f, 1200f, -1200f, 1200f), 1f, 0, 0);
					}
					if (!charMeta.isBreaker)
					{
						c[k].charAnim.SetAnim(charMeta.block_anim, c[k].charUpdate, overRide: true);
						if (sprite[i].traj.X > 0f)
						{
							c[k].charUpdate.face = 0;
						}
						else
						{
							c[k].charUpdate.face = 1;
						}
					}
					int type2 = sprite[i].type;
					if (type2 == 12)
					{
						c[sprite[i].owner].charUpdate.traj.X = ((sprite[i].traj.X > 0f) ? (-300f) : 300f);
					}
					switch (sprite[i].type)
					{
					case 11:
					case 21:
					case 23:
					case 24:
					case 37:
					case 101:
						sprite[i].frame = -1f;
						break;
					case 80:
						sprite[i].frame = 0.5f;
						sprite[i].hitter = false;
						break;
					case 82:
						sprite[i].hitter = false;
						break;
					case 91:
					case 94:
						sprite[i].exists = false;
						break;
					}
					continue;
				}
				bool parried = IsParrying(c, sprite[i].owner, k, face);
				float parryHp = c[k].charUpdate.hp;
				bool flag5 = c[k].charAnim.animName == charMeta.dying_anim;
				c[k].charUpdate.lastHitBy = sprite[i].owner;
				if (c[k].team == Character.Team.BadGuys)
				{
					c[k].charUpdate.npcHitFrame = 0.5f;
				}
				if (sprite[i].type != 12 || (sprite[i].flags != 118 && sprite[i].flags != 127))
				{
					c[k].charUpdate.traj.X = sprite[i].traj.X * 300f;
				}
				float num10 = 5f;
				bool flag6 = false;
				bool flag7 = false;
				if (c[k].team == Character.Team.GoodGuys)
				{
					if (c[k].charUpdate.GetCanScratch() && c[k].charKeys.rVec.Length() > 0.4f && c[k].charUpdate.charGrab.grabbedByChar <= 0)
					{
						int num11 = c[k].charUpdate.TryWarp(c[k]);
						if (num11 > 0)
						{
							c[k].charUpdate.SetScratch();
							flag6 = true;
							num6 = 2;
							if (num11 == 1)
							{
								TrySlow(c, sprite[i].owner, k, 0.05f);
								if (!Game1.camMgr.twoPlayers)
								{
									Vector2 warpVec = c[k].charUpdate.warpVec;
									warpVec.Normalize();
									QuakeManager.SetBurst(0.05f, warpVec * 2500f + ScrollManager.screenSize / 2f);
								}
							}
							else
							{
								TrySlow(c, sprite[i].owner, k, 0.01f);
								if (!Game1.camMgr.twoPlayers)
								{
									Vector2 traj2 = c[k].charUpdate.traj;
									traj2.Normalize();
									if (c[k].charUpdate.state == CharUpdate.State.Grounded)
									{
										traj2.Y = 0f;
									}
									QuakeManager.SetBurst(0.05f, traj2 * 2500f + ScrollManager.screenSize / 2f);
								}
							}
						}
					}
				}
				else if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
				{
					Level.ArcadeSpecial arcadeSpecial = Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial;
					if (arcadeSpecial == Level.ArcadeSpecial.Aerials && c[k].charUpdate.state == CharUpdate.State.Grounded)
					{
						flag7 = true;
						num6 = 3;
					}
				}
				if (sprite[i].type == 20 || sprite[i].type == 80 || sprite[i].type == 82 || sprite[i].type == 83)
				{
					num10 = 40f;
					c[k].charUpdate.state = CharUpdate.State.Airborne;
					c[k].charAnim.SetAnim("jhit", c[k].charUpdate, overRide: true);
					c[k].charUpdate.airJuggleFrame = 0f;
					c[k].charUpdate.traj = c[k].charUpdate.loc - new Vector2(0f, 30f) - sprite[i].loc;
					c[k].charUpdate.traj.Normalize();
					c[k].charUpdate.traj.X *= 100f;
					c[k].charUpdate.traj.Y = -700f;
					c[k].charUpdate.traj.X = 0f;
					if (c[k].charUpdate.hp < 0f)
					{
						c[k].charAnim.SetAnim("explode", c[k].charUpdate, overRide: true);
						c[k].charUpdate.ethereal = true;
					}
					if (sprite[i].type == 80)
					{
						TrySlow(c, sprite[i].owner, k, 0.02f);
						sprite[i].frame = 0.5f;
						sprite[i].hitter = false;
						Sound.PlaySnd(Sound.Category.FX, "zbomb");
						Sound.PlaySnd(Sound.Category.FX, "bass");
						QuakeManager.SetBright(0.5f);
					}
					if (sprite[i].type == 82)
					{
						TrySlow(c, sprite[i].owner, k, 0.02f);
						sprite[i].hitter = false;
						QuakeManager.SetBright(0.5f);
					}
					if (sprite[i].type == 83)
					{
						TrySlow(c, sprite[i].owner, k, 0.02f);
						QuakeManager.SetBright(0.5f);
					}
				}
				if (sprite[i].type == 24 || sprite[i].type == 23)
				{
					sprite[i].frame = -1f;
					c[k].charAnim.SetAnim("jhit", c[k].charUpdate, overRide: true);
					c[k].charUpdate.airJuggleFrame = 0f;
					c[k].charUpdate.state = CharUpdate.State.Airborne;
					c[k].charUpdate.traj = c[k].charUpdate.loc - new Vector2(0f, 30f) - sprite[i].loc;
					c[k].charUpdate.traj.Normalize();
					c[k].charUpdate.traj.X *= 100f;
					c[k].charUpdate.traj.Y = -700f;
				}
				if (sprite[i].type == 91 || sprite[i].type == 94)
				{
					sprite[i].frame = -1f;
					Sound.PlaySnd(Sound.Category.FX, "hit");
					Sound.PlaySnd(Sound.Category.FX, "bass");
					TrySlow(c, sprite[i].owner, k, 0.01f);
					c[k].charAnim.SetAnim("jhit", c[k].charUpdate, overRide: true);
					c[k].charUpdate.airJuggleFrame = 0f;
					c[k].charUpdate.state = CharUpdate.State.Airborne;
					c[k].charUpdate.traj = c[k].charUpdate.loc - new Vector2(0f, 30f) - sprite[i].loc;
					c[k].charUpdate.traj.Normalize();
					c[k].charUpdate.traj.X *= 200f;
					c[k].charUpdate.traj.Y = -200f;
				}
				if (sprite[i].type == 96)
				{
					sprite[i].frame = -1f;
					Sound.PlaySnd(Sound.Category.FX, "hit");
					Sound.PlaySnd(Sound.Category.FX, "slash1");
					spriteMan.MakeSquirt(sprite[i].loc, sprite[i].traj * -0.001f, num6, k);
					TrySlow(c, sprite[i].owner, k, 0.01f);
					c[k].charAnim.SetAnim("jhit", c[k].charUpdate, overRide: true);
					c[k].charUpdate.airJuggleFrame = 0f;
					c[k].charUpdate.state = CharUpdate.State.Airborne;
					c[k].charUpdate.traj = c[k].charUpdate.loc - new Vector2(0f, 30f) - sprite[i].loc;
					c[k].charUpdate.traj.Normalize();
					c[k].charUpdate.traj.X *= 200f;
					c[k].charUpdate.traj.Y = -200f;
				}
				if (sprite[i].type == 44 || sprite[i].type == 45 || sprite[i].type == 53 || sprite[i].type == 52)
				{
					sprite[i].flags = 0;
					sprite[i].traj.X *= Rand.GetRandomFloat(-0.05f, -0.1f);
					sprite[i].traj.Y = Rand.GetRandomFloat(-400f, -200f);
					QuakeManager.SetQuake(0.2f);
					sprite[i].hitter = false;
					c[k].charAnim.SetAnim("jhit", c[k].charUpdate, overRide: true);
					c[k].charUpdate.airJuggleFrame = 0f;
					c[k].charUpdate.state = CharUpdate.State.Airborne;
					c[k].charUpdate.traj = c[k].charUpdate.loc - new Vector2(0f, 30f) - sprite[i].loc;
					c[k].charUpdate.traj.Normalize();
					c[k].charUpdate.traj.X *= 100f;
					c[k].charUpdate.traj.Y = -700f;
					TrySlow(c, sprite[i].owner, k, 0.02f);
					spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 1f);
					Sound.PlaySnd(Sound.Category.FX, "hit");
					if (num6 != 2)
					{
						Sound.PlaySnd(Sound.Category.FX, "crunch");
					}
					spriteMan.MakeSplatter(sprite[i].loc, sprite[i].rotation, 5, charMeta.GetSpark(), k);
					num10 = 20f;
				}
				if (sprite[i].type == 11 || sprite[i].type == 21 || sprite[i].type == 37 || sprite[i].type == 98 || sprite[i].type == 101)
				{
					if (sprite[i].type == 37 && c[k].charAnim.animName == "spinhit")
					{
						c[k].charUpdate.airJuggleFrame = 0f;
						if (Rand.CointToss(0.5f))
						{
							spriteMan.MakeSquirt(new Vector2(c[k].charUpdate.loc.X, sprite[i].loc.Y), sprite[i].traj * -0.001f, num6, k);
						}
						if (c[k].charUpdate.traj.X > 1000f)
						{
							c[k].charUpdate.traj.X = 1000f;
						}
						if (c[k].charUpdate.traj.X < -1000f)
						{
							c[k].charUpdate.traj.X = -1000f;
						}
						if (c[k].charUpdate.hp < 0f && !flag2 && c[k].charAnim.CheckAnim("explode") > -1)
						{
							c[k].charUpdate.state = CharUpdate.State.Airborne;
							c[k].charUpdate.traj.X = sprite[i].traj.X;
							if (c[k].charUpdate.traj.X > 1000f)
							{
								c[k].charUpdate.traj.X = 1000f;
							}
							if (c[k].charUpdate.traj.X < -1000f)
							{
								c[k].charUpdate.traj.X = -1000f;
							}
							c[k].charUpdate.traj.Y = -100f;
							c[k].charAnim.SetAnim("explode", c[k].charUpdate, overRide: true);
							c[k].charUpdate.ethereal = true;
							c[k].charAnim.frame = 1.99f;
						}
					}
					else
					{
						c[k].charUpdate.traj.X = sprite[i].traj.X * 0.05f;
						Vector2 vector = new Vector2(c[k].charUpdate.loc.X, sprite[i].loc.Y);
						if (isGiant)
						{
							vector.X = sprite[i].loc.X;
						}
						if (vector.Y > c[k].charUpdate.loc.Y - 20f)
						{
							vector.Y = c[k].charUpdate.loc.Y - 20f - Rand.GetRandomFloat(0f, 30f);
						}
						if (sprite[i].type == 21 || sprite[i].type == 101)
						{
							vector = sprite[i].loc;
						}
						if (sprite[i].type != 101)
						{
							spriteMan.MakeSquirt(vector, sprite[i].traj * -0.001f, num6, k);
							if (Rand.CointToss(0.3f))
							{
								spriteMan.MakeSquirt(vector + sprite[i].traj * 0.02f, sprite[i].traj * 0.004f, num6, k);
							}
						}
						num10 = sprite[i].type switch
						{
							37 => 0.5f, 
							11 => 0.5f, 
							98 => 1f, 
							101 => 0.3f, 
							_ => 5f, 
						};
						if (!isJuggernaut && !c[k].GetMeta().isBoss && (Rand.CointToss(0.2f) || sprite[i].type == 21 || c[k].charUpdate.face != face))
						{
							c[k].charAnim.SetAnim("hit", c[k].charUpdate, overRide: true);
						}
						if (sprite[i].type != 98 && c[k].charUpdate.hp < 0f)
						{
							if (c[k].charUpdate.state != CharUpdate.State.Airborne)
							{
								if (Rand.CointToss(0.1f))
								{
									c[k].charAnim.SetAnim("gunkill", c[k].charUpdate);
								}
								if (Rand.CointToss(0.1f))
								{
									c[k].charAnim.SetAnim("gunkill2", c[k].charUpdate);
								}
							}
							if (flag5)
							{
								if (Rand.CointToss(0.5f))
								{
									c[k].charAnim.SetAnim("gunkill", c[k].charUpdate);
								}
								else
								{
									c[k].charAnim.SetAnim("gunkill2", c[k].charUpdate);
								}
							}
						}
						if (c[k].charUpdate.state == CharUpdate.State.Airborne)
						{
							if (!isJuggernaut)
							{
								c[k].charAnim.SetAnim("jmid", c[k].charUpdate, overRide: true);
								c[k].charUpdate.airJuggleFrame = 0.15f;
								c[k].charUpdate.airJuggleVec = c[k].charUpdate.loc + sprite[i].traj * 0.01f;
								if (!flag2 && sprite[i].type != 98 && ((sprite[i].type == 37 && c[k].charUpdate.hp < 0f) || c[k].charUpdate.hp < c[k].charUpdate.mhp / -2f))
								{
									if (sprite[i].type == 37)
									{
										c[k].charUpdate.airJuggleFrame = 0f;
										if (sprite[i].traj.X > 0f)
										{
											c[k].charUpdate.traj.X = 1000f;
										}
										if (sprite[i].traj.X < 0f)
										{
											c[k].charUpdate.traj.X = -1000f;
										}
										c[k].charUpdate.floating = false;
									}
									c[k].charAnim.SetAnim("explode", c[k].charUpdate, overRide: true);
									c[k].charUpdate.ethereal = true;
									c[k].charAnim.frame = 1.99f;
								}
							}
						}
						else if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.Instakill && c[k].charUpdate.hp < 0f && c[k].charAnim.CheckAnim("explode") > -1)
						{
							c[k].charUpdate.state = CharUpdate.State.Airborne;
							c[k].charUpdate.traj.X = sprite[i].traj.X;
							if (c[k].charUpdate.traj.X > 500f)
							{
								c[k].charUpdate.traj.X = 500f;
							}
							if (c[k].charUpdate.traj.X < -500f)
							{
								c[k].charUpdate.traj.X = -500f;
							}
							c[k].charUpdate.traj.Y = -100f;
							c[k].charAnim.SetAnim("explode", c[k].charUpdate, overRide: true);
							c[k].charUpdate.ethereal = true;
							c[k].charAnim.frame = 1.99f;
						}
					}
					if (Rand.CointToss(0.2f))
					{
						Vector2 loc3 = new Vector2(c[k].charUpdate.loc.X, sprite[i].loc.Y);
						for (int m = 0; m < 10; m++)
						{
							spriteMan.AddSprite(0, loc3, -sprite[i].traj * 0.2f + Rand.GetRandomVec2(-400f, 400f, -400f, 400f), 0f, 0, 0);
						}
					}
					sprite[i].frame = -1f;
					if (sprite[i].type == 98)
					{
						spriteMan.StopGib(sprite[i].flags);
					}
				}
				else if (sprite[i].type == 12)
				{
					num10 = DoHit(sprite, i, c, k, isJuggernaut, num10, spriteMan, num6, state, flag5, flag2);
				}
				if (c[sprite[i].owner].team == c[k].team && !(Game1.pvpMode && Game1.IsPlayerChar(sprite[i].owner) && Game1.IsPlayerChar(k)))
				{
					num10 /= 4f;
				}
				num10 *= Game1.charMeta[c[sprite[i].owner].charMeta].damage;
				if (c[sprite[i].owner].team == Character.Team.GoodGuys && DebugManager.instakill)
				{
					num10 *= 10f;
				}
				if (c[k].team == Character.Team.GoodGuys)
				{
					switch (GameSettings.difficulty)
					{
					case 0:
						num10 *= 0.1f;
						break;
					case 1:
						num10 *= 0.5f;
						break;
					case 2:
						num10 *= 1f;
						break;
					case 3:
						num10 *= 1.4f;
						break;
					case 4:
						num10 *= 2f;
						break;
					case 5:
						num10 *= 3f;
						break;
					}
					if (GameState.paxDemoMode || GameState.longDemoMode)
					{
						num10 *= 0.2f;
					}
					if (Game1.GetPlayers() >= 2)
					{
						num10 *= 1.5f;
					}
					if (k < 2)
					{
						Game1.rumbleManager.SetRumble(k, 0.5f);
					}
				}
				else if (Game1.netSession.IsClient() && sprite[i].owner == 1)
				{
					c[k].charUpdate.clientOwned = 1f;
				}
				if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
				{
					Level.ArcadeSpecial arcadeSpecial2 = Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial;
					if (arcadeSpecial2 == Level.ArcadeSpecial.Instakill)
					{
						num10 = ((c[k].team != Character.Team.BadGuys || c[sprite[i].owner].team != Character.Team.GoodGuys) ? (num10 * 5f) : (num10 * 10f));
					}
				}
				if (flag6)
				{
					switch (GameSettings.difficulty)
					{
					case 0:
						num10 = 0f;
						break;
					case 1:
						num10 = 1f;
						break;
					case 2:
						num10 = 2f;
						break;
					case 3:
						num10 = 3f;
						break;
					case 4:
					case 5:
						num10 = 5f;
						break;
					}
				}
				if (sprite[i].owner < 2)
				{
					if (Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.HacksawBead))
					{
						num10 *= 1.1f;
					}
					if (c[k].GetMeta().isRobot && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.RobotBead))
					{
						num10 *= 1.2f;
					}
					if (c[k].GetMeta().isZombie && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.CrossBead))
					{
						num10 *= 1.8f;
					}
					if (Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.WineBead))
					{
						num10 *= (c[sprite[i].owner].charUpdate.mhp - c[sprite[i].owner].charUpdate.hp) / c[sprite[i].owner].charUpdate.mhp * 0.5f + 1f;
					}
					if (Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.MathBead))
					{
						num10 *= 1f + (float)Game1.gamePlayerMgr.gamePlayer[sprite[i].owner].comboCount / 1000f;
					}
					if (Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BatBead))
					{
						num10 *= 0.9f;
						c[sprite[i].owner].charUpdate.hp += num10 * 0.1f;
						if (c[sprite[i].owner].charUpdate.hp > c[sprite[i].owner].charUpdate.mhp)
						{
							c[sprite[i].owner].charUpdate.hp = c[sprite[i].owner].charUpdate.mhp;
						}
					}
					if (Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.SquidBead) && sprite[i].type == 12)
					{
						switch (sprite[i].flags)
						{
						case 11:
						case 22:
						case 47:
						case 48:
						case 49:
						case 50:
						case 51:
						case 74:
						case 93:
						case 123:
							num10 *= 2f;
							break;
						}
					}
					int type3 = sprite[i].type;
					if ((type3 == 11 || type3 == 21 || type3 == 37) && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.GunBead))
					{
						num10 *= 1.2f;
					}
				}
				if (k < 2)
				{
					if (Game1.beadMgr.beads[k].HasBead(InvCatalog.InvItemName.CrownBead))
					{
						num10 *= 1.1f;
						c[sprite[i].owner].charUpdate.hp -= num10;
					}
					if (Game1.beadMgr.beads[k].HasBead(InvCatalog.InvItemName.BoneBead) && sprite[i].type == 12)
					{
						switch (sprite[i].flags)
						{
						case 0:
						case 1:
						case 3:
						case 42:
						case 62:
						case 84:
							num10 *= 0.8f;
							break;
						}
					}
					if (Game1.beadMgr.beads[k].HasBead(InvCatalog.InvItemName.RocketBead))
					{
						switch (sprite[i].type)
						{
						case 20:
						case 23:
						case 24:
							num10 *= 0.8f;
							break;
						}
					}
					if (Game1.beadMgr.beads[k].HasBead(InvCatalog.InvItemName.ShieldBead))
					{
						num10 *= 0.9f;
					}
					if (Game1.beadMgr.beads[k].HasBead(InvCatalog.InvItemName.IceBead) && sprite[i].type == 12 && sprite[i].flags == 86)
					{
						num10 *= 0.7f;
					}
				}
				if (flag7)
				{
					num10 = 0f;
				}
				if (sprite[i].owner > -1 && sprite[i].owner < 2)
				{
					num10 *= Game1.gamePlayerMgr.GetUpgradeDamage(sprite[i]);
				}
				if (parried)
				{
					ParryReflect(c, sprite, i, k, num10, spriteMan, loc2);
					num10 = 0f;
				}
				c[k].charUpdate.hp -= num10;
				c[k].charUpdate.cloudCharge = 0f;
				if (sprite[i].owner < Game1.gamePlayerMgr.gamePlayer.Length)
				{
					if (Game1.gamePlayerMgr.gamePlayer[sprite[i].owner].active)
					{
						if (c[k].charUpdate.hp > 0f)
						{
							Game1.gamePlayerMgr.gamePlayer[sprite[i].owner].DoHit(num10);
						}
						else
						{
							Game1.gamePlayerMgr.gamePlayer[sprite[i].owner].DoHit(0f);
						}
					}
				}
				else if (k < 2)
				{
					Game1.gamePlayerMgr.gamePlayer[k].damage += num10;
				}
				DeathCheck(c, k);
				if (c[k].charUpdate.locked && c[k].charUpdate.hp < 0f)
				{
					c[k].charAnim.SetAnim(c[k].GetMeta().lockdie_anim, c[k].charUpdate);
					TrySlow(c, sprite[i].owner, k, 0.03f);
					Sound.PlaySnd(Sound.Category.FX, "bass");
					QuakeManager.SetBright(0.4f);
					QuakeManager.SetQuake(0.5f);
					spriteMan.MakeHitSplash(sprite[i].loc, default, 1f);
					Game1.killManager.doBits(1f);
				}
				if (charMeta.isJuggernaut)
				{
					if (charMeta.isPuppet)
					{
						HitPuppet(state, traj, c, num10, k, sprite, i, spriteMan);
					}
					else
					{
						HitJuggernaut(state, traj, c, num10, k, sprite, i, spriteMan);
					}
				}
				if (parried)
				{
					c[k].charUpdate.hp = parryHp;
					c[k].charUpdate.state = state;
					c[k].charUpdate.traj = traj;
					c[k].charUpdate.parryFrame = 0.15f;
					c[k].charUpdate.parryCool = 0.2f;
					CharKeys.PlayParryPose(c[k]);
				}
			}
			if (sprite[i].type == 12 || sprite[i].type == 20 || sprite[i].type == 98)
			{
				sprite[i].exists = false;
			}
			if (sprite[i].type == 12)
			{
				switch (sprite[i].flags)
				{
				case 42:
					c[sprite[i].owner].charUpdate.cloudCharge = 0f;
					break;
				case 19:
					c[sprite[i].owner].charUpdate.cloudCharge = 0f;
					break;
				case 3:
					c[sprite[i].owner].charUpdate.cloudCharge = 0f;
					break;
				}
			}
		}
	}

	private float DoHit(Sprite[] sprite, int i, Character[] c, int n, bool giant, float hVal, SpriteManager spriteMan, int sparks, CharUpdate.State pState, bool dying, bool nomnom)
	{
		if (c[n].charUpdate.ethereal)
		{
			return 0f;
		}
		if (c[sprite[i].owner].charUpdate.charGrab.grabbedByChar > -1)
		{
			return 0f;
		}
		_ = c[n].charUpdate.face;
		if (Game1.gameMap.firstExe && c[n].team == Character.Team.BadGuys)
		{
			c[n].charUpdate.hp = 0f;
			Game1.gameMap.firstExe = false;
		}
		CharMeta charMeta = Game1.charMeta[c[n].charMeta];
		switch (sprite[i].flags)
		{
		case 129:
			hVal = 0f;
			if (c[n].charAnim.CheckAnim("hypnostabbed") > -1 && c[n].charUpdate.state == CharUpdate.State.Grounded && c[n].charUpdate.charGrab.grabbedByChar < 0 && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charUpdate.lastSpecial;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				c[n].charAnim.SetAnim("hypnostabbed", c[n].charUpdate);
				if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded;
					c[sprite[i].owner].charUpdate.loc = c[n].charUpdate.loc;
				}
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				if (sprite[i].traj.X > 0f)
				{
					c[n].charUpdate.face = 0;
				}
				else
				{
					c[n].charUpdate.face = 1;
				}
			}
			break;
		case 128:
			hVal = 0f;
			if (c[n].charAnim.CheckAnim("marachopped") > -1 && c[n].charUpdate.state == CharUpdate.State.Grounded && c[n].charUpdate.charGrab.grabbedByChar < 0 && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charUpdate.lastSpecial;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				c[n].charAnim.SetAnim("marachopped", c[n].charUpdate);
				if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded;
					c[sprite[i].owner].charUpdate.loc = c[n].charUpdate.loc;
				}
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				if (sprite[i].traj.X > 0f)
				{
					c[n].charUpdate.face = 0;
				}
				else
				{
					c[n].charUpdate.face = 1;
				}
			}
			break;
		case 126:
			hVal = 0f;
			if (c[n].charAnim.CheckAnim("chefgrabbed") > -1 && c[n].charUpdate.state == CharUpdate.State.Grounded && c[n].charUpdate.charGrab.grabbedByChar < 0 && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charUpdate.lastSpecial;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				c[n].charAnim.SetAnim("chefgrabbed", c[n].charUpdate);
				if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded;
					c[sprite[i].owner].charUpdate.loc = c[n].charUpdate.loc;
				}
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				if (sprite[i].traj.X > 0f)
				{
					c[n].charUpdate.face = 0;
				}
				else
				{
					c[n].charUpdate.face = 1;
				}
			}
			break;
		case 65:
			hVal = 0f;
			if (c[n].charAnim.CheckAnim("zgrabbed") > -1 && c[n].charUpdate.state == CharUpdate.State.Grounded && c[n].charUpdate.charGrab.grabbedByChar < 0 && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charUpdate.lastSpecial;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				c[n].charAnim.SetAnim("zgrabbed", c[n].charUpdate);
				if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded;
					c[sprite[i].owner].charUpdate.loc = c[n].charUpdate.loc;
				}
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				if (sprite[i].traj.X > 0f)
				{
					c[n].charUpdate.face = 0;
				}
				else
				{
					c[n].charUpdate.face = 1;
				}
			}
			break;
		case 82:
			hVal = 0f;
			if (c[n].charAnim.CheckAnim("slavgrabbed") > -1 && c[n].charUpdate.state == CharUpdate.State.Airborne && c[n].charUpdate.charGrab.grabbedByChar < 0 && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				c[n].charUpdate.loc = c[sprite[i].owner].charUpdate.loc;
				c[n].charUpdate.state = (c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded);
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charUpdate.lastSpecial;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				c[n].charAnim.SetAnim("slavgrabbed", c[n].charUpdate);
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				if (sprite[i].traj.X > 0f)
				{
					c[n].charUpdate.face = 0;
				}
				else
				{
					c[n].charUpdate.face = 1;
				}
			}
			break;
		case 108:
			hVal = 0f;
			if (c[n].charAnim.CheckAnim("puppetgrabbed") > -1 && c[n].charUpdate.charGrab.grabbedByChar < 0 && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				c[n].charUpdate.loc = c[sprite[i].owner].charUpdate.loc;
				c[n].charUpdate.state = (c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded);
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charUpdate.lastSpecial;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				c[n].charAnim.SetAnim("puppetgrabbed", c[n].charUpdate);
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				if (sprite[i].traj.X > 0f)
				{
					c[n].charUpdate.face = 0;
				}
				else
				{
					c[n].charUpdate.face = 1;
				}
			}
			break;
		case 64:
			hVal = 0f;
			if (c[n].charAnim.CheckAnim("wardengrabbed") > -1 && c[n].charUpdate.state == CharUpdate.State.Grounded && c[n].charUpdate.charGrab.grabbedByChar < 0 && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charUpdate.lastSpecial;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				c[n].charAnim.SetAnim("wardengrabbed", c[n].charUpdate);
				if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded;
					c[sprite[i].owner].charUpdate.loc = c[n].charUpdate.loc;
				}
				Sound.PlaySnd(Sound.Category.FX, "hit");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				if (sprite[i].traj.X > 0f)
				{
					c[n].charUpdate.face = 0;
				}
				else
				{
					c[n].charUpdate.face = 1;
				}
			}
			break;
		case 11:
		case 117:
		{
			hVal = 0f;
			if (!c[n].GetGrabbable(sprite[i].flags == 117) || c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				break;
			}
			c[n].charUpdate.giantVulnTimer = 0f;
			c[n].charUpdate.giantShrugDamage = 0f;
			bool flag = false;
			if (c[n].charAnim.CheckAnim(c[n].GetMeta().yukiwalled_anim) > -1)
			{
				if (c[sprite[i].owner].charUpdate.face == 0)
				{
					if (Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(-35f, -20f)) && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(-35f, -75f)))
					{
						flag = true;
					}
				}
				else if (c[sprite[i].owner].charUpdate.face == 1 && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(35f, -20f)) && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(35f, -75f)))
				{
					flag = true;
				}
			}
			c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
			if (c[n].charMeta == 88 && c[n].charUpdate.charGrab.grabbedByChar > -1)
			{
				int grabbedByChar = c[n].charUpdate.charGrab.grabbedByChar;
				c[grabbedByChar].charUpdate.charGrab.grabbing = false;
				c[grabbedByChar].charAnim.SetAnim("blastcorpse", c[grabbedByChar].charUpdate);
				c[grabbedByChar].charUpdate.ethereal = true;
				c[grabbedByChar].charUpdate.inactive = true;
				c[grabbedByChar].charUpdate.face = 1 - c[n].charUpdate.face;
				c[grabbedByChar].charUpdate.dyingFrame = 1.9f;
			}
			c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
			c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
			c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
			c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
			c[sprite[i].owner].charUpdate.StainWeapon(sparks);
			c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
			if (c[n].charUpdate.state == CharUpdate.State.Airborne)
			{
				c[n].charAnim.SetAnim(charMeta.jkatgrabbed_anim, c[n].charUpdate, overRide: true);
				c[n].charUpdate.canDoubleJump = true;
				TrySlow(c, sprite[i].owner, n, 0.01f);
				c[n].charUpdate.airJuggleFrame = 0f;
				c[n].charUpdate.traj.Y = -400f;
			}
			else
			{
				bool flag2 = c[n].charAnim.animName == charMeta.hitland_anim;
				if (nomnom)
				{
					c[n].charAnim.SetAnim(charMeta.jkatgrabbed_anim, c[n].charUpdate, overRide: true);
				}
				else
				{
					c[n].charAnim.SetAnim(charMeta.katgrabbed_anim, c[n].charUpdate, overRide: true);
				}
				if (c[n].charUpdate.hp < c[n].charUpdate.mhp / 4f)
				{
					if (flag)
					{
						c[n].charUpdate.state = CharUpdate.State.Grounded;
						c[n].charAnim.SetAnim(c[n].GetMeta().yukiwalled_anim, c[n].charUpdate, overRide: true);
					}
					else if (sprite[i].flags == 77 || flag2)
					{
						c[n].charUpdate.state = CharUpdate.State.Grounded;
						c[n].charAnim.SetAnim(c[n].GetMeta().vampslammed_anim, c[n].charUpdate, overRide: true);
					}
				}
				if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded;
					c[sprite[i].owner].charUpdate.loc = c[n].charUpdate.loc;
				}
			}
			Sound.PlaySnd(Sound.Category.FX, "hit");
			Sound.PlaySnd(Sound.Category.FX, "slash1");
			ScrollManager.zoom += 0.1f;
			QuakeManager.SetQuake(0.2f);
			QuakeManager.SetBright(0.2f);
			if (sprite[i].traj.X > 0f)
			{
				c[n].charUpdate.face = 0;
			}
			else
			{
				c[n].charUpdate.face = 1;
			}
			break;
		}
		case 47:
		case 48:
		case 49:
		case 50:
		case 51:
		{
			hVal = 0f;
			if (!c[n].GetGrabbable() || c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				break;
			}
			c[n].charUpdate.giantVulnTimer = 0f;
			c[n].charUpdate.giantShrugDamage = 0f;
			bool flag3 = false;
			if (c[n].charAnim.CheckAnim(c[n].GetMeta().dishwalled_anim) > -1)
			{
				if (c[sprite[i].owner].charUpdate.face == 0)
				{
					if (Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(-35f, -20f)) && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(-35f, -75f)))
					{
						flag3 = true;
					}
				}
				else if (c[sprite[i].owner].charUpdate.face == 1 && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(35f, -20f)) && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(35f, -75f)))
				{
					flag3 = true;
				}
			}
			c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
			c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
			c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
			c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
			c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
			bool flag4 = c[n].charAnim.animName == charMeta.hitland_anim && c[n].charAnim.CheckAnim(charMeta.dishslammed_anim) > -1;
			bool flag5 = false;
			if (flag4 && sprite[i].flags == 50 && c[n].charAnim.CheckAnim("dishhgmessy") > -1)
			{
				flag5 = true;
				flag4 = false;
			}
			if (c[n].charUpdate.state == CharUpdate.State.Airborne)
			{
				c[n].charAnim.SetAnim(charMeta.dishgrabbed_anim, c[n].charUpdate, overRide: true);
				c[n].charUpdate.canDoubleJump = true;
				c[n].charUpdate.airJuggleFrame = 0f;
				c[n].charUpdate.traj.Y = -400f;
			}
			else
			{
				c[n].charAnim.SetAnim(charMeta.dishgrabbed_anim, c[n].charUpdate, overRide: true);
				if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded;
					c[sprite[i].owner].charUpdate.loc = c[n].charUpdate.loc;
				}
			}
			Sound.PlaySnd(Sound.Category.FX, "hit");
			ScrollManager.zoom += 0.1f;
			QuakeManager.SetQuake(0.2f);
			QuakeManager.SetBright(0.2f);
			if (sprite[i].traj.X > 0f)
			{
				c[n].charUpdate.face = 0;
			}
			else
			{
				c[n].charUpdate.face = 1;
			}
			if (c[n].charUpdate.state != CharUpdate.State.Grounded || !(c[n].charUpdate.hp < c[n].charUpdate.mhp / 4f))
			{
				break;
			}
			if (flag3)
			{
				c[n].charUpdate.state = CharUpdate.State.Grounded;
				c[n].charAnim.SetAnim(c[n].GetMeta().dishwalled_anim, c[n].charUpdate, overRide: true);
			}
			else if (sprite[i].flags == 77 || flag4)
			{
				c[n].charUpdate.state = CharUpdate.State.Grounded;
				c[n].charAnim.SetAnim(c[n].GetMeta().dishslammed_anim, c[n].charUpdate, overRide: true);
			}
			else
			{
				if (nomnom)
				{
					break;
				}
				switch (sprite[i].flags)
				{
				case 47:
					c[n].charAnim.SetAnim("dishkatmessy", c[n].charUpdate, overRide: true);
					break;
				case 50:
					if (flag5)
					{
						c[n].charAnim.SetAnim("dishhgmessy", c[n].charUpdate, overRide: true);
					}
					else
					{
						c[n].charAnim.SetAnim("dishhmessy", c[n].charUpdate, overRide: true);
					}
					break;
				case 48:
					c[n].charAnim.SetAnim("dishcmessy", c[n].charUpdate, overRide: true);
					break;
				case 49:
					c[n].charAnim.SetAnim("dishsmessy", c[n].charUpdate, overRide: true);
					break;
				case 51:
					c[n].charAnim.SetAnim("dishtmessy", c[n].charUpdate, overRide: true);
					break;
				}
			}
			break;
		}
		case 74:
			if (c[n].charUpdate.state == CharUpdate.State.Grounded && c[n].charUpdate.hp < c[n].charUpdate.mhp / 4f && !nomnom && c[n].charAnim.CheckAnim("cgrabbed") > -1)
			{
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[sprite[i].owner].charUpdate.StainWeapon(sparks);
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				c[n].charAnim.SetAnim("cgrabbed", c[n].charUpdate, overRide: true);
				Sound.PlaySnd(Sound.Category.FX, "hit");
				Sound.PlaySnd(Sound.Category.FX, "slash1");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				if (sprite[i].traj.X > 0f)
				{
					c[n].charUpdate.face = 0;
				}
				else
				{
					c[n].charUpdate.face = 1;
				}
			}
			break;
		case 22:
		case 77:
		case 123:
		{
			hVal = 0f;
			if (!c[n].GetGrabbable() || c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				break;
			}
			c[n].charUpdate.giantVulnTimer = 0f;
			c[n].charUpdate.giantShrugDamage = 0f;
			bool flag7 = false;
			if (c[n].charAnim.CheckAnim(c[n].GetMeta().yukiwalled_anim) > -1)
			{
				if (c[sprite[i].owner].charUpdate.face == 0)
				{
					if (Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(-35f, -20f)) && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(-35f, -75f)))
					{
						flag7 = true;
					}
				}
				else if (c[sprite[i].owner].charUpdate.face == 1 && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(35f, -20f)) && Game1.gameMap.CurMap().TestCol(c[n].charUpdate.loc + new Vector2(35f, -75f)))
				{
					flag7 = true;
				}
			}
			c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
			c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
			c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
			c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
			c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
			c[sprite[i].owner].charUpdate.StainWeapon(sparks);
			c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
			if (c[n].charUpdate.state == CharUpdate.State.Airborne)
			{
				c[n].charAnim.SetAnim(charMeta.jkamgrabbed_anim, c[n].charUpdate, overRide: true);
				c[n].charUpdate.canDoubleJump = true;
				TrySlow(c, sprite[i].owner, n, 0.01f);
				c[n].charUpdate.airJuggleFrame = 0f;
				c[n].charUpdate.traj.Y = -400f;
			}
			else
			{
				bool flag8 = c[n].charAnim.animName == charMeta.hitland_anim;
				if (nomnom)
				{
					c[n].charAnim.SetAnim(charMeta.jkamgrabbed_anim, c[n].charUpdate, overRide: true);
				}
				else
				{
					c[n].charAnim.SetAnim(charMeta.kamgrabbed_anim, c[n].charUpdate, overRide: true);
				}
				if (c[n].charUpdate.hp < c[n].charUpdate.mhp / 4f)
				{
					if (flag7)
					{
						c[n].charUpdate.state = CharUpdate.State.Grounded;
						c[n].charAnim.SetAnim(c[n].GetMeta().yukiwalled_anim, c[n].charUpdate, overRide: true);
					}
					else if (sprite[i].flags == 77 || flag8)
					{
						c[n].charUpdate.state = CharUpdate.State.Grounded;
						c[n].charAnim.SetAnim(c[n].GetMeta().vampslammed_anim, c[n].charUpdate, overRide: true);
					}
					else if (sprite[i].flags == 123)
					{
						switch (Rand.GetRandomInt(0, 3))
						{
						case 0:
							c[n].charAnim.SetAnim("clawdestroyed", c[n].charUpdate, overRide: true);
							break;
						case 1:
							c[n].charAnim.SetAnim("clawdecapped", c[n].charUpdate, overRide: true);
							break;
						case 2:
							c[n].charAnim.SetAnim("clawarmed", c[n].charUpdate, overRide: true);
							break;
						}
					}
				}
				if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[sprite[i].owner].charUpdate.state = CharUpdate.State.Grounded;
					c[sprite[i].owner].charUpdate.loc = c[n].charUpdate.loc;
				}
			}
			Sound.PlaySnd(Sound.Category.FX, "hit");
			Sound.PlaySnd(Sound.Category.FX, "slash1");
			ScrollManager.zoom += 0.1f;
			QuakeManager.SetQuake(0.2f);
			QuakeManager.SetBright(0.2f);
			if (sprite[i].traj.X > 0f)
			{
				c[n].charUpdate.face = 0;
			}
			else
			{
				c[n].charUpdate.face = 1;
			}
			break;
		}
		case 16:
			hVal = 0f;
			if (c[n].GetSawable() && !c[sprite[i].owner].charUpdate.charGrab.grabbing && c[n].charUpdate.state == CharUpdate.State.Grounded)
			{
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[sprite[i].owner].charUpdate.StainChainsaw(sparks);
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				if (c[n].GetMeta().isSawer)
				{
					c[n].charAnim.SetAnim("dueled", c[n].charUpdate);
					c[n].charUpdate.charGrab.duelCount = 0;
					Sound.PlaySnd(Sound.Category.FX, "circusaw");
				}
				else
				{
					c[n].charAnim.SetAnim("sawkill", c[n].charUpdate);
					Game1.killManager.DoKill(n);
				}
				c[n].charRender.melee = c[sprite[i].owner].charRender.melee;
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetBright(0.2f);
			}
			break;
		case 25:
			hVal = 0f;
			if (c[n].GetSawable() && !c[sprite[i].owner].charUpdate.charGrab.grabbing && c[n].charUpdate.state == CharUpdate.State.Grounded)
			{
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[sprite[i].owner].charUpdate.StainChainsaw(sparks);
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				if (c[n].GetMeta().isSawer)
				{
					c[n].charAnim.SetAnim("dueled", c[n].charUpdate);
					c[n].charUpdate.charGrab.duelCount = 0;
					Sound.PlaySnd(Sound.Category.FX, "circusaw");
				}
				else
				{
					c[n].charAnim.SetAnim("sawkill2", c[n].charUpdate);
					Game1.killManager.DoKill(n);
				}
				c[n].charRender.melee = c[sprite[i].owner].charRender.melee;
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetBright(0.2f);
			}
			break;
		case 24:
			if (c[n].charUpdate.state == CharUpdate.State.Grounded)
			{
				if (!giant)
				{
					c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
					c[n].charUpdate.state = CharUpdate.State.Airborne;
					c[n].charUpdate.traj.Y = Rand.GetRandomFloat(-600f, -400f);
					if (sprite[i].traj.X > 0f)
					{
						c[n].charUpdate.traj.X = 400f;
						c[n].charUpdate.face = 0;
					}
					else
					{
						c[n].charUpdate.traj.X = -400f;
						c[n].charUpdate.face = 1;
					}
				}
				hVal = 10f;
				TrySlow(c, sprite[i].owner, n, 0.02f);
				spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 1f);
				Sound.PlaySnd(Sound.Category.FX, "hit");
				if (sparks != 2)
				{
					Sound.PlaySnd(Sound.Category.FX, "crunch");
				}
			}
			else
			{
				hVal = 0f;
			}
			break;
		case 0:
		case 1:
		case 2:
		case 3:
		case 4:
		case 23:
		case 42:
		case 67:
		case 68:
		case 84:
		case 135:
			if (!giant)
			{
				c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
			}
			if (sparks != 3)
			{
				spriteMan.AddSprite((sparks == 2) ? 22 : 4, sprite[i].loc, sprite[i].scaling, sprite[i].rotation, sprite[i].face, 0);
				int flags = sprite[i].flags;
				if (flags == 23 || flags == 68)
				{
					c[sprite[i].owner].charUpdate.StainChainsaw(sparks);
				}
				else
				{
					c[sprite[i].owner].charUpdate.StainWeapon(sparks);
				}
				c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
			}
			if (Game1.gameMap.nekoToasty && sprite[i].owner < 2)
			{
				int flags2 = sprite[i].flags;
				if (flags2 == 2 || flags2 == 23 || flags2 == 67)
				{
					Game1.gameMap.PopUpNekoToasty();
				}
			}
			switch (sprite[i].flags)
			{
			case 0:
			case 1:
				if (c[n].charUpdate.state == CharUpdate.State.Airborne)
				{
					c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
					c[n].charUpdate.state = CharUpdate.State.Airborne;
					c[n].charUpdate.traj.Y = -150f;
					c[n].charUpdate.traj.X /= 10f;
					if (!giant && pState == CharUpdate.State.Airborne && c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
					{
						Vector2 airJuggleVec3 = (c[sprite[i].owner].charUpdate.loc + c[n].charUpdate.loc) / 2f;
						c[n].charUpdate.airJuggleVec = airJuggleVec3;
						c[sprite[i].owner].charUpdate.airJuggleVec = airJuggleVec3;
						if (c[sprite[i].owner].charUpdate.face == 1)
						{
							c[sprite[i].owner].charUpdate.airJuggleVec.X -= 50f;
							c[n].charUpdate.airJuggleVec.X += 40f;
						}
						else
						{
							c[sprite[i].owner].charUpdate.airJuggleVec.X += 50f;
							c[n].charUpdate.airJuggleVec.X -= 40f;
						}
						c[n].charUpdate.airJuggleFrame = 0.25f;
						c[sprite[i].owner].charUpdate.airJuggleFrame = 0.25f;
					}
				}
				else if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne && giant)
				{
					c[sprite[i].owner].charUpdate.airJuggleFrame = 0.25f;
					c[sprite[i].owner].charUpdate.airJuggleVec = c[sprite[i].owner].charUpdate.loc;
				}
				break;
			case 84:
				if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
				{
					Sound.PlaySnd(Sound.Category.FX, "cowbell");
				}
				if (!giant)
				{
					c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
					c[n].charUpdate.state = CharUpdate.State.Airborne;
					c[n].charUpdate.traj.Y = -1300f;
					c[n].charUpdate.traj.X /= 10f;
				}
				c[n].charUpdate.airJuggleFrame = 0f;
				c[sprite[i].owner].charUpdate.airJuggleFrame = 0f;
				hVal = 20f;
				if (sparks != 2)
				{
					Sound.PlaySnd(Sound.Category.FX, "chunk");
				}
				TrySlow(c, sprite[i].owner, n, 0.01f);
				KickBurst(sprite[i], n);
				QuakeManager.SetContrast(0.2f);
				QuakeManager.SetQuake(0.6f);
				ScrollManager.scroll.Y += 10f;
				break;
			case 2:
				if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
				{
					Sound.PlaySnd(Sound.Category.FX, "cowbell");
				}
				if (!giant)
				{
					c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
					c[n].charUpdate.state = CharUpdate.State.Airborne;
					c[n].charUpdate.traj.Y = -900f;
					c[n].charUpdate.traj.X /= 10f;
				}
				KickBurst(sprite[i], n);
				c[n].charUpdate.airJuggleFrame = 0f;
				c[sprite[i].owner].charUpdate.airJuggleFrame = 0f;
				hVal = 20f;
				break;
			case 67:
				if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
				{
					Sound.PlaySnd(Sound.Category.FX, "cowbell");
				}
				if (!giant)
				{
					c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
					c[n].charUpdate.state = CharUpdate.State.Airborne;
					c[n].charUpdate.traj.Y = -1200f;
					c[n].charUpdate.traj.X /= 10f;
				}
				KickBurst(sprite[i], n);
				c[n].charUpdate.airJuggleFrame = 0f;
				c[sprite[i].owner].charUpdate.airJuggleFrame = 0f;
				hVal = 20f;
				break;
			case 23:
			case 68:
				if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
				{
					Sound.PlaySnd(Sound.Category.FX, "cowbell");
				}
				if (!giant)
				{
					c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
					c[n].charUpdate.state = CharUpdate.State.Airborne;
					c[n].charUpdate.traj.Y = -1300f;
					c[n].charUpdate.traj.X /= 10f;
				}
				hVal = 25f;
				Game1.killManager.doBits(0.5f);
				Sound.PlaySnd(Sound.Category.FX, "hit");
				if (sparks != 2)
				{
					Sound.PlaySnd(Sound.Category.FX, "chunk");
				}
				TrySlow(c, sprite[i].owner, n, 0.01f);
				KickBurst(sprite[i], n);
				QuakeManager.SetContrast(0.2f);
				QuakeManager.SetQuake(0.6f);
				ScrollManager.scroll.Y += 10f;
				break;
			case 4:
			case 42:
				if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
				{
					Sound.PlaySnd(Sound.Category.FX, "cowbell");
				}
				if (!giant)
				{
					c[n].charAnim.SetAnim("jmid", c[n].charUpdate);
					c[n].charAnim.SetAnim("spinhit", c[n].charUpdate);
					if (c[n].charUpdate.state == CharUpdate.State.Airborne)
					{
						c[n].charUpdate.traj.Y = 0f;
						c[n].charUpdate.traj.X *= 2f;
					}
					else
					{
						c[n].charUpdate.state = CharUpdate.State.Airborne;
						c[n].charUpdate.traj.Y = -300f;
						c[n].charUpdate.traj.X *= 2f;
					}
				}
				KickBurst(sprite[i], n);
				spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]) * 0.25f, 1f);
				c[n].charUpdate.airJuggleFrame = 0f;
				hVal = 20f;
				Sound.PlaySnd(Sound.Category.FX, "hit");
				if (sparks != 2)
				{
					Sound.PlaySnd(Sound.Category.FX, "chunk");
				}
				if (c[sprite[i].owner].GetMeta().special == 3)
				{
					if (c[sprite[i].owner].charUpdate.cloudCharge > 0f)
					{
						float cloudCharge = c[sprite[i].owner].charUpdate.cloudCharge;
						hVal += cloudCharge * 20f;
						if (cloudCharge > 0.5f)
						{
							QuakeManager.SetContrast(0.5f);
							Sound.PlaySnd(Sound.Category.FX, "crush");
						}
						if (cloudCharge > 1f)
						{
							QuakeManager.SetContrast(0.75f);
							QuakeManager.SetBright(0.25f);
							Sound.PlaySnd(Sound.Category.FX, "bass");
						}
						if (cloudCharge > 3f)
						{
							QuakeManager.SetContrast(1f);
							QuakeManager.SetBright(0.5f);
						}
					}
				}
				else
				{
					TrySlow(c, sprite[i].owner, n, 0.01f);
				}
				break;
			case 3:
			case 135:
				if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
				{
					Sound.PlaySnd(Sound.Category.FX, "cowbell");
				}
				if (!giant)
				{
					bool flag6 = false;
					if (c[n].charUpdate.state == CharUpdate.State.Grounded && sprite[i].flags == 135 && c[n].charUpdate.hp < 0f && c[n].charAnim.CheckAnim(c[n].GetMeta().groundsmashsplode_anim) > -1)
					{
						flag6 = true;
						c[n].charAnim.SetAnim(c[n].GetMeta().groundsmashsplode_anim, c[n].charUpdate, overRide: true);
						c[n].charAnim.frame = 0.99f;
						c[n].charUpdate.traj.X = 0f;
						Game1.killManager.DoKill(n);
						spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 0.5f);
						c[n].charUpdate.state = CharUpdate.State.Grounded;
						c[n].charUpdate.traj = default;
					}
					if (!flag6)
					{
						c[n].charAnim.SetAnim("jfall", c[n].charUpdate);
						c[n].charUpdate.state = CharUpdate.State.Airborne;
						c[n].charUpdate.traj.Y = 1200f;
						c[n].charUpdate.traj.X /= 10f;
						c[n].charUpdate.airJuggleFrame = 0f;
					}
				}
				KickBurst(sprite[i], n);
				if (c[n].team == Character.Team.GoodGuys)
				{
					c[n].charUpdate.etherealFrame = 1f;
				}
				hVal = 20f;
				break;
			}
			Sound.PlaySnd(Sound.Category.FX, "slash" + Rand.GetRandomInt(1, 4));
			break;
		case 18:
			hVal = 0f;
			if (c[n].charUpdate.state == CharUpdate.State.Airborne && !giant)
			{
				c[n].charUpdate.airJuggleVec = sprite[i].loc + new Vector2(0f, 300f);
				c[n].charUpdate.airJuggleFrame = 0.1f;
				c[n].charAnim.SetAnim("jmid", c[n].charUpdate, overRide: true);
			}
			break;
		case 19:
		case 91:
			if (!giant)
			{
				c[n].charAnim.SetAnim("jfall", c[n].charUpdate);
				c[n].charUpdate.state = CharUpdate.State.Airborne;
				c[n].charUpdate.traj.Y = 1200f;
				c[n].charUpdate.traj.X /= 10f;
				c[n].charUpdate.airJuggleFrame = 0f;
			}
			hVal = 20f;
			spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]) * -1f, 1f);
			TrySlow(c, sprite[i].owner, n, 0.02f);
			c[n].charUpdate.block = CharUpdate.Block.NoBlock;
			c[sprite[i].owner].charUpdate.StainWeapon(sparks);
			Sound.PlaySnd(Sound.Category.FX, "slash" + Rand.GetRandomInt(1, 4));
			Sound.PlaySnd(Sound.Category.FX, "hit");
			c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
			if (c[sprite[i].owner].GetMeta().special != 4 && c[sprite[i].owner].GetMeta().special != 3 && c[sprite[i].owner].GetMeta().special != 5)
			{
				c[sprite[i].owner].charUpdate.StainChainsaw(sparks);
			}
			if (c[sprite[i].owner].GetMeta().special == 3)
			{
				_ = c[sprite[i].owner].charUpdate.cloudCharge;
			}
			if (pState == CharUpdate.State.Grounded && c[sprite[i].owner].charUpdate.state == CharUpdate.State.Grounded && sprite[i].flags == 91 && !nomnom && c[n].charAnim.CheckAnim("ssdrained") > -1 && c[n].charUpdate.hp <= c[n].charUpdate.mhp / 4f && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
			{
				KickBurst(sprite[i], n);
				c[n].charUpdate.state = pState;
				c[n].charAnim.SetAnim("ssdrained", c[n].charUpdate);
				c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
				c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
				c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
				c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
				c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
				c[sprite[i].owner].charUpdate.StainWeapon(sparks);
				c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
				Sound.PlaySnd(Sound.Category.FX, "hit");
				Sound.PlaySnd(Sound.Category.FX, "slash1");
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
			}
			break;
		case 20:
			hVal = 1f;
			if (!giant)
			{
				if (c[n].charUpdate.state == CharUpdate.State.Grounded)
				{
					if (c[n].charAnim.animName == charMeta.hitland_anim || c[n].charAnim.animName == "bounce" || c[n].charAnim.animName != "groundsawed")
					{
						c[n].charAnim.SetAnim("groundsawed", c[n].charUpdate, overRide: true);
					}
					else if (c[n].charAnim.animName == "groundsawed")
					{
						spriteMan.MakeHitSplash(c[n].charUpdate.loc, default, 0.3f);
						if (Rand.CointToss(0.3f))
						{
							c[n].charAnim.SetAnim("groundsawed", c[n].charUpdate, overRide: true);
						}
						KickBurst(sprite[i], n);
					}
					else
					{
						c[n].charAnim.SetAnim(charMeta.hit_anim, c[n].charUpdate, overRide: true);
					}
				}
				c[n].charUpdate.block = CharUpdate.Block.NoBlock;
				c[n].charUpdate.traj.X /= 5f;
			}
			c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
			c[sprite[i].owner].charUpdate.StainChainsaw(sparks);
			if (c[n].charUpdate.loc.X > c[sprite[i].owner].charUpdate.loc.X + 80f)
			{
				c[n].charUpdate.traj.X = -300f;
			}
			if (c[n].charUpdate.loc.X < c[sprite[i].owner].charUpdate.loc.X - 80f)
			{
				c[n].charUpdate.traj.X = 300f;
			}
			spriteMan.MakeSquirt(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), sparks, 1, n);
			if (sparks != 2)
			{
				switch (Rand.GetRandomInt(0, 3))
				{
				case 0:
					Sound.PlayChunk();
					break;
				case 1:
					Sound.PlaySplat();
					break;
				case 2:
					Sound.PlayCrunch();
					break;
				}
			}
			else
			{
				Sound.PlaySnd(Sound.Category.FX, "slash" + Rand.GetRandomInt(1, 4));
			}
			break;
		case 9:
		{
			if (!giant && c[n].charUpdate.state == CharUpdate.State.Grounded)
			{
				c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
			}
			c[n].charUpdate.traj.X /= 5f;
			if (c[n].charUpdate.loc.X > c[sprite[i].owner].charUpdate.loc.X + 60f)
			{
				c[n].charUpdate.traj.X = -300f;
			}
			if (c[n].charUpdate.loc.X < c[sprite[i].owner].charUpdate.loc.X - 60f)
			{
				c[n].charUpdate.traj.X = 300f;
			}
			c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
			c[sprite[i].owner].charUpdate.StainChainsaw(sparks);
			hVal = 1f;
			Vector2 loc = sprite[i].loc;
			Vector2 traj = spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]);
			if (sparks != 2)
			{
				if (Rand.CointToss(0.5f))
				{
					Vector2 vector = traj;
					if (vector.Y > 0f)
					{
						vector = -vector;
					}
					spriteMan.AddGib(loc, vector * Rand.GetRandomFloat(50f, 100f), 0, 0, 0, 0, 0, 1, null, null, 1f, Game1.gameMap.CurMap(), 4, 0, n, -1);
				}
				else if (Rand.CointToss(0.1f))
				{
					spriteMan.AddSprite(43, loc, Rand.GetRandomVec2(-40f, 40f, -40f, 40f), Rand.GetRandomFloat(1.2f, 1.5f), 0, 0);
				}
				else
				{
					spriteMan.MakeSquirt(loc, traj * Rand.GetRandomFloat(0f, 1f), sparks, 1, n);
				}
				KickBurst(sprite[i], n);
				switch (Rand.GetRandomInt(0, 3))
				{
				case 0:
					Sound.PlayChunk();
					break;
				case 1:
					Sound.PlaySplat();
					break;
				case 2:
					Sound.PlayCrunch();
					break;
				}
			}
			else
			{
				spriteMan.MakeSquirt(loc, traj * Rand.GetRandomFloat(0f, 1f), sparks, n);
				Sound.PlaySnd(Sound.Category.FX, "slash" + Rand.GetRandomInt(1, 4));
			}
			break;
		}
		case 7:
		case 41:
		case 127:
		case 134:
		{
			if (!giant)
			{
				if (c[n].charUpdate.state == CharUpdate.State.Grounded)
				{
					c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
				}
				else
				{
					c[n].charAnim.SetAnim("jmid", c[n].charUpdate, overRide: true);
					c[n].charUpdate.airJuggleVec = c[n].charUpdate.loc;
					c[n].charUpdate.airJuggleFrame = 0.25f;
				}
			}
			c[n].charUpdate.traj.X *= 3f;
			if (c[sprite[i].owner].charUpdate.airJuggleFrame > 0f)
			{
				c[sprite[i].owner].charUpdate.airJuggleFrame = 0f;
			}
			hVal = 1f;
			Vector2 loc2 = sprite[i].loc;
			Vector2 traj2 = spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]);
			if (sprite[i].flags != 41 && sprite[i].flags != 127 && sprite[i].flags != 134)
			{
				break;
			}
			spriteMan.MakeSquirt(loc2, traj2, sparks, n);
			c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
			c[sprite[i].owner].charUpdate.StainWeapon(sparks);
			if (sparks != 2)
			{
				switch (Rand.GetRandomInt(0, 3))
				{
				case 0:
					Sound.PlayChunk();
					break;
				case 1:
					Sound.PlaySplat();
					break;
				case 2:
					Sound.PlayCrunch();
					break;
				}
			}
			else
			{
				Sound.PlaySnd(Sound.Category.FX, "slash" + Rand.GetRandomInt(1, 4));
			}
			break;
		}
		case 21:
			if (!giant)
			{
				c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
				c[n].charUpdate.state = CharUpdate.State.Airborne;
				c[n].charUpdate.traj.Y = -700f;
				c[n].charUpdate.traj.X /= 10f;
			}
			hVal = 20f;
			TrySlow(c, sprite[i].owner, n, 0.02f);
			spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 1f);
			Sound.PlaySnd(Sound.Category.FX, "hit");
			if (sparks != 2)
			{
				Sound.PlaySnd(Sound.Category.FX, "crunch");
			}
			break;
		case 6:
		case 69:
		case 90:
		case 93:
			if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
			{
				Sound.PlaySnd(Sound.Category.FX, "cowbell");
			}
			if (!giant)
			{
				if (c[n].charAnim.CheckAnim("spinhit") > -1)
				{
					c[n].charAnim.SetAnim("spinhit", c[n].charUpdate);
				}
				else
				{
					c[n].charAnim.SetAnim("jmid", c[n].charUpdate);
				}
				c[n].charUpdate.state = CharUpdate.State.Airborne;
				c[n].charUpdate.traj.Y = -300f;
				c[n].charUpdate.traj.X *= 2f;
				c[n].charUpdate.airJuggleFrame = 0f;
				if (sprite[i].flags == 93)
				{
					c[n].charUpdate.traj.Y = -700f;
					c[n].charUpdate.traj.X /= 2f;
				}
				if (c[sprite[i].owner].charUpdate.airJuggleFrame > 0f)
				{
					c[sprite[i].owner].charUpdate.airJuggleVec.X += 80f * ((float)c[sprite[i].owner].charUpdate.face - 0.5f) * 2f;
				}
				ScrollManager.scroll.X += c[n].charUpdate.traj.X / 60f;
			}
			hVal = 20f;
			KickBurst(sprite[i], n);
			TrySlow(c, sprite[i].owner, n, 0.02f);
			spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 1f);
			Sound.PlaySnd(Sound.Category.FX, "hit");
			if (sparks != 2)
			{
				Sound.PlaySnd(Sound.Category.FX, "crunch");
			}
			QuakeManager.SetContrast(0.2f);
			if (sprite[i].flags == 6)
			{
				if (sprite[i].owner < 2 && (Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.GoatBead) || c[n].GetMeta().autoGroundSplode) && c[n].charUpdate.hp - hVal <= 0f && c[n].charAnim.CheckAnim("explode") > -1)
				{
					c[n].charAnim.SetAnim("explode", c[n].charUpdate);
					c[n].charUpdate.ethereal = true;
					c[n].charAnim.frame = 1.99f;
					c[n].charUpdate.traj.Y = -300f;
				}
			}
			else if (sprite[i].flags == 69)
			{
				Sound.PlaySnd(Sound.Category.FX, "junk");
				spriteMan.MakeSplatter(sprite[i].loc, sprite[i].rotation, 5, charMeta.GetSpark(), n);
				c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
				c[sprite[i].owner].charUpdate.StainWeapon(sparks);
				if (c[n].charUpdate.hp < c[n].charUpdate.mhp / 4f && !nomnom && c[n].charAnim.CheckAnim("explode") > -1)
				{
					c[n].charAnim.SetAnim("explode", c[n].charUpdate);
					c[n].charUpdate.ethereal = true;
					c[n].charAnim.frame = 1.99f;
					c[n].charUpdate.traj.Y = -300f;
				}
			}
			else
			{
				if (sprite[i].flags != 90 && sprite[i].flags != 93)
				{
					break;
				}
				c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
				Sound.PlaySnd(Sound.Category.FX, "slash1");
				spriteMan.MakeSplatter(sprite[i].loc, sprite[i].rotation, 4, charMeta.GetSpark(), n);
				if (sparks != 2)
				{
					spriteMan.AddGib(sprite[i].loc + new Vector2(0f, 30f), sprite[i].traj * Rand.GetRandomFloat(-900f, -300f), 0, 0, 0, 0, 0, c[n].cDef, null, null, 0.35f, Game1.gameMap.CurMap(), 4, 0, n, -1);
				}
				KickBurst(sprite[i], n);
				if (pState == CharUpdate.State.Grounded && c[sprite[i].owner].charUpdate.state == CharUpdate.State.Grounded)
				{
					if (sprite[i].flags == 90 && !nomnom && c[n].charAnim.CheckAnim("skilled") > -1 && c[n].charUpdate.hp <= c[n].charUpdate.mhp / 4f && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
					{
						c[n].charUpdate.state = pState;
						c[n].charAnim.SetAnim("skilled", c[n].charUpdate);
						c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
						c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
						c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
						c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
						c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
						c[sprite[i].owner].charUpdate.StainWeapon(sparks);
						c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
						Sound.PlaySnd(Sound.Category.FX, "hit");
						Sound.PlaySnd(Sound.Category.FX, "slash1");
						ScrollManager.zoom += 0.1f;
						QuakeManager.SetQuake(0.2f);
						QuakeManager.SetBright(0.2f);
					}
					if (sprite[i].flags == 93 && !nomnom && c[n].charAnim.CheckAnim("sdrained") > -1 && c[n].charUpdate.hp <= c[n].charUpdate.mhp / 4f && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
					{
						c[n].charUpdate.state = pState;
						c[n].charAnim.SetAnim("sdrained", c[n].charUpdate);
						c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
						c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
						c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
						c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
						c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
						c[sprite[i].owner].charUpdate.StainWeapon(sparks);
						c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
						Sound.PlaySnd(Sound.Category.FX, "hit");
						Sound.PlaySnd(Sound.Category.FX, "slash1");
						ScrollManager.zoom += 0.1f;
						QuakeManager.SetQuake(0.2f);
						QuakeManager.SetBright(0.2f);
					}
				}
			}
			break;
		case 118:
			if (!c[n].GetMeta().isBoss)
			{
				c[n].charUpdate.drippy = 10f;
			}
			hVal = 0f;
			if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.AchievablesBead))
			{
				GetAllAchievables getAllAchievables = (GetAllAchievables)Game1.achievementMgr.playerAchievements[sprite[i].owner].achievementList[5];
				if (!getAllAchievables.squirtgunFight)
				{
					getAllAchievables.squirtgunFight = true;
					getAllAchievables.Unlock(overRide: false);
				}
			}
			break;
		case 86:
			if (!giant)
			{
				if (c[n].charAnim.CheckAnim("spinhit") > -1)
				{
					c[n].charAnim.SetAnim("spinhit", c[n].charUpdate);
				}
				else
				{
					c[n].charAnim.SetAnim("jmid", c[n].charUpdate);
				}
				c[n].charUpdate.state = CharUpdate.State.Airborne;
				c[n].charUpdate.traj.Y = -400f;
				c[n].charUpdate.traj.X *= 1.2f;
				c[n].charUpdate.airJuggleFrame = 0f;
				if (c[sprite[i].owner].charUpdate.airJuggleFrame > 0f)
				{
					c[sprite[i].owner].charUpdate.airJuggleVec.X += 80f * ((float)c[sprite[i].owner].charUpdate.face - 0.5f) * 2f;
				}
				ScrollManager.scroll.X += c[n].charUpdate.traj.X / 60f;
			}
			hVal = 10f;
			spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 1f);
			QuakeManager.SetContrast(0.2f);
			c[n].charUpdate.fire = 1.5f;
			break;
		case 5:
		case 8:
		case 79:
		case 119:
		case 120:
		case 121:
		{
			if (sprite[i].flags == 8 && c[n].GetMeta().isMagicSponge)
			{
				hVal = 1f;
			}
			if (!giant)
			{
				if (c[n].charUpdate.state == CharUpdate.State.Grounded)
				{
					c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
				}
				else
				{
					c[n].charAnim.SetAnim("jmid", c[n].charUpdate, overRide: true);
					c[n].charUpdate.traj.Y = -150f;
					c[n].charUpdate.traj.X /= 10f;
					Vector2 airJuggleVec2 = (c[sprite[i].owner].charUpdate.loc + c[n].charUpdate.loc) / 2f;
					if (sprite[i].flags != 79)
					{
						airJuggleVec2.X += ((c[sprite[i].owner].charUpdate.face == 1) ? 60f : (-60f));
					}
					c[n].charUpdate.airJuggleVec = airJuggleVec2;
					c[sprite[i].owner].charUpdate.airJuggleVec = airJuggleVec2;
					if (sprite[i].flags == 79)
					{
						c[n].charUpdate.airJuggleVec.Y -= 50f;
					}
					if (c[sprite[i].owner].charUpdate.face == 1)
					{
						c[sprite[i].owner].charUpdate.airJuggleVec.X -= 50f;
						c[n].charUpdate.airJuggleVec.X += 40f;
					}
					else
					{
						c[sprite[i].owner].charUpdate.airJuggleVec.X += 50f;
						c[n].charUpdate.airJuggleVec.X -= 40f;
					}
					c[n].charUpdate.airJuggleFrame = 0.25f;
					c[sprite[i].owner].charUpdate.airJuggleFrame = 0.25f;
				}
			}
			if (sprite[i].flags != 79)
			{
				TrySlow(c, sprite[i].owner, n, 0.008f);
			}
			spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 0.5f);
			Sound.PlaySnd(Sound.Category.FX, "hit");
			if (sprite[i].flags != 119 && sprite[i].flags != 120 && sprite[i].flags != 121)
			{
				break;
			}
			if (sprite[i].flags == 120)
			{
				hVal = 10f;
				if (!giant)
				{
					if (c[n].charAnim.CheckAnim("spinhit") > -1)
					{
						c[n].charAnim.SetAnim("spinhit", c[n].charUpdate);
					}
					else
					{
						c[n].charAnim.SetAnim("jmid", c[n].charUpdate);
					}
					c[n].charUpdate.state = CharUpdate.State.Airborne;
					c[n].charUpdate.traj.Y = -300f;
					if (c[n].charUpdate.traj.X < 0f)
					{
						c[n].charUpdate.traj.X = -800f;
					}
					else
					{
						c[n].charUpdate.traj.X = 800f;
					}
					c[n].charUpdate.airJuggleFrame = 0f;
				}
				QuakeManager.SetQuake(0.2f);
				TrySlow(c, sprite[i].owner, n, 0.01f);
			}
			else if (sprite[i].flags == 121)
			{
				hVal = 10f;
				if (!giant)
				{
					c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
					c[n].charUpdate.state = CharUpdate.State.Airborne;
					c[n].charUpdate.traj.Y = -700f;
					if (c[n].charUpdate.traj.X < 0f)
					{
						c[n].charUpdate.traj.X = -5f;
					}
					else
					{
						c[n].charUpdate.traj.X = 5f;
					}
					c[n].charUpdate.airJuggleFrame = 0f;
				}
				QuakeManager.SetQuake(0.2f);
				TrySlow(c, sprite[i].owner, n, 0.01f);
			}
			if (!(c[n].charUpdate.drippy > 0f))
			{
				break;
			}
			KickBurst(sprite[i], n);
			hVal = ((!c[n].GetMeta().isGiant) ? (hVal * 6f) : (hVal * 2f));
			QuakeManager.SetBright(0.4f);
			Sound.PlaySnd(Sound.Category.FX, "zbomb");
			TrySlow(c, sprite[i].owner, n, 0.015f);
			for (int j = 0; j < 4; j++)
			{
				spriteMan.AddSprite(79, sprite[i].loc, Rand.GetRandomVec2(-110f, 110f, -110f, 110f), Rand.GetRandomFloat(0.15f, 0.5f), 0, 0);
			}
			for (int k = 0; k < 12; k++)
			{
				spriteMan.AddSprite(0, sprite[i].loc, Rand.GetRandomVec2(-1500f, 1500f, -1500f, 1500f), Rand.GetRandomFloat(0.5f, 1f), 0, 0);
			}
			PostGlowMgr.AddGlow(sprite[i].loc, 0.5f, 0.6f, 1f, 1f, 1f, 1f);
			if (!(c[n].charUpdate.hp < 0f) || nomnom)
			{
				break;
			}
			if (c[n].charAnim.CheckAnim("explode") > -1)
			{
				TrySlow(c, sprite[i].owner, n, 0.05f);
				c[n].charAnim.SetAnim("explode", c[n].charUpdate);
				c[n].charUpdate.ethereal = true;
				c[n].charAnim.frame = 1.99f;
				c[n].charUpdate.traj.Y = -500f;
				if (c[sprite[i].owner].charUpdate.face == 0)
				{
					c[n].charUpdate.traj.X = -500f;
				}
				else
				{
					c[n].charUpdate.traj.X = 500f;
				}
				if (c[sprite[i].owner].charUpdate.etherealFrame < 0.5f)
				{
					c[sprite[i].owner].charUpdate.etherealFrame = 0.5f;
				}
				Game1.killManager.DoKill(n);
				Game1.killManager.bits = 0f;
			}
			else if (c[n].charUpdate.state == CharUpdate.State.Grounded && !nomnom && c[n].charAnim.CheckAnim(c[n].GetMeta().exe_anim) > -1)
			{
				c[n].charAnim.SetAnim(c[n].GetMeta().exe_anim, c[n].charUpdate);
			}
			break;
		}
		case 89:
			if (!giant)
			{
				if (c[n].charUpdate.state == CharUpdate.State.Grounded)
				{
					c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
				}
				else
				{
					c[n].charAnim.SetAnim("jmid", c[n].charUpdate, overRide: true);
					c[n].charUpdate.traj.Y = -150f;
					c[n].charUpdate.traj.X /= 10f;
					Vector2 airJuggleVec = (c[sprite[i].owner].charUpdate.loc + c[n].charUpdate.loc) / 2f;
					airJuggleVec.X += ((c[sprite[i].owner].charUpdate.face == 1) ? 60f : (-60f));
					c[n].charUpdate.airJuggleVec = airJuggleVec;
					c[sprite[i].owner].charUpdate.airJuggleVec = airJuggleVec;
					if (c[sprite[i].owner].charUpdate.face == 1)
					{
						c[sprite[i].owner].charUpdate.airJuggleVec.X -= 50f;
						c[n].charUpdate.airJuggleVec.X += 40f;
					}
					else
					{
						c[sprite[i].owner].charUpdate.airJuggleVec.X += 50f;
						c[n].charUpdate.airJuggleVec.X -= 40f;
					}
					c[n].charUpdate.airJuggleFrame = 0.25f;
					c[sprite[i].owner].charUpdate.airJuggleFrame = 0.25f;
				}
			}
			c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
			Sound.PlaySnd(Sound.Category.FX, "slash1");
			spriteMan.MakeSquirt(sprite[i].loc, sprite[i].traj * -5f, sparks, 4, n);
			if (sparks != 2 && Rand.CointToss(0.5f))
			{
				spriteMan.AddGib(sprite[i].loc + new Vector2(0f, 30f), sprite[i].traj * Rand.GetRandomFloat(-900f, -300f), 0, 0, 0, 0, 0, c[n].cDef, null, null, 0.35f, Game1.gameMap.CurMap(), 4, sparks, n, -1);
			}
			break;
		case 52:
			if (!giant)
			{
				if (c[n].charUpdate.state == CharUpdate.State.Grounded)
				{
					c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
				}
				else
				{
					c[n].charAnim.SetAnim("jmid", c[n].charUpdate, overRide: true);
					c[n].charAnim.SetAnim("spinhit", c[n].charUpdate, overRide: true);
					c[n].charUpdate.traj.Y = -150f;
					c[n].charUpdate.traj.X *= 0.9f;
					if (c[sprite[i].owner].charUpdate.state == CharUpdate.State.Airborne)
					{
						c[n].charUpdate.traj.X = 0f;
					}
				}
			}
			TrySlow(c, sprite[i].owner, n, 0.01f);
			spriteMan.MakeSplatter(sprite[i].loc, sprite[i].rotation, 5, charMeta.GetSpark(), hammerStuff: true, n);
			c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
			c[sprite[i].owner].charUpdate.StainWeapon(sparks);
			Sound.PlaySnd(Sound.Category.FX, "junk");
			Sound.PlaySnd(Sound.Category.FX, "hit");
			Sound.PlayCrush();
			Sound.PlayCrunch();
			break;
		case 53:
		case 78:
		case 94:
			if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
			{
				Sound.PlaySnd(Sound.Category.FX, "cowbell");
			}
			if (!giant)
			{
				c[n].charAnim.SetAnim("jfall", c[n].charUpdate);
				c[n].charUpdate.state = CharUpdate.State.Airborne;
				c[n].charUpdate.traj.Y = 1200f;
				c[n].charUpdate.traj.X /= 10f;
				c[n].charUpdate.airJuggleFrame = 0f;
			}
			if (sprite[i].flags == 78)
			{
				hVal = 10f;
				TrySlow(c, sprite[i].owner, n, 0.01f);
			}
			else if (sprite[i].flags == 94)
			{
				hVal = 10f;
				c[n].charUpdate.traj.X *= 10f;
				TrySlow(c, sprite[i].owner, n, 0.01f);
			}
			else
			{
				hVal = 20f;
				TrySlow(c, sprite[i].owner, n, 0.02f);
				c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
				c[sprite[i].owner].charUpdate.StainWeapon(sparks);
				Sound.PlaySnd(Sound.Category.FX, "junk");
				c[sprite[i].owner].charUpdate.hammerSmashFrame = 0.2f;
			}
			spriteMan.MakeSplatter(sprite[i].loc, sprite[i].rotation, 15, charMeta.GetSpark(), sprite[i].flags == 53, n);
			KickBurst(sprite[i], n);
			if (sprite[i].owner < 2 && (Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.GoatBead) || c[n].GetMeta().autoGroundSplode) && c[n].charUpdate.hp - hVal <= 0f && c[n].charAnim.CheckAnim("explode") > -1)
			{
				c[n].charAnim.SetAnim("explode", c[n].charUpdate);
				c[n].charUpdate.ethereal = true;
				c[n].charAnim.frame = 1.99f;
				c[n].charUpdate.traj.Y = 1200f;
			}
			Sound.PlaySnd(Sound.Category.FX, "hit");
			Sound.PlayChunk();
			Sound.PlayCrush();
			Sound.PlayCrunch();
			break;
		case 54:
			if (sprite[i].owner < 2 && Game1.beadMgr.beads[sprite[i].owner].HasBead(InvCatalog.InvItemName.BellBead))
			{
				Sound.PlaySnd(Sound.Category.FX, "cowbell");
			}
			if (!giant)
			{
				c[n].charAnim.SetAnim("jhit", c[n].charUpdate);
				c[n].charUpdate.state = CharUpdate.State.Airborne;
				c[n].charUpdate.traj.Y = -1300f;
				c[n].charUpdate.traj.X /= 10f;
				c[n].charUpdate.airJuggleFrame = 0f;
				if (!nomnom && c[n].charUpdate.hp < c[n].charUpdate.mhp / 4f && c[n].charAnim.CheckAnim("explode") > -1)
				{
					c[n].charAnim.SetAnim("explode", c[n].charUpdate);
					c[n].charUpdate.ethereal = true;
					c[n].charAnim.frame = 1.99f;
					c[n].charUpdate.traj.Y = -1300f;
				}
			}
			hVal = 20f;
			TrySlow(c, sprite[i].owner, n, 0.02f);
			KickBurst(sprite[i], n);
			spriteMan.MakeSplatter(sprite[i].loc, sprite[i].rotation, 15, charMeta.GetSpark(), hammerStuff: true, n);
			c[sprite[i].owner].charUpdate.FreshenWeapBlood(sparks);
			c[sprite[i].owner].charUpdate.StainWeapon(sparks);
			Sound.PlaySnd(Sound.Category.FX, "junk");
			Sound.PlaySnd(Sound.Category.FX, "hit");
			Sound.PlayChunk();
			Sound.PlayCrush();
			Sound.PlayCrunch();
			QuakeManager.SetContrast(0.2f);
			QuakeManager.SetQuake(0.6f);
			ScrollManager.scroll.Y += 10f;
			break;
		}
		if (!nomnom)
		{
			switch (sprite[i].flags)
			{
			case 7:
			case 41:
			case 42:
			case 53:
			case 93:
			case 127:
			case 134:
				if (!Game1.character[sprite[i].owner].charUpdate.charGrab.grabbing)
				{
					if (c[n].GetMeta().turnexetograb && c[n].charUpdate.hp < 0f)
					{
						if (c[n].charUpdate.state == CharUpdate.State.Grounded && !c[sprite[i].owner].charUpdate.charGrab.grabbing && c[sprite[i].owner].charMeta != 91 && c[sprite[i].owner].ID < 2)
						{
							c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
							c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
							c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
							c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
							c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
							c[sprite[i].owner].charUpdate.StainWeapon(sparks);
							c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
							if (c[sprite[i].owner].GetMeta().isYuki)
							{
								c[n].charAnim.SetAnim(c[n].GetMeta().katgrabbed_anim, c[n].charUpdate, overRide: true);
							}
							else
							{
								c[n].charAnim.SetAnim(c[n].GetMeta().dishgrabbed_anim, c[n].charUpdate, overRide: true);
							}
							Sound.PlaySnd(Sound.Category.FX, "hit");
							Sound.PlaySnd(Sound.Category.FX, "slash1");
							ScrollManager.zoom += 0.1f;
							QuakeManager.SetQuake(0.2f);
							QuakeManager.SetBright(0.2f);
							if (sprite[i].traj.X > 0f)
							{
								c[n].charUpdate.face = 0;
							}
							else
							{
								c[n].charUpdate.face = 1;
							}
						}
					}
					else if ((c[n].GetMeta().isJuggernaut && c[n].charUpdate.hp < 0f) || (c[n].charUpdate.hp < c[n].charUpdate.mhp / 4f && !c[n].GetMeta().isJuggernaut))
					{
						if (pState == CharUpdate.State.Grounded)
						{
							QuakeManager.SetBright(0.2f);
							QuakeManager.SetContrast(0.6f);
							switch (sprite[i].flags)
							{
							case 53:
								if (c[n].charAnim.CheckAnim(c[n].GetMeta().groundsmashsplode_anim) > -1)
								{
									c[n].charAnim.SetAnim(c[n].GetMeta().groundsmashsplode_anim, c[n].charUpdate);
									c[n].charAnim.frame = 0.99f;
									c[n].charUpdate.traj.X = 0f;
									Game1.killManager.DoKill(n);
									spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 0.5f);
									c[n].charUpdate.state = CharUpdate.State.Grounded;
									c[n].charUpdate.traj = default;
								}
								else if (c[n].charAnim.CheckAnim(c[n].GetMeta().exe_anim) > -1)
								{
									c[n].charAnim.SetAnim(c[n].GetMeta().exe_anim, c[n].charUpdate);
									Game1.killManager.DoKill(n);
								}
								break;
							case 134:
								if (c[n].charAnim.CheckAnim("sexkilled") > -1 && !c[sprite[i].owner].charUpdate.charGrab.grabbing)
								{
									c[n].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
									c[n].charUpdate.charGrab.grabbedByChar = c[sprite[i].owner].ID;
									c[n].charUpdate.lastSpecial = c[sprite[i].owner].charRender.machine;
									c[n].charAnim.smokeMachineLife = c[sprite[i].owner].charAnim.smokeMachineLife;
									c[sprite[i].owner].charUpdate.charGrab.grabbing = true;
									c[sprite[i].owner].charUpdate.StainWeapon(sparks);
									c[n].charAnim.charTrigs.grabberLoc = c[n].charUpdate.loc;
									c[n].charAnim.SetAnim("sexkilled", c[n].charUpdate, overRide: true);
									Sound.PlaySnd(Sound.Category.FX, "hit");
									Sound.PlaySnd(Sound.Category.FX, "slash1");
									ScrollManager.zoom += 0.1f;
									QuakeManager.SetQuake(0.2f);
									QuakeManager.SetBright(0.2f);
									KickBurst(sprite[i], n);
									if (sprite[i].traj.X > 0f)
									{
										c[n].charUpdate.face = 0;
									}
									else
									{
										c[n].charUpdate.face = 1;
									}
								}
								else if (c[n].charAnim.CheckAnim(c[n].GetMeta().exe_anim) > -1)
								{
									c[n].charAnim.SetAnim(c[n].GetMeta().exe_anim, c[n].charUpdate);
									if (Rand.CointToss(0.5f) && c[n].charAnim.CheckAnim("exe2") > -1)
									{
										c[n].charAnim.SetAnim("exe2", c[n].charUpdate);
									}
									if (Rand.CointToss(0.3f) && c[n].charAnim.CheckAnim("exe3") > -1)
									{
										c[n].charAnim.SetAnim("exe3", c[n].charUpdate);
									}
									Game1.killManager.DoKill(n);
									KickBurst(sprite[i], n);
									spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 0.5f);
									c[n].charUpdate.state = CharUpdate.State.Grounded;
									c[n].charUpdate.traj = default;
								}
								break;
							default:
								if (c[n].charAnim.CheckAnim(c[n].GetMeta().exe_anim) > -1)
								{
									c[n].charAnim.SetAnim(c[n].GetMeta().exe_anim, c[n].charUpdate);
									if (Rand.CointToss(0.5f) && c[n].charAnim.CheckAnim("exe2") > -1)
									{
										c[n].charAnim.SetAnim("exe2", c[n].charUpdate);
									}
									if (Rand.CointToss(0.3f) && c[n].charAnim.CheckAnim("exe3") > -1)
									{
										c[n].charAnim.SetAnim("exe3", c[n].charUpdate);
									}
									Game1.killManager.DoKill(n);
									KickBurst(sprite[i], n);
									spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 0.5f);
									c[n].charUpdate.state = CharUpdate.State.Grounded;
									c[n].charUpdate.traj = default;
								}
								break;
							}
						}
						else
						{
							switch (sprite[i].flags)
							{
							case 7:
							case 41:
							case 42:
							case 127:
							case 134:
								if (c[n].charAnim.CheckAnim("airsplit") > -1)
								{
									if (c[n].charUpdate.traj.X > 100f)
									{
										c[n].charUpdate.traj.X = 100f;
									}
									if (c[n].charUpdate.traj.X < -100f)
									{
										c[n].charUpdate.traj.X = -100f;
									}
									c[n].charAnim.SetAnim("airsplit", c[n].charUpdate);
									KickBurst(sprite[i], n);
									Game1.killManager.DoKill(n);
									spriteMan.MakeHitSplash(sprite[i].loc, spriteMan.catalog.spriteDef[sprite[i].type].GetTraj(sprite[i]), 0.5f);
								}
								break;
							}
						}
					}
				}
				if (sprite[i].flags == 42 && c[sprite[i].owner].GetMeta().special == 3 && c[sprite[i].owner].charUpdate.cloudCharge > 3f && (c[n].charUpdate.hp < c[n].charUpdate.mhp / 4f || hVal > c[n].charUpdate.hp) && !nomnom && c[n].charAnim.CheckAnim("explode") > -1)
				{
					KickBurst(sprite[i], n);
					c[n].charAnim.SetAnim("explode", c[n].charUpdate);
					c[n].charUpdate.ethereal = true;
					c[n].charAnim.frame = 1.99f;
					c[n].charUpdate.traj.Y = -500f;
					if (c[sprite[i].owner].charUpdate.face == 0)
					{
						c[n].charUpdate.traj.X = -1100f;
					}
					else
					{
						c[n].charUpdate.traj.X = 1100f;
					}
					if (c[sprite[i].owner].charUpdate.etherealFrame < 0.5f)
					{
						c[sprite[i].owner].charUpdate.etherealFrame = 0.5f;
					}
					Game1.killManager.DoKill(n);
					Game1.killManager.bits = 0f;
				}
				break;
			}
		}
		if (charMeta.isBox)
		{
			c[n].charUpdate.state = pState;
			c[n].charUpdate.traj.X = 0f;
		}
		return hVal;
	}

	private bool GetBiggie(Sprite[] sprite, int i)
	{
		bool result = false;
		switch (sprite[i].type)
		{
		case 12:
			switch (sprite[i].flags)
			{
			case 2:
			case 3:
			case 4:
			case 6:
			case 21:
			case 23:
			case 42:
			case 53:
			case 54:
			case 67:
			case 68:
			case 69:
			case 84:
			case 90:
			case 91:
			case 92:
			case 94:
			case 120:
			case 121:
			case 135:
				result = true;
				break;
			}
			break;
		case 20:
			result = true;
			break;
		}
		return result;
	}

	private void HitPuppet(CharUpdate.State pState, Vector2 pCharTraj, Character[] c, float hVal, int n, Sprite[] sprite, int i, SpriteManager spriteMan)
	{
		if (!(c[n].charUpdate.hp < c[n].charUpdate.hp / 2f))
		{
			return;
		}
		int type = sprite[i].type;
		if (type == 12)
		{
			switch (sprite[i].flags)
			{
			case 11:
			case 22:
			case 47:
			case 48:
			case 49:
			case 50:
			case 51:
			case 74:
			case 117:
			case 123:
				return;
			}
		}
		if (GetBiggie(sprite, i))
		{
			c[n].charUpdate.face = 1 - c[sprite[i].owner].charUpdate.face;
			c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
			if (c[n].charUpdate.hp <= 0f)
			{
				c[n].charAnim.SetAnim("die", c[n].charUpdate, overRide: true);
				c[n].charAnim.frame = 0.99f;
			}
		}
	}

	private void HitJuggernaut(CharUpdate.State pState, Vector2 pCharTraj, Character[] c, float hVal, int n, Sprite[] sprite, int i, SpriteManager spriteMan)
	{
		c[n].charUpdate.state = pState;
		c[n].charUpdate.traj = pCharTraj;
		c[n].charUpdate.airJuggleFrame = -1f;
		if (c[sprite[i].owner].team == c[n].team || c[n].charAnim.animName == c[n].GetMeta().exe_anim || (sprite[i].type == 12 && sprite[i].flags == 118) || c[n].charUpdate.state != CharUpdate.State.Grounded || c[n].charUpdate.charGrab.grabbedByChar >= 0)
		{
			return;
		}
		if (c[n].charUpdate.giantVulnTimer <= 0f)
		{
			c[n].charUpdate.giantShrugDamage += hVal;
			if (c[n].GetMeta().ishypno)
			{
				c[n].charUpdate.giantShrugDamage += hVal * 2f;
			}
			if (c[n].charUpdate.giantShrugDamage > c[n].GetMeta().mHP / 5f)
			{
				c[n].charUpdate.face = 1 - c[sprite[i].owner].charUpdate.face;
				if (c[n].GetMeta().isPuppet)
				{
					c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
				}
				else
				{
					c[n].charAnim.SetAnim("bighit", c[n].charUpdate, overRide: true);
				}
				c[n].charUpdate.giantVulnTimer = 5f;
				QuakeManager.SetBright(0.2f);
				QuakeManager.SetQuake(0.2f);
				return;
			}
			int type = sprite[i].type;
			if (type == 12)
			{
				switch (sprite[i].flags)
				{
				case 11:
				case 22:
				case 47:
				case 48:
				case 49:
				case 50:
				case 51:
				case 74:
				case 117:
				case 123:
					return;
				}
			}
			if (c[n].GetMeta().isBlocker)
			{
				switch (sprite[i].type)
				{
				case 11:
				case 21:
				case 37:
				case 101:
					return;
				}
				c[n].charUpdate.face = 1 - c[sprite[i].owner].charUpdate.face;
				c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
			}
		}
		else if (GetBiggie(sprite, i))
		{
			if (c[n].charUpdate.giantVulnTimer < 4f)
			{
				c[n].charUpdate.face = 1 - c[sprite[i].owner].charUpdate.face;
				if (c[n].GetMeta().isPuppet)
				{
					c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
				}
				else
				{
					c[n].charAnim.SetAnim("bighit", c[n].charUpdate, overRide: true);
				}
				c[n].charUpdate.giantVulnTimer = 0f;
				c[n].charUpdate.giantShrugDamage = 0f;
				TrySlow(c, sprite[i].owner, n, 0.02f);
				QuakeManager.SetBright(0.2f);
				QuakeManager.SetQuake(0.2f);
				spriteMan.MakeHitSplash(sprite[i].loc, default, 1f);
			}
			else
			{
				c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
				c[n].charUpdate.face = 1 - c[sprite[i].owner].charUpdate.face;
			}
		}
		else
		{
			c[n].charAnim.SetAnim("hit", c[n].charUpdate, overRide: true);
			c[n].charUpdate.face = 1 - c[sprite[i].owner].charUpdate.face;
		}
	}

	private static int pvpLogCount = 0;

	// Diagnostico do PvP: grava em pvp_log.txt por que um golpe de jogador nao acerta outro jogador
	private void PvpLog(Sprite[] sprite, int i, Character[] c, int k, Vector2 loc)
	{
		if (pvpLogCount >= 400)
		{
			return;
		}
		pvpLogCount++;
		try
		{
			int o = sprite[i].owner;
			string line = "#" + pvpLogCount + " spriteType=" + sprite[i].type + " flags=" + sprite[i].flags + " frame=" + sprite[i].frame + " owner=" + o + " victim=" + k
				+ " | pvpMode=" + Game1.pvpMode + " pvpMatch=" + Game1.pvpMatch + " players=" + Game1.GetPlayers()
				+ " | teamOwner=" + c[o].team + " teamVictim=" + c[k].team
				+ " | exists=" + c[k].exists + " inactive=" + c[k].charUpdate.inactive + " ethereal=" + c[k].charUpdate.ethereal + " etherealFrame=" + c[k].charUpdate.etherealFrame
				+ " warpFrame=" + c[k].charUpdate.warpFrame + " grabbedBy=" + c[k].charUpdate.charGrab.grabbedByChar + " dehealthified=" + c[k].charUpdate.dehealthified
				+ " dyingFrame=" + c[k].charUpdate.dyingFrame + " hp=" + c[k].charUpdate.hp + " charMeta=" + c[k].charMeta
				+ " | rectHit=" + c[k].CheckHit(loc, wide: true) + " dist=" + (c[k].charUpdate.loc - c[o].charUpdate.loc).Length();
			System.IO.File.AppendAllText(System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "pvp_log.txt"), line + "\r\n");
		}
		catch (System.Exception)
		{
		}
	}

	private bool IsParrying(Character[] c, int owner, int k, int face)
	{
		if (!Game1.parryEnabled || owner < 0 || owner == k || !Game1.IsPlayerChar(k))
		{
			return false;
		}
		CharUpdate u = c[k].charUpdate;
		if (u.parryFrame <= 0f || u.state != CharUpdate.State.Grounded || u.hp < 0f)
		{
			return false;
		}
		bool attackerRight = c[owner].charUpdate.loc.X >= u.loc.X;
		return attackerRight == (face == 1);
	}

	private void ParryReflect(Character[] c, Sprite[] sprite, int i, int k, float damage, SpriteManager spriteMan, Vector2 hitLoc)
	{
		int a = sprite[i].owner;
		float reflected = damage * Game1.parryMultiplier;
		if (reflected < 15f)
		{
			reflected = 15f;
		}
		CharMeta attackerMeta = Game1.charMeta[c[a].charMeta];
		c[a].charUpdate.hp -= reflected;
		c[a].charUpdate.lastHitBy = k;
		if (!attackerMeta.isJuggernaut && !attackerMeta.isGiant && !attackerMeta.isBoss && c[a].charUpdate.charGrab.grabbedByChar < 0 && c[a].charUpdate.hp >= 0f)
		{
			c[a].charUpdate.state = CharUpdate.State.Airborne;
			c[a].charUpdate.traj = new Vector2((c[a].charUpdate.loc.X >= c[k].charUpdate.loc.X) ? 450f : (-450f), -400f);
			c[a].charAnim.SetAnim("jhit", c[a].charUpdate);
		}
		if (c[a].team == Character.Team.GoodGuys)
		{
			DeathCheck(c, a);
		}
		if (k < Game1.gamePlayerMgr.gamePlayer.Length && Game1.gamePlayerMgr.gamePlayer[k].active)
		{
			Game1.gamePlayerMgr.gamePlayer[k].DoHit(reflected);
		}
		c[k].charUpdate.parryFlash = 0.35f;
		Sound.PlaySnd(Sound.Category.FX, "block");
		for (int n = 0; n < 12; n++)
		{
			spriteMan.AddSprite(0, hitLoc, Rand.GetRandomVec2(-300f, 300f, -300f, 300f), 1f, 0, 0);
			spriteMan.AddSprite(0, hitLoc, Rand.GetRandomVec2(-1400f, 1400f, -1400f, 1400f), 1f, 0, 0);
		}
		QuakeManager.SetQuake(0.4f);
		QuakeManager.SetBright(0.3f);
		TrySlow(c, a, k, 0.06f);
	}

	private void DeathCheck(Character[] c, int i)
	{
		bool flag = false;
		if (c[i].team == Character.Team.GoodGuys && c[i].charUpdate.hp < 0f)
		{
			flag = true;
			if (c[i].charUpdate.charGrab.grabbedByChar < 0 && c[i].charUpdate.state == CharUpdate.State.Grounded)
			{
				c[i].charUpdate.state = CharUpdate.State.Airborne;
				c[i].charAnim.SetAnim("jhit", c[i].charUpdate);
				c[i].charUpdate.traj.Y = -700f;
			}
		}
		if (flag && Game1.GetPlayers() >= 2)
		{
			int alive = 0;
			for (int j = 0; j < Game1.GetPlayers() && j < 4; j++)
			{
				if (Game1.character[j].team == Character.Team.GoodGuys && Game1.character[j].exists && Game1.character[j].charUpdate.hp >= 0f)
				{
					alive++;
				}
			}
			if (Game1.pvpMode)
			{
				flag = alive <= 1;
			}
			else if (alive > 0)
			{
				flag = false;
			}
		}
		if (c[i].charMeta == 83)
		{
			flag = false;
		}
		if (flag)
		{
			Game1.killManager.DoUberDeath();
		}
	}

	private void TrySlow(Character[] c, int i, int n, float val)
	{
		if (i >= -1 && n >= -1 && c[i] != null && c[n] != null && (i < 4 || n < 4))
		{
			if (Game1.camMgr.CanSlowAll())
			{
				FMan.Slow(val);
				return;
			}
			c[i].charUpdate.Slow(val);
			c[n].charUpdate.Slow(val);
		}
	}
}
