using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;

namespace Yuki_Win.netplay;

public static class NetPacker
{
	public static void WriteVec2(PacketWriter writer, Vector2 v)
	{
		writer.Write(FloatToInt16(v.X));
		writer.Write(FloatToInt16(v.Y));
	}

	public static Vector2 ReadVec2(PacketReader reader)
	{
		return new Vector2(reader.ReadInt16(), reader.ReadInt16());
	}

	public static void WriteTinyVec2(PacketWriter writer, Vector2 v)
	{
		float num = v.X * 125f;
		if (num > 125f)
		{
			num = 125f;
		}
		if (num < -125f)
		{
			num = -125f;
		}
		float num2 = v.Y * 125f;
		if (num2 > 125f)
		{
			num2 = 125f;
		}
		if (num2 < -125f)
		{
			num2 = -125f;
		}
		sbyte value = (sbyte)num;
		sbyte value2 = (sbyte)num2;
		writer.Write(value);
		writer.Write(value2);
	}

	public static Vector2 ReadTinyVec2(PacketReader reader)
	{
		Vector2 result = default;
		sbyte b = reader.ReadSByte();
		sbyte b2 = reader.ReadSByte();
		result.X = (float)b / 125f;
		result.Y = (float)b2 / 125f;
		return result;
	}

	public static void WriteSByte(PacketWriter writer, int i)
	{
		writer.Write(IntToSByte(i));
	}

	public static int ReadSByte(PacketReader reader)
	{
		return reader.ReadSByte();
	}

	public static void WriteByte(PacketWriter writer, int i)
	{
		writer.Write(IntToByte(i));
	}

	public static int ReadByte(PacketReader reader)
	{
		return reader.ReadByte();
	}

	public static void WriteNormalizedVec2(PacketWriter writer, Vector2 v)
	{
		float angle = Trig.GetAngle(default, v);
		angle /= 6.28f;
		angle *= 256f;
		writer.Write(IntToByte((int)angle));
	}

	public static Vector2 ReadNormalizedVec2(PacketReader reader)
	{
		float num = ReadByte(reader);
		num /= 256f;
		num *= 6.28f;
		return new Vector2((float)Math.Cos(num) * -1f, (float)Math.Sin(num) * -1f);
	}

	public static void WriteRadian(PacketWriter writer, float a)
	{
		while (a > 6.28f)
		{
			a -= 6.28f;
		}
		while (a < 0f)
		{
			a += 6.28f;
		}
		a /= 6.28f;
		a *= 256f;
		WriteByte(writer, (int)a);
	}

	public static float ReadRadian(PacketReader reader)
	{
		float num = ReadByte(reader);
		num /= 256f;
		return num * 6.28f;
	}

	public static void WriteSmallFloat(PacketWriter writer, float f)
	{
		writer.Write(SmallFloatToByte(f));
	}

	public static float ReadSmallFloat(PacketReader reader)
	{
		return ByteToSmallFloat(reader.ReadByte());
	}

	public static byte SmallFloatToByte(float f)
	{
		f *= 10f;
		if (f > 255f)
		{
			f = 255f;
		}
		if (f < 0f)
		{
			f = 0f;
		}
		return (byte)f;
	}

	public static float ByteToSmallFloat(byte b)
	{
		float num = (int)b;
		return num / 10f;
	}

	public static byte TinyFloatToByte(float f)
	{
		f *= 50f;
		if (f > 255f)
		{
			f = 255f;
		}
		if (f < 0f)
		{
			f = 0f;
		}
		return (byte)f;
	}

	public static float ByteToTinyFloat(byte b)
	{
		float num = (int)b;
		return num / 50f;
	}

	public static byte SmallFloatToSByte(float f)
	{
		f *= 10f;
		if (f > 127f)
		{
			f = 127f;
		}
		if (f < -128f)
		{
			f = -128f;
		}
		return (byte)f;
	}

	public static float SByteToSmallFloat(sbyte b)
	{
		float num = b;
		return num / 10f;
	}

	public static byte IntToByte(int i)
	{
		if (i > 255)
		{
			i = 255;
		}
		if (i < 0)
		{
			i = 0;
		}
		return (byte)i;
	}

	public static sbyte IntToSByte(int i)
	{
		if (i > 127)
		{
			i = 127;
		}
		if (i < -128)
		{
			i = -128;
		}
		return (sbyte)i;
	}

	public static short FloatToInt16(float f)
	{
		if (f > 32767f)
		{
			f = 32767f;
		}
		if (f < -32768f)
		{
			f = -32768f;
		}
		return (short)f;
	}

	internal static void WriteSmallInt(PacketWriter writer, int p)
	{
		if (p > 32767)
		{
			p = 32767;
		}
		if (p < -32768)
		{
			p = -32768;
		}
		short value = (short)p;
		writer.Write(value);
	}

	internal static int ReadSmallInt(PacketReader reader)
	{
		return reader.ReadInt16();
	}

	internal static void WriteTinyFloat(PacketWriter writer, float p)
	{
		writer.Write(TinyFloatToByte(p));
	}

	internal static float ReadTinyFloat(PacketReader reader)
	{
		return ByteToTinyFloat(reader.ReadByte());
	}
}
