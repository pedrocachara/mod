using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.guidestuff;
using Yuki_Win.hud;
using Yuki_Win.menu;

namespace Yuki_Win.netplay;

public class NetSession
{
	public enum State
	{
		None,
		Creating,
		Hosting,
		Finding,
		Joining,
		Client,
		JoiningInvited,
		QuickFinding
	}

	public State state;

	public NetworkSession session;

	private IAsyncResult result;

	public AvailableNetworkSessionCollection availableSessions;

	public StringBuilder[] gamerTag;

	public StringBuilder nullString = new StringBuilder("--");

	public NetGame netGame;

	public Thread netGameThread;

	public bool netUpdateBusy;

	public float createTimeOut;

	public float timeOut;

	public long sessionStartTime;

	public NetSession()
	{
		gamerTag = new StringBuilder[2];
		netGame = new NetGame();
	}

	public void Dispose()
	{
		state = State.None;
		if (session == null || session.IsDisposed)
		{
			return;
		}
		try
		{
			session.Dispose();
			while (!session.IsDisposed)
			{
			}
			session = null;
			state = State.None;
		}
		catch (Exception ex)
		{
			Game1.menuMgr.messageMgr.AddMsg(YukiText.epicFail, new string[2]
			{
				YukiText.couldNotDisposeNetworkSession,
				ex.ToString().ToLower()
			});
		}
	}

	public bool IsActive()
	{
		if (state != State.Hosting)
		{
			return state == State.Client;
		}
		return true;
	}

	public bool IsClient()
	{
		return state == State.Client;
	}

	public bool IsHost()
	{
		return state == State.Hosting;
	}

	public void Host()
	{
		Dispose();
		gamerTag[0] = null;
		gamerTag[1] = null;
		NetworkSessionProperties sessionProperties = new NetworkSessionProperties();
		List<SignedInGamer> list = new List<SignedInGamer>();
		list.Add(GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[0]));
		result = NetworkSession.BeginCreate(NetworkSessionType.PlayerMatch, list, 2, 0, sessionProperties, null, null);
		state = State.Creating;
		createTimeOut = 0f;
	}

	public void HostPrivate()
	{
		Dispose();
		gamerTag[0] = null;
		gamerTag[1] = null;
		List<SignedInGamer> list = new List<SignedInGamer>();
		list.Add(GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[0]));
		NetworkSessionProperties sessionProperties = new NetworkSessionProperties();
		result = NetworkSession.BeginCreate(NetworkSessionType.PlayerMatch, list, 2, 1, sessionProperties, null, null);
		state = State.Creating;
		createTimeOut = 0f;
	}

	public void Find()
	{
		Dispose();
		List<SignedInGamer> list = new List<SignedInGamer>();
		list.Add(GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[0]));
		NetworkSessionProperties searchProperties = new NetworkSessionProperties();
		result = NetworkSession.BeginFind(NetworkSessionType.PlayerMatch, list, searchProperties, null, null);
		state = State.Finding;
	}

	public void QuickFind()
	{
		timeOut = 0f;
		Dispose();
		NetworkSessionProperties searchProperties = new NetworkSessionProperties();
		List<SignedInGamer> list = new List<SignedInGamer>();
		list.Add(GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[0]));
		result = NetworkSession.BeginFind(NetworkSessionType.PlayerMatch, list, searchProperties, null, null);
		state = State.QuickFinding;
	}

	public bool GetSessionsAvailable()
	{
		if (availableSessions != null && availableSessions.Count > 0)
		{
			return true;
		}
		return false;
	}

	public void Join(AvailableNetworkSession session)
	{
		result = NetworkSession.BeginJoin(session, null, null);
		state = State.Joining;
	}

	public void ThreadedUpdate()
	{
		while (!Game1.mustExit)
		{
			netUpdateBusy = true;
			NetUpdate();
			netUpdateBusy = false;
			Thread.Sleep(20);
		}
	}

	internal StringBuilder GetRemoteGamerName()
	{
		if (session != null && session.RemoteGamers.Count > 0)
		{
			return new StringBuilder(session.RemoteGamers[0].Gamertag);
		}
		return new StringBuilder("");
	}

	internal StringBuilder GetLocalGamerName()
	{
		if (session != null && session.LocalGamers.Count > 0)
		{
			return new StringBuilder(session.LocalGamers[0].Gamertag);
		}
		return new StringBuilder("");
	}

	private void NetUpdate()
	{
		try
		{
			if (session != null)
			{
				lock (session)
				{
					if (session.IsDisposed)
					{
						session = null;
					}
					else
					{
						session.Update();
					}
				}
			}
			switch (state)
			{
			case State.Creating:
				if (result.IsCompleted)
				{
					session = NetworkSession.EndCreate(result);
					SetSimulatedLoss();
					session.GamerLeft += session_GamerLeft;
					session.GameStarted += session_GameStarted;
					state = State.Hosting;
					gamerTag[0] = null;
					gamerTag[1] = null;
				}
				break;
			case State.Finding:
				if (result.IsCompleted)
				{
					availableSessions = NetworkSession.EndFind(result);
					state = State.None;
				}
				break;
			case State.QuickFinding:
				if (result.IsCompleted)
				{
					availableSessions = NetworkSession.EndFind(result);
					if (availableSessions.Count > 0)
					{
						state = State.None;
					}
					else
					{
						Host();
					}
				}
				break;
			case State.Joining:
				if (!result.IsCompleted)
				{
					break;
				}
				try
				{
					session = NetworkSession.EndJoin(result);
					SetSimulatedLoss();
					session.SessionEnded += session_SessionEnded;
					session.GameStarted += session_GameStarted;
					state = State.Client;
					gamerTag[0] = null;
					gamerTag[1] = null;
					Game1.gamePlayerMgr.CopyPlayer(0, 1);
					break;
				}
				catch (Exception)
				{
					if (availableSessions != null)
					{
						availableSessions.Dispose();
					}
					Game1.menuMgr.messageMgr.AddMsg(YukiText.joinFail, new string[2]
					{
						YukiText.couldNotJoinSession,
						YukiText.lobbyFullOrUnavailable
					});
					state = State.None;
					break;
				}
			case State.JoiningInvited:
				if (result.IsCompleted)
				{
					try
					{
						session = NetworkSession.EndJoinInvited(result);
						session.SessionEnded += session_SessionEnded;
						session.GameStarted += session_GameStarted;
						state = State.Client;
						gamerTag[0] = null;
						gamerTag[1] = null;
						Game1.gamePlayerMgr.CopyPlayer(0, 1);
						break;
					}
					catch (Exception)
					{
						Game1.menuMgr.messageMgr.AddMsg(YukiText.joinFail, new string[2]
						{
							YukiText.couldNotJoinSession,
							YukiText.lobbyFullOrUnavailable
						});
						state = State.None;
						break;
					}
				}
				break;
			case State.Hosting:
				if (gamerTag[1] == null)
				{
					if (session.RemoteGamers.Count > 0)
					{
						gamerTag[1] = new StringBuilder(session.RemoteGamers[0].Gamertag);
					}
				}
				else if (session.RemoteGamers.Count == 0)
				{
					gamerTag[1] = null;
				}
				if (gamerTag[0] == null && session.LocalGamers.Count > 0)
				{
					gamerTag[0] = new StringBuilder(session.LocalGamers[0].Gamertag);
				}
				if (session.LocalGamers.Count == 0)
				{
					state = State.None;
					Dispose();
					try
					{
						Game1.storageMgr.storage[0].Read(1);
					}
					catch
					{
					}
					Game1.menuMgr.SetLevel(MenuManager.LevelTitle.MainMenu);
					Game1.menuMgr.messageMgr.AddMsg(YukiText.gameEnded, new string[4]
					{
						YukiText.disconnectedFromXboxLive,
						"",
						YukiText.returningToMain1,
						YukiText.returningToMain2
					}, clear: true, weak: true);
				}
				break;
			case State.Client:
				if (gamerTag[0] == null)
				{
					if (session.RemoteGamers.Count > 0)
					{
						gamerTag[0] = new StringBuilder(session.RemoteGamers[0].Gamertag);
					}
				}
				else if (session.RemoteGamers.Count == 0)
				{
					gamerTag[0] = null;
				}
				if (gamerTag[1] == null && session.LocalGamers.Count > 0)
				{
					gamerTag[1] = new StringBuilder(session.LocalGamers[0].Gamertag);
				}
				if (session.AllGamers.Count < 2)
				{
					state = State.None;
					Dispose();
					Game1.storageMgr.storage[0].Read(1);
				}
				break;
			}
		}
		catch (Exception ex3)
		{
			Printf.WriteLine(ex3.StackTrace);
		}
	}

	public int GetTimeDif()
	{
		long num = DateTime.UtcNow.Ticks - sessionStartTime;
		float num2 = (float)num / 10000000f;
		if (num2 > 2.1474836E+09f)
		{
			num2 = 2.1474836E+09f;
		}
		return (int)num2;
	}

	private void SetSimulatedLoss()
	{
	}

	public void Update()
	{
		NetUpdate();
		if (IsHost() || IsClient())
		{
			netGame.Update(session);
		}
	}

	private void session_GameStarted(object sender, GameStartedEventArgs e)
	{
		sessionStartTime = DateTime.UtcNow.Ticks;
	}

	private void session_GamerLeft(object sender, GamerLeftEventArgs e)
	{
		EndGuitarAndStuff();
		if (GameState.state == GameState.State.Menu && Game1.menuMgr.levels[39].active)
		{
			return;
		}
		bool flag = false;
		if (session == null)
		{
			flag = true;
		}
		else if (session.AllGamers.Count == 0)
		{
			flag = true;
		}
		if (flag)
		{
			Game1.menuMgr.messageMgr.AddMsg(YukiText.gameEnded, new string[4]
			{
				YukiText.disconnectedFromXboxLive,
				"",
				YukiText.returningToMain1,
				YukiText.returningToMain2
			}, clear: true, weak: false);
		}
		else
		{
			Game1.menuMgr.messageMgr.AddMsg(YukiText.disconnectedFromGame, new string[1] { YukiText.returningYouToLobby }, clear: true, weak: false, 1);
		}
		if (GameState.state == GameState.State.Menu)
		{
			if (Game1.menuMgr.pauseMode)
			{
				Game1.menuMgr.pauseMode = false;
			}
			Game1.menuMgr.ResetScene(1);
			if (flag)
			{
				Game1.menuMgr.SetLevel(MenuManager.LevelTitle.MainMenu);
			}
			else
			{
				Game1.menuMgr.SetLevel(MenuManager.LevelTitle.HostLobby);
			}
			Game1.menuMgr.transMode = MenuManager.TransitionMode.In;
			Game1.menuMgr.transFrame = 1f;
		}
		else
		{
			GameState.state = GameState.State.Menu;
			Game1.menuMgr.ResetScene(1);
			Game1.menuMgr.pauseMode = false;
			if (flag)
			{
				Game1.menuMgr.SetLevel(MenuManager.LevelTitle.MainMenu);
			}
			else
			{
				Game1.menuMgr.SetLevel(MenuManager.LevelTitle.HostLobby);
			}
			Game1.menuMgr.transMode = MenuManager.TransitionMode.In;
			Game1.menuMgr.transFrame = 1f;
		}
		if (session.SessionState == NetworkSessionState.Playing)
		{
			session.EndGame();
		}
	}

	private void EndGuitarAndStuff()
	{
		if (Game1.soloMgr.active)
		{
			Game1.soloMgr.guitarMgr.Stop();
		}
	}

	private void session_SessionEnded(object sender, NetworkSessionEndedEventArgs e)
	{
		EndGuitarAndStuff();
		if (GameState.state == GameState.State.Menu && Game1.menuMgr.levels[39].active)
		{
			Game1.menuMgr.SetLevel(MenuManager.LevelTitle.MultiplayerType);
			return;
		}
		_ = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[0])?.IsSignedInToLive;
		NetworkSessionEndReason endReason = e.EndReason;
		if (endReason == NetworkSessionEndReason.HostEndedSession)
		{
			Game1.menuMgr.messageMgr.AddMsg(YukiText.gameEnded, new string[5]
			{
				YukiText.hostLeft1,
				YukiText.hostLeft2,
				"",
				YukiText.returningToMultiplayer1,
				YukiText.returningToMultiplayer2
			}, clear: true, weak: true, 1);
		}
		else
		{
			Game1.menuMgr.messageMgr.AddMsg(YukiText.gameEnded, new string[5]
			{
				YukiText.remoteConnectionLost1,
				YukiText.remoteConnectionLost2,
				"",
				YukiText.returningToMultiplayer1,
				YukiText.returningToMultiplayer2
			}, clear: true, weak: true, 1);
		}
		if (GameState.state == GameState.State.Menu)
		{
			if (Game1.menuMgr.pauseMode)
			{
				Game1.menuMgr.pauseMode = false;
				Game1.menuMgr.ResetScene(1);
			}
			Game1.menuMgr.SetLevel(MenuManager.LevelTitle.MultiplayerType);
			Game1.menuMgr.transMode = MenuManager.TransitionMode.In;
			Game1.menuMgr.transFrame = 1f;
		}
		else
		{
			GameState.state = GameState.State.Menu;
			Game1.menuMgr.ResetScene(1);
			Game1.menuMgr.pauseMode = false;
			Game1.menuMgr.SetLevel(MenuManager.LevelTitle.MultiplayerType);
			Game1.menuMgr.transMode = MenuManager.TransitionMode.In;
			Game1.menuMgr.transFrame = 1f;
		}
	}

	internal bool IsReadyToLaunch()
	{
		if (state == State.Hosting && session != null && session.AllGamers.Count == 2)
		{
			return true;
		}
		return false;
	}

	internal void JoinInvite(InviteAcceptedEventArgs ie)
	{
		try
		{
			if (session != null && !session.IsDisposed)
			{
				session.Dispose();
				while (!session.IsDisposed)
				{
				}
			}
			List<SignedInGamer> list = new List<SignedInGamer>();
			list.Add(ie.Gamer);
			result = NetworkSession.BeginJoinInvited(list, null, null);
			state = State.JoiningInvited;
			Game1.menuMgr.messageMgr.Kill();
		}
		catch (Exception)
		{
			Game1.menuMgr.messageMgr.AddMsg(YukiText.joinFail, new string[2]
			{
				YukiText.couldNotJoinSession,
				YukiText.lobbyFullOrUnavailable
			}, clear: true, weak: false);
		}
	}
}
