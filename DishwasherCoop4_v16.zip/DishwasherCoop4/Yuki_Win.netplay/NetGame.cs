using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.arcade;
using Yuki_Win.chars;
using Yuki_Win.chars.script;
using Yuki_Win.hud;
using Yuki_Win.maps;
using Yuki_Win.maps.script;
using Yuki_Win.menu;
using Yuki_Win.player;
using Yuki_Win.solo;
using Yuki_Win.sprites;

namespace Yuki_Win.netplay;

public class NetGame
{
	public const byte DATA_CHAR = 0;

	public const byte DATA_SPRITE = 1;

	public const byte DATA_SERVER_UPDATE = 2;

	public const byte DATA_START_ARCADE_GAME = 3;

	public const byte DATA_END = 4;

	public const byte DATA_ARCADE_START = 5;

	public const byte DATA_MENU = 6;

	public const byte DATA_END_LEVEL = 7;

	public const byte DATA_SERVER_CLICK = 8;

	public const byte DATA_UBER_DEAD = 9;

	public const byte DATA_CONTINUE = 10;

	public const byte DATA_TRANSITION = 11;

	public const byte DATA_START_CAMPAIGN_GAME = 12;

	public const byte DATA_NET_SCRIPT = 13;

	public const byte DATA_PICKUP = 14;

	public const byte DATA_COOP_PICKUP = 15;

	public const byte DATA_ACTIVATE = 16;

	public const byte DATA_MAGIC = 17;

	public const byte DATA_CHAR_SCRIPT = 18;

	public const byte DATA_MASK = 19;

	public const byte DATA_LICHFREAKOUT = 20;

	public const byte DATA_SCENECLICK = 21;

	public const byte DATA_PAUSE = 22;

	public const byte DATA_UNPAUSE = 23;

	public const byte DATA_PICKUP_SPRITE = 24;

	public const byte DATA_CLICK_TO_HOST = 25;

	public const byte DATA_GUITAR_START = 26;

	public const byte DATA_KILL_CHAR = 27;

	public const byte DATA_ENDLICHFREAKOUT = 28;

	public const byte DATA_BACKTOLOBBY = 29;

	public const byte DATA_SCORE = 30;

	public const byte DATA_ENDSTUFF = 31;

	public const byte DATA_RESTART_LEVEL = 32;

	public const byte DATA_CREDITS_END = 33;

	public const byte DATA_GUITAR_REQUEST = 34;

	public const byte DATA_ENDLEVEL_TIME = 35;

	public const byte DATA_TIMESTAMP = 36;

	public const byte DATA_CHARS_SEND = 37;

	private const byte MENULEVEL_GAMETYPE = 0;

	private const byte MENULEVEL_CAMPAIGN_DIFFICULTY = 1;

	private const byte MENULEVEL_ARCADELEVELS = 2;

	private const byte MENULEVEL_CAMPAIGNLEVELS = 3;

	private const int HEADER_BYTES = 50;

	private PacketWriter writer;

	private PacketReader reader;

	private NetBool netBool;

	private float writeFrame;

	private float bytesPerSecond = 6000f;

	public Character dummyChar;

	private float minWriteFrame = 0.08f;

	private bool[] charsUpdate;

	public bool[] killChar;

	private int magicSend = -1;

	private CharUpdate.Magictype magicType;

	private Vector2 magicLoc;

	private long scoreToSend;

	private float panic;

	private float remotePanic;

	public bool dataJam;

	public bool IsPanic()
	{
		if (!(panic > 0f))
		{
			return remotePanic > 0f;
		}
		return true;
	}

	public NetGame()
	{
		charsUpdate = new bool[32];
		netBool = new NetBool();
		writer = new PacketWriter();
		reader = new PacketReader();
		dummyChar = new Character(16);
		killChar = new bool[32];
	}

	internal void Update(NetworkSession netSession)
	{
		if (panic > 0f)
		{
			panic -= FMan.realTime;
		}
		if (remotePanic > 0f)
		{
			remotePanic -= FMan.realTime;
		}
		lock (netSession)
		{
			LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
			int num = 0;
			int num2 = 0;
			Character obj = default;
			SoloMgr soloMgr = default;
			MenuManager menuMgr = default;
			HUD hud = default;
			while (localNetworkGamer.IsDataAvailable)
			{
				localNetworkGamer.ReceiveData(reader, out var _);
				num += reader.Length;
				bool flag = false;
				bool flag2 = false;
				for (int i = 0; i < charsUpdate.Length; i++)
				{
					charsUpdate[i] = false;
				}
				while (!flag)
				{
					switch (reader.ReadByte())
					{
					case 37:
						flag2 = true;
						break;
					case 0:
					{
						int num6 = reader.ReadByte();
						bool spawnFrame = num6 >= 100;
						num6 %= 100;
						charsUpdate[num6] = true;
						Game1.character[num6].netUpdate.Read(reader, spawnFrame);
						break;
					}
					case 30:
					{
						long score = reader.ReadInt64();
						if (Game1.netSession.IsHost())
						{
							Game1.gamePlayerMgr.gamePlayer[1].score = score;
						}
						else
						{
							Game1.gamePlayerMgr.gamePlayer[0].score = score;
						}
						break;
					}
					case 31:
						Game1.hud.ReadEndLevelStuff(reader);
						break;
					case 36:
						ReadTimestamp(reader);
						break;
					case 18:
					{
						int num5 = NetPacker.ReadByte(reader);
						int command = NetPacker.ReadByte(reader);
						int iParam = NetPacker.ReadByte(reader);
						string sParam = reader.ReadString();
						bool lockTaken4 = false;
						try
						{
							Monitor.Enter(obj = Game1.character[num5], ref lockTaken4);
							ScriptCommand s = new ScriptCommand((ScriptCommandParser.Command)command, iParam, sParam);
							Game1.character[num5].charAnim.charScript.ExecuteCommand(s, Game1.character[num5].charAnim, Game1.character[num5].charUpdate, Game1.character[num5].charMeta, Game1.character[num5].charKeys, num5, netInduced: true);
						}
						finally
						{
							if (lockTaken4)
							{
								Monitor.Exit(obj);
							}
						}
						break;
					}
					case 32:
						Game1.menuMgr.transGoal = MenuManager.TransitionGoal.RestartLevel;
						Game1.menuMgr.transFrame = 1f;
						Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
						break;
					case 29:
						Game1.menuMgr.transFrame = 1f;
						Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
						Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Lobby;
						break;
					case 35:
					{
						float t = reader.ReadSingle();
						Game1.hud.ReceiveServerTime(t);
						break;
					}
					case 33:
						Game1.credits.ClientCreditsEnd();
						break;
					case 21:
						Game1.sceneMgr.SceneClick(netInduced: true);
						break;
					case 25:
						ScriptManager.ClickToLoc(0);
						break;
					case 26:
					{
						string s2 = reader.ReadString();
						int num5 = ((!Game1.netSession.IsHost()) ? 1 : 0);
						bool lockTaken8 = false;
						try
						{
							Monitor.Enter(soloMgr = Game1.soloMgr, ref lockTaken8);
							Game1.soloMgr.Init(SoloMgr.NameFromString(s2));
							bool lockTaken9 = false;
							try
							{
								Monitor.Enter(obj = Game1.character[num5], ref lockTaken9);
								Game1.character[num5].charUpdate.charInput.StartGuitar(num5);
							}
							finally
							{
								if (lockTaken9)
								{
									Monitor.Exit(obj);
								}
							}
						}
						finally
						{
							if (lockTaken8)
							{
								Monitor.Exit(soloMgr);
							}
						}
						break;
					}
					case 34:
					{
						for (int k = 0; k < Game1.character.Length; k++)
						{
							if (!Game1.character[k].exists || !Game1.character[k].GetMeta().isGuitar)
							{
								continue;
							}
							string tag = Game1.character[k].tag;
							bool lockTaken6 = false;
							try
							{
								Monitor.Enter(soloMgr = Game1.soloMgr, ref lockTaken6);
								Game1.soloMgr.Init(SoloMgr.NameFromString(tag));
								bool lockTaken7 = false;
								try
								{
									Monitor.Enter(obj = Game1.character[0], ref lockTaken7);
									Game1.character[0].charUpdate.charInput.StartGuitar(0);
								}
								finally
								{
									if (lockTaken7)
									{
										Monitor.Exit(obj);
									}
								}
							}
							finally
							{
								if (lockTaken6)
								{
									Monitor.Exit(soloMgr);
								}
							}
							SendGuitar(netSession, tag);
							break;
						}
						break;
					}
					case 20:
						lock (Game1.gameMap)
						{
							Game1.gameMap.DoLichFreakout(netInduced: true);
						}
						break;
					case 28:
						Game1.gameMap.EndLichFreakout(p: true);
						break;
					case 3:
						lock (Game1.arcade)
						{
							Game1.arcade.arcadeMode = Arcade.ArcadeMode.Arcade;
							Game1.arcade.players = 2;
							bool lockTaken5 = false;
							try
							{
								Monitor.Enter(menuMgr = Game1.menuMgr, ref lockTaken5);
								GameSettings.difficulty = 2;
								Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Arcade;
								Game1.menuMgr.transGoalLevel = NetPacker.ReadByte(reader);
								Game1.menuMgr.transFrame = 1f;
								Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
							}
							finally
							{
								if (lockTaken5)
								{
									Monitor.Exit(menuMgr);
								}
							}
						}
						break;
					case 22:
					{
						if (Game1.netSession.IsHost() && GameState.state == GameState.State.Menu)
						{
							break;
						}
						GameState.state = GameState.State.Menu;
						bool lockTaken3 = false;
						try
						{
							Monitor.Enter(menuMgr = Game1.menuMgr, ref lockTaken3);
							Game1.menuMgr.owner = 0;
							Game1.menuMgr.pauseMode = true;
							Game1.menuMgr.remotePause = true;
							Game1.menuMgr.transMode = MenuManager.TransitionMode.In;
							Game1.menuMgr.transFrame = 1f;
							Game1.menuMgr.SetLevel(MenuManager.LevelTitle.RemotePauseMenu);
						}
						finally
						{
							if (lockTaken3)
							{
								Monitor.Exit(menuMgr);
							}
						}
						if (Game1.soloMgr.active)
						{
							Game1.soloMgr.Pause();
						}
						break;
					}
					case 23:
						Game1.menuMgr.UnPause(netInduced: true);
						break;
					case 19:
					{
						Vector2 loc2 = NetPacker.ReadVec2(reader);
						Vector2 traj = NetPacker.ReadVec2(reader);
						if (!CharTrigs.CheckAlreadyMask())
						{
							int num11 = Game1.spriteMan.AddGib(loc2, traj, 1, Game1.charMeta[73].headTex, Game1.charMeta[73].torsoTex, Game1.charMeta[73].legsTex, Game1.charMeta[73].weapTex, 26, "headfall", "headland", 0.35f, Game1.gameMap.CurMap(), 0, 1, 0, -1);
							if (num11 > -1)
							{
								Game1.spriteMan.gib[num11].isMask = true;
							}
						}
						break;
					}
					case 24:
						lock (Game1.spriteMan)
						{
							Game1.spriteMan.AddSprite(47, NetPacker.ReadVec2(reader), default, 0f, 0, -1);
						}
						break;
					case 27:
					{
						int num10 = NetPacker.ReadByte(reader);
						if (!(Game1.character[num10].charUpdate.spawnFrame > 0f))
						{
							Game1.character[num10].KillMe();
							Game1.character[num10].exists = false;
						}
						break;
					}
					case 16:
					{
						int num8 = NetPacker.ReadByte(reader);
						int num9 = NetPacker.ReadByte(reader);
						bool lockTaken14 = false;
						try
						{
							Monitor.Enter(obj = Game1.character[num8], ref lockTaken14);
							Game1.character[num8].charAnim.SetAnim(Game1.character[num8].GetMeta().activate_anim, Game1.character[num8].charUpdate);
							if (Game1.character[num8].charUpdate.loc.X > Game1.character[0].charUpdate.loc.X)
							{
								Game1.character[num8].charUpdate.face = 0;
							}
							else
							{
								Game1.character[num8].charUpdate.face = 1;
							}
							if (Game1.charMeta[num9].toast1 != null)
							{
								Game1.camMgr.bossToast.Init(Game1.charMeta[num9].toast1, Game1.charMeta[num9].toast2, num8, netInduced: true);
							}
						}
						finally
						{
							if (lockTaken14)
							{
								Monitor.Exit(obj);
							}
						}
						break;
					}
					case 17:
					{
						CharUpdate.Magictype magictype = (CharUpdate.Magictype)NetPacker.ReadByte(reader);
						Vector2 location = NetPacker.ReadVec2(reader);
						int num7 = NetPacker.ReadByte(reader);
						bool lockTaken13 = false;
						try
						{
							Monitor.Enter(obj = Game1.character[num7], ref lockTaken13);
							Game1.character[num7].charUpdate.magicType = magictype;
							Game1.character[num7].charAnim.charTrigs.DoMagic(Game1.character[num7], Game1.spriteMan, location, netInduced: true);
						}
						finally
						{
							if (lockTaken13)
							{
								Monitor.Exit(obj);
							}
						}
						break;
					}
					case 12:
					{
						bool lockTaken12 = false;
						try
						{
							Monitor.Enter(menuMgr = Game1.menuMgr, ref lockTaken12);
							Game1.menuMgr.transGoal = MenuManager.TransitionGoal.CoopCampaign;
							Game1.menuMgr.transGoalLevel = NetPacker.ReadByte(reader);
							GameSettings.difficulty = NetPacker.ReadByte(reader);
							Game1.menuMgr.transFrame = 1f;
							Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
						}
						finally
						{
							if (lockTaken12)
							{
								Monitor.Exit(menuMgr);
							}
						}
						break;
					}
					case 14:
					{
						bool lockTaken11 = false;
						try
						{
							Monitor.Enter(hud = Game1.hud, ref lockTaken11);
							Game1.hud.DoPickups(NetPacker.ReadByte(reader), reader.ReadBoolean(), netInduced: true);
						}
						finally
						{
							if (lockTaken11)
							{
								Monitor.Exit(hud);
							}
						}
						break;
					}
					case 15:
					{
						bool lockTaken10 = false;
						try
						{
							Monitor.Enter(hud = Game1.hud, ref lockTaken10);
							Game1.hud.DoPickups(NetPacker.ReadByte(reader), NetPacker.ReadByte(reader), netInduced: true);
						}
						finally
						{
							if (lockTaken10)
							{
								Monitor.Exit(hud);
							}
						}
						break;
					}
					case 13:
						Game1.gameMap.CurMap().scriptMgr.ReadNetScript(reader);
						break;
					case 9:
						Game1.killManager.DoUberDeath(netInduced: true);
						break;
					case 4:
						flag = true;
						break;
					case 8:
						Game1.hud.EndLevelServerClick();
						ReceiveStartSignal();
						break;
					case 5:
						Game1.hud.arcadeIn.GetHostArcadeGoSignal();
						ReceiveStartSignal();
						break;
					case 1:
						NetSprite.Read(reader);
						break;
					case 6:
					{
						bool active = Game1.menuMgr.levels[21].active;
						if (Game1.menuMgr.pauseMode)
						{
							NetPacker.ReadByte(reader);
							NetPacker.ReadByte(reader);
							break;
						}
						if (Game1.menuMgr.levels[46].active)
						{
							NetPacker.ReadByte(reader);
							NetPacker.ReadByte(reader);
							break;
						}
						for (int j = 0; j < Game1.menuMgr.levels.Count; j++)
						{
							Game1.menuMgr.levels[j].active = false;
						}
						int num3 = NetPacker.ReadByte(reader);
						if (num3 == 39 || num3 == 52)
						{
							num3 = 36;
						}
						if (num3 == 21 && !active)
						{
							Game1.worldMapMgr.Read("coop");
						}
						Game1.menuMgr.levels[num3].active = true;
						int num4 = NetPacker.ReadByte(reader);
						if (num3 == 14)
						{
							Game1.levelMgr.currentTrack = 3;
						}
						if (num3 == 11)
						{
							Game1.levelMgr.currentTrack = 2;
							GameSettings.difficulty = num4;
						}
						if (num3 != 36)
						{
							Game1.menuMgr.levels[num3].selected = num4;
						}
						break;
					}
					case 11:
					{
						string dest = reader.ReadString();
						Vector2 loc = NetPacker.ReadVec2(reader);
						int direction = NetPacker.ReadByte(reader);
						int dirX = NetPacker.ReadSByte(reader);
						int dirY = NetPacker.ReadSByte(reader);
						int transitionOwner = NetPacker.ReadByte(reader);
						int srcX = NetPacker.ReadByte(reader);
						int srcY = NetPacker.ReadByte(reader);
						lock (Game1.transMgr)
						{
							lock (Game1.character)
							{
								Game1.transMgr.DoNetTrans(dest, loc, direction, dirX, dirY, transitionOwner, srcX, srcY);
							}
						}
						break;
					}
					case 7:
					{
						bool lockTaken2 = false;
						try
						{
							Monitor.Enter(hud = Game1.hud, ref lockTaken2);
							Game1.hud.EndLevel();
						}
						finally
						{
							if (lockTaken2)
							{
								Monitor.Exit(hud);
							}
						}
						break;
					}
					case 10:
					{
						bool lockTaken = false;
						try
						{
							Monitor.Enter(menuMgr = Game1.menuMgr, ref lockTaken);
							Game1.menuMgr.transGoal = MenuManager.TransitionGoal.Continue;
							Game1.menuMgr.transFrame = 1f;
							Game1.menuMgr.transMode = MenuManager.TransitionMode.Out;
						}
						finally
						{
							if (lockTaken)
							{
								Monitor.Exit(menuMgr);
							}
						}
						break;
					}
					}
				}
				if (Game1.netSession.IsClient())
				{
					if (!flag2)
					{
						continue;
					}
					for (int l = 4; l < charsUpdate.Length; l++)
					{
						if (!charsUpdate[l] && Game1.character[l].exists)
						{
							Game1.character[l].exists = false;
						}
					}
				}
				else
				{
					DeathCheck();
				}
			}
			if (writeFrame > 0f)
			{
				writeFrame -= FMan.realTime;
				return;
			}
			for (int m = 0; m < netSession.RemoteGamers.Count; m++)
			{
				NetworkGamer recipient = netSession.RemoteGamers[m];
				bool flag3 = false;
				if (GameState.state == GameState.State.Playing)
				{
					WriteTimestamp(writer);
					if (Game1.netSession.IsHost())
					{
						NetPacker.WriteByte(writer, 37);
						Game1.character[0].netUpdate.Write(writer);
						if (Game1.character[2].exists)
						{
							Game1.character[2].netUpdate.Write(writer);
						}
						for (int n = 4; n < Game1.character.Length; n++)
						{
							if (Game1.character[n].exists)
							{
								Game1.character[n].netUpdate.Write(writer);
							}
						}
					}
					else
					{
						Game1.character[1].netUpdate.Write(writer);
						if (Game1.character[3].exists)
						{
							Game1.character[3].netUpdate.Write(writer);
						}
						for (int num12 = 4; num12 < Game1.character.Length; num12++)
						{
							if (Game1.character[num12].exists && Game1.character[num12].charUpdate.clientOwned > 0f)
							{
								Game1.character[num12].netUpdate.Write(writer);
							}
						}
					}
					for (int num13 = 0; num13 < killChar.Length; num13++)
					{
						if (killChar[num13])
						{
							NetPacker.WriteByte(writer, 27);
							NetPacker.WriteByte(writer, num13);
							flag3 = true;
							killChar[num13] = false;
						}
					}
					Game1.spriteMan.WriteNetSprites(writer);
					if (Game1.netSession.IsHost())
					{
						flag3 = Game1.gameMap.CurMap().scriptMgr.WriteNetScript(writer);
					}
					if (magicSend > -1)
					{
						NetPacker.WriteByte(writer, 17);
						NetPacker.WriteByte(writer, (int)magicType);
						NetPacker.WriteVec2(writer, magicLoc);
						NetPacker.WriteByte(writer, magicSend);
						magicSend = -1;
						flag3 = true;
					}
				}
				else if (GameState.state == GameState.State.Menu && Game1.netSession.IsHost())
				{
					for (int num14 = 0; num14 < Game1.menuMgr.levels.Count; num14++)
					{
						if (Game1.menuMgr.levels[num14].active)
						{
							NetPacker.WriteByte(writer, 6);
							NetPacker.WriteByte(writer, num14);
							NetPacker.WriteByte(writer, Game1.menuMgr.levels[num14].selected);
						}
					}
				}
				NetPacker.WriteByte(writer, 4);
				num2 = UpdateSendtotal(num2);
				if (dataJam)
				{
					num2 = UpdateDataJam(writer, num2);
					dataJam = false;
				}
				localNetworkGamer.SendData(writer, flag3 ? SendDataOptions.Reliable : SendDataOptions.InOrder, recipient);
			}
			writeFrame += (float)num2 / bytesPerSecond;
			if (writeFrame < minWriteFrame)
			{
				writeFrame = minWriteFrame;
			}
			if (IsPanic() && writeFrame < 1f)
			{
				writeFrame = 1f;
			}
		}
	}

	private void ReceiveStartSignal()
	{
	}

	private int UpdateDataJam(PacketWriter writer, int sendtotal)
	{
		if (flibitPort.GetInputAnalog(0, flibitPort.InputAction.Magic) > 0.3f)
		{
			for (int i = 0; i < 1000; i++)
			{
				if (Game1.netSession.IsHost())
				{
					Game1.character[0].netUpdate.Write(writer);
				}
				else if (Game1.netSession.IsClient())
				{
					Game1.character[1].netUpdate.Write(writer);
				}
			}
			return 0;
		}
		return sendtotal;
	}

	private void WriteTimestamp(PacketWriter writer)
	{
		writer.Write((byte)36);
		int timeDif = Game1.netSession.GetTimeDif();
		writer.Write(timeDif);
		writer.Write(panic > 0f);
	}

	private void ReadTimestamp(PacketReader reader)
	{
		int num = reader.ReadInt32();
		bool flag = reader.ReadBoolean();
		int timeDif = Game1.netSession.GetTimeDif();
		if (timeDif > 5)
		{
			timeDif -= num;
			if (timeDif > 5 || timeDif < -5)
			{
				panic = 5f;
			}
		}
		if (flag)
		{
			remotePanic = 2f;
		}
	}

	private void DeathCheck()
	{
		if (!(Game1.character[0].charUpdate.hp < 0f) || !(Game1.character[1].charUpdate.hp < 0f))
		{
			return;
		}
		for (int i = 0; i < 2; i++)
		{
			switch (Game1.character[i].charAnim.animName)
			{
			case "jhit":
			case "jmid":
			case "jfall":
			case "hitland":
				continue;
			}
			Game1.character[i].charAnim.SetAnim("jhit", Game1.character[i].charUpdate);
			Game1.character[i].charUpdate.traj.Y = -100f;
			Game1.character[i].charUpdate.state = CharUpdate.State.Airborne;
		}
		Game1.killManager.DoUberDeath();
	}

	internal void StartArcadeGame(NetworkSession netSession, int level)
	{
		if (netSession.SessionState == NetworkSessionState.Lobby)
		{
			netSession.StartGame();
		}
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 3);
			NetPacker.WriteByte(writer, level);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void StartArcade(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 5);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendEndLevel(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 7);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendServerClick(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 8);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendUberDead(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 9);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendContinue(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 10);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendTransition(NetworkSession networkSession, Vector2 loc, string dest, TransitionManager.TransitionDirection direction, int dirX, int dirY, int transitionOwner, int srcX, int srcY)
	{
		LocalNetworkGamer localNetworkGamer = networkSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < networkSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = networkSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 11);
			writer.Write(dest);
			NetPacker.WriteVec2(writer, loc);
			NetPacker.WriteByte(writer, (int)direction);
			NetPacker.WriteSByte(writer, dirX);
			NetPacker.WriteSByte(writer, dirY);
			NetPacker.WriteByte(writer, transitionOwner);
			NetPacker.WriteByte(writer, srcX);
			NetPacker.WriteByte(writer, srcY);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void StartCampaignGame(NetworkSession netSession, int level)
	{
		if (netSession.SessionState == NetworkSessionState.Lobby)
		{
			netSession.StartGame();
		}
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 12);
			NetPacker.WriteByte(writer, level);
			NetPacker.WriteByte(writer, GameSettings.difficulty);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendPickup(NetworkSession netSession, int name, bool used)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 14);
			NetPacker.WriteByte(writer, name);
			writer.Write(used);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	private int UpdateSendtotal(int sendTotal)
	{
		sendTotal += writer.Length;
		sendTotal += 50;
		return sendTotal;
	}

	internal void SendCoopPickup(NetworkSession netSession, int name, int coopName)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 15);
			NetPacker.WriteByte(writer, name);
			NetPacker.WriteByte(writer, coopName);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendActivate(NetworkSession netSession, int m, int def)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 16);
			NetPacker.WriteByte(writer, m);
			NetPacker.WriteByte(writer, def);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void AddMagic(Character c, Vector2 location)
	{
		magicSend = c.ID;
		magicType = c.charUpdate.magicType;
		magicLoc = location;
	}

	internal void SendCharScript(NetworkSession netSession, ScriptCommand s, int ID)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 18);
			NetPacker.WriteByte(writer, ID);
			NetPacker.WriteByte(writer, (int)s.command);
			NetPacker.WriteByte(writer, s.iParam);
			if (s.sParam != null)
			{
				writer.Write(s.sParam);
			}
			else
			{
				writer.Write("");
			}
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendMask(NetworkSession netSession, Vector2 loc, Vector2 traj)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 19);
			NetPacker.WriteVec2(writer, loc);
			NetPacker.WriteVec2(writer, traj);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendLichFreakout(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 20);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void EndLichFreakout(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 28);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendSceneClick(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 21);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendPause(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 22);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendUnPause(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 23);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendPickupSprite(NetworkSession netSession, Vector2 vector2)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 24);
			NetPacker.WriteVec2(writer, vector2);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendClickToHostLoc(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 25);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendGuitar(NetworkSession netSession, string path)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 26);
			writer.Write(path);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendGuitarRequest(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 34);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendBackToLobby(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 29);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendCreditsEnd(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 33);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendScore(NetworkSession netSession, long score)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 30);
			writer.Write(score);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendEndStuff(NetworkSession netSession, int idx, int kills, int maxCombo, long score, int damage)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 31);
			NetPacker.WriteByte(writer, idx);
			writer.Write(kills);
			writer.Write(maxCombo);
			writer.Write(damage);
			writer.Write(score);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendRestart(NetworkSession netSession)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 32);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}

	internal void SendEndLevelTime(NetworkSession netSession, float p)
	{
		LocalNetworkGamer localNetworkGamer = netSession.LocalGamers[0];
		int num = 0;
		for (int i = 0; i < netSession.RemoteGamers.Count; i++)
		{
			NetworkGamer recipient = netSession.RemoteGamers[i];
			NetPacker.WriteByte(writer, 35);
			writer.Write(p);
			NetPacker.WriteByte(writer, 4);
			num = UpdateSendtotal(num);
			localNetworkGamer.SendData(writer, SendDataOptions.Reliable, recipient);
		}
		writeFrame += (float)num / bytesPerSecond;
		if (writeFrame < minWriteFrame)
		{
			writeFrame = minWriteFrame;
		}
	}
}
