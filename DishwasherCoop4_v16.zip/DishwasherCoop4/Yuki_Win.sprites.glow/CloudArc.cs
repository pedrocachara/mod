using System;
using Microsoft.Xna.Framework;

namespace Yuki_Win.sprites.glow;

public class CloudArc : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.rotation = size;
		p.flags = flags;
		p.traj = traj;
		p.frame = 0.16f;
		p.thresh = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite part, SpriteManager spriteMan)
	{
		for (int i = 0; i < 2; i++)
		{
			float frame = part.frame;
			part.frame -= FMan.frameTime;
			if ((int)(frame * 60f) == (int)(part.frame * 60f))
			{
				continue;
			}
			for (int j = 0; j < 2; j++)
			{
				float num = 0.2f - part.frame;
				if (part.flags == 0)
				{
					num = 0.2f - num;
				}
				num = num * 5f * 3.14f;
				num += ((part.flags == 1) ? 1.57f : (-1.57f));
				num += Rand.GetRandomFloat(-0.05f, 0.05f);
				Vector2 v = new Vector2((float)Math.Cos(num) * 64f * part.traj.X, (float)Math.Sin(num) * 64f * part.traj.Y);
				float angle = Trig.GetAngle(default, v);
				float num2 = (float)Math.Sqrt(v.X * v.X + v.Y * v.Y);
				angle += part.rotation;
				v = new Vector2((float)Math.Cos(angle) * num2, (float)Math.Sin(angle) * num2);
				v += part.loc;
				float num3 = Rand.GetRandomFloat(180f, 220f);
				if (part.flags == 0)
				{
					num3 = 0f - num3;
				}
				if (part.frame > 0.09f)
				{
					if (Rand.CointToss(0.25f))
					{
						spriteMan.AddSprite(42, v, new Vector2((float)Math.Cos((double)angle + 1.57) * part.traj.X * num3 * 4f, (float)Math.Sin((double)angle + 1.57) * part.traj.Y * num3 * 4f), part.frame * 8f, 0, 0);
					}
					else
					{
						spriteMan.AddSprite(42, v, new Vector2((float)Math.Cos((double)angle + 1.57) * part.traj.X * num3 * 5f, (float)Math.Sin((double)angle + 1.57) * part.traj.Y * num3 * 5f), part.frame * 8f, 0, 0);
					}
				}
				if (part.frame < 0.1f && Rand.CointToss(0.25f))
				{
					spriteMan.AddSprite(18, v, new Vector2((float)Math.Cos((double)angle + 1.57) * part.traj.X * num3, (float)Math.Sin((double)angle + 1.57) * part.traj.Y * num3), (0.2f - part.frame) * 5f + 0.2f, 0, 0);
				}
			}
		}
	}
}
