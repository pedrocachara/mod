using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.glow;

internal class BlastInk : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		p.r = Rand.GetRandomFloat(size / 4f, size / 2f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.frame = Rand.GetRandomFloat(0.05f, 0.1f);
		p.loc += traj * 0.025f;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		p.rotation = Trig.GetAngle(default, p.traj);
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		sprite.Draw(spritesTex, screenLoc, new Rectangle(448, 64, 64, 64), new Color(new Vector4(0.1f, 0f, 0f, p.frame * 15f)), p.rotation, new Vector2(32f, 32f), new Vector2(p.size, p.r) * ScrollManager.cannedDepth[0] * 0.55f, SpriteEffects.None, 1f);
	}
}
