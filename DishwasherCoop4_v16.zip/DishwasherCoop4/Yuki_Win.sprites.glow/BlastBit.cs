using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.glow;

internal class BlastBit : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.r = 1f;
		p.g = 1f;
		p.b = 1f;
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 2);
		p.frame = Rand.GetRandomFloat(0.2f, 0.4f);
		p.alpha = true;
		p.loc += traj * Rand.GetRandomFloat(0f, 0.1f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		p.rotation = Trig.GetAngle(default, p.traj) + 3.14f;
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		sprite.Draw(spritesTex, screenLoc, new Rectangle(448, 32, 128, 32), new Color(new Vector4(p.r, p.g, p.b, p.frame * 0.35f)), p.rotation, new Vector2(16f, 16f), new Vector2(p.size * 2f, p.size) * ScrollManager.cannedDepth[0] * 0.55f, SpriteEffects.None, 1f);
	}
}
