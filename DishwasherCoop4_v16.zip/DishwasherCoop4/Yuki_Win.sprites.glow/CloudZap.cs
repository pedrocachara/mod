using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.glow;

internal class CloudZap : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		p.frame = 0.2f;
		p.alpha = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(896, Rand.GetRandomInt(0, 3) * 128, 128, 128), new Color(0.5f, 0.5f, 1f, 1f), Rand.GetRandomFloat(0f, 6.28f), new Vector2(64f, 64f), p.size, SpriteEffects.None, 1f);
		PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), 0.5f, 0.5f, 1f, p.size * Rand.GetRandomFloat(0.1f, 2f), p.frame * 0.4f, 1f);
	}
}
