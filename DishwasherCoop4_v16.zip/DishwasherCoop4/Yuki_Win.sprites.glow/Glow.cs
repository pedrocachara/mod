using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.glow;

internal class Glow : SpriteDef
{
	public const int GLOW_RED = 0;

	public const int GLOW_BLUE = 1;

	public const int GLOW_WHITE = 2;

	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		switch (flags)
		{
		case 2:
			p.r = 1f;
			p.g = 1f;
			p.b = 1f;
			break;
		case 0:
			p.r = 1f;
			p.g = 0.6f;
			p.b = 0.5f;
			break;
		case 1:
			p.r = 0.3f;
			p.g = 0.5f;
			p.b = 1f;
			break;
		}
		p.size = size;
		p.frame = 1f;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(256, 0, 64, 64), new Color(new Vector4(p.r, p.g, p.b, p.frame)), 0f, new Vector2(32f, 32f), p.size, SpriteEffects.None, 1f);
		PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), p.r, p.g, p.b, p.size * 2f * ScrollManager.cannedDepth[0] * 0.55f, p.frame * 0.2f, 1f);
	}
}
