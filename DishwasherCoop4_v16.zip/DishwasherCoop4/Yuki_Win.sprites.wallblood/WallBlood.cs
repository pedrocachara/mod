using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.sprites.goreInstance;

namespace Yuki_Win.sprites.wallblood;

public class WallBlood
{
	public Vector2 loc;

	public float r;

	public float size;

	public int idx;

	public int dripIdx;

	public float frame;

	public int dripTest;

	public bool exists;

	public void Init(Vector2 loc)
	{
		exists = true;
		this.loc = loc;
		r = Rand.GetRandomFloat(0f, 6.28f);
		size = Rand.GetRandomFloat(0.8f, 1.2f);
		idx = Rand.GetRandomInt(0, 6);
		dripIdx = Rand.GetRandomInt(0, 4);
		dripTest = 0;
		frame = 10f;
	}

	public void SetFromInstance(Vector2 loc, float r, float size, int idx, int dripIdx, int dripTest, float frame)
	{
		exists = true;
		this.loc = loc;
		this.r = r;
		this.size = size;
		this.idx = idx;
		this.dripIdx = dripIdx;
		this.dripTest = dripTest;
		this.frame = frame;
	}

	public void Update()
	{
		if (frame > 0f)
		{
			frame -= FMan.frameTime;
		}
		if (frame <= 0f)
		{
			exists = false;
		}
	}

	public void Draw(SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = 1f;
		if (frame < 1f)
		{
			num = frame;
		}
		float num2 = size;
		if (frame > 9.9f)
		{
			num2 = (10f - frame) * size * 10f;
		}
		Vector2 screenLoc = ScrollManager.GetScreenLoc(loc, 1f);
		if (dripTest == 1)
		{
			sprite.Draw(spritesTex, screenLoc, new Rectangle(384 + idx * 64, 256, 64, 64), new Color(new Vector4(0.6f, 0f, 0f, num)), 0f, new Vector2(32f, 32f), new Vector2(num2 * 1.2f, num2 * 0.9f) * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
		}
		else
		{
			if (dripTest <= 1)
			{
				return;
			}
			sprite.Draw(spritesTex, screenLoc, new Rectangle(384 + idx * 64, 256, 64, 64), new Color(new Vector4(0.6f, 0f, 0f, num)), r, new Vector2(32f, 32f), num2 * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
			if (dripTest == 3 && frame < 9.95f)
			{
				screenLoc = ScrollManager.GetScreenLoc(loc - new Vector2(0f, 16f), 1f);
				float num3 = (9.95f - frame) * 0.5f;
				float num4 = (9.95f - frame) * 3f;
				if (num4 > 1f)
				{
					num4 = 1f;
				}
				if (num3 > 3f)
				{
					num3 = 3f;
				}
				sprite.Draw(spritesTex, screenLoc, new Rectangle(448 + idx % 4 * 32, 192, 32, 32), new Color(new Vector4(0.6f, 0f, 0f, num * num4)), 0f, new Vector2(16f, 3f), new Vector2(size * 1.5f, size * 0.5f + num3) * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
			}
		}
	}

	internal GoreInstance.WallBloodInstance GetInstance()
	{
		GoreInstance.WallBloodInstance result = default;
		result.dripIdx = dripIdx;
		result.dripTest = dripTest;
		result.frame = frame;
		result.idx = idx;
		result.loc = loc;
		result.r = r;
		result.size = size;
		return result;
	}
}
