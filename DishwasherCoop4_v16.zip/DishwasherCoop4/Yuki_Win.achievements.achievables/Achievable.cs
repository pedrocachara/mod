using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;

namespace Yuki_Win.achievements.achievables;

public class Achievable
{
	public float frame;

	public void Update()
	{
		if (frame > 0f)
		{
			frame -= FMan.frameTime;
		}
	}

	public void Draw(SpriteBatch sprite)
	{
		float num = 1f;
		float scale = 1f;
		Vector2 vector = new Vector2(560f, 580f);
		if (frame < 0.5f)
		{
			num = (float)Math.Sin(frame * 4f);
		}
		else
		{
			num = ((!(frame < 3f)) ? ((float)Math.Sin((3.5f - frame) * 4f)) : ((float)Math.Sin(2.0)));
		}
		float num2 = frame;
		if (num2 < 2f)
		{
			num2 -= 0.125f;
		}
		if (num2 > 2f)
		{
			num2 += 0.125f;
		}
		if (num2 > 0f && num2 < 3.5f)
		{
			if (num2 < 0.5f)
			{
				scale = (float)Math.Sin(num2 * 4f);
			}
			else
			{
				scale = ((!(num2 < 3f)) ? ((float)Math.Sin((3.5f - num2) * 4f)) : ((float)Math.Sin(2.0)));
			}
			scale *= 1.1f;
			sprite.Draw(Game1.spritesTex, vector, new Rectangle(1024, 128, 128, 320), new Color(1f, 1f, 1f, 1f), -1.57f, new Vector2(64f, 64f), scale, SpriteEffects.None, 1f);
		}
		if (frame > 0.5f && frame < 3f)
		{
			sprite.Draw(Game1.spritesTex, vector + new Vector2(70f, 0f), new Rectangle(1024, 576, 128, 256), new Color(1f, 1f, 1f, 1f), -1.57f, new Vector2(64f, 64f), scale, SpriteEffects.None, 1f);
		}
		sprite.Draw(Game1.spritesTex, vector, new Rectangle(1024, 448, 128, 128), new Color(1f, 1f, 1f, 1f), -1.57f, new Vector2(64f, 64f), num, SpriteEffects.None, 1f);
		if (frame > 0.5f && frame < 3f && (int)((frame - 0.5f) * 2f) % 2 == 0)
		{
			sprite.Draw(Game1.spritesTex, vector, new Rectangle(1024, 832, 64, 64), new Color(1f, 1f, 1f, 1f), -1.57f, new Vector2(32f, 32f), num, SpriteEffects.None, 1f);
		}
	}

	internal void Init()
	{
		frame = 3.5f;
		Sound.PlaySnd(Sound.Category.FX, "bleep");
	}
}
