using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.warp;

internal class WarpSmokeOut : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.flags = Rand.GetRandomInt(0, 4);
		p.frame = Rand.GetRandomFloat(0.4f, 0.5f);
		p.size = Rand.GetRandomFloat(0.5f, 2f);
		p.thresh = true;
		p.r = Rand.GetRandomFloat(0f, 0.5f);
		if (p.frame < 0.3f && p.traj.LengthSquared() > 90000f)
		{
			p.traj.Normalize();
			p.traj *= 300f;
		}
		if (p.frame < 0.15f && p.traj.LengthSquared() > 10000f)
		{
			p.traj.Normalize();
			p.traj *= 100f;
		}
		p.traj.Y -= FMan.frameTime * 110f;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.frame < 0.3f && p.traj.LengthSquared() > 90000f)
		{
			p.traj.Normalize();
			p.traj *= 300f;
		}
		if (p.frame < 0.15f && p.traj.LengthSquared() > 10000f)
		{
			p.traj.Normalize();
			p.traj *= 100f;
		}
		p.traj.Y -= FMan.AdjustedFrame(p.owner) * 110f;
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite par, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = par.frame * 6.28f;
		float num2 = (float)Math.Sin(num);
		float num3 = num2;
		if (num3 > 0.5f)
		{
			num3 = 0.5f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(par.loc, 1f), new Rectangle(256 + 64 * par.flags, 128, 64, 64), new Color(par.r, 0f, 0f, num3), par.frame, new Vector2(32f, 32f), par.size * ScrollManager.cannedDepth[0] * 1f, SpriteEffects.None, 1f);
	}
}
