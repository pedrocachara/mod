using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.warp;

internal class DishWarpIn : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.flags = Rand.GetRandomInt(0, 5);
		p.frame = Rand.GetRandomFloat(0.125f, 0.25f);
		p.size = Rand.GetRandomFloat(0.5f, 0.8f);
		p.thresh = false;
		p.owner = owner;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		Vector2 loc = Game1.character[p.owner].charUpdate.loc;
		_ = loc - p.loc + Game1.character[p.owner].charUpdate.warpVec * 600f;
		p.traj = (loc + new Vector2(0f, -40f) - p.loc) * (0.25f - p.frame) * 120f;
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite par, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = (0.125f - par.frame) * 4f;
		if (num > 0.3f)
		{
			num = 0.3f;
		}
		if (!par.thresh)
		{
			num *= 2f;
		}
		if (par.frame < 0.04f)
		{
			num *= par.frame * 25f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(par.loc, 1f), new Rectangle(576 + 64 * par.flags, 192, 64, 64), new Color(new Vector4(0f, 0f, par.thresh ? 1f : 0f, num)), par.frame, new Vector2(32f, 32f), par.size * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
	}
}
