using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.warp;

internal class DishWarpSmoke : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.flags = Rand.GetRandomInt(0, 5);
		p.frame = Rand.GetRandomFloat(0.2f, 0.4f);
		p.size = Rand.GetRandomFloat(0.5f, 1f);
		p.thresh = Rand.CointToss(0.05f);
		p.rotation = Trig.GetAngle(default, traj);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.frame < 0.3f && p.traj.Length() > 300f)
		{
			p.traj.Normalize();
			p.traj *= 300f;
		}
		if (p.frame < 0.15f && p.traj.Length() > 100f)
		{
			p.traj.Normalize();
			p.traj *= 100f;
		}
		p.traj.Y -= FMan.AdjustedFrame(p.owner) * 110f;
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite par, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = par.frame;
		if (num > 0.2f)
		{
			num = 0.2f;
		}
		if (!par.thresh)
		{
			num *= 1.5f;
		}
		if (par.flags == 4)
		{
			num *= 2f;
		}
		float x = 3f;
		if (par.frame < 0.5f)
		{
			x = 0.5f + par.frame * 5f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(par.loc, 1f) * 1f, new Rectangle(576 + 64 * par.flags, 192, 64, 64), new Color(new Vector4(0f, 0f, par.thresh ? 1f : 0f, num)), par.rotation, new Vector2(32f, 32f), new Vector2(x, 0.5f) * par.size * ScrollManager.cannedDepth[0] * 1f, SpriteEffects.None, 1f);
	}
}
