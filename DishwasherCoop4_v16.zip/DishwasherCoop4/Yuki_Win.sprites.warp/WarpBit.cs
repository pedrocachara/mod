using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.chars;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.warp;

internal class WarpBit : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.owner = owner;
		CharUpdate charUpdate = Game1.character[p.owner].charUpdate;
		p.loc = new Vector2(0f, -40f) + Rand.GetRandomVec2(-30f, 30f, -40f, 40f);
		p.traj = charUpdate.warpVec + Rand.GetRandomVec2(-500f, 500f, -500f, 500f);
		p.flags = Rand.GetRandomInt(0, 3);
		p.frame = 0.125f;
		p.size = Rand.GetRandomFloat(1f, 3f);
		p.r = Rand.GetRandomFloat(0f, 0.5f);
		p.thresh = true;
		if (charUpdate != null)
		{
			Vector2 realWarpVec = charUpdate.realWarpVec;
			if (realWarpVec.Length() < 1f)
			{
				p.traj = charUpdate.warpVec;
			}
			else
			{
				p.traj = realWarpVec;
			}
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		CharUpdate charUpdate = Game1.character[p.owner].charUpdate;
		if (charUpdate != null)
		{
			Vector2 realWarpVec = charUpdate.realWarpVec;
			if (realWarpVec.Length() < 1f)
			{
				p.traj = charUpdate.warpVec;
			}
			else
			{
				p.traj = realWarpVec;
			}
		}
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
		p.rotation = Trig.GetAngle(default, p.traj);
	}

	public override void Draw(Sprite par, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = par.frame * 12.56f;
		float num2 = (float)Math.Sin(num);
		float num3 = 4f * num2;
		if (num3 > 0.65f)
		{
			num3 = 0.65f;
		}
		if (num2 > 0.25f && num2 < 0.25f)
		{
			num2 = 0.25f;
		}
		CharUpdate charUpdate = Game1.character[par.owner].charUpdate;
		if (charUpdate != null)
		{
			sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(charUpdate.loc + par.loc, 1f), new Rectangle(256 + 64 * par.flags, 128, 64, 64), new Color(par.r, 0f, 0f, num3 * 2f), par.rotation, new Vector2(32f, 32f), new Vector2(num2 * par.size * 2f, par.size / 4f) * ScrollManager.cannedDepth[0] * 1f, SpriteEffects.None, 1f);
			if (par.thresh)
			{
				GameRender.threshRender.AddPoint(ScrollManager.GetScreenLoc(charUpdate.loc + par.loc, 1f), 20f);
				GameRender.threshRender.AddPoint(ScrollManager.GetScreenLoc(charUpdate.loc + par.loc + par.traj * 5f, 1f), 20f);
				GameRender.threshRender.AddPoint(ScrollManager.GetScreenLoc(charUpdate.loc + par.loc + par.traj * -5f, 1f), 20f);
			}
		}
	}
}
