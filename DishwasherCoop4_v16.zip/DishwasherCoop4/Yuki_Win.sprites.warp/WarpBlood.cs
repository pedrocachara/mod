using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.warp;

internal class WarpBlood : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.owner = owner;
		p.loc = loc;
		p.traj = traj + Rand.GetRandomVec2(-50f, 50f, -50f, 50f);
		p.flags = Rand.GetRandomInt(0, 3);
		p.frame = 0.15f;
		p.size = Rand.GetRandomFloat(3f, 5f);
		p.r = Rand.GetRandomFloat(0.2f, 0.6f) * 10f;
		p.rotation = Trig.GetAngle(default, traj);
		p.g = Rand.GetRandomFloat(0f, 0.5f);
		p.thresh = Rand.CointToss(0.5f);
		p.thresh = true;
		if (Rand.CointToss(0.5f))
		{
			p.rotation += 3.14f;
		}
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
	}

	public override void Draw(Sprite par, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = par.frame * 7f;
		if (num > 0.175f)
		{
			num = 0.175f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(par.loc, 1f), new Rectangle(512 + 128 * par.flags, 1024, 128, 64), new Color(par.g, 0f, 0f, num * 2f), par.rotation, new Vector2(64f, 32f), new Vector2(0.5f - par.frame, par.r * par.frame) * 1f * par.size * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
	}
}
