using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.warp;

internal class DishWarpOutRefract : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.flags = Rand.GetRandomInt(0, 5);
		p.frame = Rand.GetRandomFloat(0.25f, 0.5f);
		p.size = Rand.GetRandomFloat(0.95f, 1f);
		p.thresh = Rand.CointToss(0.05f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (p.frame < 0.4f && p.traj.LengthSquared() > 90000f)
		{
			p.traj.Normalize();
			p.traj *= 300f;
		}
		if (p.frame < 0.3f && p.traj.LengthSquared() > 10000f)
		{
			p.traj.Normalize();
			p.traj *= 100f;
		}
		p.traj.Y -= FMan.frameTime * 110f;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite par, SpriteBatch sprite, Texture2D spritesTex)
	{
		float num = par.frame;
		if (num > 0.3f)
		{
			num = 0.3f;
		}
		if (!par.thresh)
		{
			num *= 1.5f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(par.loc, 1f) * 1f, new Rectangle(576 + 64 * par.flags, 192, 64, 64), new Color(new Vector4(0f, 0f, 0.05f, num)), par.frame * 2f, new Vector2(32f, 32f), par.size * ScrollManager.cannedDepth[0] * 1f, SpriteEffects.None, 1f);
	}
}
