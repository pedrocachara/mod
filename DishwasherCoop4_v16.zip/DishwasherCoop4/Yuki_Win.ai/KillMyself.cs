using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class KillMyself : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.charger = true;
		ai.job = 9;
	}
}
