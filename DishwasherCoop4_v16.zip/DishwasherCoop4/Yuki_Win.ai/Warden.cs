using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class Warden : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.charger = true;
		if (ai.frame < 0f)
		{
			if (ai.job == 1)
			{
				ai.SetJob(3, Rand.GetRandomFloat(2f, 3f), c);
			}
			else if (ai.job == 3)
			{
				ai.SetJob(4, Rand.GetRandomFloat(2f, 3f), c);
			}
			else
			{
				ai.SetJob(1, Rand.GetRandomFloat(2f, 3f), c);
			}
		}
	}
}
