using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class Box : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.SetJob(0, 1f, c);
	}
}
