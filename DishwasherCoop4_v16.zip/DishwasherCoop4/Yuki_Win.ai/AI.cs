using System;
using Microsoft.Xna.Framework;
using Yuki_Win.chars;
using Yuki_Win.debug;

namespace Yuki_Win.ai;

public class AI
{
	public const int JOB_IDLE = 0;

	public const int JOB_MELEE_CHASE = 1;

	public const int JOB_STRONG_CHASE = 2;

	public const int JOB_SHOOT_CHASE = 3;

	public const int JOB_JUMP_CHASE = 4;

	public const int JOB_SHOOT_OR_MELEE_CHASE = 5;

	public const int JOB_FOLLOW_TARG = 6;

	public const int JOB_BERZERKER = 7;

	public const int JOB_KILL_CENTER = 8;

	public const int JOB_KILL_MYSELF = 9;

	public const int JOB_AIR_KILL_CENTER = 10;

	public const int JOB_BE_A_YUKI = 11;

	public const int JOB_BE_A_LACKEY = 12;

	public int job;

	public float frame;

	public int targ;

	public int ID;

	public int type;

	public bool charger;

	public Vector2 vTarg;

	public int owner;

	public bool mount;

	public AI(int type, int ID)
	{
		this.type = type;
		this.ID = ID;
	}

	public float GetTargDist()
	{
		if (targ > -1 && Game1.character[targ].exists)
		{
			return Math.Abs(Game1.character[targ].charUpdate.loc.X - Game1.character[ID].charUpdate.loc.X);
		}
		return -1f;
	}

	public void Update(Character[] c)
	{
		frame -= FMan.frameTime;
		if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
		{
			if (Game1.netSession.netGame.IsPanic())
			{
				job = 0;
				frame = 1f;
			}
			if (Game1.netSession.IsHost())
			{
				if (c[ID].charUpdate.clientOwned > 0f)
				{
					return;
				}
			}
			else if (Game1.netSession.IsClient() && (!DebugManager.netLackeyMode || ID != 1) && c[ID].charUpdate.clientOwned <= 0f)
			{
				return;
			}
		}
		AICatalog.aiType[type].Update(this, c);
		switch (job)
		{
		case 1:
			if (Chase(c, new Vector2(100f, 100f)))
			{
				Attack(c, lookUp: true);
			}
			break;
		case 3:
			if (Chase(c, new Vector2(400f, 100f)))
			{
				Strong(c, lookUp: true);
			}
			break;
		case 4:
			if (Chase(c, new Vector2(300f, 100f)))
			{
				Jump(c, lookUp: true);
			}
			break;
		case 5:
			Chase(c, new Vector2(100f, 100f));
			if (GetTargDist() <= 100f)
			{
				Attack(c);
			}
			else if (GetTargDist() <= 500f)
			{
				Strong(c, lookUp: true);
			}
			break;
		case 6:
			WalkTo(c, new Vector2(60f, 20f));
			break;
		case 7:
			Chase(c, new Vector2(200f, 100f));
			if (GetTargDist() <= 300f)
			{
				float randomFloat2 = Rand.GetRandomFloat(0f, 1f);
				if (randomFloat2 < 0.33f)
				{
					Attack(c, lookUp: true);
				}
				else if (randomFloat2 < 0.66f)
				{
					Strong(c, lookUp: true);
				}
				else
				{
					Jump(c, lookUp: true);
				}
			}
			break;
		case 12:
		{
			int num = 1 - ID;
			if (c[num].charKeys.keyRight)
			{
				c[ID].charKeys.keyRight = true;
			}
			if (c[num].charKeys.keyLeft)
			{
				c[ID].charKeys.keyLeft = true;
			}
			if (c[num].charUpdate.state != CharUpdate.State.Grounded)
			{
				c[ID].charKeys.rVec = c[num].charUpdate.loc - c[ID].charUpdate.loc;
				c[ID].charKeys.rVec.Y = 0f - c[ID].charKeys.rVec.Y;
				c[ID].charKeys.rVec.Normalize();
			}
			break;
		}
		case 11:
			Chase(c, new Vector2(200f, 100f));
			if (GetTargDist() <= 300f)
			{
				float randomFloat = Rand.GetRandomFloat(0f, 1f);
				if (randomFloat < 0.33f)
				{
					Attack(c, lookUp: true);
				}
				else if (randomFloat < 0.66f)
				{
					Strong(c, lookUp: true);
				}
				else
				{
					Jump(c, lookUp: true);
				}
			}
			if (c[ID].charAnim.animName == c[ID].GetMeta().hit_anim || c[ID].charAnim.animName == "jhit" || c[ID].charAnim.animName == "jmid" || c[ID].charAnim.animName == "jfall")
			{
				c[ID].charKeys.rVec = Rand.GetRandomVec2(-1f, 1f, 0f, 1f);
			}
			c[ID].charUpdate.hp = c[ID].charUpdate.mhp;
			break;
		case 8:
			if (c[ID].charUpdate.state != CharUpdate.State.Grounded)
			{
				break;
			}
			if (targ > -1)
			{
				if (c[ID].charUpdate.loc.X > (float)Game1.gameMap.CurMap().xSize * 64f * 0.5f)
				{
					if (c[ID].charUpdate.face == 0)
					{
						if (c[targ].charUpdate.loc.X > c[ID].charUpdate.loc.X)
						{
							c[ID].charKeys.keyJump = true;
						}
						else if (Rand.CointToss(0.33f))
						{
							c[ID].charKeys.keyAttack = true;
						}
						else if (Rand.CointToss(0.5f))
						{
							c[ID].charKeys.keyStrong = true;
						}
						else
						{
							c[ID].charKeys.keyJump = true;
						}
					}
					else
					{
						c[ID].charKeys.keyLeft = true;
					}
				}
				else if (c[ID].charUpdate.face == 1)
				{
					if (c[targ].charUpdate.loc.X < c[ID].charUpdate.loc.X)
					{
						c[ID].charKeys.keyJump = true;
					}
					else if (Rand.CointToss(0.33f))
					{
						c[ID].charKeys.keyAttack = true;
					}
					else if (Rand.CointToss(0.5f))
					{
						c[ID].charKeys.keyStrong = true;
					}
					else
					{
						c[ID].charKeys.keyJump = true;
					}
				}
				else
				{
					c[ID].charKeys.keyRight = true;
				}
			}
			else
			{
				targ = FindTarg(c);
			}
			break;
		case 10:
			if (c[ID].charUpdate.state == CharUpdate.State.Grounded)
			{
				c[ID].charKeys.keyJump = true;
			}
			if (c[ID].charUpdate.state != CharUpdate.State.Airborne)
			{
				break;
			}
			if (targ > -1)
			{
				if (!(c[ID].charAnim.animName == c[ID].GetMeta().fly_anim) || !(c[ID].charUpdate.loc.Y > c[targ].charUpdate.loc.Y - 500f))
				{
					break;
				}
				if (c[ID].charUpdate.loc.X > c[targ].charUpdate.loc.X)
				{
					if (c[ID].charUpdate.face == 0)
					{
						if (Rand.CointToss(0.5f))
						{
							c[ID].charKeys.keyAttack = true;
						}
						else
						{
							c[ID].charKeys.keyStrong = true;
						}
					}
					else
					{
						c[ID].charKeys.keyLeft = true;
					}
				}
				else if (c[ID].charUpdate.face == 1)
				{
					if (Rand.CointToss(0.5f))
					{
						c[ID].charKeys.keyAttack = true;
					}
					else
					{
						c[ID].charKeys.keyStrong = true;
					}
				}
				else
				{
					c[ID].charKeys.keyRight = true;
				}
			}
			else
			{
				targ = FindTarg(c);
			}
			break;
		case 9:
			if (c[0].charUpdate.loc.X < c[ID].charUpdate.loc.X)
			{
				if (c[ID].charUpdate.face == 1)
				{
					c[ID].charKeys.keyLeft = true;
				}
				else
				{
					c[ID].charKeys.keyAttack = true;
				}
			}
			else if (c[ID].charUpdate.face == 0)
			{
				c[ID].charKeys.keyRight = true;
			}
			else
			{
				c[ID].charKeys.keyAttack = true;
			}
			if (!c[ID].charUpdate.ethereal)
			{
				if (c[ID].charKeys.keyLeft)
				{
					c[ID].charUpdate.face = 0;
				}
				if (c[ID].charKeys.keyRight)
				{
					c[ID].charUpdate.face = 1;
				}
			}
			break;
		case 0:
		case 2:
			break;
		}
	}

	private bool CheckInWay(Character[] c)
	{
		if (c[ID].team == Character.Team.GoodGuys)
		{
			return false;
		}
		if (charger)
		{
			return false;
		}
		if (targ < 0)
		{
			return false;
		}
		if (!c[targ].exists || !c[ID].exists)
		{
			return false;
		}
		float num = 0f;
		float num2 = 0f;
		if (c[ID].charUpdate.loc.X > c[targ].charUpdate.loc.X)
		{
			num = c[targ].charUpdate.loc.X;
			num2 = c[ID].charUpdate.loc.X;
		}
		else
		{
			num2 = c[targ].charUpdate.loc.X;
			num = c[ID].charUpdate.loc.X;
		}
		for (int i = 0; i < c.Length; i++)
		{
			if (c[i].exists && !c[i].GetMeta().isCrow && !c[i].GetMeta().isNeko && i != targ && i != ID)
			{
				Vector2 loc = c[i].charUpdate.loc;
				if (loc.X > num && loc.X < num2 && loc.Y <= c[ID].charUpdate.loc.Y && loc.Y > c[ID].charUpdate.loc.Y - 100f)
				{
					return true;
				}
			}
		}
		return false;
	}

	private bool WalkTo(Character[] c, Vector2 dist)
	{
		if (targ < 0)
		{
			return false;
		}
		if (!c[ID].exists)
		{
			return false;
		}
		vTarg = c[owner].charUpdate.loc;
		Vector2 vector = vTarg - c[ID].charUpdate.loc;
		if (Math.Abs(vector.X) < 150f)
		{
			c[ID].charKeys.keyWalk = true;
		}
		else if (Math.Abs(vector.X) < 180f)
		{
			c[ID].charKeys.keyJog = true;
		}
		if (vector.X > 0f)
		{
			if (!(vector.X > dist.X))
			{
				return true;
			}
			c[ID].charKeys.keyRight = true;
			if (Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(100f, -60f), ceils: false, shadow: false, ledge: true) && !Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(100f, -90f), ceils: false, shadow: false, ledge: true))
			{
				c[ID].charKeys.keyJump = true;
			}
			if (!Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(96f, 20f), ceils: false, shadow: false, ledge: true) && Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(192f, 20f), ceils: false, shadow: false, ledge: true) && !Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(192f, -20f), ceils: false, shadow: false, ledge: true))
			{
				c[ID].charKeys.keyJump = true;
			}
		}
		else
		{
			if (!(vector.X < 0f - dist.X))
			{
				return true;
			}
			c[ID].charKeys.keyLeft = true;
			if (Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(-100f, -60f), ceils: false, shadow: false, ledge: true) && !Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(-100f, -90f), ceils: false, shadow: false, ledge: true))
			{
				c[ID].charKeys.keyJump = true;
			}
			if (!Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(-96f, 20f), ceils: false, shadow: false, ledge: true) && Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(-192f, 20f), ceils: false, shadow: false, ledge: true) && !Game1.gameMap.CurMap().TestCol(c[ID].charUpdate.loc + new Vector2(-192f, -20f), ceils: false, shadow: false, ledge: true))
			{
				c[ID].charKeys.keyJump = true;
			}
		}
		return false;
	}

	private bool Chase(Character[] c, Vector2 dist)
	{
		if (targ < 0)
		{
			return false;
		}
		if (!c[targ].exists || !c[ID].exists)
		{
			return false;
		}
		Vector2 vector = c[targ].charUpdate.loc - c[ID].charUpdate.loc;
		if (vector.Y > 0f)
		{
			c[ID].charKeys.keyDown = true;
		}
		if (vector.X > 0f)
		{
			if (!(vector.X > dist.X))
			{
				return true;
			}
			c[ID].charKeys.keyRight = true;
		}
		else
		{
			if (!(vector.X < 0f - dist.X))
			{
				return true;
			}
			c[ID].charKeys.keyLeft = true;
		}
		return false;
	}

	private void Attack(Character[] c)
	{
		Attack(c, lookUp: false);
	}

	private void Attack(Character[] c, bool lookUp)
	{
		if (targ < 0 || !c[targ].exists || !c[ID].exists || CheckInWay(c))
		{
			return;
		}
		if (c[targ].charUpdate.loc.Y < c[ID].charUpdate.loc.Y + 500f)
		{
			if (c[targ].charUpdate.loc.X > c[ID].charUpdate.loc.X)
			{
				if (c[ID].charUpdate.face == 0)
				{
					c[ID].charKeys.keyRight = true;
				}
				c[ID].charKeys.keyAttack = true;
			}
			else
			{
				if (c[ID].charUpdate.face == 1)
				{
					c[ID].charKeys.keyLeft = true;
				}
				c[ID].charKeys.keyAttack = true;
			}
		}
		if (c[ID].charKeys.keyAttack && lookUp && c[targ].charUpdate.loc.Y < c[ID].charUpdate.loc.Y - 100f)
		{
			c[ID].charKeys.keyUp = true;
		}
	}

	private bool Strong(Character[] c, bool lookUp)
	{
		if (targ < 0)
		{
			return false;
		}
		if (!c[targ].exists || !c[ID].exists)
		{
			return false;
		}
		if (CheckInWay(c))
		{
			return false;
		}
		if (c[targ].charUpdate.loc.Y < c[ID].charUpdate.loc.Y + 500f)
		{
			if (c[targ].charUpdate.loc.X > c[ID].charUpdate.loc.X)
			{
				if (c[ID].charUpdate.face == 0)
				{
					c[ID].charKeys.keyRight = true;
				}
				c[ID].charKeys.keyStrong = true;
			}
			else
			{
				if (c[ID].charUpdate.face == 1)
				{
					c[ID].charKeys.keyLeft = true;
				}
				c[ID].charKeys.keyStrong = true;
			}
		}
		if (c[ID].charKeys.keyStrong)
		{
			if (lookUp && c[targ].charUpdate.loc.Y < c[ID].charUpdate.loc.Y - 100f)
			{
				c[ID].charKeys.keyUp = true;
			}
			return true;
		}
		return false;
	}

	private bool Jump(Character[] c, bool lookUp)
	{
		if (targ < 0)
		{
			return false;
		}
		if (!c[targ].exists || !c[ID].exists)
		{
			return false;
		}
		if (CheckInWay(c))
		{
			return false;
		}
		if (c[targ].charUpdate.loc.X > c[ID].charUpdate.loc.X)
		{
			if (c[ID].charUpdate.face == 0)
			{
				c[ID].charKeys.keyRight = true;
			}
			c[ID].charKeys.keyJump = true;
		}
		else
		{
			if (c[ID].charUpdate.face == 1)
			{
				c[ID].charKeys.keyLeft = true;
			}
			c[ID].charKeys.keyJump = true;
		}
		if (c[ID].charKeys.keyJump)
		{
			if (lookUp && c[targ].charUpdate.loc.Y < c[ID].charUpdate.loc.Y - 100f)
			{
				c[ID].charKeys.keyUp = true;
			}
			return true;
		}
		return false;
	}

	public void SetJob(int job, float frame, Character[] c)
	{
		this.job = job;
		this.frame = frame;
		switch (job)
		{
		case 6:
			vTarg = c[owner].charUpdate.loc + Rand.GetRandomVec2(-200f, 200f, 0f, 0f);
			if (!Game1.gameMap.CurMap().TestCol(vTarg + new Vector2(0f, 10f)))
			{
				this.job = 0;
				this.frame = Rand.GetRandomFloat(0.5f, 1f);
			}
			break;
		case 1:
		case 2:
		case 3:
		case 7:
		case 11:
			targ = FindTarg(c);
			if (targ == -1)
			{
				job = 0;
			}
			break;
		case 0:
		case 4:
		case 5:
		case 8:
		case 9:
		case 10:
			break;
		}
	}

	public int FindTarg(Character[] c)
	{
		int num = -1;
		int num2 = 0;
		for (int i = 0; i < c.Length; i++)
		{
			if (!c[i].exists || !(c[i].charUpdate.hp >= 0f) || c[i].charUpdate.inactive || i == ID || c[i].team == c[ID].team || Game1.charMeta[c[i].charMeta].isNeko || Game1.charMeta[c[i].charMeta].isCrow)
			{
				continue;
			}
			if (num == -1)
			{
				num = i;
				num2 = 1;
				continue;
			}
			num2++;
			if (Rand.CointToss(1f / (float)num2))
			{
				num = i;
			}
		}
		return num;
	}
}
