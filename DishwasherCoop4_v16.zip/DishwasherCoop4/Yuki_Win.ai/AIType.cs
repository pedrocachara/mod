using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class AIType
{
	public virtual void Update(AI ai, Character[] c)
	{
	}
}
