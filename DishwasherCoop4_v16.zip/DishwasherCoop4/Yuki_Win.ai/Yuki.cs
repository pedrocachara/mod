using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class Yuki : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.charger = true;
		if (ai.frame < 0f)
		{
			if (ai.job == 0)
			{
				ai.SetJob(11, Rand.GetRandomFloat(2f, 3f), c);
			}
			else
			{
				ai.SetJob(0, Rand.GetRandomFloat(0.25f, 1f), c);
			}
		}
	}
}
