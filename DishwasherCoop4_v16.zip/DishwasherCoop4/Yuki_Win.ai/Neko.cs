using System;
using director;
using Microsoft.Xna.Framework;
using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class Neko : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.charger = false;
		Character character = c[ai.ID];
		CharMeta meta = character.GetMeta();
		int face = character.charUpdate.face;
		Vector2 screenLoc = ScrollManager.GetScreenLoc(character.charUpdate.loc, 1f);
		if ((screenLoc.Y > ScrollManager.screenSize.Y + 40f || screenLoc.X < -10f || screenLoc.X > ScrollManager.screenSize.X + 10f) && character.charAnim.animName != meta.hover_anim && character.charAnim.animName != meta.flight_anim)
		{
			character.charAnim.SetAnim(meta.hover_anim, character.charUpdate);
			character.charUpdate.state = CharUpdate.State.Airborne;
		}
		if (character.charAnim.animName == meta.hover_anim || character.charAnim.animName == meta.fturn_anim || character.charAnim.animName == meta.flight_anim)
		{
			if (c[ai.owner].charUpdate.loc.Y - c[ai.ID].charUpdate.loc.Y > 0f && c[ai.owner].charUpdate.state == CharUpdate.State.Grounded && Game1.spriteMan.CheckVis(character.charUpdate.loc, c[ai.owner].charUpdate.loc, Game1.gameMap.CurMap()))
			{
				float num = Math.Abs(c[ai.owner].charUpdate.loc.X - c[ai.ID].charUpdate.loc.X);
				float num2 = Math.Abs(c[ai.owner].charUpdate.loc.Y - c[ai.ID].charUpdate.loc.Y);
				if (num < 100f && num2 < 100f && !Game1.gameMap.CurMap().TestCol(character.charUpdate.loc + new Vector2(-40f, -40f)) && !Game1.gameMap.CurMap().TestCol(character.charUpdate.loc + new Vector2(40f, -40f)) && !Game1.gameMap.CurMap().TestCol(character.charUpdate.loc + new Vector2(-40f, 40f)) && !Game1.gameMap.CurMap().TestCol(character.charUpdate.loc + new Vector2(40f, 40f)))
				{
					character.charAnim.SetAnim("jhit", character.charUpdate);
				}
			}
			if (character.charAnim.animName != "jhit")
			{
				Vector2 vector = c[ai.owner].charUpdate.loc + new Vector2(0f, -100f) - character.charUpdate.loc;
				if (vector.X > 800f)
				{
					vector.X = 800f;
				}
				if (vector.X < -800f)
				{
					vector.X = -800f;
				}
				if (vector.Y > 500f)
				{
					vector.Y = 500f;
				}
				if (vector.Y < -500f)
				{
					vector.Y = -500f;
				}
				if (character.charAnim.animName != meta.fturn_anim)
				{
					if (vector.X > 170f || vector.X < -170f)
					{
						if (character.charAnim.animName == meta.hover_anim)
						{
							character.charAnim.SetAnim(meta.flight_anim, character.charUpdate);
						}
					}
					else if (character.charAnim.animName == meta.flight_anim)
					{
						character.charAnim.SetAnim(meta.hover_anim, character.charUpdate);
					}
				}
				float num3 = FMan.frameTime * 90f;
				if (num3 > 1f)
				{
					num3 = 1f;
				}
				character.charUpdate.traj.X += (vector.X - character.charUpdate.traj.X) * num3;
				character.charUpdate.traj.Y += (vector.Y - character.charUpdate.traj.Y) * num3;
				if (character.charUpdate.traj.X > 0f)
				{
					character.charUpdate.face = 1;
				}
				if (character.charUpdate.traj.X < 0f)
				{
					character.charUpdate.face = 0;
				}
				if (character.charAnim.animName == meta.fturn_anim)
				{
					character.charUpdate.face = face;
				}
				else if (character.charUpdate.face != face)
				{
					character.charAnim.SetAnim(meta.fturn_anim, character.charUpdate);
				}
			}
			ai.job = 0;
			ai.frame = 0.1f;
			return;
		}
		float num4 = Math.Abs(c[ai.owner].charUpdate.loc.X - c[ai.ID].charUpdate.loc.X);
		if (num4 > 250f && ai.frame > 0.5f)
		{
			ai.frame = 0.5f;
		}
		float num5 = ai.frame + FMan.frameTime;
		if (((int)num5 != (int)ai.frame || num4 > 250f || character.charUpdate.loc.Y < c[ai.owner].charUpdate.loc.Y - 300f) && (!Game1.spriteMan.CheckVis(c[ai.ID].charUpdate.loc, c[ai.owner].charUpdate.loc, Game1.gameMap.CurMap()) || character.charUpdate.loc.Y > c[ai.owner].charUpdate.loc.Y + 200f || num4 > 250f) && c[ai.owner].charUpdate.state == CharUpdate.State.Grounded)
		{
			character.charAnim.SetAnim(meta.takeoff_anim, character.charUpdate);
			character.charUpdate.state = CharUpdate.State.Airborne;
			character.charUpdate.traj = new Vector2(((float)character.charUpdate.face - 0.5f) * 100f, -100f);
		}
		if (ai.frame < 0f)
		{
			if (c[ai.owner].charUpdate.loc.X > c[ai.ID].charUpdate.loc.X + 40f)
			{
				ai.SetJob(6, Rand.GetRandomFloat(1f, 2f), c);
				ai.frame = Rand.GetRandomFloat(0.5f, 1f);
				ai.vTarg.X = c[ai.owner].charUpdate.loc.X + 100f;
			}
			if (c[ai.owner].charUpdate.loc.X < c[ai.ID].charUpdate.loc.X - 40f)
			{
				ai.SetJob(6, Rand.GetRandomFloat(1f, 2f), c);
				ai.frame = Rand.GetRandomFloat(0.5f, 1f);
				ai.vTarg.X = c[ai.owner].charUpdate.loc.X - 100f;
			}
			ai.SetJob(6, Rand.GetRandomFloat(1f, 2f), c);
			ai.frame = Rand.GetRandomFloat(1f, 5f);
		}
	}
}
