using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class Shop : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.SetJob(0, 1f, c);
		float num = (c[0].charUpdate.loc - c[ai.ID].charUpdate.loc).LengthSquared();
		int num2 = 0;
		if (c[1].exists && (c[1].charUpdate.loc - c[ai.ID].charUpdate.loc).LengthSquared() < num)
		{
			num2 = 1;
		}
		if (Game1.hud.shopMgr.shop[1].active)
		{
			num2 = 1;
		}
		if (Game1.hud.shopMgr.shop[0].active)
		{
			num2 = 0;
		}
		bool flag = false;
		if (c[num2].charUpdate.loc.X < c[ai.ID].charUpdate.loc.X)
		{
			if (c[ai.ID].charUpdate.face == 1)
			{
				flag = true;
			}
		}
		else if (c[ai.ID].charUpdate.face == 0)
		{
			flag = true;
		}
		if (flag)
		{
			c[ai.ID].charUpdate.face = 1 - c[ai.ID].charUpdate.face;
			c[ai.ID].charAnim.SetAnim(c[ai.ID].GetMeta().turn_anim, c[ai.ID].charUpdate);
		}
	}
}
