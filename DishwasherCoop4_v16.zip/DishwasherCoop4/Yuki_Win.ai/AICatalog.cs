namespace Yuki_Win.ai;

public class AICatalog
{
	public const int AI_GUARD = 0;

	public const int AI_SWAT = 1;

	public const int AI_TANK = 2;

	public const int AI_NEKO = 3;

	public const int AI_POD = 4;

	public const int AI_CROW = 5;

	public const int AI_BERZERKER = 6;

	public const int AI_WARDEN = 7;

	public const int AI_KILLCENTER = 8;

	public const int AI_KILLMYSELF = 9;

	public const int AI_BOX = 10;

	public const int AI_MURDERFLY = 11;

	public const int AI_SHOP = 12;

	public const int AI_PUPPET = 13;

	public const int AI_YUKI = 14;

	public const int AI_NETLACKEY = 15;

	public static AIType[] aiType = new AIType[16]
	{
		new Guard(),
		new SWAT(),
		new Tank(),
		new Neko(),
		new Pod(),
		new Crow(),
		new Berzerker(),
		new Warden(),
		new KillCenter(),
		new KillMyself(),
		new Box(),
		new Murderfly(),
		new Shop(),
		new Puppet(),
		new Yuki(),
		new NetLackey()
	};
}
