using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class SWAT : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.charger = false;
		if (ai.frame < 0f)
		{
			float randomFloat = Rand.GetRandomFloat(0f, 1f);
			if (randomFloat < 0.2f)
			{
				ai.SetJob(3, Rand.GetRandomFloat(1f, 2f), c);
			}
			else if (randomFloat < 0.6f)
			{
				ai.SetJob(1, Rand.GetRandomFloat(1f, 2f), c);
			}
			else
			{
				ai.SetJob(4, Rand.GetRandomFloat(0.5f, 1f), c);
			}
		}
	}
}
