using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class Tank : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.charger = true;
		if (ai.frame < 0f)
		{
			float randomFloat = Rand.GetRandomFloat(0f, 1f);
			if (randomFloat < 0.8f)
			{
				ai.SetJob(5, Rand.GetRandomFloat(1f, 2f), c);
			}
			else
			{
				ai.SetJob(4, Rand.GetRandomFloat(0.5f, 1f), c);
			}
		}
	}
}
