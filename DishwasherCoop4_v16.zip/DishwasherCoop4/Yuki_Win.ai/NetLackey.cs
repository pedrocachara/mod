using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class NetLackey : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		ai.charger = true;
		c[ai.ID].charUpdate.hp = c[ai.ID].charUpdate.mhp;
		if (!(ai.frame < 0f))
		{
			return;
		}
		bool flag = false;
		for (int i = 0; i < c.Length; i++)
		{
			if (c[i].exists && c[i].team != c[ai.ID].team && !c[i].GetMeta().isShop && !c[i].GetMeta().isGuitar && !c[i].charUpdate.inactive)
			{
				flag = true;
			}
		}
		if (flag)
		{
			if (ai.job == 0)
			{
				ai.SetJob(7, Rand.GetRandomFloat(2f, 3f), c);
			}
			else
			{
				ai.SetJob(0, Rand.GetRandomFloat(0.25f, 1f), c);
			}
		}
		else if (ai.job == 0)
		{
			ai.SetJob(12, Rand.GetRandomFloat(2f, 3f), c);
		}
		else
		{
			ai.SetJob(0, Rand.GetRandomFloat(0.25f, 1f), c);
		}
	}
}
