using System;
using Microsoft.Xna.Framework;
using Yuki_Win.chars;

namespace Yuki_Win.ai;

public class Crow : AIType
{
	public override void Update(AI ai, Character[] c)
	{
		Character character = c[ai.ID];
		CharMeta meta = character.GetMeta();
		ai.charger = false;
		Vector2 vector = c[ai.owner].charUpdate.loc - c[ai.ID].charUpdate.loc;
		if ((vector.X > 150f || vector.X < -150f || vector.Y > 150f || vector.Y < -150f) && character.charUpdate.state == CharUpdate.State.Grounded && character.charAnim.animName == meta.idle_anim)
		{
			character.charAnim.SetAnim(meta.takeoff_anim, character.charUpdate);
			character.charUpdate.state = CharUpdate.State.Airborne;
			character.charUpdate.traj = new Vector2(((float)character.charUpdate.face - 0.5f) * 100f, -100f);
		}
		int face = character.charUpdate.face;
		if (c[ai.owner].charUpdate.headTop.X > 0f)
		{
			ai.frame = 2f;
		}
		else
		{
			ai.frame = 0f;
		}
		if (ai.mount)
		{
			if (c[ai.owner].charUpdate.face != character.charUpdate.face)
			{
				character.charUpdate.face = 1 - character.charUpdate.face;
				character.charAnim.SetAnim(meta.turn_anim, character.charUpdate);
			}
		}
		else if (character.charUpdate.state == CharUpdate.State.Airborne)
		{
			if (character.charAnim.animName == meta.fly_anim)
			{
				character.charAnim.SetAnim(meta.hover_anim, character.charUpdate);
			}
			if (character.charAnim.animName == meta.fturn_anim || character.charAnim.animName == meta.hover_anim || character.charAnim.animName == meta.flight_anim || character.charAnim.animName == meta.launch_anim)
			{
				Vector2 vector2 = c[ai.owner].charUpdate.loc + new Vector2(0f, -100f) - character.charUpdate.loc;
				if (vector2.X > -100f && vector2.X < 100f && vector2.Y < 100f)
				{
					if (ai.frame > 1f && c[ai.owner].charUpdate.headTop.X > 0f)
					{
						Vector2 vector3 = c[ai.owner].charUpdate.headTop - character.charUpdate.loc;
						float num = Math.Abs(vector3.X) * -0.25f;
						num += 10f;
						if (num > 0f)
						{
							num = 0f;
						}
						vector2 = c[ai.owner].charUpdate.headTop + new Vector2(0f, num) - character.charUpdate.loc;
						if (vector3.X > -100f && vector3.X < 100f)
						{
							if (vector2.Y < 0f && vector2.Y > -50f)
							{
								vector2.Y = -50f;
							}
							if (vector2.Y > 0f && vector2.Y < 30f)
							{
								vector2.Y = 30f;
							}
							if (!(vector2.Y > Math.Abs(vector2.X)))
							{
								if (vector2.X < 0f && vector2.X > -30f)
								{
									vector2.X = -30f;
								}
								if (vector2.X > 0f && vector2.X < 30f)
								{
									vector2.X = 30f;
								}
							}
						}
						if (vector3.LengthSquared() < 100f)
						{
							ai.mount = true;
							character.charAnim.SetAnim(meta.land_anim, character.charUpdate);
							character.charUpdate.loc = c[ai.owner].charUpdate.headTop;
						}
					}
					else
					{
						float num2 = vector2.X;
						if (vector2.X < 0f)
						{
							num2 = 0f - num2;
						}
						num2 = (100f - num2) * 2f;
						if (num2 > 100f)
						{
							num2 = 100f;
						}
						vector2 = c[ai.owner].charUpdate.loc + new Vector2(0f, -100f + num2) - character.charUpdate.loc;
					}
				}
				if (!ai.mount)
				{
					if (vector2.X > 800f)
					{
						vector2.X = 800f;
					}
					if (vector2.X < -800f)
					{
						vector2.X = -800f;
					}
					if (vector2.Y > 500f)
					{
						vector2.Y = 500f;
					}
					if (vector2.Y < -500f)
					{
						vector2.Y = -500f;
					}
					if (character.charAnim.animName != meta.fturn_anim)
					{
						if (vector2.X > 170f || vector2.X < -170f)
						{
							if (character.charAnim.animName == meta.hover_anim)
							{
								character.charAnim.SetAnim(meta.launch_anim, character.charUpdate);
							}
						}
						else if (character.charAnim.animName == meta.flight_anim)
						{
							character.charAnim.SetAnim(meta.hover_anim, character.charUpdate);
						}
					}
					float num3 = FMan.frameTime * 90f;
					if (num3 > 1f)
					{
						num3 = 1f;
					}
					character.charUpdate.traj.X += (vector2.X - character.charUpdate.traj.X) * num3;
					character.charUpdate.traj.Y += (vector2.Y - character.charUpdate.traj.Y) * num3;
					if (character.charUpdate.traj.X > 0f)
					{
						character.charUpdate.face = 1;
					}
					if (character.charUpdate.traj.X < 0f)
					{
						character.charUpdate.face = 0;
					}
					if (character.charAnim.animName == meta.fturn_anim)
					{
						character.charUpdate.face = face;
					}
					else if (character.charUpdate.face != face)
					{
						character.charAnim.SetAnim(meta.fturn_anim, character.charUpdate);
					}
				}
			}
		}
		float num4 = ai.frame + FMan.frameTime;
		if (((int)num4 != (int)ai.frame || Math.Abs(vector.X) > 250f) && !Game1.spriteMan.CheckVis(character.charUpdate.loc, c[ai.owner].charUpdate.loc, Game1.gameMap.CurMap()))
		{
			Vector2 vector4 = c[ai.owner].charUpdate.loc + Rand.GetRandomVec2(-50f, 50f, -100f, -50f);
			if (!Game1.gameMap.CurMap().TestCol(vector4) && !Game1.gameMap.CurMap().TestCol(vector4 + new Vector2(-30f, 0f)) && !Game1.gameMap.CurMap().TestCol(vector4 + new Vector2(30f, 0f)) && !Game1.gameMap.CurMap().TestCol(vector4 + new Vector2(-30f, -80f)) && !Game1.gameMap.CurMap().TestCol(vector4 + new Vector2(30f, -80f)))
			{
				Vector2 vector5 = vector4 - c[ai.ID].charUpdate.loc;
				vector5.Normalize();
				for (int i = 0; i < 5; i++)
				{
					Game1.spriteMan.AddSprite(32, vector4, Rand.GetRandomVec2(-20f, 20f, -20f, 20f) + vector5 * Rand.GetRandomFloat(1f, 250f), Rand.GetRandomFloat(0f, 1f), 0, ai.ID);
					Game1.spriteMan.AddSprite(33, c[ai.ID].charUpdate.loc, Rand.GetRandomVec2(-20f, 20f, -20f, 20f) + vector5 * Rand.GetRandomFloat(1f, 500f), Rand.GetRandomFloat(0f, 1f), 0, ai.ID);
				}
				c[ai.ID].charUpdate.loc = vector4;
				c[ai.ID].charAnim.SetAnim(c[ai.ID].GetMeta().hover_anim, c[ai.ID].charUpdate);
				c[ai.ID].charUpdate.state = CharUpdate.State.Airborne;
			}
		}
		ai.job = 0;
		ai.frame = 1f;
	}
}
