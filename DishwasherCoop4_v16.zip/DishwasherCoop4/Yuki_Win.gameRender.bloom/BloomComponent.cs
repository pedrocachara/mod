using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.gameRender.bloom;

public class BloomComponent
{
	public enum IntermediateBuffer
	{
		PreBloom,
		BlurredHorizontally,
		BlurredBothWays,
		FinalResult
	}

	private GraphicsDevice dev;

	private Effect bloomExtractEffect;

	private Effect bloomCombineEffect;

	private Effect redBloomCombineEffect;

	private Effect gaussianBlurEffect;

	private RenderTarget2D renderTarget1;

	private RenderTarget2D renderTarget2;

	private BloomSettings settings = BloomSettings.PresetSettings[0];

	private IntermediateBuffer showBuffer = IntermediateBuffer.FinalResult;

	public BloomSettings Settings
	{
		get
		{
			return settings;
		}
		set
		{
			settings = value;
		}
	}

	public IntermediateBuffer ShowBuffer
	{
		get
		{
			return showBuffer;
		}
		set
		{
			showBuffer = value;
		}
	}

	public BloomComponent(GraphicsDevice dev, ContentManager Content)
	{
		this.dev = dev;
		bloomExtractEffect = Content.Load<Effect>("fx/bloom/BloomExtract");
		bloomCombineEffect = Content.Load<Effect>("fx/bloom/BloomCombine");
		redBloomCombineEffect = Content.Load<Effect>("fx/bloom/RedBloomCombine");
		gaussianBlurEffect = Content.Load<Effect>("fx/bloom/GaussianBlur");
		CreateTargs(dev);
	}

	public void CreateTargs(GraphicsDevice dev)
	{
		renderTarget1 = new RenderTarget2D(dev, (int)ScrollManager.screenSize.X / 2, (int)ScrollManager.screenSize.Y / 2);
		renderTarget2 = new RenderTarget2D(dev, (int)ScrollManager.screenSize.X / 2, (int)ScrollManager.screenSize.Y / 2);
	}

	public void Draw(RenderTarget2D goalTarg, RenderTarget2D sceneRenderTarget)
	{
		dev.SamplerStates[1] = SamplerState.LinearClamp;
		Settings = BloomSettings.PresetSettings[3];
		bloomExtractEffect.Parameters["BloomThreshold"].SetValue(0.1f);
		DrawFullscreenQuad(sceneRenderTarget, renderTarget1, bloomExtractEffect, IntermediateBuffer.PreBloom);
		SetBlurEffectParameters(1f / (float)renderTarget1.Width, 0f);
		DrawFullscreenQuad(renderTarget1, renderTarget2, gaussianBlurEffect, IntermediateBuffer.BlurredHorizontally);
		SetBlurEffectParameters(0f, 1f / (float)renderTarget1.Height);
		DrawFullscreenQuad(renderTarget2, renderTarget1, gaussianBlurEffect, IntermediateBuffer.BlurredBothWays);
		dev.SetRenderTarget(goalTarg);
		EffectParameterCollection parameters = bloomCombineEffect.Parameters;
		parameters["BloomIntensity"].SetValue(GameRender.bloomRender.alpha * 1.2f);
		parameters["BaseIntensity"].SetValue(1.1f - GameRender.redVal * 1.2f);
		parameters["BloomSaturation"].SetValue(GameRender.bloomRender.sat * 1.5f);
		parameters["BaseSaturation"].SetValue(1f);
		parameters["gb"].SetValue(1f - GameRender.redVal);
		dev.Textures[1] = sceneRenderTarget;
		Viewport viewport = dev.Viewport;
		DrawFullscreenQuad(renderTarget1, viewport.Width, viewport.Height, bloomCombineEffect, IntermediateBuffer.FinalResult);
	}

	private void DrawFullscreenQuad(Texture2D texture, RenderTarget2D renderTarget, Effect effect, IntermediateBuffer currentBuffer)
	{
		dev.SetRenderTarget(renderTarget);
		DrawFullscreenQuad(texture, renderTarget.Width, renderTarget.Height, effect, currentBuffer);
	}

	private void DrawFullscreenQuad(Texture2D texture, int width, int height, Effect effect, IntermediateBuffer currentBuffer)
	{
		if (showBuffer < currentBuffer)
		{
			effect = null;
		}
		SpriteTools.sprite.Begin(SpriteSortMode.Deferred, BlendState.Opaque, null, null, null, effect);
		SpriteTools.sprite.Draw(texture, new Rectangle(0, 0, width, height), Color.White);
		SpriteTools.sprite.End();
	}

	private void SetBlurEffectParameters(float dx, float dy)
	{
		EffectParameter effectParameter = gaussianBlurEffect.Parameters["SampleWeights"];
		EffectParameter effectParameter2 = gaussianBlurEffect.Parameters["SampleOffsets"];
		int count = effectParameter.Elements.Count;
		float[] array = new float[count];
		Vector2[] array2 = new Vector2[count];
		array[0] = ComputeGaussian(0f);
		ref Vector2 reference = ref array2[0];
		reference = new Vector2(0f);
		float num = array[0];
		for (int i = 0; i < count / 2; i++)
		{
			num += (array[i * 2 + 2] = (array[i * 2 + 1] = ComputeGaussian(i + 1))) * 2f;
			float num2 = (float)(i * 2) + 1.5f;
			Vector2 vector = new Vector2(dx, dy) * num2;
			array2[i * 2 + 1] = vector;
			ref Vector2 reference2 = ref array2[i * 2 + 2];
			reference2 = -vector;
		}
		for (int j = 0; j < array.Length; j++)
		{
			array[j] /= num;
		}
		effectParameter.SetValue(array);
		effectParameter2.SetValue(array2);
	}

	private float ComputeGaussian(float n)
	{
		float blurAmount = Settings.BlurAmount;
		return (float)(1.0 / Math.Sqrt(Math.PI * 2.0 * (double)blurAmount) * Math.Exp((0f - n * n) / (2f * blurAmount * blurAmount)));
	}
}
