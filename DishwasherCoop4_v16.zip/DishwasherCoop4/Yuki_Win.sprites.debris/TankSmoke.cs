using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.debris;

internal class TankSmoke : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(1f, 2f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 8);
		p.alpha = false;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		base.Update(p, spriteMan);
		if (frame > 1f && p.frame <= 1f)
		{
			p.traj /= 2f;
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(704 + p.flags % 2, 64, 64, 64);
		if (p.flags < 6)
		{
			value = new Rectangle(384 + p.flags, 320, 64, 64);
		}
		float num = p.frame;
		if (num > 0.5f)
		{
			num = 0.5f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, new Color(0.7f, 0.7f, 0.7f, num), p.frame * 0.1f, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
	}
}
