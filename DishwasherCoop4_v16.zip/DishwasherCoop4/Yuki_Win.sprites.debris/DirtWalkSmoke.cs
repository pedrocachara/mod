using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.debris;

internal class DirtWalkSmoke : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.4f, 0.8f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 8);
		p.alpha = false;
		p.rDir = Rand.GetRandomFloat(-1f, 1f);
		p.r = Rand.GetRandomFloat(0f, 0.4f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += p.rDir * FMan.frameTime;
		p.size += FMan.frameTime * 0.1f;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(576 + p.flags % 4, 192, 64, 64);
		if (p.flags < 6)
		{
			value = new Rectangle(384 + p.flags, 320, 64, 64);
		}
		_ = p.size;
		_ = p.rotation;
		float num = p.frame;
		if (num > 0.3f)
		{
			num = 0.3f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, new Color(p.r, p.r, p.r, num), p.rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
	}
}
