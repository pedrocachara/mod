using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.debris;

internal class GlassSmoke : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(0.4f, 0.8f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.size = size;
		p.flags = Rand.GetRandomInt(0, 8);
		p.alpha = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(704 + p.flags % 2, 64, 64, 64);
		if (p.flags < 6)
		{
			value = new Rectangle(384 + p.flags, 320, 64, 64);
		}
		_ = p.size;
		if (p.flags >= 6)
		{
			_ = p.frame;
			_ = p.rotation;
		}
		else
		{
			_ = p.rotation;
		}
		float num = p.frame;
		if (num > 0.3f)
		{
			num = 0.3f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, new Color(1f, 1f, 1f, num), p.frame * -4f + p.rotation, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * 0.5f * p.size - (1f - p.frame), SpriteEffects.None, 1f);
	}
}
