using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.debris;

internal class Glass : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = Rand.GetRandomFloat(1f, 2f);
		p.alpha = true;
		p.wallFree = false;
		p.rDir = Rand.GetRandomFloat(-2f, 2f);
		p.size = Rand.GetRandomFloat(0.5f, 1.5f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.frameTime;
		p.rotation += p.rDir * FMan.frameTime;
		spriteMan.TrimSprite(p);
		p.traj.Y += FMan.frameTime * 800f;
		Vector2 loc = p.loc;
		if (!p.wallFree)
		{
			if (!Game1.gameMap.CurMap().TestCol(p.loc))
			{
				p.wallFree = true;
			}
		}
		else
		{
			for (int i = 0; i < 2; i++)
			{
				if (i == 0)
				{
					p.loc.X += p.traj.X * FMan.frameTime;
				}
				else
				{
					p.loc.Y += p.traj.Y * FMan.frameTime;
				}
				if (Game1.gameMap.CurMap().TestCol(p.loc))
				{
					p.loc = loc;
					if (i == 0)
					{
						p.traj.X = p.traj.X * -0.9f;
					}
					else
					{
						p.traj.Y = p.traj.Y * -0.9f;
					}
				}
			}
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Rectangle value = new Rectangle(512, 560, 16, 16);
		float rotation = p.rotation;
		float scale = ScrollManager.cannedDepth[0] * p.size;
		Vector2 origin = new Vector2(8f, 8f);
		float num = p.frame;
		if (num > 0.4f)
		{
			num = 0.4f;
		}
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), value, new Color(1f, 1f, 1f, num), rotation, origin, scale, SpriteEffects.None, 1f);
		if (Rand.CointToss(0.01f))
		{
			PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(p.loc, 1f), 1f, 1f, 1f, Rand.GetRandomFloat(0.5f, 1f), Rand.GetRandomFloat(0.05f, 0.15f), 1f);
		}
	}
}
