using director;
using Microsoft.Xna.Framework;
using Yuki_Win.achievements.cheevos;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.director;
using Yuki_Win.levels;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.solo;

namespace Yuki_Win.chars.update;

public class CharInput
{
	public void InputToAnimation(Map map, Character c, Character[] cArray, CharUpdate cUp)
	{
		CharAnim charAnim = c.charAnim;
		CharKeys charKeys = c.charKeys;
		CharMeta meta = c.GetMeta();
		int face = cUp.face;
		if (Game1.IsPlayerChar(cUp.ID) && Game1.hud.shopMgr.shop[cUp.ID].alpha > 0f)
		{
			return;
		}
		if (cUp.secondaryFrame > 0f)
		{
			cUp.secondaryFrame -= FMan.frameTime;
		}
		if (c.charAnim.animName == meta.idle_anim || c.charAnim.animName == meta.idlet_anim || c.charAnim.animName == meta.run_anim || c.charAnim.animName == meta.runstart_anim || c.charAnim.animName == meta.runend_anim || c.charAnim.animName == meta.altRunStart_anim || c.charAnim.animName == meta.jog_anim || c.charAnim.animName == meta.walk_anim || c.charAnim.animName == meta.turn_anim || c.charAnim.animName == meta.altturn_anim || (cUp.state == CharUpdate.State.Grounded && charAnim.canCancel))
		{
			cUp.ClearGrabs();
			if (meta.isstopbeforeattack && (charKeys.keyJump || charKeys.keyAttack || charKeys.keyStrong) && (c.charAnim.animName == meta.run_anim || c.charAnim.animName == meta.runstart_anim))
			{
				c.charAnim.SetAnim(meta.runend_anim, cUp);
			}
			if ((c.team != Character.Team.BadGuys || !(c.charAnim.animName == meta.turn_anim)) && (!meta.isstopbeforeattack || !(c.charAnim.animName == meta.runend_anim)))
			{
				if (charKeys.keyJump && !meta.alwaysRight)
				{
					UpdateFace(charKeys, cUp);
					charAnim.SetAnim(meta.jump_anim, cUp);
				}
				if (charKeys.keyAttack)
				{
					EnemyFace(c, cArray);
					UpdateFace(charKeys, cUp);
					if (charAnim.CheckAnim(meta.exer_anim) > -1)
					{
						if (cUp.charGrab.CheckExeKillable(cUp, cArray))
						{
							charAnim.SetAnim(meta.exer_anim, cUp);
							cUp.etherealFrame = 1f;
						}
						else
						{
							charAnim.SetAnim(meta.attack_anim, cUp);
						}
					}
					else
					{
						charAnim.SetAnim(meta.attack_anim, cUp);
					}
					Game1.practice.SetKey(0, c.ID);
				}
				if (charKeys.keySec)
				{
					UpdateFace(charKeys, cUp);
					cUp.CheckSec(charAnim, charKeys, overRide: false);
				}
				else if (charKeys.keyStrong)
				{
					EnemyFace(c, cArray);
					UpdateFace(charKeys, cUp);
					if (meta.special == 3 || meta.special == 4)
					{
						charAnim.SetAnim(meta.strong_anim, cUp);
					}
					else
					{
						cUp.lastSpecial = 1;
						charAnim.smokeMachineLife = 10f;
						if (charAnim.CheckAnim(meta.strong_kill_anim) > -1 && charAnim.CheckAnim(meta.strong_kill2_anim) > -1)
						{
							if (cUp.charGrab.CheckSawKillable(cUp, cArray))
							{
								if (Rand.CointToss(0.5f))
								{
									charAnim.SetAnim(meta.strong_kill_anim, cUp);
								}
								else
								{
									charAnim.SetAnim(meta.strong_kill2_anim, cUp);
								}
							}
							else
							{
								charAnim.SetAnim(meta.strong_anim, cUp);
							}
						}
						else
						{
							charAnim.SetAnim(meta.strong_anim, cUp);
						}
					}
					Game1.practice.SetKey(1, c.ID);
				}
				else if (charKeys.keyGrab)
				{
					EnemyFace(c, cArray);
					UpdateFace(charKeys, cUp);
					charAnim.SetAnim(meta.grab_anim, cUp);
					Game1.practice.SetKey(3, c.ID);
					for (int i = 0; i < Game1.character.Length; i++)
					{
						if (!Game1.character[i].exists)
						{
							continue;
						}
						if (Game1.character[i].GetMeta().isShop)
						{
							Vector2 vector = cUp.loc + new Vector2(((float)cUp.face - 0.5f) * 100f, -70f);
							if (vector.X > Game1.character[i].charUpdate.loc.X - 70f && vector.X < Game1.character[i].charUpdate.loc.X + 70f && vector.Y > Game1.character[i].charUpdate.loc.Y - 90f && vector.Y < Game1.character[i].charUpdate.loc.Y + 5f)
							{
								Game1.hud.shopMgr.InitShop(cUp.ID);
								charAnim.SetAnim(meta.idle_anim, cUp);
								charKeys.keyRight = false;
								charKeys.keyLeft = false;
							}
						}
						if (((!c.GetMeta().isYuki || !Game1.character[i].GetMeta().isViolin) && (!c.GetMeta().isDish || !Game1.character[i].GetMeta().isGuitar)) || Game1.levelMgr.guitarEmpty)
						{
							continue;
						}
						Vector2 vector2 = cUp.loc + new Vector2(((float)cUp.face - 0.5f) * 100f, -70f);
						if (!(vector2.X > Game1.character[i].charUpdate.loc.X - 70f) || !(vector2.X < Game1.character[i].charUpdate.loc.X + 70f) || !(vector2.Y > Game1.character[i].charUpdate.loc.Y - 90f) || !(vector2.Y < Game1.character[i].charUpdate.loc.Y + 5f))
						{
							continue;
						}
						if (Game1.netSession.IsClient() && c.ID == 1)
						{
							Game1.netSession.netGame.SendGuitarRequest(Game1.netSession.session);
						}
						else if ((Game1.netSession.IsHost() && c.ID == 0) || (!Game1.netSession.IsHost() && !Game1.netSession.IsClient()))
						{
							cUp.loc = Game1.character[i].charUpdate.loc;
							if (c.GetMeta().isDish)
							{
								cUp.face = 1;
							}
							else
							{
								cUp.face = 0;
							}
							Game1.soloMgr.Init(SoloMgr.NameFromString(Game1.character[i].tag));
							if (Game1.levelMgr.currentTrack == 2)
							{
								for (int mate = 0; mate < 4; mate++)
								{
									if (mate != c.ID && Game1.IsPlayerChar(mate))
									{
										Game1.character[mate].charUpdate.charInput.StartGuitar(mate);
									}
							}
							}
							if (Game1.netSession.IsHost())
							{
								Game1.netSession.netGame.SendGuitar(Game1.netSession.session, Game1.character[i].tag);
							}
							charKeys.keyRight = false;
							charKeys.keyLeft = false;
						}
					}
				}
				if ((charKeys.keyAttackMagic || charKeys.keyJumpMagic || charKeys.keyGrabMagic || charKeys.keyStrongMagic) && cUp.mp > 0)
				{
					Game1.practice.Mod(10, c.ID);
					charAnim.SetAnim("magic", cUp);
					cUp.magic = 0.1f;
					cUp.ethereal = true;
					cUp.magicOut = 0f;
					Sound.PlaySnd(Sound.Category.FX, "gitmagic");
					if (charKeys.keyAttackMagic)
					{
						cUp.magicType = CharUpdate.Magictype.Attack;
					}
					if (charKeys.keyStrongMagic)
					{
						cUp.magicType = CharUpdate.Magictype.Strong;
					}
					if (charKeys.keyJumpMagic)
					{
						cUp.magicType = CharUpdate.Magictype.Jump;
					}
					if (charKeys.keyGrabMagic)
					{
						cUp.magicType = CharUpdate.Magictype.Grab;
					}
				}
				if (cUp.face != face && meta.isGiant)
				{
					c.charAnim.SetAnim(meta.turn_anim, cUp);
				}
			}
			if (Game1.gameMap.chairScreamMode && cUp.loc.X > (float)Game1.gameMap.scriptTrigX)
			{
				Sound.PlaySnd(Sound.Category.FX, "liegit");
				charAnim.SetAnim("chairscream", cUp);
				Game1.gameMap.CrazyTransitionInFrame = 3f;
			}
			if (Game1.gameMap.bedMode && charKeys.keyUp && cUp.loc.X > (float)Game1.gameMap.scriptTrigX - 64f && cUp.loc.X < (float)Game1.gameMap.scriptTrigX + 64f)
			{
				if (cUp.loc.X < (float)Game1.gameMap.scriptTrigX - 6f)
				{
					cUp.traj.X = 300f;
				}
				else if (cUp.loc.X > (float)Game1.gameMap.scriptTrigX + 6f)
				{
					cUp.traj.X = -300f;
				}
				else
				{
					cUp.traj.X = 0f;
					if (cUp.face != 0)
					{
						charAnim.SetAnim(meta.turn_anim, cUp);
						cUp.face = 0;
					}
					if (charAnim.animName == meta.idle_anim)
					{
						charAnim.SetAnim("lie", cUp);
						Game1.gameMap.CrazyTransitionInFrame = 3f;
						Sound.PlaySnd(Sound.Category.FX, "liegit");
					}
				}
			}
			if (Game1.gameMap.dentistChairMode && charKeys.keyUp && cUp.loc.X > (float)Game1.gameMap.scriptTrigX - 64f && cUp.loc.X < (float)Game1.gameMap.scriptTrigX + 64f)
			{
				if (cUp.loc.X < (float)Game1.gameMap.scriptTrigX - 6f)
				{
					cUp.traj.X = 300f;
				}
				else if (cUp.loc.X > (float)Game1.gameMap.scriptTrigX + 6f)
				{
					cUp.traj.X = -300f;
				}
				else
				{
					cUp.traj.X = 0f;
					if (cUp.face != 1)
					{
						charAnim.SetAnim(meta.turn_anim, cUp);
						cUp.face = 1;
					}
					if (charAnim.animName == meta.idle_anim)
					{
						charAnim.SetAnim("armsit", cUp);
						Sound.PlaySnd(Sound.Category.FX, "liegit");
						if (Game1.gameMap.zapchairmode)
						{
							Game1.gameMap.CrazyTransitionInFrame = 2f;
						}
					}
				}
			}
		}
		if (cUp.charGrab.grabbedByChar > -1 && cUp.state == CharUpdate.State.Airborne)
		{
			Character character = cArray[cUp.charGrab.grabbedByChar];
			if (character.charKeys.keyAttack && character.charUpdate.canGrabCancel)
			{
				cUp.charGrab.grabAttack = true;
			}
			if (character.charKeys.keyGrab && character.charUpdate.canGrabCancel)
			{
				if (cUp.hp < cUp.mhp / 4f)
				{
					cUp.charGrab.grabChop = true;
				}
				if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.NomNom || Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.CrackingSkull))
				{
					cUp.charGrab.grabChop = false;
				}
			}
			if (cUp.charGrab.grabAttack && cUp.traj.Y > -100f)
			{
				cUp.charGrab.grabAttack = false;
				character.charUpdate.loc = cUp.loc;
				character.charAnim.SetAnim(character.GetMeta().fatk_anim, character.charUpdate, overRide: true);
				character.charUpdate.state = CharUpdate.State.Airborne;
				character.charUpdate.airJuggleFrame = 0.5f;
				cUp.airJuggleFrame = 0.5f;
				if (cUp.face == 0)
				{
					character.charUpdate.airJuggleVec = cUp.loc + new Vector2(-40f, -30f);
					cUp.airJuggleVec = cUp.loc + new Vector2(40f, -30f);
				}
				else
				{
					character.charUpdate.airJuggleVec = cUp.loc + new Vector2(40f, -30f);
					cUp.airJuggleVec = cUp.loc + new Vector2(-40f, -30f);
				}
				charAnim.SetAnim("jmid", cUp);
				character.charUpdate.charGrab.grabbing = false;
				cUp.charGrab.grabbedByChar = -1;
				ScrollManager.zoom += 0.1f;
				QuakeManager.SetQuake(0.2f);
				QuakeManager.SetBright(0.2f);
				Sound.PlaySnd(Sound.Category.FX, "hit");
				character.charUpdate.canGrabCancel = false;
			}
			if (cUp.charGrab.grabChop && cUp.traj.Y > -100f)
			{
				cUp.charGrab.grabChop = false;
				bool flag = false;
				if (charAnim.animName == meta.jkatgrabbed_anim)
				{
					if (charAnim.CheckAnim("katchop") > -1)
					{
						charAnim.SetAnim("katchop", cUp);
					}
					flag = true;
					Game1.practice.SetKey(3, cUp.charGrab.grabbedByChar);
				}
				else if (charAnim.animName == meta.jkamgrabbed_anim)
				{
					if (charAnim.CheckAnim("kamchop") > -1)
					{
						charAnim.SetAnim("kamchop", cUp);
					}
					flag = true;
					Game1.practice.SetKey(3, cUp.charGrab.grabbedByChar);
				}
				else if (charAnim.animName == meta.dishgrabbed_anim || charAnim.animName == meta.dishhammergrabbed_anim || charAnim.animName == meta.dishhold2grabbed_anim || charAnim.animName == meta.dishbladegrabbed_anim || charAnim.animName == meta.dishkamagrabbed_anim || charAnim.animName == meta.dishsawgrabbed_anim)
				{
					if (charAnim.CheckAnim("izuna") > -1)
					{
						charAnim.SetAnim("izuna", cUp);
					}
					flag = true;
					Game1.practice.SetKey(3, cUp.charGrab.grabbedByChar);
				}
				if (flag)
				{
					charAnim.frame = 1f;
					Game1.killManager.DoKill(c.ID);
					QuakeManager.SetBright(0.2f);
					Sound.PlaySnd(Sound.Category.FX, "hit");
					Sound.PlaySnd(Sound.Category.FX, "crunch");
				}
			}
		}
		else
		{
			cUp.charGrab.grabAttack = false;
		}
		if (c.charAnim.animName == meta.idle_anim || c.charAnim.animName == meta.idlet_anim)
		{
			bool altRunStart = cUp.altRunStart;
			_ = charAnim.animName == meta.idle_anim;
			if (charKeys.keyRight)
			{
				cUp.face = 1;
				if (cUp.runStartAnim != null)
				{
					c.charAnim.SetAnim(cUp.runStartAnim, cUp);
				}
				else if (charKeys.keyWalk)
				{
					charAnim.SetAnim(meta.walk_anim, cUp);
				}
				else if (charKeys.keyJog)
				{
					charAnim.SetAnim(meta.jog_anim, cUp);
				}
				else if (charAnim.CheckAnim(meta.runstart_anim) > -1)
				{
					charAnim.SetAnim(meta.runstart_anim, cUp);
				}
				else
				{
					charAnim.SetAnim(meta.run_anim, cUp);
				}
			}
			if (charKeys.keyLeft && !meta.alwaysRight)
			{
				cUp.face = 0;
				if (cUp.runStartAnim != null)
				{
					c.charAnim.SetAnim(cUp.runStartAnim, cUp);
				}
				else if (charKeys.keyWalk)
				{
					charAnim.SetAnim(meta.walk_anim, cUp);
				}
				else if (charKeys.keyJog)
				{
					charAnim.SetAnim(meta.jog_anim, cUp);
				}
				else if (charAnim.CheckAnim(meta.runstart_anim) > -1)
				{
					charAnim.SetAnim(meta.runstart_anim, cUp);
				}
				else
				{
					charAnim.SetAnim(meta.run_anim, cUp);
				}
			}
			if (face != cUp.face)
			{
				cUp.altRunStart = altRunStart;
				charAnim.SetAnim(meta.turn_anim, cUp, overRide: true);
			}
			if (cUp.hp < 0f)
			{
				charAnim.SetAnim(meta.dying_anim, cUp);
			}
			if (cUp.isSuicidal && cUp.hp < cUp.mhp / 2f)
			{
				charAnim.SetAnim(meta.suicide_anim, cUp, overRide: true);
				cUp.isSuicidal = false;
			}
		}
		else if (c.charAnim.animName == "gun" || c.charAnim.animName == "gunu" || c.charAnim.animName == "gunuu")
		{
			if (charKeys.keyShotty)
			{
				DoShotty(charKeys, charAnim, cUp, c);
				Game1.practice.SetKey(1, c.ID);
			}
			else if (charKeys.keyReload)
			{
				Reload(charAnim, cUp);
				Game1.practice.SetKey(3, c.ID);
			}
		}
		else if (c.charAnim.animName == "fgun" || c.charAnim.animName == "fgunu" || c.charAnim.animName == "fgunuu" || c.charAnim.animName == "fgund" || c.charAnim.animName == "fgundd")
		{
			if (charKeys.keyShotty)
			{
				DoFShotty(charKeys, charAnim, cUp, c);
				Game1.practice.SetKey(1, c.ID);
			}
			else if (charKeys.keyReload)
			{
				Reload(charAnim, cUp);
				Game1.practice.SetKey(3, c.ID);
			}
		}
		else if (c.charAnim.animName == meta.jkatgrabbed_anim)
		{
			if (!cUp.floating)
			{
			}
		}
		else if (c.charAnim.animName == meta.dying_anim)
		{
			cUp.hp += FMan.frameTime * 0.1f;
			if (cUp.hp > 0f)
			{
				cUp.hp = 5f;
				charAnim.SetAnim(meta.idle_anim, cUp);
			}
		}
		else if (c.charAnim.animName == meta.run_anim || c.charAnim.animName == meta.runstart_anim || c.charAnim.animName == meta.runend_anim || c.charAnim.animName == meta.altRunStart_anim || c.charAnim.animName == meta.jog_anim || c.charAnim.animName == meta.turn_anim || c.charAnim.animName == meta.altturn_anim || c.charAnim.animName == meta.walk_anim)
		{
			if (charKeys.keyRight)
			{
				if (charKeys.keyWalk)
				{
					cUp.traj.X = meta.speed / 4f;
					if (c.charAnim.animName != meta.turn_anim && c.charAnim.animName != meta.altRunStart_anim && c.charAnim.animName != meta.altturn_anim)
					{
						c.charAnim.SetAnim(meta.walk_anim, cUp);
					}
				}
				else if (charKeys.keyJog)
				{
					cUp.traj.X = meta.speed / 2f;
					if (c.charAnim.animName != meta.turn_anim && c.charAnim.animName != meta.altRunStart_anim && c.charAnim.animName != meta.altturn_anim)
					{
						c.charAnim.SetAnim(meta.jog_anim, cUp);
					}
				}
				else if (c.charAnim.animName == meta.turn_anim)
				{
					if (meta.isGiant)
					{
						cUp.traj.X = meta.speed / 10f;
					}
					else
					{
						cUp.traj.X = meta.speed / 3f;
					}
				}
				else if (!meta.isstopbeforeattack || !(c.charAnim.animName == meta.runend_anim))
				{
					if (c.charAnim.animName != meta.runstart_anim && c.charAnim.animName != meta.run_anim && c.charAnim.animName != meta.turn_anim && c.charAnim.animName != meta.altturn_anim && c.charAnim.animName != meta.altRunStart_anim)
					{
						c.charAnim.SetAnim(meta.runstart_anim, cUp);
					}
					cUp.traj.X = meta.speed;
				}
				cUp.face = 1;
			}
			else if (charKeys.keyLeft)
			{
				if (charKeys.keyWalk)
				{
					cUp.traj.X = (0f - meta.speed) / 4f;
					if (c.charAnim.animName != meta.turn_anim && c.charAnim.animName != meta.altRunStart_anim && c.charAnim.animName != meta.altturn_anim)
					{
						c.charAnim.SetAnim(meta.walk_anim, cUp);
					}
				}
				else if (charKeys.keyJog)
				{
					cUp.traj.X = (0f - meta.speed) / 2f;
					if (c.charAnim.animName != meta.turn_anim && c.charAnim.animName != meta.altRunStart_anim && c.charAnim.animName != meta.altturn_anim)
					{
						c.charAnim.SetAnim(meta.jog_anim, cUp);
					}
				}
				else if (!meta.isstopbeforeattack || !(c.charAnim.animName == meta.runend_anim))
				{
					if (c.charAnim.animName != meta.runstart_anim && c.charAnim.animName != meta.run_anim && c.charAnim.animName != meta.turn_anim && c.charAnim.animName != meta.altturn_anim && c.charAnim.animName != meta.altRunStart_anim)
					{
						c.charAnim.SetAnim(meta.runstart_anim, cUp);
					}
					cUp.traj.X = 0f - meta.speed;
				}
				cUp.face = 0;
			}
			else if (!(c.charAnim.animName == meta.turn_anim) && !(c.charAnim.animName == meta.altturn_anim))
			{
				if (c.charAnim.animName == meta.run_anim || c.charAnim.animName == meta.altRunStart_anim)
				{
					charAnim.SetAnim(meta.runend_anim, cUp);
				}
				if (charAnim.animName != meta.runend_anim)
				{
					charAnim.SetAnim(meta.idle_anim, cUp);
				}
			}
			if (face != cUp.face)
			{
				charAnim.SetAnim(meta.turn_anim, cUp, overRide: true);
			}
		}
		else if (c.charAnim.animName == meta.fly_anim || c.charAnim.animName == meta.flip_anim || c.charAnim.animName == meta.wall_jump_anim || c.charAnim.animName == meta.fturn_anim || (c.charAnim.animName == meta.jump_anim && cUp.state == CharUpdate.State.Airborne && c.team == Character.Team.GoodGuys) || (cUp.state == CharUpdate.State.Airborne && charAnim.canCancel))
		{
			if (c.charAnim.animName != meta.wall_jump_anim)
			{
				cUp.ClearGrabs();
				if (charKeys.keyRight)
				{
					cUp.face = 1;
					if (cUp.traj.X < meta.speed)
					{
						cUp.traj.X += 500f * FMan.frameTime;
					}
				}
				else if (charKeys.keyLeft)
				{
					cUp.face = 0;
					if (cUp.traj.X > 0f - meta.speed)
					{
						cUp.traj.X -= 500f * FMan.frameTime;
					}
				}
				if (cUp.face != face && c.charAnim.CheckAnim(meta.fturn_anim) > -1)
				{
					c.charAnim.SetAnim(meta.fturn_anim, cUp);
				}
			}
			cUp.totalHang = 0f;
			if (charKeys.keyJump && c.ai.type < 0 && cUp.canDoubleJump)
			{
				charAnim.SetAnim(meta.flip_anim, cUp);
				charAnim.JoyJump(charKeys, cUp);
				cUp.canDoubleJump = false;
				if (Game1.IsPlayerChar(c.ID) && Game1.beadMgr.beads[c.ID].HasBead(InvCatalog.InvItemName.AchievablesBead))
				{
					GetAllAchievables getAllAchievables = (GetAllAchievables)Game1.achievementMgr.playerAchievements[c.ID].achievementList[5];
					if (!getAllAchievables.doubleJump)
					{
						getAllAchievables.doubleJump = true;
						getAllAchievables.Unlock(overRide: false);
					}
				}
			}
			if (charKeys.keyAttack)
			{
				EnemyFace(c, cArray);
				charAnim.SetAnim(meta.fatk_anim, cUp);
				UpdateFace(charKeys, cUp);
				if (Game1.IsPlayerChar(c.ID))
				{
					cUp.JuggleStick(c.ID, warp: false);
				}
				Game1.practice.SetKey(0, c.ID);
			}
			if (charKeys.keySec)
			{
				cUp.CheckSec(charAnim, charKeys, overRide: false);
			}
			else if (charKeys.keyStrong)
			{
				if (meta.special == 3 || meta.special == 4)
				{
					EnemyFace(c, cArray);
					charAnim.SetAnim(meta.fstrong_anim, cUp);
					UpdateFace(charKeys, cUp);
				}
				else
				{
					EnemyFace(c, cArray);
					cUp.lastSpecial = 1;
					charAnim.SetAnim(meta.fstrong_anim, cUp);
					charAnim.smokeMachineLife = 10f;
					UpdateFace(charKeys, cUp);
				}
				Game1.practice.SetKey(1, c.ID);
			}
			else if (charKeys.keyGrab)
			{
				EnemyFace(c, cArray);
				UpdateFace(charKeys, cUp);
				charAnim.SetAnim(meta.jgrab_anim, cUp);
				if (Game1.IsPlayerChar(c.ID))
				{
					cUp.JuggleStick(c.ID, warp: false);
				}
				Game1.practice.SetKey(3, c.ID);
			}
		}
		else if (c.charAnim.animName == meta.wall_anim)
		{
			if (charKeys.keyJump)
			{
				cUp.traj = default;
				charAnim.SetAnim(meta.wall_jump_anim, cUp);
				cUp.face = face;
			}
			if (charKeys.keyUp)
			{
				charAnim.SetAnim(meta.wall_run_anim, cUp);
			}
			if (charKeys.keyDown)
			{
				charAnim.SetAnim(meta.wall_slide_anim, cUp);
			}
			if (charKeys.keyAttack)
			{
				charAnim.SetAnim(meta.wallatk_anim, cUp);
				cUp.face = 1 - face;
			}
			else
			{
				cUp.CheckWalled(cUp.loc, map, charAnim, meta);
			}
		}
		else if (c.charAnim.animName == meta.wall_run_anim)
		{
			cUp.traj.Y = -420f;
			if (Game1.gameMap.liftOn)
			{
				if (cUp.loc.Y > 1000f)
				{
					cUp.traj.Y += Game1.gameMap.liftSpeed * 60f;
				}
				else if (cUp.loc.Y > 900f)
				{
					cUp.traj.Y += Game1.gameMap.liftSpeed * (60f + (1000f - cUp.loc.Y) / 100f * 50f);
				}
				else
				{
					cUp.traj.Y += Game1.gameMap.liftSpeed * 110f;
				}
				if (cUp.loc.Y < 900f || cUp.traj.Y > -100f)
				{
					charKeys.keyJump = true;
				}
			}
			if (Game1.gameMap.fakeCeiling > -1f && cUp.loc.Y < Game1.gameMap.fakeCeiling)
			{
				charKeys.keyJump = true;
			}
			if (Game1.gameMap.slippyWalls && cUp.loc.Y < 550f)
			{
				charKeys.keyJump = true;
			}
			if (charKeys.keyJump)
			{
				charAnim.SetAnim(meta.wall_jump_anim, cUp);
				cUp.face = face;
			}
			else if (!charKeys.keyUp)
			{
				charAnim.SetAnim(meta.wall_anim, cUp);
			}
			if (charKeys.keyAttack || charKeys.keyStrong || charKeys.keyGrab)
			{
				charAnim.SetAnim(meta.wallatk_anim, cUp);
				cUp.face = 1 - face;
			}
			else
			{
				cUp.CheckWalled(cUp.loc, map, charAnim, meta);
			}
			if (c.charAnim.animName == meta.wall_run_anim && map.TestCol(cUp.loc + new Vector2(0f, -85f), ceils: true))
			{
				cUp.loc.Y = map.GetMaxY(cUp.loc + new Vector2(0f, -85f)) + 80f;
				if ((charKeys.keyLeft && cUp.face == 1) || (charKeys.keyRight && cUp.face == 0))
				{
					c.charAnim.SetAnim(meta.ceilrun_anim, cUp);
				}
				else
				{
					charAnim.SetAnim(meta.wall_jump_anim, cUp);
				}
			}
		}
		else if (c.charAnim.animName == meta.wall_slide_anim)
		{
			if (cUp.traj.Y < 50f)
			{
				cUp.traj.Y += FMan.frameTime * 800f;
			}
			if (charKeys.keyJump)
			{
				charAnim.SetAnim(meta.wall_jump_anim, cUp);
			}
			if (!charKeys.keyDown)
			{
				charAnim.SetAnim(meta.wall_anim, cUp);
			}
			if (charKeys.keyAttack || charKeys.keyStrong || charKeys.keyGrab)
			{
				cUp.face = 1 - cUp.face;
				charAnim.SetAnim(meta.wallatk_anim, cUp);
				cUp.traj.X = ((float)cUp.face - 0.5f) * 1600f;
				cUp.traj.Y = 200f;
			}
			else
			{
				cUp.CheckWalled(cUp.loc, map, charAnim, meta);
			}
		}
		else
		{
			if (!(c.charAnim.animName == meta.ceilrun_anim))
			{
				return;
			}
			if (charKeys.keyJump)
			{
				c.charAnim.SetAnim(meta.ceildrop_anim, cUp);
				cUp.traj.Y = 500f;
				cUp.traj.X /= 2f;
			}
			else if (charKeys.keyAttack || charKeys.keyStrong || charKeys.keyGrab)
			{
				if (c.charAnim.CheckAnim(meta.ceilatk_anim) > -1)
				{
					cUp.face = 1 - cUp.face;
					c.charAnim.SetAnim(meta.ceilatk_anim, cUp);
				}
			}
			else if (map.TestCol(cUp.loc + new Vector2(0f, -85f), ceils: true))
			{
				if (map.GetCol(cUp.loc + new Vector2(0f, -85f)) == Map.Collision.Null)
				{
					c.charAnim.SetAnim(meta.ceildrop_anim, cUp);
					cUp.traj.Y = 0f;
					cUp.traj.X /= 2f;
					return;
				}
				cUp.loc.Y = map.GetMaxY(cUp.loc + new Vector2(0f, -85f)) + 80f;
				cUp.traj.Y = 0f;
				if ((charKeys.keyLeft && cUp.face == 1) || (charKeys.keyRight && cUp.face == 0))
				{
					cUp.traj.X = ((float)cUp.face - 0.5f) * meta.speed * -2.8f;
				}
				else
				{
					c.charAnim.SetAnim(meta.ceildrop_anim, cUp);
					cUp.traj.Y = 0f;
					cUp.traj.X /= 2f;
				}
				if (cUp.traj.X < 0f)
				{
					if (!map.TestCol(cUp.loc + new Vector2(-30f, -81f), ceils: true))
					{
						c.charAnim.SetAnim(meta.ceildrop_anim, cUp);
						cUp.traj.Y = 0f;
						cUp.traj.X /= 2f;
					}
				}
				else if (cUp.traj.X > 0f && !map.TestCol(cUp.loc + new Vector2(30f, -81f), ceils: true))
				{
					c.charAnim.SetAnim(meta.ceildrop_anim, cUp);
					cUp.traj.Y = 0f;
					cUp.traj.X /= 2f;
				}
			}
			else
			{
				c.charAnim.SetAnim(meta.ceildrop_anim, cUp);
				cUp.traj.Y = 0f;
				cUp.traj.X /= 2f;
			}
		}
	}

	public void StartGuitar(int ID)
	{
		for (int i = 0; i < Game1.character.Length; i++)
		{
			if (Game1.character[i].exists && (Game1.character[i].GetMeta().isViolin || Game1.character[i].GetMeta().isGuitar) && ((Game1.character[ID].GetMeta().isDish && Game1.character[i].GetMeta().isGuitar) || (Game1.character[ID].GetMeta().isYuki && Game1.character[i].GetMeta().isViolin)))
			{
				Game1.character[ID].charUpdate.loc = Game1.character[i].charUpdate.loc;
				if (Game1.character[ID].GetMeta().isDish)
				{
					Game1.character[ID].charUpdate.face = 1;
				}
				else
				{
					Game1.character[ID].charUpdate.face = 0;
				}
			}
		}
	}

	private void EnemyFace(Character c, Character[] cArray)
	{
		if (c.team != Character.Team.GoodGuys)
		{
			return;
		}
		bool flag = false;
		bool flag2 = false;
		for (int i = 0; i < cArray.Length; i++)
		{
			if (!cArray[i].exists || i == c.ID || cArray[i].team == c.team || cArray[i].charUpdate.ethereal)
			{
				continue;
			}
			flag2 = true;
			if (c.charUpdate.face == 1)
			{
				if (cArray[i].charUpdate.loc.X > c.charUpdate.loc.X)
				{
					flag = true;
				}
			}
			else if (c.charUpdate.face == 0 && cArray[i].charUpdate.loc.X < c.charUpdate.loc.X)
			{
				flag = true;
			}
		}
		if (flag2 && !flag)
		{
			if (c.charUpdate.face == 1)
			{
				c.charUpdate.face = 0;
			}
			else
			{
				c.charUpdate.face = 1;
			}
		}
	}

	public void UpdateFace(CharKeys charKeys, CharUpdate cUp)
	{
		if (charKeys.keyLeft)
		{
			cUp.face = 0;
		}
		if (charKeys.keyRight)
		{
			cUp.face = 1;
		}
	}

	public void Reload(CharAnim charAnim, CharUpdate cUp)
	{
		if (cUp.state == CharUpdate.State.Grounded)
		{
			charAnim.SetAnim("reload", cUp);
		}
		else
		{
			charAnim.SetAnim("freload", cUp);
		}
	}

	public void DoFShotty(CharKeys charKeys, CharAnim charAnim, CharUpdate cUp, Character c)
	{
		if (!CanShotty(c))
		{
			return;
		}
		if (charKeys.keyRight && charKeys.keyUp)
		{
			cUp.face = 1;
			charAnim.SetAnim("fshottyu", cUp);
			return;
		}
		if (charKeys.keyLeft && charKeys.keyUp)
		{
			cUp.face = 0;
			charAnim.SetAnim("fshottyu", cUp);
			return;
		}
		if (charKeys.keyUp)
		{
			charAnim.SetAnim("fshottyuu", cUp);
			return;
		}
		if (charKeys.keyRight && charKeys.keyDown)
		{
			cUp.face = 1;
			charAnim.SetAnim("fshottyd", cUp);
			return;
		}
		if (charKeys.keyLeft && charKeys.keyDown)
		{
			cUp.face = 0;
			charAnim.SetAnim("fshottyd", cUp);
			return;
		}
		if (charKeys.keyDown)
		{
			charAnim.SetAnim("fshottydd", cUp);
			return;
		}
		if (charKeys.keyRight)
		{
			cUp.face = 1;
		}
		if (charKeys.keyLeft)
		{
			cUp.face = 0;
		}
		charAnim.SetAnim("fshotty", cUp);
	}

	private bool CanShotty(Character c)
	{
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
		{
			if (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].gunMode == Level.GunMode.Shotty)
			{
				return true;
			}
			return false;
		}
		if (c.GetMeta().isDish)
		{
			if (Game1.player.dishPhase >= 9)
			{
				return true;
			}
			if (Game1.gamePlayerMgr.gamePlayer[c.ID].highestDishPhase >= 9)
			{
				return true;
			}
		}
		else if (c.GetMeta().isYuki)
		{
			if (Game1.player.yukiPhase >= 14)
			{
				return true;
			}
			if (Game1.player.yukiPhase >= 6 && Game1.gamePlayerMgr.gamePlayer[c.ID].highestYukiPhase >= 14)
			{
				return true;
			}
		}
		return false;
	}

	public void DoShotty(CharKeys charKeys, CharAnim charAnim, CharUpdate cUp, Character c)
	{
		if (!CanShotty(c))
		{
			return;
		}
		if (charKeys.keyRight && charKeys.keyUp)
		{
			cUp.face = 1;
			charAnim.SetAnim("shottyu", cUp);
			return;
		}
		if (charKeys.keyLeft && charKeys.keyUp)
		{
			cUp.face = 0;
			charAnim.SetAnim("shottyu", cUp);
			return;
		}
		if (charKeys.keyUp)
		{
			charAnim.SetAnim("shottyuu", cUp);
			return;
		}
		if (charKeys.keyRight)
		{
			cUp.face = 1;
		}
		if (charKeys.keyLeft)
		{
			cUp.face = 0;
		}
		charAnim.SetAnim("shotty", cUp);
	}
}
