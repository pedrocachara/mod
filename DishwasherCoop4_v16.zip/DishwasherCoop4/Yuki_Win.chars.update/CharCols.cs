using Microsoft.Xna.Framework;
using Yuki_Win.maps;

namespace Yuki_Win.chars.update;

public class CharCols
{
	public bool TestCol(Vector2 v, Map map, bool falling, bool warping)
	{
		int num = (int)(v.X / 64f);
		int num2 = (int)(v.Y / 32f);
		float num3 = (v.X - (float)num * 64f) / 64f;
		float num4 = (v.Y - (float)num2 * 32f) / 32f;
		if (num >= 0 && num2 >= 0 && num < map.xSize && num2 < map.ySize * 2)
		{
			switch (map.collision[num, num2])
			{
			case Map.Collision.Full:
				return true;
			case Map.Collision.Null:
				return true;
			case Map.Collision.Rise:
				if (num4 > 1f - num3)
				{
					return true;
				}
				break;
			case Map.Collision.Fall:
				if (num4 > num3)
				{
					return true;
				}
				break;
			case Map.Collision.CeilingRise:
				if (num4 < 1f - num3)
				{
					return true;
				}
				break;
			case Map.Collision.CeilingFall:
				if (num4 < num3)
				{
					return true;
				}
				break;
			case Map.Collision.Ceiling:
				if (!falling)
				{
					return true;
				}
				break;
			case Map.Collision.Pipe:
				if (!warping)
				{
					return true;
				}
				break;
			case Map.Collision.Ledge:
				if (falling)
				{
					return true;
				}
				break;
			}
		}
		return false;
	}

	public void TestCollision(Character me, Character[] c, CharUpdate cUpdate)
	{
		if (cUpdate.ethereal || c[me.ID].GetMeta().isNeko || c[me.ID].GetMeta().isCrow || cUpdate.dyingFrame > 0f || c[me.ID].GetMeta().isGuitar || c[me.ID].GetMeta().isViolin)
		{
			return;
		}
		cUpdate.colVal = 0f;
		for (int i = 0; i < c.Length; i++)
		{
			if (me.ID == i || !c[i].exists)
			{
				continue;
			}
			if (!c[i].charUpdate.ethereal && !c[i].charUpdate.inactive && !c[i].GetMeta().isNeko && !c[i].GetMeta().isCrow && !c[i].GetMeta().isGuitar && !c[i].GetMeta().isViolin && c[i].charUpdate.dyingFrame <= 0f && (me.team == Character.Team.BadGuys || c[i].team == Character.Team.BadGuys) && (me.GetMeta().autoGroundSplode == c[i].GetMeta().autoGroundSplode || c[i].team != Character.Team.BadGuys || me.team != Character.Team.BadGuys) && (!c[i].GetMeta().isBoss || !Game1.gameMap.lichFreakoutMode))
			{
				Vector2 cPreLoc = me.charUpdate.cPreLoc;
				Vector2 loc = c[i].charUpdate.loc;
				bool flag = false;
				float num = 40f;
				if (c[i].GetMeta().widthbuffer > 0)
				{
					num += (float)c[i].GetMeta().widthbuffer;
				}
				if (cPreLoc.Y > loc.Y - 80f && cPreLoc.Y < loc.Y + 80f && cPreLoc.X > loc.X - num && cPreLoc.X < loc.X + num)
				{
					flag = true;
				}
				if (!flag && c[i].GetMeta().isGiant && c[i].charRect.CheckHit(cPreLoc + new Vector2(0f, -30f), wide: true, c[i].GetMeta().widthbuffer) > -1)
				{
					flag = true;
				}
				if (!flag)
				{
					continue;
				}
				if (cPreLoc.X < loc.X)
				{
					cUpdate.colVal = -100f;
					if (cUpdate.traj.X > 100f)
					{
						cUpdate.colVal = 0f - cUpdate.traj.X - 1800f * FMan.frameTime;
					}
					if (c[i].GetMeta().isBox)
					{
						cUpdate.colVal -= 30f;
					}
					c[i].charUpdate.colVal = 100f;
				}
				else
				{
					cUpdate.colVal = 100f;
					if (cUpdate.traj.X < -100f)
					{
						cUpdate.colVal = 0f - cUpdate.traj.X + 1800f * FMan.frameTime;
					}
					if (c[i].GetMeta().isBox)
					{
						cUpdate.colVal += 30f;
					}
					c[i].charUpdate.colVal = -100f;
				}
			}
			else
			{
				if (c[i].team != me.team || c[i].charUpdate.charGrab.grabbedByChar <= -1)
				{
					continue;
				}
				float num2 = 40f;
				if (c[i].GetMeta().widthbuffer > 0)
				{
					num2 += (float)c[i].GetMeta().widthbuffer;
				}
				Vector2 loc2 = me.charUpdate.loc;
				Vector2 loc3 = c[i].charUpdate.loc;
				num2 += 150f;
				if (!(loc2.Y > loc3.Y - 80f) || !(loc2.Y < loc3.Y + 80f) || !(loc2.X > loc3.X - num2) || !(loc2.X < loc3.X + num2))
				{
					continue;
				}
				if (loc2.X < loc3.X)
				{
					cUpdate.colVal = -200f;
					if (cUpdate.traj.X > 200f)
					{
						cUpdate.colVal = 0f - cUpdate.traj.X;
					}
				}
				else
				{
					cUpdate.colVal = 200f;
					if (cUpdate.traj.X < -200f)
					{
						cUpdate.colVal = 0f - cUpdate.traj.X;
					}
				}
			}
		}
	}
}
