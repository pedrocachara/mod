using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Yuki_Win.achievements;
using Yuki_Win.chars;
using Yuki_Win.director;
using Yuki_Win.eightbit;
using Yuki_Win.gameRender;
using Yuki_Win.hud;
using Yuki_Win.maps;
using Yuki_Win.maps.foreground;

namespace Yuki_Win.debug;

public class DebugManager
{
	public enum PlayMode
	{
		Playing,
		Step
	}

	public enum StatMode
	{
		Off,
		On,
		History
	}

	public enum ClickAction
	{
		None,
		SpawnTransmara,
		SpawnMidEngie,
		SpawnFreak,
		EndLevel,
		EnableWater,
		SpawnForeguy,
		SpawnGoonPuppet,
		MakeGibs,
		SpawnSwordsman,
		Goresplode,
		DoGuitar,
		SpawnInvalid,
		SpawnBigEngie,
		CycleTheme,
		SpawnBox,
		ToggleFilterMode,
		DoPickup,
		SpawnChef,
		SpawnYukiNPC,
		AwardAchievement,
		Beatdown,
		SpawnSamurai,
		PrisonStart,
		EightbitGame,
		NekoToasty,
		DustinTerror
	}

	public enum LeftTrigAction
	{
		None,
		Slow,
		Fast,
		Zoom,
		DataJam
	}

	public class PerfFrame
	{
		public long[] phase = new long[10];

		public long GetTotal()
		{
			long num = 0L;
			for (int i = 0; i < phase.Length; i++)
			{
				num += phase[i];
			}
			return num;
		}
	}

	public static PlayMode playMode = PlayMode.Playing;

	public static bool canStep;

	public static bool godMode;

	public static bool ropeTest;

	public static float fpsTimer;

	public static int framesRendered;

	public static float fps;

	public static StatMode showFPS;

	public static StringBuilder fpsString = new StringBuilder("fps: ");

	public static StringBuilder spritesString = new StringBuilder("particles: ");

	public static bool hideChars;

	public static int totalSprites;

	public static StatMode showSprites;

	public static bool showHitRects;

	public static bool stepMode;

	public static bool threeDeeMode;

	public static ClickAction clickAction;

	private static int achievementToAward = 0;

	public static LeftTrigAction leftTrigAction;

	public static int[] spriteHistory = new int[256];

	public static int[] frameHistory = new int[256];

	public static PerfFrame[] perfHistory = new PerfFrame[256];

	private static int stagnantFrames;

	public static int perfFrame = 0;

	public static bool showPerf;

	public static bool instakill;

	public static bool noclipwarp;

	public static bool unlockAll;

	public static bool netLackeyMode;

	public static bool videoRecordMode;

	public static void Init()
	{
		for (int i = 0; i < perfHistory.Length; i++)
		{
			perfHistory[i] = new PerfFrame();
		}
	}

	public static void PerfSnap(int p, long v)
	{
		if (showPerf)
		{
			perfHistory[perfFrame].phase[p] = v;
		}
	}

	public static void PerfFinish(long start)
	{
		if (showPerf)
		{
			for (int num = perfHistory[perfFrame].phase.Length - 1; num > 0; num--)
			{
				perfHistory[perfFrame].phase[num] = perfHistory[perfFrame].phase[num] - perfHistory[perfFrame].phase[num - 1];
			}
			perfHistory[perfFrame].phase[0] = perfHistory[perfFrame].phase[0] - start;
			perfFrame = (perfFrame + 1) % perfHistory.Length;
		}
	}

	public static void DrawPerf(SpriteBatch sprite, Vector2 loc, int threedee)
	{
		switch (threedee)
		{
		case 0:
			loc.X++;
			break;
		case 1:
			loc.X--;
			break;
		}
		sprite.Draw(Game1.nullTex, loc, new Rectangle(0, 0, 1, 1), new Color(0f, 0f, 0f, 0.8f), 0f, new Vector2(0f, 0f), new Vector2(246f, 100f), SpriteEffects.None, 1f);
		int num = perfFrame;
		for (int i = 0; i < perfHistory.Length - 10; i++)
		{
			long total = perfHistory[num].GetTotal();
			if (total > 0)
			{
				float num2 = loc.Y + 100f;
				float num3 = loc.Y + 100f;
				for (int j = 0; j < perfHistory[num].phase.Length; j++)
				{
					Color color = Color.White;
					switch (j)
					{
					case 0:
						color = new Color(1f, 1f, 1f, 1f);
						break;
					case 1:
						color = new Color(1f, 0f, 0f, 1f);
						break;
					case 2:
						color = new Color(0f, 1f, 0f, 1f);
						break;
					case 3:
						color = new Color(0.3f, 0.3f, 0.3f, 1f);
						break;
					case 4:
						color = new Color(0f, 1f, 1f, 1f);
						break;
					case 5:
						color = new Color(0f, 0f, 1f, 1f);
						break;
					case 6:
						color = new Color(1f, 0.5f, 0f, 1f);
						break;
					case 7:
						color = new Color(1f, 0f, 1f, 1f);
						break;
					case 8:
						color = new Color(0.5f, 0f, 0f, 1f);
						break;
					case 9:
						color = new Color(1f, 0.7f, 0.7f, 1f);
						break;
					}
					long num4 = 0L;
					int num5 = num;
					for (int k = 0; k < 8; k++)
					{
						num4 += perfHistory[num5].phase[j];
						num5 = (num5 + 1) % perfHistory.Length;
					}
					num4 /= 8;
					num2 -= (float)(num4 / 1000);
					sprite.Draw(Game1.nullTex, new Rectangle((int)loc.X + i, (int)num2, 1, (int)(num3 - num2)), new Rectangle(0, 0, 1, 1), color);
					num3 = num2;
				}
			}
			num = (num + 1) % perfHistory.Length;
		}
	}

	public static void DrawHistory(SpriteBatch sprite, Vector2 loc, int threedee)
	{
		switch (threedee)
		{
		case 0:
			loc.X++;
			break;
		case 1:
			loc.X--;
			break;
		}
		sprite.Draw(Game1.nullTex, loc, new Rectangle(0, 0, 1, 1), new Color(0f, 0f, 0f, 0.8f), 0f, new Vector2(0f, 0f), new Vector2(226f, 100f), SpriteEffects.None, 1f);
		if (showSprites == StatMode.History)
		{
			for (int i = 0; i < spriteHistory.Length - 30; i++)
			{
				float num = (float)spriteHistory[i] / 2048f;
				num *= 100f;
				sprite.Draw(Game1.nullTex, new Rectangle((int)loc.X + i, (int)loc.Y + 100 - (int)num, 1, (int)num), new Color(1f, 0f, 0f, 0.7f));
			}
		}
		if (showFPS != StatMode.History)
		{
			return;
		}
		for (int j = 0; j < frameHistory.Length - 30; j++)
		{
			if (frameHistory[j] > -1)
			{
				float num2 = (float)frameHistory[j] / 60f;
				num2 *= 100f;
				sprite.Draw(Game1.nullTex, loc + new Vector2(j, 100f - num2), new Rectangle(0, 0, 1, 1), new Color(0f, 1f, 0f, Rand.GetRandomFloat(0.2f, 0.3f)), 0f, new Vector2(0.5f, 0.5f), Rand.GetRandomFloat(1f, 4f), SpriteEffects.None, 1f);
			}
		}
	}

	public static void Update()
	{
		if (showFPS == StatMode.History)
		{
			for (int i = 1; i < frameHistory.Length; i++)
			{
				frameHistory[i - 1] = frameHistory[i];
			}
			if (stagnantFrames > 0)
			{
				frameHistory[frameHistory.Length - 1] = -1;
			}
			else
			{
				frameHistory[frameHistory.Length - 1] = (int)fps;
			}
		}
		if (showSprites == StatMode.History)
		{
			for (int j = 1; j < spriteHistory.Length; j++)
			{
				spriteHistory[j - 1] = spriteHistory[j];
			}
			spriteHistory[spriteHistory.Length - 1] = totalSprites;
		}
		fpsTimer -= FMan.realTime;
		if (fpsTimer < 0f)
		{
			fps = (float)framesRendered / 0.5f;
			fpsTimer += 0.5f;
			framesRendered = 0;
			if (showFPS == StatMode.History)
			{
				int num = frameHistory.Length - stagnantFrames - 1;
				float num2 = frameHistory[num];
				for (int k = num; k < frameHistory.Length; k++)
				{
					float num3 = (fps - num2) * ((float)(k - num) / (float)stagnantFrames) + num2;
					frameHistory[k] = (int)num3;
				}
				stagnantFrames = 0;
			}
		}
		else if (showFPS == StatMode.History)
		{
			stagnantFrames++;
		}
		if (stepMode)
		{
			if (flibitPort.GetInputClicked(0, flibitPort.InputAction.Inventory))
			{
				switch (playMode)
				{
				case PlayMode.Playing:
					playMode = PlayMode.Step;
					break;
				case PlayMode.Step:
					playMode = PlayMode.Playing;
					break;
				}
			}
			if (playMode == PlayMode.Step && flibitPort.GetInputClicked(0, flibitPort.InputAction.PauseConfirm))
			{
				canStep = true;
			}
		}
		else
		{
			playMode = PlayMode.Playing;
		}
		if (flibitPort.GetInputAnalog(0, flibitPort.InputAction.Magic) > 0.1f)
		{
			switch (leftTrigAction)
			{
			case LeftTrigAction.Fast:
				FMan.frameTime *= 4f;
				break;
			case LeftTrigAction.Slow:
				FMan.slowFrame = 0.1f;
				break;
			case LeftTrigAction.Zoom:
				ScrollManager.zoom += FMan.frameTime * 5f;
				break;
			case LeftTrigAction.DataJam:
				Game1.netSession.netGame.dataJam = true;
				break;
			}
		}
		if (!GamePad.GetState(PlayerIndex.One).IsButtonDown(Buttons.RightStick))
		{
			return;
		}
		switch (clickAction)
		{
		case ClickAction.SpawnYukiNPC:
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 55, "");
			break;
		case ClickAction.SpawnSamurai:
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 34, "");
			break;
		case ClickAction.CycleTheme:
			Game1.gameMap.theme.theme = (Themes.ThemeType)((int)(Game1.gameMap.theme.theme + 1) % 31);
			Printf.WriteLine(Game1.gameMap.theme.theme.ToString());
			break;
		case ClickAction.SpawnTransmara:
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc + new Vector2(100f, 0f), 53, "");
			break;
		case ClickAction.NekoToasty:
			Game1.gameMap.PopUpNekoToasty();
			break;
		case ClickAction.DustinTerror:
			Game1.gameMap.goryoMode = true;
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc + new Vector2(0f, -100f), 7, "");
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc + new Vector2(0f, -100f), 25, "");
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc + new Vector2(0f, -100f), 19, "");
			break;
		case ClickAction.SpawnFreak:
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 24, "");
			break;
		case ClickAction.SpawnSwordsman:
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 9, "");
			break;
		case ClickAction.PrisonStart:
			Game1.levelMgr.SetGlobalFlag("scream");
			Game1.character[0].charUpdate.loc.Y = 200f;
			Game1.character[0].charUpdate.state = CharUpdate.State.Grounded;
			Game1.player.SetYukiPhase(2);
			Game1.character[0].Init(0, Game1.character[0].charUpdate.loc, 78, Game1.mainPlayer[0], Character.Team.GoodGuys, -1);
			Game1.gameMap.SetMap("prison1");
			break;
		case ClickAction.AwardAchievement:
		{
			achievementToAward = (achievementToAward + 1) % 12;
			AchievementDef achievementDef = Game1.achievementMgr.playerAchievements[0].achievementList[achievementToAward];
			achievementDef.Unlock(overRide: true);
			break;
		}
		case ClickAction.SpawnInvalid:
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 32, "");
			break;
		case ClickAction.SpawnBigEngie:
			Game1.spawnMgr.SpawnLockedMonster(new Vector2(650f, 650f), 41, "");
			break;
		case ClickAction.DoGuitar:
			switch (Game1.levelMgr.currentTrack)
			{
			case 0:
				Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc + new Vector2(0f, -100f), 58, "");
				break;
			case 1:
				Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc + new Vector2(0f, -100f), 57, "");
				break;
			case 2:
				Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc + new Vector2(-30f, -100f), 58, "");
				Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc + new Vector2(30f, -100f), 57, "");
				break;
			}
			break;
		case ClickAction.SpawnMidEngie:
		{
			int num10 = Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 44, "");
			if (num10 > -1)
			{
				Game1.character[num10].FloorMe(Game1.character[num10].charUpdate.loc);
				Game1.character[num10].charAnim.SetAnim(Game1.character[num10].GetMeta().activate_anim, Game1.character[num10].charUpdate);
			}
			break;
		}
		case ClickAction.EightbitGame:
			Game1.eightBitGame.Init(2);
			EightBitGame.enabled = true;
			break;
		case ClickAction.DoPickup:
		{
			string text = "cloud-hammer";
			int num9 = text.IndexOf('-');
			Game1.spriteMan.AddSprite(47, Game1.character[0].charUpdate.loc + new Vector2(150f, 0f), default, 0f, (int)Game1.invCatalog.GetNameFromName(text.Substring(0, num9)), (int)Game1.invCatalog.GetNameFromName(text.Substring(num9 + 1, text.Length - num9 - 1)));
			break;
		}
		case ClickAction.Beatdown:
		{
			Vector2 loc = Game1.character[0].charUpdate.loc + new Vector2(250f, 0f);
			if (Rand.CointToss(0.5f))
			{
				int num5 = Game1.spawnMgr.SpawnMonster(loc, 0, "");
				int num6 = Game1.spawnMgr.SpawnMonster(loc, 61, "");
				if (num5 > -1 && num6 > -1)
				{
					Game1.character[num5].FloorMe(loc);
					Game1.character[num6].FloorMe(loc);
					Game1.character[num5].charAnim.SetAnim("cution", Game1.character[num5].charUpdate);
					Game1.character[num5].charUpdate.charGrab.grabbedByChar = num6;
					Game1.character[num6].charUpdate.charGrab.grabbing = true;
					Game1.character[num5].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
					Game1.character[num6].charUpdate.face = Rand.GetRandomInt(0, 2);
					Game1.character[num5].charUpdate.face = 1 - Game1.character[num6].charUpdate.face;
				}
			}
			else
			{
				int num7 = Game1.spawnMgr.SpawnMonster(loc, 48, "");
				int num8 = Game1.spawnMgr.SpawnMonster(loc, 61, "");
				if (num7 > -1 && num8 > -1)
				{
					Game1.character[num7].FloorMe(loc);
					Game1.character[num8].FloorMe(loc);
					Game1.character[num7].charAnim.SetAnim("maul", Game1.character[num7].charUpdate);
					Game1.character[num7].charUpdate.charGrab.grabbedByChar = num8;
					Game1.character[num8].charUpdate.charGrab.grabbing = true;
					Game1.character[num7].charUpdate.charGrab.grabberLoc = new Vector2(-50f, -50f);
					Game1.character[num8].charUpdate.face = Rand.GetRandomInt(0, 2);
					Game1.character[num7].charUpdate.face = 1 - Game1.character[num8].charUpdate.face;
				}
			}
			break;
		}
		case ClickAction.SpawnChef:
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 50, "");
			break;
		case ClickAction.ToggleFilterMode:
			GameRender.filterRender.newVersion = !GameRender.filterRender.newVersion;
			break;
		case ClickAction.SpawnGoonPuppet:
			Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 39, "");
			break;
		case ClickAction.Goresplode:
			Game1.spriteMan.MakeExplosion(Game1.character[0].charUpdate.loc + new Vector2(0f, -100f), 0, 5f, splash: false);
			break;
		case ClickAction.SpawnBox:
		{
			int num4 = Game1.spawnMgr.SpawnMonster(Game1.character[0].charUpdate.loc, 18, "cloud");
			if (num4 > -1)
			{
				Game1.character[num4].FloorMe(Game1.character[num4].charUpdate.loc);
				Game1.character[num4].reward = Character.Reward.Pickup;
			}
			break;
		}
		case ClickAction.MakeGibs:
			QuakeManager.SetQuirk(0.1f);
			break;
		case ClickAction.EndLevel:
		{
			for (int l = 0; l < 2; l++)
			{
				Game1.gamePlayerMgr.gamePlayer[l].damage += 1000f;
				Game1.gamePlayerMgr.gamePlayer[l].score++;
			}
			Game1.levelMgr.elapsedTime += 1000f;
			Game1.hud.EndLevel();
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.SendEndLevel(Game1.netSession.session);
			}
			break;
		}
		case ClickAction.EnableWater:
			Game1.gameMap.water = true;
			Game1.gameMap.waterLev = Game1.character[0].charUpdate.loc.Y + 50f;
			break;
		case ClickAction.SpawnForeguy:
			Game1.gameMap.foregroundMgr.AddCharacter(ForeGroundMgr.ForeGroundDef.Dragon, new Vector2(-700f, 950f), 1);
			break;
		}
	}
}
