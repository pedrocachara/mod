using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;

namespace Yuki_Win.sprites.guns;

internal class UziMag : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj + Rand.GetRandomVec2(-40f, 40f, -40f, 40f);
		p.frame = Rand.GetRandomFloat(1f, 3f);
		p.rotation = Trig.GetAngle(default, traj) + 1.57f;
		p.rDir = Rand.GetRandomFloat(-10f, 10f);
		p.owner = 1;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.rotation += FMan.frameTime * p.rDir;
		p.traj.Y += FMan.frameTime * 1600f;
		p.frame -= FMan.frameTime * 2f;
		Vector2 loc = p.loc;
		if (!p.wallFree)
		{
			p.loc += p.traj * FMan.frameTime * 2f;
			if (!Game1.gameMap.CurMap().TestCol(p.loc))
			{
				p.wallFree = true;
			}
			return;
		}
		p.loc.X += p.traj.X * FMan.frameTime * 2f;
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.loc.X = loc.X;
			p.traj.X *= -0.5f;
			if (p.owner > 0)
			{
				Sound.PlaySnd(Sound.Category.FX, "drum");
				p.owner = -1;
			}
		}
		p.loc.Y += p.traj.Y * FMan.frameTime * 2f;
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.loc.Y = loc.Y;
			p.traj.X *= 0.2f;
			p.traj.Y *= -0.4f;
			if (p.owner > 0)
			{
				Sound.PlaySnd(Sound.Category.FX, "drum");
				p.owner = -1;
			}
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(608, 448, 16, 64), new Color(1f, 1f, 1f, p.frame * 9f), p.rotation, new Vector2(8f, 32f), ScrollManager.cannedDepth[0] * 0.4f, SpriteEffects.None, 1f);
	}
}
