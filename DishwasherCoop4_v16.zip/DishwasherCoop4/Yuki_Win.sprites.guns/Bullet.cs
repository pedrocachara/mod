using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.guns;

internal class Bullet : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.owner = owner;
		p.hitter = true;
		p.alpha = true;
		p.frame = 0.3f;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.frame = -1f;
			Vector2 loc = p.loc - p.traj * FMan.frameTime;
			for (int i = 0; i < 10; i++)
			{
				spriteMan.AddSprite(0, loc, -p.traj * 0.2f + Rand.GetRandomVec2(-400f, 400f, -400f, 400f), 0f, 0, 0);
			}
		}
		p.rotation = Trig.GetAngle(default, p.traj);
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(448, 32, 128, 32), new Color(new Vector4(1f, 0.6f, 1f, 1f)), p.rotation, new Vector2(64f, 16f) * Rand.GetRandomFloat(0.5f, 1f), new Vector2(1f, 0.5f) * Rand.GetRandomFloat(0.1f, 0.8f) * ScrollManager.cannedDepth[0], SpriteEffects.None, 1f);
	}
}
