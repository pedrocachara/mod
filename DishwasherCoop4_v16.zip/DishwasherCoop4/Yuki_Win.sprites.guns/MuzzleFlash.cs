using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.gameRender;

namespace Yuki_Win.sprites.guns;

internal class MuzzleFlash : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.owner = owner;
		p.size = size;
		p.frame = Rand.GetRandomFloat(0.025f, 0.05f);
		p.rotation = Rand.GetRandomFloat(0f, 6.28f);
		p.traj += Rand.GetRandomVec2(-100f, 100f, -100f, 100f);
		p.flags = Rand.GetRandomInt(0, 3);
		p.r = Rand.GetRandomFloat(0f, 1f);
		p.thresh = true;
		p.alpha = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.frame -= FMan.AdjustedFrame(p.owner);
		p.loc += p.traj * FMan.AdjustedFrame(p.owner);
		if (p.size > 0.3f && p.frame <= 0f)
		{
			spriteMan.AddRefractSprite(69, p.loc + p.traj * Rand.GetRandomFloat(0f, 0.05f), p.traj + new Vector2(0f, -100f) + Rand.GetRandomVec2(-100f, 100f, -100f, 100f), Rand.GetRandomFloat(0.5f, 1f), 0, 0);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(p.loc, 1f);
		if (p.thresh)
		{
			sprite.Draw(spritesTex, screenLoc, new Rectangle(256 + p.flags * 64, 192, 64, 64), new Color(new Vector4(0f, p.r, 0f, p.frame * 22f)), p.rotation, new Vector2(32f, 32f), (p.size + 0.2f - p.frame) * ScrollManager.cannedDepth[0] * 0.5f * 4f, SpriteEffects.None, 1f);
		}
		else
		{
			sprite.Draw(spritesTex, screenLoc, new Rectangle(256 + p.flags * 64, 192, 64, 64), new Color(new Vector4(1f, p.frame * 22f, p.frame * 22f, p.frame * 22f)), p.rotation, new Vector2(32f, 32f), (p.size + 0.2f - p.frame) * ScrollManager.cannedDepth[0] * 2f, SpriteEffects.None, 1f);
		}
		if (p.size > 0.3f)
		{
			PostGlowMgr.AddGlow(screenLoc, 1f, 0.6f, 0.5f, p.size * 10f, p.frame * 0.8f, 0f);
			PostGlowMgr.AddGlow(screenLoc, 0.5f, 0.6f, 1f, p.size * 3f, p.frame, 1f);
		}
	}
}
