using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win;

namespace SceneEdit.scene;

public class AddMgr
{
	public RenderTarget2D rTarg;

	public AddMgr(GraphicsDevice dev)
	{
		rTarg = new RenderTarget2D(dev, 128, 128);
	}

	internal void Prepare(GraphicsDevice dev, SpriteBatch sprite, RenderTarget2D comicTarg)
	{
		dev.SetRenderTarget(rTarg);
		SpriteTools.BeginOpaque();
		sprite.Draw(comicTarg, new Rectangle(0, 0, 128, 128), Color.White);
		SpriteTools.End();
	}

	internal void Draw(SpriteBatch sprite, float a, bool rand)
	{
		SpriteTools.End();
		SpriteTools.BeginAdditive();
		Rectangle destinationRectangle = new Rectangle(Rand.GetRandomInt(-10, 0), Rand.GetRandomInt(-5, 0), (int)ScrollManager.screenSize.X + Rand.GetRandomInt(10, 20), (int)ScrollManager.screenSize.Y + Rand.GetRandomInt(5, 10));
		if (!rand)
		{
			destinationRectangle = new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		}
		try
		{
			sprite.Draw(rTarg, destinationRectangle, new Color(1f, 1f, 1f, a));
		}
		catch (Exception)
		{
		}
		SpriteTools.End();
		SpriteTools.BeginAlpha();
	}

	internal void DrawGlobs(SpriteBatch sprite, Texture2D spritesTex)
	{
		for (int i = 0; i < 32; i++)
		{
			sprite.Draw(spritesTex, Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, 0f, ScrollManager.screenSize.Y), new Rectangle(384 + Rand.GetRandomInt(0, 6) * 64, 320, 64, 64), new Color(0f, 0f, 0f, Rand.GetRandomFloat(0f, 0.15f)), Rand.GetRandomFloat(0f, 6.28f), new Vector2(32f, 32f), Rand.GetRandomFloat(0f, 1f), SpriteEffects.None, 1f);
			sprite.Draw(spritesTex, Rand.GetRandomVec2(0f, ScrollManager.screenSize.X, ScrollManager.screenSize.Y / 2f, ScrollManager.screenSize.Y / 2f), new Rectangle(128, Rand.GetRandomInt(0, 3) * 32, 128, 32), new Color(0f, 0f, 0f, Rand.GetRandomFloat(0f, 0.15f)), 1.57f, new Vector2(62f, 16f), new Vector2(5f, 0.2f), SpriteEffects.None, 1f);
		}
	}
}
