using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Yuki_Win.maps;
using Yuki_Win.sprites.gibs;
using Yuki_Win.sprites.wallblood;

namespace Yuki_Win.sprites.goreInstance;

public class GoreInstance
{
	public struct GibInstance
	{
		public Vector2 loc;

		public int face;

		public int headTex;

		public int torsoTex;

		public int legsTex;

		public int weaponTex;

		public int charDef;

		public int landAnim;

		public int key;

		public float size;

		public int owner;
	}

	public struct WallBloodInstance
	{
		public Vector2 loc;

		public float r;

		public float size;

		public int idx;

		public int dripIdx;

		public float frame;

		public int dripTest;
	}

	public List<GibInstance> gibInstance;

	public List<WallBloodInstance> wallBloodInstance;

	public GoreInstance()
	{
		gibInstance = new List<GibInstance>();
		wallBloodInstance = new List<WallBloodInstance>();
	}

	internal void Set()
	{
		gibInstance.Clear();
		wallBloodInstance.Clear();
		for (int i = 0; i < Game1.spriteMan.gib.Length; i++)
		{
			Gib gib = Game1.spriteMan.gib[i];
			if (gib.exists)
			{
				switch (gib.gibType)
				{
				case 4:
				case 6:
					continue;
				}
				gibInstance.Add(gib.GetInstance());
			}
		}
		for (int j = 0; j < Game1.spriteMan.wallBlood.Length; j++)
		{
			WallBlood wallBlood = Game1.spriteMan.wallBlood[j];
			if (wallBlood.exists)
			{
				wallBloodInstance.Add(wallBlood.GetInstance());
			}
		}
	}

	internal void Restore()
	{
		Map map = Game1.gameMap.CurMap();
		for (int i = 0; i < gibInstance.Count; i++)
		{
			Game1.spriteMan.gib[i].SetFromInstance(gibInstance[i], map);
		}
		for (int j = 0; j < wallBloodInstance.Count; j++)
		{
			Game1.spriteMan.wallBlood[j].SetFromInstance(wallBloodInstance[j].loc, wallBloodInstance[j].r, wallBloodInstance[j].size, wallBloodInstance[j].idx, wallBloodInstance[j].dripIdx, wallBloodInstance[j].dripTest, wallBloodInstance[j].frame);
		}
	}
}
