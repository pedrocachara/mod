using System.Collections.Generic;
using Yuki_Win.arcade;

namespace Yuki_Win.sprites.goreInstance;

public class GoreInstanceMgr
{
	private Dictionary<string, GoreInstance> goreInstance;

	public GoreInstanceMgr()
	{
		goreInstance = new Dictionary<string, GoreInstance>();
	}

	public void Reset()
	{
		goreInstance.Clear();
	}

	public void SetInstances()
	{
		string curMap = Game1.gameMap.curMap;
		if (!goreInstance.ContainsKey(curMap))
		{
			goreInstance.Add(curMap, new GoreInstance());
		}
		goreInstance[curMap].Set();
	}

	public void RestoreInstances()
	{
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off)
		{
			string curMap = Game1.gameMap.curMap;
			if (goreInstance.ContainsKey(curMap))
			{
				goreInstance[curMap].Restore();
			}
		}
	}
}
