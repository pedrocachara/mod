using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.hud.practice;

public class PracticeNode
{
	public const int X = 0;

	public const int Y = 1;

	public const int A = 2;

	public const int B = 3;

	public const int DOWN = 4;

	public const int UP = 5;

	public const int HOLD = 6;

	public const int YHOLD = 7;

	public const int YRELEASE = 8;

	public const int R = 9;

	public const int L = 10;

	public int idx;

	public void Set(int idx)
	{
		this.idx = idx;
	}

	public float Draw(SpriteBatch sprite, Vector2 loc)
	{
		float result = 60f;
		char attrib = '?';
		switch (idx)
		{
		case 0:
			attrib = 'X';
			break;
		case 1:
		case 7:
		case 8:
			attrib = 'Y';
			break;
		case 5:
			attrib = 'u';
			result = 40f;
			break;
		case 4:
			attrib = 'd';
			result = 40f;
			break;
		case 2:
			attrib = 'A';
			break;
		case 3:
			attrib = 'B';
			break;
		case 10:
			attrib = 'L';
			break;
		case 9:
			attrib = 'R';
			break;
		}
		flibitPort.DrawButtonAttrib(attrib, loc, Color.White, 0f, new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
		if (idx == 7 || idx == 8)
		{
			flibitPort.DrawButtonAttrib((idx == 7) ? 'Y' : 'X', loc + new Vector2(0f, -24f), Color.White, 0f, new Vector2(32f, 32f), 0.7f, SpriteEffects.None, 1f);
		}
		return result;
	}
}
