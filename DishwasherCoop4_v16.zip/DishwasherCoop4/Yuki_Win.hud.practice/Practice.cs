using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.hud.practice;

public class Practice
{
	public PracticeNode[] node;

	public int nodeCount;

	private float frame;

	public Practice()
	{
		node = new PracticeNode[32];
		for (int i = 0; i < node.Length; i++)
		{
			node[i] = new PracticeNode();
		}
	}

	public void Mod(int key, int ID)
	{
		if (ID <= 0 && (Game1.levelMgr.currentTrack == 5 || Game1.levelMgr.currentTrack == 6) && nodeCount > 0 && nodeCount < node.Length)
		{
			node[nodeCount].Set(node[nodeCount - 1].idx);
			node[nodeCount - 1].idx = key;
			nodeCount++;
			frame = 1f;
		}
	}

	public void SetKey(int key, int ID)
	{
		if (ID <= 0 && (Game1.levelMgr.currentTrack == 5 || Game1.levelMgr.currentTrack == 6))
		{
			if (nodeCount >= node.Length)
			{
				nodeCount = 0;
			}
			if (frame <= 0f)
			{
				nodeCount = 0;
			}
			if (nodeCount <= 0 || node[nodeCount - 1].idx != 9 || key != 9)
			{
				node[nodeCount].Set(key);
				nodeCount++;
				frame = 1f;
			}
		}
	}

	public void Update()
	{
		if (frame > 0f)
		{
			frame -= FMan.frameTime;
			if (Game1.character[0].charAnim.animName == Game1.character[0].GetMeta().idle_anim)
			{
				frame = 0f;
			}
		}
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		Vector2 loc = new Vector2(120f, 100f);
		switch (threedee)
		{
		case 0:
			loc.X++;
			break;
		case 1:
			loc.X--;
			break;
		}
		for (int i = 0; i < nodeCount; i++)
		{
			loc.X += node[i].Draw(sprite, loc);
		}
	}
}
