using director;
using Microsoft.Xna.Framework;
using Yuki_Win.ai;
using Yuki_Win.chars;

namespace Yuki_Win.pet;

public class PetPlayer
{
	public const int PET_PAKA = 0;

	public const int PET_MORDECAI = 1;

	private const float ACTIVE_MAX = 10f;

	public const int PUKE_HEALTH = 0;

	public const int PUKE_MAGIC = 1;

	public float activeFrame;

	public int ID;

	public int controllerIdx;

	public bool keyLeft;

	public bool keyRight;

	public bool keyJump;

	public bool keyJog;

	public bool keyWalk;

	public Vector2 lVec;

	private bool keyChow;

	private bool keyPukeHearts;

	private bool keyPukeMagic;

	public float chow;

	public int pukeType;

	public Vector2 rVec;

	public bool IsActive()
	{
		return activeFrame > 0f;
	}

	public void SetCharKeys(Character me, CharKeys keys)
	{
		keys.ClearKeys();
		if (PetType() == 0)
		{
			keys.keyLeft = keyLeft;
			keys.keyRight = keyRight;
			keys.keyJog = keyJog;
			keys.keyWalk = keyWalk;
		}
		CharMeta meta = me.GetMeta();
		_ = me.charUpdate.face;
		if (me.charUpdate.state == CharUpdate.State.Grounded || me.ai.mount)
		{
			if (me.charAnim.animName != meta.land_anim && (lVec.Y > 0.3f || (PetType() == 1 && (keyLeft || keyRight))))
			{
				if (keyLeft)
				{
					me.charUpdate.face = 0;
				}
				if (keyRight)
				{
					me.charUpdate.face = 1;
				}
				me.charAnim.SetAnim(meta.takeoff_anim, me.charUpdate);
				me.charUpdate.state = CharUpdate.State.Airborne;
				me.charUpdate.traj = new Vector2(((float)me.charUpdate.face - 0.5f) * 100f, -100f) + new Vector2(0f, -100f);
				if (ScrollManager.GetScreenLoc(me.charUpdate.loc, 1f).Y > ScrollManager.screenSize.Y * 0.69f && me.charUpdate.traj.Y < 0f)
				{
					me.charUpdate.traj.Y *= 5f;
				}
				me.ai.mount = false;
			}
		}
		else if (me.charAnim.animName == me.GetMeta().hover_anim || me.charAnim.animName == me.GetMeta().flight_anim || me.charAnim.animName == me.GetMeta().fturn_anim)
		{
			Vector2 traj = me.charUpdate.traj;
			Vector2 vector = lVec;
			vector.X *= 500f;
			vector.Y *= -300f;
			if (vector.X > 800f)
			{
				vector.X = 800f;
			}
			if (vector.X < -800f)
			{
				vector.X = -800f;
			}
			if (vector.Y > 500f)
			{
				vector.Y = 500f;
			}
			if (vector.Y < -500f)
			{
				vector.Y = -500f;
			}
			if (me.charAnim.animName != meta.fturn_anim)
			{
				if (vector.X > 170f || vector.X < -170f)
				{
					if (me.charAnim.animName == meta.hover_anim)
					{
						me.charAnim.SetAnim(meta.flight_anim, me.charUpdate);
					}
				}
				else if (me.charAnim.animName == meta.flight_anim)
				{
					me.charAnim.SetAnim(meta.hover_anim, me.charUpdate);
				}
			}
			me.charUpdate.traj.X += (vector.X - me.charUpdate.traj.X) * FMan.frameTime * 4f;
			me.charUpdate.traj.Y += (vector.Y - me.charUpdate.traj.Y) * FMan.frameTime * 10f;
			if (me.charUpdate.traj.X > 0f)
			{
				me.charUpdate.face = 1;
			}
			if (me.charUpdate.traj.X < 0f)
			{
				me.charUpdate.face = 0;
			}
			if ((traj.X < 0f && me.charUpdate.traj.X >= 0f) || (traj.X > 0f && me.charUpdate.traj.X <= 0f))
			{
				me.charAnim.SetAnim(meta.fturn_anim, me.charUpdate);
			}
			Vector2 screenLoc = ScrollManager.GetScreenLoc(me.charUpdate.loc, 1f);
			float num = 40f;
			if (screenLoc.X < 0f - num && vector.X > 0f)
			{
				screenLoc.X = 0f - num;
			}
			if (screenLoc.Y < 0f - num && vector.Y > 0f)
			{
				screenLoc.Y = 0f - num;
			}
			if (screenLoc.X > ScrollManager.screenSize.X + num && vector.X < 0f)
			{
				screenLoc.X = ScrollManager.screenSize.X + num;
			}
			if (screenLoc.Y > ScrollManager.screenSize.Y + num && vector.Y < 0f)
			{
				screenLoc.Y = ScrollManager.screenSize.Y + num;
			}
			if (PetType() == 1)
			{
				AI ai = me.ai;
				if (Game1.character[ai.owner].charUpdate.headTop.X > 0f && (Game1.character[ai.owner].charUpdate.headTop - me.charUpdate.loc).LengthSquared() < 100f)
				{
					ai.mount = true;
					me.charAnim.SetAnim(meta.land_anim, me.charUpdate);
					me.charUpdate.loc = Game1.character[ai.owner].charUpdate.headTop;
				}
			}
		}
		if (me.charAnim.animName == "fpuke")
		{
			me.charUpdate.traj = default;
		}
		if (me.charUpdate.state == CharUpdate.State.Grounded || me.ai.mount)
		{
			if (keyChow)
			{
				me.charAnim.SetAnim("chow", me.charUpdate);
			}
			if (keyPukeMagic || keyPukeHearts)
			{
				me.charAnim.SetAnim("puke", me.charUpdate);
			}
		}
		else if (keyPukeMagic || keyPukeHearts)
		{
			me.charAnim.SetAnim("fpuke", me.charUpdate);
		}
		keys.rVec = rVec;
		if (rVec.X < 0f)
		{
			if (!keyLeft && !keyRight && me.charUpdate.face == 1)
			{
				keys.keyLeft = true;
			}
		}
		else if (rVec.X > 0f && !keyLeft && !keyRight && me.charUpdate.face == 0)
		{
			keys.keyRight = true;
		}
	}

	private void ClearKeys()
	{
		keyLeft = false;
		keyRight = false;
		keyJog = false;
		keyWalk = false;
		keyJump = false;
		keyChow = false;
		keyPukeHearts = false;
		keyPukeMagic = false;
		rVec = default;
	}

	public void Update()
	{
		if (!(activeFrame > 0f))
		{
			return;
		}
		activeFrame -= FMan.frameTime;
		ClearKeys();
		Vector2 inputStick = flibitPort.GetInputStick(controllerIdx, flibitPort.InputAction.Move);
		if (inputStick.X < -0.1f)
		{
			keyLeft = true;
			if (inputStick.X > -0.4f)
			{
				keyWalk = true;
			}
			else if (inputStick.X > -0.7f)
			{
				keyJog = true;
			}
		}
		if (inputStick.X > 0.1f)
		{
			keyRight = true;
			if (inputStick.X < 0.4f)
			{
				keyWalk = true;
			}
			else if (inputStick.X < 0.7f)
			{
				keyJog = true;
			}
		}
		if (flibitPort.GetInputClicked(controllerIdx, flibitPort.InputAction.JumpAccept))
		{
			keyJump = true;
		}
		if (flibitPort.GetInputClicked(controllerIdx, flibitPort.InputAction.GrabCancel))
		{
			keyChow = true;
		}
		if (flibitPort.GetInputClicked(controllerIdx, flibitPort.InputAction.Attack))
		{
			keyPukeHearts = true;
			pukeType = 0;
		}
		if (flibitPort.GetInputClicked(controllerIdx, flibitPort.InputAction.StrongSaw))
		{
			keyPukeMagic = true;
			pukeType = 1;
		}
		lVec = flibitPort.GetInputStick(controllerIdx, flibitPort.InputAction.Move);
		rVec = flibitPort.GetInputStick(controllerIdx, flibitPort.InputAction.WarpRoll);
		rVec.Y = 0f - rVec.Y;
		if (rVec.LengthSquared() > 0.09f)
		{
			activeFrame = 10f;
		}
		if (keyLeft || keyRight || keyJump || keyChow || keyPukeHearts || keyPukeMagic || lVec.Y > 0.3f)
		{
			activeFrame = 10f;
		}
	}

	public PetPlayer(int idx)
	{
		ID = idx;
	}

	public int PetType()
	{
		switch (Game1.levelMgr.currentTrack)
		{
		case 0:
			return 0;
		case 1:
			return 1;
		default:
			if (ID == 0)
			{
				return 0;
			}
			return 1;
		}
	}

	internal void Reset()
	{
		activeFrame = -1f;
		chow = 0f;
	}
}
