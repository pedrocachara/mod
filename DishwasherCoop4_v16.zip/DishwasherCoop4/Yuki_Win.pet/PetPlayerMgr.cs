namespace Yuki_Win.pet;

public class PetPlayerMgr
{
	public PetPlayer[] petPlayer;

	public PetPlayerMgr()
	{
		petPlayer = new PetPlayer[2];
		for (int i = 0; i < petPlayer.Length; i++)
		{
			petPlayer[i] = new PetPlayer(i);
		}
	}

	public void Update()
	{
		for (int i = 0; i < 2; i++)
		{
			petPlayer[i].Update();
		}
	}

	internal bool GetOwned(int p)
	{
		return p switch
		{
			2 => petPlayer[0].IsActive(), 
			3 => petPlayer[1].IsActive(), 
			_ => false, 
		};
	}

	public void Reset()
	{
		for (int i = 0; i < petPlayer.Length; i++)
		{
			petPlayer[i].Reset();
		}
	}

	internal PetPlayer GetPlayer(int p)
	{
		if (p == 3)
		{
			return petPlayer[1];
		}
		return petPlayer[0];
	}

	internal void AddChow(int ID)
	{
		ID -= 2;
		if (ID >= 0 && ID < 2)
		{
			petPlayer[ID].chow += 0.3f;
			if (petPlayer[ID].chow > 7f)
			{
				petPlayer[ID].chow = 7f;
			}
		}
	}

	internal int GetPuke(int ID)
	{
		ID -= 2;
		if (ID >= 0 && ID < 2)
		{
			return petPlayer[ID].pukeType;
		}
		return 0;
	}

	internal bool UseChow(int ID, float p)
	{
		ID -= 2;
		if (ID >= 0 && ID < 2 && petPlayer[ID].chow >= p)
		{
			petPlayer[ID].chow -= p;
			return true;
		}
		return false;
	}

	internal float GetChow(int ID)
	{
		ID -= 2;
		if (ID >= 0 && ID < 2)
		{
			return petPlayer[ID].chow;
		}
		return 0f;
	}
}
