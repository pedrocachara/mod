using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;

namespace WorldMapEdit;

public class WorldMap
{
	public List<WorldLevel> levels;

	public string path;

	public WorldMap()
	{
		levels = new List<WorldLevel>();
	}

	public void Write()
	{
		BinaryWriter binaryWriter = new BinaryWriter(File.Open(path, FileMode.OpenOrCreate, FileAccess.Write));
		binaryWriter.Write(levels.Count);
		foreach (WorldLevel level in levels)
		{
			binaryWriter.Write(level.name);
			binaryWriter.Write(level.desc1);
			binaryWriter.Write(level.desc2);
			binaryWriter.Write(level.node.Count);
			foreach (WorldNode item in level.node)
			{
				binaryWriter.Write((int)item.type);
				binaryWriter.Write(item.loc.X);
				binaryWriter.Write(item.loc.Y);
			}
		}
		binaryWriter.Close();
	}

	public void Read()
	{
		BinaryReader binaryReader = new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read));
		levels = new List<WorldLevel>();
		int num = binaryReader.ReadInt32();
		for (int i = 0; i < num; i++)
		{
			WorldLevel worldLevel = new WorldLevel();
			worldLevel.name = binaryReader.ReadString();
			worldLevel.desc1 = binaryReader.ReadString();
			worldLevel.desc2 = binaryReader.ReadString();
			int num2 = binaryReader.ReadInt32();
			for (int j = 0; j < num2; j++)
			{
				WorldNode item = new WorldNode((WorldNode.NodeType)binaryReader.ReadInt32(), new Vector2(binaryReader.ReadSingle(), binaryReader.ReadSingle()));
				worldLevel.node.Add(item);
			}
			levels.Add(worldLevel);
		}
		binaryReader.Close();
	}
}
