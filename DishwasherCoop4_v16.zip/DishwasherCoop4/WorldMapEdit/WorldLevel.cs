using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace WorldMapEdit;

public class WorldLevel
{
	public string name;

	public List<WorldNode> node;

	public string desc1;

	public string desc2;

	public WorldLevel()
	{
		node = new List<WorldNode>();
		name = "new level";
		desc1 = "";
		desc2 = "";
	}

	public void AddNode(WorldNode.NodeType type, Vector2 loc)
	{
		node.Add(new WorldNode(type, loc));
	}

	public bool DeleteNode(WorldNode node)
	{
		return this.node.Remove(node);
	}
}
