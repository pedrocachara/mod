using Microsoft.Xna.Framework;

namespace WorldMapEdit;

public class WorldNode
{
	public enum NodeType
	{
		Dot,
		Boss,
		Mark
	}

	public Vector2 loc;

	public NodeType type;

	public WorldNode(NodeType type, Vector2 loc)
	{
		this.type = type;
		this.loc = loc;
	}
}
