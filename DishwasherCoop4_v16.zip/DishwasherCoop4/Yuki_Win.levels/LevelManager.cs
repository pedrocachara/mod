﻿using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.arcade;
using Yuki_Win.chars;
using Yuki_Win.director;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.world;

namespace Yuki_Win.levels;

public class LevelManager
{
	public enum PlayerType
	{
		Yuki,
		Dishwasher
	}

	public const int YUKI_CAMPAIGN = 0;

	public const int DISH_CAMPAIGN = 1;

	public const int COOP_CAMPAIGN = 2;

	public const int ARCADE = 3;

	public const int DISH_CHALLENGE = 4;

	public const int YUKI_PRACTICE = 5;

	public const int DISH_PRACTICE = 6;

	public float elapsedTime;

	public bool guitarEmpty;

	public Dictionary<int, List<Level>> levels;

	public int currentLevel;

	public int currentTrack;

	public List<string> globalFlags;

	private float[] startHP = new float[4] { -1f, -1f, -1f, -1f };

	private int[] startMP = new int[4] { -1, -1, -1, -1 };

	public void ResetMapEnterVals(int ID)
	{
		startHP[ID] = -1f;
		startMP[ID] = -1;
	}

	public void SetMapEnterVals(int ID, float hp, int mp)
	{
		startHP[ID] = hp;
		startMP[ID] = mp;
	}

	// PvP em fase da campanha: afasta os jogadores um do outro, cada um virado para o centro
	private void PvpSpreadPlayers(Vector2 start)
	{
		Map map = Game1.gameMap.CurMap();
		int n = Game1.coopPlayers;
		for (int i = 0; i < n && i < 4; i++)
		{
			float x = start.X + ((float)i - (float)(n - 1) / 2f) * 200f;
			Vector2 probe = new Vector2(x, start.Y - 64f);
			bool found = false;
			while (probe.Y <= (float)map.ySize * 64f)
			{
				if (map.TestCol(probe, ceils: false, shadow: false, ledge: true))
				{
					found = true;
					break;
				}
				probe.Y += 16f;
			}
			if (found)
			{
				Game1.character[i].FloorMe(new Vector2(x, start.Y - 64f));
			}
			Game1.character[i].charUpdate.face = ((i < n / 2) ? 1 : 0);
		}
	}

	public void Update()
	{
		if (Game1.pvpMatch)
		{
			Game1.arcade.PvpTick();
		}
		if (!Game1.hud.IsEndLevel() && !Game1.hud.IsArcadeIn() && GameState.state != GameState.State.Menu && !Game1.sceneMgr.playing && !Game1.hud.invMgr.IsActive() && !Game1.hud.shopMgr.IsActive())
		{
			elapsedTime += FMan.frameTime;
		}
	}

	public void SetGlobalFlag(string s)
	{
		if (!globalFlags.Contains(s))
		{
			globalFlags.Add(s);
		}
	}

	public bool GetGlobalFlag(string s)
	{
		return globalFlags.Contains(s);
	}

	public LevelManager()
	{
		globalFlags = new List<string>();
		levels = new Dictionary<int, List<Level>>();
		levels[0] = new List<Level>();
		levels[0].Add(new Level(Game1.locs.iffenhauseSpacePrison, "prison", "church1", 0, new Vector2(100f, 300f), Level.SpecialIntro.Getup, null));
		levels[0].Add(new Level(Game1.locs.lunarWastes, "main", "workshop", 6, new Vector2(300f, 300f), Level.SpecialIntro.SawGetup, new string[2] { "yuki", "moon1" }));
		levels[0].Add(new Level(Game1.locs.omodoCrash, "main", "moon11", 7, new Vector2(500f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "bank1" }));
		levels[0].Add(new Level(Game1.locs.omodosExecution, "main", "bank0", 9, new Vector2(800f, 500f), Level.SpecialIntro.None, new string[2] { "yuki", "bank2" }));
		levels[0].Add(new Level(Game1.locs.thePit, "main", "board2", 10, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "crypt1" }));
		levels[0].Add(new Level(Game1.locs.sunkenArmory, "main", "crypt2", 11, new Vector2(900f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "cryptc" }));
		levels[0].Add(new Level(Game1.locs.hellChambers, "main", "crypt8", 12, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "crypt2" }));
		levels[0].Add(new Level(Game1.locs.grimTower, "main", "dark1", 13, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "crypt3" }));
		levels[0].Add(new Level(Game1.locs.landcruiserStadium, "main", "dark14", 14, new Vector2(300f, 300f), Level.SpecialIntro.SawCrazyGetup, new string[2] { "yuki", "tank1" }));
		levels[0].Add(new Level(Game1.locs.forstadtLobby, "main", "tankin6", 15, new Vector2(1200f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "lobby1" }));
		levels[0].Add(new Level(Game1.locs.aquaMarina, "main", "freaky1", 15, new Vector2(1200f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "lobby2" }));
		levels[0].Add(new Level(Game1.locs.justiceSummit, "main", "aqua10", 15, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "lobby3" }));
		levels[0].Add(new Level(Game1.locs.theStagnantNightmare, "dish", "dish1", 15, new Vector2(300f, 300f), Level.SpecialIntro.None, new string[2] { "yuki", "dish1" }));
		levels[1] = new List<Level>();
		levels[1].Add(new Level(Game1.locs.lunarWastes, "main", "workshop", 1, new Vector2(300f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "moon1" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.omodoCrash, "main", "moon11", 2, new Vector2(500f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "bank1" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.omodosExecution, "main", "bank0", 4, new Vector2(800f, 500f), Level.SpecialIntro.None, new string[2] { "dish", "bank2" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.thePit, "main", "board2", 5, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "crypt1" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.sunkenArmory, "main", "crypt2", 6, new Vector2(900f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "cryptc" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.hellChambers, "main", "crypt8", 7, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "crypt2" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.grimTower, "main", "dark1", 8, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "crypt3" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.landcruiserStadium, "main", "dark10", 9, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "tank1" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.forstadtLobby, "main", "tankin6", 10, new Vector2(1200f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "lobby1" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.aquaMarina, "main", "freaky1", 10, new Vector2(1200f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "lobby2" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.justiceSummit, "main", "aqua10", 10, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "lobby3" }, dishwasher: true));
		levels[1].Add(new Level(Game1.locs.theStagnantNightmare, "dish", "dish1", 10, new Vector2(300f, 300f), Level.SpecialIntro.None, new string[2] { "dish", "dish1" }, dishwasher: true));
		levels[2] = new List<Level>();
		levels[2].Add(new Level(YukiText.lunarWastes, "main", "workshop", 6, 1, new Vector2(300f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "moon1" }));
		levels[2].Add(new Level(YukiText.omodoCrash, "main", "moon11", 7, 2, new Vector2(500f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "bank1" }));
		levels[2].Add(new Level(YukiText.omodosExecution, "main", "bank0", 9, 4, new Vector2(800f, 500f), Level.SpecialIntro.None, new string[2] { "coop", "bank2" }));
		levels[2].Add(new Level(YukiText.thePit, "main", "board2", 10, 5, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "crypt1" }));
		levels[2].Add(new Level(YukiText.sunkenArmory, "main", "crypt2", 11, 6, new Vector2(900f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "cryptc" }));
		levels[2].Add(new Level(YukiText.hellChambers, "main", "crypt8", 12, 7, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "crypt2" }));
		levels[2].Add(new Level(YukiText.grimTower, "main", "dark1", 13, 8, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "crypt3" }));
		levels[2].Add(new Level(YukiText.landcruiserStadium, "main", "dark10", 14, 9, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "tank1" }));
		levels[2].Add(new Level(YukiText.forstadtLobby, "main", "tankin6", 15, 10, new Vector2(1200f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "lobby1" }));
		levels[2].Add(new Level(YukiText.aquaMarina, "main", "freaky1", 15, 10, new Vector2(1200f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "lobby2" }));
		levels[2].Add(new Level(YukiText.justiceSummit, "main", "aqua10", 15, 10, new Vector2(600f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "lobby3" }));
		levels[2].Add(new Level(YukiText.theStagnantNightmare, "dish", "dish1", 15, 10, new Vector2(300f, 300f), Level.SpecialIntro.None, new string[2] { "coop", "dish1" }));
		levels[3] = new List<Level>();
		levels[3].Add(new Level(Game1.locs.arcadeTitle[0], Game1.locs.arcadeDesc1[0], Game1.locs.arcadeDesc2[0], "arcade1", Level.ArcadeSpecial.None, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.None, Level.GunMode.None, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[1], Game1.locs.arcadeDesc1[1], Game1.locs.arcadeDesc2[1], "arcade2", Level.ArcadeSpecial.None, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, 2, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.None, Level.GunMode.SMG, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[2], Game1.locs.arcadeDesc1[2], Game1.locs.arcadeDesc2[2], "arcade3", Level.ArcadeSpecial.None, 2, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.TheGuillotine, 3, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.TheGuillotine, Level.ArcadeMagic.None, Level.GunMode.SMG, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[3], Game1.locs.arcadeDesc1[3], Game1.locs.arcadeDesc2[3], "arcade4", Level.ArcadeSpecial.None, 1, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.ViolenceHammer, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.None, Level.GunMode.SMG, 3));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[4], Game1.locs.arcadeDesc1[4], Game1.locs.arcadeDesc2[4], "arcade5", Level.ArcadeSpecial.Blitz, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 3, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.None, Level.GunMode.SMG, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[5], Game1.locs.arcadeDesc1[5], Game1.locs.arcadeDesc2[5], "arcade6", Level.ArcadeSpecial.Instakill, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.None, 3, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.None, Level.ArcadeMagic.None, Level.GunMode.SMG, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[6], Game1.locs.arcadeDesc1[6], Game1.locs.arcadeDesc2[6], "arcade36", Level.ArcadeSpecial.HotPotato, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.Painkiller, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, Level.ArcadeMagic.Electric, Level.GunMode.SMG, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[7], Game1.locs.arcadeDesc1[7], Game1.locs.arcadeDesc2[7], "arcade7", Level.ArcadeSpecial.Vampire, 3, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.TheGuillotine, 4, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.Kamakazi, Level.ArcadeMagic.None, Level.GunMode.SMG, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[8], Game1.locs.arcadeDesc1[8], Game1.locs.arcadeDesc2[8], "arcade8", Level.ArcadeSpecial.Aerials, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, 3, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.None, Level.GunMode.SMG, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[9], Game1.locs.arcadeDesc1[9], Game1.locs.arcadeDesc2[9], "arcade9", Level.ArcadeSpecial.Slow, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.Kamakazi, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.None, Level.GunMode.SMG, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[10], Game1.locs.arcadeDesc1[10], Game1.locs.arcadeDesc2[10], "arcade10", Level.ArcadeSpecial.None, 1, InvCatalog.InvItemName.ViolenceHammer, InvCatalog.InvItemName.MeatCleavers, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Steel, Level.GunMode.SMG, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[11], Game1.locs.arcadeDesc1[11], Game1.locs.arcadeDesc2[11], "arcade11", Level.ArcadeSpecial.HotPotato, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Holy, Level.GunMode.SMG, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[12], Game1.locs.arcadeDesc1[12], Game1.locs.arcadeDesc2[12], "arcade12", Level.ArcadeSpecial.Vampire, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 3, InvCatalog.InvItemName.ViolenceHammer, InvCatalog.InvItemName.TheGuillotine, Level.ArcadeMagic.Electric, Level.GunMode.SMG, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[13], Game1.locs.arcadeDesc1[13], Game1.locs.arcadeDesc2[13], "arcade13", Level.ArcadeSpecial.Blitz, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.Painkiller, 3, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Devouring, Level.GunMode.SMG, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[14], Game1.locs.arcadeDesc1[14], Game1.locs.arcadeDesc2[14], "arcade14", Level.ArcadeSpecial.None, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 4, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.Painkiller, Level.ArcadeMagic.Holy, Level.GunMode.SMG, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[15], Game1.locs.arcadeDesc1[15], Game1.locs.arcadeDesc2[15], "arcade37", Level.ArcadeSpecial.Blitz, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, 0, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Steel, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[16], Game1.locs.arcadeDesc1[16], Game1.locs.arcadeDesc2[16], "arcade38", Level.ArcadeSpecial.Vampire, 2, InvCatalog.InvItemName.ViolenceHammer, InvCatalog.InvItemName.MeatCleavers, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.Painkiller, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[17], Game1.locs.arcadeDesc1[17], Game1.locs.arcadeDesc2[17], "arcade42", Level.ArcadeSpecial.Aerials, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, 3, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[18], Game1.locs.arcadeDesc1[18], Game1.locs.arcadeDesc2[18], "arcade16", Level.ArcadeSpecial.Blitz, 2, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.MeatCleavers, 3, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Steel, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[19], Game1.locs.arcadeDesc1[19], Game1.locs.arcadeDesc2[19], "arcade17", Level.ArcadeSpecial.NomNom, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.None, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.None, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[20], Game1.locs.arcadeDesc1[20], Game1.locs.arcadeDesc2[20], "arcade18", Level.ArcadeSpecial.Slow, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.Painkiller, Level.ArcadeMagic.Steel, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[21], Game1.locs.arcadeDesc1[21], Game1.locs.arcadeDesc2[21], "arcade19", Level.ArcadeSpecial.Instakill, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.None, 1, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.None, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[22], Game1.locs.arcadeDesc1[22], Game1.locs.arcadeDesc2[22], "arcade20", Level.ArcadeSpecial.Vampire, 4, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, 3, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 3));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[23], Game1.locs.arcadeDesc1[23], Game1.locs.arcadeDesc2[23], "arcade21", Level.ArcadeSpecial.TurboBlitz, 2, InvCatalog.InvItemName.ViolenceHammer, InvCatalog.InvItemName.None, 3, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.None, Level.ArcadeMagic.None, Level.GunMode.Shotty, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[24], Game1.locs.arcadeDesc1[24], Game1.locs.arcadeDesc2[24], "arcade22", Level.ArcadeSpecial.CrackingSkull, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 2, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[25], Game1.locs.arcadeDesc1[25], Game1.locs.arcadeDesc2[25], "arcade23", Level.ArcadeSpecial.Blitz, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[26], Game1.locs.arcadeDesc1[26], Game1.locs.arcadeDesc2[26], "arcade24", Level.ArcadeSpecial.Slow, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[27], Game1.locs.arcadeDesc1[27], Game1.locs.arcadeDesc2[27], "arcade25", Level.ArcadeSpecial.Vampire, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, Level.ArcadeMagic.Steel, Level.GunMode.Shotty, 3));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[28], Game1.locs.arcadeDesc1[28], Game1.locs.arcadeDesc2[28], "arcade39", Level.ArcadeSpecial.Blitz, 3, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.TheGuillotine, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[29], Game1.locs.arcadeDesc1[29], Game1.locs.arcadeDesc2[29], "arcade26", Level.ArcadeSpecial.HotPotato, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.Painkiller, 3, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.Dekkentozter, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[30], Game1.locs.arcadeDesc1[30], Game1.locs.arcadeDesc2[30], "arcade27", Level.ArcadeSpecial.Instakill, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.None, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.None, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[31], Game1.locs.arcadeDesc1[31], Game1.locs.arcadeDesc2[31], "arcade28", Level.ArcadeSpecial.None, 2, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.TheGuillotine, 3, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.TheGuillotine, Level.ArcadeMagic.Steel, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[32], Game1.locs.arcadeDesc1[32], Game1.locs.arcadeDesc2[32], "arcade29", Level.ArcadeSpecial.Blitz, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.Painkiller, 4, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[33], Game1.locs.arcadeDesc1[33], Game1.locs.arcadeDesc2[33], "arcade30", Level.ArcadeSpecial.Aerials, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.None, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.None, Level.ArcadeMagic.Steel, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[34], Game1.locs.arcadeDesc1[34], Game1.locs.arcadeDesc2[34], "arcade43", Level.ArcadeSpecial.Blitz, 4, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, 2, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.Dekkentozter, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[35], Game1.locs.arcadeDesc1[35], Game1.locs.arcadeDesc2[35], "arcade15", Level.ArcadeSpecial.HotPotato, 3, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.MeatCleavers, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 3));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[36], Game1.locs.arcadeDesc1[36], Game1.locs.arcadeDesc2[36], "arcade31", Level.ArcadeSpecial.Vampire, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 3, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[37], Game1.locs.arcadeDesc1[37], Game1.locs.arcadeDesc2[37], "arcade32", Level.ArcadeSpecial.Blitz, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, 4, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[38], Game1.locs.arcadeDesc1[38], Game1.locs.arcadeDesc2[38], "arcade44", Level.ArcadeSpecial.Instakill, 1, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.None, 3, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.None, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[39], Game1.locs.arcadeDesc1[39], Game1.locs.arcadeDesc2[39], "arcade33", Level.ArcadeSpecial.None, 2, InvCatalog.InvItemName.Dekkentozter, InvCatalog.InvItemName.None, 3, InvCatalog.InvItemName.Dekkentozter, InvCatalog.InvItemName.None, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 5));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[40], Game1.locs.arcadeDesc1[40], Game1.locs.arcadeDesc2[40], "arcade45", Level.ArcadeSpecial.Blitz, 0, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.Painkiller, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Steel, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[41], Game1.locs.arcadeDesc1[41], Game1.locs.arcadeDesc2[41], "arcade34", Level.ArcadeSpecial.HotPotato, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.Painkiller, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[42], Game1.locs.arcadeDesc1[42], Game1.locs.arcadeDesc2[42], "arcade35", Level.ArcadeSpecial.Instakill, 2, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.None, 3, InvCatalog.InvItemName.MeatCleavers, InvCatalog.InvItemName.None, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 1));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[43], Game1.locs.arcadeDesc1[43], Game1.locs.arcadeDesc2[43], "arcade46", Level.ArcadeSpecial.None, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 3, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[44], Game1.locs.arcadeDesc1[44], Game1.locs.arcadeDesc2[44], "arcade40", Level.ArcadeSpecial.None, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.Painkiller, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 3));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[45], Game1.locs.arcadeDesc1[45], Game1.locs.arcadeDesc2[45], "arcade47", Level.ArcadeSpecial.Vampire, 2, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, 3, InvCatalog.InvItemName.TheGuillotine, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[46], Game1.locs.arcadeDesc1[46], Game1.locs.arcadeDesc2[46], "arcade41", Level.ArcadeSpecial.HotPotato, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.TheGuillotine, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 7));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[47], Game1.locs.arcadeDesc1[47], Game1.locs.arcadeDesc2[47], "arcade48", Level.ArcadeSpecial.None, 0, InvCatalog.InvItemName.Kamakazi, InvCatalog.InvItemName.Painkiller, 4, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Devouring, Level.GunMode.Shotty, 8));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[48], Game1.locs.arcadeDesc1[48], Game1.locs.arcadeDesc2[48], "arcade49", Level.ArcadeSpecial.None, 4, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, 3, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.ViolenceHammer, Level.ArcadeMagic.Electric, Level.GunMode.Shotty, 3));
		levels[3].Add(new Level(Game1.locs.arcadeTitle[49], Game1.locs.arcadeDesc1[49], Game1.locs.arcadeDesc2[49], "arcade50", Level.ArcadeSpecial.None, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 11));
		levels[4] = new List<Level>();
		levels[4].Add(new Level(Game1.locs.dishChallenge, Game1.locs.dishChallengeDesc, new StringBuilder(""), "dishchallenge", Level.ArcadeSpecial.None, 1, InvCatalog.InvItemName.ShiftBlade, InvCatalog.InvItemName.MeatCleavers, 0, InvCatalog.InvItemName.Conviction, InvCatalog.InvItemName.CloudSword, Level.ArcadeMagic.Holy, Level.GunMode.Shotty, 7));
		levels[6] = new List<Level>();
		levels[6].Add(new Level(Game1.locs.practiceRoom, "main", "practice", 0, new Vector2(300f, 300f), Level.SpecialIntro.None, null));
		levels[5] = new List<Level>();
		levels[5].Add(new Level(Game1.locs.practiceRoom, "main", "practice", 4, new Vector2(300f, 300f), Level.SpecialIntro.None, null));
	}

	public void Continue()
	{
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Asylum)
		{
			string map = Game1.gameMap.CurMap().scriptMgr.AutoDesylum();
			Game1.gameMap.SetMap(map);
		}
		bool flag = false;
		if (Game1.transMgr.enterMap != null)
		{
			WorldManager.curWorld = Game1.transMgr.enterWorld;
			Game1.gameMap.SetMap(Game1.transMgr.enterMap);
			flag = true;
		}
		if (Game1.gameMap.CurMap().scriptMgr.resetNecessary)
		{
			Game1.gameMap.CurMap().Read();
		}
		Game1.gameMap.CurMap().Reset();
		MainPlayer.uberDyingFrame = 0f;
		Init(levels[currentTrack][currentLevel], newLevel: false, newGame: false);
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
		{
			for (int i = 0; i < Game1.arcade.players; i++)
			{
				InitArcadePlayer(i);
			}
			Game1.arcade.Init();
		}
		else
		{
			for (int j = 0; j < 4; j++)
			{
				if (Game1.character[j].exists)
				{
					Game1.character[j].charUpdate.loc = Game1.transMgr.enterVec;
					Game1.character[j].charUpdate.face = Game1.transMgr.enterFace;
					Game1.character[j].charUpdate.state = Game1.transMgr.enterState;
					if (Game1.character[j].charUpdate.state == CharUpdate.State.Grounded)
					{
						Game1.character[j].charAnim.SetAnim(Game1.character[j].GetMeta().idle_anim, Game1.character[j].charUpdate);
					}
					else
					{
						Game1.character[j].charAnim.SetAnim(Game1.character[j].GetMeta().fly_anim, Game1.character[j].charUpdate);
					}
				}
			}
		}
		if (flag)
		{
			Game1.gameMap.CurMap().scriptMgr.Update();
			if (Game1.gameMap.theme.theme == Themes.ThemeType.Asylum)
			{
				Character character = Game1.character[0];
				character.charMeta = (character.charAnim.charMeta = 10);
				if (Game1.player.yukiPhase >= 6)
				{
					character.charMeta = (character.charAnim.charMeta = 22);
				}
				if (Game1.player.yukiPhase >= 13)
				{
					character.charMeta = (character.charAnim.charMeta = 85);
				}
				character.cDef = (character.charAnim.charDef = 6);
				character.charAnim.SetAnim(character.GetMeta().idle_anim, character.charUpdate);
			}
		}
		GameState.state = GameState.State.Playing;
		Game1.transMgr.levelInFrame = 2f;
	}

	private void InitArcadePlayer(int ID)
	{
		Level level = levels[currentTrack][currentLevel];
		int src = Game1.arcade.GetLevelSrc(level, ID);
		int forcedType = -1;
		if (Game1.arcade.players >= 2 && Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
		{
			int pickA = Game1.slotChar[ID];
			forcedType = ((pickA == 0) ? 0 : ((pickA == 1) ? 1 : ((pickA == 2) ? 4 : 3)));
		}
		Game1.gamePlayerMgr.gamePlayer[ID].score = 0L;
		Game1.gamePlayerMgr.gamePlayer[ID].totalKills = 0;
		Game1.gamePlayerMgr.gamePlayer[ID].maxCombos = 0;
		Game1.gamePlayerMgr.gamePlayer[ID].comboFrame = 0f;
		Game1.gamePlayerMgr.gamePlayer[ID].comboCashFrame = 0f;
		Game1.gamePlayerMgr.gamePlayer[ID].scoreFrame = 0f;
		Game1.arcade.player[ID] = ((forcedType >= 0) ? forcedType : level.arcadePlayer[src]);
		Level level2 = levels[3][currentLevel];
		if (currentTrack == 4)
		{
			level2 = levels[4][0];
		}
		int charMeta;
		switch (Game1.arcade.player[ID])
		{
		case 1:
			charMeta = 5;
			switch (level2.arcadeWeapon[src, 0])
			{
			case InvCatalog.InvItemName.ShiftBlade:
				charMeta = 5;
				break;
			case InvCatalog.InvItemName.MeatCleavers:
				charMeta = 16;
				break;
			case InvCatalog.InvItemName.ViolenceHammer:
				charMeta = 15;
				break;
			case InvCatalog.InvItemName.TheGuillotine:
				charMeta = 24;
				break;
			case InvCatalog.InvItemName.Dekkentozter:
				charMeta = 26;
				break;
			}
			break;
		case 2:
			charMeta = 27;
			switch (level2.arcadeWeapon[src, 0])
			{
			case InvCatalog.InvItemName.ShiftBlade:
				charMeta = 27;
				break;
			case InvCatalog.InvItemName.MeatCleavers:
				charMeta = 29;
				break;
			case InvCatalog.InvItemName.ViolenceHammer:
				charMeta = 28;
				break;
			case InvCatalog.InvItemName.TheGuillotine:
				charMeta = 30;
				break;
			case InvCatalog.InvItemName.Dekkentozter:
				charMeta = 31;
				break;
			}
			break;
		case 3:
			charMeta = 32;
			switch (level2.arcadeWeapon[src, 0])
			{
			case InvCatalog.InvItemName.ShiftBlade:
				charMeta = 32;
				break;
			case InvCatalog.InvItemName.MeatCleavers:
				charMeta = 34;
				break;
			case InvCatalog.InvItemName.ViolenceHammer:
				charMeta = 33;
				break;
			case InvCatalog.InvItemName.TheGuillotine:
				charMeta = 35;
				break;
			case InvCatalog.InvItemName.Dekkentozter:
				charMeta = 36;
				break;
			}
			break;
		case 4:
			charMeta = 37;
			switch (level2.arcadeWeapon[src, 0])
			{
			case InvCatalog.InvItemName.Claws:
				charMeta = 79;
				break;
			case InvCatalog.InvItemName.Conviction:
				charMeta = 37;
				break;
			case InvCatalog.InvItemName.Kamakazi:
				charMeta = 38;
				break;
			case InvCatalog.InvItemName.CloudSword:
				charMeta = 39;
				break;
			case InvCatalog.InvItemName.Painkiller:
				charMeta = 76;
				break;
			}
			break;
		default:
			charMeta = 0;
			switch (level2.arcadeWeapon[src, 0])
			{
			case InvCatalog.InvItemName.Claws:
				charMeta = 78;
				break;
			case InvCatalog.InvItemName.Conviction:
				charMeta = 0;
				break;
			case InvCatalog.InvItemName.Kamakazi:
				charMeta = 2;
				break;
			case InvCatalog.InvItemName.CloudSword:
				charMeta = 25;
				break;
			case InvCatalog.InvItemName.Painkiller:
				charMeta = 46;
				break;
			}
			break;
		}
		int cDef;
		switch (Game1.arcade.player[ID])
		{
		case 1:
		case 2:
		case 3:
			cDef = 3;
			Game1.gamePlayerMgr.gamePlayer[ID].loadOut[0].weapon[0] = level.arcadeWeapon[src, 0];
			Game1.gamePlayerMgr.gamePlayer[ID].loadOut[0].weapon[1] = level.arcadeWeapon[src, 1];
			break;
		default:
			cDef = 0;
			Game1.gamePlayerMgr.gamePlayer[ID].loadOut[0].weapon[0] = level.arcadeWeapon[src, 0];
			Game1.gamePlayerMgr.gamePlayer[ID].loadOut[0].weapon[1] = level.arcadeWeapon[src, 1];
			break;
		}
		Game1.character[ID].loadOut = 0;
		Game1.character[ID].weapIdx = 0;
		float num = (float)Game1.gameMap.CurMap().xSize * 64f * 0.5f;
		if (Game1.arcade.players >= 2)
		{
			num += ((float)ID - ((float)Game1.arcade.players - 1f) / 2f) * (Game1.pvpMatch ? 320f : 100f);
		}
		float num2 = 64f * (float)Game1.gameMap.CurMap().ySize;
		bool flag = false;
		while (!flag)
		{
			num2 -= 32f;
			if (!Game1.gameMap.CurMap().TestCol(new Vector2(num, num2)))
			{
				num2 = Game1.gameMap.CurMap().GetMaxY(new Vector2(num, num2));
				flag = true;
			}
			if (num2 < 0f)
			{
				num2 = 300f;
				flag = true;
			}
		}
		Game1.character[ID].Init(cDef, new Vector2(num, num2), charMeta, 0, Character.Team.GoodGuys, -1);
		Game1.character[ID].FloorMe(Game1.character[ID].charUpdate.loc);
		Game1.character[ID].charKeys.idx = ID;
		if (Game1.netSession.IsClient() && ID == 1)
		{
			Game1.character[ID].charKeys.idx = 0;
		}
		Game1.character[ID].charUpdate.mp = 0;
		Game1.player.yukiPhase = 15;
		Game1.player.dishPhase = 10;
		if (!Game1.pvpMatch || Game1.pvpRound <= 1)
		{
			Game1.hud.arcadeIn.Init();
		}
	}

	private void SetDefaultLoadout(int ID, PlayerType type)
	{
		Game1.gamePlayerMgr.gamePlayer[ID].ResetLoadout();
		Game1.character[ID].loadOut = 0;
		Game1.character[ID].weapIdx = 0;
		switch (type)
		{
		case PlayerType.Yuki:
			switch (Game1.player.yukiPhase)
			{
			case 0:
			{
				for (int n = 0; n < 2; n++)
				{
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(n, 0, InvCatalog.InvItemName.ShiftBlade, 0);
				}
				for (int num = 0; num < 2; num++)
				{
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(num, 1, InvCatalog.InvItemName.MeatCleavers, 0);
				}
				break;
			}
			case 2:
			{
				for (int m = 0; m < 2; m++)
				{
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(m, 0, InvCatalog.InvItemName.Claws, 0);
				}
				break;
			}
			default:
			{
				for (int k = 0; k < 2; k++)
				{
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(k, 0, InvCatalog.InvItemName.Conviction, 0);
				}
				if (Game1.player.yukiPhase >= 7)
				{
					for (int l = 0; l < 2; l++)
					{
						Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(l, 1, InvCatalog.InvItemName.CloudSword, 0);
					}
				}
				break;
			}
			case 1:
				break;
			}
			break;
		case PlayerType.Dishwasher:
		{
			for (int i = 0; i < 2; i++)
			{
				Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(i, 0, InvCatalog.InvItemName.ShiftBlade, 0);
			}
			for (int j = 0; j < 2; j++)
			{
				Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(j, 1, InvCatalog.InvItemName.MeatCleavers, 0);
			}
			if (GameState.paxDemoMode || GameState.longDemoMode)
			{
				Game1.gamePlayerMgr.gamePlayer[ID].loadOut[1].weapon[0] = InvCatalog.InvItemName.TheGuillotine;
				Game1.gamePlayerMgr.gamePlayer[ID].loadOut[1].weapon[1] = InvCatalog.InvItemName.ViolenceHammer;
			}
			break;
		}
		}
	}

	// Coop 4P: aplica a skin (Hargreaves/Mara) escolhida no menu para os slots 3 e 4.
	private void ApplyCoopSkin(int ID)
	{
		int ch = Game1.slotChar[ID];
		int cur = Game1.character[ID].charMeta;
		int skin = cur;
		if (ch == 3)
		{
			switch (cur)
			{
			case 5: skin = 32; break;
			case 15: skin = 33; break;
			case 16: skin = 34; break;
			case 24: skin = 35; break;
			case 26: skin = 36; break;
			}
		}
		else if (ch == 2)
		{
			switch (cur)
			{
			case 0: skin = 37; break;
			case 2: skin = 38; break;
			case 25: skin = 39; break;
			case 46: skin = 76; break;
			case 78: skin = 79; break;
			}
		}
		if (skin != cur)
		{
			Game1.character[ID].charMeta = skin;
			Game1.character[ID].charAnim.charMeta = skin;
		}
	}

	private void InitPlayer(int ID, PlayerType type, bool newLevel, bool newGame)
	{
		Level level = levels[currentTrack][currentLevel];
		switch (type)
		{
		case PlayerType.Yuki:
			if (newLevel)
			{
				Game1.player.yukiPhase = level.yukiPhase;
			}
			switch (Game1.player.yukiPhase)
			{
			case 0:
				Game1.character[ID].Init(3, level.startLoc, 92, 0, Character.Team.GoodGuys, -1);
				break;
			case 1:
				Game1.character[ID].Init(7, level.startLoc, 11, 0, Character.Team.GoodGuys, -1);
				break;
			case 2:
			case 3:
				Game1.character[ID].Init(0, level.startLoc, 78, 0, Character.Team.GoodGuys, -1);
				break;
			default:
				if (currentTrack == 5)
				{
					if (Game1.gamePlayerMgr.gamePlayer[ID].highestYukiPhase <= 2)
					{
						Game1.character[ID].Init(0, level.startLoc, 78, 0, Character.Team.GoodGuys, -1);
					}
					else
					{
						Game1.character[ID].Init(0, level.startLoc, 0, 0, Character.Team.GoodGuys, -1);
					}
				}
				else
				{
					Game1.character[ID].Init(0, level.startLoc, 0, 0, Character.Team.GoodGuys, -1);
				}
				break;
			}
			if (level.yukiPhase < 8)
			{
				if (level.yukiPhase < 6)
				{
					Game1.character[ID].charRender.machine = 0;
					if (currentTrack == 5)
					{
						Game1.player.yukiPhase = Game1.gamePlayerMgr.gamePlayer[0].highestYukiPhase;
						if (Game1.gamePlayerMgr.gamePlayer[0].highestYukiPhase >= 6)
						{
							Game1.character[ID].charRender.machine = 1;
						}
					}
				}
				else
				{
					Game1.character[ID].charRender.machine = 1;
				}
			}
			Game1.character[ID].charUpdate.face = 1;
			Game1.character[ID].FloorMe(level.startLoc);
			if (newLevel)
			{
				switch (level.intro)
				{
				case Level.SpecialIntro.Getup:
					Game1.character[ID].charAnim.SetAnim("getup", Game1.character[ID].charUpdate);
					break;
				case Level.SpecialIntro.SawGetup:
					Game1.character[ID].charAnim.SetAnim("screamup", Game1.character[ID].charUpdate);
					break;
				case Level.SpecialIntro.SawCrazyGetup:
					Game1.character[ID].charAnim.SetAnim("screamup", Game1.character[ID].charUpdate);
					QuakeManager.SetBright(1f);
					break;
				}
			}
			break;
		case PlayerType.Dishwasher:
			if (newLevel)
			{
				Game1.player.dishPhase = level.dishPhase;
			}
			_ = level.dishPhase;
			Game1.character[ID].Init(3, level.startLoc, 5, 0, Character.Team.GoodGuys, -1);
			Game1.character[ID].charUpdate.face = 1;
			Game1.character[ID].FloorMe(level.startLoc);
			if (currentTrack == 6)
			{
				Game1.player.dishPhase = Game1.gamePlayerMgr.gamePlayer[0].highestDishPhase;
			}
			break;
		}
		SetLoadoutFromData(ID, type);
		switch (type)
		{
		case PlayerType.Yuki:
			switch (level.yukiPhase)
			{
			default:
				switch (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[0].weapon[0])
				{
				case InvCatalog.InvItemName.Conviction:
					Game1.character[ID].charMeta = 0;
					break;
				case InvCatalog.InvItemName.Kamakazi:
					Game1.character[ID].charMeta = 2;
					break;
				case InvCatalog.InvItemName.CloudSword:
					Game1.character[ID].charMeta = 25;
					break;
				case InvCatalog.InvItemName.Painkiller:
					Game1.character[ID].charMeta = 46;
					break;
				}
				if (newLevel)
				{
					switch (level.intro)
					{
					default:
						Game1.character[ID].charAnim.SetAnim(Game1.character[ID].GetMeta().idle_anim, Game1.character[ID].charUpdate);
						break;
					case Level.SpecialIntro.Getup:
					case Level.SpecialIntro.SawGetup:
					case Level.SpecialIntro.SawCrazyGetup:
						break;
					}
				}
				break;
			case 0:
			case 1:
			case 2:
				break;
			}
			break;
		case PlayerType.Dishwasher:
			switch (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[0].weapon[0])
			{
			case InvCatalog.InvItemName.ShiftBlade:
				Game1.character[ID].charMeta = 5;
				break;
			case InvCatalog.InvItemName.MeatCleavers:
				Game1.character[ID].charMeta = 16;
				break;
			case InvCatalog.InvItemName.ViolenceHammer:
				Game1.character[ID].charMeta = 15;
				break;
			case InvCatalog.InvItemName.TheGuillotine:
				Game1.character[ID].charMeta = 24;
				break;
			case InvCatalog.InvItemName.Dekkentozter:
				Game1.character[ID].charMeta = 26;
				break;
			}
			if (newLevel)
			{
				Game1.character[ID].charAnim.SetAnim(Game1.character[ID].GetMeta().idle_anim, Game1.character[ID].charUpdate);
			}
			break;
		}
		Game1.character[ID].charKeys.idx = ID;
		if (Game1.netSession.IsClient() && ID == 1)
		{
			Game1.character[ID].charKeys.idx = 0;
		}
		Game1.character[ID].SetUpgradeHealth(fill: true);
		Game1.character[ID].SetUpgradeMagic(fill: true);
		Game1.spawnMgr.SpawnFamiliar(ID);
		Game1.character[ID].loadOut = 0;
		Game1.character[ID].weapIdx = 0;
		if (newGame || newLevel)
		{
			ResetMapEnterVals(ID);
			return;
		}
		if (startHP[ID] > 0f)
		{
			Game1.character[ID].charUpdate.hp = startHP[ID];
		}
		if (startMP[ID] > 0)
		{
			Game1.character[ID].charUpdate.mp = startMP[ID];
		}
	}

	private void SetLoadoutFromData(int ID, PlayerType type)
	{
		switch (type)
		{
		case PlayerType.Yuki:
		{
			for (int k = 0; k < 2; k++)
			{
				for (int l = 0; l < 2; l++)
				{
					switch (Game1.gamePlayerMgr.gamePlayer[ID].yukiLoadOut[k].weapon[l])
					{
					default:
						if (l == 0)
						{
							if (Game1.player.yukiPhase >= 4)
							{
								Game1.gamePlayerMgr.gamePlayer[ID].yukiLoadOut[k].weapon[l] = InvCatalog.InvItemName.Conviction;
							}
							else
							{
								Game1.gamePlayerMgr.gamePlayer[ID].yukiLoadOut[k].weapon[l] = InvCatalog.InvItemName.Claws;
							}
						}
						else if (Game1.player.yukiPhase >= 7)
						{
							Game1.gamePlayerMgr.gamePlayer[ID].yukiLoadOut[k].weapon[l] = InvCatalog.InvItemName.CloudSword;
						}
						else
						{
							Game1.gamePlayerMgr.gamePlayer[ID].yukiLoadOut[k].weapon[l] = InvCatalog.InvItemName.None;
						}
						break;
					case InvCatalog.InvItemName.None:
					case InvCatalog.InvItemName.Conviction:
					case InvCatalog.InvItemName.Kamakazi:
					case InvCatalog.InvItemName.CloudSword:
					case InvCatalog.InvItemName.Painkiller:
					case InvCatalog.InvItemName.Claws:
						break;
					}
					Game1.gamePlayerMgr.gamePlayer[ID].loadOut[k].weapon[l] = Game1.gamePlayerMgr.gamePlayer[ID].yukiLoadOut[k].weapon[l];
				}
				switch (Game1.player.yukiPhase)
				{
				case 0:
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(k, 0, InvCatalog.InvItemName.ShiftBlade, 0);
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(k, 1, InvCatalog.InvItemName.MeatCleavers, 0);
					break;
				case 2:
				case 3:
					if (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[k].weapon[0] == InvCatalog.InvItemName.None)
					{
						Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(k, 0, InvCatalog.InvItemName.Claws, ID);
					}
					break;
				case 4:
				case 5:
				case 6:
					if (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[k].weapon[0] == InvCatalog.InvItemName.None)
					{
						Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(k, 0, InvCatalog.InvItemName.Conviction, ID);
					}
					break;
				default:
					if (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[k].weapon[0] == InvCatalog.InvItemName.None)
					{
						Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(k, 0, InvCatalog.InvItemName.Conviction, ID);
					}
					if (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[k].weapon[1] == InvCatalog.InvItemName.None)
					{
						Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(k, 1, InvCatalog.InvItemName.CloudSword, ID);
					}
					break;
				case 1:
					break;
				}
				if (Game1.player.yukiPhase >= 4 && Game1.gamePlayerMgr.gamePlayer[ID].loadOut[k].weapon[0] == InvCatalog.InvItemName.Claws)
				{
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(k, 0, InvCatalog.InvItemName.Conviction, ID);
				}
			}
			break;
		}
		case PlayerType.Dishwasher:
		{
			for (int i = 0; i < 2; i++)
			{
				for (int j = 0; j < 2; j++)
				{
					switch (Game1.gamePlayerMgr.gamePlayer[ID].dishLoadOut[i].weapon[j])
					{
					default:
						if (j == 0)
						{
							Game1.gamePlayerMgr.gamePlayer[ID].yukiLoadOut[i].weapon[j] = InvCatalog.InvItemName.ShiftBlade;
						}
						else
						{
							Game1.gamePlayerMgr.gamePlayer[ID].yukiLoadOut[i].weapon[j] = InvCatalog.InvItemName.MeatCleavers;
						}
						break;
					case InvCatalog.InvItemName.None:
					case InvCatalog.InvItemName.ShiftBlade:
					case InvCatalog.InvItemName.MeatCleavers:
					case InvCatalog.InvItemName.ViolenceHammer:
					case InvCatalog.InvItemName.TheGuillotine:
					case InvCatalog.InvItemName.Dekkentozter:
						break;
					}
					Game1.gamePlayerMgr.gamePlayer[ID].loadOut[i].weapon[j] = Game1.gamePlayerMgr.gamePlayer[ID].dishLoadOut[i].weapon[j];
				}
				if (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[i].weapon[0] == InvCatalog.InvItemName.None)
				{
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(i, 0, InvCatalog.InvItemName.ShiftBlade, ID);
				}
				if (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[i].weapon[1] == InvCatalog.InvItemName.None)
				{
					Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(i, 1, InvCatalog.InvItemName.MeatCleavers, ID);
				}
			}
			break;
		}
		}
	}

	private void Init(Level level, bool newLevel, bool newGame)
	{
		Game1.hud.ResetEndLevel();
		Game1.hud.arcadeIn.active = false;
		Game1.hud.shopMgr.Clear();
		Game1.hud.ClearTut();
		if (newGame)
		{
			Game1.spriteMan.goreInstanceMgr.Reset();
		}
		for (int i = 0; i < Game1.character.Length; i++)
		{
			Game1.character[i].exists = false;
		}
		Game1.spriteMan.Reset();
		if (currentTrack == 5 || currentTrack == 6)
		{
			Game1.practice.nodeCount = 0;
		}
		switch (level.levelType)
		{
		case Level.LevelType.YukiLevel:
			InitPlayer(0, PlayerType.Yuki, newLevel, newGame);
			break;
		case Level.LevelType.DishLevel:
			InitPlayer(0, PlayerType.Dishwasher, newLevel, newGame);
			break;
		case Level.LevelType.CoopLevel:
			for (int cp = 0; cp < Game1.coopPlayers; cp++)
			{
				int pick = Game1.slotChar[cp];
				bool yukiType = pick == 0 || pick == 2;
				if (cp >= 2 && newGame)
				{
					Game1.gamePlayerMgr.CopyPlayer(yukiType ? 0 : 1, cp);
				}
				InitPlayer(cp, yukiType ? PlayerType.Yuki : PlayerType.Dishwasher, newLevel, newGame);
				ApplyCoopSkin(cp);
			}
			if (Game1.pvpMatch)
			{
				PvpSpreadPlayers(level.startLoc);
			}
			break;
		case Level.LevelType.ArcadeLevel:
		{
			for (int j = 0; j < Game1.arcade.players; j++)
			{
				InitArcadePlayer(j);
			}
			Game1.arcade.Init();
			break;
		}
		}
		GameState.state = GameState.State.Playing;
		Game1.transMgr.levelInFrame = 2f;
		Game1.sceneMgr.Reset();
	}

	public void NewLevel(int currentlevel, int currentTrack)
	{
		NewLevel(currentlevel, currentTrack, newGame: false);
	}

	public void NewLevel(int currentlevel, int currentTrack, bool newGame)
	{
		Game1.hud.ResetInv();
		this.currentTrack = currentTrack;
		globalFlags.Clear();
		Game1.soloMgr.Reset();
		Game1.gamePlayerMgr.ResetGamertags();
		if (GameState.paxDemoMode || GameState.longDemoMode)
		{
			MainPlayer.ClearUberFlags();
		}
		Game1.petPlayerMgr.Reset();
		currentLevel = currentlevel;
		_ = currentLevel;
		_ = levels[currentTrack].Count;
		Level level = levels[currentTrack][currentLevel];
		MainPlayer.uberDyingFrame = 0f;
		Game1.hud.PickupDeathReset();
		WorldManager.curWorld = level.world;
		Game1.gameMap.SetMap(level.map);
		Game1.player.levelType = level.levelType;
		for (int i = 0; i < Game1.gamePlayerMgr.gamePlayer.Length; i++)
		{
			Game1.gamePlayerMgr.gamePlayer[i].Reset(newGame);
		}
		elapsedTime = 0f;
		guitarEmpty = false;
		Init(level, newLevel: true, newGame);
		if (level.startFlags != null)
		{
			for (int j = 0; j < level.startFlags.Length; j++)
			{
				SetGlobalFlag(level.startFlags[j]);
			}
		}
		GameState.state = GameState.State.Playing;
		Game1.transMgr.levelInFrame = 2f;
	}

	internal void NextLevel()
	{
		currentLevel++;
		NewLevel(currentLevel, currentTrack);
	}
}
