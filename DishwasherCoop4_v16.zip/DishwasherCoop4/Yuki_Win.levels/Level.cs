using System.Text;
using Microsoft.Xna.Framework;
using Yuki_Win.player;

namespace Yuki_Win.levels;

public class Level
{
	public enum ArcadeSpecial
	{
		None,
		Instakill,
		Vampire,
		Aerials,
		ColorKeys,
		PowerPlayer,
		Blitz,
		Slow,
		SplitAerials,
		HotPotato,
		CrackingSkull,
		NomNom,
		TurboBlitz
	}

	public enum LevelType
	{
		YukiLevel,
		DishLevel,
		CoopLevel,
		ArcadeLevel
	}

	public enum ArcadeMagic
	{
		None,
		Electric,
		Steel,
		Devouring,
		Holy
	}

	public enum GunMode
	{
		None,
		SMG,
		Shotty
	}

	public enum SpecialIntro
	{
		None,
		Getup,
		SawGetup,
		SawCrazyGetup
	}

	public string name;

	public StringBuilder nameStr;

	public string world;

	public string map;

	public StringBuilder[] desc;

	public int yukiPhase;

	public int dishPhase;

	public ArcadeSpecial arcadeSpecial;

	public LevelType levelType;

	public Vector2 startLoc;

	public string[] startFlags;

	public int[] arcadePlayer = new int[2] { 1, 0 };

	public InvCatalog.InvItemName[,] arcadeWeapon = new InvCatalog.InvItemName[2, 2];

	public ArcadeMagic magic;

	public GunMode gunMode;

	public int track;

	public SpecialIntro intro;

	public Level(StringBuilder name, StringBuilder desc, StringBuilder desc2, string map, ArcadeSpecial arcadeMode, int player1, InvCatalog.InvItemName player1weap1, InvCatalog.InvItemName player1weap2, int player2, InvCatalog.InvItemName player2weap1, InvCatalog.InvItemName player2weap2, ArcadeMagic magic, GunMode gunMode, int track)
	{
		this.map = map;
		this.name = name.ToString();
		this.desc = new StringBuilder[2] { desc, desc2 };
		nameStr = name;
		arcadeSpecial = arcadeMode;
		levelType = LevelType.ArcadeLevel;
		arcadePlayer[0] = player1;
		arcadeWeapon[0, 0] = player1weap1;
		arcadeWeapon[0, 1] = player1weap2;
		arcadePlayer[1] = player2;
		arcadeWeapon[1, 0] = player2weap1;
		arcadeWeapon[1, 1] = player2weap2;
		this.gunMode = gunMode;
		this.magic = magic;
		this.track = track;
		if (GameState.paxDemoMode || GameState.longDemoMode)
		{
			this.gunMode = GunMode.Shotty;
		}
	}

	public Level(StringBuilder name, string world, string map, int phase, Vector2 startLoc, SpecialIntro intro, string[] startFlags)
	{
		this.name = name.ToString();
		nameStr = name;
		this.world = world;
		this.map = map;
		yukiPhase = phase;
		this.startLoc = startLoc;
		this.intro = intro;
		this.startFlags = startFlags;
		levelType = LevelType.YukiLevel;
	}

	public Level(StringBuilder name, string world, string map, int phase, Vector2 startLoc, SpecialIntro intro, string[] startFlags, bool dishwasher)
	{
		this.name = name.ToString();
		nameStr = name;
		this.world = world;
		this.map = map;
		dishPhase = phase;
		this.startLoc = startLoc;
		this.intro = intro;
		this.startFlags = startFlags;
		levelType = LevelType.DishLevel;
	}

	public Level(string name, string world, string map, int yukiphase, int dishphase, Vector2 startLoc, SpecialIntro intro, string[] startFlags)
	{
		this.name = name;
		nameStr = new StringBuilder(name);
		this.world = world;
		this.map = map;
		yukiPhase = yukiphase;
		dishPhase = dishphase;
		this.startLoc = startLoc;
		this.intro = intro;
		this.startFlags = startFlags;
		levelType = LevelType.CoopLevel;
	}
}
