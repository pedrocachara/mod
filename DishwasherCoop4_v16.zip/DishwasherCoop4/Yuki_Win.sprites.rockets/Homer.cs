using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.rockets;

internal class Homer : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.owner = owner;
		p.hitter = true;
		p.frame = 3f;
		p.rotation = 3.14f + Trig.GetAngle(default, p.traj);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float num = p.frame - FMan.frameTime;
		if (p.frame > 1f && (int)(num * 60f) != (int)(p.frame * 60f))
		{
			spriteMan.AddSprite(16, p.loc, p.traj * -0.4f + Rand.GetRandomVec2(-10f, 10f, -10f, 10f), 0.4f, 0, 0);
		}
		if ((int)(num * 30f) != (int)(p.frame * 30f))
		{
			spriteMan.AddSprite(18, p.loc, p.traj * -0.1f, 0.4f, 0, 0);
		}
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.frame = -1f;
		}
		if (p.frame > 1f)
		{
			float rotation = p.rotation;
			p.rotation = 3.14f + Trig.GetAngle(default, p.traj);
			p.rDir = (p.rotation - rotation) / FMan.frameTime;
			float num2 = 0f;
			int num3 = -1;
			for (int i = 0; i < Game1.character.Length; i++)
			{
				if (Game1.character[i].exists && Game1.character[i].team != Game1.character[p.owner].team && !Game1.character[i].GetMeta().isNeko && !Game1.character[i].GetMeta().isCrow)
				{
					float num4 = (Game1.character[i].charUpdate.loc - p.loc).Length();
					if (num3 == -1)
					{
						num2 = num4;
						num3 = i;
					}
					else if (num4 < num2)
					{
						num3 = i;
						num2 = num4;
					}
				}
			}
			if (num3 > -1)
			{
				float num5;
				for (num5 = 3.14f + Trig.GetAngle(p.loc, Game1.character[num3].charUpdate.loc - new Vector2(0f, 50f)); num5 > 6.28f; num5 -= 6.28f)
				{
				}
				float num6;
				for (num6 = num5 - p.rotation; num6 > 6.28f; num6 -= 6.28f)
				{
				}
				for (; num6 < 0f; num6 += 6.28f)
				{
				}
				if (num6 > 3.14f)
				{
					p.rotation -= FMan.frameTime * 4f;
				}
				else
				{
					p.rotation += FMan.frameTime * 4f;
				}
				while (p.rotation > 6.28f)
				{
					p.rotation -= 6.28f;
				}
				while (p.rotation < 0f)
				{
					p.rotation += 6.28f;
				}
				p.traj = new Vector2((float)Math.Cos(p.rotation), (float)Math.Sin(p.rotation)) * 400f;
			}
		}
		else
		{
			p.hitter = false;
			if (p.rDir > -0.3f && p.rDir < 0.3f)
			{
				p.rDir = Rand.GetRandomFloat(-0.3f, 0.3f);
			}
			p.traj.Y += FMan.frameTime * 1200f;
			p.rotation += p.rDir * FMan.frameTime;
		}
		base.Update(p, spriteMan);
		if (p.frame < 0f)
		{
			spriteMan.MakeExplosion(p.loc - p.traj * 0.1f, p.owner, 2f, splash: false);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640, 128, 128, 64), new Color(new Vector4(1f, 1f, 1f, 1f)), p.rotation, new Vector2(64f, 32f), ScrollManager.cannedDepth[0] * 0.35f, SpriteEffects.None, 1f);
	}
}
