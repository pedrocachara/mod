using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.rockets;

internal class Rocket : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.owner = owner;
		p.hitter = true;
		p.frame = 2f;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float num = p.frame - FMan.frameTime;
		if ((int)(num * 60f) != (int)(p.frame * 60f))
		{
			spriteMan.AddSprite(16, p.loc, p.traj * -0.4f, 0.6f, 0, 0);
		}
		if ((int)(num * 30f) != (int)(p.frame * 30f))
		{
			spriteMan.AddSprite(18, p.loc, p.traj * -0.1f, 1f, 0, 0);
		}
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.frame = -1f;
		}
		base.Update(p, spriteMan);
		p.rotation = Trig.GetAngle(default, p.traj);
		if (p.frame < 0f)
		{
			spriteMan.MakeExplosion(p.loc - p.traj * 0.1f, p.owner, 5f, splash: true);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640, 128, 128, 64), new Color(new Vector4(1f, 1f, 1f, 1f)), 3.14f + p.rotation, new Vector2(64f, 32f), ScrollManager.cannedDepth[0] * 0.6f, SpriteEffects.None, 1f);
	}
}
