using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using WorldMapEdit;
using Yuki_Win.audio;

namespace Yuki_Win.worldmap;

public class WorldMapMgr
{
	public enum WorldDrawMode
	{
		Menu,
		LevelTrans
	}

	public WorldMap worldMap;

	private float frame;

	public Vector2 scroll;

	public float zoom = 1f;

	private float trackFrame;

	private int pCurLevel = -1;

	private GraphicsDevice dev;

	public void ResetTrack()
	{
		trackFrame = 0f;
	}

	public WorldMapMgr(GraphicsDevice dev)
	{
		worldMap = new WorldMap();
		this.dev = dev;
	}

	public void Read(string path)
	{
		worldMap.path = "worldmap/data/" + path + ".zax";
		worldMap.Read();
		pCurLevel = -1;
	}

	public void MenuUpdate(int selected)
	{
		if (worldMap.levels.Count <= selected || selected <= -1)
		{
			return;
		}
		WorldLevel worldLevel = worldMap.levels[selected];
		if (worldLevel == null)
		{
			return;
		}
		Vector2 vector = default;
		Vector2 vector2 = default;
		Vector2 vector3 = default;
		int num = 0;
		foreach (WorldNode item in worldLevel.node)
		{
			vector += item.loc;
			num++;
			if (num == 1)
			{
				vector2 = item.loc;
				vector3 = item.loc;
				continue;
			}
			if (item.loc.X < vector2.X)
			{
				vector2.X = item.loc.X;
			}
			if (item.loc.Y < vector2.Y)
			{
				vector2.Y = item.loc.Y;
			}
			if (item.loc.X > vector3.X)
			{
				vector3.X = item.loc.X;
			}
			if (item.loc.Y > vector3.Y)
			{
				vector3.Y = item.loc.Y;
			}
		}
		vector3.Y += 100f;
		vector = (vector2 + vector3) / 2f;
		Vector2 vector4 = vector3 - vector2;
		vector4.Y += 100f;
		vector4.Y *= 1.7777778f;
		if (vector4.Y > vector4.X)
		{
			vector4.X = vector4.Y;
		}
		if (vector4.X > 0f)
		{
			float num2 = (0f - vector4.X) / 100f;
			if (num2 > 1.5f)
			{
				num2 = 1.5f;
			}
			zoom += (num2 - Game1.worldMapMgr.zoom) * FMan.frameTime * 4f;
			vector.Y -= 80f / num2;
		}
		scroll += (vector - Game1.worldMapMgr.scroll) * FMan.frameTime * 4f;
	}

	public void Update()
	{
		if (Game1.loader.complete)
		{
			frame += FMan.frameTime;
			if (frame > 6.28f)
			{
				frame -= 6.28f;
			}
			if (trackFrame < 2f)
			{
				trackFrame += FMan.frameTime;
			}
		}
	}

	public void NextUpdate(int curLevel, bool advance)
	{
		frame += FMan.frameTime;
		if (frame > 6.28f)
		{
			frame -= 6.28f;
		}
		if (!(trackFrame < 2f))
		{
			return;
		}
		float num = trackFrame;
		if (advance)
		{
			trackFrame += FMan.frameTime * 0.2f;
		}
		Vector2 vector = scroll;
		if (curLevel >= worldMap.levels.Count)
		{
			return;
		}
		WorldLevel worldLevel = worldMap.levels[curLevel];
		for (int i = 0; i < worldLevel.node.Count - 1; i++)
		{
			WorldNode worldNode = worldLevel.node[i];
			WorldNode worldNode2 = worldLevel.node[i + 1];
			float num2 = (float)i / (float)(worldLevel.node.Count - 1);
			float num3 = (float)(i + 1) / (float)(worldLevel.node.Count - 1);
			if (trackFrame >= num2 && trackFrame < num3)
			{
				float num4 = (trackFrame - num2) / (num3 - num2);
				vector = worldNode.loc + (worldNode2.loc - worldNode.loc) * num4;
			}
			if (trackFrame > num3 && num <= num3)
			{
				switch (worldNode2.type)
				{
				case WorldNode.NodeType.Dot:
					Sound.PlaySnd(Sound.Category.FX, "foot1");
					break;
				case WorldNode.NodeType.Boss:
					Sound.PlaySnd(Sound.Category.FX, "jail");
					break;
				case WorldNode.NodeType.Mark:
					Sound.PlaySnd(Sound.Category.FX, "slash1");
					Sound.PlaySnd(Sound.Category.FX, "chunk");
					Sound.PlaySnd(Sound.Category.FX, "crush");
					break;
				}
			}
		}
		float num5 = 2f;
		zoom += (num5 - Game1.worldMapMgr.zoom) * FMan.frameTime * 4f;
		scroll += (vector - Game1.worldMapMgr.scroll) * FMan.frameTime * 3f;
	}

	public void Draw(SpriteBatch sprite, WorldDrawMode drawMode, float alpha, int curLevel, int threedee)
	{
		if (alpha <= 0f)
		{
			return;
		}
		if (!Game1.loader.complete)
		{
			alpha = 0f;
			return;
		}
		dev.SetRenderTarget(Game1.sceneMgr.comicTarg);
		dev.Clear(Color.Black);
		Vector2 vector = ScrollManager.scroll;
		float num = ScrollManager.zoom;
		ScrollManager.scroll = scroll;
		ScrollManager.zoom = zoom;
		ScrollManager.UpdateCannedValues();
		if (curLevel != pCurLevel)
		{
			ResetTrack();
			pCurLevel = curLevel;
		}
		sprite.Draw(Game1.bgTex[1], ScrollManager.GetScreenLoc(new Vector2(1000f, 600f), 0.5f), new Rectangle(0, 0, (int)ScrollManager.screenSize.X / 2, (int)ScrollManager.screenSize.Y), new Color(alpha, alpha, alpha, alpha), 0f, ScrollManager.screenSize / 4f, ScrollManager.zoom * 4f, SpriteEffects.FlipHorizontally, 1f);
		sprite.Draw(Game1.worldMapTex, ScrollManager.GetScreenLoc(default(Vector2), 1f), new Rectangle(0, 0, 2000, 1200), new Color(alpha, alpha, alpha, alpha), 0f, default, ScrollManager.GetSize(1f), SpriteEffects.None, 1f);
		float num2 = trackFrame;
		for (int i = 0; i < 4; i++)
		{
			sprite.Draw(sourceRectangle: new Rectangle(0, 256, 384, 192), texture: Game1.spritesTex, position: ScrollManager.GetScreenLoc(new Vector2((float)i * 500f + 250f, 1000f), 1.4f), color: new Color(alpha, alpha, alpha, alpha), rotation: -1.57f + (float)Math.Cos(frame + (float)i) * 0.2f + (0.15f - (float)i * 0.1f), origin: new Vector2(64f, 96f), scale: ScrollManager.GetSize(1f) * new Vector2(4f, 1.5f), effects: SpriteEffects.None, layerDepth: 1f);
		}
		sprite.End();
		switch (threedee)
		{
		case -1:
			dev.SetRenderTarget(null);
			break;
		case 0:
		case 1:
			dev.SetRenderTarget(Game1.threeDeeTarg[threedee]);
			break;
		}
		dev.Clear(Color.Black);
		SpriteTools.BeginAlpha(Game1.sceneMgr.creepEffect);
		sprite.Draw(Game1.sceneMgr.comicTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
		SpriteTools.End();
		Vector2 vector2 = default;
		switch (threedee)
		{
		case 0:
			vector2.X = 1f;
			break;
		case 1:
			vector2.X = -1f;
			break;
		}
		float num3 = 1.1f;
		SpriteTools.BeginAlpha();
		for (int j = 0; j < worldMap.levels.Count; j++)
		{
			if (curLevel != j)
			{
				continue;
			}
			WorldLevel worldLevel = worldMap.levels[j];
			for (int k = 0; k < worldLevel.node.Count - 1; k++)
			{
				WorldNode worldNode = worldLevel.node[k];
				WorldNode worldNode2 = worldLevel.node[k + 1];
				float num4 = (float)k / (float)(worldLevel.node.Count - 1);
				if (num2 > num4)
				{
					float num5 = (num2 - num4) * 10f;
					if (num5 > 1f)
					{
						num5 = 1f;
					}
					sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc((worldNode.loc + worldNode2.loc) / 2f + vector2, num3), new Rectangle((k + j) % 4 * 128, 960, 128, 64), new Color(1f, 0f, 0f, num5 * alpha), Trig.GetAngle(worldNode.loc, worldNode2.loc), new Vector2(64f, 32f), new Vector2(Trig.GetDist(ScrollManager.GetScreenLoc(worldNode.loc, num3), ScrollManager.GetScreenLoc(worldNode2.loc, 1f)) / 128f, ScrollManager.GetSize(num3) * 0.2f), SpriteEffects.None, 1f);
				}
			}
		}
		for (int l = 0; l < worldMap.levels.Count; l++)
		{
			WorldLevel worldLevel2 = worldMap.levels[l];
			for (int m = 0; m < worldLevel2.node.Count; m++)
			{
				WorldNode worldNode3 = worldLevel2.node[m];
				Rectangle value = new Rectangle(0, 0, 64, 64);
				float num6 = (float)m / (float)worldLevel2.node.Count;
				float num7 = frame / 6.28f * 5f;
				num7 -= (float)(int)num7;
				float num8 = num6 - num7;
				float num9 = 0.5f;
				for (; num8 < 0f; num8++)
				{
				}
				if (num8 < 0.1f)
				{
					num9 += (0.1f - num8) * 2f;
				}
				if (num8 > 0.9f)
				{
					num9 += (num8 - 0.9f) * 2f;
				}
				float rotation = 0f;
				switch (worldNode3.type)
				{
				case WorldNode.NodeType.Boss:
					value.X = 64;
					num9 = 1f + (float)Math.Cos(frame * 7f) * 0.1f;
					rotation = (float)Math.Cos(frame * 4f) * 0.1f;
					break;
				case WorldNode.NodeType.Mark:
					value.Y = 64;
					num9 = 1f + (float)Math.Cos(frame * 7f) * 0.1f;
					break;
				}
				Color color = new Color(1f, 1f, 1f, alpha);
				float num10 = 1f;
				sprite.Draw(Game1.worldSpritesTex, ScrollManager.GetScreenLoc(worldNode3.loc + vector2, num3), value, new Color(0f, 0f, 0f, 0.2f * alpha), rotation, new Vector2(32f, 32f), ScrollManager.GetSize(num3) * 0.5f, SpriteEffects.None, 1f);
				if (curLevel != l)
				{
					continue;
				}
				num6 = (float)m / (float)(worldLevel2.node.Count - 1);
				if (num2 > num6)
				{
					num10 = (num2 - num6) * 10f;
					if (num10 > 1f)
					{
						num10 = 1f;
					}
				}
				else
				{
					num10 = 0f;
				}
				sprite.Draw(color: new Color(1f, 1f, 1f, alpha * num10 * alpha), texture: Game1.worldSpritesTex, position: ScrollManager.GetScreenLoc(worldNode3.loc + vector2, num3), sourceRectangle: value, rotation: rotation, origin: new Vector2(32f, 32f), scale: ScrollManager.GetSize(num3) * num9, effects: SpriteEffects.None, layerDepth: 1f);
			}
		}
		ScrollManager.scroll = vector;
		ScrollManager.zoom = num;
	}
}
