using System.Text;
using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.debug;
using Yuki_Win.director;
using Yuki_Win.gameRender;
using Yuki_Win.guidestuff;
using Yuki_Win.hud.pickups;
using Yuki_Win.hud.tut;
using Yuki_Win.levels;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.player.inventory;
using Yuki_Win.shop;

namespace Yuki_Win.hud;

public class HUD
{
	public const float THREEDEE_OFFSET = 1f;

	public PlayerHUD[] playerHUD = new PlayerHUD[4];

	private HUDBox[] bossBox = new HUDBox[4];

	private EndLevel endLevel;

	private int totalBoss;

	private TutManager tutMgr;

	private Pickups pickups;

	public ShopMgr shopMgr;

	public InvMgr invMgr;

	private float transFrame;

	private float waveDefeatedFrame;

	private int waveDefeatedIdx;

	public float waveDefeatedOkFrame;

	public ArcadeInScreen arcadeIn;

	public void ResetInv()
	{
		for (int i = 0; i < invMgr.inv.Length; i++)
		{
			invMgr.inv[i].active = false;
			invMgr.inv[i].alpha = 0f;
			invMgr.inv[i].currentTab = Inv.InvTabSection.Food;
		}
	}

	public HUD()
	{
		shopMgr = new ShopMgr();
		invMgr = new InvMgr();
		arcadeIn = new ArcadeInScreen();
		endLevel = new EndLevel();
		tutMgr = new TutManager();
		for (int i = 0; i < playerHUD.Length; i++)
		{
			playerHUD[i] = new PlayerHUD(i);
		}
		for (int j = 0; j < bossBox.Length; j++)
		{
			bossBox[j] = new HUDBox(400, 28);
		}
		pickups = new Pickups();
	}

	public void EndLevelServerClick()
	{
		endLevel.serverClick = true;
	}

	public bool PickupsActive()
	{
		return pickups.IsActive();
	}

	public void PickupDeath()
	{
		pickups.Die();
	}

	public void PickupDeathReset()
	{
		pickups.ResetDeath();
	}

	public void DoGuitar(float perc)
	{
		pickups.DoGuitar(perc);
	}

	public void DoGuitar(float perc, float perc2)
	{
		pickups.DoGuitar(perc, perc2);
	}

	public void DoPickups(int name, int coopName)
	{
		pickups.DoPickup(name, coopName, netInduced: false);
	}

	public void DoPickups(int name)
	{
		pickups.DoPickup(name);
	}

	public void DoPickups(string name)
	{
		pickups.DoPickup(name, used: false);
	}

	public void DoPickups(string name, bool used)
	{
		pickups.DoPickup(name, used);
	}

	public void DoPickups(int name, bool used, bool netInduced)
	{
		pickups.DoPickup((InvCatalog.InvItemName)name, used, netInduced);
	}

	public void DoPickups(int name, int coopName, bool netInduced)
	{
		pickups.DoPickup(name, coopName, netInduced);
	}

	public bool GetIsTutActive()
	{
		return tutMgr.IsGoing();
	}

	public void DoTut(string tut)
	{
		tutMgr.DoTut(tut);
	}

	public void EndLevel()
	{
		if (Game1.pvpMatch)
		{
			return;
		}
		endLevel.DoEnd();
	}

	public bool IsEndLevel()
	{
		return endLevel.active;
	}

	public float GetEndLevelAlpha()
	{
		float num = endLevel.frame;
		if (num > 1f)
		{
			num = 1f;
		}
		return num;
	}

	public void DefeatWave()
	{
		if (!Game1.netSession.IsHost() && !Game1.netSession.IsClient() && waveDefeatedOkFrame > 0f)
		{
			Sound.PlaySnd(Sound.Category.FX, "clear");
			waveDefeatedFrame = 1f;
			FMan.Slow(0.1f);
		}
	}

	public void Update()
	{
		transFrame += FMan.frameTime * 2f;
		if (transFrame > 1f)
		{
			transFrame--;
		}
		tutMgr.Update();
		if (pickups.IsActive())
		{
			pickups.Update();
		}
		if (endLevel.active)
		{
			endLevel.Update();
		}
		if (arcadeIn.active)
		{
			arcadeIn.Update();
		}
		if (Game1.levelMgr.currentTrack == 6 || Game1.levelMgr.currentTrack == 5)
		{
			Game1.practice.Update();
		}
		for (int i = 0; i < playerHUD.Length; i++)
		{
			playerHUD[i].visible = false;
		}
		if (waveDefeatedOkFrame > 0f)
		{
			waveDefeatedOkFrame -= FMan.frameTime;
		}
		if (waveDefeatedFrame > 0f)
		{
			waveDefeatedFrame -= FMan.frameTime;
			if (waveDefeatedFrame > 0.95f)
			{
				QuakeManager.SetBright((1f - waveDefeatedFrame) * 5f);
				QuakeManager.SetContrast((1f - waveDefeatedFrame) * 4f);
			}
			float num = 1f;
			if (waveDefeatedFrame > 0.95f)
			{
				num = (1f - waveDefeatedFrame) * 20f;
			}
			else
			{
				num = ((!(waveDefeatedFrame < 0.9f)) ? 1f : (waveDefeatedFrame * 1.1111112f));
			}
			QuakeManager.SetBurst(num * 0.3f, ScrollManager.screenSize / 2f);
		}
		playerHUD[0].visible = true;
		if (Game1.GetPlayers() >= 2)
		{
			playerHUD[1].visible = true;
		}
		for (int pv = 2; pv < 4; pv++)
		{
			if (Game1.GetPlayers() > pv)
			{
				playerHUD[pv].visible = true;
			}
		}
		for (int j = 0; j < playerHUD.Length; j++)
		{
			playerHUD[j].Update();
		}
		shopMgr.Update();
		invMgr.Update();
		totalBoss = 0;
		if (Game1.gameMap.theme.theme != Themes.ThemeType.Asylum)
		{
			for (int k = 0; k < Game1.character.Length; k++)
			{
				if (Game1.character[k].exists && Game1.character[k].GetMeta().isBoss && !Game1.character[k].charUpdate.inactive && !Game1.character[k].charUpdate.nomusic && totalBoss < bossBox.Length)
				{
					bossBox[totalBoss].prog = Game1.character[k].charUpdate.hp / Game1.character[k].charUpdate.mhp;
					bossBox[totalBoss].Update();
					totalBoss++;
				}
			}
		}
		for (int l = totalBoss; l < bossBox.Length; l++)
		{
			bossBox[l].prog = 0f;
			bossBox[l].Update();
		}
		if (totalBoss > 0)
		{
			GuideStuff.toast = 1;
		}
	}

	public void DrawEndLevel(SpriteBatch sprite, int threedee)
	{
		endLevel.Draw(sprite, threedee);
	}

	private void DrawMarker(int c, SpriteBatch sprite, int threedee)
	{
		if (!Game1.gameMap.yukiDeathFocus && Game1.character[c].charUpdate.charGrab.grabbedByChar <= -1 && !Game1.character[c].charUpdate.charGrab.grabbing && !Game1.character[c].charUpdate.nomusic && Game1.gameMap.theme.theme != Themes.ThemeType.Asylum && Game1.player.yukiPhase != 1 && (Game1.gameMap.theme.theme != Themes.ThemeType.Final || !(Game1.gameMap.CrazyTransitionInFrame > 0f)))
		{
			Color color = Color.White;
			switch (Game1.arcade.player[c])
			{
			case 1:
				color = new Color(1f, 1f, 1f, 1f);
				break;
			case 2:
				color = new Color(0.5f, 0.6f, 1f, 1f);
				break;
			case 3:
				color = new Color(1f, 0.35f, 0.35f, 1f);
				break;
			case 4:
				color = new Color(0.6f, 0.2f, 0.6f, 1f);
				break;
			case 0:
				color = new Color(1f, 0.5f, 0.75f, 1f);
				break;
			}
			Vector2 vector = default;
			switch (threedee)
			{
			case 0:
				vector.X = 1f;
				break;
			case 1:
				vector.X = -1f;
				break;
			}
			sprite.Draw(Game1.spritesTex, ScrollManager.GetScreenLoc(Game1.character[c].charUpdate.loc + new Vector2(0f, -90f), 1f) + vector * 0.3f, new Rectangle(192, 768, 64, 64), color, 0f, new Vector2(32f, 64f), new Vector2(1.2f, 0.6f) * (ScrollManager.cannedDepth[0] * 0.3f + 0.3f), SpriteEffects.None, 1f);
		}
	}

	// Parry: arma na frente do personagem durante a janela + anel de brilho no sucesso.
	private void DrawParry(SpriteBatch sprite)
	{
		for (int p = 0; p < Game1.GetPlayers() && p < 4; p++)
		{
			Character ch = Game1.character[p];
			if (ch == null || !ch.exists)
			{
				continue;
			}
			CharUpdate u = ch.charUpdate;
			if (u.parryFrame <= 0f && u.parryFlash <= 0f)
			{
				continue;
			}
			float dir = ((u.face == 1) ? 1f : (-1f));
			Vector2 center = ScrollManager.GetScreenLoc(u.loc + new Vector2(0f, -60f), 1f);
			Vector2 front = center + new Vector2(dir * 55f, 0f);
			if (u.parryFrame > 0f)
			{
				InvCatalog.InvItemName weapon = Game1.gamePlayerMgr.gamePlayer[p].loadOut[ch.loadOut].weapon[ch.weapIdx];
				bool poseAnim = u.borrowed || ch.charAnim.animName == "parry" || ch.charAnim.animName == ch.GetMeta().switch_anim;
				if (weapon != InvCatalog.InvItemName.None && !poseAnim)
				{
					Rectangle rect = Game1.invCatalog.GetInvitemRect(weapon);
					sprite.Draw(Game1.itemsTex, front, rect, new Color(1f, 1f, 1f, 1f), dir * 0.35f, new Vector2((float)rect.Width / 2f, (float)rect.Height / 2f), 0.6f, (dir > 0f) ? SpriteEffects.None : SpriteEffects.FlipHorizontally, 1f);
				}
				sprite.Draw(Game1.spritesTex, front, new Rectangle(832, 192, 64, 64), new Color(1f, 0.9f, 0.4f, 0.45f), 0f, new Vector2(32f, 32f), 1.4f, SpriteEffects.None, 1f);
			}
			if (u.parryFlash > 0f)
			{
				float t = 1f - u.parryFlash / 0.35f;
				sprite.Draw(Game1.spritesTex, front, new Rectangle(832, 192, 64, 64), new Color(1f, 1f, 0.7f, (1f - t) * 0.9f), 0f, new Vector2(32f, 32f), 1.4f + t * 4f, SpriteEffects.None, 1f);
			}
		}
	}

	private void DrawPvp(SpriteBatch sprite)
	{
		StringBuilder score = new StringBuilder("ROUND " + Game1.pvpRound + "   ");
		for (int pi = 0; pi < Game1.GetPlayers() && pi < 4; pi++)
		{
			score.Append("P" + (pi + 1) + ": " + Game1.pvpWins[pi] + "   ");
		}
		score.Append("FIRST TO " + Game1.pvpRoundsToWin);
		string banner = null;
		if (Game1.pvpState == 1)
		{
			banner = ((Game1.pvpWinner >= 0) ? ("PLAYER " + (Game1.pvpWinner + 1) + " WINS THE ROUND") : "DRAW");
		}
		else if (Game1.pvpState == 2 && Game1.pvpWinner >= 0)
		{
			banner = "PLAYER " + (Game1.pvpWinner + 1) + " WINS THE MATCH!";
		}
		for (int k = 0; k < 2; k++)
		{
			float shade = ((k == 0) ? 0f : 1f);
			float a = ((k == 0) ? 0.6f : 1f);
			Vector2 shadow = new Vector2(3f, 3f) * k;
			Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 30f) - shadow, score, new Color(shade, shade, shade, a), 0.8f, 1);
			if (banner != null)
			{
				Text.DrawCText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, ScrollManager.screenSize.Y * 0.3f) - shadow, new StringBuilder(banner), new Color(shade, shade, shade, a), 1.6f, 1);
			}
		}
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		if (DebugManager.hideChars || DebugManager.videoRecordMode || Game1.soloMgr.active || Game1.camMgr.bossToast.needsImprint || Game1.gameMap.psychoTVAlpha > 0f || Game1.camMgr.bossToast.frame >= 0f)
		{
			return;
		}
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		DrawPrompts(sprite, threedee);
		if (Game1.gameMap.nekoToastyFrame > 0f)
		{
			Game1.gameMap.DrawNekoToasty(sprite);
		}
		if (invMgr.IsActive())
		{
			invMgr.Draw(sprite, threedee);
		}
		if (pickups.IsActive())
		{
			pickups.Draw(sprite, threedee);
		}
		else if (tutMgr.IsGoing())
		{
			tutMgr.Draw(sprite, threedee);
		}
		else
		{
			if (endLevel.active || Game1.sceneMgr.playing)
			{
				return;
			}
			if (Game1.gameMap.slavachase && Game1.character[0].charAnim.animName == "armpanic")
			{
				float num = Game1.gameMap.tvFrame * 100f - (float)(int)(Game1.gameMap.tvFrame * 100f);
				sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f + new Vector2(0f, 200f) + vector, new Rectangle(384 + Rand.GetRandomInt(0, 6) * 64, 256, 64, 64), new Color(0f, 0f, 0f, 1f), 0f, new Vector2(32f, 32f), 1.2f + num * 0.5f, SpriteEffects.None, 1f);
				flibitPort.DrawButtonAttrib('A', ScrollManager.screenSize / 2f + new Vector2(0f, 200f) + vector, new Color(1f, 1f, 1f, 1f), 0f, new Vector2(32f, 32f), 1f + num * 0.2f, SpriteEffects.None, 1f);
			}
			if (Game1.gameMap.chainMash)
			{
				float num2 = Game1.gameMap.tvFrame * 100f - (float)(int)(Game1.gameMap.tvFrame * 100f);
				sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f + new Vector2(0f, 200f) + vector, new Rectangle(384 + Rand.GetRandomInt(0, 6) * 64, 256, 64, 64), new Color(0f, 0f, 0f, 1f), 0f, new Vector2(32f, 32f), 1.2f + num2 * 0.5f, SpriteEffects.None, 1f);
				flibitPort.DrawButtonAttrib('Y', ScrollManager.screenSize / 2f + new Vector2(0f, 200f) + vector, new Color(1f, 1f, 1f, 1f), 0f, new Vector2(32f, 32f), 1f + num2 * 0.2f, SpriteEffects.None, 1f);
				Game1.gameMap.chainMash = false;
			}
			if (Game1.gameMap.dentistChairMode || Game1.gameMap.bedMode)
			{
				float num3 = Game1.gameMap.tvFrame * 10f;
				num3 -= (float)(int)num3;
				num3 *= 6f;
				float num4 = 0f;
				if (num3 < 2f)
				{
					num4 = 0f;
				}
				else if (num3 < 3f)
				{
					num4 = num3 - 2f;
				}
				else if (num3 < 5f)
				{
					num4 = 1f;
				}
				else
				{
					num4 = ((!(num3 < 6f)) ? 0f : (6f - num3));
				}
				if (num4 > 0f)
				{
					flibitPort.DrawButtonAttrib('u', ScrollManager.GetScreenLoc(new Vector2(Game1.gameMap.scriptTrigX, Game1.character[0].charUpdate.loc.Y - 80f - num3 * 4f), 1f) + vector, new Color(1f, 1f, 1f, num4), 0f, new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
				}
			}
			if (Game1.gameMap.theme.theme != Themes.ThemeType.Asylum && Game1.gameMap.theme.theme != Themes.ThemeType.Escape && Game1.gameMap.theme.theme != Themes.ThemeType.EscapeOut && !invMgr.IsActive() && !Game1.gameMap.lockCharMode && !shopMgr.IsActive())
			{
				if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
				{
					for (int i = 0; i < Game1.arcade.players; i++)
					{
						DrawMarker(i, sprite, threedee);
					}
				}
				else if (Game1.GetPlayers() > 1)
				{
					for (int mk = 0; mk < 4; mk++)
					{
						Game1.arcade.player[mk] = Game1.ArcadeTypeFromPick(Game1.slotChar[mk]);
					}
					for (int j = 0; j < Game1.GetPlayers(); j++)
					{
						DrawMarker(j, sprite, threedee);
					}
				}
				else
				{
					if (Game1.character[0].GetMeta().isYuki)
					{
						Game1.arcade.player[0] = 0;
					}
					else
					{
						Game1.arcade.player[0] = 1;
					}
					DrawMarker(0, sprite, threedee);
				}
			}
			DrawCornerChars(sprite, threedee);
			if (Game1.pvpMatch && threedee != 0 && threedee != 1)
			{
				DrawPvp(sprite);
			}
			if (Game1.parryEnabled && threedee != 0 && threedee != 1)
			{
				DrawParry(sprite);
			}
			flibitPort.DrawMouseHUD(sprite, threedee);
			if (Game1.gameMap.theme.theme != Themes.ThemeType.Asylum && Game1.gameMap.theme.theme != Themes.ThemeType.Escape && Game1.gameMap.theme.theme != Themes.ThemeType.Church && Game1.gameMap.theme.theme != Themes.ThemeType.EscapeOut)
			{
				playerHUD[0].Draw(sprite, threedee);
				if (Game1.GetPlayers() >= 2)
				{
					playerHUD[1].Draw(sprite, threedee);
				}
				for (int pd = 2; pd < 4; pd++)
				{
					if (Game1.GetPlayers() > pd)
					{
						playerHUD[pd].Draw(sprite, threedee);
					}
				}
				for (int k = 2; k < 4; k++)
				{
					if (Game1.GetPlayers() > 2 || !Game1.character[k].exists || !Game1.petPlayerMgr.petPlayer[k - 2].IsActive())
					{
						continue;
					}
					Vector2 screenLoc = ScrollManager.GetScreenLoc(Game1.character[k].charUpdate.loc, 1f);
					float num5 = 110f;
					float num6 = -1f;
					if (screenLoc.X > ScrollManager.screenSize.X - num5)
					{
						screenLoc.X = ScrollManager.screenSize.X - num5;
						num6 = 0f;
					}
					if (screenLoc.X < num5)
					{
						screenLoc.X = num5;
						num6 = 3.14f;
					}
					if (screenLoc.Y > ScrollManager.screenSize.Y - num5)
					{
						screenLoc.Y = ScrollManager.screenSize.Y - num5;
						num6 = 1.57f;
					}
					if (screenLoc.Y < num5)
					{
						screenLoc.Y = num5;
						num6 = 4.71f;
					}
					if (num6 >= 0f)
					{
						sprite.Draw(Game1.spritesTex, screenLoc + vector, new Rectangle(64, 768, 64, 64), Color.White, num6, new Vector2(32f, 32f), 0.5f, SpriteEffects.None, 1f);
					}
					float chow = Game1.petPlayerMgr.GetChow(k);
					if (!(chow > 0f))
					{
						continue;
					}
					for (int l = 0; l < (int)(chow + 1f); l++)
					{
						Rectangle value = new Rectangle(896, 896, 32, 32);
						float num7 = 0.35f;
						if (l == (int)chow)
						{
							num7 *= chow - (float)l;
						}
						Color color = new Color(1f, 0f, 0f, 0.5f);
						if (l < (int)chow || num7 >= 0.5f)
						{
							if (l == 2)
							{
								num7 *= 2f;
								value.X = 640;
								value.Y = 608;
								color = new Color(1f, 0f, 1f, 1f);
							}
							if (l == 6)
							{
								num7 *= 2f;
								value.X = 896;
								value.Y = 864;
								color = new Color(1f, 1f, 0f, 1f);
							}
						}
						value.X += Rand.GetRandomInt(0, 4) * 32;
						sprite.Draw(Game1.spritesTex, new Vector2(ScrollManager.screenSize.X / 2f + 530f * ((k == 2) ? (-1f) : 1f) + 12f * (float)l * ((k == 2) ? 1f : (-1f)), 500f) + vector, value, color, 0f, new Vector2(16f, 16f), num7, SpriteEffects.None, 1f);
					}
				}
				if (shopMgr.IsActive())
				{
					shopMgr.Draw(sprite, threedee);
					return;
				}
			}
			if (!Game1.gameMap.yukiDeathFocus && totalBoss > 0)
			{
				for (int m = 0; m < totalBoss; m++)
				{
					bossBox[m].Draw(sprite, new Vector2(ScrollManager.screenSize.X / 2f - (float)bossBox[m].width / 2f, ScrollManager.screenSize.Y - 100f - 32f * (float)m) + vector, 1f, flip: false);
				}
			}
			if (DebugManager.showFPS != DebugManager.StatMode.Off)
			{
				sprite.Draw(Game1.spritesTex, new Vector2(80f, 240f) + vector, new Rectangle(640, 384, 256, 64), new Color(0f, 0f, 0f, 0.6f), 0f, default, new Vector2(0.43f, 0.77f), SpriteEffects.None, 1f);
				Text.DrawCText(sprite, new Vector2(90f, 250f) + vector, DebugManager.fpsString, Color.Lime, 0.7f, 0);
				Text.DrawScore(160 + (int)vector.X, 250, (long)DebugManager.fps, new Color(1f, 1f, 1f, 1f), sprite, flip: false, 0f, 0.7f);
			}
			if (DebugManager.showSprites != DebugManager.StatMode.Off)
			{
				sprite.Draw(Game1.spritesTex, new Vector2(80f, 280f) + vector, new Rectangle(640, 384, 256, 64), new Color(0f, 0f, 0f, 0.6f), 0f, default, new Vector2(0.73f, 0.77f), SpriteEffects.None, 1f);
				Text.DrawCText(sprite, new Vector2(90f, 290f) + vector, DebugManager.spritesString, Color.Red, 0.7f, 0);
				Text.DrawScore(250 + (int)vector.X, 290, DebugManager.totalSprites, new Color(1f, 1f, 1f, 1f), sprite, flip: false, 0f, 0.7f);
			}
			if (Game1.levelMgr.currentTrack == 6 || Game1.levelMgr.currentTrack == 5)
			{
				Game1.practice.Draw(sprite, threedee);
			}
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
			{
				if (Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.Blitz || Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.TurboBlitz)
				{
					int num8 = (int)Game1.arcade.blitzFrame;
					if (num8 < 0)
					{
						num8 = 0;
					}
					if (num8 > HUDStrings.timeStr.Length - 1)
					{
						num8 = HUDStrings.timeStr.Length - 1;
					}
					float num9 = Game1.arcade.blitzFrame - (float)(int)Game1.arcade.blitzFrame;
					float num10 = num9 - 0.8f;
					if (num10 < 0f)
					{
						num10 = 0f;
					}
					if (num10 > 0f)
					{
						for (int n = 0; n < 2; n++)
						{
							Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 100f) + Rand.GetRandomVec2(-5f, 5f, -5f, 5f) * num10 * 20f + vector, HUDStrings.timeStr[num8], new Color(1f, 0f, 0f, num10 * 3f), 1.3f, 1);
						}
					}
					Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 100f) + Rand.GetRandomVec2(-5f, 5f, -5f, 5f) * num10 * 10f + vector, HUDStrings.timeStr[num8], new Color(1f, 1f, 1f, 1f), 1.3f, 1);
				}
			}
			else
			{
				DrawTimes(sprite, vector);
			}
			if (waveDefeatedFrame > 0f)
			{
				DrawWaveDefeated(sprite, threedee);
			}
			if ((Game1.netSession.IsHost() || Game1.netSession.IsClient()) && Game1.netSession.netGame.IsPanic() && (int)(Game1.gameMap.frame * 2f) % 2 == 0)
			{
				sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f + new Vector2(0f, -200f), new Rectangle((int)ScrollManager.screenSize.X - 196, 864, 64, 64), new Color(1f, 1f, 1f, 1f), 0f, new Vector2(32f, 32f), 2f, SpriteEffects.None, 1f);
			}
			if (DebugManager.showPerf)
			{
				DebugManager.DrawPerf(sprite, new Vector2(84f, 450f), threedee);
			}
			if (DebugManager.showSprites == DebugManager.StatMode.History || DebugManager.showFPS == DebugManager.StatMode.History)
			{
				DebugManager.DrawHistory(sprite, new Vector2(84f, 340f), threedee);
			}
		}
	}

	private void DrawTimes(SpriteBatch sprite, Vector2 offx)
	{
		float num = 100f;
		if (GameSettings.difficulty == 5)
		{
			int num2 = (int)Game1.levelMgr.elapsedTime;
			if (num2 < 0)
			{
				num2 = 0;
			}
			if (num2 > HUDStrings.timeStr.Length - 1)
			{
				num2 = HUDStrings.timeStr.Length - 1;
			}
			float num3 = Game1.levelMgr.elapsedTime - (float)(int)Game1.levelMgr.elapsedTime;
			if (num2 < HUDStrings.timeStr.Length)
			{
				float num4 = num3 - 0.8f;
				if (num4 < 0f)
				{
					num4 = 0f;
				}
				if (num4 > 0f)
				{
					for (int i = 0; i < 2; i++)
					{
						Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 100f) + Rand.GetRandomVec2(-5f, 5f, -5f, 5f) * num4 * 20f + offx, HUDStrings.timeStr[num2], new Color(1f, 0f, 0f, num4 * 3f), 1.3f, 1);
					}
				}
				Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 100f) + Rand.GetRandomVec2(-5f, 5f, -5f, 5f) * num4 * 10f + offx, HUDStrings.timeStr[num2], new Color(1f, 1f, 1f, 1f), 1.3f, 1);
			}
			else
			{
				Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, 100f) + offx, HUDStrings.nullString, new Color(1f, 1f, 1f, 1f), 1.3f, 1);
			}
			num += 30f;
		}
		if (!Game1.gameMap.CurMap().scriptMgr.mapCountDown.GetActive())
		{
			return;
		}
		float countDownFrame = Game1.gameMap.CurMap().scriptMgr.mapCountDown.countDownFrame;
		int num5 = (int)countDownFrame;
		if (num5 < 0)
		{
			num5 = 0;
		}
		if (num5 > HUDStrings.timeStr.Length - 1)
		{
			num5 = HUDStrings.timeStr.Length - 1;
		}
		float num6 = countDownFrame - (float)(int)countDownFrame;
		if (num5 < HUDStrings.timeStr.Length)
		{
			float num7 = num6 - 0.8f;
			if (num7 < 0f)
			{
				num7 = 0f;
			}
			if (num7 > 0f)
			{
				for (int j = 0; j < 2; j++)
				{
					Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, num) + Rand.GetRandomVec2(-5f, 5f, -5f, 5f) * num7 * 20f + offx, HUDStrings.timeStr[num5], new Color(1f, 0f, 0f, num7 * 3f), 1.3f, 1);
				}
			}
			Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, num) + Rand.GetRandomVec2(-5f, 5f, -5f, 5f) * num7 * 10f + offx, HUDStrings.timeStr[num5], new Color(1f, 1f, 1f, 1f), 1.3f, 1);
		}
		else
		{
			Text.DrawJText(sprite, new Vector2(ScrollManager.screenSize.X / 2f, num) + offx, HUDStrings.nullString, new Color(1f, 1f, 1f, 1f), 1.3f, 1);
		}
	}

	private void DrawPrompts(SpriteBatch sprite, int threedee)
	{
		for (int i = 0; i < Game1.GetPlayers(); i++)
		{
			Game1.character[i].charUpdate.charPrompt.Draw(Game1.character[i], sprite, threedee);
		}
	}

	private void DrawCornerChars(SpriteBatch sprite, int threedee)
	{
		if (Game1.gameMap.lichFreakoutMode || Game1.gameMap.theme.theme == Themes.ThemeType.Asylum)
		{
			return;
		}
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		float charBrite = GameRender.filterRender.charBrite;
		GameRender.filterRender.charBrite = 1f;
		for (int i = 0; i < Game1.character.Length; i++)
		{
			Character character = Game1.character[i];
			if (!character.exists)
			{
				continue;
			}
			if (character.team == Character.Team.GoodGuys && Game1.levelMgr.currentTrack == 2 && Game1.IsPlayerChar(i))
			{
				Vector2 loc = character.charUpdate.loc;
				Vector2 traj = character.charUpdate.traj;
				if (loc.X < 64f && traj.X < 0f && Game1.character[i].charKeys.keyLeft)
				{
					DrawTransArrow(sprite, character, 0, threedee);
				}
				if (loc.X > (float)Game1.gameMap.CurMap().xSize * 64f - 64f && traj.X > 0f && Game1.character[i].charKeys.keyRight)
				{
					DrawTransArrow(sprite, character, 1, threedee);
				}
			}
			if (character.team != Character.Team.BadGuys || character.charUpdate.inactive || character.charUpdate.nomusic || !character.GetMeta().isBoss || character.charUpdate.charGrab.grabbedByChar >= 0 || !(character.charUpdate.spawnFrame <= 0f) || !(character.charUpdate.wait <= 0f))
			{
				continue;
			}
			lock (character)
			{
				CharUpdate charUpdate = character.charUpdate;
				Vector2 screenLoc = ScrollManager.GetScreenLoc(charUpdate.loc, 1f);
				Vector2 size = character.charRect.GetSize();
				float num = 100f;
				if (!(screenLoc.X - size.X < 0f - num) && !(screenLoc.X + size.X > ScrollManager.screenSize.X + num) && !(screenLoc.Y - size.Y < 0f - num) && !(screenLoc.Y > ScrollManager.screenSize.Y + num))
				{
					continue;
				}
				float rotation = Trig.GetAngle(screenLoc, ScrollManager.screenSize / 2f) + 0.785f;
				Vector2 screenLoc2 = ScrollManager.GetScreenLoc(character.charUpdate.loc + new Vector2(0f, size.Y / -2f), 1f);
				float num2 = 160f;
				if (screenLoc2.Y < num2)
				{
					screenLoc2.Y = num2;
				}
				if (screenLoc2.Y > ScrollManager.screenSize.Y - num2)
				{
					screenLoc2.Y = ScrollManager.screenSize.Y - num2;
				}
				if (screenLoc2.X < num2)
				{
					screenLoc2.X = num2;
				}
				if (screenLoc2.X > ScrollManager.screenSize.X - num2)
				{
					screenLoc2.X = ScrollManager.screenSize.X - num2;
				}
				sprite.Draw(Game1.spritesTex, screenLoc2 + vector, new Rectangle(1024, 0, 128, 128), new Color(1f, 0f, 0f, 1f), rotation, new Vector2(64f, 64f), 1f, SpriteEffects.None, 1f);
				screenLoc2.Y += 60f;
				float scale = 90f / (size.X + size.Y);
				CharDef charDef = Game1.charDef[character.cDef];
				CharAnim charAnim = character.charAnim;
				CharRender charRender = character.charRender;
				int charMeta = character.charMeta;
				if (charDef.GetAnimation(charAnim.anim).GetKeyFrame(charAnim.GetKey()).lerp)
				{
					int num3 = charAnim.GetKey() + 1;
					if (num3 >= charDef.GetAnimation(charAnim.anim).getKeyFrameArray().Length)
					{
						num3 = 0;
					}
					else if (charDef.GetAnimation(charAnim.anim).GetKeyFrame(num3) == null)
					{
						num3 = 0;
					}
					else if (charDef.GetAnimation(charAnim.anim).GetKeyFrame(num3).duration <= 0)
					{
						num3 = 0;
					}
					charRender.DrawCharacter(sprite, screenLoc2 + vector, scale, charUpdate.face, charAnim.GetCurFrame(), charDef, Game1.charMeta[charMeta], null, null, charUpdate, character, charDef.GetAnimation(charAnim.anim).GetKeyFrame(num3).frameRef, grabberOnly: false);
				}
				else
				{
					charRender.DrawCharacter(sprite, screenLoc2 + vector, scale, charUpdate.face, charAnim.GetCurFrame(), charDef, Game1.charMeta[charMeta], charUpdate, character);
				}
			}
		}
		GameRender.filterRender.charBrite = charBrite;
	}

	private void DrawWaveDefeated(SpriteBatch sprite, int threedee)
	{
		float num = 1f;
		if (waveDefeatedFrame > 0.95f)
		{
			num = (1f - waveDefeatedFrame) * 20f;
		}
		else
		{
			num = ((!(waveDefeatedFrame < 0.9f)) ? 1f : (waveDefeatedFrame * 1.1111112f));
		}
		for (int i = 0; i < 32; i++)
		{
			float randomFloat = Rand.GetRandomFloat(0f, 6.28f);
			sprite.Draw(Game1.spritesTex, ScrollManager.screenSize / 2f + new Vector2((float)Math.Cos(randomFloat), (float)Math.Sin(randomFloat)) * Rand.GetRandomFloat(400f, 800f), new Rectangle(128, Rand.GetRandomInt(0, 3) * 32, 128, 32), new Color(0f, 0f, 0f, num), randomFloat, new Vector2(64f, 16f), Rand.GetRandomVec2(0.1f, 2f, 0.1f, 2f), SpriteEffects.None, 1f);
		}
	}

	private void DrawLensFlareBit(SpriteBatch sprite, float p, int idx, float alpha, float frame, float size, Vector2 off)
	{
		Rectangle value = new Rectangle(992, 1024, 128, 128);
		if (idx > 0)
		{
			value = new Rectangle(800 + 64 * (idx - 1), 1088, 64, 64);
		}
		if (off.X > 0f)
		{
			off.X += p * 2f;
		}
		if (off.X < 0f)
		{
			off.X -= p * 2f;
		}
		p -= 0.5f;
		Vector2 vector = new Vector2(ScrollManager.screenSize.X * p, (ScrollManager.screenSize.Y - 80f) * p);
		vector *= 0.8f + frame * 0.3f;
		vector += ScrollManager.screenSize / 2f;
		sprite.Draw(Game1.spritesTex, vector + off, value, new Color(1f, 1f, 1f, alpha * 0.175f), frame, new Vector2((float)value.Width / 2f, (float)value.Height / 2f), size, SpriteEffects.None, 1f);
	}

	private void DrawTransArrow(SpriteBatch sprite, Character c, int face, int threedee)
	{
		Vector2 screenLoc = ScrollManager.GetScreenLoc(c.charUpdate.loc + new Vector2(0f, -40f), 1f);
		new Rectangle(64, 640, 64, 64);
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		float num = 100f;
		if (screenLoc.X < num)
		{
			screenLoc.X = num;
		}
		if (screenLoc.Y < num)
		{
			screenLoc.Y = num;
		}
		if (screenLoc.X > ScrollManager.screenSize.X - num)
		{
			screenLoc.X = ScrollManager.screenSize.X - num;
		}
		if (screenLoc.Y > ScrollManager.screenSize.Y - num)
		{
			screenLoc.Y = ScrollManager.screenSize.Y - num;
		}
		float num2 = ((face == 0) ? (-1f) : 1f) * 50f;
		screenLoc.X += num2 * (transFrame - 0.5f);
		float alpha = 1f;
		if (transFrame < 0.2f)
		{
			alpha = transFrame * 5f;
		}
		if (transFrame > 0.8f)
		{
			alpha = (1f - transFrame) * 5f;
		}
		flibitPort.DrawButtonAttrib('d', screenLoc + vector, new Color(1f, 1f, 1f, alpha), (face == 0) ? 1.57f : (-1.57f), new Vector2(32f, 32f), 2f, SpriteEffects.None, 1f);
	}

	internal void DrawArcadeIn(SpriteBatch spriteBatch, int threedee)
	{
		arcadeIn.Draw(spriteBatch, threedee);
	}

	internal bool IsArcadeIn()
	{
		return arcadeIn.IsActive();
	}

	internal void ResetWaveDefeatedOkFrame()
	{
		waveDefeatedOkFrame = 0.5f;
	}

	internal void ReadEndLevelStuff(PacketReader reader)
	{
		endLevel.ReadEndStuff(reader);
	}

	internal void ResetEndLevel()
	{
		endLevel.active = false;
		endLevel.readBeforeSave = false;
	}

	internal void RetryEndLevel()
	{
		endLevel.frame = 22f;
	}

	internal void RetryEndLevelNoSave()
	{
		endLevel.frame = 20f;
		endLevel.noSave = true;
	}

	internal void ReceiveServerTime(float t)
	{
		endLevel.ReceiveServerTime(t);
	}

	internal bool WaveDefeated()
	{
		return waveDefeatedFrame > 0f;
	}

	internal void ClearTut()
	{
		tutMgr.active = false;
		tutMgr.alpha = 0f;
	}

	internal void SetEndLevelReadBeforeSave()
	{
		endLevel.readBeforeSave = true;
	}
}
