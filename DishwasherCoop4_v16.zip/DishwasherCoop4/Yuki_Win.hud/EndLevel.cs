﻿using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.guidestuff;
using Yuki_Win.leaderboards;
using Yuki_Win.player;
using Yuki_Win.storage;
using Yuki_Win.worldmap;

namespace Yuki_Win.hud;

public class EndLevel
{
	public enum EndLevelPhase
	{
		Stats,
		Next
	}

	public float frame;

	public bool active;

	private bool awaitingServerTime;

	public static StringBuilder levelCompleteStr = new StringBuilder(YukiText.e_levelComplete);

	public static StringBuilder timeStr = new StringBuilder(YukiText.e_time);

	public static StringBuilder killsStr = new StringBuilder(YukiText.e_kills);

	public static StringBuilder maxComboStr = new StringBuilder(YukiText.e_maxCombo);

	public static StringBuilder scoreStr = new StringBuilder(YukiText.e_score);

	public static StringBuilder damageStr = new StringBuilder(YukiText.e_damage);

	private StringBuilder[] names;

	private StringBuilder[] time;

	private StringBuilder[] kills;

	private StringBuilder[] maxCombo;

	private StringBuilder[] score;

	private StringBuilder[] damage;

	private long[] lscore;

	public bool serverClick;

	public int players;

	private int selected;

	private bool alreadyWarned;

	public bool noSave;

	public bool readBeforeSave;

	public bool queuedServerClick;

	public EndLevelPhase phase;

	private StringBuilder[] mustBeSignedInToSubmit = new StringBuilder[3]
	{
		new StringBuilder(YukiText.MustBeSignedInToSubmit1),
		new StringBuilder(YukiText.MustBeSignedInToSubmit2),
		new StringBuilder(YukiText.MustBeSignedInToSubmit3)
	};

	public EndLevel()
	{
		time = new StringBuilder[4];
		kills = new StringBuilder[4];
		maxCombo = new StringBuilder[4];
		score = new StringBuilder[4];
		damage = new StringBuilder[4];
		names = new StringBuilder[4];
		lscore = new long[4];
	}

	public void NetWriteEndStuff(int idx, int kills, int maxCombo, long score, int damage)
	{
		Game1.netSession.netGame.SendEndStuff(Game1.netSession.session, idx, kills, maxCombo, score, damage);
	}

	public void DoEnd()
	{
		alreadyWarned = false;
		noSave = false;
		if (Game1.netSession.IsClient())
		{
			serverClick = false;
			queuedServerClick = false;
		}
		awaitingServerTime = false;
		if (readBeforeSave)
		{
			Game1.storageMgr.storage[0].ReadAll();
			readBeforeSave = false;
		}
		if ((Game1.netSession.IsHost() || Game1.netSession.IsClient()) && Game1.netSession.gamerTag.Length > 1)
		{
			BottomRightMessage.strings[23] = new StringBuilder(string.Concat(YukiText.SHOWGAMERCARDCAPS.ToString(), " (", Game1.netSession.gamerTag[0], ")"));
			BottomRightMessage.strings[24] = new StringBuilder(string.Concat(YukiText.SHOWGAMERCARDCAPS.ToString(), " (", Game1.netSession.gamerTag[1], ")"));
		}
		if (active)
		{
			return;
		}
		active = true;
		frame = 0f;
		phase = EndLevelPhase.Stats;
		players = Game1.GetPlayers();
		for (int i = 0; i < Game1.GetPlayers(); i++)
		{
			Game1.character[i].charUpdate.dyingFrame = 0f;
			Game1.gamePlayerMgr.gamePlayer[i].CashInCombo();
			string text = "";
			int num = (int)Game1.levelMgr.elapsedTime;
			Game1.gamePlayerMgr.gamePlayer[i].time = Game1.levelMgr.elapsedTime;
			int num2 = num % 60;
			text = num2.ToString();
			if (num2 < 10)
			{
				text = "0" + text;
			}
			text = num / 60 + ":" + text;
			time[i] = new StringBuilder(text);
			if (Game1.gamePlayerMgr.gamePlayer[i].gamerTag != null)
			{
				names[i] = new StringBuilder(Game1.gamePlayerMgr.gamePlayer[i].gamerTag.ToString());
			}
			if ((!Game1.netSession.IsHost() || i != 1) && (!Game1.netSession.IsClient() || i != 0))
			{
				kills[i] = new StringBuilder(Game1.gamePlayerMgr.gamePlayer[i].totalKills.ToString());
				maxCombo[i] = new StringBuilder(Game1.gamePlayerMgr.gamePlayer[i].maxCombos.ToString());
				damage[i] = new StringBuilder(((int)Game1.gamePlayerMgr.gamePlayer[i].damage).ToString());
				long num3 = Game1.gamePlayerMgr.gamePlayer[i].score;
				int num4 = 0;
				string text2 = "";
				lscore[i] = Game1.gamePlayerMgr.gamePlayer[i].score;
				if (num3 == 0)
				{
					text2 = "0";
				}
				else
				{
					while (num3 > 0)
					{
						num4++;
						if (num4 % 4 == 0)
						{
							text2 = Text.language switch
							{
								2 => " " + text2, 
								1 => "." + text2, 
								_ => "," + text2, 
							};
						}
						else
						{
							long num5 = num3 % 10;
							num3 /= 10;
							text2 = num5 + text2;
						}
					}
				}
				score[i] = new StringBuilder(text2);
			}
			if ((Game1.netSession.IsHost() && i == 0) || (Game1.netSession.IsClient() && i == 1))
			{
				Game1.netSession.netGame.SendEndStuff(Game1.netSession.session, i, Game1.gamePlayerMgr.gamePlayer[i].totalKills, Game1.gamePlayerMgr.gamePlayer[i].maxCombos, Game1.gamePlayerMgr.gamePlayer[i].score, (int)Game1.gamePlayerMgr.gamePlayer[i].damage);
			}
		}
		if (Game1.netSession.IsHost())
		{
			Game1.netSession.netGame.SendEndLevelTime(Game1.netSession.session, Game1.levelMgr.elapsedTime);
		}
		if (Game1.netSession.IsClient())
		{
			awaitingServerTime = true;
		}
		else
		{
			LeaderWrite();
		}
	}

	public void ReceiveServerTime(float servertime)
	{
		Game1.levelMgr.elapsedTime = servertime;
		int num = 1;
		string text = "";
		int num2 = (int)Game1.levelMgr.elapsedTime;
		Game1.gamePlayerMgr.gamePlayer[num].time = Game1.levelMgr.elapsedTime;
		int num3 = num2 % 60;
		text = num3.ToString();
		if (num3 < 10)
		{
			text = "0" + text;
		}
		text = num2 / 60 + ":" + text;
		time[num] = new StringBuilder(text);
		awaitingServerTime = false;
		LeaderWrite();
	}

	private void LeaderWrite()
	{
		switch (Game1.arcade.arcadeMode)
		{
		case Arcade.ArcadeMode.Arcade:
			if (Game1.arcade.players == 1)
			{
				Game1.leaderBoard.Write(0, Game1.levelMgr.currentLevel, lscore[0], (long)(Game1.levelMgr.elapsedTime * 100f));
			}
			else if (Game1.netSession.IsHost())
			{
				Game1.leaderBoard.Write(2, Game1.levelMgr.currentLevel, lscore[0], (long)(Game1.levelMgr.elapsedTime * 100f));
			}
			else if (Game1.netSession.IsClient())
			{
				Game1.gamePlayerMgr.gamePlayer[1].CashInCombo();
				lscore[1] = Game1.gamePlayerMgr.gamePlayer[1].score;
				Game1.leaderBoard.Write(2, Game1.levelMgr.currentLevel, lscore[1], (long)(Game1.levelMgr.elapsedTime * 100f));
			}
			else
			{
				Game1.leaderBoard.Write(2, Game1.levelMgr.currentLevel, lscore[0], (long)(Game1.levelMgr.elapsedTime * 100f), lscore[1]);
			}
			break;
		case Arcade.ArcadeMode.DishChallenge:
			Game1.leaderBoard.WriteDishChallenge(lscore[0], Game1.levelMgr.levels[4][0].arcadeWeapon[0, 0], Game1.levelMgr.levels[4][0].arcadeWeapon[0, 1], Game1.levelMgr.levels[4][0].arcadePlayer[0]);
			break;
		case Arcade.ArcadeMode.Off:
		{
			int difficulty = GameSettings.difficulty;
			if (difficulty == 5)
			{
				switch (Game1.levelMgr.currentTrack)
				{
				case 1:
					Game1.leaderBoard.Write(6, Game1.levelMgr.currentLevel, lscore[0], (long)(Game1.levelMgr.elapsedTime * 100f));
					break;
				case 0:
					Game1.leaderBoard.Write(7, Game1.levelMgr.currentLevel, lscore[0], (long)(Game1.levelMgr.elapsedTime * 100f));
					break;
				}
			}
			break;
		}
		}
	}

	private bool WriteData()
	{
		if (noSave)
		{
			return false;
		}
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.DishChallenge)
		{
			return false;
		}
		int num = Game1.GetPlayers();
		int num2 = 0;
		if (Game1.netSession.IsHost())
		{
			num2 += WritePlayerData(0, 0);
		}
		else if (Game1.netSession.IsClient())
		{
			num2 += WritePlayerData(1, 0);
		}
		else
		{
			for (int i = 0; i < num; i++)
			{
				num2 += WritePlayerData(i, i);
			}
		}
		return num2 > 0;
	}

	private int WritePlayerData(int player, int storage)
	{
		PlayerLevelData.LevelTrack trackFromDifficulty = PlayerLevelData.GetTrackFromDifficulty(Game1.levelMgr.currentTrack, GameSettings.difficulty);
		LevelTrackData levelTrackData = Game1.storageMgr.playerData[player].levelData[(int)trackFromDifficulty];
		LevelData levelData = levelTrackData.levelData[Game1.levelMgr.currentLevel];
		if (Game1.gamePlayerMgr.gamePlayer[player].damage < levelData.damage || levelData.time <= 0f)
		{
			levelData.damage = Game1.gamePlayerMgr.gamePlayer[player].damage;
		}
		if (Game1.gamePlayerMgr.gamePlayer[player].time < levelData.time || levelData.time <= 0f)
		{
			levelData.SetTime(Game1.gamePlayerMgr.gamePlayer[player].time);
		}
		if (Game1.gamePlayerMgr.gamePlayer[player].score > levelData.score)
		{
			levelData.score = Game1.gamePlayerMgr.gamePlayer[player].score;
		}
		if (Game1.gamePlayerMgr.gamePlayer[player].maxCombos > levelData.maxCombo)
		{
			levelData.maxCombo = Game1.gamePlayerMgr.gamePlayer[player].maxCombos;
		}
		if (Game1.gamePlayerMgr.gamePlayer[player].totalKills > levelData.kills)
		{
			levelData.kills = Game1.gamePlayerMgr.gamePlayer[player].totalKills;
		}
		return Game1.storageMgr.storage[storage].Write(1);
	}

	public void Update()
	{
		float pframe = frame;
		frame += FMan.realTime;
		switch (phase)
		{
		case EndLevelPhase.Stats:
			UpdateStatsLevel(pframe);
			break;
		case EndLevelPhase.Next:
			UpdateNextLevel(pframe);
			break;
		}
	}

	private void UpdateNextLevel(float pframe)
	{
		Game1.worldMapMgr.NextUpdate(Game1.levelMgr.currentLevel + 1, frame > 1f);
		if (pframe <= 0.1f && frame > 0.1f)
		{
			Sound.PlaySnd(Sound.Category.FX, "slam");
		}
		if (frame >= 20f)
		{
			if (frame > 22f)
			{
				active = false;
				Game1.sceneMgr.playing = false;
				Game1.levelMgr.NextLevel();
				if (GameSettings.difficulty == 5)
				{
					GuideStuff.CheckLiveStart(noWarn: true);
				}
			}
		}
		else
		{
			if (!(frame > 7f))
			{
				return;
			}
			frame = 7f;
			if (Game1.netSession.IsClient())
			{
				if (serverClick)
				{
					frame = 20f;
					Sound.PlaySnd(Sound.Category.FX, "bell");
					serverClick = false;
				}
			}
			else if (Game1.character[0].charKeys.keyJump || (Game1.GetPlayers() >= 2 && Game1.character[0].charKeys.keyJump))
			{
				frame = 20f;
				Sound.PlaySnd(Sound.Category.FX, "bell");
				if (Game1.netSession.IsHost())
				{
					Game1.netSession.netGame.SendServerClick(Game1.netSession.session);
				}
			}
		}
	}

	private void UpdateStatsLevel(float pframe)
	{
		if (Game1.netSession.IsHost() && pframe < 4f && frame >= 4f && Game1.netSession.session.SessionState == NetworkSessionState.Playing)
		{
			Game1.netSession.session.EndGame();
			Game1.netSession.session.Update();
		}
		if (pframe <= 0.1f && frame > 0.1f)
		{
			Sound.PlaySnd(Sound.Category.FX, "slam");
		}
		if (frame >= 20f)
		{
			if (!(frame > 22f))
			{
				return;
			}
			if (WriteData() && !Game1.netSession.IsClient() && !Game1.netSession.IsHost())
			{
				frame = 5f;
				if (Game1.netSession.IsClient())
				{
					queuedServerClick = true;
				}
				return;
			}
			if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
			{
				Game1.menuMgr.messageMgr.Kill();
			}
			if (Game1.netSession.IsHost() && Game1.netSession.session.SessionState != NetworkSessionState.Playing)
			{
				Game1.netSession.session.StartGame();
			}
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off)
			{
				phase = EndLevelPhase.Next;
				frame = 0f;
				if (GameState.paxDemoMode || GuideStuff.GetTrial())
				{
					Game1.menuMgr.DemoReset();
					active = false;
				}
				if (GameState.longDemoMode && Game1.levelMgr.currentLevel > 2)
				{
					Game1.menuMgr.DemoReset();
					active = false;
				}
				if (Game1.levelMgr.currentLevel == 0 && Game1.levelMgr.currentTrack == 0)
				{
					Game1.achievementMgr.playerAchievements[0].achievementList[0].Unlock(overRide: false);
					if (!GuideStuff.GetTrial())
					{
						Game1.menuMgr.EndLevelOne();
						active = false;
					}
				}
				if (Game1.levelMgr.currentLevel == 7 && Game1.levelMgr.currentTrack == 0)
				{
					Game1.achievementMgr.playerAchievements[0].achievementList[9].Unlock(overRide: false);
				}
				if (Game1.levelMgr.currentLevel + 1 < Game1.levelMgr.levels[Game1.levelMgr.currentTrack].Count)
				{
					return;
				}
				Game1.levelMgr.currentLevel = Game1.levelMgr.levels[Game1.levelMgr.currentTrack].Count - 1;
				Game1.credits.Init();
				active = false;
				switch (Game1.levelMgr.currentTrack)
				{
				case 0:
					Game1.achievementMgr.playerAchievements[0].achievementList[1].Unlock(overRide: false);
					if (!Game1.storageMgr.playerData[0].wonGame)
					{
						Game1.storageMgr.playerData[0].wonGame = true;
						Game1.menuMgr.messageMgr.AddMsg(YukiText.difficultyUnlocked, new string[2]
						{
							YukiText.unlockedsamuraiDiff1,
							YukiText.unlockedsamuraiDiff2
						});
					}
					break;
				case 1:
					Game1.achievementMgr.playerAchievements[0].achievementList[2].Unlock(overRide: false);
					if (!Game1.storageMgr.playerData[0].wonGame)
					{
						Game1.storageMgr.playerData[0].wonGame = true;
						Game1.menuMgr.messageMgr.AddMsg(YukiText.difficultyUnlocked, new string[2]
						{
							YukiText.unlockedsamuraiDiff1,
							YukiText.unlockedsamuraiDiff2
						});
					}
					break;
				case 2:
					if (Game1.netSession.IsHost())
					{
						Game1.achievementMgr.playerAchievements[0].achievementList[1].Unlock(overRide: false);
						break;
					}
					if (Game1.netSession.IsClient())
					{
						Game1.achievementMgr.playerAchievements[0].achievementList[2].Unlock(overRide: false);
						break;
					}
					Game1.achievementMgr.playerAchievements[0].achievementList[1].Unlock(overRide: false);
					Game1.achievementMgr.playerAchievements[1].achievementList[2].Unlock(overRide: false);
					break;
				}
				if (GameSettings.difficulty == 4)
				{
					Game1.achievementMgr.playerAchievements[0].achievementList[3].Unlock(overRide: false);
					if (Game1.levelMgr.currentTrack == 2 && !Game1.netSession.IsHost() && !Game1.netSession.IsClient())
					{
						Game1.achievementMgr.playerAchievements[1].achievementList[3].Unlock(overRide: false);
					}
				}
				return;
			}
			active = false;
			Game1.sceneMgr.playing = false;
			if (GuideStuff.GetTrial())
			{
				Game1.menuMgr.DemoReset();
				active = false;
			}
			else if ((GameState.paxDemoMode || GameState.longDemoMode) && Game1.levelMgr.currentLevel >= 4)
			{
				Game1.menuMgr.DemoReset();
				active = false;
			}
			else if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.DishChallenge)
			{
				Game1.menuMgr.EndDishChallenge();
			}
			else if (Game1.levelMgr.currentLevel + 1 >= Game1.levelMgr.levels[Game1.levelMgr.currentTrack].Count)
			{
				Game1.levelMgr.currentLevel = Game1.levelMgr.levels[Game1.levelMgr.currentTrack].Count - 1;
				Game1.credits.Init();
				active = false;
				if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
				{
					Game1.achievementMgr.playerAchievements[0].achievementList[4].Unlock(overRide: false);
					return;
				}
				for (int i = 0; i < Game1.arcade.players; i++)
				{
					Game1.achievementMgr.playerAchievements[i].achievementList[4].Unlock(overRide: false);
				}
			}
			else
			{
				Game1.levelMgr.NextLevel();
				GuideStuff.CheckLiveStart(noWarn: true);
			}
		}
		else
		{
			if (!(frame > 5f))
			{
				return;
			}
			frame = 5f;
			if (Game1.netSession.IsClient())
			{
				if (!Guide.IsVisible && queuedServerClick)
				{
					queuedServerClick = false;
					serverClick = true;
				}
				if (serverClick)
				{
					frame = 20f;
					Sound.PlaySnd(Sound.Category.FX, "bell");
					serverClick = false;
				}
				if (Guide.IsVisible)
				{
					return;
				}
				try
				{
					if (Game1.character[1].charKeys.keyAttack)
					{
						Guide.ShowGamerCard((PlayerIndex)Game1.mainPlayer[0], Game1.netSession.session.RemoteGamers[0]);
					}
					if (Game1.character[1].charKeys.keyStrong)
					{
						Guide.ShowGamerCard((PlayerIndex)Game1.mainPlayer[0], Game1.netSession.session.LocalGamers[0]);
					}
					return;
				}
				catch
				{
					return;
				}
			}
			if (Game1.character[0].charKeys.keyJump || Game1.AnyCoopJump())
			{
				frame = 20f;
				Sound.PlaySnd(Sound.Category.FX, "bell");
				if (Game1.netSession.IsHost())
				{
					Game1.netSession.netGame.SendServerClick(Game1.netSession.session);
				}
			}
			if (Game1.netSession.IsHost() && !Guide.IsVisible)
			{
				try
				{
					if (Game1.character[0].charKeys.keyAttack)
					{
						Guide.ShowGamerCard((PlayerIndex)Game1.mainPlayer[0], Game1.netSession.session.RemoteGamers[0]);
					}
					if (Game1.character[0].charKeys.keyStrong)
					{
						Guide.ShowGamerCard((PlayerIndex)Game1.mainPlayer[0], Game1.netSession.session.LocalGamers[0]);
					}
				}
				catch
				{
				}
			}
			if (Game1.arcade.arcadeMode != Arcade.ArcadeMode.Off || (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off && GameSettings.difficulty == 5))
			{
				LeaderBoard.LeaderState state = Game1.leaderBoard.state;
				if (state == LeaderBoard.LeaderState.WriteFailed && (Game1.character[0].charKeys.keyStrong || (Game1.GetPlayers() >= 2 && Game1.character[1].charKeys.keyStrong)))
				{
					LeaderWrite();
				}
			}
		}
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		float num = frame;
		if (num > 1f)
		{
			num = 1f;
		}
		num *= 0.9f;
		Vector2 vector = default;
		switch (threedee)
		{
		case 0:
			vector.X = 1f;
			break;
		case 1:
			vector.X = -1f;
			break;
		}
		SpriteTools.BeginAlpha();
		switch (phase)
		{
		case EndLevelPhase.Stats:
		{
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, num));
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
			{
				float num2 = frame - 0.5f;
				if (num2 > 0f)
				{
					for (int i = 0; i < Game1.arcade.players; i++)
					{
						float num3 = ScrollManager.screenSize.X / 2f;
						num3 = ScrollManager.screenSize.X / 4f + ScrollManager.screenSize.X / 2f * (float)i;
						if (Game1.arcade.players > 2)
						{
							num3 = ScrollManager.screenSize.X / (float)(Game1.arcade.players * 2) + ScrollManager.screenSize.X / (float)Game1.arcade.players * (float)i;
						}
						int num4 = 0;
						switch (Game1.arcade.player[i])
						{
						case 1:
							num4 = 0;
							break;
						case 0:
							num4 = 1;
							break;
						case 2:
							num4 = 2;
							break;
						case 4:
							num4 = 3;
							break;
						case 3:
							num4 = 4;
							break;
						}
						sprite.Draw(Game1.portraitsTex, new Vector2(num3, ScrollManager.screenSize.Y / 2f) + vector * 0.8f, new Rectangle(num4 * 384, 0, 384, 640), new Color(0.25f, 0.25f, 0.25f, num2), 0f, new Vector2(192f, 360f), 1.2f, SpriteEffects.None, 1f);
					}
				}
			}
			DrawLine(sprite, levelCompleteStr, new Vector2(ScrollManager.screenSize.X / 2f, 100f) + vector, 1, 1f, red: false);
			DrawLine(sprite, Game1.levelMgr.levels[Game1.levelMgr.currentTrack][Game1.levelMgr.currentLevel].nameStr, new Vector2(ScrollManager.screenSize.X / 2f, 140f) + vector, 1, 1.5f, red: true);
			float num5 = 40f;
			float num6 = 240f;
			if (players == 2)
			{
				DrawLine(sprite, null, new Vector2(400f, num6) + vector, 0, 3f, red: false, names);
				DrawLine(sprite, timeStr, new Vector2(400f, num6 + 1f * num5) + vector, 0, 3.25f, red: false, time);
				DrawLine(sprite, killsStr, new Vector2(400f, num6 + 2f * num5) + vector, 0, 3.5f, red: false, kills);
				DrawLine(sprite, maxComboStr, new Vector2(400f, num6 + 3f * num5) + vector, 0, 3.75f, red: false, maxCombo);
				DrawLine(sprite, scoreStr, new Vector2(400f, num6 + 4f * num5) + vector, 0, 4f, red: false, score);
				DrawLine(sprite, damageStr, new Vector2(400f, num6 + 5f * num5) + vector, 0, 4.25f, red: false, damage);
			}
			else
			{
				DrawLine(sprite, timeStr, new Vector2(400f, num6) + vector, 0, 3f, red: false, time);
				DrawLine(sprite, killsStr, new Vector2(400f, num6 + 1f * num5) + vector, 0, 3.3f, red: false, kills);
				DrawLine(sprite, maxComboStr, new Vector2(400f, num6 + 2f * num5) + vector, 0, 3.6f, red: false, maxCombo);
				DrawLine(sprite, scoreStr, new Vector2(400f, num6 + 3f * num5) + vector, 0, 3.9f, red: false, score);
				DrawLine(sprite, damageStr, new Vector2(400f, num6 + 4f * num5) + vector, 0, 4.2f, red: false, damage);
			}
			if (frame > 20f)
			{
				num = frame - 20f;
				if (num > 1f)
				{
					num = 1f;
				}
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, num));
			}
			else if (frame >= 5f)
			{
				if (Game1.netSession.IsClient())
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.WaitingForHost, 0, 1f);
				}
				else
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Continue, 0, 1f);
				}
				if (Game1.netSession.IsClient() || Game1.netSession.IsHost())
				{
					BottomRightMessage.DrawButton(sprite, Game1.netSession.IsClient() ? BottomRightMessage.Button.Y : BottomRightMessage.Button.X, BottomRightMessage.Msg.Gamercard2, 2, 1f, lcText: true);
					BottomRightMessage.DrawButton(sprite, Game1.netSession.IsClient() ? BottomRightMessage.Button.X : BottomRightMessage.Button.Y, BottomRightMessage.Msg.Gamercard1, 3, 1f, lcText: true);
				}
			}
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off && (Game1.arcade.arcadeMode != Arcade.ArcadeMode.Off || GameSettings.difficulty != 5))
			{
				break;
			}
			bool flag = false;
			if (Game1.netSession.IsHost() || Game1.netSession.IsClient())
			{
				flag = true;
			}
			else
			{
				for (int j = 0; j < Game1.GetPlayers(); j++)
				{
					SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex(Game1.mainPlayer[j]);
					if (signedInGamerAtIndex != null && signedInGamerAtIndex.IsSignedInToLive)
					{
						flag = true;
					}
				}
			}
			if (GameState.paxDemoMode || GameState.longDemoMode)
			{
				break;
			}
			if (GuideStuff.initedAsLive || flag)
			{
				switch (Game1.leaderBoard.state)
				{
				case LeaderBoard.LeaderState.ReadingDishChallenge:
				case LeaderBoard.LeaderState.ReadingWeeklyRush:
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.CheckingHighScores, 1, 1f);
					break;
				case LeaderBoard.LeaderState.Writing:
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.SendingScore, 1, 1f);
					break;
				case LeaderBoard.LeaderState.WriteComplete:
				{
					bool flag2 = false;
					if ((Game1.netSession.IsHost() || Game1.netSession.IsClient()) && Game1.netSession.session.SessionState == NetworkSessionState.Playing)
					{
						flag2 = true;
					}
					if (flag2)
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.SendingScore, 1, 1f);
					}
					else
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.ScoreUploaded, 1, 1f);
					}
					break;
				}
				case LeaderBoard.LeaderState.WriteFailed:
					if (frame < 5f)
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.WriteFailed, 1, 1f);
					}
					else
					{
						BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.Y, BottomRightMessage.Msg.ResubmitScore, 1, 1f);
					}
					if (!alreadyWarned)
					{
						alreadyWarned = true;
						Game1.menuMgr.messageMgr.AddMsg(YukiText.writeFailed, new string[3]
						{
							YukiText.MustBeSignedInToSubmit1,
							YukiText.MustBeSignedInToSubmit2,
							YukiText.MustBeSignedInToSubmit3
						});
					}
					break;
				}
			}
			else if (!(frame >= 5f))
			{
			}
			break;
		}
		case EndLevelPhase.Next:
		{
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, 1f));
			float alpha = 1f;
			if (frame < 1f)
			{
				alpha = frame;
			}
			if (frame > 20f)
			{
				alpha = 21f - frame;
			}
			Game1.worldMapMgr.zoom = -5f;
			Game1.worldMapMgr.Draw(sprite, WorldMapMgr.WorldDrawMode.LevelTrans, alpha, Game1.levelMgr.currentLevel + 1, threedee);
			if (frame >= 7f && frame < 20f)
			{
				if (Game1.netSession.IsClient())
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.None, BottomRightMessage.Msg.WaitingForHost, 0, 1f);
				}
				else
				{
					BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Continue, 0, 1f);
				}
			}
			break;
		}
		}
		sprite.End();
	}

	private void DrawLine(SpriteBatch sprite, StringBuilder s, Vector2 loc, int jus, float iFrame, bool red)
	{
		DrawLine(sprite, s, loc, jus, iFrame, red, null);
	}

	private void DrawLine(SpriteBatch sprite, StringBuilder s, Vector2 loc, int jus, float iFrame, bool red, StringBuilder[] str)
	{
		if (!(frame > iFrame))
		{
			return;
		}
		float num = (frame - iFrame) * 2f;
		if (num > 1f)
		{
			num = 1f;
		}
		if (str != null && players == 2)
		{
			loc.X -= 200f;
		}
		if (s != null)
		{
			Text.DrawCText(sprite, loc, s, red ? new Color(1f, 0f, 0f, num) : new Color(1f, 1f, 1f, num), 1f, jus, blur: true);
		}
		if (str == null)
		{
			return;
		}
		for (int i = 0; i < players; i++)
		{
			if (str[i] != null)
			{
				float x = 350f;
				if (players == 2)
				{
					x = ((i != 0) ? 650f : 300f);
				}
				else if (players > 2)
				{
					x = 350f + ((float)i - (float)(players - 1) / 2f) * 200f;
				}
				Text.DrawLCText(sprite, loc + new Vector2(x, 0f), str[i], (i == players - 1) ? new Color(1f, 0f, 0f, num) : new Color(0.5f, 0.5f, 1f, num), 1f, jus, blur: true);
			}
		}
	}

	internal void ReadEndStuff(PacketReader reader)
	{
		int num = reader.ReadByte();
		kills[num] = new StringBuilder(reader.ReadInt32().ToString());
		maxCombo[num] = new StringBuilder(reader.ReadInt32().ToString());
		damage[num] = new StringBuilder(reader.ReadInt32().ToString());
		lscore[num] = reader.ReadInt64();
		long num2 = lscore[num];
		string text = "";
		int num3 = 0;
		if (num2 == 0)
		{
			text = "0";
		}
		else
		{
			while (num2 > 0)
			{
				num3++;
				if (num3 % 4 == 0)
				{
					text = "," + text;
					continue;
				}
				long num4 = num2 % 10;
				num2 /= 10;
				text = num4 + text;
			}
		}
		score[num] = new StringBuilder(text);
	}
}
