using System.Collections.Generic;
using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.hud;

public class BottomRightMessage
{
	public enum Msg
	{
		Accept,
		Cancel,
		ViewLeaderboards,
		Back,
		Close,
		Skip,
		Continue,
		Buy,
		Use,
		Exit,
		ScoreUploaded,
		ResubmitScore,
		SendingScore,
		ViewGamercard,
		ShowScore,
		ShowTime,
		FilterAll,
		FilterMe,
		FilterFriends,
		UnlockFullGame,
		WaitingForHost,
		CheckingHighScores,
		WriteFailed,
		Gamercard1,
		Gamercard2,
		Retry,
		ContinueWithoutSaving,
		SelectStorageDevice,
		ReturnToGame,
		ReturnToGameLibrary,
		PageUp,
		PageDown,
		Waiting,
		PreviousWeapon,
		NextWeapon,
		ShopDone,
		ShopBuy
	}

	public enum Button
	{
		A,
		B,
		X,
		Y,
		None,
		LT,
		RT
	}

	public static Dictionary<int, StringBuilder> strings;

	public static void Init()
	{
		strings = new Dictionary<int, StringBuilder>();
		strings.Add(0, new StringBuilder(YukiText.accept));
		strings.Add(1, new StringBuilder(YukiText.cancel));
		strings.Add(2, new StringBuilder(YukiText.viewLeaderboards));
		strings.Add(3, new StringBuilder(YukiText.aback));
		strings.Add(4, new StringBuilder(YukiText.close));
		strings.Add(5, new StringBuilder(YukiText.skip));
		strings.Add(6, new StringBuilder(YukiText.continues));
		strings.Add(7, new StringBuilder(YukiText.unlockFullGame));
		strings.Add(8, new StringBuilder(YukiText.use));
		strings.Add(9, new StringBuilder(YukiText.exit));
		strings.Add(11, new StringBuilder(YukiText.resubmit));
		strings.Add(10, new StringBuilder(YukiText.scoreUpdated));
		strings.Add(12, new StringBuilder(YukiText.sendingScore));
		strings.Add(13, new StringBuilder(YukiText.viewGamercard));
		strings.Add(14, new StringBuilder(YukiText.showScore));
		strings.Add(15, new StringBuilder(YukiText.showTime));
		strings.Add(16, new StringBuilder(YukiText.filterOverall));
		strings.Add(17, new StringBuilder(YukiText.filterMyScore));
		strings.Add(18, new StringBuilder(YukiText.filterFriends));
		strings.Add(19, new StringBuilder(YukiText.unlockFullGame));
		strings.Add(20, new StringBuilder(YukiText.waitingForHost));
		strings.Add(21, new StringBuilder(YukiText.updating));
		strings.Add(22, new StringBuilder(YukiText.writeFailed));
		strings.Add(23, new StringBuilder(YukiText.SHOWGAMERCARDCAPS));
		strings.Add(24, new StringBuilder(YukiText.SHOWGAMERCARDCAPS));
		strings.Add(25, new StringBuilder(YukiText.retry));
		strings.Add(26, new StringBuilder(YukiText.continueWithoutSaving));
		strings.Add(27, new StringBuilder(YukiText.selectStorageDevice));
		strings.Add(28, new StringBuilder(YukiText.returnToGame));
		strings.Add(29, new StringBuilder(YukiText.returnToGameLibrary));
		strings.Add(30, new StringBuilder(YukiText.pageUp));
		strings.Add(31, new StringBuilder(YukiText.pageDown));
		strings.Add(32, new StringBuilder(YukiText.waiting));
		strings.Add(33, new StringBuilder(YukiText.previousWeapon));
		strings.Add(34, new StringBuilder(YukiText.nextWeapon));
		strings.Add(35, new StringBuilder(YukiText.shopDone));
		strings.Add(36, new StringBuilder(YukiText.shopBuy));
	}

	public static void DrawButton(SpriteBatch sprite, Button button, Msg msg, int position, float a)
	{
		DrawButton(sprite, button, msg, position, a, lcText: false);
	}

	public static void DrawButton(SpriteBatch sprite, Button button, Msg msg, int position, float a, bool lcText)
	{
		float x = 150f;
		float num = 120f;
		Vector2 vector = ScrollManager.screenSize - new Vector2(x, num) + new Vector2((float)position * 5f, (float)position * -30f);
		float scale = 0.8f;
		if (position == 2 || position == 3)
		{
			vector = new Vector2(0f, ScrollManager.screenSize.Y) + new Vector2(x, 0f - num) + new Vector2((float)(position - 2) * 5f, (float)(position - 2) * -30f);
		}
		flibitPort.RenderingPlayer = flibitPort.GetMenuOwner();
		if (position == 10)
		{
			Text.DrawCText(sprite, new Vector2(640f, ScrollManager.screenSize.Y - num), strings[(int)msg], new Color(1f, 1f, 1f, a), scale, 1);
			return;
		}
		StringBuilder stringBuilder = new StringBuilder();
		switch (button)
		{
		case Button.Y:
			stringBuilder.Append("[Y]");
			break;
		case Button.A:
			stringBuilder.Append("[A]");
			break;
		case Button.B:
			stringBuilder.Append("[B]");
			break;
		case Button.None:
			Text.DrawCText(sprite, vector, strings[(int)msg], new Color(1f, 1f, 1f, a), scale, 2);
			return;
		case Button.LT:
			stringBuilder.Append("[L]");
			break;
		case Button.RT:
			stringBuilder.Append("[R]");
			break;
		}
		if (position == 0 || position == 1)
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Insert(0, " ");
			}
			stringBuilder.Insert(0, strings[(int)msg].ToString());
			if (lcText)
			{
				Text.DrawLCText(sprite, vector - new Vector2(2f, 0f), stringBuilder, new Color(1f, 1f, 1f, a), scale, 2);
			}
			else
			{
				Text.DrawCText(sprite, vector - new Vector2(2f, 0f), stringBuilder, new Color(1f, 1f, 1f, a), scale, 2);
			}
		}
		else
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(" ");
			}
			stringBuilder.Append(strings[(int)msg].ToString());
			if (lcText)
			{
				Text.DrawLCText(sprite, vector + new Vector2(28f, 0f), stringBuilder, new Color(1f, 1f, 1f, a), scale, 0);
			}
			else
			{
				Text.DrawCText(sprite, vector + new Vector2(28f, 0f), stringBuilder, new Color(1f, 1f, 1f, a), scale, 0);
			}
		}
		flibitPort.RenderingPlayer = 0;
	}
}
