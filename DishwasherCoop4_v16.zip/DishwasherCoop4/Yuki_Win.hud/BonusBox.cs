using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.hud;

public class BonusBox
{
	public HUDBox hudBox;

	public float y;

	public float goalY;

	public float alpha;

	public float prog;

	public int idx;

	public BonusBox(int idx)
	{
		hudBox = new HUDBox(100, 16);
		this.idx = idx;
		y = 720f;
		goalY = 720f;
	}

	public void Draw(SpriteBatch sprite, float x, float y, float sub, bool flip)
	{
		goalY = y;
		hudBox.prog = prog;
		hudBox.Draw(sprite, new Vector2(x, this.y), alpha, flip);
		sprite.Draw(Game1.spritesTex, new Vector2(x, this.y - sub), new Rectangle(idx * 64, 704, 64, 64), new Color(1f, 1f, 1f, alpha), 0f, new Vector2(32f, 0f), 0.5f, SpriteEffects.None, 1f);
	}

	public void Update()
	{
		hudBox.Update();
		if (prog > 0f)
		{
			if (alpha < 1f)
			{
				alpha += FMan.frameTime * 5f;
				if (alpha > 1f)
				{
					alpha = 1f;
				}
			}
		}
		else if (alpha > 0f)
		{
			alpha -= FMan.frameTime;
			if (alpha < 0f)
			{
				alpha = 0f;
			}
		}
		if (y < goalY)
		{
			y += (goalY - y) * FMan.frameTime * 15f;
			if (y > goalY)
			{
				y = goalY;
			}
		}
		if (y > goalY)
		{
			y += (goalY - y) * FMan.frameTime * 15f;
			if (y < goalY)
			{
				y = goalY;
			}
		}
	}
}
