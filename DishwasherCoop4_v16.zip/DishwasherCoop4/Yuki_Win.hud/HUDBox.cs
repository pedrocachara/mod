using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.hud;

public class HUDBox
{
	public float prog;

	private float trailProg;

	public int width;

	public int height;

	public HUDBox(int width, int height)
	{
		this.width = width;
		this.height = height;
	}

	public void Update()
	{
		if (trailProg < prog)
		{
			trailProg += FMan.frameTime;
			if (trailProg > prog)
			{
				trailProg = prog;
			}
		}
		if (trailProg > prog)
		{
			trailProg -= FMan.frameTime;
			if (trailProg < prog)
			{
				trailProg = prog;
			}
		}
	}

	public void Draw(SpriteBatch sprite, Vector2 loc, float alpha, bool flip)
	{
		if (!float.IsNaN(prog))
		{
			Rectangle destinationRectangle = new Rectangle((int)loc.X, (int)loc.Y, width, height);
			if (flip)
			{
				destinationRectangle.X -= width;
				sprite.Draw(Game1.spritesTex, new Rectangle(destinationRectangle.Right - (int)((float)destinationRectangle.Width * prog), destinationRectangle.Y, (int)((float)destinationRectangle.Width * prog), destinationRectangle.Height), new Rectangle(896 - (int)(256f * prog), 384, (int)(256f * prog), 65), new Color(1f, 0f, 0f, alpha * 0.5f), 0f, new Vector2(0f, 0f), SpriteEffects.None, 1f);
				sprite.Draw(Game1.spritesTex, new Rectangle(destinationRectangle.Right - (int)((float)destinationRectangle.Width * trailProg), destinationRectangle.Y, (int)((float)destinationRectangle.Width * trailProg), destinationRectangle.Height), new Rectangle(896 - (int)(256f * trailProg), 384, (int)(256f * trailProg), 65), new Color(1f, 0f, 0f, alpha * 0.5f), 0f, new Vector2(0f, 0f), SpriteEffects.None, 1f);
			}
			else
			{
				sprite.Draw(Game1.spritesTex, new Rectangle(destinationRectangle.X, destinationRectangle.Y, (int)((float)destinationRectangle.Width * prog), destinationRectangle.Height), new Rectangle(640, 384, (int)(256f * prog), 65), new Color(1f, 0f, 0f, alpha * 0.5f), 0f, new Vector2(0f, 0f), SpriteEffects.None, 1f);
				sprite.Draw(Game1.spritesTex, new Rectangle(destinationRectangle.X, destinationRectangle.Y, (int)((float)destinationRectangle.Width * trailProg), destinationRectangle.Height), new Rectangle(640, 384, (int)(256f * trailProg), 65), new Color(1f, 0f, 0f, alpha * 0.5f), 0f, new Vector2(0f, 0f), SpriteEffects.None, 1f);
			}
			sprite.Draw(Game1.spritesTex, destinationRectangle, new Rectangle(384, 384, 256, 65), new Color(1f, 1f, 1f, alpha), 0f, new Vector2(0f, 0f), SpriteEffects.None, 1f);
		}
	}
}
