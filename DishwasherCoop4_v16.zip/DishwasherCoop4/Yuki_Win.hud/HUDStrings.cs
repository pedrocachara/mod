using System.Text;

namespace Yuki_Win.hud;

public class HUDStrings
{
	public static StringBuilder comboStr = new StringBuilder(YukiText.c_combo);

	public static StringBuilder[] hitsStr;

	public static StringBuilder[] killsStr;

	public static StringBuilder[] comboCapStr;

	public static StringBuilder[] timeStr;

	public static StringBuilder nullString;

	public static void Init()
	{
		hitsStr = new StringBuilder[10000];
		for (int i = 0; i < hitsStr.Length; i++)
		{
			hitsStr[i] = new StringBuilder(i + " " + YukiText.hits);
		}
		killsStr = new StringBuilder[100];
		for (int j = 0; j < killsStr.Length; j++)
		{
			killsStr[j] = new StringBuilder("+ " + j + " " + YukiText.kills);
		}
		nullString = new StringBuilder("--:--");
		comboCapStr = new StringBuilder[13]
		{
			new StringBuilder(YukiText.c_combo),
			new StringBuilder(YukiText.c_awesome),
			new StringBuilder(YukiText.c_sick),
			new StringBuilder(YukiText.c_heavy),
			new StringBuilder(YukiText.c_epic),
			new StringBuilder(YukiText.c_hardcore),
			new StringBuilder(YukiText.c_twisted),
			new StringBuilder(YukiText.c_intense),
			new StringBuilder(YukiText.c_manic),
			new StringBuilder(YukiText.c_insane),
			new StringBuilder(YukiText.c_monstrous),
			new StringBuilder(YukiText.c_psychotic),
			new StringBuilder(YukiText.c_ultimate)
		};
		int num = 30;
		int num2 = 60;
		timeStr = new StringBuilder[num * num2];
		for (int k = 0; k < num; k++)
		{
			for (int l = 0; l < num2; l++)
			{
				timeStr[k * num2 + l] = new StringBuilder(k + ":" + ((l < 10) ? ("0" + l) : l.ToString()));
			}
		}
	}
}
