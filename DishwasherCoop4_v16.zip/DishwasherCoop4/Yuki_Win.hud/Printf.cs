using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.hud;

internal class Printf
{
	public static StringBuilder[] line;

	public static int min;

	public static int max;

	public static float frame;

	public static void Init()
	{
		line = new StringBuilder[32];
	}

	public static void AddLine(string s)
	{
		line[max] = new StringBuilder(s);
		max = (max + 1) % line.Length;
		if (max == min)
		{
			min = (min + 1) % line.Length;
		}
		frame = 3f;
	}

	public static void Update()
	{
		if (min != max)
		{
			frame -= FMan.frameTime;
			if (frame < 0f)
			{
				frame = 3f;
				min = (min + 1) % line.Length;
			}
		}
	}

	public static void Draw(SpriteBatch sprite, SpriteFont font)
	{
		if (font != null && max != min)
		{
			SpriteTools.BeginAlpha();
			int num = min;
			int num2 = 0;
			while (num != max)
			{
				sprite.DrawString(font, line[num], new Vector2(50f, 50f) + new Vector2(0f, (float)num2 * 20f), Color.White);
				num = (num + 1) % line.Length;
				num2++;
			}
			SpriteTools.End();
		}
	}

	internal static void WriteLine(string p)
	{
	}
}
