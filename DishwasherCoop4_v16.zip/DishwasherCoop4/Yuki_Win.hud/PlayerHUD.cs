using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.arcade;
using Yuki_Win.levels;
using Yuki_Win.maps;
using Yuki_Win.player;

namespace Yuki_Win.hud;

public class PlayerHUD
{
	public const int BONUS_CLEAN = 0;

	public const int BONUS_SLASHER = 1;

	public const int BONUS_SMASH = 2;

	public const int BONUS_RENDER = 3;

	public const int BONUS_BLASTER = 4;

	private HUDBox healthBox;

	private BonusBox[] bonusBox;

	private HUDBox comboBox;

	private float alpha;

	private float weaponAlpha;

	public bool visible;

	public int ID;

	private float comboAlpha;

	private float weapSwitchFrame;

	private float loadoutSwitchFrame;

	private float secondaryFrame;

	public void SwitchWeaps()
	{
		weapSwitchFrame = 1f;
	}

	public void SwitchLoadouts()
	{
		loadoutSwitchFrame = 1f;
	}

	public PlayerHUD(int ID)
	{
		healthBox = new HUDBox(200, 64);
		bonusBox = new BonusBox[5];
		bonusBox[0] = new BonusBox(0);
		bonusBox[1] = new BonusBox(4);
		bonusBox[2] = new BonusBox(3);
		bonusBox[3] = new BonusBox(1);
		bonusBox[4] = new BonusBox(2);
		comboBox = new HUDBox(150, 16);
		this.ID = ID;
	}

	// Skins (Hargreaves/Mara) usam as mesmas regras de HUD do Dishwasher/Yuki.
	private static int HudMeta(int m)
	{
		switch (m)
		{
		case 32: return 5;
		case 33: return 15;
		case 34: return 16;
		case 35: return 24;
		case 36: return 26;
		case 37: return 0;
		case 38: return 2;
		case 39: return 25;
		case 76: return 46;
		case 79: return 78;
		default: return m;
		}
	}

	private void DrawAmmo(SpriteBatch sprite, Vector2 loc, int ammo, bool flip)
	{
		for (int i = 0; i < 2; i++)
		{
			Vector2 position = loc;
			Color color = new Color(1f, 1f, 1f, alpha * 0.8f);
			if (i == 0)
			{
				position += new Vector2(3f, 3f);
				color = new Color(0f, 0f, 0f, alpha * 0.4f);
			}
			if (!flip)
			{
				sprite.Draw(Game1.spritesTex, position, new Rectangle(512 + (42 - ammo) * 8, 544, ammo * 8, 16), color, 0f, new Vector2(0f, 0f), new Vector2(0.5f, 0.7f), SpriteEffects.None, 1f);
			}
			else
			{
				sprite.Draw(Game1.spritesTex, position, new Rectangle(512 + (42 - ammo) * 8, 544, ammo * 8, 16), color, 3.14f, new Vector2(0f, 16f), new Vector2(0.5f, 0.7f), SpriteEffects.FlipVertically, 1f);
			}
		}
	}

	private void DrawLoadout(Vector2 centerVec, int loadIdx, SpriteBatch sprite, float lAlpha)
	{
		if ((Game1.netSession.IsHost() && ID != 0) || (Game1.netSession.IsClient() && ID != 1))
		{
			return;
		}
		Loadout loadout = Game1.gamePlayerMgr.gamePlayer[ID].loadOut[loadIdx];
		for (int num = 1; num >= 0; num--)
		{
			float num2 = (float)num * 3.14f;
			if (weapSwitchFrame > 0f)
			{
				num2 += weapSwitchFrame * 3.14f;
			}
			float num3 = 0.3f;
			if (num2 < 1f)
			{
				num3 += (1f - num2) * 0.3f;
			}
			if (num2 > 5.28f)
			{
				num3 += (num2 - 5.28f) * 0.3f;
			}
			num2--;
			Vector2 loc = centerVec + new Vector2((float)Math.Cos(num2), (float)Math.Sin(num2)) * 30f;
			DrawWeapon(loadout.weapon[(num + Game1.character[ID].weapIdx) % 2], sprite, loc, weaponAlpha * lAlpha, num3, loadIdx);
		}
	}

	// Icone da arma equipada (grande) e da outra arma do loadout (pequeno) na frente da barra de vida
	private void DrawHudWeapons(SpriteBatch sprite, Vector2 loc)
	{
		if ((Game1.netSession.IsHost() && ID != 0) || (Game1.netSession.IsClient() && ID != 1))
		{
			return;
		}
		int loadIdx = Game1.character[ID].loadOut;
		int weapIdx = Game1.character[ID].weapIdx;
		Loadout loadout = Game1.gamePlayerMgr.gamePlayer[ID].loadOut[loadIdx];
		float pop = 1f + ((weapSwitchFrame > 0f) ? (weapSwitchFrame * 0.3f) : 0f);
		DrawHudWeaponIcon(sprite, loadout.weapon[weapIdx], loc, 58f * pop, 1f, loadIdx);
		DrawHudWeaponIcon(sprite, loadout.weapon[1 - weapIdx], loc + new Vector2(0f, 52f), 34f, 0.6f, loadIdx);
	}

	private void DrawHudWeaponIcon(SpriteBatch sprite, InvCatalog.InvItemName idx, Vector2 loc, float size, float a, int loadout)
	{
		if (idx == InvCatalog.InvItemName.None)
		{
			return;
		}
		float al = weaponAlpha * a;
		Color ring = ((loadout == 0) ? new Color(1f, 0.4f, 0.4f, 0.55f * al) : new Color(0.4f, 0.4f, 1f, 0.55f * al));
		sprite.Draw(Game1.spritesTex, loc, new Rectangle(832, 192, 64, 64), new Color(0f, 0f, 0f, 0.7f * al), 0f, new Vector2(32f, 32f), size / 64f * 1.25f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, loc, new Rectangle(832, 192, 64, 64), ring, 0f, new Vector2(32f, 32f), size / 64f * 1.5f, SpriteEffects.FlipHorizontally, 1f);
		Rectangle rect = Game1.invCatalog.GetInvitemRect(idx);
		float sc = size / (float)Math.Max(rect.Width, rect.Height);
		sprite.Draw(Game1.itemsTex, loc, rect, new Color(1f, 1f, 1f, al), 0f, new Vector2((float)rect.Width / 2f, (float)rect.Height / 2f), sc, SpriteEffects.None, 1f);
	}

	private void DrawWeapon(InvCatalog.InvItemName idx, SpriteBatch sprite, Vector2 loc, float alpha, float scale, int loadout)
	{
		if (idx != InvCatalog.InvItemName.None)
		{
			Color color = ((loadout == 0) ? new Color(1f, 0.4f, 0.4f, 0.5f * alpha) : new Color(0.4f, 0.4f, 1f, 0.5f * alpha));
			sprite.Draw(Game1.spritesTex, loc, new Rectangle(832, 192, 64, 64), new Color(0f, 0f, 0f, 0.8f * alpha), secondaryFrame + loc.Y * 0.1f, new Vector2(32f, 32f), scale * 3f, SpriteEffects.None, 1f);
			sprite.Draw(Game1.spritesTex, loc, new Rectangle(832, 192, 64, 64), color, 0f - secondaryFrame + loc.Y * 0.1f, new Vector2(32f, 32f), scale * 4f, SpriteEffects.FlipHorizontally, 1f);
			_ = Game1.invCatalog.catalog[(int)idx].idx;
			sprite.Draw(Game1.itemsTex, loc, Game1.invCatalog.GetInvitemRect(idx), new Color(1f, 1f, 1f, alpha), 0f, new Vector2(64f, 64f) * 2f, scale / 2f, SpriteEffects.None, 1f);
		}
	}

	internal void Draw(SpriteBatch sprite, int threedee)
	{
		if (Game1.gameMap.lockCharMode || (Game1.gameMap.theme.theme == Themes.ThemeType.Final && Game1.gameMap.CrazyTransitionInFrame > 0f))
		{
			return;
		}
		bool flag = false;
		float num = 100f;
		float num2 = 1f;
		int iD = ID;
		int justification = 0;
		if (ID % 2 == 1)
		{
			flag = true;
		}
		if (Game1.beadMgr.beads[ID].HasBead(InvCatalog.InvItemName.MirrorBead))
		{
			flag = !flag;
		}
		if (flag)
		{
			num = ScrollManager.screenSize.X - 100f;
			num2 = -1f;
			justification = 2;
		}
		float baseY = ((ID >= 2) ? (ScrollManager.screenSize.Y - 200f) : 100f);
		switch (threedee)
		{
		case 0:
			num++;
			break;
		case 1:
			num--;
			break;
		}
		bool flag2 = false;
		bool flag3 = false;
		bool flag4 = false;
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Off)
		{
			switch (HudMeta(Game1.character[iD].charUpdate.borrowed ? Game1.character[iD].charUpdate.borrowMeta : Game1.character[iD].charMeta))
			{
			case 5:
			case 15:
			case 16:
			case 24:
			case 26:
				flag2 = false;
				flag4 = true;
				switch (Game1.player.dishPhase)
				{
				case 0:
				case 1:
				case 2:
					flag2 = true;
					flag3 = true;
					break;
				case 3:
					flag3 = true;
					break;
				default:
					flag3 = false;
					break;
				}
				if (Game1.gamePlayerMgr.gamePlayer[ID].highestDishPhase >= 4)
				{
					flag3 = false;
				}
				flag2 = false;
				break;
			case 78:
				flag2 = true;
				flag4 = false;
				flag3 = true;
				break;
			case 0:
			case 2:
			case 25:
			case 46:
				if (Game1.gamePlayerMgr.gamePlayer[ID].highestYukiPhase < 8)
				{
					flag2 = true;
				}
				flag4 = true;
				switch (Game1.gamePlayerMgr.gamePlayer[ID].highestYukiPhase)
				{
				case 0:
				case 2:
				case 3:
				case 4:
				case 5:
					flag4 = false;
					flag3 = true;
					break;
				case 6:
				case 7:
				case 8:
					flag3 = true;
					break;
				default:
					flag3 = false;
					break;
				}
				if (Game1.player.yukiPhase >= 6 && Game1.gamePlayerMgr.gamePlayer[ID].highestYukiPhase >= 9)
				{
					flag3 = false;
				}
				break;
			case 8:
			case 9:
			case 10:
			case 11:
			case 22:
				return;
			}
		}
		else
		{
			flag2 = false;
			flag4 = true;
		}
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].magic == Level.ArcadeMagic.None)
		{
			flag3 = true;
		}
		if (Game1.levelMgr.currentTrack != 6 && Game1.levelMgr.currentTrack != 5)
		{
			healthBox.width = (int)(2f * Game1.character[iD].charUpdate.mhp);
			healthBox.Draw(sprite, new Vector2(num, baseY), alpha, flag);
			if (Game1.GetPlayers() >= 2 && Game1.gamePlayerMgr.gamePlayer[ID].gamerTag != null)
			{
				Vector2 location = new Vector2(num, baseY - 10f);
				Text.DrawLCText(sprite, location, Game1.gamePlayerMgr.gamePlayer[ID].gamerTag, new Color(0f, 0f, 0f, alpha * 0.5f), 0.7f, flag ? 2 : 0, blur: true);
				Text.DrawLCText(sprite, location, Game1.gamePlayerMgr.gamePlayer[ID].gamerTag, new Color(1f, 1f, 1f, alpha), 0.7f, flag ? 2 : 0);
			}
			if (!flag2)
			{
				int ammo = Game1.character[iD].charUpdate.ammo;
				DrawAmmo(sprite, new Vector2(num + 3f * num2, baseY + 47f), ammo, flag);
			}
			if (!flag3)
			{
				int mp = Game1.character[iD].charUpdate.mp;
				int mmp = Game1.character[iD].charUpdate.mmp;
				DrawMagic(sprite, new Vector2(num + 3f * num2, baseY + 60f), mp, mmp, flag, Game1.character[ID].GetMeta().isDish);
			}
		}
		float num3 = 500f;
		GamePlayer gamePlayer = Game1.gamePlayerMgr.gamePlayer[iD];
		if (Game1.hud.invMgr.IsActive())
		{
			return;
		}
		if (gamePlayer.score > 0)
		{
			Text.DrawScore((int)num, (int)baseY + 90, gamePlayer.score, new Color(1f, 1f, 1f, alpha), sprite, !flag, gamePlayer.scoreFrame, 0.65f);
		}
		if (Game1.hud.shopMgr.IsActive())
		{
			flag4 = false;
		}
		if (flag4)
		{
			Vector2 vector = new Vector2(num - 52f * num2, baseY + 8f);
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade && Game1.levelMgr.levels[3][Game1.levelMgr.currentLevel].arcadeSpecial == Level.ArcadeSpecial.HotPotato && Game1.arcade.hotPotatoFrame[ID, 0] > 5f)
			{
				vector += Rand.GetRandomVec2(-1f, 1f, -1f, 1f) * (Game1.arcade.hotPotatoFrame[ID, 0] - 5f) * 10f;
			}
			DrawHudWeapons(sprite, vector);
		}
		if (comboAlpha > 0f && gamePlayer.comboScore > 0 && gamePlayer.comboCount > 0)
		{
			num3 = ((ID >= 2) ? (baseY - 170f) : 210f);
			float num4 = 1f;
			float frame = 0f;
			if (gamePlayer.comboFrame > 2.7f)
			{
				num4 += gamePlayer.comboFrame - 10.8f;
				frame = gamePlayer.comboFrame - 10.8f;
			}
			for (int i = 0; i < 4; i++)
			{
				sprite.Draw(Game1.spritesTex, new Vector2(num + (float)i * 40f * num2, num3 + (float)i * 20f) + Rand.GetRandomVec2(0f - num4, num4, 0f - num4, num4) * 0.5f, new Rectangle(384 + i * 64, 320, 64, 64), new Color((float)(6 - i) * 0.3f, 0f, 0f, comboAlpha * 0.4f * alpha), 0f, new Vector2(32f, 32f), 2.5f, SpriteEffects.None, 1f);
			}
			comboBox.Draw(sprite, new Vector2(num, num3 + 22f), alpha * comboAlpha, flag);
			Text.DrawScore((int)num, (int)num3 + 40, gamePlayer.comboScore, new Color(1f, 1f, 1f, comboAlpha * alpha), sprite, !flag, frame, 0.7f);
			Text.DrawJText(sprite, new Vector2(num, num3) + new Vector2(5f * num2, 5f) + Rand.GetRandomVec2(0f - num4, num4, 0f - num4, num4), HUDStrings.comboStr, new Color(0f, 0f, 0f, comboAlpha * 0.25f * alpha), 1.2f, justification);
			long num5 = gamePlayer.comboCount;
			if (num5 >= HUDStrings.hitsStr.Length)
			{
				num5 = HUDStrings.hitsStr.Length - 1;
			}
			Text.DrawJText(sprite, new Vector2(num, num3) + Rand.GetRandomVec2(0f - num4, num4, 0f - num4, num4) * 0.5f, HUDStrings.hitsStr[num5], new Color(1f, 0f, 0f, comboAlpha * 0.95f * alpha), 1f, justification);
			Text.DrawJText(sprite, new Vector2(num, num3) + Rand.GetRandomVec2(0f - num4, num4, 0f - num4, num4) * 0.5f, HUDStrings.hitsStr[num5], new Color(1f, 1f, 1f, comboAlpha * alpha), 1f, justification);
		}
		if (gamePlayer.comboCashFrame > 0f)
		{
			num3 = ((ID >= 2) ? (baseY - 130f) : 250f);
			float frame2 = 0f;
			float num6 = gamePlayer.comboCashFrame;
			if (num6 > 1f)
			{
				num6 = 1f;
			}
			if (gamePlayer.comboCashFrame > 2.5f)
			{
				frame2 = gamePlayer.comboCashFrame - 2.5f;
			}
			for (int j = 0; j < 10; j++)
			{
				sprite.Draw(Game1.spritesTex, new Vector2(num + num2 * (float)j * 32f, num3 + 96f), new Rectangle(384 + j % 6 * 64, 320, 64, 64), new Color(1f, 0f, 0f, num6 * 0.5f * alpha), j, new Vector2(16f, 32f), 0.5f + (10f - (float)j) * 0.1f, SpriteEffects.None, 1f);
			}
			Text.DrawScore((int)num + Rand.GetRandomInt(-5, 5), (int)num3 + 70 + Rand.GetRandomInt(-5, 5), gamePlayer.comboCash, new Color(0f, 0f, 0f, num6 * 0.4f * alpha), sprite, !flag, frame2, 1.5f);
			Text.DrawScore((int)num + Rand.GetRandomInt(-5, 5), (int)num3 + 70 + Rand.GetRandomInt(-5, 5), gamePlayer.comboCash, new Color(1f, 0f, 0f, num6 * 0.4f * alpha), sprite, !flag, frame2, 1.5f);
			Text.DrawScore((int)num, (int)num3 + 70, gamePlayer.comboCash, new Color(1f, 1f, 1f, gamePlayer.comboCashFrame * alpha), sprite, !flag, frame2, 1.5f);
		}
	}

	private void DrawMagic(SpriteBatch sprite, Vector2 loc, int magic, int maxMagic, bool flip, bool isDish)
	{
		float num = (flip ? (-1f) : 1f);
		loc.X += num * 16f;
		loc.Y += 10f;
		float num2 = 0.9f;
		float num3 = 0.7f * alpha;
		for (int i = 0; i < maxMagic; i++)
		{
			if (magic > i)
			{
				sprite.Draw(Game1.spritesTex, loc + new Vector2((float)i * num, 0f), new Rectangle(896 + Rand.GetRandomInt(0, 4) * 32, 832, 32, 32), isDish ? new Color(0.25f, 1f, 0.25f, num3) : new Color(1f, 0.5f, 0.5f, num3), 0f, new Vector2(16f, 16f), num2, SpriteEffects.None, 1f);
			}
			float num4 = num2;
			if (magic <= i)
			{
				num4 *= 0.5f;
			}
			sprite.Draw(Game1.spritesTex, loc + new Vector2((float)i * num, 0f), new Rectangle(896 + Rand.GetRandomInt(0, 4) * 32, 864, 32, 32), isDish ? new Color(0f, 1f, 0f, num3) : new Color(1f, 0f, 0f, num3), 0f, new Vector2(16f, 16f), num4, SpriteEffects.None, 1f);
			loc.X += num * 24f;
		}
	}

	internal void Update()
	{
		if (visible)
		{
			float num = 1f;
			for (int i = 0; i < 4; i++)
			{
				if (!Game1.IsPlayerChar(i) || !Game1.character[i].exists)
				{
					continue;
				}
				Vector2 screenLoc = ScrollManager.GetScreenLoc(Game1.character[i].charUpdate.loc, 1f);
				if (ID % 2 == 0)
				{
					if (screenLoc.X < 500f && screenLoc.Y < 400f)
					{
						num = 0.15f;
					}
				}
				else if (screenLoc.X > ScrollManager.screenSize.X - 500f && screenLoc.Y < 400f)
				{
					num = 0.15f;
				}
			}
			if (alpha < num)
			{
				alpha += FMan.frameTime * 4f;
				if (alpha > num)
				{
					alpha = num;
				}
			}
			if (alpha > num)
			{
				alpha -= FMan.frameTime * 4f;
				if (alpha < num)
				{
					alpha = num;
				}
			}
			if (weaponAlpha < 1f)
			{
				weaponAlpha += FMan.frameTime * 4f;
				if (weaponAlpha > 1f)
				{
					weaponAlpha = 1f;
				}
			}
		}
		else
		{
			if (alpha > 0f)
			{
				alpha -= FMan.frameTime;
				if (alpha < 0f)
				{
					alpha = 0f;
				}
			}
			if (weaponAlpha > 0f)
			{
				weaponAlpha -= FMan.frameTime * 5f;
				if (weaponAlpha < 0f)
				{
					weaponAlpha = 0f;
				}
			}
		}
		secondaryFrame += FMan.frameTime;
		if (secondaryFrame > 6.28f)
		{
			secondaryFrame -= 6.28f;
		}
		if (weapSwitchFrame > 0f)
		{
			weapSwitchFrame -= FMan.frameTime * 9f;
			if (weapSwitchFrame < 0f)
			{
				weapSwitchFrame = 0f;
			}
		}
		if (loadoutSwitchFrame > 0f)
		{
			loadoutSwitchFrame -= FMan.frameTime * 9f;
			if (loadoutSwitchFrame < 0f)
			{
				loadoutSwitchFrame = 0f;
			}
		}
		bonusBox[0].prog = Game1.gamePlayerMgr.gamePlayer[ID].cleanKillFrame / 20f;
		bonusBox[1].prog = Game1.gamePlayerMgr.gamePlayer[ID].slasherKillFrame / 20f;
		bonusBox[2].prog = Game1.gamePlayerMgr.gamePlayer[ID].smashKillFrame / 20f;
		bonusBox[3].prog = Game1.gamePlayerMgr.gamePlayer[ID].rendKillFrame / 20f;
		bonusBox[4].prog = Game1.gamePlayerMgr.gamePlayer[ID].blastKillFrame / 20f;
		comboBox.prog = Game1.gamePlayerMgr.gamePlayer[ID].comboFrame / 3f;
		if (Game1.gamePlayerMgr.gamePlayer[ID].comboFrame > 0f)
		{
			if (comboAlpha < 1f)
			{
				comboAlpha += FMan.frameTime * 5f;
			}
			if (comboAlpha > 1f)
			{
				comboAlpha = 1f;
			}
		}
		else
		{
			if (comboAlpha > 0f)
			{
				comboAlpha -= FMan.frameTime;
			}
			if (comboAlpha < 0f)
			{
				comboAlpha = 0f;
			}
		}
		for (int j = 0; j < bonusBox.Length; j++)
		{
			bonusBox[j].Update();
		}
		healthBox.prog = Game1.gamePlayerMgr.gamePlayer[ID].hp / Game1.gamePlayerMgr.gamePlayer[ID].mhp;
		healthBox.Update();
		for (int k = 0; k < bonusBox.Length; k++)
		{
			bonusBox[k].Update();
		}
		comboBox.Update();
	}
}
