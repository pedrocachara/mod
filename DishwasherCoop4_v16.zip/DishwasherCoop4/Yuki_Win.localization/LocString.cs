using System.Collections.Generic;
using System.Text;

namespace Yuki_Win.localization;

public class LocString
{
	public StringBuilder welcome = new StringBuilder(YukiText.Welcome);

	public StringBuilder ok = new StringBuilder(YukiText.ok);

	public StringBuilder cancel = new StringBuilder(YukiText.cancel);

	public StringBuilder endCurrentGame = new StringBuilder(YukiText.endCurrentGame);

	public StringBuilder youWillLose1 = new StringBuilder(YukiText.youWillLose1);

	public StringBuilder youWillLose2 = new StringBuilder(YukiText.youWillLose2);

	public StringBuilder back = new StringBuilder(YukiText.back);

	public StringBuilder selectLevel = new StringBuilder(YukiText.selectLevel);

	public StringBuilder retry = new StringBuilder(YukiText.retry);

	public StringBuilder endGame = new StringBuilder(YukiText.endGame);

	public StringBuilder youAreDead = new StringBuilder(YukiText.youAreDead);

	public StringBuilder buy = new StringBuilder(YukiText.buy);

	public StringBuilder theDishwasher = new StringBuilder(YukiText.theDishwasher);

	public StringBuilder selectCampaign = new StringBuilder(YukiText.selectCampaign);

	public StringBuilder yuki = new StringBuilder(YukiText.yuki);

	public StringBuilder exitGameSession = new StringBuilder(YukiText.exitGameSession);

	public StringBuilder mode = new StringBuilder(YukiText.mode);

	public StringBuilder original = new StringBuilder(YukiText.original);

	public StringBuilder flipped = new StringBuilder(YukiText.flipped);

	public StringBuilder selectDifficulty = new StringBuilder(YukiText.selectDifficulty);

	public StringBuilder prettyPrincess = new StringBuilder(YukiText.prettyPrincess);

	public StringBuilder easy = new StringBuilder(YukiText.easy);

	public StringBuilder normal = new StringBuilder(YukiText.normal);

	public StringBuilder ninja = new StringBuilder(YukiText.ninja);

	public StringBuilder samurai = new StringBuilder(YukiText.samurai);

	public StringBuilder speedRun = new StringBuilder(YukiText.speedRun);

	public StringBuilder createPublicMatch = new StringBuilder(YukiText.createPublicMatch);

	public StringBuilder createPrivateMatch = new StringBuilder(YukiText.createPrivateMatch);

	public StringBuilder customMatch = new StringBuilder(YukiText.customMatch);

	public StringBuilder restartLevel = new StringBuilder(YukiText.restartLevel);

	public StringBuilder go = new StringBuilder(YukiText.go);

	public StringBuilder shiftBlade = new StringBuilder(YukiText.shiftBlade);

	public StringBuilder meatCleavers = new StringBuilder(YukiText.meatCleavers);

	public StringBuilder theGuillotine = new StringBuilder(YukiText.theGuillotine);

	public StringBuilder violenceHammer = new StringBuilder(YukiText.violenceHammer);

	public StringBuilder dekkentozter = new StringBuilder(YukiText.dekkentozter);

	public StringBuilder conviction = new StringBuilder(YukiText.conviction);

	public StringBuilder kamakazi = new StringBuilder(YukiText.kamakazi);

	public StringBuilder painkiller = new StringBuilder(YukiText.painkiller);

	public StringBuilder cloudSword = new StringBuilder(YukiText.cloudSword);

	public StringBuilder howToPlay = new StringBuilder(YukiText.howToPlay);

	public StringBuilder controls = new StringBuilder(YukiText.controls);

	public StringBuilder settings = new StringBuilder(YukiText.settings);

	public StringBuilder selectStorageDevice = new StringBuilder(YukiText.selectStorageDevice);

	public StringBuilder helpAndOptions = new StringBuilder(YukiText.helpAndOptions);

	public StringBuilder launch = new StringBuilder(YukiText.launch);

	public StringBuilder xboxLiveMultiplayer = new StringBuilder(YukiText.xboxLiveMultiplayer);

	public StringBuilder howToPlay1 = new StringBuilder(YukiText.howToPlay1);

	public StringBuilder howToPlay2 = new StringBuilder(YukiText.howToPlay2);

	public StringBuilder howToPlay3 = new StringBuilder(YukiText.howToPlay3);

	public StringBuilder howToPlay4 = new StringBuilder(YukiText.howToPlay4);

	public StringBuilder howToPlay5 = new StringBuilder(YukiText.howToPlay5);

	public StringBuilder howToPlay6 = new StringBuilder(YukiText.howToPlay6);

	public StringBuilder arcadeSolo = new StringBuilder(YukiText.arcadeSolo);

	public StringBuilder arcadeCoop = new StringBuilder(YukiText.arcadeCoop);

	public StringBuilder dishChallenge = new StringBuilder(YukiText.dishChallenge);

	public StringBuilder tourney = new StringBuilder(YukiText.tourney);

	public StringBuilder weeklyRush = new StringBuilder(YukiText.weeklyRush);

	public StringBuilder speedRunDishwasher = new StringBuilder(YukiText.speedRunDishwasher);

	public StringBuilder speedRunYuki = new StringBuilder(YukiText.speedRunYuki);

	public StringBuilder leaderboards = new StringBuilder(YukiText.leaderboards);

	public StringBuilder availableGames = new StringBuilder(YukiText.availableGames);

	public StringBuilder singlePlayer = new StringBuilder(YukiText.singlePlayer);

	public StringBuilder multiplayer = new StringBuilder(YukiText.multiplayer);

	public StringBuilder achievements = new StringBuilder(YukiText.achievements);

	public StringBuilder debug = new StringBuilder(YukiText.debug);

	public StringBuilder returnToGameLibrary = new StringBuilder(YukiText.returnToGameLibrary);

	public StringBuilder mainMenu = new StringBuilder(YukiText.mainMenu);

	public StringBuilder totalPlayers = new StringBuilder(YukiText.totalPlayers);

	public StringBuilder movesList = new StringBuilder(YukiText.movesList);

	public StringBuilder coopStory = new StringBuilder(YukiText.coopStory);

	public StringBuilder arcadeMode = new StringBuilder(YukiText.arcadeMode);

	public StringBuilder local = new StringBuilder(YukiText.local);

	public StringBuilder resumeGame = new StringBuilder(YukiText.resumeGame);

	public StringBuilder paused = new StringBuilder(YukiText.paused);

	public StringBuilder selectPlayer = new StringBuilder(YukiText.selectPlayer);

	public StringBuilder pressStart = new StringBuilder(YukiText.pressStart);

	public StringBuilder searching = new StringBuilder(YukiText.searching);

	public StringBuilder returnToGameLibraryQ = new StringBuilder(YukiText.returnToGameLibraryQ);

	public StringBuilder remotelyPaused = new StringBuilder(YukiText.remotelyPaused);

	public StringBuilder selectPlayers = new StringBuilder(YukiText.selectPlayers);

	public StringBuilder sfx = new StringBuilder(YukiText.sfx);

	public StringBuilder bgm = new StringBuilder(YukiText.bgm);

	public StringBuilder vibration = new StringBuilder(YukiText.vibration);

	public StringBuilder threedee = new StringBuilder(YukiText.threedee);

	public StringBuilder sfx0 = new StringBuilder(YukiText.sfx0);

	public StringBuilder sfx10 = new StringBuilder(YukiText.sfx10);

	public StringBuilder sfx20 = new StringBuilder(YukiText.sfx20);

	public StringBuilder sfx30 = new StringBuilder(YukiText.sfx30);

	public StringBuilder sfx40 = new StringBuilder(YukiText.sfx40);

	public StringBuilder sfx50 = new StringBuilder(YukiText.sfx50);

	public StringBuilder sfx60 = new StringBuilder(YukiText.sfx60);

	public StringBuilder sfx70 = new StringBuilder(YukiText.sfx70);

	public StringBuilder sfx80 = new StringBuilder(YukiText.sfx80);

	public StringBuilder sfx90 = new StringBuilder(YukiText.sfx90);

	public StringBuilder sfx100 = new StringBuilder(YukiText.sfx100);

	public StringBuilder bgm0 = new StringBuilder(YukiText.bgm0);

	public StringBuilder bgm10 = new StringBuilder(YukiText.bgm10);

	public StringBuilder bgm20 = new StringBuilder(YukiText.bgm20);

	public StringBuilder bgm30 = new StringBuilder(YukiText.bgm30);

	public StringBuilder bgm40 = new StringBuilder(YukiText.bgm40);

	public StringBuilder bgm50 = new StringBuilder(YukiText.bgm50);

	public StringBuilder bgm60 = new StringBuilder(YukiText.bgm60);

	public StringBuilder bgm70 = new StringBuilder(YukiText.bgm70);

	public StringBuilder bgm80 = new StringBuilder(YukiText.bgm80);

	public StringBuilder bgm90 = new StringBuilder(YukiText.bgm90);

	public StringBuilder bgm100 = new StringBuilder(YukiText.bgm100);

	public StringBuilder vibrationoff = new StringBuilder(YukiText.vibrationoff);

	public StringBuilder vibrationon = new StringBuilder(YukiText.vibrationon);

	public StringBuilder threedeetvoff = new StringBuilder(YukiText.threedeetvoff);

	public StringBuilder threedeetvon = new StringBuilder(YukiText.threedeetvon);

	public StringBuilder storyMode = new StringBuilder(YukiText.storyMode);

	public StringBuilder practiceRoom = new StringBuilder(YukiText.practiceRoom);

	public StringBuilder quickMatch = new StringBuilder(YukiText.quickMatch);

	public StringBuilder continues = new StringBuilder(YukiText.continues);

	public StringBuilder[] arcadeTitle = new StringBuilder[50];

	public StringBuilder[] arcadeDesc1 = new StringBuilder[50];

	public StringBuilder[] arcadeDesc2 = new StringBuilder[50];

	public Dictionary<string, StringBuilder> comic;

	public StringBuilder dishChallengeDesc = new StringBuilder(YukiText.dishChallengeDesc);

	public StringBuilder iffenhauseSpacePrison = new StringBuilder(YukiText.iffenhauseSpacePrison);

	public StringBuilder lunarWastes = new StringBuilder(YukiText.lunarWastes);

	public StringBuilder omodoCrash = new StringBuilder(YukiText.omodoCrash);

	public StringBuilder omodosExecution = new StringBuilder(YukiText.omodosExecution);

	public StringBuilder thePit = new StringBuilder(YukiText.thePit);

	public StringBuilder sunkenArmory = new StringBuilder(YukiText.sunkenArmory);

	public StringBuilder hellChambers = new StringBuilder(YukiText.hellChambers);

	public StringBuilder grimTower = new StringBuilder(YukiText.grimTower);

	public StringBuilder landcruiserStadium = new StringBuilder(YukiText.landcruiserStadium);

	public StringBuilder forstadtLobby = new StringBuilder(YukiText.forstadtLobby);

	public StringBuilder aquaMarina = new StringBuilder(YukiText.aquaMarina);

	public StringBuilder justiceSummit = new StringBuilder(YukiText.justiceSummit);

	public StringBuilder theStagnantNightmare = new StringBuilder(YukiText.theStagnantNightmare);

	public LocString()
	{
		comic = new Dictionary<string, StringBuilder>();
		arcadeTitle[0] = new StringBuilder(YukiText.arcade1);
		arcadeDesc1[0] = new StringBuilder(YukiText.arcade1desc1);
		arcadeDesc2[0] = new StringBuilder(YukiText.arcade1desc2);
		arcadeTitle[1] = new StringBuilder(YukiText.arcade2);
		arcadeDesc1[1] = new StringBuilder(YukiText.arcade2desc1);
		arcadeDesc2[1] = new StringBuilder(YukiText.arcade2desc2);
		arcadeTitle[2] = new StringBuilder(YukiText.arcade3);
		arcadeDesc1[2] = new StringBuilder(YukiText.arcade3desc1);
		arcadeDesc2[2] = new StringBuilder(YukiText.arcade3desc2);
		arcadeTitle[3] = new StringBuilder(YukiText.arcade4);
		arcadeDesc1[3] = new StringBuilder(YukiText.arcade4desc1);
		arcadeDesc2[3] = new StringBuilder(YukiText.arcade4desc2);
		arcadeTitle[4] = new StringBuilder(YukiText.arcade5);
		arcadeDesc1[4] = new StringBuilder(YukiText.arcade5desc1);
		arcadeDesc2[4] = new StringBuilder(YukiText.arcade5desc2);
		arcadeTitle[5] = new StringBuilder(YukiText.arcade6);
		arcadeDesc1[5] = new StringBuilder(YukiText.arcade6desc1);
		arcadeDesc2[5] = new StringBuilder(YukiText.arcade6desc2);
		arcadeTitle[6] = new StringBuilder(YukiText.arcade7);
		arcadeDesc1[6] = new StringBuilder(YukiText.arcade7desc1);
		arcadeDesc2[6] = new StringBuilder(YukiText.arcade7desc2);
		arcadeTitle[7] = new StringBuilder(YukiText.arcade8);
		arcadeDesc1[7] = new StringBuilder(YukiText.arcade8desc1);
		arcadeDesc2[7] = new StringBuilder(YukiText.arcade8desc2);
		arcadeTitle[8] = new StringBuilder(YukiText.arcade9);
		arcadeDesc1[8] = new StringBuilder(YukiText.arcade9desc1);
		arcadeDesc2[8] = new StringBuilder(YukiText.arcade9desc2);
		arcadeTitle[9] = new StringBuilder(YukiText.arcade10);
		arcadeDesc1[9] = new StringBuilder(YukiText.arcade10desc1);
		arcadeDesc2[9] = new StringBuilder(YukiText.arcade10desc2);
		arcadeTitle[10] = new StringBuilder(YukiText.arcade11);
		arcadeDesc1[10] = new StringBuilder(YukiText.arcade11desc1);
		arcadeDesc2[10] = new StringBuilder(YukiText.arcade11desc2);
		arcadeTitle[11] = new StringBuilder(YukiText.arcade12);
		arcadeDesc1[11] = new StringBuilder(YukiText.arcade12desc1);
		arcadeDesc2[11] = new StringBuilder(YukiText.arcade12desc2);
		arcadeTitle[12] = new StringBuilder(YukiText.arcade13);
		arcadeDesc1[12] = new StringBuilder(YukiText.arcade13desc1);
		arcadeDesc2[12] = new StringBuilder(YukiText.arcade13desc2);
		arcadeTitle[13] = new StringBuilder(YukiText.arcade14);
		arcadeDesc1[13] = new StringBuilder(YukiText.arcade14desc1);
		arcadeDesc2[13] = new StringBuilder(YukiText.arcade14desc2);
		arcadeTitle[14] = new StringBuilder(YukiText.arcade15);
		arcadeDesc1[14] = new StringBuilder(YukiText.arcade15desc1);
		arcadeDesc2[14] = new StringBuilder(YukiText.arcade15desc2);
		arcadeTitle[15] = new StringBuilder(YukiText.arcade16);
		arcadeDesc1[15] = new StringBuilder(YukiText.arcade16desc1);
		arcadeDesc2[15] = new StringBuilder(YukiText.arcade16desc2);
		arcadeTitle[16] = new StringBuilder(YukiText.arcade17);
		arcadeDesc1[16] = new StringBuilder(YukiText.arcade17desc1);
		arcadeDesc2[16] = new StringBuilder(YukiText.arcade17desc2);
		arcadeTitle[17] = new StringBuilder(YukiText.arcade18);
		arcadeDesc1[17] = new StringBuilder(YukiText.arcade18desc1);
		arcadeDesc2[17] = new StringBuilder(YukiText.arcade18desc2);
		arcadeTitle[18] = new StringBuilder(YukiText.arcade19);
		arcadeDesc1[18] = new StringBuilder(YukiText.arcade19desc1);
		arcadeDesc2[18] = new StringBuilder(YukiText.arcade19desc2);
		arcadeTitle[19] = new StringBuilder(YukiText.arcade20);
		arcadeDesc1[19] = new StringBuilder(YukiText.arcade20desc1);
		arcadeDesc2[19] = new StringBuilder(YukiText.arcade20desc2);
		arcadeTitle[20] = new StringBuilder(YukiText.arcade21);
		arcadeDesc1[20] = new StringBuilder(YukiText.arcade21desc1);
		arcadeDesc2[20] = new StringBuilder(YukiText.arcade21desc2);
		arcadeTitle[21] = new StringBuilder(YukiText.arcade22);
		arcadeDesc1[21] = new StringBuilder(YukiText.arcade22desc1);
		arcadeDesc2[21] = new StringBuilder(YukiText.arcade22desc2);
		arcadeTitle[22] = new StringBuilder(YukiText.arcade23);
		arcadeDesc1[22] = new StringBuilder(YukiText.arcade23desc1);
		arcadeDesc2[22] = new StringBuilder(YukiText.arcade23desc2);
		arcadeTitle[23] = new StringBuilder(YukiText.arcade24);
		arcadeDesc1[23] = new StringBuilder(YukiText.arcade24desc1);
		arcadeDesc2[23] = new StringBuilder(YukiText.arcade24desc2);
		arcadeTitle[24] = new StringBuilder(YukiText.arcade25);
		arcadeDesc1[24] = new StringBuilder(YukiText.arcade25desc1);
		arcadeDesc2[24] = new StringBuilder(YukiText.arcade25desc2);
		arcadeTitle[25] = new StringBuilder(YukiText.arcade26);
		arcadeDesc1[25] = new StringBuilder(YukiText.arcade26desc1);
		arcadeDesc2[25] = new StringBuilder(YukiText.arcade26desc2);
		arcadeTitle[26] = new StringBuilder(YukiText.arcade27);
		arcadeDesc1[26] = new StringBuilder(YukiText.arcade27desc1);
		arcadeDesc2[26] = new StringBuilder(YukiText.arcade27desc2);
		arcadeTitle[27] = new StringBuilder(YukiText.arcade28);
		arcadeDesc1[27] = new StringBuilder(YukiText.arcade28desc1);
		arcadeDesc2[27] = new StringBuilder(YukiText.arcade28desc2);
		arcadeTitle[28] = new StringBuilder(YukiText.arcade29);
		arcadeDesc1[28] = new StringBuilder(YukiText.arcade29desc1);
		arcadeDesc2[28] = new StringBuilder(YukiText.arcade29desc2);
		arcadeTitle[29] = new StringBuilder(YukiText.arcade30);
		arcadeDesc1[29] = new StringBuilder(YukiText.arcade30desc1);
		arcadeDesc2[29] = new StringBuilder(YukiText.arcade30desc2);
		arcadeTitle[30] = new StringBuilder(YukiText.arcade31);
		arcadeDesc1[30] = new StringBuilder(YukiText.arcade31desc1);
		arcadeDesc2[30] = new StringBuilder(YukiText.arcade31desc2);
		arcadeTitle[31] = new StringBuilder(YukiText.arcade32);
		arcadeDesc1[31] = new StringBuilder(YukiText.arcade32desc1);
		arcadeDesc2[31] = new StringBuilder(YukiText.arcade32desc2);
		arcadeTitle[32] = new StringBuilder(YukiText.arcade33);
		arcadeDesc1[32] = new StringBuilder(YukiText.arcade33desc1);
		arcadeDesc2[32] = new StringBuilder(YukiText.arcade33desc2);
		arcadeTitle[33] = new StringBuilder(YukiText.arcade34);
		arcadeDesc1[33] = new StringBuilder(YukiText.arcade34desc1);
		arcadeDesc2[33] = new StringBuilder(YukiText.arcade34desc2);
		arcadeTitle[34] = new StringBuilder(YukiText.arcade35);
		arcadeDesc1[34] = new StringBuilder(YukiText.arcade35desc1);
		arcadeDesc2[34] = new StringBuilder(YukiText.arcade35desc2);
		arcadeTitle[35] = new StringBuilder(YukiText.arcade36);
		arcadeDesc1[35] = new StringBuilder(YukiText.arcade36desc1);
		arcadeDesc2[35] = new StringBuilder(YukiText.arcade36desc2);
		arcadeTitle[36] = new StringBuilder(YukiText.arcade37);
		arcadeDesc1[36] = new StringBuilder(YukiText.arcade37desc1);
		arcadeDesc2[36] = new StringBuilder(YukiText.arcade37desc2);
		arcadeTitle[37] = new StringBuilder(YukiText.arcade38);
		arcadeDesc1[37] = new StringBuilder(YukiText.arcade38desc1);
		arcadeDesc2[37] = new StringBuilder(YukiText.arcade38desc2);
		arcadeTitle[38] = new StringBuilder(YukiText.arcade39);
		arcadeDesc1[38] = new StringBuilder(YukiText.arcade39desc1);
		arcadeDesc2[38] = new StringBuilder(YukiText.arcade39desc2);
		arcadeTitle[39] = new StringBuilder(YukiText.arcade40);
		arcadeDesc1[39] = new StringBuilder(YukiText.arcade40desc1);
		arcadeDesc2[39] = new StringBuilder(YukiText.arcade40desc2);
		arcadeTitle[40] = new StringBuilder(YukiText.arcade41);
		arcadeDesc1[40] = new StringBuilder(YukiText.arcade41desc1);
		arcadeDesc2[40] = new StringBuilder(YukiText.arcade41desc2);
		arcadeTitle[41] = new StringBuilder(YukiText.arcade42);
		arcadeDesc1[41] = new StringBuilder(YukiText.arcade42desc1);
		arcadeDesc2[41] = new StringBuilder(YukiText.arcade42desc2);
		arcadeTitle[42] = new StringBuilder(YukiText.arcade43);
		arcadeDesc1[42] = new StringBuilder(YukiText.arcade43desc1);
		arcadeDesc2[42] = new StringBuilder(YukiText.arcade43desc2);
		arcadeTitle[43] = new StringBuilder(YukiText.arcade44);
		arcadeDesc1[43] = new StringBuilder(YukiText.arcade44desc1);
		arcadeDesc2[43] = new StringBuilder(YukiText.arcade44desc2);
		arcadeTitle[44] = new StringBuilder(YukiText.arcade45);
		arcadeDesc1[44] = new StringBuilder(YukiText.arcade45desc1);
		arcadeDesc2[44] = new StringBuilder(YukiText.arcade45desc2);
		arcadeTitle[45] = new StringBuilder(YukiText.arcade46);
		arcadeDesc1[45] = new StringBuilder(YukiText.arcade46desc1);
		arcadeDesc2[45] = new StringBuilder(YukiText.arcade46desc2);
		arcadeTitle[46] = new StringBuilder(YukiText.arcade47);
		arcadeDesc1[46] = new StringBuilder(YukiText.arcade47desc1);
		arcadeDesc2[46] = new StringBuilder(YukiText.arcade47desc2);
		arcadeTitle[47] = new StringBuilder(YukiText.arcade48);
		arcadeDesc1[47] = new StringBuilder(YukiText.arcade48desc1);
		arcadeDesc2[47] = new StringBuilder(YukiText.arcade48desc2);
		arcadeTitle[48] = new StringBuilder(YukiText.arcade49);
		arcadeDesc1[48] = new StringBuilder(YukiText.arcade49desc1);
		arcadeDesc2[48] = new StringBuilder(YukiText.arcade49desc2);
		arcadeTitle[49] = new StringBuilder(YukiText.arcade50);
		arcadeDesc1[49] = new StringBuilder(YukiText.arcade50desc1);
		arcadeDesc2[49] = new StringBuilder(YukiText.arcade50desc2);
		comic.Add("banker_banker_0_text1_0_0", new StringBuilder(YukiText.banker_banker_0_text1_0_0));
		comic.Add("banker_banker_0_text2_1_0", new StringBuilder(YukiText.banker_banker_0_text2_1_0));
		comic.Add("banker_banker_0_text2_1_1", new StringBuilder(YukiText.banker_banker_0_text2_1_1));
		comic.Add("banker_banker_0_text3_2_0", new StringBuilder(YukiText.banker_banker_0_text3_2_0));
		comic.Add("banker_banker_0_text4_3_0", new StringBuilder(YukiText.banker_banker_0_text4_3_0));
		comic.Add("banker_banker_0_text4_3_1", new StringBuilder(YukiText.banker_banker_0_text4_3_1));
		comic.Add("banker_banker_0_text5_4_0", new StringBuilder(YukiText.banker_banker_0_text5_4_0));
		comic.Add("banker_banker_0_text6_5_0", new StringBuilder(YukiText.banker_banker_0_text6_5_0));
		comic.Add("banker_banker_0_text7_6_0", new StringBuilder(YukiText.banker_banker_0_text7_6_0));
		comic.Add("banker_banker_0_text7_6_1", new StringBuilder(YukiText.banker_banker_0_text7_6_1));
		comic.Add("banker_banker_0_text8_7_0", new StringBuilder(YukiText.banker_banker_0_text8_7_0));
		comic.Add("bankerdead_dead_0_text1_0_0", new StringBuilder(YukiText.bankerdead_dead_0_text1_0_0));
		comic.Add("bankerdead_dead_0_text2_1_0", new StringBuilder(YukiText.bankerdead_dead_0_text2_1_0));
		comic.Add("bankerdead_dead_0_text3_2_0", new StringBuilder(YukiText.bankerdead_dead_0_text3_2_0));
		comic.Add("bankerdead_dead_0_text4_3_0", new StringBuilder(YukiText.bankerdead_dead_0_text4_3_0));
		comic.Add("bankerdead_dead_0_text5_4_0", new StringBuilder(YukiText.bankerdead_dead_0_text5_4_0));
		comic.Add("bankerkill_banker_0_text1_0_0", new StringBuilder(YukiText.bankerkill_banker_0_text1_0_0));
		comic.Add("bankerkill_banker_0_text1_0_1", new StringBuilder(YukiText.bankerkill_banker_0_text1_0_1));
		comic.Add("bankerkill_banker_0_text2_1_0", new StringBuilder(YukiText.bankerkill_banker_0_text2_1_0));
		comic.Add("bankerkill_banker_0_text2_1_1", new StringBuilder(YukiText.bankerkill_banker_0_text2_1_1));
		comic.Add("bankerkill_banker_0_text3_2_0", new StringBuilder(YukiText.bankerkill_banker_0_text3_2_0));
		comic.Add("bankerkill_banker_0_text4_3_0", new StringBuilder(YukiText.bankerkill_banker_0_text4_3_0));
		comic.Add("bankerkill_banker_0_text5_4_0", new StringBuilder(YukiText.bankerkill_banker_0_text5_4_0));
		comic.Add("bankerkill_banker_0_text6_5_0", new StringBuilder(YukiText.bankerkill_banker_0_text6_5_0));
		comic.Add("bankerkill_banker_0_text6_5_1", new StringBuilder(YukiText.bankerkill_banker_0_text6_5_1));
		comic.Add("bankerkill_banker_0_text7_6_0", new StringBuilder(YukiText.bankerkill_banker_0_text7_6_0));
		comic.Add("baptised_baptised_0_text1_0_0", new StringBuilder(YukiText.baptised_baptised_0_text1_0_0));
		comic.Add("baptised_baptised_0_text2_1_0", new StringBuilder(YukiText.baptised_baptised_0_text2_1_0));
		comic.Add("baptised_baptised_0_text3_2_0", new StringBuilder(YukiText.baptised_baptised_0_text3_2_0));
		comic.Add("baptised_baptised_0_text4_3_0", new StringBuilder(YukiText.baptised_baptised_0_text4_3_0));
		comic.Add("chef_yuki_yuki_0_text1_0_0", new StringBuilder(YukiText.chef_yuki_yuki_0_text1_0_0));
		comic.Add("chef_yuki_yuki_0_text2_1_0", new StringBuilder(YukiText.chef_yuki_yuki_0_text2_1_0));
		comic.Add("chef_yuki_yuki_0_text2_1_1", new StringBuilder(YukiText.chef_yuki_yuki_0_text2_1_1));
		comic.Add("chef_yuki_yuki_0_text3_2_0", new StringBuilder(YukiText.chef_yuki_yuki_0_text3_2_0));
		comic.Add("chef_yuki_yuki_0_text3_2_1", new StringBuilder(YukiText.chef_yuki_yuki_0_text3_2_1));
		comic.Add("chef_yuki_yuki_0_text4_3_0", new StringBuilder(YukiText.chef_yuki_yuki_0_text4_3_0));
		comic.Add("chef_yuki_yuki_0_text4_3_1", new StringBuilder(YukiText.chef_yuki_yuki_0_text4_3_1));
		comic.Add("chef_yuki_chef_1_text1_0_0", new StringBuilder(YukiText.chef_yuki_chef_1_text1_0_0));
		comic.Add("chef_yuki_chef_1_text2_1_0", new StringBuilder(YukiText.chef_yuki_chef_1_text2_1_0));
		comic.Add("chef_yuki_chef_1_text2_1_1", new StringBuilder(YukiText.chef_yuki_chef_1_text2_1_1));
		comic.Add("chef_yuki_chef_1_text3_2_0", new StringBuilder(YukiText.chef_yuki_chef_1_text3_2_0));
		comic.Add("chef_yuki_chef_1_text3_2_1", new StringBuilder(YukiText.chef_yuki_chef_1_text3_2_1));
		comic.Add("chef_yuki_chef_1_text4_3_0", new StringBuilder(YukiText.chef_yuki_chef_1_text4_3_0));
		comic.Add("chef_yuki_chef_1_text4_3_1", new StringBuilder(YukiText.chef_yuki_chef_1_text4_3_1));
		comic.Add("chef_yuki_yuki_2_text1_0_0", new StringBuilder(YukiText.chef_yuki_yuki_2_text1_0_0));
		comic.Add("chef_yuki_yuki_2_text2_1_0", new StringBuilder(YukiText.chef_yuki_yuki_2_text2_1_0));
		comic.Add("chef_yuki_yuki_2_text2_1_1", new StringBuilder(YukiText.chef_yuki_yuki_2_text2_1_1));
		comic.Add("chef_yuki_yuki_2_text3_2_0", new StringBuilder(YukiText.chef_yuki_yuki_2_text3_2_0));
		comic.Add("chef_yuki_yuki_2_text4_3_0", new StringBuilder(YukiText.chef_yuki_yuki_2_text4_3_0));
		comic.Add("chef_yuki_yuki_2_text4_3_1", new StringBuilder(YukiText.chef_yuki_yuki_2_text4_3_1));
		comic.Add("chef_yuki_chef_3_text1_0_0", new StringBuilder(YukiText.chef_yuki_chef_3_text1_0_0));
		comic.Add("chef_yuki_chef_3_text2_1_0", new StringBuilder(YukiText.chef_yuki_chef_3_text2_1_0));
		comic.Add("chef_yuki_chef_3_text2_1_1", new StringBuilder(YukiText.chef_yuki_chef_3_text2_1_1));
		comic.Add("chef_yuki_chef_3_text3_2_0", new StringBuilder(YukiText.chef_yuki_chef_3_text3_2_0));
		comic.Add("chef_yuki_chef_3_text4_3_0", new StringBuilder(YukiText.chef_yuki_chef_3_text4_3_0));
		comic.Add("chef_yuki_chef_3_text4_3_1", new StringBuilder(YukiText.chef_yuki_chef_3_text4_3_1));
		comic.Add("chef_yuki_chef_3_text5_4_0", new StringBuilder(YukiText.chef_yuki_chef_3_text5_4_0));
		comic.Add("chef_yuki_chef_3_text5_4_1", new StringBuilder(YukiText.chef_yuki_chef_3_text5_4_1));
		comic.Add("chef_yuki_chef_3_text6_6_0", new StringBuilder(YukiText.chef_yuki_chef_3_text6_6_0));
		comic.Add("chef_yuki_chef_3_text6_6_1", new StringBuilder(YukiText.chef_yuki_chef_3_text6_6_1));
		comic.Add("chef_yuki_yuki_4_text1_0_0", new StringBuilder(YukiText.chef_yuki_yuki_4_text1_0_0));
		comic.Add("chef_yuki_yuki_4_text2_1_0", new StringBuilder(YukiText.chef_yuki_yuki_4_text2_1_0));
		comic.Add("chef_yuki_yuki_4_text2_1_1", new StringBuilder(YukiText.chef_yuki_yuki_4_text2_1_1));
		comic.Add("chef_yuki_yuki_4_text3_2_0", new StringBuilder(YukiText.chef_yuki_yuki_4_text3_2_0));
		comic.Add("chef_yuki_yuki_4_text4_3_0", new StringBuilder(YukiText.chef_yuki_yuki_4_text4_3_0));
		comic.Add("chef_yuki_yuki_4_text4_3_1", new StringBuilder(YukiText.chef_yuki_yuki_4_text4_3_1));
		comic.Add("chef_yuki_yuki_4_text4_3_2", new StringBuilder(YukiText.chef_yuki_yuki_4_text4_3_2));
		comic.Add("chef_yuki_chef_5_text1_0_0", new StringBuilder(YukiText.chef_yuki_chef_5_text1_0_0));
		comic.Add("chef_yuki_chef_5_text1_0_1", new StringBuilder(YukiText.chef_yuki_chef_5_text1_0_1));
		comic.Add("chef_yuki_chef_5_text2_1_0", new StringBuilder(YukiText.chef_yuki_chef_5_text2_1_0));
		comic.Add("chef_yuki_chef_5_text2_1_1", new StringBuilder(YukiText.chef_yuki_chef_5_text2_1_1));
		comic.Add("chef_yuki_chef_5_text3_2_0", new StringBuilder(YukiText.chef_yuki_chef_5_text3_2_0));
		comic.Add("chef_yuki_chef_5_text4_3_0", new StringBuilder(YukiText.chef_yuki_chef_5_text4_3_0));
		comic.Add("coop_mask_mask_0_text1_0_0", new StringBuilder(YukiText.coop_mask_mask_0_text1_0_0));
		comic.Add("coop_mask_mask_0_text2_1_0", new StringBuilder(YukiText.coop_mask_mask_0_text2_1_0));
		comic.Add("coop_mask_mask_0_text3_2_0", new StringBuilder(YukiText.coop_mask_mask_0_text3_2_0));
		comic.Add("coop_mask_mask_0_text4_3_0", new StringBuilder(YukiText.coop_mask_mask_0_text4_3_0));
		comic.Add("coop_mask_dish_1_text1_0_0", new StringBuilder(YukiText.coop_mask_dish_1_text1_0_0));
		comic.Add("coop_mask_dish_1_text1_0_1", new StringBuilder(YukiText.coop_mask_dish_1_text1_0_1));
		comic.Add("coop_mask_dish_1_text2_1_0", new StringBuilder(YukiText.coop_mask_dish_1_text2_1_0));
		comic.Add("coop_mask_dish_1_text2_1_1", new StringBuilder(YukiText.coop_mask_dish_1_text2_1_1));
		comic.Add("coop_mask_dish_1_text3_2_0", new StringBuilder(YukiText.coop_mask_dish_1_text3_2_0));
		comic.Add("coop_mask_dish_1_text4_3_0", new StringBuilder(YukiText.coop_mask_dish_1_text4_3_0));
		comic.Add("coop_mask_dish_1_text4_3_1", new StringBuilder(YukiText.coop_mask_dish_1_text4_3_1));
		comic.Add("coop_mask_dish_1_text5_4_0", new StringBuilder(YukiText.coop_mask_dish_1_text5_4_0));
		comic.Add("coop_mask_dish_1_text5_4_1", new StringBuilder(YukiText.coop_mask_dish_1_text5_4_1));
		comic.Add("coop_puppets_puppet_0_text1_0_0", new StringBuilder(YukiText.coop_puppets_puppet_0_text1_0_0));
		comic.Add("coop_puppets_puppet_0_text2_1_0", new StringBuilder(YukiText.coop_puppets_puppet_0_text2_1_0));
		comic.Add("coop_puppets_puppet_0_text3_2_0", new StringBuilder(YukiText.coop_puppets_puppet_0_text3_2_0));
		comic.Add("coop_puppets_puppet_0_text4_3_0", new StringBuilder(YukiText.coop_puppets_puppet_0_text4_3_0));
		comic.Add("coop_start_yuki_0_text1_0_0", new StringBuilder(YukiText.coop_start_yuki_0_text1_0_0));
		comic.Add("coop_start_yuki_0_text2_1_0", new StringBuilder(YukiText.coop_start_yuki_0_text2_1_0));
		comic.Add("coop_start_yuki_0_text2_1_1", new StringBuilder(YukiText.coop_start_yuki_0_text2_1_1));
		comic.Add("coop_start_yuki_0_text3_2_0", new StringBuilder(YukiText.coop_start_yuki_0_text3_2_0));
		comic.Add("coop_start_yuki_0_text3_2_1", new StringBuilder(YukiText.coop_start_yuki_0_text3_2_1));
		comic.Add("coop_start_yuki_0_text4_3_0", new StringBuilder(YukiText.coop_start_yuki_0_text4_3_0));
		comic.Add("coop_start_yuki_0_text5_4_0", new StringBuilder(YukiText.coop_start_yuki_0_text5_4_0));
		comic.Add("coop_start_yuki_0_text6_5_0", new StringBuilder(YukiText.coop_start_yuki_0_text6_5_0));
		comic.Add("coop_start_dish_1_text1_0_0", new StringBuilder(YukiText.coop_start_dish_1_text1_0_0));
		comic.Add("coop_start_dish_1_text2_1_0", new StringBuilder(YukiText.coop_start_dish_1_text2_1_0));
		comic.Add("coop_start_dish_1_text2_1_1", new StringBuilder(YukiText.coop_start_dish_1_text2_1_1));
		comic.Add("coop_start_dish_1_text3_2_0", new StringBuilder(YukiText.coop_start_dish_1_text3_2_0));
		comic.Add("coop_start_dish_1_text4_3_0", new StringBuilder(YukiText.coop_start_dish_1_text4_3_0));
		comic.Add("coop_start_dish_1_text5_4_0", new StringBuilder(YukiText.coop_start_dish_1_text5_4_0));
		comic.Add("coop_start_dish_1_text5_4_1", new StringBuilder(YukiText.coop_start_dish_1_text5_4_1));
		comic.Add("coop_start_dish_1_text6_5_0", new StringBuilder(YukiText.coop_start_dish_1_text6_5_0));
		comic.Add("coop_start_dish_1_text7_6_0", new StringBuilder(YukiText.coop_start_dish_1_text7_6_0));
		comic.Add("coop_start_yuki_2_text1_0_0", new StringBuilder(YukiText.coop_start_yuki_2_text1_0_0));
		comic.Add("coop_start_yuki_2_text2_1_0", new StringBuilder(YukiText.coop_start_yuki_2_text2_1_0));
		comic.Add("coop_start_yuki_2_text3_2_0", new StringBuilder(YukiText.coop_start_yuki_2_text3_2_0));
		comic.Add("coop_start_yuki_2_text4_3_0", new StringBuilder(YukiText.coop_start_yuki_2_text4_3_0));
		comic.Add("demon_dead_asylum_0_text1_0_0", new StringBuilder(YukiText.demon_dead_asylum_0_text1_0_0));
		comic.Add("demon_dead_asylum_0_text2_1_0", new StringBuilder(YukiText.demon_dead_asylum_0_text2_1_0));
		comic.Add("demon_dead_asylum_0_text3_2_0", new StringBuilder(YukiText.demon_dead_asylum_0_text3_2_0));
		comic.Add("demon_dead_asylum_0_text4_3_0", new StringBuilder(YukiText.demon_dead_asylum_0_text4_3_0));
		comic.Add("dishisdead_yuki_0_text1_0_0", new StringBuilder(YukiText.dishisdead_yuki_0_text1_0_0));
		comic.Add("dishisdead_yuki_0_text2_1_0", new StringBuilder(YukiText.dishisdead_yuki_0_text2_1_0));
		comic.Add("dishisdead_yuki_0_text3_2_0", new StringBuilder(YukiText.dishisdead_yuki_0_text3_2_0));
		comic.Add("dishisdead_yuki_0_text4_3_0", new StringBuilder(YukiText.dishisdead_yuki_0_text4_3_0));
		comic.Add("dishisdead_yuki_0_talk1_4_0", new StringBuilder(YukiText.dishisdead_yuki_0_talk1_4_0));
		comic.Add("dishisdead_chef_1_text1_0_0", new StringBuilder(YukiText.dishisdead_chef_1_text1_0_0));
		comic.Add("dishisdead_chef_1_text2_1_0", new StringBuilder(YukiText.dishisdead_chef_1_text2_1_0));
		comic.Add("dishisdead_chef_1_text3_2_0", new StringBuilder(YukiText.dishisdead_chef_1_text3_2_0));
		comic.Add("dishisdead_yuki_2_text1_0_0", new StringBuilder(YukiText.dishisdead_yuki_2_text1_0_0));
		comic.Add("dishisdead_yuki_2_text2_1_0", new StringBuilder(YukiText.dishisdead_yuki_2_text2_1_0));
		comic.Add("dishisdead_yuki_2_text2_1_1", new StringBuilder(YukiText.dishisdead_yuki_2_text2_1_1));
		comic.Add("dishisdead_yuki_2_text3_2_0", new StringBuilder(YukiText.dishisdead_yuki_2_text3_2_0));
		comic.Add("dishisdead_yuki_2_text3_2_1", new StringBuilder(YukiText.dishisdead_yuki_2_text3_2_1));
		comic.Add("dishisdead_yuki_2_text4_3_0", new StringBuilder(YukiText.dishisdead_yuki_2_text4_3_0));
		comic.Add("dishisdead_yuki_2_text5_4_0", new StringBuilder(YukiText.dishisdead_yuki_2_text5_4_0));
		comic.Add("dishisdead_yuki_2_text5_4_1", new StringBuilder(YukiText.dishisdead_yuki_2_text5_4_1));
		comic.Add("dishisdead_chef_3_text1_0_0", new StringBuilder(YukiText.dishisdead_chef_3_text1_0_0));
		comic.Add("dishisdead_chef_3_text1_0_1", new StringBuilder(YukiText.dishisdead_chef_3_text1_0_1));
		comic.Add("dishisdead_chef_3_text2_1_0", new StringBuilder(YukiText.dishisdead_chef_3_text2_1_0));
		comic.Add("dishisdead_chef_3_text2_1_1", new StringBuilder(YukiText.dishisdead_chef_3_text2_1_1));
		comic.Add("dishisdead_chef_3_text3_2_0", new StringBuilder(YukiText.dishisdead_chef_3_text3_2_0));
		comic.Add("dishisdead_chef_3_text3_2_1", new StringBuilder(YukiText.dishisdead_chef_3_text3_2_1));
		comic.Add("dishisdead_chef_3_text4_3_0", new StringBuilder(YukiText.dishisdead_chef_3_text4_3_0));
		comic.Add("dishisdead_chef_3_text5_4_0", new StringBuilder(YukiText.dishisdead_chef_3_text5_4_0));
		comic.Add("dishisdead_yuki_4_text1_0_0", new StringBuilder(YukiText.dishisdead_yuki_4_text1_0_0));
		comic.Add("dishisdead_yuki_4_text1_0_1", new StringBuilder(YukiText.dishisdead_yuki_4_text1_0_1));
		comic.Add("dishisdead_yuki_4_text2_1_0", new StringBuilder(YukiText.dishisdead_yuki_4_text2_1_0));
		comic.Add("dishisdead_yuki_4_text3_2_0", new StringBuilder(YukiText.dishisdead_yuki_4_text3_2_0));
		comic.Add("dishisdead_chef_5_text1_0_0", new StringBuilder(YukiText.dishisdead_chef_5_text1_0_0));
		comic.Add("dishisdead_chef_5_text2_1_0", new StringBuilder(YukiText.dishisdead_chef_5_text2_1_0));
		comic.Add("dishisdead_chef_5_text2_1_1", new StringBuilder(YukiText.dishisdead_chef_5_text2_1_1));
		comic.Add("dishisdead_chef_5_text3_2_0", new StringBuilder(YukiText.dishisdead_chef_5_text3_2_0));
		comic.Add("dishisdead_chef_5_text4_3_0", new StringBuilder(YukiText.dishisdead_chef_5_text4_3_0));
		comic.Add("dishisdead_chef_5_text4_3_1", new StringBuilder(YukiText.dishisdead_chef_5_text4_3_1));
		comic.Add("dishisdead_chef_5_text5_4_0", new StringBuilder(YukiText.dishisdead_chef_5_text5_4_0));
		comic.Add("dishisdead_chef_5_text6_5_0", new StringBuilder(YukiText.dishisdead_chef_5_text6_5_0));
		comic.Add("dishisdead_chef_5_text6_5_1", new StringBuilder(YukiText.dishisdead_chef_5_text6_5_1));
		comic.Add("dishisdead_chef_5_text7_6_0", new StringBuilder(YukiText.dishisdead_chef_5_text7_6_0));
		comic.Add("dishisdead_chef_5_text7_6_1", new StringBuilder(YukiText.dishisdead_chef_5_text7_6_1));
		comic.Add("dishisdead_chef_5_text8_7_0", new StringBuilder(YukiText.dishisdead_chef_5_text8_7_0));
		comic.Add("dishisdead_yuki_6_text1_0_0", new StringBuilder(YukiText.dishisdead_yuki_6_text1_0_0));
		comic.Add("dishisdead_yuki_6_text2_1_0", new StringBuilder(YukiText.dishisdead_yuki_6_text2_1_0));
		comic.Add("dishisdead_yuki_6_text3_2_0", new StringBuilder(YukiText.dishisdead_yuki_6_text3_2_0));
		comic.Add("dishisdead_yuki_6_text4_3_0", new StringBuilder(YukiText.dishisdead_yuki_6_text4_3_0));
		comic.Add("dish_aqua_dish_0_text_0_0", new StringBuilder(YukiText.dish_aqua_dish_0_text_0_0));
		comic.Add("dish_aqua_dish_0_text_0_1", new StringBuilder(YukiText.dish_aqua_dish_0_text_0_1));
		comic.Add("dish_aqua_dish_0_text_1_0", new StringBuilder(YukiText.dish_aqua_dish_0_text_1_0));
		comic.Add("dish_aqua_dish_0_text_1_1", new StringBuilder(YukiText.dish_aqua_dish_0_text_1_1));
		comic.Add("dish_aqua_dish_0_text_2_0", new StringBuilder(YukiText.dish_aqua_dish_0_text_2_0));
		comic.Add("dish_aqua_dish_0_text_3_0", new StringBuilder(YukiText.dish_aqua_dish_0_text_3_0));
		comic.Add("dish_aqua_dish_0_text_3_1", new StringBuilder(YukiText.dish_aqua_dish_0_text_3_1));
		comic.Add("dish_aqua_dish_0_text_4_0", new StringBuilder(YukiText.dish_aqua_dish_0_text_4_0));
		comic.Add("dish_aqua_dish_0_text_5_0", new StringBuilder(YukiText.dish_aqua_dish_0_text_5_0));
		comic.Add("dish_cache_dish_0_text1_0_0", new StringBuilder(YukiText.dish_cache_dish_0_text1_0_0));
		comic.Add("dish_cache_dish_0_text2_1_0", new StringBuilder(YukiText.dish_cache_dish_0_text2_1_0));
		comic.Add("dish_cache_dish_0_text2_1_1", new StringBuilder(YukiText.dish_cache_dish_0_text2_1_1));
		comic.Add("dish_cache_dish_0_text3_2_0", new StringBuilder(YukiText.dish_cache_dish_0_text3_2_0));
		comic.Add("dish_cache_dish_0_text3_2_1", new StringBuilder(YukiText.dish_cache_dish_0_text3_2_1));
		comic.Add("dish_cache_dish_0_text4_3_0", new StringBuilder(YukiText.dish_cache_dish_0_text4_3_0));
		comic.Add("dish_cache_dish_0_text4_3_1", new StringBuilder(YukiText.dish_cache_dish_0_text4_3_1));
		comic.Add("dish_cache_dish_0_text5_4_0", new StringBuilder(YukiText.dish_cache_dish_0_text5_4_0));
		comic.Add("dish_cafe_dish_0_text1_0_0", new StringBuilder(YukiText.dish_cafe_dish_0_text1_0_0));
		comic.Add("dish_cafe_dish_0_text2_1_0", new StringBuilder(YukiText.dish_cafe_dish_0_text2_1_0));
		comic.Add("dish_cafe_dish_0_text3_2_0", new StringBuilder(YukiText.dish_cafe_dish_0_text3_2_0));
		comic.Add("dish_cafe_dish_0_text5_3_0", new StringBuilder(YukiText.dish_cafe_dish_0_text5_3_0));
		comic.Add("dish_chef_dish_0_text1_0_0", new StringBuilder(YukiText.dish_chef_dish_0_text1_0_0));
		comic.Add("dish_chef_dish_0_text2_1_0", new StringBuilder(YukiText.dish_chef_dish_0_text2_1_0));
		comic.Add("dish_chef_dish_0_text2_1_1", new StringBuilder(YukiText.dish_chef_dish_0_text2_1_1));
		comic.Add("dish_chef_dish_0_text3_2_0", new StringBuilder(YukiText.dish_chef_dish_0_text3_2_0));
		comic.Add("dish_chef_dish_0_text3_2_1", new StringBuilder(YukiText.dish_chef_dish_0_text3_2_1));
		comic.Add("dish_chef_dish_0_text4_3_0", new StringBuilder(YukiText.dish_chef_dish_0_text4_3_0));
		comic.Add("dish_chef_dish_0_text4_3_1", new StringBuilder(YukiText.dish_chef_dish_0_text4_3_1));
		comic.Add("dish_chef_chef_1_text1_0_0", new StringBuilder(YukiText.dish_chef_chef_1_text1_0_0));
		comic.Add("dish_chef_chef_1_text2_1_0", new StringBuilder(YukiText.dish_chef_chef_1_text2_1_0));
		comic.Add("dish_chef_chef_1_text2_1_1", new StringBuilder(YukiText.dish_chef_chef_1_text2_1_1));
		comic.Add("dish_chef_chef_1_text3_2_0", new StringBuilder(YukiText.dish_chef_chef_1_text3_2_0));
		comic.Add("dish_chef_chef_1_text3_2_1", new StringBuilder(YukiText.dish_chef_chef_1_text3_2_1));
		comic.Add("dish_chef_chef_1_text4_3_0", new StringBuilder(YukiText.dish_chef_chef_1_text4_3_0));
		comic.Add("dish_chef_chef_1_text4_3_1", new StringBuilder(YukiText.dish_chef_chef_1_text4_3_1));
		comic.Add("dish_chef_dish_2_text1_0_0", new StringBuilder(YukiText.dish_chef_dish_2_text1_0_0));
		comic.Add("dish_chef_dish_2_text2_1_0", new StringBuilder(YukiText.dish_chef_dish_2_text2_1_0));
		comic.Add("dish_chef_dish_2_text2_1_1", new StringBuilder(YukiText.dish_chef_dish_2_text2_1_1));
		comic.Add("dish_chef_dish_2_text3_2_0", new StringBuilder(YukiText.dish_chef_dish_2_text3_2_0));
		comic.Add("dish_chef_dish_2_text3_2_1", new StringBuilder(YukiText.dish_chef_dish_2_text3_2_1));
		comic.Add("dish_chef_chef_3_text1_0_0", new StringBuilder(YukiText.dish_chef_chef_3_text1_0_0));
		comic.Add("dish_chef_chef_3_text1_0_1", new StringBuilder(YukiText.dish_chef_chef_3_text1_0_1));
		comic.Add("dish_chef_chef_3_text1_0_2", new StringBuilder(YukiText.dish_chef_chef_3_text1_0_2));
		comic.Add("dish_chef_chef_3_text2_1_0", new StringBuilder(YukiText.dish_chef_chef_3_text2_1_0));
		comic.Add("dish_chef_chef_3_text2_1_1", new StringBuilder(YukiText.dish_chef_chef_3_text2_1_1));
		comic.Add("dish_chef_chef_3_text3_2_0", new StringBuilder(YukiText.dish_chef_chef_3_text3_2_0));
		comic.Add("dish_chef_chef_3_text3_2_1", new StringBuilder(YukiText.dish_chef_chef_3_text3_2_1));
		comic.Add("dish_chef_chef_3_text4_3_0", new StringBuilder(YukiText.dish_chef_chef_3_text4_3_0));
		comic.Add("dish_chef_dish_4_text1_0_0", new StringBuilder(YukiText.dish_chef_dish_4_text1_0_0));
		comic.Add("dish_chef_dish_4_text2_1_0", new StringBuilder(YukiText.dish_chef_dish_4_text2_1_0));
		comic.Add("dish_chef_dish_4_text2_1_1", new StringBuilder(YukiText.dish_chef_dish_4_text2_1_1));
		comic.Add("dish_chef_chef_5_text1_0_0", new StringBuilder(YukiText.dish_chef_chef_5_text1_0_0));
		comic.Add("dish_chef_chef_5_text1_0_1", new StringBuilder(YukiText.dish_chef_chef_5_text1_0_1));
		comic.Add("dish_chef_chef_5_text2_1_0", new StringBuilder(YukiText.dish_chef_chef_5_text2_1_0));
		comic.Add("dish_chef_chef_5_text2_1_1", new StringBuilder(YukiText.dish_chef_chef_5_text2_1_1));
		comic.Add("dish_chef_chef_5_text3_2_0", new StringBuilder(YukiText.dish_chef_chef_5_text3_2_0));
		comic.Add("dish_chef_chef_5_text3_2_1", new StringBuilder(YukiText.dish_chef_chef_5_text3_2_1));
		comic.Add("dish_chef_chef_5_text4_3_0", new StringBuilder(YukiText.dish_chef_chef_5_text4_3_0));
		comic.Add("dish_chef_chef_5_text4_3_1", new StringBuilder(YukiText.dish_chef_chef_5_text4_3_1));
		comic.Add("dish_chef_chef_5_text5_4_0", new StringBuilder(YukiText.dish_chef_chef_5_text5_4_0));
		comic.Add("dish_chef_chef_5_text5_4_1", new StringBuilder(YukiText.dish_chef_chef_5_text5_4_1));
		comic.Add("dish_chef_dish_6_text1_0_0", new StringBuilder(YukiText.dish_chef_dish_6_text1_0_0));
		comic.Add("dish_chef_dish_6_text2_1_0", new StringBuilder(YukiText.dish_chef_dish_6_text2_1_0));
		comic.Add("dish_chef_dish_6_text3_2_0", new StringBuilder(YukiText.dish_chef_dish_6_text3_2_0));
		comic.Add("dish_crypt_dish_0_text1_0_0", new StringBuilder(YukiText.dish_crypt_dish_0_text1_0_0));
		comic.Add("dish_crypt_dish_0_text2_1_0", new StringBuilder(YukiText.dish_crypt_dish_0_text2_1_0));
		comic.Add("dish_crypt_dish_0_text3_2_0", new StringBuilder(YukiText.dish_crypt_dish_0_text3_2_0));
		comic.Add("dish_crypt_dish_0_text3_2_1", new StringBuilder(YukiText.dish_crypt_dish_0_text3_2_1));
		comic.Add("dish_crypt_dish_0_text4_3_0", new StringBuilder(YukiText.dish_crypt_dish_0_text4_3_0));
		comic.Add("dish_crypt_dish_0_text5_4_0", new StringBuilder(YukiText.dish_crypt_dish_0_text5_4_0));
		comic.Add("dish_crypt_dish_0_text6_5_0", new StringBuilder(YukiText.dish_crypt_dish_0_text6_5_0));
		comic.Add("dish_crypt_dish_0_text6_5_1", new StringBuilder(YukiText.dish_crypt_dish_0_text6_5_1));
		comic.Add("dish_dark_dish_0_text1_0_0", new StringBuilder(YukiText.dish_dark_dish_0_text1_0_0));
		comic.Add("dish_dark_dish_0_text2_1_0", new StringBuilder(YukiText.dish_dark_dish_0_text2_1_0));
		comic.Add("dish_dark_dish_0_text2_1_1", new StringBuilder(YukiText.dish_dark_dish_0_text2_1_1));
		comic.Add("dish_dark_dish_0_text3_2_0", new StringBuilder(YukiText.dish_dark_dish_0_text3_2_0));
		comic.Add("dish_dark_dish_0_text4_3_0", new StringBuilder(YukiText.dish_dark_dish_0_text4_3_0));
		comic.Add("dish_dark_dish_0_text4_3_1", new StringBuilder(YukiText.dish_dark_dish_0_text4_3_1));
		comic.Add("dish_engie_engie_0_text1_0_0", new StringBuilder(YukiText.dish_engie_engie_0_text1_0_0));
		comic.Add("dish_engie_engie_0_text1_0_1", new StringBuilder(YukiText.dish_engie_engie_0_text1_0_1));
		comic.Add("dish_engie_engie_0_text2_1_0", new StringBuilder(YukiText.dish_engie_engie_0_text2_1_0));
		comic.Add("dish_engie_engie_0_text3_2_0", new StringBuilder(YukiText.dish_engie_engie_0_text3_2_0));
		comic.Add("dish_engie_engie_0_text3_2_1", new StringBuilder(YukiText.dish_engie_engie_0_text3_2_1));
		comic.Add("dish_engie_engie_0_text4_3_0", new StringBuilder(YukiText.dish_engie_engie_0_text4_3_0));
		comic.Add("dish_engie_engie_0_text4_3_1", new StringBuilder(YukiText.dish_engie_engie_0_text4_3_1));
		comic.Add("dish_engie_engie_0_text5_4_0", new StringBuilder(YukiText.dish_engie_engie_0_text5_4_0));
		comic.Add("dish_engie_engie_0_text6_5_0", new StringBuilder(YukiText.dish_engie_engie_0_text6_5_0));
		comic.Add("dish_general_dish_0_text_0_0", new StringBuilder(YukiText.dish_general_dish_0_text_0_0));
		comic.Add("dish_general_dish_0_text_0_1", new StringBuilder(YukiText.dish_general_dish_0_text_0_1));
		comic.Add("dish_general_dish_0_text_1_0", new StringBuilder(YukiText.dish_general_dish_0_text_1_0));
		comic.Add("dish_general_dish_0_text_2_0", new StringBuilder(YukiText.dish_general_dish_0_text_2_0));
		comic.Add("dish_general_dish_0_text_3_0", new StringBuilder(YukiText.dish_general_dish_0_text_3_0));
		comic.Add("dish_general_dish_0_text_4_0", new StringBuilder(YukiText.dish_general_dish_0_text_4_0));
		comic.Add("dish_gross_gross_0_text1_0_0", new StringBuilder(YukiText.dish_gross_gross_0_text1_0_0));
		comic.Add("dish_gross_gross_0_text1_0_1", new StringBuilder(YukiText.dish_gross_gross_0_text1_0_1));
		comic.Add("dish_gross_gross_0_text2_1_0", new StringBuilder(YukiText.dish_gross_gross_0_text2_1_0));
		comic.Add("dish_gross_gross_0_text3_2_0", new StringBuilder(YukiText.dish_gross_gross_0_text3_2_0));
		comic.Add("dish_gross_gross_0_text3_2_1", new StringBuilder(YukiText.dish_gross_gross_0_text3_2_1));
		comic.Add("dish_gross_gross_0_text4_3_0", new StringBuilder(YukiText.dish_gross_gross_0_text4_3_0));
		comic.Add("dish_gross_gross_0_text4_3_1", new StringBuilder(YukiText.dish_gross_gross_0_text4_3_1));
		comic.Add("dish_gross_gross_0_text5_4_0", new StringBuilder(YukiText.dish_gross_gross_0_text5_4_0));
		comic.Add("dish_gross_gross_0_text6_5_0", new StringBuilder(YukiText.dish_gross_gross_0_text6_5_0));
		comic.Add("dish_hockey_hockey_0_text_0_0", new StringBuilder(YukiText.dish_hockey_hockey_0_text_0_0));
		comic.Add("dish_hockey_hockey_0_text_0_1", new StringBuilder(YukiText.dish_hockey_hockey_0_text_0_1));
		comic.Add("dish_hockey_hockey_0_text_1_0", new StringBuilder(YukiText.dish_hockey_hockey_0_text_1_0));
		comic.Add("dish_hockey_hockey_0_text_1_1", new StringBuilder(YukiText.dish_hockey_hockey_0_text_1_1));
		comic.Add("dish_hockey_hockey_0_text_2_0", new StringBuilder(YukiText.dish_hockey_hockey_0_text_2_0));
		comic.Add("dish_hockey_hockey_0_text_3_0", new StringBuilder(YukiText.dish_hockey_hockey_0_text_3_0));
		comic.Add("dish_hockey_hockey_0_text_3_1", new StringBuilder(YukiText.dish_hockey_hockey_0_text_3_1));
		comic.Add("dish_hockey_hockey_0_text_4_0", new StringBuilder(YukiText.dish_hockey_hockey_0_text_4_0));
		comic.Add("dish_hockey_hockey_0_text_5_0", new StringBuilder(YukiText.dish_hockey_hockey_0_text_5_0));
		comic.Add("dish_judge_done_0_text1_0_0", new StringBuilder(YukiText.dish_judge_done_0_text1_0_0));
		comic.Add("dish_judge_done_0_text2_1_0", new StringBuilder(YukiText.dish_judge_done_0_text2_1_0));
		comic.Add("dish_judge_done_0_text2_1_1", new StringBuilder(YukiText.dish_judge_done_0_text2_1_1));
		comic.Add("dish_judge_done_0_text3_2_0", new StringBuilder(YukiText.dish_judge_done_0_text3_2_0));
		comic.Add("dish_judge_done_0_text3_2_1", new StringBuilder(YukiText.dish_judge_done_0_text3_2_1));
		comic.Add("dish_judge_done_0_text4_3_0", new StringBuilder(YukiText.dish_judge_done_0_text4_3_0));
		comic.Add("dish_judge_done_0_text4_3_1", new StringBuilder(YukiText.dish_judge_done_0_text4_3_1));
		comic.Add("dish_judge_done_0_text5_4_0", new StringBuilder(YukiText.dish_judge_done_0_text5_4_0));
		comic.Add("dish_judge_done_0_text6_5_0", new StringBuilder(YukiText.dish_judge_done_0_text6_5_0));
		comic.Add("dish_judge_judge_1_text1_0_0", new StringBuilder(YukiText.dish_judge_judge_1_text1_0_0));
		comic.Add("dish_judge_judge_1_text1_0_1", new StringBuilder(YukiText.dish_judge_judge_1_text1_0_1));
		comic.Add("dish_judge_judge_1_text2_1_0", new StringBuilder(YukiText.dish_judge_judge_1_text2_1_0));
		comic.Add("dish_judge_judge_1_text2_1_1", new StringBuilder(YukiText.dish_judge_judge_1_text2_1_1));
		comic.Add("dish_judge_judge_1_text3_2_0", new StringBuilder(YukiText.dish_judge_judge_1_text3_2_0));
		comic.Add("dish_judge_judge_1_text4_3_0", new StringBuilder(YukiText.dish_judge_judge_1_text4_3_0));
		comic.Add("dish_judge_judge_1_text5_4_0", new StringBuilder(YukiText.dish_judge_judge_1_text5_4_0));
		comic.Add("dish_judge_judge_1_text6_5_0", new StringBuilder(YukiText.dish_judge_judge_1_text6_5_0));
		comic.Add("dish_judge_judge_1_text7_6_0", new StringBuilder(YukiText.dish_judge_judge_1_text7_6_0));
		comic.Add("dish_lobby_dish_0_text1_0_0", new StringBuilder(YukiText.dish_lobby_dish_0_text1_0_0));
		comic.Add("dish_lobby_dish_0_text2_1_0", new StringBuilder(YukiText.dish_lobby_dish_0_text2_1_0));
		comic.Add("dish_lobby_dish_0_text2_1_1", new StringBuilder(YukiText.dish_lobby_dish_0_text2_1_1));
		comic.Add("dish_lobby_dish_0_text3_2_0", new StringBuilder(YukiText.dish_lobby_dish_0_text3_2_0));
		comic.Add("dish_lobby_dish_0_text4_3_0", new StringBuilder(YukiText.dish_lobby_dish_0_text4_3_0));
		comic.Add("dish_lobby_dish_0_text4_3_1", new StringBuilder(YukiText.dish_lobby_dish_0_text4_3_1));
		comic.Add("dish_lobby_dish_0_text5_4_0", new StringBuilder(YukiText.dish_lobby_dish_0_text5_4_0));
		comic.Add("dish_lobby_dish_0_text6_5_0", new StringBuilder(YukiText.dish_lobby_dish_0_text6_5_0));
		comic.Add("dish_mask_mask_0_text1_0_0", new StringBuilder(YukiText.dish_mask_mask_0_text1_0_0));
		comic.Add("dish_mask_mask_0_text2_1_0", new StringBuilder(YukiText.dish_mask_mask_0_text2_1_0));
		comic.Add("dish_mask_mask_0_text2_1_1", new StringBuilder(YukiText.dish_mask_mask_0_text2_1_1));
		comic.Add("dish_mask_mask_0_text3_2_0", new StringBuilder(YukiText.dish_mask_mask_0_text3_2_0));
		comic.Add("dish_mask_mask_0_text4_3_0", new StringBuilder(YukiText.dish_mask_mask_0_text4_3_0));
		comic.Add("dish_mask_dish_1_text1_0_0", new StringBuilder(YukiText.dish_mask_dish_1_text1_0_0));
		comic.Add("dish_mask_dish_1_text1_0_1", new StringBuilder(YukiText.dish_mask_dish_1_text1_0_1));
		comic.Add("dish_mask_dish_1_text2_1_0", new StringBuilder(YukiText.dish_mask_dish_1_text2_1_0));
		comic.Add("dish_mask_dish_1_text2_1_1", new StringBuilder(YukiText.dish_mask_dish_1_text2_1_1));
		comic.Add("dish_mask_dish_1_text3_2_0", new StringBuilder(YukiText.dish_mask_dish_1_text3_2_0));
		comic.Add("dish_mask_dish_1_text4_3_0", new StringBuilder(YukiText.dish_mask_dish_1_text4_3_0));
		comic.Add("dish_mask_dish_1_text4_3_1", new StringBuilder(YukiText.dish_mask_dish_1_text4_3_1));
		comic.Add("dish_mask_dish_1_text5_4_0", new StringBuilder(YukiText.dish_mask_dish_1_text5_4_0));
		comic.Add("dish_puppets_puppet_0_text1_0_0", new StringBuilder(YukiText.dish_puppets_puppet_0_text1_0_0));
		comic.Add("dish_puppets_puppet_0_text2_1_0", new StringBuilder(YukiText.dish_puppets_puppet_0_text2_1_0));
		comic.Add("dish_puppets_puppet_0_text3_2_0", new StringBuilder(YukiText.dish_puppets_puppet_0_text3_2_0));
		comic.Add("dish_puppets_puppet_0_text4_3_0", new StringBuilder(YukiText.dish_puppets_puppet_0_text4_3_0));
		comic.Add("dish_rgb_dish_0_text1_0_0", new StringBuilder(YukiText.dish_rgb_dish_0_text1_0_0));
		comic.Add("dish_rgb_dish_0_text1_0_1", new StringBuilder(YukiText.dish_rgb_dish_0_text1_0_1));
		comic.Add("dish_rgb_dish_0_text2_1_0", new StringBuilder(YukiText.dish_rgb_dish_0_text2_1_0));
		comic.Add("dish_rgb_dish_0_text2_1_1", new StringBuilder(YukiText.dish_rgb_dish_0_text2_1_1));
		comic.Add("dish_rgb_dish_0_text3_2_0", new StringBuilder(YukiText.dish_rgb_dish_0_text3_2_0));
		comic.Add("dish_rgb_dish_0_text4_3_0", new StringBuilder(YukiText.dish_rgb_dish_0_text4_3_0));
		comic.Add("dish_rgb_dish_0_text4_3_1", new StringBuilder(YukiText.dish_rgb_dish_0_text4_3_1));
		comic.Add("dish_rgb_dish_0_text5_4_0", new StringBuilder(YukiText.dish_rgb_dish_0_text5_4_0));
		comic.Add("dish_rgb_dish_0_text6_5_0", new StringBuilder(YukiText.dish_rgb_dish_0_text6_5_0));
		comic.Add("dish_rgb_dish_0_text7_6_0", new StringBuilder(YukiText.dish_rgb_dish_0_text7_6_0));
		comic.Add("dish_slava_dish_0_text1_0_0", new StringBuilder(YukiText.dish_slava_dish_0_text1_0_0));
		comic.Add("dish_slava_dish_0_text2_1_0", new StringBuilder(YukiText.dish_slava_dish_0_text2_1_0));
		comic.Add("dish_slava_dish_0_text3_2_0", new StringBuilder(YukiText.dish_slava_dish_0_text3_2_0));
		comic.Add("dish_slava_dish_0_text4_3_0", new StringBuilder(YukiText.dish_slava_dish_0_text4_3_0));
		comic.Add("dish_slava_dish_0_text4_3_1", new StringBuilder(YukiText.dish_slava_dish_0_text4_3_1));
		comic.Add("dish_slava_dish_0_text5_4_0", new StringBuilder(YukiText.dish_slava_dish_0_text5_4_0));
		comic.Add("dish_slava_dish_0_text6_5_0", new StringBuilder(YukiText.dish_slava_dish_0_text6_5_0));
		comic.Add("dish_start_moon_0_text1_0_0", new StringBuilder(YukiText.dish_start_moon_0_text1_0_0));
		comic.Add("dish_start_moon_0_text2_1_0", new StringBuilder(YukiText.dish_start_moon_0_text2_1_0));
		comic.Add("dish_start_moon_0_text3_2_0", new StringBuilder(YukiText.dish_start_moon_0_text3_2_0));
		comic.Add("dish_start_moon_0_text3_2_1", new StringBuilder(YukiText.dish_start_moon_0_text3_2_1));
		comic.Add("dish_start_moon_0_text4_3_0", new StringBuilder(YukiText.dish_start_moon_0_text4_3_0));
		comic.Add("dish_start_moon_0_text4_3_1", new StringBuilder(YukiText.dish_start_moon_0_text4_3_1));
		comic.Add("dish_start_moon_0_text5_4_0", new StringBuilder(YukiText.dish_start_moon_0_text5_4_0));
		comic.Add("dish_start_moon_0_text6_5_0", new StringBuilder(YukiText.dish_start_moon_0_text6_5_0));
		comic.Add("dish_start_moon_0_text6_5_1", new StringBuilder(YukiText.dish_start_moon_0_text6_5_1));
		comic.Add("dish_start_dish_1_text1_0_0", new StringBuilder(YukiText.dish_start_dish_1_text1_0_0));
		comic.Add("dish_start_dish_1_text1_0_1", new StringBuilder(YukiText.dish_start_dish_1_text1_0_1));
		comic.Add("dish_start_dish_1_text2_1_0", new StringBuilder(YukiText.dish_start_dish_1_text2_1_0));
		comic.Add("dish_start_dish_1_text2_1_1", new StringBuilder(YukiText.dish_start_dish_1_text2_1_1));
		comic.Add("dish_start_dish_1_text3_2_0", new StringBuilder(YukiText.dish_start_dish_1_text3_2_0));
		comic.Add("dish_start_dish_1_text4_3_0", new StringBuilder(YukiText.dish_start_dish_1_text4_3_0));
		comic.Add("dish_start_dish_1_text4_3_1", new StringBuilder(YukiText.dish_start_dish_1_text4_3_1));
		comic.Add("dish_start_dish_1_text5_4_0", new StringBuilder(YukiText.dish_start_dish_1_text5_4_0));
		comic.Add("dish_start_dish_1_text6_5_0", new StringBuilder(YukiText.dish_start_dish_1_text6_5_0));
		comic.Add("dish_yuki_yuki_0_text1_0_0", new StringBuilder(YukiText.dish_yuki_yuki_0_text1_0_0));
		comic.Add("dish_yuki_yuki_0_text2_1_0", new StringBuilder(YukiText.dish_yuki_yuki_0_text2_1_0));
		comic.Add("dish_yuki_yuki_0_text3_2_0", new StringBuilder(YukiText.dish_yuki_yuki_0_text3_2_0));
		comic.Add("dish_yuki_yuki_0_text4_3_0", new StringBuilder(YukiText.dish_yuki_yuki_0_text4_3_0));
		comic.Add("dish_yuki_yuki_0_text5_4_0", new StringBuilder(YukiText.dish_yuki_yuki_0_text5_4_0));
		comic.Add("dish_yuki_yuki_0_text6_5_0", new StringBuilder(YukiText.dish_yuki_yuki_0_text6_5_0));
		comic.Add("dish_yuki_dish_1_text1_0_0", new StringBuilder(YukiText.dish_yuki_dish_1_text1_0_0));
		comic.Add("dish_yuki_dish_1_text2_1_0", new StringBuilder(YukiText.dish_yuki_dish_1_text2_1_0));
		comic.Add("dish_yuki_dish_1_text3_2_0", new StringBuilder(YukiText.dish_yuki_dish_1_text3_2_0));
		comic.Add("dish_yuki_dish_1_text4_3_0", new StringBuilder(YukiText.dish_yuki_dish_1_text4_3_0));
		comic.Add("dish_yuki_dish_1_text5_4_0", new StringBuilder(YukiText.dish_yuki_dish_1_text5_4_0));
		comic.Add("dish_yuki_dish_1_text6_5_0", new StringBuilder(YukiText.dish_yuki_dish_1_text6_5_0));
		comic.Add("dish_yuki_dish_1_text7_6_0", new StringBuilder(YukiText.dish_yuki_dish_1_text7_6_0));
		comic.Add("dish_yuki_yuki_2_text1_0_0", new StringBuilder(YukiText.dish_yuki_yuki_2_text1_0_0));
		comic.Add("dish_yuki_yuki_2_text2_1_0", new StringBuilder(YukiText.dish_yuki_yuki_2_text2_1_0));
		comic.Add("dish_yuki_yuki_2_text3_2_0", new StringBuilder(YukiText.dish_yuki_yuki_2_text3_2_0));
		comic.Add("dish_yuki_yuki_2_text3_2_1", new StringBuilder(YukiText.dish_yuki_yuki_2_text3_2_1));
		comic.Add("dish_yuki_yuki_2_text4_3_0", new StringBuilder(YukiText.dish_yuki_yuki_2_text4_3_0));
		comic.Add("dish_yuki_yuki_2_text4_3_1", new StringBuilder(YukiText.dish_yuki_yuki_2_text4_3_1));
		comic.Add("dish_yuki_yuki_2_text5_4_0", new StringBuilder(YukiText.dish_yuki_yuki_2_text5_4_0));
		comic.Add("dish_yuki_yuki_2_text5_4_1", new StringBuilder(YukiText.dish_yuki_yuki_2_text5_4_1));
		comic.Add("engiehand_engie_0_text1_0_0", new StringBuilder(YukiText.engiehand_engie_0_text1_0_0));
		comic.Add("engiehand_engie_0_text2_1_0", new StringBuilder(YukiText.engiehand_engie_0_text2_1_0));
		comic.Add("engiehand_engie_0_text3_2_0", new StringBuilder(YukiText.engiehand_engie_0_text3_2_0));
		comic.Add("engiehand_engie_0_text4_3_0", new StringBuilder(YukiText.engiehand_engie_0_text4_3_0));
		comic.Add("engiehand_engie_0_text5_4_0", new StringBuilder(YukiText.engiehand_engie_0_text5_4_0));
		comic.Add("engiehand_engie_0_text6_5_0", new StringBuilder(YukiText.engiehand_engie_0_text6_5_0));
		comic.Add("floor_floor_0_talk1_0_0", new StringBuilder(YukiText.floor_floor_0_talk1_0_0));
		comic.Add("floor_floor_0_talk2_1_0", new StringBuilder(YukiText.floor_floor_0_talk2_1_0));
		comic.Add("floor_floor_0_talk3_2_0", new StringBuilder(YukiText.floor_floor_0_talk3_2_0));
		comic.Add("floor_floor_0_talk3_2_1", new StringBuilder(YukiText.floor_floor_0_talk3_2_1));
		comic.Add("floor_floor_0_talk4_3_0", new StringBuilder(YukiText.floor_floor_0_talk4_3_0));
		comic.Add("floor_wakeup_1_talk1_0_0", new StringBuilder(YukiText.floor_wakeup_1_talk1_0_0));
		comic.Add("floor_wakeup_1_talk2_1_0", new StringBuilder(YukiText.floor_wakeup_1_talk2_1_0));
		comic.Add("floor_wakeup_1_talk3_2_0", new StringBuilder(YukiText.floor_wakeup_1_talk3_2_0));
		comic.Add("floor_wakeup_1_talk4_3_0", new StringBuilder(YukiText.floor_wakeup_1_talk4_3_0));
		comic.Add("floor_talk_2_talk1_0_0", new StringBuilder(YukiText.floor_talk_2_talk1_0_0));
		comic.Add("floor_talk_2_talk2_1_0", new StringBuilder(YukiText.floor_talk_2_talk2_1_0));
		comic.Add("floor_talk_2_talk3_2_0", new StringBuilder(YukiText.floor_talk_2_talk3_2_0));
		comic.Add("floor_talk_2_talk3_2_1", new StringBuilder(YukiText.floor_talk_2_talk3_2_1));
		comic.Add("floor_talk_2_talk4_3_0", new StringBuilder(YukiText.floor_talk_2_talk4_3_0));
		comic.Add("floor_talk_2_talk5_4_0", new StringBuilder(YukiText.floor_talk_2_talk5_4_0));
		comic.Add("floor2_floor_0_talk1_0_0", new StringBuilder(YukiText.floor2_floor_0_talk1_0_0));
		comic.Add("floor2_floor_0_talk2_1_0", new StringBuilder(YukiText.floor2_floor_0_talk2_1_0));
		comic.Add("floor2_floor_0_talk3_2_0", new StringBuilder(YukiText.floor2_floor_0_talk3_2_0));
		comic.Add("floor2_floor_0_talk3_2_1", new StringBuilder(YukiText.floor2_floor_0_talk3_2_1));
		comic.Add("floor2_floor_0_talk4_3_0", new StringBuilder(YukiText.floor2_floor_0_talk4_3_0));
		comic.Add("floor2_wakeup_1_talk1_0_0", new StringBuilder(YukiText.floor2_wakeup_1_talk1_0_0));
		comic.Add("floor2_wakeup_1_talk2_1_0", new StringBuilder(YukiText.floor2_wakeup_1_talk2_1_0));
		comic.Add("floor2_wakeup_1_talk3_2_0", new StringBuilder(YukiText.floor2_wakeup_1_talk3_2_0));
		comic.Add("floor2_wakeup_1_talk4_3_0", new StringBuilder(YukiText.floor2_wakeup_1_talk4_3_0));
		comic.Add("floor2_talk_2_talk1_0_0", new StringBuilder(YukiText.floor2_talk_2_talk1_0_0));
		comic.Add("floor2_talk_2_talk2_1_0", new StringBuilder(YukiText.floor2_talk_2_talk2_1_0));
		comic.Add("floor2_talk_2_talk3_2_0", new StringBuilder(YukiText.floor2_talk_2_talk3_2_0));
		comic.Add("floor2_talk_2_talk3_2_1", new StringBuilder(YukiText.floor2_talk_2_talk3_2_1));
		comic.Add("floor2_talk_2_talk4_3_0", new StringBuilder(YukiText.floor2_talk_2_talk4_3_0));
		comic.Add("floor2_talk_2_talk5_4_0", new StringBuilder(YukiText.floor2_talk_2_talk5_4_0));
		comic.Add("general_general_0_text1_0_0", new StringBuilder(YukiText.general_general_0_text1_0_0));
		comic.Add("general_general_0_text2_1_0", new StringBuilder(YukiText.general_general_0_text2_1_0));
		comic.Add("general_general_0_text2_1_1", new StringBuilder(YukiText.general_general_0_text2_1_1));
		comic.Add("general_general_0_text3_2_0", new StringBuilder(YukiText.general_general_0_text3_2_0));
		comic.Add("general_general_0_text3_2_1", new StringBuilder(YukiText.general_general_0_text3_2_1));
		comic.Add("general_general_0_text4_3_0", new StringBuilder(YukiText.general_general_0_text4_3_0));
		comic.Add("general_general_0_text5_4_0", new StringBuilder(YukiText.general_general_0_text5_4_0));
		comic.Add("general_general_0_text6_5_0", new StringBuilder(YukiText.general_general_0_text6_5_0));
		comic.Add("general_general_0_text7_6_0", new StringBuilder(YukiText.general_general_0_text7_6_0));
		comic.Add("generalkill_general_0_text1_0_0", new StringBuilder(YukiText.generalkill_general_0_text1_0_0));
		comic.Add("generalkill_general_0_text1_0_1", new StringBuilder(YukiText.generalkill_general_0_text1_0_1));
		comic.Add("generalkill_general_0_text2_1_0", new StringBuilder(YukiText.generalkill_general_0_text2_1_0));
		comic.Add("generalkill_general_0_text2_1_1", new StringBuilder(YukiText.generalkill_general_0_text2_1_1));
		comic.Add("generalkill_general_0_text3_2_0", new StringBuilder(YukiText.generalkill_general_0_text3_2_0));
		comic.Add("generalkill_general_0_text4_3_0", new StringBuilder(YukiText.generalkill_general_0_text4_3_0));
		comic.Add("generalkill_general_0_text5_4_0", new StringBuilder(YukiText.generalkill_general_0_text5_4_0));
		comic.Add("generalkill_general_0_text5_4_1", new StringBuilder(YukiText.generalkill_general_0_text5_4_1));
		comic.Add("generalkill_general_0_text6_5_0", new StringBuilder(YukiText.generalkill_general_0_text6_5_0));
		comic.Add("generalkill_general_0_text7_6_0", new StringBuilder(YukiText.generalkill_general_0_text7_6_0));
		comic.Add("generalkill_general_0_text7_6_1", new StringBuilder(YukiText.generalkill_general_0_text7_6_1));
		comic.Add("grate_grate_0_yuki1_0_0", new StringBuilder(YukiText.grate_grate_0_yuki1_0_0));
		comic.Add("grate_grate_0_yuki2_1_0", new StringBuilder(YukiText.grate_grate_0_yuki2_1_0));
		comic.Add("grate_grate_0_yuki2_1_1", new StringBuilder(YukiText.grate_grate_0_yuki2_1_1));
		comic.Add("grate_grate_0_yuki3_2_0", new StringBuilder(YukiText.grate_grate_0_yuki3_2_0));
		comic.Add("grate_grate_0_yuki4_3_0", new StringBuilder(YukiText.grate_grate_0_yuki4_3_0));
		comic.Add("grate_grate_0_yuki4_3_1", new StringBuilder(YukiText.grate_grate_0_yuki4_3_1));
		comic.Add("grate_grate_0_yuki5_4_0", new StringBuilder(YukiText.grate_grate_0_yuki5_4_0));
		comic.Add("intro_ship_0_yuki1_0_0", new StringBuilder(YukiText.intro_ship_0_yuki1_0_0));
		comic.Add("intro_ship_0_yuki2_1_0", new StringBuilder(YukiText.intro_ship_0_yuki2_1_0));
		comic.Add("intro_ship_0_yuki3_2_0", new StringBuilder(YukiText.intro_ship_0_yuki3_2_0));
		comic.Add("intro_ship_0_yuki4_3_0", new StringBuilder(YukiText.intro_ship_0_yuki4_3_0));
		comic.Add("intro_ship_0_yuki5_4_0", new StringBuilder(YukiText.intro_ship_0_yuki5_4_0));
		comic.Add("intro_ship_0_yuki6_5_0", new StringBuilder(YukiText.intro_ship_0_yuki6_5_0));
		comic.Add("intro_cell_1_died1_0_0", new StringBuilder(YukiText.intro_cell_1_died1_0_0));
		comic.Add("intro_cell_1_died1_0_1", new StringBuilder(YukiText.intro_cell_1_died1_0_1));
		comic.Add("intro_cell_1_died2_1_0", new StringBuilder(YukiText.intro_cell_1_died2_1_0));
		comic.Add("intro_cell_1_died3_2_0", new StringBuilder(YukiText.intro_cell_1_died3_2_0));
		comic.Add("intro_cell_1_died3_2_1", new StringBuilder(YukiText.intro_cell_1_died3_2_1));
		comic.Add("intro_cell_1_died4_3_0", new StringBuilder(YukiText.intro_cell_1_died4_3_0));
		comic.Add("intro_cell_1_died4_3_1", new StringBuilder(YukiText.intro_cell_1_died4_3_1));
		comic.Add("intro_prison2_2_prison1_0_0", new StringBuilder(YukiText.intro_prison2_2_prison1_0_0));
		comic.Add("intro_prison2_2_prison1_0_1", new StringBuilder(YukiText.intro_prison2_2_prison1_0_1));
		comic.Add("intro_prison2_2_prison2_1_0", new StringBuilder(YukiText.intro_prison2_2_prison2_1_0));
		comic.Add("intro_prison2_2_prison3_2_0", new StringBuilder(YukiText.intro_prison2_2_prison3_2_0));
		comic.Add("intro_prison2_2_prison4_3_0", new StringBuilder(YukiText.intro_prison2_2_prison4_3_0));
		comic.Add("intro_prison2_2_prison5_4_0", new StringBuilder(YukiText.intro_prison2_2_prison5_4_0));
		comic.Add("intro_prison2_2_prison6_5_0", new StringBuilder(YukiText.intro_prison2_2_prison6_5_0));
		comic.Add("intro_prison3_3_hi1_0_0", new StringBuilder(YukiText.intro_prison3_3_hi1_0_0));
		comic.Add("intro_prison3_3_hi2_1_0", new StringBuilder(YukiText.intro_prison3_3_hi2_1_0));
		comic.Add("intro_prison3_3_switch_2_0", new StringBuilder(YukiText.intro_prison3_3_switch_2_0));
		comic.Add("judge_judge_0_text1_0_0", new StringBuilder(YukiText.judge_judge_0_text1_0_0));
		comic.Add("judge_judge_0_text2_1_0", new StringBuilder(YukiText.judge_judge_0_text2_1_0));
		comic.Add("judge_judge_0_text3_2_0", new StringBuilder(YukiText.judge_judge_0_text3_2_0));
		comic.Add("judge_judge_0_text3_2_1", new StringBuilder(YukiText.judge_judge_0_text3_2_1));
		comic.Add("judge_judge_0_text4_3_0", new StringBuilder(YukiText.judge_judge_0_text4_3_0));
		comic.Add("judge_judge_0_text4_3_1", new StringBuilder(YukiText.judge_judge_0_text4_3_1));
		comic.Add("judge_judge_0_text5_4_0", new StringBuilder(YukiText.judge_judge_0_text5_4_0));
		comic.Add("judge_judge_0_text6_5_0", new StringBuilder(YukiText.judge_judge_0_text6_5_0));
		comic.Add("judgekill_judge_0_text1_0_0", new StringBuilder(YukiText.judgekill_judge_0_text1_0_0));
		comic.Add("judgekill_judge_0_text1_0_1", new StringBuilder(YukiText.judgekill_judge_0_text1_0_1));
		comic.Add("judgekill_judge_0_text2_1_0", new StringBuilder(YukiText.judgekill_judge_0_text2_1_0));
		comic.Add("judgekill_judge_0_text2_1_1", new StringBuilder(YukiText.judgekill_judge_0_text2_1_1));
		comic.Add("judgekill_judge_0_text3_2_0", new StringBuilder(YukiText.judgekill_judge_0_text3_2_0));
		comic.Add("judgekill_judge_0_text4_3_0", new StringBuilder(YukiText.judgekill_judge_0_text4_3_0));
		comic.Add("judgekill_judge_0_text5_4_0", new StringBuilder(YukiText.judgekill_judge_0_text5_4_0));
		comic.Add("judgekill_judge_0_text6_5_0", new StringBuilder(YukiText.judgekill_judge_0_text6_5_0));
		comic.Add("judgekill_judge_0_text7_6_0", new StringBuilder(YukiText.judgekill_judge_0_text7_6_0));
		comic.Add("judgerise_engie_0_text1_0_0", new StringBuilder(YukiText.judgerise_engie_0_text1_0_0));
		comic.Add("judgerise_engie_0_text2_1_0", new StringBuilder(YukiText.judgerise_engie_0_text2_1_0));
		comic.Add("judgerise_engie_0_text3_2_0", new StringBuilder(YukiText.judgerise_engie_0_text3_2_0));
		comic.Add("judgerise_engie_0_text4_3_0", new StringBuilder(YukiText.judgerise_engie_0_text4_3_0));
		comic.Add("judgerise_engie_0_text4_3_1", new StringBuilder(YukiText.judgerise_engie_0_text4_3_1));
		comic.Add("judgerise_engie_0_text5_4_0", new StringBuilder(YukiText.judgerise_engie_0_text5_4_0));
		comic.Add("judgerise_engie_0_text5_4_1", new StringBuilder(YukiText.judgerise_engie_0_text5_4_1));
		comic.Add("judgerise_engie_0_text6_5_0", new StringBuilder(YukiText.judgerise_engie_0_text6_5_0));
		comic.Add("judgerise_engie_0_text6_5_1", new StringBuilder(YukiText.judgerise_engie_0_text6_5_1));
		comic.Add("judgerise_engie_0_text7_6_0", new StringBuilder(YukiText.judgerise_engie_0_text7_6_0));
		comic.Add("mask_mask_0_text1_0_0", new StringBuilder(YukiText.mask_mask_0_text1_0_0));
		comic.Add("mask_mask_0_text1_0_1", new StringBuilder(YukiText.mask_mask_0_text1_0_1));
		comic.Add("mask_mask_0_text2_1_0", new StringBuilder(YukiText.mask_mask_0_text2_1_0));
		comic.Add("mask_mask_0_text2_1_1", new StringBuilder(YukiText.mask_mask_0_text2_1_1));
		comic.Add("mask_mask_0_text3_2_0", new StringBuilder(YukiText.mask_mask_0_text3_2_0));
		comic.Add("mask_mask_0_text4_3_0", new StringBuilder(YukiText.mask_mask_0_text4_3_0));
		comic.Add("mask_yuki_1_text1_0_0", new StringBuilder(YukiText.mask_yuki_1_text1_0_0));
		comic.Add("mask_yuki_1_text1_0_1", new StringBuilder(YukiText.mask_yuki_1_text1_0_1));
		comic.Add("mask_yuki_1_text2_1_0", new StringBuilder(YukiText.mask_yuki_1_text2_1_0));
		comic.Add("mask_yuki_1_text3_2_0", new StringBuilder(YukiText.mask_yuki_1_text3_2_0));
		comic.Add("mask_yuki_1_text3_2_1", new StringBuilder(YukiText.mask_yuki_1_text3_2_1));
		comic.Add("mask_yuki_1_text4_3_0", new StringBuilder(YukiText.mask_yuki_1_text4_3_0));
		comic.Add("mask_yuki_1_text5_4_0", new StringBuilder(YukiText.mask_yuki_1_text5_4_0));
		comic.Add("memory_memory_0_text1_0_0", new StringBuilder(YukiText.memory_memory_0_text1_0_0));
		comic.Add("memory_memory_0_text2_1_0", new StringBuilder(YukiText.memory_memory_0_text2_1_0));
		comic.Add("memory_memory_0_text3_2_0", new StringBuilder(YukiText.memory_memory_0_text3_2_0));
		comic.Add("memory_memory_0_text4_3_0", new StringBuilder(YukiText.memory_memory_0_text4_3_0));
		comic.Add("memory_memory_0_text5_4_0", new StringBuilder(YukiText.memory_memory_0_text5_4_0));
		comic.Add("memory_memory_0_text5_4_1", new StringBuilder(YukiText.memory_memory_0_text5_4_1));
		comic.Add("memory_memory_0_text6_5_0", new StringBuilder(YukiText.memory_memory_0_text6_5_0));
		comic.Add("memory_memory_0_text7_6_0", new StringBuilder(YukiText.memory_memory_0_text7_6_0));
		comic.Add("memory_memory_0_text8_7_0", new StringBuilder(YukiText.memory_memory_0_text8_7_0));
		comic.Add("memory_memory_0_text9_8_0", new StringBuilder(YukiText.memory_memory_0_text9_8_0));
		comic.Add("prisonend_yuki_0_talk1_0_0", new StringBuilder(YukiText.prisonend_yuki_0_talk1_0_0));
		comic.Add("prisonend_yuki_0_talk2_1_0", new StringBuilder(YukiText.prisonend_yuki_0_talk2_1_0));
		comic.Add("prisonend_yuki_0_talk3_2_0", new StringBuilder(YukiText.prisonend_yuki_0_talk3_2_0));
		comic.Add("prisonend_yuki_0_talk3_2_1", new StringBuilder(YukiText.prisonend_yuki_0_talk3_2_1));
		comic.Add("prisonend_yuki_0_talk4_3_0", new StringBuilder(YukiText.prisonend_yuki_0_talk4_3_0));
		comic.Add("prisonend_yuki2_2_yuki1_0_0", new StringBuilder(YukiText.prisonend_yuki2_2_yuki1_0_0));
		comic.Add("prisonend_yuki2_2_yuki2_1_0", new StringBuilder(YukiText.prisonend_yuki2_2_yuki2_1_0));
		comic.Add("raven_raven_0_text1_0_0", new StringBuilder(YukiText.raven_raven_0_text1_0_0));
		comic.Add("raven_raven_0_text2_1_0", new StringBuilder(YukiText.raven_raven_0_text2_1_0));
		comic.Add("raven_raven_0_text3_2_0", new StringBuilder(YukiText.raven_raven_0_text3_2_0));
		comic.Add("raven_raven_0_text4_3_0", new StringBuilder(YukiText.raven_raven_0_text4_3_0));
		comic.Add("raven_raven_0_text5_4_0", new StringBuilder(YukiText.raven_raven_0_text5_4_0));
		comic.Add("raven_raven_0_text6_5_0", new StringBuilder(YukiText.raven_raven_0_text6_5_0));
		comic.Add("raven_raven_0_text7_6_0", new StringBuilder(YukiText.raven_raven_0_text7_6_0));
		comic.Add("raven_raven_0_text8_7_0", new StringBuilder(YukiText.raven_raven_0_text8_7_0));
		comic.Add("raven_yuki_1_text1_0_0", new StringBuilder(YukiText.raven_yuki_1_text1_0_0));
		comic.Add("raven_yuki_1_text2_1_0", new StringBuilder(YukiText.raven_yuki_1_text2_1_0));
		comic.Add("raven_yuki_1_text3_2_0", new StringBuilder(YukiText.raven_yuki_1_text3_2_0));
		comic.Add("raven_yuki_1_text4_3_0", new StringBuilder(YukiText.raven_yuki_1_text4_3_0));
		comic.Add("sin_sin_0_text1_0_0", new StringBuilder(YukiText.sin_sin_0_text1_0_0));
		comic.Add("sin_sin_0_text1_0_1", new StringBuilder(YukiText.sin_sin_0_text1_0_1));
		comic.Add("sin_sin_0_text2_1_0", new StringBuilder(YukiText.sin_sin_0_text2_1_0));
		comic.Add("sin_sin_0_text3_2_0", new StringBuilder(YukiText.sin_sin_0_text3_2_0));
		comic.Add("sin_sin_0_text3_2_1", new StringBuilder(YukiText.sin_sin_0_text3_2_1));
		comic.Add("sin_sin_0_text4_3_0", new StringBuilder(YukiText.sin_sin_0_text4_3_0));
		comic.Add("sin_sin_0_text5_4_0", new StringBuilder(YukiText.sin_sin_0_text5_4_0));
		comic.Add("sin_sin_0_text5_4_1", new StringBuilder(YukiText.sin_sin_0_text5_4_1));
		comic.Add("sin_sin_0_text6_5_0", new StringBuilder(YukiText.sin_sin_0_text6_5_0));
		comic.Add("sin_sin_0_text7_6_0", new StringBuilder(YukiText.sin_sin_0_text7_6_0));
		comic.Add("slava_hurt_slava_0_text1_0_0", new StringBuilder(YukiText.slava_hurt_slava_0_text1_0_0));
		comic.Add("slava_hurt_slava_0_text2_1_0", new StringBuilder(YukiText.slava_hurt_slava_0_text2_1_0));
		comic.Add("slava_hurt_slava_0_text3_2_0", new StringBuilder(YukiText.slava_hurt_slava_0_text3_2_0));
		comic.Add("slava_hurt_slava_0_text3_2_1", new StringBuilder(YukiText.slava_hurt_slava_0_text3_2_1));
		comic.Add("slava_hurt_slava_0_text4_3_0", new StringBuilder(YukiText.slava_hurt_slava_0_text4_3_0));
		comic.Add("slava_hurt_slava_0_text5_4_0", new StringBuilder(YukiText.slava_hurt_slava_0_text5_4_0));
		comic.Add("slava_hurt_slava_0_text6_5_0", new StringBuilder(YukiText.slava_hurt_slava_0_text6_5_0));
		comic.Add("slava_kill_slava_0_text1_0_0", new StringBuilder(YukiText.slava_kill_slava_0_text1_0_0));
		comic.Add("slava_kill_slava_0_text2_1_0", new StringBuilder(YukiText.slava_kill_slava_0_text2_1_0));
		comic.Add("slava_kill_slava_0_text2_1_1", new StringBuilder(YukiText.slava_kill_slava_0_text2_1_1));
		comic.Add("slava_kill_slava_0_text3_2_0", new StringBuilder(YukiText.slava_kill_slava_0_text3_2_0));
		comic.Add("slava_kill_slava_0_text4_3_0", new StringBuilder(YukiText.slava_kill_slava_0_text4_3_0));
		comic.Add("slava_kill_slava_0_text4_3_1", new StringBuilder(YukiText.slava_kill_slava_0_text4_3_1));
		comic.Add("start_1_0_text_0_0", new StringBuilder(YukiText.start_1_0_text_0_0));
		comic.Add("timebridge_1_0_text1_0_0", new StringBuilder(YukiText.timebridge_1_0_text1_0_0));
		comic.Add("timebridge_church_1_text1_0_0", new StringBuilder(YukiText.timebridge_church_1_text1_0_0));
		comic.Add("timebridge_church_1_text2_1_0", new StringBuilder(YukiText.timebridge_church_1_text2_1_0));
		comic.Add("timebridge_church_1_text3_2_0", new StringBuilder(YukiText.timebridge_church_1_text3_2_0));
		comic.Add("timebridge_2_2_text1_0_0", new StringBuilder(YukiText.timebridge_2_2_text1_0_0));
		comic.Add("timebridge_board_3_text1_0_0", new StringBuilder(YukiText.timebridge_board_3_text1_0_0));
		comic.Add("timebridge_board_3_text2_1_0", new StringBuilder(YukiText.timebridge_board_3_text2_1_0));
		comic.Add("timebridge_board_3_text3_2_0", new StringBuilder(YukiText.timebridge_board_3_text3_2_0));
		comic.Add("timebridge_board_3_text3_2_1", new StringBuilder(YukiText.timebridge_board_3_text3_2_1));
		comic.Add("timebridge_board_3_text4_3_0", new StringBuilder(YukiText.timebridge_board_3_text4_3_0));
		comic.Add("timebridge_3_4_text1_0_0", new StringBuilder(YukiText.timebridge_3_4_text1_0_0));
		comic.Add("timebridge_3_4_text1_0_1", new StringBuilder(YukiText.timebridge_3_4_text1_0_1));
		comic.Add("timebridge_3_4_text2_1_0", new StringBuilder(YukiText.timebridge_3_4_text2_1_0));
		comic.Add("timebridge_news_5_text1_0_0", new StringBuilder(YukiText.timebridge_news_5_text1_0_0));
		comic.Add("timebridge_news_5_text2_1_0", new StringBuilder(YukiText.timebridge_news_5_text2_1_0));
		comic.Add("timebridge_news_5_text3_2_0", new StringBuilder(YukiText.timebridge_news_5_text3_2_0));
		comic.Add("timebridge_news_5_text4_3_0", new StringBuilder(YukiText.timebridge_news_5_text4_3_0));
		comic.Add("timebridge_news_5_text5_4_0", new StringBuilder(YukiText.timebridge_news_5_text5_4_0));
		comic.Add("timebridge_4_6_text1_0_0", new StringBuilder(YukiText.timebridge_4_6_text1_0_0));
		comic.Add("timebridge_prison_7_text1_0_0", new StringBuilder(YukiText.timebridge_prison_7_text1_0_0));
		comic.Add("timebridge_prison_7_text2_1_0", new StringBuilder(YukiText.timebridge_prison_7_text2_1_0));
		comic.Add("timebridge_prison_7_text3_2_0", new StringBuilder(YukiText.timebridge_prison_7_text3_2_0));
		comic.Add("timebridge_prison_7_text4_3_0", new StringBuilder(YukiText.timebridge_prison_7_text4_3_0));
		comic.Add("timebridge_prison_7_text5_4_0", new StringBuilder(YukiText.timebridge_prison_7_text5_4_0));
		comic.Add("timebridge_5_8_text1_0_0", new StringBuilder(YukiText.timebridge_5_8_text1_0_0));
		comic.Add("timebridge_5_8_text2_1_0", new StringBuilder(YukiText.timebridge_5_8_text2_1_0));
		comic.Add("timebridge_in_9_text1_0_0", new StringBuilder(YukiText.timebridge_in_9_text1_0_0));
		comic.Add("timebridge_in_9_text2_1_0", new StringBuilder(YukiText.timebridge_in_9_text2_1_0));
		comic.Add("yuki_aqua_yuki_0_text_0_0", new StringBuilder(YukiText.yuki_aqua_yuki_0_text_0_0));
		comic.Add("yuki_aqua_yuki_0_text_1_0", new StringBuilder(YukiText.yuki_aqua_yuki_0_text_1_0));
		comic.Add("yuki_aqua_yuki_0_text_2_0", new StringBuilder(YukiText.yuki_aqua_yuki_0_text_2_0));
		comic.Add("yuki_aqua_yuki_0_text_2_1", new StringBuilder(YukiText.yuki_aqua_yuki_0_text_2_1));
		comic.Add("yuki_aqua_yuki_0_text_3_0", new StringBuilder(YukiText.yuki_aqua_yuki_0_text_3_0));
		comic.Add("yuki_aqua_yuki_0_text_4_0", new StringBuilder(YukiText.yuki_aqua_yuki_0_text_4_0));
		comic.Add("yuki_cafe_yuki_0_text1_0_0", new StringBuilder(YukiText.yuki_cafe_yuki_0_text1_0_0));
		comic.Add("yuki_cafe_yuki_0_text2_1_0", new StringBuilder(YukiText.yuki_cafe_yuki_0_text2_1_0));
		comic.Add("yuki_cafe_yuki_0_text3_2_0", new StringBuilder(YukiText.yuki_cafe_yuki_0_text3_2_0));
		comic.Add("yuki_cafe_yuki_0_text4_3_0", new StringBuilder(YukiText.yuki_cafe_yuki_0_text4_3_0));
		comic.Add("yuki_cafe_yuki_0_text5_4_0", new StringBuilder(YukiText.yuki_cafe_yuki_0_text5_4_0));
		comic.Add("yuki_closet_yuki_0_text1_0_0", new StringBuilder(YukiText.yuki_closet_yuki_0_text1_0_0));
		comic.Add("yuki_closet_yuki_0_text2_1_0", new StringBuilder(YukiText.yuki_closet_yuki_0_text2_1_0));
		comic.Add("yuki_closet_yuki_0_text2_1_1", new StringBuilder(YukiText.yuki_closet_yuki_0_text2_1_1));
		comic.Add("yuki_closet_yuki_0_text3_2_0", new StringBuilder(YukiText.yuki_closet_yuki_0_text3_2_0));
		comic.Add("yuki_closet_yuki_0_text3_2_1", new StringBuilder(YukiText.yuki_closet_yuki_0_text3_2_1));
		comic.Add("yuki_closet_yuki_0_text4_3_0", new StringBuilder(YukiText.yuki_closet_yuki_0_text4_3_0));
		comic.Add("yuki_crypt_yuki_0_text1_0_0", new StringBuilder(YukiText.yuki_crypt_yuki_0_text1_0_0));
		comic.Add("yuki_crypt_yuki_0_text2_1_0", new StringBuilder(YukiText.yuki_crypt_yuki_0_text2_1_0));
		comic.Add("yuki_crypt_yuki_0_text2_1_1", new StringBuilder(YukiText.yuki_crypt_yuki_0_text2_1_1));
		comic.Add("yuki_crypt_yuki_0_text3_2_0", new StringBuilder(YukiText.yuki_crypt_yuki_0_text3_2_0));
		comic.Add("yuki_crypt_yuki_0_text4_3_0", new StringBuilder(YukiText.yuki_crypt_yuki_0_text4_3_0));
		comic.Add("yuki_crypt_yuki_0_text5_4_0", new StringBuilder(YukiText.yuki_crypt_yuki_0_text5_4_0));
		comic.Add("yuki_crypt_yuki_0_text6_5_0", new StringBuilder(YukiText.yuki_crypt_yuki_0_text6_5_0));
		comic.Add("yuki_crypt_yuki_0_text6_5_1", new StringBuilder(YukiText.yuki_crypt_yuki_0_text6_5_1));
		comic.Add("yuki_gross_gross_0_text1_0_0", new StringBuilder(YukiText.yuki_gross_gross_0_text1_0_0));
		comic.Add("yuki_gross_gross_0_text2_1_0", new StringBuilder(YukiText.yuki_gross_gross_0_text2_1_0));
		comic.Add("yuki_gross_gross_0_text2_1_1", new StringBuilder(YukiText.yuki_gross_gross_0_text2_1_1));
		comic.Add("yuki_gross_gross_0_text3_2_0", new StringBuilder(YukiText.yuki_gross_gross_0_text3_2_0));
		comic.Add("yuki_gross_gross_0_text4_3_0", new StringBuilder(YukiText.yuki_gross_gross_0_text4_3_0));
		comic.Add("yuki_gross_gross_0_text5_4_0", new StringBuilder(YukiText.yuki_gross_gross_0_text5_4_0));
		comic.Add("yuki_gross_gross_0_text6_5_0", new StringBuilder(YukiText.yuki_gross_gross_0_text6_5_0));
		comic.Add("yuki_gross_gross_0_text7_6_0", new StringBuilder(YukiText.yuki_gross_gross_0_text7_6_0));
		comic.Add("yuki_gross_gross_0_text8_7_0", new StringBuilder(YukiText.yuki_gross_gross_0_text8_7_0));
		comic.Add("yuki_gross_gross_0_text9_8_0", new StringBuilder(YukiText.yuki_gross_gross_0_text9_8_0));
		comic.Add("yuki_ohno_dish_0_text1_0_0", new StringBuilder(YukiText.yuki_ohno_dish_0_text1_0_0));
		comic.Add("yuki_ohno_dish_0_text2_1_0", new StringBuilder(YukiText.yuki_ohno_dish_0_text2_1_0));
		comic.Add("yuki_ohno_dish_0_text2_1_1", new StringBuilder(YukiText.yuki_ohno_dish_0_text2_1_1));
		comic.Add("yuki_ohno_dish_0_text3_2_0", new StringBuilder(YukiText.yuki_ohno_dish_0_text3_2_0));
		comic.Add("yuki_ohno_dish_0_text3_2_1", new StringBuilder(YukiText.yuki_ohno_dish_0_text3_2_1));
		comic.Add("yuki_ohno_yuki_1_text1_0_0", new StringBuilder(YukiText.yuki_ohno_yuki_1_text1_0_0));
		comic.Add("yuki_ohno_yuki_1_text2_1_0", new StringBuilder(YukiText.yuki_ohno_yuki_1_text2_1_0));
		comic.Add("yuki_ohno_yuki_1_text3_2_0", new StringBuilder(YukiText.yuki_ohno_yuki_1_text3_2_0));
		comic.Add("yuki_ohno_yuki_1_text3_2_1", new StringBuilder(YukiText.yuki_ohno_yuki_1_text3_2_1));
		comic.Add("yuki_ohno_dish_2_text1_0_0", new StringBuilder(YukiText.yuki_ohno_dish_2_text1_0_0));
		comic.Add("yuki_ohno_dish_2_text1_0_1", new StringBuilder(YukiText.yuki_ohno_dish_2_text1_0_1));
		comic.Add("yuki_ohno_dish_2_text2_1_0", new StringBuilder(YukiText.yuki_ohno_dish_2_text2_1_0));
		comic.Add("yuki_ohno_dish_2_text2_1_1", new StringBuilder(YukiText.yuki_ohno_dish_2_text2_1_1));
		comic.Add("yuki_ohno_dish_2_text2_1_2", new StringBuilder(YukiText.yuki_ohno_dish_2_text2_1_2));
		comic.Add("yuki_ohno_dish_2_text3_2_0", new StringBuilder(YukiText.yuki_ohno_dish_2_text3_2_0));
		comic.Add("yuki_ohno_dish_2_text3_2_1", new StringBuilder(YukiText.yuki_ohno_dish_2_text3_2_1));
		comic.Add("yuki_prison_hockey_0_text_0_0", new StringBuilder(YukiText.yuki_prison_hockey_0_text_0_0));
		comic.Add("yuki_prison_hockey_0_text_1_0", new StringBuilder(YukiText.yuki_prison_hockey_0_text_1_0));
		comic.Add("yuki_prison_hockey_0_text_2_0", new StringBuilder(YukiText.yuki_prison_hockey_0_text_2_0));
		comic.Add("yuki_prison_hockey_0_text_3_0", new StringBuilder(YukiText.yuki_prison_hockey_0_text_3_0));
		comic.Add("yuki_prison_hockey_0_text_3_1", new StringBuilder(YukiText.yuki_prison_hockey_0_text_3_1));
		comic.Add("yuki_prison_hockey_0_text_4_0", new StringBuilder(YukiText.yuki_prison_hockey_0_text_4_0));
		comic.Add("yuki_prison_hockey_0_text_5_0", new StringBuilder(YukiText.yuki_prison_hockey_0_text_5_0));
		comic.Add("yuki_prison_prison_1_text1_0_0", new StringBuilder(YukiText.yuki_prison_prison_1_text1_0_0));
		comic.Add("yuki_prison_prison_1_text2_1_0", new StringBuilder(YukiText.yuki_prison_prison_1_text2_1_0));
		comic.Add("yuki_prison_prison_1_text3_2_0", new StringBuilder(YukiText.yuki_prison_prison_1_text3_2_0));
		comic.Add("yuki_prison_prison_1_text4_3_0", new StringBuilder(YukiText.yuki_prison_prison_1_text4_3_0));
		comic.Add("yuki_prison_prison_1_text5_4_0", new StringBuilder(YukiText.yuki_prison_prison_1_text5_4_0));
		comic.Add("yuki_prison_prison_1_text6_5_0", new StringBuilder(YukiText.yuki_prison_prison_1_text6_5_0));
		comic.Add("yuki_prison_prison_1_text6_5_1", new StringBuilder(YukiText.yuki_prison_prison_1_text6_5_1));
		comic.Add("yuki_prison_prison_1_text7_6_0", new StringBuilder(YukiText.yuki_prison_prison_1_text7_6_0));
		comic.Add("yuki_prison_prison_1_text7_6_1", new StringBuilder(YukiText.yuki_prison_prison_1_text7_6_1));
		comic.Add("yuki_prison_prison_1_text8_7_0", new StringBuilder(YukiText.yuki_prison_prison_1_text8_7_0));
		comic.Add("yuki_prison_prison_1_text8_7_1", new StringBuilder(YukiText.yuki_prison_prison_1_text8_7_1));
		comic.Add("yuki_prison_prison_1_text9_8_0", new StringBuilder(YukiText.yuki_prison_prison_1_text9_8_0));
		comic.Add("yuki_prison_prison_1_text9_8_1", new StringBuilder(YukiText.yuki_prison_prison_1_text9_8_1));
		comic.Add("yuki_puppets_puppet_0_text1_0_0", new StringBuilder(YukiText.yuki_puppets_puppet_0_text1_0_0));
		comic.Add("yuki_puppets_puppet_0_text2_1_0", new StringBuilder(YukiText.yuki_puppets_puppet_0_text2_1_0));
		comic.Add("yuki_puppets_puppet_0_text3_2_0", new StringBuilder(YukiText.yuki_puppets_puppet_0_text3_2_0));
		comic.Add("yuki_puppets_puppet_0_text4_3_0", new StringBuilder(YukiText.yuki_puppets_puppet_0_text4_3_0));
		comic.Add("yuki_rgb_dish_0_text1_0_0", new StringBuilder(YukiText.yuki_rgb_dish_0_text1_0_0));
		comic.Add("yuki_rgb_dish_0_text2_1_0", new StringBuilder(YukiText.yuki_rgb_dish_0_text2_1_0));
		comic.Add("yuki_rgb_dish_0_text3_2_0", new StringBuilder(YukiText.yuki_rgb_dish_0_text3_2_0));
		comic.Add("yuki_rgb_dish_0_text4_3_0", new StringBuilder(YukiText.yuki_rgb_dish_0_text4_3_0));
		comic.Add("yuki_rgb_dish_0_text5_4_0", new StringBuilder(YukiText.yuki_rgb_dish_0_text5_4_0));
		comic.Add("yuki_rgb_dish_0_text5_4_1", new StringBuilder(YukiText.yuki_rgb_dish_0_text5_4_1));
		comic.Add("yuki_window_yukiwindow_0_text_1_0", new StringBuilder(YukiText.yuki_window_yukiwindow_0_text_1_0));
		comic.Add("yuki_window_yukiwindow_0_text_2_0", new StringBuilder(YukiText.yuki_window_yukiwindow_0_text_2_0));
		comic.Add("yuki_window_yukiwindow_0_text_3_0", new StringBuilder(YukiText.yuki_window_yukiwindow_0_text_3_0));
		comic.Add("yuki_window_yukiwindow_0_text_4_0", new StringBuilder(YukiText.yuki_window_yukiwindow_0_text_4_0));
		comic.Add("zap_zap_0_box1_2_0", new StringBuilder(YukiText.zap_zap_0_box1_2_0));
		comic.Add("zap_zap_0_box2_3_0", new StringBuilder(YukiText.zap_zap_0_box2_3_0));
		comic.Add("zap_zap_0_box3_4_0", new StringBuilder(YukiText.zap_zap_0_box3_4_0));
		comic.Add("zap_zap_0_box4_5_0", new StringBuilder(YukiText.zap_zap_0_box4_5_0));
	}
}
