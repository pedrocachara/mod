using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using SceneEdit.scene;
using Yuki_Win.achievements.cheevos;
using Yuki_Win.audio;
using Yuki_Win.debug;
using Yuki_Win.director;
using Yuki_Win.gameRender;
using Yuki_Win.hud;
using Yuki_Win.player;

namespace Yuki_Win;

public class SceneMgr
{
	public Dictionary<string, Texture2D> texture;

	public Video video;

	public int curScene;

	public int selLayer;

	public int selBubble;

	public int selKeyframe;

	public string path;

	public RenderTarget2D comicTarg;

	public RenderTarget2D maskTarg;

	public Effect comicEffect;

	public Effect creepEffect;

	public Effect creepTVEffect;

	public AddMgr addMgr;

	public bool playing;

	public bool overlay;

	public bool flicker;

	public bool spazz;

	public bool endLevel;

	public bool strobe;

	public bool creep;

	public bool smoothcam;

	public bool needsCrazyTrans;

	public bool miniAdjust;

	public float loaderFrame;

	public int speedTilNext;

	public float transInFrame;

	public EffectPass pass;

	private ContentManager Content;

	private bool hasMask;

	private Vector4 offset;

	private float offsetFrame;

	public bool reading;

	private string[][][] bubbleKey;

	private float closest;

	public SceneMgr(ContentManager Content)
	{
		video = new Video();
		texture = new Dictionary<string, Texture2D>();
		this.Content = Content;
	}

	public void Play(string s)
	{
		Read(s);
		playing = true;
		overlay = false;
		curScene = 0;
		video.time = 0f;
	}

	public void TransPlay(string s)
	{
		Play(s);
		overlay = true;
		transInFrame = 1f;
	}

	public void Stop()
	{
		playing = false;
	}

	public void Update()
	{
		Update(1f);
	}

	public void Update(float alpha)
	{
		if (reading)
		{
			loaderFrame += FMan.frameTime;
			if (transInFrame > 0f)
			{
				transInFrame -= FMan.realTime;
				if (transInFrame <= 0f)
				{
					overlay = false;
				}
			}
		}
		else
		{
			if (curScene >= video.scenes.Count)
			{
				return;
			}
			float time = video.time;
			offsetFrame -= FMan.realTime;
			if (offsetFrame <= 0f)
			{
				offsetFrame = Rand.GetRandomFloat(0.2f, 0.5f);
				offset = Rand.GetRandomVec4(-20f, 20f, -20f, 20f, -0.01f, 0.01f, -0.3f, 0.3f);
			}
			if (GameState.state == GameState.State.Menu && curScene == 1)
			{
				float time2 = video.time;
				video.time = (float)Game1.menuMgr.sceneLoc * 2f;
				SceneCam.Update(video, video.scenes[curScene], smoothcam, FMan.realTime, 0.03f, offset);
				video.time = time2;
			}
			else
			{
				if (GameState.state == GameState.State.Credits && video.time < 0.1f)
				{
					smoothcam = false;
				}
				SceneCam.Update(video, video.scenes[curScene], smoothcam, FMan.realTime);
			}
			SceneMaster.Update(video, video.scenes[curScene]);
			video.scenes[curScene].r *= alpha;
			video.scenes[curScene].g *= alpha;
			video.scenes[curScene].b *= alpha;
			if (transInFrame > 0f)
			{
				transInFrame -= FMan.realTime;
				if (transInFrame <= 0f)
				{
					overlay = false;
				}
				return;
			}
			video.time += FMan.realTime;
			if (speedTilNext > 0)
			{
				video.time += FMan.frameTime * 15f;
				Scene scene = video.scenes[curScene];
				for (int i = 0; i < scene.bubble.Count; i++)
				{
					Bubble bubble = scene.bubble[i];
					switch (bubble.type)
					{
					case Bubble.BubbleType.Box:
					case Bubble.BubbleType.LBubble:
					case Bubble.BubbleType.RBubble:
					case Bubble.BubbleType.LExclaim:
					case Bubble.BubbleType.RExclaim:
					case Bubble.BubbleType.Oval:
						if (time < bubble.time && video.time >= bubble.time)
						{
							speedTilNext--;
						}
						break;
					}
				}
			}
			for (int j = 0; j < Game1.GetPlayers(); j++)
			{
				if (Game1.mainPlayer[j] > -1 && GameState.state == GameState.State.Playing && flibitPort.GetInputClicked(Game1.mainPlayer[j], flibitPort.InputAction.JumpAccept) && video.time > 0.5f && video.time < video.scenes[curScene].duration - 0.5f)
				{
					SceneClick(netInduced: false);
				}
			}
			if (!(video.time > video.scenes[curScene].duration))
			{
				return;
			}
			if (endLevel)
			{
				endLevel = false;
				video.time = video.scenes[curScene].duration;
				Game1.hud.EndLevel();
				return;
			}
			video.time = 0f;
			speedTilNext = 0;
			if (GameState.state != GameState.State.Menu)
			{
				if (GameState.state == GameState.State.Credits)
				{
					for (int k = 0; k < Game1.GetPlayers(); k++)
					{
						if (Game1.beadMgr.beads[k].HasBead(InvCatalog.InvItemName.AchievablesBead))
						{
							GetAllAchievables getAllAchievables = (GetAllAchievables)Game1.achievementMgr.playerAchievements[k].achievementList[5];
							if (!getAllAchievables.watchCredits)
							{
								getAllAchievables.watchCredits = true;
								getAllAchievables.Unlock(overRide: false);
							}
						}
					}
					Game1.credits.EndIt();
				}
				else if (GameState.state == GameState.State.Upsell)
				{
					GameState.state = GameState.State.Menu;
					Game1.menuMgr.MenuReset();
				}
				else
				{
					curScene++;
				}
			}
			if (curScene < video.scenes.Count)
			{
				return;
			}
			if (GameState.state == GameState.State.Menu)
			{
				curScene = 0;
				return;
			}
			playing = false;
			if (!overlay)
			{
				Game1.transMgr.levelInFrame = 1f;
				if (needsCrazyTrans)
				{
					Game1.transMgr.levelInFrame = 0f;
					QuakeManager.SetBright(1f);
					Sound.PlaySnd(Sound.Category.FX, "lieend");
				}
			}
		}
	}

	public void SceneClick(bool netInduced)
	{
		if (!Game1.netSession.IsClient() || netInduced)
		{
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.SendSceneClick(Game1.netSession.session);
			}
			speedTilNext++;
			Sound.PlaySnd(Sound.Category.FX, "swing");
		}
	}

	private void DrawLayers(bool mask, SpriteBatch sprite, Scene scene, float xAdd)
	{
		if (!mask)
		{
			closest = 0f;
		}
		foreach (Layer item in scene.layer)
		{
			if (item.keyframe.Count <= 0)
			{
				continue;
			}
			switch (item.name)
			{
			case "cam":
			case "master":
				continue;
			}
			if ((!mask || !(item.name == "mask")) && (mask || !(item.name != "mask")))
			{
				continue;
			}
			if (mask)
			{
				hasMask = true;
			}
			int num = 0;
			float num2 = 0f;
			for (int i = 0; i < item.keyframe.Count; i++)
			{
				Keyframe keyframe = item.keyframe[i];
				if (keyframe.time <= video.time && keyframe.time > num2)
				{
					num = i;
					num2 = keyframe.time;
				}
			}
			Keyframe keyframe2 = item.keyframe[num];
			if (keyframe2.texture == null)
			{
				continue;
			}
			Vector3 loc = keyframe2.loc;
			if (mask)
			{
				loc.Z = 0.1f;
				if (miniAdjust)
				{
					loc.Z = 0.01f;
				}
			}
			Vector2 vector = keyframe2.scale;
			float num3 = keyframe2.r;
			float num4 = keyframe2.g;
			float num5 = keyframe2.b;
			float num6 = keyframe2.a;
			float num7 = keyframe2.angle;
			if (keyframe2.tween && num < item.keyframe.Count - 1)
			{
				Keyframe keyframe3 = item.keyframe[num + 1];
				Vector3 loc2 = keyframe3.loc;
				if (mask)
				{
					loc2.Z = 0.1f;
				}
				float num8 = (video.time - keyframe2.time) / (keyframe3.time - keyframe2.time);
				loc += (loc2 - loc) * num8;
				vector = keyframe2.scale + (keyframe3.scale - keyframe2.scale) * num8;
				num3 = keyframe2.r + (keyframe3.r - keyframe2.r) * num8;
				num4 = keyframe2.g + (keyframe3.g - keyframe2.g) * num8;
				num5 = keyframe2.b + (keyframe3.b - keyframe2.b) * num8;
				num6 = keyframe2.a + (keyframe3.a - keyframe2.a) * num8;
				num7 = keyframe2.angle + (keyframe3.angle - keyframe2.angle) * num8;
			}
			num3 *= scene.r;
			num4 *= scene.g;
			num5 *= scene.b;
			if (item.name.Length > 4)
			{
				try
				{
					if (item.name.Substring(0, 4) == "rot-")
					{
						loc.X += (float)Math.Cos(video.time * 3.14f + keyframe2.loc.X * 1.2f + keyframe2.loc.Y + keyframe2.loc.Z) * 20f;
						loc.Y += (float)Math.Sin(video.time * 3.14f + keyframe2.loc.X * 1.2f + keyframe2.loc.Y + keyframe2.loc.Z) * 20f;
					}
				}
				catch
				{
				}
			}
			Vector2 screenLoc = SceneCam.GetScreenLoc(loc);
			Vector2 vector2 = screenLoc - ScrollManager.screenSize / 2f;
			float num9 = ScrollManager.screenSize.X / 1280f;
			vector2 *= num9;
			vector *= num9;
			num7 += SceneCam.rotation;
			screenLoc = ScrollManager.screenSize / 2f + new Vector2((float)Math.Cos(SceneCam.rotation) * vector2.X, (float)Math.Sin(SceneCam.rotation) * vector2.X) + new Vector2((float)Math.Cos(SceneCam.rotation + 1.57f) * vector2.Y, (float)Math.Sin(SceneCam.rotation + 1.57f) * vector2.Y);
			vector *= loc.Z;
			try
			{
				if (flicker)
				{
					float randomFloat = Rand.GetRandomFloat(0.5f, 1f);
					num3 *= randomFloat;
					num4 *= randomFloat;
					num5 *= randomFloat;
				}
				if (spazz)
				{
					screenLoc += Rand.GetRandomVec2(-10f, 10f, -10f, 10f);
				}
				if (item.name == "zap")
				{
					screenLoc += Rand.GetRandomVec2(-10f, 10f, -10f, 10f);
					num7 += Rand.GetRandomFloat(0f, 6.28f);
				}
				if (mask && miniAdjust)
				{
					vector *= 1f + SceneCam.location.Z * 0.02f;
					num7 *= 0.3f;
				}
				else
				{
					vector *= SceneCam.location.Z;
				}
				if (!mask && loc.Z > closest)
				{
					closest = loc.Z;
				}
				if (!video.playing && scene.name != video.scenes[curScene].name)
				{
					num6 /= 10f;
				}
				screenLoc.X += xAdd;
				sprite.Draw(texture[keyframe2.texture], screenLoc, new Rectangle(0, 0, texture[keyframe2.texture].Width, texture[keyframe2.texture].Height), new Color(num3, num4, num5, num6), num7, new Vector2((float)texture[keyframe2.texture].Width / 2f, (float)texture[keyframe2.texture].Height / 2f), (vector.X < 0f) ? new Vector2(0f - vector.X, vector.Y) : vector, (vector.X < 0f) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
			}
			catch (Exception ex)
			{
				Printf.WriteLine(ex.ToString());
			}
		}
	}

	private void DrawBubbles(SpriteBatch sprite, Scene scene)
	{
		if (DebugManager.videoRecordMode)
		{
			return;
		}
		for (int i = 0; i < scene.bubble.Count; i++)
		{
			Bubble bubble = scene.bubble[i];
			switch (bubble.type)
			{
			case Bubble.BubbleType.Box:
			case Bubble.BubbleType.LBubble:
			case Bubble.BubbleType.RBubble:
			case Bubble.BubbleType.LExclaim:
			case Bubble.BubbleType.RExclaim:
			case Bubble.BubbleType.Oval:
			{
				if (bubble.text == null || !(bubble.time - 0.1f < video.time) || (!(bubble.timeOff + 0.1f > video.time) && !(bubble.timeOff <= 0f)))
				{
					break;
				}
				float num = 1f;
				if (video.time < bubble.time)
				{
					num = 1f - (bubble.time - video.time) * 10f;
				}
				if (bubble.timeOff > 0f && video.time > bubble.timeOff)
				{
					num = 1f - (video.time - bubble.timeOff) * 10f;
				}
				Vector2 origin = default;
				Vector2 vector = default;
				Rectangle value = default;
				int num2 = 0;
				bool flag = false;
				switch (bubble.type)
				{
				case Bubble.BubbleType.Box:
					num2 = 1;
					origin = new Vector2(24f, 24f);
					vector = new Vector2(384f, 219f);
					break;
				case Bubble.BubbleType.LBubble:
				case Bubble.BubbleType.RBubble:
					num2 = 0;
					origin = new Vector2(196f, 16f);
					vector = new Vector2(196f, 171f);
					num2 = 4;
					origin = new Vector2(196f, 40f);
					vector = new Vector2(196f, 148f);
					break;
				case Bubble.BubbleType.LExclaim:
				case Bubble.BubbleType.RExclaim:
					num2 = 2;
					origin = new Vector2(196f, 40f);
					vector = new Vector2(196f, 119f);
					break;
				case Bubble.BubbleType.Oval:
					num2 = 3;
					origin = new Vector2(196f, 16f);
					vector = new Vector2(196f, 225f);
					num2 = 5;
					origin = new Vector2(196f, 40f);
					vector = new Vector2(196f, 190f);
					break;
				}
				switch (bubble.type)
				{
				case Bubble.BubbleType.RBubble:
				case Bubble.BubbleType.RExclaim:
					flag = true;
					break;
				}
				value.X = num2 % 2 * 400;
				value.Y = num2 / 2 * 240;
				value.Width = 400;
				value.Height = 240;
				int num3 = 0;
				float num4 = 0f;
				for (int j = 0; j < bubble.text.Length; j++)
				{
					if (bubble.text[j] != null)
					{
						num3 = j + 1;
					}
				}
				for (int k = 0; k < bubble.text.Length; k++)
				{
					if (bubble.text[k] == null)
					{
						continue;
					}
					float num5 = 0.9f * Text.GetStringSpace(bubble.text[k]);
					if (Game1.locs.comic.ContainsKey(bubbleKey[curScene][i][k]))
					{
						num5 = 0.9f * Text.GetStringSpace(Game1.locs.comic[bubbleKey[curScene][i][k]]);
					}
					switch (bubble.type)
					{
					case Bubble.BubbleType.LBubble:
					case Bubble.BubbleType.RBubble:
					case Bubble.BubbleType.Oval:
					{
						float num6 = (float)num3 / 2f;
						float num7 = num6 - (float)k;
						if (num7 < 0f)
						{
							num7 = 0f - num7;
						}
						float num8 = (float)Math.Cos(num7);
						num5 *= 1f / num8;
						num5 = 0.9f * Text.GetStringSpace(bubble.text[k]);
						if (Game1.locs.comic.ContainsKey(bubbleKey[curScene][i][k]))
						{
							num5 = 0.9f * Text.GetStringSpace(Game1.locs.comic[bubbleKey[curScene][i][k]]);
						}
						break;
					}
					}
					if (num5 > num4)
					{
						num4 = num5;
					}
				}
				if (!miniAdjust)
				{
					num4 *= SceneCam.location.Z;
				}
				num4 += 20f;
				Vector2 scale = new Vector2(1f, 1f);
				scale.Y = (float)num3 * 32f / (vector.Y - origin.Y);
				Vector3 loc = new Vector3(bubble.loc.X, bubble.loc.Y, miniAdjust ? (1f / SceneCam.location.Z) : 0.1f);
				Vector2 screenLoc = SceneCam.GetScreenLoc(loc);
				Vector2 vector2 = screenLoc - ScrollManager.screenSize / 2f;
				vector2.X *= ScrollManager.screenSize.X / 1280f;
				vector2.Y *= ScrollManager.screenSize.Y / 720f;
				float num9 = SceneCam.rotation;
				screenLoc = ScrollManager.screenSize / 2f + new Vector2((float)Math.Cos(SceneCam.rotation) * vector2.X, (float)Math.Sin(SceneCam.rotation) * vector2.X) + new Vector2((float)Math.Cos(SceneCam.rotation + 1.57f) * vector2.Y, (float)Math.Sin(SceneCam.rotation + 1.57f) * vector2.Y);
				if (!miniAdjust)
				{
					scale *= SceneCam.location.Z;
				}
				switch (bubble.type)
				{
				case Bubble.BubbleType.Box:
					scale.X = num4 / (vector.X - origin.X);
					break;
				case Bubble.BubbleType.Oval:
					scale.X = num4 / 350f;
					break;
				case Bubble.BubbleType.LBubble:
				case Bubble.BubbleType.RBubble:
					scale.X = num4 / 250f;
					break;
				}
				float num10 = (scene.r + scene.g + scene.b) / 3f;
				Color color = new Color(num10, num10, num10, num);
				if (miniAdjust)
				{
					num9 *= 0.1f;
				}
				if (bubble.justify == Bubble.BubbleJustify.Left)
				{
					float num11 = screenLoc.X + num4 * ((!miniAdjust) ? SceneCam.location.Z : 1f);
					if (num11 > 1120f)
					{
						screenLoc.X -= num11 - 1120f;
					}
				}
				if (bubble.color != Bubble.BubbleColor.Clear)
				{
					sprite.Draw(Game1.bubbleTex, screenLoc + new Vector2(5f, 5f), value, new Color(0f, 0f, 0f, num * 0.2f), num9, origin, scale, flag ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
					sprite.Draw(Game1.bubbleTex, screenLoc + new Vector2(-2f, -2f), value, new Color(0f, 0f, 0f, num * 0.1f), num9, origin, scale, flag ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
					sprite.Draw(Game1.bubbleTex, screenLoc + new Vector2(2f, -2f), value, new Color(0f, 0f, 0f, num * 0.1f), num9, origin, scale, flag ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
					sprite.Draw(Game1.bubbleTex, screenLoc + new Vector2(-2f, 2f), value, new Color(0f, 0f, 0f, num * 0.1f), num9, origin, scale, flag ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
					sprite.Draw(Game1.bubbleTex, screenLoc + new Vector2(2f, 2f), value, new Color(0f, 0f, 0f, num * 0.1f), num9, origin, scale, flag ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
					if (bubble.color == Bubble.BubbleColor.Gray)
					{
						color = new Color(0.99f, 0.95f, 0.86f, num);
					}
					if (bubble.color == Bubble.BubbleColor.Black)
					{
						color = new Color(0f, 0f, 0f, num);
					}
					sprite.Draw(Game1.bubbleTex, screenLoc, value, color, num9, origin, scale, flag ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
				}
				for (int l = 0; l < bubble.text.Length; l++)
				{
					if (bubble.text[l] != null)
					{
						color = new Color(0f, 0f, 0f, num);
						if (bubble.color == Bubble.BubbleColor.Black || bubble.color == Bubble.BubbleColor.Clear)
						{
							color = new Color(num10, num10, num10, num);
						}
						if (Game1.locs.comic.ContainsKey(bubbleKey[curScene][i][l]))
						{
							Text.DrawCText(sprite, screenLoc + new Vector2((float)Math.Cos(num9 + 1.57f), (float)Math.Sin(num9 + 1.57f)) * l * 32f * SceneCam.location.Z, Game1.locs.comic[bubbleKey[curScene][i][l]], color, 0.9f * ((!miniAdjust) ? SceneCam.location.Z : 1f), (int)bubble.justify, num9);
						}
						else
						{
							Text.DrawCText(sprite, screenLoc + new Vector2((float)Math.Cos(num9 + 1.57f), (float)Math.Sin(num9 + 1.57f)) * l * 32f * SceneCam.location.Z, bubble.text[l], color, 0.9f * ((!miniAdjust) ? SceneCam.location.Z : 1f), (int)bubble.justify, num9);
						}
					}
				}
				break;
			}
			}
		}
	}

	public void Draw(GraphicsDeviceManager dev, SpriteBatch sprite, bool overlay)
	{
		Draw(dev, sprite, -1, overlay);
	}

	public void Draw(GraphicsDeviceManager g, SpriteBatch sprite, int threedee, bool overlay)
	{
		GraphicsDevice graphicsDevice = g.GraphicsDevice;
		if (GameState.state == GameState.State.Credits || GameState.state == GameState.State.Upsell)
		{
			hasMask = false;
		}
		if (Game1.gameMap.curMap != null)
		{
			Game1.gameMap.theme.UpdateColors();
		}
		if (video.scenes.Count <= 0)
		{
			return;
		}
		if (reading)
		{
			graphicsDevice.SetRenderTarget(null);
			graphicsDevice.Clear(Color.Black);
		}
		else
		{
			if (curScene >= video.scenes.Count)
			{
				return;
			}
			Scene scene = video.scenes[curScene];
			graphicsDevice.SetRenderTarget(comicTarg);
			graphicsDevice.Clear(Color.Black);
			SpriteTools.BeginAlpha();
			Vector3 location = SceneCam.location;
			float num = 0f;
			float num2 = 2f;
			if (closest > 0f)
			{
				num2 = 15f / closest;
			}
			if (num2 > 2f)
			{
				num2 = 2f;
			}
			float xAdd = 0f;
			switch (threedee)
			{
			case 0:
				num -= num2;
				xAdd = (0f - num2) * 2f;
				break;
			case 1:
				num += num2;
				xAdd = num2 * 2f;
				break;
			}
			if (num != 0f)
			{
				SceneCam.location.X += (float)Math.Cos(0f - SceneCam.rotation) * num;
				SceneCam.location.Y += (float)Math.Sin(0f - SceneCam.rotation) * num;
			}
			DrawLayers(mask: false, sprite, scene, xAdd);
			if (strobe && (int)(video.time * 20f) % 2 == 0)
			{
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, 0.8f));
			}
			if (creep)
			{
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(1f, 1f, 1f, Rand.GetRandomFloat(0.1f, 0.2f)));
			}
			sprite.End();
			graphicsDevice.SetRenderTarget(maskTarg);
			graphicsDevice.Clear(Color.Black);
			SpriteTools.BeginAdditive();
			DrawLayers(mask: true, sprite, scene, xAdd);
			if (!hasMask)
			{
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
			}
			sprite.End();
			addMgr.Prepare(graphicsDevice, sprite, comicTarg);
			switch (threedee)
			{
			case -1:
				graphicsDevice.SetRenderTarget(null);
				break;
			case 0:
			case 1:
				graphicsDevice.SetRenderTarget(Game1.threeDeeTarg[threedee]);
				break;
			}
			graphicsDevice.Clear(Color.Black);
			if (creep)
			{
				if (GameState.state == GameState.State.Upsell)
				{
					SpriteTools.BeginAlpha(creepTVEffect);
					sprite.Draw(comicTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
					SpriteTools.End();
				}
				else
				{
					SpriteTools.BeginAlpha(creepEffect);
					sprite.Draw(comicTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
					SpriteTools.End();
				}
			}
			else
			{
				graphicsDevice.Textures[1] = maskTarg;
				if (GameState.state == GameState.State.Credits)
				{
					comicEffect.Parameters["add"].SetValue(Rand.GetRandomFloat(0f, 0.01f) - 0.1f);
				}
				else
				{
					comicEffect.Parameters["add"].SetValue(0.1f);
				}
				SpriteTools.BeginAlpha(comicEffect);
				sprite.Draw(comicTarg, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), Color.White);
				SpriteTools.End();
				graphicsDevice.Textures[1] = null;
			}
			DrawOverlay(sprite, threedee);
			if (overlay)
			{
				GameRender.DrawOverlay(sprite, g, threedee);
			}
			SceneCam.location = location;
		}
	}

	public void DrawLoader(SpriteBatch sprite)
	{
		SpriteTools.BeginAlpha();
		Vector2 position = ScrollManager.screenSize - new Vector2(100f, 100f);
		if (Game1.menuMgr.levels[2].active || Game1.menuMgr.levels[12].active)
		{
			position = ScrollManager.screenSize / 2f;
		}
		sprite.Draw(Game1.spritesTex, position, new Rectangle(832, 192, 64, 64), new Color(0f, 0f, 0f, 0.5f), 0f - loaderFrame, new Vector2(32f, 32f), 1f, SpriteEffects.FlipHorizontally, 1f);
		sprite.Draw(Game1.spritesTex, position, new Rectangle(832, 192, 64, 64), new Color(1f, 1f, 1f, 0.5f), loaderFrame, new Vector2(32f, 32f), 1f, SpriteEffects.None, 1f);
		sprite.End();
	}

	public void DrawOverlay(SpriteBatch sprite, int threedee)
	{
		if (transInFrame > 0f)
		{
			SpriteTools.BeginAlpha();
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, 1f - transInFrame));
			SpriteTools.End();
			return;
		}
		SpriteTools.BeginAlpha();
		Scene scene = video.scenes[curScene];
		flicker = false;
		spazz = false;
		endLevel = false;
		strobe = false;
		smoothcam = false;
		creep = false;
		needsCrazyTrans = false;
		miniAdjust = false;
		foreach (Bubble item in scene.bubble)
		{
			switch (item.type)
			{
			case Bubble.BubbleType.Trig_Miniadjust:
				miniAdjust = true;
				break;
			case Bubble.BubbleType.Trig_CreepFilter:
				creep = true;
				break;
			case Bubble.BubbleType.Trig_Smoothcam:
				smoothcam = true;
				break;
			case Bubble.BubbleType.Trig_Endlevel:
			case Bubble.BubbleType.Trig_EndGame:
				endLevel = true;
				break;
			case Bubble.BubbleType.Trig_Strobe:
				if (video.time >= item.time && video.time <= item.timeOff)
				{
					strobe = true;
				}
				break;
			case Bubble.BubbleType.Trig_FadeOut:
				if (!overlay)
				{
					overlay = true;
					Game1.transMgr.levelInFrame = 1f;
				}
				break;
			case Bubble.BubbleType.Trig_GlowOutCrazy:
				needsCrazyTrans = true;
				if (video.time > video.scenes[curScene].duration - 1f)
				{
					for (int j = 0; j < 3; j++)
					{
						addMgr.Draw(sprite, (video.time - (video.scenes[curScene].duration - 1f)) * 1f, !Game1.hud.IsEndLevel());
					}
				}
				break;
			case Bubble.BubbleType.Trig_GlowOut:
				if (video.time > video.scenes[curScene].duration - 0.5f)
				{
					for (int i = 0; i < 3; i++)
					{
						addMgr.Draw(sprite, (video.time - (video.scenes[curScene].duration - 0.5f)) * 2f, !Game1.hud.IsEndLevel());
					}
				}
				break;
			case Bubble.BubbleType.Trig_GlowIn:
				if (video.time < 0.5f)
				{
					for (int k = 0; k < 3; k++)
					{
						addMgr.Draw(sprite, (0.5f - video.time) * 2f, !Game1.hud.IsEndLevel());
					}
				}
				break;
			case Bubble.BubbleType.Trig_Speckles:
				addMgr.DrawGlobs(sprite, Game1.spritesTex);
				break;
			case Bubble.BubbleType.Trig_Flicker:
				flicker = true;
				break;
			case Bubble.BubbleType.Trig_Spazz:
				spazz = true;
				break;
			case Bubble.BubbleType.Trig_Glow:
				if (video.time >= item.time && video.time <= item.timeOff)
				{
					float num = 1f;
					if (video.time < item.time + 0.25f)
					{
						num = (video.time - item.time) * 4f;
					}
					if (video.time > item.timeOff - 0.25f)
					{
						num = (item.timeOff - video.time) * 4f;
					}
					addMgr.Draw(sprite, num * Rand.GetRandomFloat(0f, 1f), !Game1.hud.IsEndLevel());
				}
				break;
			}
		}
		DrawBubbles(sprite, scene);
		if (GameState.state == GameState.State.Playing && video.time > 0.5f && video.time < video.scenes[curScene].duration - 0.5f)
		{
			BottomRightMessage.DrawButton(sprite, BottomRightMessage.Button.A, BottomRightMessage.Msg.Skip, 0, 1f);
		}
		sprite.End();
	}

	internal void Read(string path)
	{
		Read(path, blocking: false);
	}

	internal void Read(string path, bool blocking)
	{
		speedTilNext = 0;
		if (blocking)
		{
			StraightRead(path);
			return;
		}
		reading = true;
		this.path = path;
		Thread thread = new Thread(ThreadRead);
		thread.Start();
	}

	private void ThreadRead()
	{
		try
		{
			lock (video)
			{
				BinaryReader binaryReader = new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read));
				video.Read(binaryReader);
				binaryReader.Close();
				foreach (Scene scene2 in video.scenes)
				{
					foreach (Layer item in scene2.layer)
					{
						foreach (Keyframe item2 in item.keyframe)
						{
							if (item2.texture != null && item2.texture != "" && !texture.ContainsKey(item2.texture))
							{
								try
								{
									texture.Add(item2.texture, Content.Load<Texture2D>("gfx/scenes/" + item2.texture));
								}
								catch
								{
								}
							}
						}
					}
				}
				bubbleKey = new string[video.scenes.Count][][];
				string[] array = path.Split('/');
				string text = array[array.Length - 1];
				text = text.Substring(0, text.Length - 4);
				for (int i = 0; i < video.scenes.Count; i++)
				{
					Scene scene = video.scenes[i];
					bubbleKey[i] = new string[scene.bubble.Count][];
					for (int j = 0; j < video.scenes[i].bubble.Count; j++)
					{
						Bubble bubble = scene.bubble[j];
						bubbleKey[i][j] = new string[bubble.text.Length];
						for (int k = 0; k < bubble.text.Length; k++)
						{
							bubbleKey[i][j][k] = text + "_" + scene.name + "_" + i + "_" + bubble.name + "_" + j + "_" + k;
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			Game1.loader.DebugPrint(ex.Message);
		}
		reading = false;
	}

	private void StraightRead(string path)
	{
		this.path = path;
		try
		{
			BinaryReader binaryReader = new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read));
			video.Read(binaryReader);
			binaryReader.Close();
			foreach (Scene scene2 in video.scenes)
			{
				foreach (Layer item in scene2.layer)
				{
					foreach (Keyframe item2 in item.keyframe)
					{
						if (item2.texture != null && item2.texture != "" && !texture.ContainsKey(item2.texture))
						{
							try
							{
								texture.Add(item2.texture, Content.Load<Texture2D>("gfx/scenes/" + item2.texture));
							}
							catch
							{
							}
						}
					}
				}
			}
			bubbleKey = new string[video.scenes.Count][][];
			string[] array = path.Split('/');
			string text = array[array.Length - 1];
			text = text.Substring(0, text.Length - 4);
			for (int i = 0; i < video.scenes.Count; i++)
			{
				Scene scene = video.scenes[i];
				bubbleKey[i] = new string[scene.bubble.Count][];
				for (int j = 0; j < video.scenes[i].bubble.Count; j++)
				{
					Bubble bubble = scene.bubble[j];
					bubbleKey[i][j] = new string[bubble.text.Length];
					for (int k = 0; k < bubble.text.Length; k++)
					{
						bubbleKey[i][j][k] = text + "_" + scene.name + "_" + i + "_" + bubble.name + "_" + j + "_" + k;
					}
				}
			}
		}
		catch (Exception ex)
		{
			Game1.loader.DebugPrint(ex.Message);
		}
		reading = false;
	}

	internal void Write(string path)
	{
		this.path = path;
		Write();
	}

	internal void Write()
	{
		BinaryWriter binaryWriter = new BinaryWriter(File.Open(path, FileMode.OpenOrCreate, FileAccess.Write));
		video.Write(binaryWriter);
		binaryWriter.Close();
	}

	internal void Reset()
	{
		playing = false;
		endLevel = false;
	}
}
