using System.Collections.Generic;
using Yuki_Win.levels;
using Yuki_Win.player;

namespace Yuki_Win;

public class MainPlayer
{
	public const int YUKI_PHASE_DISHINTRO = 0;

	public const int YUKI_PHASE_PRISONER = 1;

	public const int YUKI_PHASE_CLAWS = 2;

	public const int YUKI_PHASE_WARP = 3;

	public const int YUKI_PHASE_KATANA = 4;

	public const int YUKI_PHASE_NEKO = 5;

	public const int YUKI_PHASE_SAW = 6;

	public const int YUKI_PHASE_CLOUD = 7;

	public const int YUKI_PHASE_GUN = 8;

	public const int YUKI_PHASE_ELECTRIC_MAGIC = 9;

	public const int YUKI_PHASE_KAMAKAZI = 10;

	public const int YUKI_PHASE_STEEL_MAGIC = 11;

	public const int YUKI_PHASE_SYRINGE = 12;

	public const int YUKI_PHASE_DEVOURING_MAGIC = 13;

	public const int YUKI_PHASE_SHOTTY = 14;

	public const int YUKI_PHASE_HOLY_MAGIC = 15;

	public const int DISH_PHASE_SHIFT_BLADE = 0;

	public const int DISH_PHASE_CLEAVERS = 1;

	public const int DISH_PHASE_HAMMER = 2;

	public const int DISH_PHASE_GUN = 3;

	public const int DISH_PHASE_ELECTRIC_MAGIC = 4;

	public const int DISH_PHASE_SCISSORS = 5;

	public const int DISH_PHASE_STEEL_MAGIC = 6;

	public const int DISH_PHASE_TOASTER = 7;

	public const int DISH_PHASE_DEVOURING_MAGIC = 8;

	public const int DISH_PHASE_SHOTTY = 9;

	public const int DISH_PHASE_HOLY_MAGIC = 10;

	public Level.LevelType levelType;

	public int yukiPhase = 4;

	public int dishPhase;

	public static Dictionary<string, int> stringToYukiPhase = new Dictionary<string, int>();

	public static Dictionary<string, int> stringToDishPhase = new Dictionary<string, int>();

	public static float uberDyingFrame;

	public static void ClearUberFlags()
	{
		Game1.storageMgr.playerData[0].uberFlags.Clear();
	}

	public static void SetUberFlag(string s)
	{
		if (Game1.levelMgr.currentTrack == 1 || Game1.levelMgr.currentTrack == 0)
		{
			SetUberFlag(Game1.storageMgr.playerData[0].uberFlags, s);
		}
		else if (Game1.levelMgr.currentTrack == 2)
		{
			if (Game1.netSession.IsHost())
			{
				Game1.levelMgr.SetGlobalFlag(s);
				SetUberFlag(Game1.storageMgr.playerData[0].uberFlags, s);
			}
			else if (Game1.netSession.IsClient())
			{
				SetUberFlag(Game1.storageMgr.playerData[1].uberFlags, s);
			}
			else
			{
				SetUberFlag(Game1.storageMgr.playerData[0].uberFlags, s);
				SetUberFlag(Game1.storageMgr.playerData[1].uberFlags, s);
			}
		}
	}

	private static void SetUberFlag(List<string> uberFlags, string s)
	{
		if (!uberFlags.Contains(s))
		{
			uberFlags.Add(s);
		}
	}

	public static bool GetUberFlag(string s)
	{
		if (Game1.levelMgr.currentTrack == 1 || Game1.levelMgr.currentTrack == 0)
		{
			return Game1.storageMgr.playerData[0].uberFlags.Contains(s);
		}
		if (Game1.levelMgr.currentTrack == 2)
		{
			if (Game1.netSession.IsHost())
			{
				return Game1.levelMgr.GetGlobalFlag(s);
			}
			if (Game1.netSession.IsClient())
			{
				return Game1.storageMgr.playerData[1].uberFlags.Contains(s);
			}
			if (!Game1.storageMgr.playerData[0].uberFlags.Contains(s))
			{
				return Game1.storageMgr.playerData[1].uberFlags.Contains(s);
			}
			return true;
		}
		return false;
	}

	public static void InitPlayer()
	{
		stringToYukiPhase.Add("dishintro", 0);
		stringToYukiPhase.Add("prisoner", 1);
		stringToYukiPhase.Add("claws", 2);
		stringToYukiPhase.Add("katana", 4);
		stringToYukiPhase.Add("warp", 3);
		stringToYukiPhase.Add("kama", 10);
		stringToYukiPhase.Add("saw", 6);
		stringToYukiPhase.Add("gun", 8);
		stringToYukiPhase.Add("neko", 5);
		stringToYukiPhase.Add("cloud", 7);
		stringToYukiPhase.Add("syringe", 12);
		stringToYukiPhase.Add("electricmagic", 9);
		stringToYukiPhase.Add("steelmagic", 11);
		stringToYukiPhase.Add("devouringmagic", 13);
		stringToYukiPhase.Add("shotty", 14);
		stringToYukiPhase.Add("holymagic", 15);
		stringToDishPhase.Add("shiftblade", 0);
		stringToDishPhase.Add("cleavers", 1);
		stringToDishPhase.Add("hammer", 2);
		stringToDishPhase.Add("gun", 3);
		stringToDishPhase.Add("scissor", 5);
		stringToDishPhase.Add("toaster", 7);
		stringToDishPhase.Add("electricmagic", 4);
		stringToDishPhase.Add("steelmagic", 6);
		stringToDishPhase.Add("devouringmagic", 8);
		stringToDishPhase.Add("shotty", 9);
		stringToDishPhase.Add("holymagic", 10);
	}

	public void SetYukiPhase(string phase)
	{
		if (stringToYukiPhase.ContainsKey(phase))
		{
			SetYukiPhase(stringToYukiPhase[phase]);
		}
	}

	public void SetYukiPhase(int phase)
	{
		for (int i = 0; i < 2; i++)
		{
			if (phase > Game1.gamePlayerMgr.gamePlayer[i].highestYukiPhase)
			{
				Game1.gamePlayerMgr.gamePlayer[i].highestYukiPhase = phase;
			}
		}
		if (phase <= yukiPhase)
		{
			return;
		}
		yukiPhase = phase;
		switch (yukiPhase)
		{
		case 2:
		{
			for (int n = 0; n < 2; n++)
			{
				Game1.gamePlayerMgr.gamePlayer[0].loadOut[n].weapon[0] = InvCatalog.InvItemName.Claws;
				Game1.gamePlayerMgr.gamePlayer[0].loadOut[n].weapon[1] = InvCatalog.InvItemName.None;
			}
			break;
		}
		case 4:
		{
			for (int k = 0; k < 2; k++)
			{
				Game1.gamePlayerMgr.gamePlayer[0].loadOut[k].weapon[0] = InvCatalog.InvItemName.Conviction;
			}
			break;
		}
		case 6:
		{
			for (int l = 0; l < 2; l++)
			{
				for (int m = 0; m < 2; m++)
				{
					if (Game1.gamePlayerMgr.gamePlayer[0].yukiLoadOut[l].weapon[m] == InvCatalog.InvItemName.Claws)
					{
						Game1.gamePlayerMgr.gamePlayer[0].yukiLoadOut[l].weapon[m] = InvCatalog.InvItemName.Conviction;
					}
					Game1.gamePlayerMgr.gamePlayer[0].loadOut[l].weapon[m] = Game1.gamePlayerMgr.gamePlayer[0].yukiLoadOut[l].weapon[m];
				}
			}
			break;
		}
		case 7:
		{
			for (int j = 0; j < 2; j++)
			{
				if (Game1.gamePlayerMgr.gamePlayer[0].loadOut[j].weapon[1] == InvCatalog.InvItemName.None)
				{
					Game1.gamePlayerMgr.gamePlayer[0].SetLoadout(j, 1, InvCatalog.InvItemName.CloudSword, 0);
				}
			}
			break;
		}
		case 3:
		case 5:
			break;
		}
	}

	public void SetDishPhase(string sphase)
	{
		if (!stringToDishPhase.ContainsKey(sphase))
		{
			return;
		}
		int num = stringToDishPhase[sphase];
		if (num > dishPhase)
		{
			dishPhase = num;
		}
		for (int i = 0; i < 2; i++)
		{
			if (num > Game1.gamePlayerMgr.gamePlayer[i].highestDishPhase)
			{
				Game1.gamePlayerMgr.gamePlayer[i].highestDishPhase = num;
			}
		}
	}
}
