namespace Yuki_Win;

internal class Enviro
{
	public const float GRAVITY = 2500f;

	public const float SLIDE = 1800f;
}
