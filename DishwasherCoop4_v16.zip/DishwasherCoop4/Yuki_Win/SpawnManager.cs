using Microsoft.Xna.Framework;
using Yuki_Win.chars;
using Yuki_Win.hud;

namespace Yuki_Win;

public class SpawnManager
{
	public static int StringToMonster(string s)
	{
		switch (s)
		{
		case "swat":
			return 1;
		case "guard":
			return 0;
		case "goon":
			return 23;
		case "freak":
			return 24;
		case "hockey":
			return 25;
		case "ghost":
			return 26;
		case "mook":
			return 27;
		case "predator":
			return 59;
		case "raptor":
			return 60;
		case "shark":
			return 28;
		case "dragon":
			return 29;
		case "tank":
			return 3;
		case "blade":
			return 2;
		case "pod":
			return 4;
		case "hackbot":
			return 49;
		case "chef":
			return 50;
		case "ninja":
			return 5;
		case "zombie":
			return 6;
		case "cretin":
			return 7;
		case "warden":
			return 8;
		case "warclone":
			return 20;
		case "pyro":
			return 21;
		case "lich":
			return 9;
		case "slava":
			return 13;
		case "invalid":
			return 32;
		case "sackboy":
		case "sack":
			return 31;
		case "pumpkinhead":
		case "pumpkin":
			return 14;
		case "skeletank":
			return 15;
		case "banker":
			return 16;
		case "general":
			return 22;
		case "force":
			return 17;
		case "box":
			return 18;
		case "murderfly":
			return 19;
		case "murderbug":
			return 45;
		case "goreface":
			return 10;
		case "uslava":
			return 51;
		case "apple2":
			return 11;
		case "podbot":
			return 12;
		case "samurai":
			return 34;
		case "yukinpc":
			return 55;
		case "assassin":
			return 56;
		case "squid":
		case "squidface":
			return 35;
		case "hypno":
			return 54;
		case "corpse":
			return 36;
		case "judge":
			return 37;
		case "engineer":
			return 38;
		case "goonpuppet":
		case "puppet":
			return 39;
		case "swatpuppet":
			return 40;
		case "bigengie":
			return 41;
		case "horse":
			return 42;
		case "engie2":
			return 43;
		case "midengie":
			return 44;
		case "swordsman":
		case "gaoler":
			return 47;
		case "ghoul":
			return 46;
		case "thug":
			return 48;
		case "inmate":
			return 61;
		default:
			Printf.WriteLine("Unrecognized monster: " + s);
			return 0;
		}
	}

	public void SpawnLockedMonster(Vector2 loc, int monster, string tag)
	{
		int num = SpawnMonster(loc, monster, tag);
		if (num > -1)
		{
			Game1.character[num].charAnim.SetAnim(Game1.character[num].GetMeta().lock_anim, Game1.character[num].charUpdate);
			Game1.character[num].charUpdate.LockChar(loc);
			if (loc.X > (float)Game1.gameMap.CurMap().xSize * 64f * 0.5f)
			{
				Game1.character[num].charUpdate.face = 0;
			}
			else
			{
				Game1.character[num].charUpdate.face = 1;
			}
		}
	}

	public int SpawnMonster(Vector2 loc, int monster, string tag)
	{
		for (int i = 4; i < Game1.character.Length; i++)
		{
			if (!Game1.character[i].exists)
			{
				int num = 1;
				int cDef = 1;
				int ai = 0;
				switch (monster)
				{
				case 61:
					num = 99;
					cDef = 1;
					ai = 10;
					break;
				case 0:
					num = 1;
					cDef = 1;
					ai = 0;
					break;
				case 48:
					num = 81;
					cDef = 1;
					ai = 6;
					break;
				case 23:
					num = 53;
					cDef = 1;
					ai = 0;
					break;
				case 55:
					num = 91;
					cDef = 0;
					ai = 14;
					break;
				case 56:
					num = 94;
					cDef = 36;
					ai = 6;
					break;
				case 34:
					num = 64;
					cDef = 23;
					ai = 6;
					break;
				case 36:
					num = 66;
					cDef = 25;
					ai = 10;
					break;
				case 38:
					num = 68;
					cDef = 26;
					ai = 6;
					break;
				case 43:
					num = 73;
					cDef = 26;
					ai = 6;
					break;
				case 44:
					num = 74;
					cDef = 30;
					ai = 6;
					break;
				case 47:
					num = 80;
					cDef = 31;
					ai = 6;
					break;
				case 46:
					num = 77;
					cDef = 1;
					ai = 6;
					break;
				case 39:
					num = 69;
					cDef = 27;
					ai = 13;
					break;
				case 40:
					num = 70;
					cDef = 27;
					ai = 13;
					break;
				case 41:
					num = 71;
					cDef = 28;
					ai = 10;
					break;
				case 42:
					num = 72;
					cDef = 29;
					ai = 10;
					break;
				case 37:
					num = 67;
					cDef = 1;
					ai = 10;
					break;
				case 35:
					num = 65;
					cDef = 25;
					ai = 6;
					break;
				case 54:
					num = 90;
					cDef = 35;
					ai = 6;
					break;
				case 24:
					num = 54;
					cDef = 1;
					ai = 6;
					break;
				case 25:
					num = 55;
					cDef = 19;
					ai = 6;
					break;
				case 1:
					num = 3;
					cDef = 1;
					ai = 1;
					break;
				case 52:
					num = 88;
					cDef = 33;
					ai = 10;
					break;
				case 2:
					num = 6;
					cDef = 4;
					ai = 1;
					break;
				case 3:
					num = 4;
					cDef = 2;
					ai = 2;
					break;
				case 4:
					num = 13;
					cDef = 8;
					ai = 4;
					break;
				case 49:
					num = 82;
					cDef = 8;
					ai = 4;
					break;
				case 11:
					num = 40;
					cDef = 8;
					ai = 4;
					break;
				case 12:
					num = 41;
					cDef = 4;
					ai = 1;
					break;
				case 5:
					num = 14;
					cDef = 1;
					ai = 0;
					break;
				case 6:
					num = 17;
					cDef = 1;
					ai = 1;
					break;
				case 26:
					num = 56;
					cDef = 1;
					ai = 1;
					break;
				case 27:
					num = 57;
					cDef = 1;
					ai = 0;
					break;
				case 59:
					num = 97;
					cDef = 1;
					ai = 0;
					break;
				case 60:
					num = 98;
					cDef = 1;
					ai = 6;
					break;
				case 50:
					num = 83;
					cDef = 32;
					ai = 6;
					break;
				case 53:
					num = 89;
					cDef = 34;
					ai = 6;
					break;
				case 28:
					num = 58;
					cDef = 2;
					ai = 2;
					break;
				case 29:
					num = 59;
					cDef = 20;
					ai = 8;
					break;
				case 30:
					num = 60;
					cDef = 20;
					ai = 8;
					break;
				case 7:
					num = 19;
					cDef = 10;
					ai = 6;
					break;
				case 8:
					num = 20;
					cDef = 12;
					ai = 7;
					break;
				case 20:
					num = 50;
					cDef = 12;
					ai = 7;
					break;
				case 21:
					num = 51;
					cDef = 4;
					ai = 6;
					break;
				case 9:
					num = 21;
					cDef = 11;
					ai = 6;
					break;
				case 13:
					num = 42;
					cDef = 14;
					ai = 6;
					break;
				case 31:
					num = 61;
					cDef = 14;
					ai = 6;
					break;
				case 32:
					num = 62;
					cDef = 21;
					ai = 10;
					break;
				case 15:
					num = 44;
					cDef = 15;
					ai = 8;
					break;
				case 33:
					num = 63;
					cDef = 22;
					ai = 12;
					break;
				case 58:
					num = 96;
					cDef = 0;
					ai = 10;
					break;
				case 57:
					num = 95;
					cDef = 3;
					ai = 10;
					break;
				case 16:
					num = 45;
					cDef = 1;
					ai = 9;
					break;
				case 22:
					num = 52;
					cDef = 1;
					ai = 9;
					break;
				case 17:
					num = 47;
					cDef = 16;
					ai = 10;
					break;
				case 18:
					num = 48;
					cDef = 17;
					ai = 10;
					break;
				case 19:
					num = 49;
					cDef = 18;
					ai = 11;
					break;
				case 45:
					num = 75;
					cDef = 18;
					ai = 11;
					break;
				case 14:
					num = 43;
					cDef = 4;
					ai = 6;
					break;
				case 10:
					num = 23;
					cDef = 13;
					ai = 6;
					break;
				case 51:
					num = 87;
					cDef = 14;
					ai = 10;
					break;
				}
				Game1.character[i].Init(cDef, loc, num, -1, (!Game1.charMeta[num].isfriendly) ? Character.Team.BadGuys : Character.Team.GoodGuys, ai, tag);
				if (monster == 17)
				{
					Game1.character[i].charUpdate.face = 0;
				}
				return i;
			}
		}
		return -1;
	}

	internal void SpawnFamiliar(int ID)
	{
		if (Game1.GetPlayers() > 2)
		{
			return;
		}
		if (Game1.character[ID].GetMeta().isHatless)
		{
			return;
		}
		if (Game1.character[ID].GetMeta().isYuki)
		{
			if (Game1.player.yukiPhase < 5)
			{
				return;
			}
			Game1.character[ID + 2].Init(5, Game1.character[ID].charUpdate.loc, 7, -1, Character.Team.GoodGuys, 3);
			if (Game1.character[ID].charUpdate.state == CharUpdate.State.Airborne)
			{
				Game1.character[ID + 2].charUpdate.state = CharUpdate.State.Airborne;
				Game1.character[ID + 2].charAnim.SetAnim("jhit", Game1.character[ID + 2].charUpdate);
				Game1.character[ID + 2].charUpdate.traj = Game1.character[ID].charUpdate.traj;
				if (Game1.character[ID + 2].charUpdate.traj.Y < 0f)
				{
					Game1.character[ID + 2].charUpdate.traj.Y = -1000f;
				}
			}
		}
		else if (Game1.character[ID].GetMeta().isDish)
		{
			bool flag = false;
			if (Game1.character[ID + 2].ai.mount)
			{
				flag = true;
			}
			Game1.character[ID + 2].Init(9, Game1.character[ID].charUpdate.loc, 18, -1, Character.Team.GoodGuys, 5);
			if (flag)
			{
				Game1.character[ID + 2].ai.mount = true;
				Game1.character[ID + 2].charAnim.SetAnim(Game1.character[ID + 2].GetMeta().idle_anim, Game1.character[ID + 2].charUpdate);
			}
		}
		Game1.character[ID + 2].charUpdate.face = Game1.character[ID].charUpdate.face;
		Game1.character[ID + 2].ai.owner = ID;
	}
}
