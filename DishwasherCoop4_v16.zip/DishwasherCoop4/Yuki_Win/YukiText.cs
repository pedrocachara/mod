using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Yuki_Win;

[CompilerGenerated]
[DebuggerNonUserCode]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
internal class YukiText
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager
	{
		get
		{
			if (object.ReferenceEquals(resourceMan, null))
			{
				ResourceManager resourceManager = new ResourceManager("Yuki_Win.YukiText", typeof(YukiText).Assembly);
				resourceMan = resourceManager;
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	internal static string aback => ResourceManager.GetString("aback", resourceCulture);

	internal static string accept => ResourceManager.GetString("accept", resourceCulture);

	internal static string acceptInvitation => ResourceManager.GetString("acceptInvitation", resourceCulture);

	internal static string achievablesBead => ResourceManager.GetString("achievablesBead", resourceCulture);

	internal static string achievablesBeadDesc1 => ResourceManager.GetString("achievablesBeadDesc1", resourceCulture);

	internal static string achievementFailed1 => ResourceManager.GetString("achievementFailed1", resourceCulture);

	internal static string achievementFailed2 => ResourceManager.GetString("achievementFailed2", resourceCulture);

	internal static string achievementFailed3 => ResourceManager.GetString("achievementFailed3", resourceCulture);

	internal static string achievements => ResourceManager.GetString("achievements", resourceCulture);

	internal static string aerials => ResourceManager.GetString("aerials", resourceCulture);

	internal static string aerials_desc1 => ResourceManager.GetString("aerials_desc1", resourceCulture);

	internal static string aerials_desc2 => ResourceManager.GetString("aerials_desc2", resourceCulture);

	internal static string aquaMarina => ResourceManager.GetString("aquaMarina", resourceCulture);

	internal static string arcade1 => ResourceManager.GetString("arcade1", resourceCulture);

	internal static string arcade10 => ResourceManager.GetString("arcade10", resourceCulture);

	internal static string arcade10desc1 => ResourceManager.GetString("arcade10desc1", resourceCulture);

	internal static string arcade10desc2 => ResourceManager.GetString("arcade10desc2", resourceCulture);

	internal static string arcade11 => ResourceManager.GetString("arcade11", resourceCulture);

	internal static string arcade11desc1 => ResourceManager.GetString("arcade11desc1", resourceCulture);

	internal static string arcade11desc2 => ResourceManager.GetString("arcade11desc2", resourceCulture);

	internal static string arcade12 => ResourceManager.GetString("arcade12", resourceCulture);

	internal static string arcade12desc1 => ResourceManager.GetString("arcade12desc1", resourceCulture);

	internal static string arcade12desc2 => ResourceManager.GetString("arcade12desc2", resourceCulture);

	internal static string arcade13 => ResourceManager.GetString("arcade13", resourceCulture);

	internal static string arcade13desc1 => ResourceManager.GetString("arcade13desc1", resourceCulture);

	internal static string arcade13desc2 => ResourceManager.GetString("arcade13desc2", resourceCulture);

	internal static string arcade14 => ResourceManager.GetString("arcade14", resourceCulture);

	internal static string arcade14desc1 => ResourceManager.GetString("arcade14desc1", resourceCulture);

	internal static string arcade14desc2 => ResourceManager.GetString("arcade14desc2", resourceCulture);

	internal static string arcade15 => ResourceManager.GetString("arcade15", resourceCulture);

	internal static string arcade15desc1 => ResourceManager.GetString("arcade15desc1", resourceCulture);

	internal static string arcade15desc2 => ResourceManager.GetString("arcade15desc2", resourceCulture);

	internal static string arcade16 => ResourceManager.GetString("arcade16", resourceCulture);

	internal static string arcade16desc1 => ResourceManager.GetString("arcade16desc1", resourceCulture);

	internal static string arcade16desc2 => ResourceManager.GetString("arcade16desc2", resourceCulture);

	internal static string arcade17 => ResourceManager.GetString("arcade17", resourceCulture);

	internal static string arcade17desc1 => ResourceManager.GetString("arcade17desc1", resourceCulture);

	internal static string arcade17desc2 => ResourceManager.GetString("arcade17desc2", resourceCulture);

	internal static string arcade18 => ResourceManager.GetString("arcade18", resourceCulture);

	internal static string arcade18desc1 => ResourceManager.GetString("arcade18desc1", resourceCulture);

	internal static string arcade18desc2 => ResourceManager.GetString("arcade18desc2", resourceCulture);

	internal static string arcade19 => ResourceManager.GetString("arcade19", resourceCulture);

	internal static string arcade19desc1 => ResourceManager.GetString("arcade19desc1", resourceCulture);

	internal static string arcade19desc2 => ResourceManager.GetString("arcade19desc2", resourceCulture);

	internal static string arcade1desc1 => ResourceManager.GetString("arcade1desc1", resourceCulture);

	internal static string arcade1desc2 => ResourceManager.GetString("arcade1desc2", resourceCulture);

	internal static string arcade2 => ResourceManager.GetString("arcade2", resourceCulture);

	internal static string arcade20 => ResourceManager.GetString("arcade20", resourceCulture);

	internal static string arcade20desc1 => ResourceManager.GetString("arcade20desc1", resourceCulture);

	internal static string arcade20desc2 => ResourceManager.GetString("arcade20desc2", resourceCulture);

	internal static string arcade21 => ResourceManager.GetString("arcade21", resourceCulture);

	internal static string arcade21desc1 => ResourceManager.GetString("arcade21desc1", resourceCulture);

	internal static string arcade21desc2 => ResourceManager.GetString("arcade21desc2", resourceCulture);

	internal static string arcade22 => ResourceManager.GetString("arcade22", resourceCulture);

	internal static string arcade22desc1 => ResourceManager.GetString("arcade22desc1", resourceCulture);

	internal static string arcade22desc2 => ResourceManager.GetString("arcade22desc2", resourceCulture);

	internal static string arcade23 => ResourceManager.GetString("arcade23", resourceCulture);

	internal static string arcade23desc1 => ResourceManager.GetString("arcade23desc1", resourceCulture);

	internal static string arcade23desc2 => ResourceManager.GetString("arcade23desc2", resourceCulture);

	internal static string arcade24 => ResourceManager.GetString("arcade24", resourceCulture);

	internal static string arcade24desc1 => ResourceManager.GetString("arcade24desc1", resourceCulture);

	internal static string arcade24desc2 => ResourceManager.GetString("arcade24desc2", resourceCulture);

	internal static string arcade25 => ResourceManager.GetString("arcade25", resourceCulture);

	internal static string arcade25desc1 => ResourceManager.GetString("arcade25desc1", resourceCulture);

	internal static string arcade25desc2 => ResourceManager.GetString("arcade25desc2", resourceCulture);

	internal static string arcade26 => ResourceManager.GetString("arcade26", resourceCulture);

	internal static string arcade26desc1 => ResourceManager.GetString("arcade26desc1", resourceCulture);

	internal static string arcade26desc2 => ResourceManager.GetString("arcade26desc2", resourceCulture);

	internal static string arcade27 => ResourceManager.GetString("arcade27", resourceCulture);

	internal static string arcade27desc1 => ResourceManager.GetString("arcade27desc1", resourceCulture);

	internal static string arcade27desc2 => ResourceManager.GetString("arcade27desc2", resourceCulture);

	internal static string arcade28 => ResourceManager.GetString("arcade28", resourceCulture);

	internal static string arcade28desc1 => ResourceManager.GetString("arcade28desc1", resourceCulture);

	internal static string arcade28desc2 => ResourceManager.GetString("arcade28desc2", resourceCulture);

	internal static string arcade29 => ResourceManager.GetString("arcade29", resourceCulture);

	internal static string arcade29desc1 => ResourceManager.GetString("arcade29desc1", resourceCulture);

	internal static string arcade29desc2 => ResourceManager.GetString("arcade29desc2", resourceCulture);

	internal static string arcade2desc1 => ResourceManager.GetString("arcade2desc1", resourceCulture);

	internal static string arcade2desc2 => ResourceManager.GetString("arcade2desc2", resourceCulture);

	internal static string arcade3 => ResourceManager.GetString("arcade3", resourceCulture);

	internal static string arcade30 => ResourceManager.GetString("arcade30", resourceCulture);

	internal static string arcade30desc1 => ResourceManager.GetString("arcade30desc1", resourceCulture);

	internal static string arcade30desc2 => ResourceManager.GetString("arcade30desc2", resourceCulture);

	internal static string arcade31 => ResourceManager.GetString("arcade31", resourceCulture);

	internal static string arcade31desc1 => ResourceManager.GetString("arcade31desc1", resourceCulture);

	internal static string arcade31desc2 => ResourceManager.GetString("arcade31desc2", resourceCulture);

	internal static string arcade32 => ResourceManager.GetString("arcade32", resourceCulture);

	internal static string arcade32desc1 => ResourceManager.GetString("arcade32desc1", resourceCulture);

	internal static string arcade32desc2 => ResourceManager.GetString("arcade32desc2", resourceCulture);

	internal static string arcade33 => ResourceManager.GetString("arcade33", resourceCulture);

	internal static string arcade33desc1 => ResourceManager.GetString("arcade33desc1", resourceCulture);

	internal static string arcade33desc2 => ResourceManager.GetString("arcade33desc2", resourceCulture);

	internal static string arcade34 => ResourceManager.GetString("arcade34", resourceCulture);

	internal static string arcade34desc1 => ResourceManager.GetString("arcade34desc1", resourceCulture);

	internal static string arcade34desc2 => ResourceManager.GetString("arcade34desc2", resourceCulture);

	internal static string arcade35 => ResourceManager.GetString("arcade35", resourceCulture);

	internal static string arcade35desc1 => ResourceManager.GetString("arcade35desc1", resourceCulture);

	internal static string arcade35desc2 => ResourceManager.GetString("arcade35desc2", resourceCulture);

	internal static string arcade36 => ResourceManager.GetString("arcade36", resourceCulture);

	internal static string arcade36desc1 => ResourceManager.GetString("arcade36desc1", resourceCulture);

	internal static string arcade36desc2 => ResourceManager.GetString("arcade36desc2", resourceCulture);

	internal static string arcade37 => ResourceManager.GetString("arcade37", resourceCulture);

	internal static string arcade37desc1 => ResourceManager.GetString("arcade37desc1", resourceCulture);

	internal static string arcade37desc2 => ResourceManager.GetString("arcade37desc2", resourceCulture);

	internal static string arcade38 => ResourceManager.GetString("arcade38", resourceCulture);

	internal static string arcade38desc1 => ResourceManager.GetString("arcade38desc1", resourceCulture);

	internal static string arcade38desc2 => ResourceManager.GetString("arcade38desc2", resourceCulture);

	internal static string arcade39 => ResourceManager.GetString("arcade39", resourceCulture);

	internal static string arcade39desc1 => ResourceManager.GetString("arcade39desc1", resourceCulture);

	internal static string arcade39desc2 => ResourceManager.GetString("arcade39desc2", resourceCulture);

	internal static string arcade3desc1 => ResourceManager.GetString("arcade3desc1", resourceCulture);

	internal static string arcade3desc2 => ResourceManager.GetString("arcade3desc2", resourceCulture);

	internal static string arcade4 => ResourceManager.GetString("arcade4", resourceCulture);

	internal static string arcade40 => ResourceManager.GetString("arcade40", resourceCulture);

	internal static string arcade40desc1 => ResourceManager.GetString("arcade40desc1", resourceCulture);

	internal static string arcade40desc2 => ResourceManager.GetString("arcade40desc2", resourceCulture);

	internal static string arcade41 => ResourceManager.GetString("arcade41", resourceCulture);

	internal static string arcade41desc1 => ResourceManager.GetString("arcade41desc1", resourceCulture);

	internal static string arcade41desc2 => ResourceManager.GetString("arcade41desc2", resourceCulture);

	internal static string arcade42 => ResourceManager.GetString("arcade42", resourceCulture);

	internal static string arcade42desc1 => ResourceManager.GetString("arcade42desc1", resourceCulture);

	internal static string arcade42desc2 => ResourceManager.GetString("arcade42desc2", resourceCulture);

	internal static string arcade43 => ResourceManager.GetString("arcade43", resourceCulture);

	internal static string arcade43desc1 => ResourceManager.GetString("arcade43desc1", resourceCulture);

	internal static string arcade43desc2 => ResourceManager.GetString("arcade43desc2", resourceCulture);

	internal static string arcade44 => ResourceManager.GetString("arcade44", resourceCulture);

	internal static string arcade44desc1 => ResourceManager.GetString("arcade44desc1", resourceCulture);

	internal static string arcade44desc2 => ResourceManager.GetString("arcade44desc2", resourceCulture);

	internal static string arcade45 => ResourceManager.GetString("arcade45", resourceCulture);

	internal static string arcade45desc1 => ResourceManager.GetString("arcade45desc1", resourceCulture);

	internal static string arcade45desc2 => ResourceManager.GetString("arcade45desc2", resourceCulture);

	internal static string arcade46 => ResourceManager.GetString("arcade46", resourceCulture);

	internal static string arcade46desc1 => ResourceManager.GetString("arcade46desc1", resourceCulture);

	internal static string arcade46desc2 => ResourceManager.GetString("arcade46desc2", resourceCulture);

	internal static string arcade47 => ResourceManager.GetString("arcade47", resourceCulture);

	internal static string arcade47desc1 => ResourceManager.GetString("arcade47desc1", resourceCulture);

	internal static string arcade47desc2 => ResourceManager.GetString("arcade47desc2", resourceCulture);

	internal static string arcade48 => ResourceManager.GetString("arcade48", resourceCulture);

	internal static string arcade48desc1 => ResourceManager.GetString("arcade48desc1", resourceCulture);

	internal static string arcade48desc2 => ResourceManager.GetString("arcade48desc2", resourceCulture);

	internal static string arcade49 => ResourceManager.GetString("arcade49", resourceCulture);

	internal static string arcade49desc1 => ResourceManager.GetString("arcade49desc1", resourceCulture);

	internal static string arcade49desc2 => ResourceManager.GetString("arcade49desc2", resourceCulture);

	internal static string arcade4desc1 => ResourceManager.GetString("arcade4desc1", resourceCulture);

	internal static string arcade4desc2 => ResourceManager.GetString("arcade4desc2", resourceCulture);

	internal static string arcade5 => ResourceManager.GetString("arcade5", resourceCulture);

	internal static string arcade50 => ResourceManager.GetString("arcade50", resourceCulture);

	internal static string arcade50desc1 => ResourceManager.GetString("arcade50desc1", resourceCulture);

	internal static string arcade50desc2 => ResourceManager.GetString("arcade50desc2", resourceCulture);

	internal static string arcade5desc1 => ResourceManager.GetString("arcade5desc1", resourceCulture);

	internal static string arcade5desc2 => ResourceManager.GetString("arcade5desc2", resourceCulture);

	internal static string arcade6 => ResourceManager.GetString("arcade6", resourceCulture);

	internal static string arcade6desc1 => ResourceManager.GetString("arcade6desc1", resourceCulture);

	internal static string arcade6desc2 => ResourceManager.GetString("arcade6desc2", resourceCulture);

	internal static string arcade7 => ResourceManager.GetString("arcade7", resourceCulture);

	internal static string arcade7desc1 => ResourceManager.GetString("arcade7desc1", resourceCulture);

	internal static string arcade7desc2 => ResourceManager.GetString("arcade7desc2", resourceCulture);

	internal static string arcade8 => ResourceManager.GetString("arcade8", resourceCulture);

	internal static string arcade8desc1 => ResourceManager.GetString("arcade8desc1", resourceCulture);

	internal static string arcade8desc2 => ResourceManager.GetString("arcade8desc2", resourceCulture);

	internal static string arcade9 => ResourceManager.GetString("arcade9", resourceCulture);

	internal static string arcade9desc1 => ResourceManager.GetString("arcade9desc1", resourceCulture);

	internal static string arcade9desc2 => ResourceManager.GetString("arcade9desc2", resourceCulture);

	internal static string arcadeCoop => ResourceManager.GetString("arcadeCoop", resourceCulture);

	internal static string arcadeMode => ResourceManager.GetString("arcadeMode", resourceCulture);

	internal static string arcadeSolo => ResourceManager.GetString("arcadeSolo", resourceCulture);

	internal static string attack => ResourceManager.GetString("attack", resourceCulture);

	internal static string attackTut1 => ResourceManager.GetString("attackTut1", resourceCulture);

	internal static string attackTut2 => ResourceManager.GetString("attackTut2", resourceCulture);

	internal static string attackTut3 => ResourceManager.GetString("attackTut3", resourceCulture);

	internal static string attackTut4 => ResourceManager.GetString("attackTut4", resourceCulture);

	internal static string autosave1 => ResourceManager.GetString("autosave1", resourceCulture);

	internal static string autosave2 => ResourceManager.GetString("autosave2", resourceCulture);

	internal static string autosave3 => ResourceManager.GetString("autosave3", resourceCulture);

	internal static string availableGames => ResourceManager.GetString("availableGames", resourceCulture);

	internal static string back => ResourceManager.GetString("back", resourceCulture);

	internal static string banker_banker_0_text1_0_0 => ResourceManager.GetString("banker_banker_0_text1_0_0", resourceCulture);

	internal static string banker_banker_0_text2_1_0 => ResourceManager.GetString("banker_banker_0_text2_1_0", resourceCulture);

	internal static string banker_banker_0_text2_1_1 => ResourceManager.GetString("banker_banker_0_text2_1_1", resourceCulture);

	internal static string banker_banker_0_text3_2_0 => ResourceManager.GetString("banker_banker_0_text3_2_0", resourceCulture);

	internal static string banker_banker_0_text4_3_0 => ResourceManager.GetString("banker_banker_0_text4_3_0", resourceCulture);

	internal static string banker_banker_0_text4_3_1 => ResourceManager.GetString("banker_banker_0_text4_3_1", resourceCulture);

	internal static string banker_banker_0_text5_4_0 => ResourceManager.GetString("banker_banker_0_text5_4_0", resourceCulture);

	internal static string banker_banker_0_text6_5_0 => ResourceManager.GetString("banker_banker_0_text6_5_0", resourceCulture);

	internal static string banker_banker_0_text7_6_0 => ResourceManager.GetString("banker_banker_0_text7_6_0", resourceCulture);

	internal static string banker_banker_0_text7_6_1 => ResourceManager.GetString("banker_banker_0_text7_6_1", resourceCulture);

	internal static string banker_banker_0_text8_7_0 => ResourceManager.GetString("banker_banker_0_text8_7_0", resourceCulture);

	internal static string bankerdead_dead_0_text1_0_0 => ResourceManager.GetString("bankerdead_dead_0_text1_0_0", resourceCulture);

	internal static string bankerdead_dead_0_text2_1_0 => ResourceManager.GetString("bankerdead_dead_0_text2_1_0", resourceCulture);

	internal static string bankerdead_dead_0_text3_2_0 => ResourceManager.GetString("bankerdead_dead_0_text3_2_0", resourceCulture);

	internal static string bankerdead_dead_0_text4_3_0 => ResourceManager.GetString("bankerdead_dead_0_text4_3_0", resourceCulture);

	internal static string bankerdead_dead_0_text5_4_0 => ResourceManager.GetString("bankerdead_dead_0_text5_4_0", resourceCulture);

	internal static string bankerkill_banker_0_text1_0_0 => ResourceManager.GetString("bankerkill_banker_0_text1_0_0", resourceCulture);

	internal static string bankerkill_banker_0_text1_0_1 => ResourceManager.GetString("bankerkill_banker_0_text1_0_1", resourceCulture);

	internal static string bankerkill_banker_0_text2_1_0 => ResourceManager.GetString("bankerkill_banker_0_text2_1_0", resourceCulture);

	internal static string bankerkill_banker_0_text2_1_1 => ResourceManager.GetString("bankerkill_banker_0_text2_1_1", resourceCulture);

	internal static string bankerkill_banker_0_text3_2_0 => ResourceManager.GetString("bankerkill_banker_0_text3_2_0", resourceCulture);

	internal static string bankerkill_banker_0_text4_3_0 => ResourceManager.GetString("bankerkill_banker_0_text4_3_0", resourceCulture);

	internal static string bankerkill_banker_0_text5_4_0 => ResourceManager.GetString("bankerkill_banker_0_text5_4_0", resourceCulture);

	internal static string bankerkill_banker_0_text6_5_0 => ResourceManager.GetString("bankerkill_banker_0_text6_5_0", resourceCulture);

	internal static string bankerkill_banker_0_text6_5_1 => ResourceManager.GetString("bankerkill_banker_0_text6_5_1", resourceCulture);

	internal static string bankerkill_banker_0_text7_6_0 => ResourceManager.GetString("bankerkill_banker_0_text7_6_0", resourceCulture);

	internal static string baptised_baptised_0_text1_0_0 => ResourceManager.GetString("baptised_baptised_0_text1_0_0", resourceCulture);

	internal static string baptised_baptised_0_text2_1_0 => ResourceManager.GetString("baptised_baptised_0_text2_1_0", resourceCulture);

	internal static string baptised_baptised_0_text3_2_0 => ResourceManager.GetString("baptised_baptised_0_text3_2_0", resourceCulture);

	internal static string baptised_baptised_0_text4_3_0 => ResourceManager.GetString("baptised_baptised_0_text4_3_0", resourceCulture);

	internal static string batBead => ResourceManager.GetString("batBead", resourceCulture);

	internal static string batBeadDesc1 => ResourceManager.GetString("batBeadDesc1", resourceCulture);

	internal static string batBeadDesc2 => ResourceManager.GetString("batBeadDesc2", resourceCulture);

	internal static string bellBead => ResourceManager.GetString("bellBead", resourceCulture);

	internal static string bellBeadDesc1 => ResourceManager.GetString("bellBeadDesc1", resourceCulture);

	internal static string bgm => ResourceManager.GetString("bgm", resourceCulture);

	internal static string bgm0 => ResourceManager.GetString("bgm0", resourceCulture);

	internal static string bgm10 => ResourceManager.GetString("bgm10", resourceCulture);

	internal static string bgm100 => ResourceManager.GetString("bgm100", resourceCulture);

	internal static string bgm20 => ResourceManager.GetString("bgm20", resourceCulture);

	internal static string bgm30 => ResourceManager.GetString("bgm30", resourceCulture);

	internal static string bgm40 => ResourceManager.GetString("bgm40", resourceCulture);

	internal static string bgm50 => ResourceManager.GetString("bgm50", resourceCulture);

	internal static string bgm60 => ResourceManager.GetString("bgm60", resourceCulture);

	internal static string bgm70 => ResourceManager.GetString("bgm70", resourceCulture);

	internal static string bgm80 => ResourceManager.GetString("bgm80", resourceCulture);

	internal static string bgm90 => ResourceManager.GetString("bgm90", resourceCulture);

	internal static string blitz => ResourceManager.GetString("blitz", resourceCulture);

	internal static string blitz_desc1 => ResourceManager.GetString("blitz_desc1", resourceCulture);

	internal static string blitz_desc1a => ResourceManager.GetString("blitz_desc1a", resourceCulture);

	internal static string blitz_desc2 => ResourceManager.GetString("blitz_desc2", resourceCulture);

	internal static string blitz_desc2a => ResourceManager.GetString("blitz_desc2a", resourceCulture);

	internal static string blitz_desc3 => ResourceManager.GetString("blitz_desc3", resourceCulture);

	internal static string blitz_desc4 => ResourceManager.GetString("blitz_desc4", resourceCulture);

	internal static string bloodoff => ResourceManager.GetString("bloodoff", resourceCulture);

	internal static string bloodon => ResourceManager.GetString("bloodon", resourceCulture);

	internal static string boardroomKeycard => ResourceManager.GetString("boardroomKeycard", resourceCulture);

	internal static string boneBead => ResourceManager.GetString("boneBead", resourceCulture);

	internal static string boneBeadDesc1 => ResourceManager.GetString("boneBeadDesc1", resourceCulture);

	internal static string boneBeadDesc2 => ResourceManager.GetString("boneBeadDesc2", resourceCulture);

	internal static string brainBead => ResourceManager.GetString("brainBead", resourceCulture);

	internal static string brainBeadDesc1 => ResourceManager.GetString("brainBeadDesc1", resourceCulture);

	internal static string brainBeadDesc2 => ResourceManager.GetString("brainBeadDesc2", resourceCulture);

	internal static string bulletTime => ResourceManager.GetString("bulletTime", resourceCulture);

	internal static string bulletTime_desc1 => ResourceManager.GetString("bulletTime_desc1", resourceCulture);

	internal static string bulletTime_desc2 => ResourceManager.GetString("bulletTime_desc2", resourceCulture);

	internal static string bulletTime_desc3 => ResourceManager.GetString("bulletTime_desc3", resourceCulture);

	internal static string buy => ResourceManager.GetString("buy", resourceCulture);

	internal static string buy_msg_0 => ResourceManager.GetString("buy_msg_0", resourceCulture);

	internal static string buy_msg_1 => ResourceManager.GetString("buy_msg_1", resourceCulture);

	internal static string buy_msg_10 => ResourceManager.GetString("buy_msg_10", resourceCulture);

	internal static string buy_msg_11 => ResourceManager.GetString("buy_msg_11", resourceCulture);

	internal static string buy_msg_12 => ResourceManager.GetString("buy_msg_12", resourceCulture);

	internal static string buy_msg_13 => ResourceManager.GetString("buy_msg_13", resourceCulture);

	internal static string buy_msg_14 => ResourceManager.GetString("buy_msg_14", resourceCulture);

	internal static string buy_msg_15 => ResourceManager.GetString("buy_msg_15", resourceCulture);

	internal static string buy_msg_2 => ResourceManager.GetString("buy_msg_2", resourceCulture);

	internal static string buy_msg_3 => ResourceManager.GetString("buy_msg_3", resourceCulture);

	internal static string buy_msg_4 => ResourceManager.GetString("buy_msg_4", resourceCulture);

	internal static string buy_msg_5 => ResourceManager.GetString("buy_msg_5", resourceCulture);

	internal static string buy_msg_6 => ResourceManager.GetString("buy_msg_6", resourceCulture);

	internal static string buy_msg_7 => ResourceManager.GetString("buy_msg_7", resourceCulture);

	internal static string buy_msg_8 => ResourceManager.GetString("buy_msg_8", resourceCulture);

	internal static string buy_msg_9 => ResourceManager.GetString("buy_msg_9", resourceCulture);

	internal static string c_awesome => ResourceManager.GetString("c_awesome", resourceCulture);

	internal static string c_combo => ResourceManager.GetString("c_combo", resourceCulture);

	internal static string c_epic => ResourceManager.GetString("c_epic", resourceCulture);

	internal static string c_hardcore => ResourceManager.GetString("c_hardcore", resourceCulture);

	internal static string c_heavy => ResourceManager.GetString("c_heavy", resourceCulture);

	internal static string c_insane => ResourceManager.GetString("c_insane", resourceCulture);

	internal static string c_intense => ResourceManager.GetString("c_intense", resourceCulture);

	internal static string c_manic => ResourceManager.GetString("c_manic", resourceCulture);

	internal static string c_monstrous => ResourceManager.GetString("c_monstrous", resourceCulture);

	internal static string c_psychotic => ResourceManager.GetString("c_psychotic", resourceCulture);

	internal static string c_sick => ResourceManager.GetString("c_sick", resourceCulture);

	internal static string c_twisted => ResourceManager.GetString("c_twisted", resourceCulture);

	internal static string c_ultimate => ResourceManager.GetString("c_ultimate", resourceCulture);

	internal static string campaignUnlocked => ResourceManager.GetString("campaignUnlocked", resourceCulture);

	internal static string cancel => ResourceManager.GetString("cancel", resourceCulture);

	internal static string cantHost => ResourceManager.GetString("cantHost", resourceCulture);

	internal static string cantReadCorrupt1 => ResourceManager.GetString("cantReadCorrupt1", resourceCulture);

	internal static string cantReadLeaderboards => ResourceManager.GetString("cantReadLeaderboards", resourceCulture);

	internal static string cantUnlock => ResourceManager.GetString("cantUnlock", resourceCulture);

	internal static string cantWrite1 => ResourceManager.GetString("cantWrite1", resourceCulture);

	internal static string cantWrite2 => ResourceManager.GetString("cantWrite2", resourceCulture);

	internal static string cantWriteCorrupt1 => ResourceManager.GetString("cantWriteCorrupt1", resourceCulture);

	internal static string cantWriteCorrupt2 => ResourceManager.GetString("cantWriteCorrupt2", resourceCulture);

	internal static string cantWriteCorrupt3 => ResourceManager.GetString("cantWriteCorrupt3", resourceCulture);

	internal static string cantWriteCorrupt4 => ResourceManager.GetString("cantWriteCorrupt4", resourceCulture);

	internal static string cantWriteCorrupt5 => ResourceManager.GetString("cantWriteCorrupt5", resourceCulture);

	internal static string cantWriteStorage1 => ResourceManager.GetString("cantWriteStorage1", resourceCulture);

	internal static string cantWriteStorage2 => ResourceManager.GetString("cantWriteStorage2", resourceCulture);

	internal static string cantWriteStorage3 => ResourceManager.GetString("cantWriteStorage3", resourceCulture);

	internal static string catBead => ResourceManager.GetString("catBead", resourceCulture);

	internal static string catBeadDesc1 => ResourceManager.GetString("catBeadDesc1", resourceCulture);

	internal static string chainsawTut1 => ResourceManager.GetString("chainsawTut1", resourceCulture);

	internal static string chainsawTut2 => ResourceManager.GetString("chainsawTut2", resourceCulture);

	internal static string chainsawTut3 => ResourceManager.GetString("chainsawTut3", resourceCulture);

	internal static string chainsawTut4 => ResourceManager.GetString("chainsawTut4", resourceCulture);

	internal static string chainsawTut5 => ResourceManager.GetString("chainsawTut5", resourceCulture);

	internal static string chainsawTut6 => ResourceManager.GetString("chainsawTut6", resourceCulture);

	internal static string checkXboxLiveTry1 => ResourceManager.GetString("checkXboxLiveTry1", resourceCulture);

	internal static string checkXboxLiveTry2 => ResourceManager.GetString("checkXboxLiveTry2", resourceCulture);

	internal static string chef_yuki_chef_1_text1_0_0 => ResourceManager.GetString("chef_yuki_chef_1_text1_0_0", resourceCulture);

	internal static string chef_yuki_chef_1_text2_1_0 => ResourceManager.GetString("chef_yuki_chef_1_text2_1_0", resourceCulture);

	internal static string chef_yuki_chef_1_text2_1_1 => ResourceManager.GetString("chef_yuki_chef_1_text2_1_1", resourceCulture);

	internal static string chef_yuki_chef_1_text3_2_0 => ResourceManager.GetString("chef_yuki_chef_1_text3_2_0", resourceCulture);

	internal static string chef_yuki_chef_1_text3_2_1 => ResourceManager.GetString("chef_yuki_chef_1_text3_2_1", resourceCulture);

	internal static string chef_yuki_chef_1_text4_3_0 => ResourceManager.GetString("chef_yuki_chef_1_text4_3_0", resourceCulture);

	internal static string chef_yuki_chef_1_text4_3_1 => ResourceManager.GetString("chef_yuki_chef_1_text4_3_1", resourceCulture);

	internal static string chef_yuki_chef_3_text1_0_0 => ResourceManager.GetString("chef_yuki_chef_3_text1_0_0", resourceCulture);

	internal static string chef_yuki_chef_3_text2_1_0 => ResourceManager.GetString("chef_yuki_chef_3_text2_1_0", resourceCulture);

	internal static string chef_yuki_chef_3_text2_1_1 => ResourceManager.GetString("chef_yuki_chef_3_text2_1_1", resourceCulture);

	internal static string chef_yuki_chef_3_text3_2_0 => ResourceManager.GetString("chef_yuki_chef_3_text3_2_0", resourceCulture);

	internal static string chef_yuki_chef_3_text4_3_0 => ResourceManager.GetString("chef_yuki_chef_3_text4_3_0", resourceCulture);

	internal static string chef_yuki_chef_3_text4_3_1 => ResourceManager.GetString("chef_yuki_chef_3_text4_3_1", resourceCulture);

	internal static string chef_yuki_chef_3_text5_4_0 => ResourceManager.GetString("chef_yuki_chef_3_text5_4_0", resourceCulture);

	internal static string chef_yuki_chef_3_text5_4_1 => ResourceManager.GetString("chef_yuki_chef_3_text5_4_1", resourceCulture);

	internal static string chef_yuki_chef_3_text6_6_0 => ResourceManager.GetString("chef_yuki_chef_3_text6_6_0", resourceCulture);

	internal static string chef_yuki_chef_3_text6_6_1 => ResourceManager.GetString("chef_yuki_chef_3_text6_6_1", resourceCulture);

	internal static string chef_yuki_chef_5_text1_0_0 => ResourceManager.GetString("chef_yuki_chef_5_text1_0_0", resourceCulture);

	internal static string chef_yuki_chef_5_text1_0_1 => ResourceManager.GetString("chef_yuki_chef_5_text1_0_1", resourceCulture);

	internal static string chef_yuki_chef_5_text2_1_0 => ResourceManager.GetString("chef_yuki_chef_5_text2_1_0", resourceCulture);

	internal static string chef_yuki_chef_5_text2_1_1 => ResourceManager.GetString("chef_yuki_chef_5_text2_1_1", resourceCulture);

	internal static string chef_yuki_chef_5_text3_2_0 => ResourceManager.GetString("chef_yuki_chef_5_text3_2_0", resourceCulture);

	internal static string chef_yuki_chef_5_text4_3_0 => ResourceManager.GetString("chef_yuki_chef_5_text4_3_0", resourceCulture);

	internal static string chef_yuki_yuki_0_text1_0_0 => ResourceManager.GetString("chef_yuki_yuki_0_text1_0_0", resourceCulture);

	internal static string chef_yuki_yuki_0_text2_1_0 => ResourceManager.GetString("chef_yuki_yuki_0_text2_1_0", resourceCulture);

	internal static string chef_yuki_yuki_0_text2_1_1 => ResourceManager.GetString("chef_yuki_yuki_0_text2_1_1", resourceCulture);

	internal static string chef_yuki_yuki_0_text3_2_0 => ResourceManager.GetString("chef_yuki_yuki_0_text3_2_0", resourceCulture);

	internal static string chef_yuki_yuki_0_text3_2_1 => ResourceManager.GetString("chef_yuki_yuki_0_text3_2_1", resourceCulture);

	internal static string chef_yuki_yuki_0_text4_3_0 => ResourceManager.GetString("chef_yuki_yuki_0_text4_3_0", resourceCulture);

	internal static string chef_yuki_yuki_0_text4_3_1 => ResourceManager.GetString("chef_yuki_yuki_0_text4_3_1", resourceCulture);

	internal static string chef_yuki_yuki_2_text1_0_0 => ResourceManager.GetString("chef_yuki_yuki_2_text1_0_0", resourceCulture);

	internal static string chef_yuki_yuki_2_text2_1_0 => ResourceManager.GetString("chef_yuki_yuki_2_text2_1_0", resourceCulture);

	internal static string chef_yuki_yuki_2_text2_1_1 => ResourceManager.GetString("chef_yuki_yuki_2_text2_1_1", resourceCulture);

	internal static string chef_yuki_yuki_2_text3_2_0 => ResourceManager.GetString("chef_yuki_yuki_2_text3_2_0", resourceCulture);

	internal static string chef_yuki_yuki_2_text4_3_0 => ResourceManager.GetString("chef_yuki_yuki_2_text4_3_0", resourceCulture);

	internal static string chef_yuki_yuki_2_text4_3_1 => ResourceManager.GetString("chef_yuki_yuki_2_text4_3_1", resourceCulture);

	internal static string chef_yuki_yuki_4_text1_0_0 => ResourceManager.GetString("chef_yuki_yuki_4_text1_0_0", resourceCulture);

	internal static string chef_yuki_yuki_4_text2_1_0 => ResourceManager.GetString("chef_yuki_yuki_4_text2_1_0", resourceCulture);

	internal static string chef_yuki_yuki_4_text2_1_1 => ResourceManager.GetString("chef_yuki_yuki_4_text2_1_1", resourceCulture);

	internal static string chef_yuki_yuki_4_text3_2_0 => ResourceManager.GetString("chef_yuki_yuki_4_text3_2_0", resourceCulture);

	internal static string chef_yuki_yuki_4_text4_3_0 => ResourceManager.GetString("chef_yuki_yuki_4_text4_3_0", resourceCulture);

	internal static string chef_yuki_yuki_4_text4_3_1 => ResourceManager.GetString("chef_yuki_yuki_4_text4_3_1", resourceCulture);

	internal static string chef_yuki_yuki_4_text4_3_2 => ResourceManager.GetString("chef_yuki_yuki_4_text4_3_2", resourceCulture);

	internal static string claws => ResourceManager.GetString("claws", resourceCulture);

	internal static string claws_airBarrage => ResourceManager.GetString("claws_airBarrage", resourceCulture);

	internal static string claws_bloodhawk => ResourceManager.GetString("claws_bloodhawk", resourceCulture);

	internal static string claws_clawBarrage => ResourceManager.GetString("claws_clawBarrage", resourceCulture);

	internal static string claws_corkscrew => ResourceManager.GetString("claws_corkscrew", resourceCulture);

	internal static string claws_creatureKick => ResourceManager.GetString("claws_creatureKick", resourceCulture);

	internal static string claws_feralSplit => ResourceManager.GetString("claws_feralSplit", resourceCulture);

	internal static string claws_rager => ResourceManager.GetString("claws_rager", resourceCulture);

	internal static string cleavers => ResourceManager.GetString("cleavers", resourceCulture);

	internal static string cleavers_aerator => ResourceManager.GetString("cleavers_aerator", resourceCulture);

	internal static string cleavers_aerialEight => ResourceManager.GetString("cleavers_aerialEight", resourceCulture);

	internal static string cleavers_birdOfPrey => ResourceManager.GetString("cleavers_birdOfPrey", resourceCulture);

	internal static string cleavers_cleaverBlast => ResourceManager.GetString("cleavers_cleaverBlast", resourceCulture);

	internal static string cleavers_cleaverDrop => ResourceManager.GetString("cleavers_cleaverDrop", resourceCulture);

	internal static string cleavers_cleaverHackNSlash => ResourceManager.GetString("cleavers_cleaverHackNSlash", resourceCulture);

	internal static string cleavers_cleaverKill => ResourceManager.GetString("cleavers_cleaverKill", resourceCulture);

	internal static string cleavers_crossedEight => ResourceManager.GetString("cleavers_crossedEight", resourceCulture);

	internal static string cleavers_crossSlash => ResourceManager.GetString("cleavers_crossSlash", resourceCulture);

	internal static string cleavers_dishiuken => ResourceManager.GetString("cleavers_dishiuken", resourceCulture);

	internal static string cleavers_dishkick => ResourceManager.GetString("cleavers_dishkick", resourceCulture);

	internal static string cleavers_dishKickCombo => ResourceManager.GetString("cleavers_dishKickCombo", resourceCulture);

	internal static string cleavers_finisher => ResourceManager.GetString("cleavers_finisher", resourceCulture);

	internal static string cleavers_kitchenSploder => ResourceManager.GetString("cleavers_kitchenSploder", resourceCulture);

	internal static string cleavers_ochodishiuken => ResourceManager.GetString("cleavers_ochodishiuken", resourceCulture);

	internal static string cleavers_ochoSlam => ResourceManager.GetString("cleavers_ochoSlam", resourceCulture);

	internal static string cleavers_perfectChop => ResourceManager.GetString("cleavers_perfectChop", resourceCulture);

	internal static string cleavers_rollingBlades => ResourceManager.GetString("cleavers_rollingBlades", resourceCulture);

	internal static string cleavers_rollingLaunch => ResourceManager.GetString("cleavers_rollingLaunch", resourceCulture);

	internal static string cleavers_trickyDishKick => ResourceManager.GetString("cleavers_trickyDishKick", resourceCulture);

	internal static string clientQuit => ResourceManager.GetString("clientQuit", resourceCulture);

	internal static string close => ResourceManager.GetString("close", resourceCulture);

	internal static string cloud_arcBlade => ResourceManager.GetString("cloud_arcBlade", resourceCulture);

	internal static string cloud_bloodGeyser => ResourceManager.GetString("cloud_bloodGeyser", resourceCulture);

	internal static string cloud_bloodHurricane => ResourceManager.GetString("cloud_bloodHurricane", resourceCulture);

	internal static string cloud_chaosFlood => ResourceManager.GetString("cloud_chaosFlood", resourceCulture);

	internal static string cloud_doomingStorm => ResourceManager.GetString("cloud_doomingStorm", resourceCulture);

	internal static string cloud_finalCut => ResourceManager.GetString("cloud_finalCut", resourceCulture);

	internal static string cloud_heavyCut => ResourceManager.GetString("cloud_heavyCut", resourceCulture);

	internal static string cloud_hurricane => ResourceManager.GetString("cloud_hurricane", resourceCulture);

	internal static string cloud_lightningSpear => ResourceManager.GetString("cloud_lightningSpear", resourceCulture);

	internal static string cloud_metalSky => ResourceManager.GetString("cloud_metalSky", resourceCulture);

	internal static string cloud_righteousShockwave => ResourceManager.GetString("cloud_righteousShockwave", resourceCulture);

	internal static string cloud_risingTyphoon => ResourceManager.GetString("cloud_risingTyphoon", resourceCulture);

	internal static string cloud_skyBlade => ResourceManager.GetString("cloud_skyBlade", resourceCulture);

	internal static string cloud_thunderCrash => ResourceManager.GetString("cloud_thunderCrash", resourceCulture);

	internal static string cloud_thunderSpear => ResourceManager.GetString("cloud_thunderSpear", resourceCulture);

	internal static string cloud_visceraStorm => ResourceManager.GetString("cloud_visceraStorm", resourceCulture);

	internal static string cloudBead => ResourceManager.GetString("cloudBead", resourceCulture);

	internal static string cloudBeadDesc1 => ResourceManager.GetString("cloudBeadDesc1", resourceCulture);

	internal static string cloudBeadDesc2 => ResourceManager.GetString("cloudBeadDesc2", resourceCulture);

	internal static string cloudSword => ResourceManager.GetString("cloudSword", resourceCulture);

	internal static string cloudSwordUpgradeDesc1 => ResourceManager.GetString("cloudSwordUpgradeDesc1", resourceCulture);

	internal static string cloudTut1 => ResourceManager.GetString("cloudTut1", resourceCulture);

	internal static string cloudTut10 => ResourceManager.GetString("cloudTut10", resourceCulture);

	internal static string cloudTut2 => ResourceManager.GetString("cloudTut2", resourceCulture);

	internal static string cloudTut3 => ResourceManager.GetString("cloudTut3", resourceCulture);

	internal static string cloudTut4 => ResourceManager.GetString("cloudTut4", resourceCulture);

	internal static string cloudTut5 => ResourceManager.GetString("cloudTut5", resourceCulture);

	internal static string cloudTut6 => ResourceManager.GetString("cloudTut6", resourceCulture);

	internal static string cloudTut7 => ResourceManager.GetString("cloudTut7", resourceCulture);

	internal static string cloudTut8 => ResourceManager.GetString("cloudTut8", resourceCulture);

	internal static string cloudTut9 => ResourceManager.GetString("cloudTut9", resourceCulture);

	internal static string cloudyTut1 => ResourceManager.GetString("cloudyTut1", resourceCulture);

	internal static string cloudyTut2 => ResourceManager.GetString("cloudyTut2", resourceCulture);

	internal static string cloudyTut3 => ResourceManager.GetString("cloudyTut3", resourceCulture);

	internal static string cloudyTut4 => ResourceManager.GetString("cloudyTut4", resourceCulture);

	internal static string cloudyTut5 => ResourceManager.GetString("cloudyTut5", resourceCulture);

	internal static string colorKeys => ResourceManager.GetString("colorKeys", resourceCulture);

	internal static string colorKeys_desc1 => ResourceManager.GetString("colorKeys_desc1", resourceCulture);

	internal static string colorKeys_desc2 => ResourceManager.GetString("colorKeys_desc2", resourceCulture);

	internal static string colorKeys_desc3 => ResourceManager.GetString("colorKeys_desc3", resourceCulture);

	internal static string commsKey => ResourceManager.GetString("commsKey", resourceCulture);

	internal static string concition_vultureBarrage => ResourceManager.GetString("concition_vultureBarrage", resourceCulture);

	internal static string connecting => ResourceManager.GetString("connecting", resourceCulture);

	internal static string continues => ResourceManager.GetString("continues", resourceCulture);

	internal static string continueWithoutSaving => ResourceManager.GetString("continueWithoutSaving", resourceCulture);

	internal static string contrastBead => ResourceManager.GetString("contrastBead", resourceCulture);

	internal static string contrastBeadDesc1 => ResourceManager.GetString("contrastBeadDesc1", resourceCulture);

	internal static string contrastBeadDesc2 => ResourceManager.GetString("contrastBeadDesc2", resourceCulture);

	internal static string controllerDisconnected => ResourceManager.GetString("controllerDisconnected", resourceCulture);

	internal static string controllerDisconnected1 => ResourceManager.GetString("controllerDisconnected1", resourceCulture);

	internal static string controllerDisconnected2 => ResourceManager.GetString("controllerDisconnected2", resourceCulture);

	internal static string controls => ResourceManager.GetString("controls", resourceCulture);

	internal static string conviction => ResourceManager.GetString("conviction", resourceCulture);

	internal static string conviction_bloodAngel => ResourceManager.GetString("conviction_bloodAngel", resourceCulture);

	internal static string conviction_gallowsSlash => ResourceManager.GetString("conviction_gallowsSlash", resourceCulture);

	internal static string conviction_impalerSlash => ResourceManager.GetString("conviction_impalerSlash", resourceCulture);

	internal static string conviction_machineBlast => ResourceManager.GetString("conviction_machineBlast", resourceCulture);

	internal static string conviction_machineScatter => ResourceManager.GetString("conviction_machineScatter", resourceCulture);

	internal static string conviction_metalBarrage => ResourceManager.GetString("conviction_metalBarrage", resourceCulture);

	internal static string conviction_murderBarrage => ResourceManager.GetString("conviction_murderBarrage", resourceCulture);

	internal static string conviction_murderGrab => ResourceManager.GetString("conviction_murderGrab", resourceCulture);

	internal static string conviction_severSlash => ResourceManager.GetString("conviction_severSlash", resourceCulture);

	internal static string conviction_sickLaunch => ResourceManager.GetString("conviction_sickLaunch", resourceCulture);

	internal static string conviction_skewerDrop => ResourceManager.GetString("conviction_skewerDrop", resourceCulture);

	internal static string conviction_skewerSlash => ResourceManager.GetString("conviction_skewerSlash", resourceCulture);

	internal static string conviction_vultureBarrage => ResourceManager.GetString("conviction_vultureBarrage", resourceCulture);

	internal static string conviction_vultureGrab => ResourceManager.GetString("conviction_vultureGrab", resourceCulture);

	internal static string conviction_vultureSmash => ResourceManager.GetString("conviction_vultureSmash", resourceCulture);

	internal static string convictionUpgradeDesc1 => ResourceManager.GetString("convictionUpgradeDesc1", resourceCulture);

	internal static string coop_mask_dish_1_text1_0_0 => ResourceManager.GetString("coop_mask_dish_1_text1_0_0", resourceCulture);

	internal static string coop_mask_dish_1_text1_0_1 => ResourceManager.GetString("coop_mask_dish_1_text1_0_1", resourceCulture);

	internal static string coop_mask_dish_1_text2_1_0 => ResourceManager.GetString("coop_mask_dish_1_text2_1_0", resourceCulture);

	internal static string coop_mask_dish_1_text2_1_1 => ResourceManager.GetString("coop_mask_dish_1_text2_1_1", resourceCulture);

	internal static string coop_mask_dish_1_text3_2_0 => ResourceManager.GetString("coop_mask_dish_1_text3_2_0", resourceCulture);

	internal static string coop_mask_dish_1_text4_3_0 => ResourceManager.GetString("coop_mask_dish_1_text4_3_0", resourceCulture);

	internal static string coop_mask_dish_1_text4_3_1 => ResourceManager.GetString("coop_mask_dish_1_text4_3_1", resourceCulture);

	internal static string coop_mask_dish_1_text5_4_0 => ResourceManager.GetString("coop_mask_dish_1_text5_4_0", resourceCulture);

	internal static string coop_mask_dish_1_text5_4_1 => ResourceManager.GetString("coop_mask_dish_1_text5_4_1", resourceCulture);

	internal static string coop_mask_mask_0_text1_0_0 => ResourceManager.GetString("coop_mask_mask_0_text1_0_0", resourceCulture);

	internal static string coop_mask_mask_0_text2_1_0 => ResourceManager.GetString("coop_mask_mask_0_text2_1_0", resourceCulture);

	internal static string coop_mask_mask_0_text3_2_0 => ResourceManager.GetString("coop_mask_mask_0_text3_2_0", resourceCulture);

	internal static string coop_mask_mask_0_text4_3_0 => ResourceManager.GetString("coop_mask_mask_0_text4_3_0", resourceCulture);

	internal static string coop_puppets_puppet_0_text1_0_0 => ResourceManager.GetString("coop_puppets_puppet_0_text1_0_0", resourceCulture);

	internal static string coop_puppets_puppet_0_text2_1_0 => ResourceManager.GetString("coop_puppets_puppet_0_text2_1_0", resourceCulture);

	internal static string coop_puppets_puppet_0_text3_2_0 => ResourceManager.GetString("coop_puppets_puppet_0_text3_2_0", resourceCulture);

	internal static string coop_puppets_puppet_0_text4_3_0 => ResourceManager.GetString("coop_puppets_puppet_0_text4_3_0", resourceCulture);

	internal static string coop_start_dish_1_text1_0_0 => ResourceManager.GetString("coop_start_dish_1_text1_0_0", resourceCulture);

	internal static string coop_start_dish_1_text2_1_0 => ResourceManager.GetString("coop_start_dish_1_text2_1_0", resourceCulture);

	internal static string coop_start_dish_1_text2_1_1 => ResourceManager.GetString("coop_start_dish_1_text2_1_1", resourceCulture);

	internal static string coop_start_dish_1_text3_2_0 => ResourceManager.GetString("coop_start_dish_1_text3_2_0", resourceCulture);

	internal static string coop_start_dish_1_text4_3_0 => ResourceManager.GetString("coop_start_dish_1_text4_3_0", resourceCulture);

	internal static string coop_start_dish_1_text5_4_0 => ResourceManager.GetString("coop_start_dish_1_text5_4_0", resourceCulture);

	internal static string coop_start_dish_1_text5_4_1 => ResourceManager.GetString("coop_start_dish_1_text5_4_1", resourceCulture);

	internal static string coop_start_dish_1_text6_5_0 => ResourceManager.GetString("coop_start_dish_1_text6_5_0", resourceCulture);

	internal static string coop_start_dish_1_text7_6_0 => ResourceManager.GetString("coop_start_dish_1_text7_6_0", resourceCulture);

	internal static string coop_start_yuki_0_text1_0_0 => ResourceManager.GetString("coop_start_yuki_0_text1_0_0", resourceCulture);

	internal static string coop_start_yuki_0_text2_1_0 => ResourceManager.GetString("coop_start_yuki_0_text2_1_0", resourceCulture);

	internal static string coop_start_yuki_0_text2_1_1 => ResourceManager.GetString("coop_start_yuki_0_text2_1_1", resourceCulture);

	internal static string coop_start_yuki_0_text3_2_0 => ResourceManager.GetString("coop_start_yuki_0_text3_2_0", resourceCulture);

	internal static string coop_start_yuki_0_text3_2_1 => ResourceManager.GetString("coop_start_yuki_0_text3_2_1", resourceCulture);

	internal static string coop_start_yuki_0_text4_3_0 => ResourceManager.GetString("coop_start_yuki_0_text4_3_0", resourceCulture);

	internal static string coop_start_yuki_0_text5_4_0 => ResourceManager.GetString("coop_start_yuki_0_text5_4_0", resourceCulture);

	internal static string coop_start_yuki_0_text6_5_0 => ResourceManager.GetString("coop_start_yuki_0_text6_5_0", resourceCulture);

	internal static string coop_start_yuki_2_text1_0_0 => ResourceManager.GetString("coop_start_yuki_2_text1_0_0", resourceCulture);

	internal static string coop_start_yuki_2_text2_1_0 => ResourceManager.GetString("coop_start_yuki_2_text2_1_0", resourceCulture);

	internal static string coop_start_yuki_2_text3_2_0 => ResourceManager.GetString("coop_start_yuki_2_text3_2_0", resourceCulture);

	internal static string coop_start_yuki_2_text4_3_0 => ResourceManager.GetString("coop_start_yuki_2_text4_3_0", resourceCulture);

	internal static string coopStory => ResourceManager.GetString("coopStory", resourceCulture);

	internal static string coopyTut1 => ResourceManager.GetString("coopyTut1", resourceCulture);

	internal static string coopyTut2 => ResourceManager.GetString("coopyTut2", resourceCulture);

	internal static string coopyTut3 => ResourceManager.GetString("coopyTut3", resourceCulture);

	internal static string coopyTut4 => ResourceManager.GetString("coopyTut4", resourceCulture);

	internal static string coopyTut5 => ResourceManager.GetString("coopyTut5", resourceCulture);

	internal static string coopyTut6 => ResourceManager.GetString("coopyTut6", resourceCulture);

	internal static string coopyTut7 => ResourceManager.GetString("coopyTut7", resourceCulture);

	internal static string coopyTut8 => ResourceManager.GetString("coopyTut8", resourceCulture);

	internal static string couldNotDisposeNetworkSession => ResourceManager.GetString("couldNotDisposeNetworkSession", resourceCulture);

	internal static string couldNotJoinSession => ResourceManager.GetString("couldNotJoinSession", resourceCulture);

	internal static string couldntRead1 => ResourceManager.GetString("couldntRead1", resourceCulture);

	internal static string couldntRead2 => ResourceManager.GetString("couldntRead2", resourceCulture);

	internal static string crackingSkulls => ResourceManager.GetString("crackingSkulls", resourceCulture);

	internal static string crackingSkulls_desc1 => ResourceManager.GetString("crackingSkulls_desc1", resourceCulture);

	internal static string crackingSkulls_desc2 => ResourceManager.GetString("crackingSkulls_desc2", resourceCulture);

	internal static string crackingSkulls_desc3 => ResourceManager.GetString("crackingSkulls_desc3", resourceCulture);

	internal static string crackingSkulls_desc4 => ResourceManager.GetString("crackingSkulls_desc4", resourceCulture);

	internal static string createPrivateMatch => ResourceManager.GetString("createPrivateMatch", resourceCulture);

	internal static string createPublicMatch => ResourceManager.GetString("createPublicMatch", resourceCulture);

	internal static string credits => ResourceManager.GetString("credits", resourceCulture);

	internal static string credits_art => ResourceManager.GetString("credits_art", resourceCulture);

	internal static string credits_by => ResourceManager.GetString("credits_by", resourceCulture);

	internal static string credits_contribs => ResourceManager.GetString("credits_contribs", resourceCulture);

	internal static string credits_leadDishwasher => ResourceManager.GetString("credits_leadDishwasher", resourceCulture);

	internal static string credits_mkting => ResourceManager.GetString("credits_mkting", resourceCulture);

	internal static string credits_named => ResourceManager.GetString("credits_named", resourceCulture);

	internal static string credits_neuromancer => ResourceManager.GetString("credits_neuromancer", resourceCulture);

	internal static string credits_ska => ResourceManager.GetString("credits_ska", resourceCulture);

	internal static string credits_special => ResourceManager.GetString("credits_special", resourceCulture);

	internal static string credits_thanks => ResourceManager.GetString("credits_thanks", resourceCulture);

	internal static string credits_voiceYuki => ResourceManager.GetString("credits_voiceYuki", resourceCulture);

	internal static string creditsTitle1 => ResourceManager.GetString("creditsTitle1", resourceCulture);

	internal static string creditsTitle2 => ResourceManager.GetString("creditsTitle2", resourceCulture);

	internal static string crossBead => ResourceManager.GetString("crossBead", resourceCulture);

	internal static string crossBeadDesc1 => ResourceManager.GetString("crossBeadDesc1", resourceCulture);

	internal static string crossBeadDesc2 => ResourceManager.GetString("crossBeadDesc2", resourceCulture);

	internal static string crownBead => ResourceManager.GetString("crownBead", resourceCulture);

	internal static string crownBeadDesc1 => ResourceManager.GetString("crownBeadDesc1", resourceCulture);

	internal static string crownBeadDesc2 => ResourceManager.GetString("crownBeadDesc2", resourceCulture);

	internal static string customMatch => ResourceManager.GetString("customMatch", resourceCulture);

	internal static string debug => ResourceManager.GetString("debug", resourceCulture);

	internal static string dekkentozter => ResourceManager.GetString("dekkentozter", resourceCulture);

	internal static string dekkentozterUpgradeDesc1 => ResourceManager.GetString("dekkentozterUpgradeDesc1", resourceCulture);

	internal static string demon_dead_asylum_0_text1_0_0 => ResourceManager.GetString("demon_dead_asylum_0_text1_0_0", resourceCulture);

	internal static string demon_dead_asylum_0_text2_1_0 => ResourceManager.GetString("demon_dead_asylum_0_text2_1_0", resourceCulture);

	internal static string demon_dead_asylum_0_text3_2_0 => ResourceManager.GetString("demon_dead_asylum_0_text3_2_0", resourceCulture);

	internal static string demon_dead_asylum_0_text4_3_0 => ResourceManager.GetString("demon_dead_asylum_0_text4_3_0", resourceCulture);

	internal static string devouringBloodMagic => ResourceManager.GetString("devouringBloodMagic", resourceCulture);

	internal static string devouringBloodMagicTut1 => ResourceManager.GetString("devouringBloodMagicTut1", resourceCulture);

	internal static string devouringBloodMagicTut2 => ResourceManager.GetString("devouringBloodMagicTut2", resourceCulture);

	internal static string devouringBloodMagicTut3 => ResourceManager.GetString("devouringBloodMagicTut3", resourceCulture);

	internal static string devouringBloodMagicTut4 => ResourceManager.GetString("devouringBloodMagicTut4", resourceCulture);

	internal static string devouringBloodMagicTut5 => ResourceManager.GetString("devouringBloodMagicTut5", resourceCulture);

	internal static string devouringBloodMagicTut6 => ResourceManager.GetString("devouringBloodMagicTut6", resourceCulture);

	internal static string devouringBloodMagicTut7 => ResourceManager.GetString("devouringBloodMagicTut7", resourceCulture);

	internal static string devouringBloodMagicTut8 => ResourceManager.GetString("devouringBloodMagicTut8", resourceCulture);

	internal static string devouringDishMagic => ResourceManager.GetString("devouringDishMagic", resourceCulture);

	internal static string devouringDishMagicTut1 => ResourceManager.GetString("devouringDishMagicTut1", resourceCulture);

	internal static string devouringDishMagicTut2 => ResourceManager.GetString("devouringDishMagicTut2", resourceCulture);

	internal static string devouringDishMagicTut3 => ResourceManager.GetString("devouringDishMagicTut3", resourceCulture);

	internal static string devouringDishMagicTut4 => ResourceManager.GetString("devouringDishMagicTut4", resourceCulture);

	internal static string devouringDishMagicTut5 => ResourceManager.GetString("devouringDishMagicTut5", resourceCulture);

	internal static string devouringDishMagicTut6 => ResourceManager.GetString("devouringDishMagicTut6", resourceCulture);

	internal static string devouringDishMagicTut7 => ResourceManager.GetString("devouringDishMagicTut7", resourceCulture);

	internal static string devouringDishMagicTut8 => ResourceManager.GetString("devouringDishMagicTut8", resourceCulture);

	internal static string difficultyUnlocked => ResourceManager.GetString("difficultyUnlocked", resourceCulture);

	internal static string disconnectedFromGame => ResourceManager.GetString("disconnectedFromGame", resourceCulture);

	internal static string disconnectedFromXboxLive => ResourceManager.GetString("disconnectedFromXboxLive", resourceCulture);

	internal static string dish_aqua_dish_0_text_0_0 => ResourceManager.GetString("dish_aqua_dish_0_text_0_0", resourceCulture);

	internal static string dish_aqua_dish_0_text_0_1 => ResourceManager.GetString("dish_aqua_dish_0_text_0_1", resourceCulture);

	internal static string dish_aqua_dish_0_text_1_0 => ResourceManager.GetString("dish_aqua_dish_0_text_1_0", resourceCulture);

	internal static string dish_aqua_dish_0_text_1_1 => ResourceManager.GetString("dish_aqua_dish_0_text_1_1", resourceCulture);

	internal static string dish_aqua_dish_0_text_2_0 => ResourceManager.GetString("dish_aqua_dish_0_text_2_0", resourceCulture);

	internal static string dish_aqua_dish_0_text_3_0 => ResourceManager.GetString("dish_aqua_dish_0_text_3_0", resourceCulture);

	internal static string dish_aqua_dish_0_text_3_1 => ResourceManager.GetString("dish_aqua_dish_0_text_3_1", resourceCulture);

	internal static string dish_aqua_dish_0_text_4_0 => ResourceManager.GetString("dish_aqua_dish_0_text_4_0", resourceCulture);

	internal static string dish_aqua_dish_0_text_5_0 => ResourceManager.GetString("dish_aqua_dish_0_text_5_0", resourceCulture);

	internal static string dish_cache_dish_0_text1_0_0 => ResourceManager.GetString("dish_cache_dish_0_text1_0_0", resourceCulture);

	internal static string dish_cache_dish_0_text2_1_0 => ResourceManager.GetString("dish_cache_dish_0_text2_1_0", resourceCulture);

	internal static string dish_cache_dish_0_text2_1_1 => ResourceManager.GetString("dish_cache_dish_0_text2_1_1", resourceCulture);

	internal static string dish_cache_dish_0_text3_2_0 => ResourceManager.GetString("dish_cache_dish_0_text3_2_0", resourceCulture);

	internal static string dish_cache_dish_0_text3_2_1 => ResourceManager.GetString("dish_cache_dish_0_text3_2_1", resourceCulture);

	internal static string dish_cache_dish_0_text4_3_0 => ResourceManager.GetString("dish_cache_dish_0_text4_3_0", resourceCulture);

	internal static string dish_cache_dish_0_text4_3_1 => ResourceManager.GetString("dish_cache_dish_0_text4_3_1", resourceCulture);

	internal static string dish_cache_dish_0_text5_4_0 => ResourceManager.GetString("dish_cache_dish_0_text5_4_0", resourceCulture);

	internal static string dish_cafe_dish_0_text1_0_0 => ResourceManager.GetString("dish_cafe_dish_0_text1_0_0", resourceCulture);

	internal static string dish_cafe_dish_0_text2_1_0 => ResourceManager.GetString("dish_cafe_dish_0_text2_1_0", resourceCulture);

	internal static string dish_cafe_dish_0_text3_2_0 => ResourceManager.GetString("dish_cafe_dish_0_text3_2_0", resourceCulture);

	internal static string dish_cafe_dish_0_text5_3_0 => ResourceManager.GetString("dish_cafe_dish_0_text5_3_0", resourceCulture);

	internal static string dish_chef_chef_1_text1_0_0 => ResourceManager.GetString("dish_chef_chef_1_text1_0_0", resourceCulture);

	internal static string dish_chef_chef_1_text2_1_0 => ResourceManager.GetString("dish_chef_chef_1_text2_1_0", resourceCulture);

	internal static string dish_chef_chef_1_text2_1_1 => ResourceManager.GetString("dish_chef_chef_1_text2_1_1", resourceCulture);

	internal static string dish_chef_chef_1_text3_2_0 => ResourceManager.GetString("dish_chef_chef_1_text3_2_0", resourceCulture);

	internal static string dish_chef_chef_1_text3_2_1 => ResourceManager.GetString("dish_chef_chef_1_text3_2_1", resourceCulture);

	internal static string dish_chef_chef_1_text4_3_0 => ResourceManager.GetString("dish_chef_chef_1_text4_3_0", resourceCulture);

	internal static string dish_chef_chef_1_text4_3_1 => ResourceManager.GetString("dish_chef_chef_1_text4_3_1", resourceCulture);

	internal static string dish_chef_chef_3_text1_0_0 => ResourceManager.GetString("dish_chef_chef_3_text1_0_0", resourceCulture);

	internal static string dish_chef_chef_3_text1_0_1 => ResourceManager.GetString("dish_chef_chef_3_text1_0_1", resourceCulture);

	internal static string dish_chef_chef_3_text1_0_2 => ResourceManager.GetString("dish_chef_chef_3_text1_0_2", resourceCulture);

	internal static string dish_chef_chef_3_text2_1_0 => ResourceManager.GetString("dish_chef_chef_3_text2_1_0", resourceCulture);

	internal static string dish_chef_chef_3_text2_1_1 => ResourceManager.GetString("dish_chef_chef_3_text2_1_1", resourceCulture);

	internal static string dish_chef_chef_3_text3_2_0 => ResourceManager.GetString("dish_chef_chef_3_text3_2_0", resourceCulture);

	internal static string dish_chef_chef_3_text3_2_1 => ResourceManager.GetString("dish_chef_chef_3_text3_2_1", resourceCulture);

	internal static string dish_chef_chef_3_text4_3_0 => ResourceManager.GetString("dish_chef_chef_3_text4_3_0", resourceCulture);

	internal static string dish_chef_chef_5_text1_0_0 => ResourceManager.GetString("dish_chef_chef_5_text1_0_0", resourceCulture);

	internal static string dish_chef_chef_5_text1_0_1 => ResourceManager.GetString("dish_chef_chef_5_text1_0_1", resourceCulture);

	internal static string dish_chef_chef_5_text2_1_0 => ResourceManager.GetString("dish_chef_chef_5_text2_1_0", resourceCulture);

	internal static string dish_chef_chef_5_text2_1_1 => ResourceManager.GetString("dish_chef_chef_5_text2_1_1", resourceCulture);

	internal static string dish_chef_chef_5_text3_2_0 => ResourceManager.GetString("dish_chef_chef_5_text3_2_0", resourceCulture);

	internal static string dish_chef_chef_5_text3_2_1 => ResourceManager.GetString("dish_chef_chef_5_text3_2_1", resourceCulture);

	internal static string dish_chef_chef_5_text4_3_0 => ResourceManager.GetString("dish_chef_chef_5_text4_3_0", resourceCulture);

	internal static string dish_chef_chef_5_text4_3_1 => ResourceManager.GetString("dish_chef_chef_5_text4_3_1", resourceCulture);

	internal static string dish_chef_chef_5_text5_4_0 => ResourceManager.GetString("dish_chef_chef_5_text5_4_0", resourceCulture);

	internal static string dish_chef_chef_5_text5_4_1 => ResourceManager.GetString("dish_chef_chef_5_text5_4_1", resourceCulture);

	internal static string dish_chef_dish_0_text1_0_0 => ResourceManager.GetString("dish_chef_dish_0_text1_0_0", resourceCulture);

	internal static string dish_chef_dish_0_text2_1_0 => ResourceManager.GetString("dish_chef_dish_0_text2_1_0", resourceCulture);

	internal static string dish_chef_dish_0_text2_1_1 => ResourceManager.GetString("dish_chef_dish_0_text2_1_1", resourceCulture);

	internal static string dish_chef_dish_0_text3_2_0 => ResourceManager.GetString("dish_chef_dish_0_text3_2_0", resourceCulture);

	internal static string dish_chef_dish_0_text3_2_1 => ResourceManager.GetString("dish_chef_dish_0_text3_2_1", resourceCulture);

	internal static string dish_chef_dish_0_text4_3_0 => ResourceManager.GetString("dish_chef_dish_0_text4_3_0", resourceCulture);

	internal static string dish_chef_dish_0_text4_3_1 => ResourceManager.GetString("dish_chef_dish_0_text4_3_1", resourceCulture);

	internal static string dish_chef_dish_2_text1_0_0 => ResourceManager.GetString("dish_chef_dish_2_text1_0_0", resourceCulture);

	internal static string dish_chef_dish_2_text2_1_0 => ResourceManager.GetString("dish_chef_dish_2_text2_1_0", resourceCulture);

	internal static string dish_chef_dish_2_text2_1_1 => ResourceManager.GetString("dish_chef_dish_2_text2_1_1", resourceCulture);

	internal static string dish_chef_dish_2_text3_2_0 => ResourceManager.GetString("dish_chef_dish_2_text3_2_0", resourceCulture);

	internal static string dish_chef_dish_2_text3_2_1 => ResourceManager.GetString("dish_chef_dish_2_text3_2_1", resourceCulture);

	internal static string dish_chef_dish_4_text1_0_0 => ResourceManager.GetString("dish_chef_dish_4_text1_0_0", resourceCulture);

	internal static string dish_chef_dish_4_text2_1_0 => ResourceManager.GetString("dish_chef_dish_4_text2_1_0", resourceCulture);

	internal static string dish_chef_dish_4_text2_1_1 => ResourceManager.GetString("dish_chef_dish_4_text2_1_1", resourceCulture);

	internal static string dish_chef_dish_6_text1_0_0 => ResourceManager.GetString("dish_chef_dish_6_text1_0_0", resourceCulture);

	internal static string dish_chef_dish_6_text2_1_0 => ResourceManager.GetString("dish_chef_dish_6_text2_1_0", resourceCulture);

	internal static string dish_chef_dish_6_text3_2_0 => ResourceManager.GetString("dish_chef_dish_6_text3_2_0", resourceCulture);

	internal static string dish_crypt_dish_0_text1_0_0 => ResourceManager.GetString("dish_crypt_dish_0_text1_0_0", resourceCulture);

	internal static string dish_crypt_dish_0_text2_1_0 => ResourceManager.GetString("dish_crypt_dish_0_text2_1_0", resourceCulture);

	internal static string dish_crypt_dish_0_text3_2_0 => ResourceManager.GetString("dish_crypt_dish_0_text3_2_0", resourceCulture);

	internal static string dish_crypt_dish_0_text3_2_1 => ResourceManager.GetString("dish_crypt_dish_0_text3_2_1", resourceCulture);

	internal static string dish_crypt_dish_0_text4_3_0 => ResourceManager.GetString("dish_crypt_dish_0_text4_3_0", resourceCulture);

	internal static string dish_crypt_dish_0_text5_4_0 => ResourceManager.GetString("dish_crypt_dish_0_text5_4_0", resourceCulture);

	internal static string dish_crypt_dish_0_text6_5_0 => ResourceManager.GetString("dish_crypt_dish_0_text6_5_0", resourceCulture);

	internal static string dish_crypt_dish_0_text6_5_1 => ResourceManager.GetString("dish_crypt_dish_0_text6_5_1", resourceCulture);

	internal static string dish_dark_dish_0_text1_0_0 => ResourceManager.GetString("dish_dark_dish_0_text1_0_0", resourceCulture);

	internal static string dish_dark_dish_0_text2_1_0 => ResourceManager.GetString("dish_dark_dish_0_text2_1_0", resourceCulture);

	internal static string dish_dark_dish_0_text2_1_1 => ResourceManager.GetString("dish_dark_dish_0_text2_1_1", resourceCulture);

	internal static string dish_dark_dish_0_text3_2_0 => ResourceManager.GetString("dish_dark_dish_0_text3_2_0", resourceCulture);

	internal static string dish_dark_dish_0_text4_3_0 => ResourceManager.GetString("dish_dark_dish_0_text4_3_0", resourceCulture);

	internal static string dish_dark_dish_0_text4_3_1 => ResourceManager.GetString("dish_dark_dish_0_text4_3_1", resourceCulture);

	internal static string dish_engie_engie_0_text1_0_0 => ResourceManager.GetString("dish_engie_engie_0_text1_0_0", resourceCulture);

	internal static string dish_engie_engie_0_text1_0_1 => ResourceManager.GetString("dish_engie_engie_0_text1_0_1", resourceCulture);

	internal static string dish_engie_engie_0_text2_1_0 => ResourceManager.GetString("dish_engie_engie_0_text2_1_0", resourceCulture);

	internal static string dish_engie_engie_0_text3_2_0 => ResourceManager.GetString("dish_engie_engie_0_text3_2_0", resourceCulture);

	internal static string dish_engie_engie_0_text3_2_1 => ResourceManager.GetString("dish_engie_engie_0_text3_2_1", resourceCulture);

	internal static string dish_engie_engie_0_text4_3_0 => ResourceManager.GetString("dish_engie_engie_0_text4_3_0", resourceCulture);

	internal static string dish_engie_engie_0_text4_3_1 => ResourceManager.GetString("dish_engie_engie_0_text4_3_1", resourceCulture);

	internal static string dish_engie_engie_0_text5_4_0 => ResourceManager.GetString("dish_engie_engie_0_text5_4_0", resourceCulture);

	internal static string dish_engie_engie_0_text6_5_0 => ResourceManager.GetString("dish_engie_engie_0_text6_5_0", resourceCulture);

	internal static string dish_general_dish_0_text_0_0 => ResourceManager.GetString("dish_general_dish_0_text_0_0", resourceCulture);

	internal static string dish_general_dish_0_text_0_1 => ResourceManager.GetString("dish_general_dish_0_text_0_1", resourceCulture);

	internal static string dish_general_dish_0_text_1_0 => ResourceManager.GetString("dish_general_dish_0_text_1_0", resourceCulture);

	internal static string dish_general_dish_0_text_2_0 => ResourceManager.GetString("dish_general_dish_0_text_2_0", resourceCulture);

	internal static string dish_general_dish_0_text_3_0 => ResourceManager.GetString("dish_general_dish_0_text_3_0", resourceCulture);

	internal static string dish_general_dish_0_text_4_0 => ResourceManager.GetString("dish_general_dish_0_text_4_0", resourceCulture);

	internal static string dish_gross_gross_0_text1_0_0 => ResourceManager.GetString("dish_gross_gross_0_text1_0_0", resourceCulture);

	internal static string dish_gross_gross_0_text1_0_1 => ResourceManager.GetString("dish_gross_gross_0_text1_0_1", resourceCulture);

	internal static string dish_gross_gross_0_text2_1_0 => ResourceManager.GetString("dish_gross_gross_0_text2_1_0", resourceCulture);

	internal static string dish_gross_gross_0_text3_2_0 => ResourceManager.GetString("dish_gross_gross_0_text3_2_0", resourceCulture);

	internal static string dish_gross_gross_0_text3_2_1 => ResourceManager.GetString("dish_gross_gross_0_text3_2_1", resourceCulture);

	internal static string dish_gross_gross_0_text4_3_0 => ResourceManager.GetString("dish_gross_gross_0_text4_3_0", resourceCulture);

	internal static string dish_gross_gross_0_text4_3_1 => ResourceManager.GetString("dish_gross_gross_0_text4_3_1", resourceCulture);

	internal static string dish_gross_gross_0_text5_4_0 => ResourceManager.GetString("dish_gross_gross_0_text5_4_0", resourceCulture);

	internal static string dish_gross_gross_0_text6_5_0 => ResourceManager.GetString("dish_gross_gross_0_text6_5_0", resourceCulture);

	internal static string dish_hockey_hockey_0_text_0_0 => ResourceManager.GetString("dish_hockey_hockey_0_text_0_0", resourceCulture);

	internal static string dish_hockey_hockey_0_text_0_1 => ResourceManager.GetString("dish_hockey_hockey_0_text_0_1", resourceCulture);

	internal static string dish_hockey_hockey_0_text_1_0 => ResourceManager.GetString("dish_hockey_hockey_0_text_1_0", resourceCulture);

	internal static string dish_hockey_hockey_0_text_1_1 => ResourceManager.GetString("dish_hockey_hockey_0_text_1_1", resourceCulture);

	internal static string dish_hockey_hockey_0_text_2_0 => ResourceManager.GetString("dish_hockey_hockey_0_text_2_0", resourceCulture);

	internal static string dish_hockey_hockey_0_text_3_0 => ResourceManager.GetString("dish_hockey_hockey_0_text_3_0", resourceCulture);

	internal static string dish_hockey_hockey_0_text_3_1 => ResourceManager.GetString("dish_hockey_hockey_0_text_3_1", resourceCulture);

	internal static string dish_hockey_hockey_0_text_4_0 => ResourceManager.GetString("dish_hockey_hockey_0_text_4_0", resourceCulture);

	internal static string dish_hockey_hockey_0_text_5_0 => ResourceManager.GetString("dish_hockey_hockey_0_text_5_0", resourceCulture);

	internal static string dish_judge_done_0_text1_0_0 => ResourceManager.GetString("dish_judge_done_0_text1_0_0", resourceCulture);

	internal static string dish_judge_done_0_text2_1_0 => ResourceManager.GetString("dish_judge_done_0_text2_1_0", resourceCulture);

	internal static string dish_judge_done_0_text2_1_1 => ResourceManager.GetString("dish_judge_done_0_text2_1_1", resourceCulture);

	internal static string dish_judge_done_0_text3_2_0 => ResourceManager.GetString("dish_judge_done_0_text3_2_0", resourceCulture);

	internal static string dish_judge_done_0_text3_2_1 => ResourceManager.GetString("dish_judge_done_0_text3_2_1", resourceCulture);

	internal static string dish_judge_done_0_text4_3_0 => ResourceManager.GetString("dish_judge_done_0_text4_3_0", resourceCulture);

	internal static string dish_judge_done_0_text4_3_1 => ResourceManager.GetString("dish_judge_done_0_text4_3_1", resourceCulture);

	internal static string dish_judge_done_0_text5_4_0 => ResourceManager.GetString("dish_judge_done_0_text5_4_0", resourceCulture);

	internal static string dish_judge_done_0_text6_5_0 => ResourceManager.GetString("dish_judge_done_0_text6_5_0", resourceCulture);

	internal static string dish_judge_judge_1_text1_0_0 => ResourceManager.GetString("dish_judge_judge_1_text1_0_0", resourceCulture);

	internal static string dish_judge_judge_1_text1_0_1 => ResourceManager.GetString("dish_judge_judge_1_text1_0_1", resourceCulture);

	internal static string dish_judge_judge_1_text2_1_0 => ResourceManager.GetString("dish_judge_judge_1_text2_1_0", resourceCulture);

	internal static string dish_judge_judge_1_text2_1_1 => ResourceManager.GetString("dish_judge_judge_1_text2_1_1", resourceCulture);

	internal static string dish_judge_judge_1_text3_2_0 => ResourceManager.GetString("dish_judge_judge_1_text3_2_0", resourceCulture);

	internal static string dish_judge_judge_1_text4_3_0 => ResourceManager.GetString("dish_judge_judge_1_text4_3_0", resourceCulture);

	internal static string dish_judge_judge_1_text5_4_0 => ResourceManager.GetString("dish_judge_judge_1_text5_4_0", resourceCulture);

	internal static string dish_judge_judge_1_text6_5_0 => ResourceManager.GetString("dish_judge_judge_1_text6_5_0", resourceCulture);

	internal static string dish_judge_judge_1_text7_6_0 => ResourceManager.GetString("dish_judge_judge_1_text7_6_0", resourceCulture);

	internal static string dish_lobby_dish_0_text1_0_0 => ResourceManager.GetString("dish_lobby_dish_0_text1_0_0", resourceCulture);

	internal static string dish_lobby_dish_0_text2_1_0 => ResourceManager.GetString("dish_lobby_dish_0_text2_1_0", resourceCulture);

	internal static string dish_lobby_dish_0_text2_1_1 => ResourceManager.GetString("dish_lobby_dish_0_text2_1_1", resourceCulture);

	internal static string dish_lobby_dish_0_text3_2_0 => ResourceManager.GetString("dish_lobby_dish_0_text3_2_0", resourceCulture);

	internal static string dish_lobby_dish_0_text4_3_0 => ResourceManager.GetString("dish_lobby_dish_0_text4_3_0", resourceCulture);

	internal static string dish_lobby_dish_0_text4_3_1 => ResourceManager.GetString("dish_lobby_dish_0_text4_3_1", resourceCulture);

	internal static string dish_lobby_dish_0_text5_4_0 => ResourceManager.GetString("dish_lobby_dish_0_text5_4_0", resourceCulture);

	internal static string dish_lobby_dish_0_text6_5_0 => ResourceManager.GetString("dish_lobby_dish_0_text6_5_0", resourceCulture);

	internal static string dish_mask_dish_1_text1_0_0 => ResourceManager.GetString("dish_mask_dish_1_text1_0_0", resourceCulture);

	internal static string dish_mask_dish_1_text1_0_1 => ResourceManager.GetString("dish_mask_dish_1_text1_0_1", resourceCulture);

	internal static string dish_mask_dish_1_text2_1_0 => ResourceManager.GetString("dish_mask_dish_1_text2_1_0", resourceCulture);

	internal static string dish_mask_dish_1_text2_1_1 => ResourceManager.GetString("dish_mask_dish_1_text2_1_1", resourceCulture);

	internal static string dish_mask_dish_1_text3_2_0 => ResourceManager.GetString("dish_mask_dish_1_text3_2_0", resourceCulture);

	internal static string dish_mask_dish_1_text4_3_0 => ResourceManager.GetString("dish_mask_dish_1_text4_3_0", resourceCulture);

	internal static string dish_mask_dish_1_text4_3_1 => ResourceManager.GetString("dish_mask_dish_1_text4_3_1", resourceCulture);

	internal static string dish_mask_dish_1_text5_4_0 => ResourceManager.GetString("dish_mask_dish_1_text5_4_0", resourceCulture);

	internal static string dish_mask_mask_0_text1_0_0 => ResourceManager.GetString("dish_mask_mask_0_text1_0_0", resourceCulture);

	internal static string dish_mask_mask_0_text2_1_0 => ResourceManager.GetString("dish_mask_mask_0_text2_1_0", resourceCulture);

	internal static string dish_mask_mask_0_text2_1_1 => ResourceManager.GetString("dish_mask_mask_0_text2_1_1", resourceCulture);

	internal static string dish_mask_mask_0_text3_2_0 => ResourceManager.GetString("dish_mask_mask_0_text3_2_0", resourceCulture);

	internal static string dish_mask_mask_0_text4_3_0 => ResourceManager.GetString("dish_mask_mask_0_text4_3_0", resourceCulture);

	internal static string dish_puppets_puppet_0_text1_0_0 => ResourceManager.GetString("dish_puppets_puppet_0_text1_0_0", resourceCulture);

	internal static string dish_puppets_puppet_0_text2_1_0 => ResourceManager.GetString("dish_puppets_puppet_0_text2_1_0", resourceCulture);

	internal static string dish_puppets_puppet_0_text3_2_0 => ResourceManager.GetString("dish_puppets_puppet_0_text3_2_0", resourceCulture);

	internal static string dish_puppets_puppet_0_text4_3_0 => ResourceManager.GetString("dish_puppets_puppet_0_text4_3_0", resourceCulture);

	internal static string dish_rgb_dish_0_text1_0_0 => ResourceManager.GetString("dish_rgb_dish_0_text1_0_0", resourceCulture);

	internal static string dish_rgb_dish_0_text1_0_1 => ResourceManager.GetString("dish_rgb_dish_0_text1_0_1", resourceCulture);

	internal static string dish_rgb_dish_0_text2_1_0 => ResourceManager.GetString("dish_rgb_dish_0_text2_1_0", resourceCulture);

	internal static string dish_rgb_dish_0_text2_1_1 => ResourceManager.GetString("dish_rgb_dish_0_text2_1_1", resourceCulture);

	internal static string dish_rgb_dish_0_text3_2_0 => ResourceManager.GetString("dish_rgb_dish_0_text3_2_0", resourceCulture);

	internal static string dish_rgb_dish_0_text4_3_0 => ResourceManager.GetString("dish_rgb_dish_0_text4_3_0", resourceCulture);

	internal static string dish_rgb_dish_0_text4_3_1 => ResourceManager.GetString("dish_rgb_dish_0_text4_3_1", resourceCulture);

	internal static string dish_rgb_dish_0_text5_4_0 => ResourceManager.GetString("dish_rgb_dish_0_text5_4_0", resourceCulture);

	internal static string dish_rgb_dish_0_text6_5_0 => ResourceManager.GetString("dish_rgb_dish_0_text6_5_0", resourceCulture);

	internal static string dish_rgb_dish_0_text7_6_0 => ResourceManager.GetString("dish_rgb_dish_0_text7_6_0", resourceCulture);

	internal static string dish_slava_dish_0_text1_0_0 => ResourceManager.GetString("dish_slava_dish_0_text1_0_0", resourceCulture);

	internal static string dish_slava_dish_0_text2_1_0 => ResourceManager.GetString("dish_slava_dish_0_text2_1_0", resourceCulture);

	internal static string dish_slava_dish_0_text3_2_0 => ResourceManager.GetString("dish_slava_dish_0_text3_2_0", resourceCulture);

	internal static string dish_slava_dish_0_text4_3_0 => ResourceManager.GetString("dish_slava_dish_0_text4_3_0", resourceCulture);

	internal static string dish_slava_dish_0_text4_3_1 => ResourceManager.GetString("dish_slava_dish_0_text4_3_1", resourceCulture);

	internal static string dish_slava_dish_0_text5_4_0 => ResourceManager.GetString("dish_slava_dish_0_text5_4_0", resourceCulture);

	internal static string dish_slava_dish_0_text6_5_0 => ResourceManager.GetString("dish_slava_dish_0_text6_5_0", resourceCulture);

	internal static string dish_start_dish_1_text1_0_0 => ResourceManager.GetString("dish_start_dish_1_text1_0_0", resourceCulture);

	internal static string dish_start_dish_1_text1_0_1 => ResourceManager.GetString("dish_start_dish_1_text1_0_1", resourceCulture);

	internal static string dish_start_dish_1_text2_1_0 => ResourceManager.GetString("dish_start_dish_1_text2_1_0", resourceCulture);

	internal static string dish_start_dish_1_text2_1_1 => ResourceManager.GetString("dish_start_dish_1_text2_1_1", resourceCulture);

	internal static string dish_start_dish_1_text3_2_0 => ResourceManager.GetString("dish_start_dish_1_text3_2_0", resourceCulture);

	internal static string dish_start_dish_1_text4_3_0 => ResourceManager.GetString("dish_start_dish_1_text4_3_0", resourceCulture);

	internal static string dish_start_dish_1_text4_3_1 => ResourceManager.GetString("dish_start_dish_1_text4_3_1", resourceCulture);

	internal static string dish_start_dish_1_text5_4_0 => ResourceManager.GetString("dish_start_dish_1_text5_4_0", resourceCulture);

	internal static string dish_start_dish_1_text6_5_0 => ResourceManager.GetString("dish_start_dish_1_text6_5_0", resourceCulture);

	internal static string dish_start_moon_0_text1_0_0 => ResourceManager.GetString("dish_start_moon_0_text1_0_0", resourceCulture);

	internal static string dish_start_moon_0_text2_1_0 => ResourceManager.GetString("dish_start_moon_0_text2_1_0", resourceCulture);

	internal static string dish_start_moon_0_text3_2_0 => ResourceManager.GetString("dish_start_moon_0_text3_2_0", resourceCulture);

	internal static string dish_start_moon_0_text3_2_1 => ResourceManager.GetString("dish_start_moon_0_text3_2_1", resourceCulture);

	internal static string dish_start_moon_0_text4_3_0 => ResourceManager.GetString("dish_start_moon_0_text4_3_0", resourceCulture);

	internal static string dish_start_moon_0_text4_3_1 => ResourceManager.GetString("dish_start_moon_0_text4_3_1", resourceCulture);

	internal static string dish_start_moon_0_text5_4_0 => ResourceManager.GetString("dish_start_moon_0_text5_4_0", resourceCulture);

	internal static string dish_start_moon_0_text6_5_0 => ResourceManager.GetString("dish_start_moon_0_text6_5_0", resourceCulture);

	internal static string dish_start_moon_0_text6_5_1 => ResourceManager.GetString("dish_start_moon_0_text6_5_1", resourceCulture);

	internal static string dish_yuki_dish_1_text1_0_0 => ResourceManager.GetString("dish_yuki_dish_1_text1_0_0", resourceCulture);

	internal static string dish_yuki_dish_1_text2_1_0 => ResourceManager.GetString("dish_yuki_dish_1_text2_1_0", resourceCulture);

	internal static string dish_yuki_dish_1_text3_2_0 => ResourceManager.GetString("dish_yuki_dish_1_text3_2_0", resourceCulture);

	internal static string dish_yuki_dish_1_text4_3_0 => ResourceManager.GetString("dish_yuki_dish_1_text4_3_0", resourceCulture);

	internal static string dish_yuki_dish_1_text5_4_0 => ResourceManager.GetString("dish_yuki_dish_1_text5_4_0", resourceCulture);

	internal static string dish_yuki_dish_1_text6_5_0 => ResourceManager.GetString("dish_yuki_dish_1_text6_5_0", resourceCulture);

	internal static string dish_yuki_dish_1_text7_6_0 => ResourceManager.GetString("dish_yuki_dish_1_text7_6_0", resourceCulture);

	internal static string dish_yuki_yuki_0_text1_0_0 => ResourceManager.GetString("dish_yuki_yuki_0_text1_0_0", resourceCulture);

	internal static string dish_yuki_yuki_0_text2_1_0 => ResourceManager.GetString("dish_yuki_yuki_0_text2_1_0", resourceCulture);

	internal static string dish_yuki_yuki_0_text3_2_0 => ResourceManager.GetString("dish_yuki_yuki_0_text3_2_0", resourceCulture);

	internal static string dish_yuki_yuki_0_text4_3_0 => ResourceManager.GetString("dish_yuki_yuki_0_text4_3_0", resourceCulture);

	internal static string dish_yuki_yuki_0_text5_4_0 => ResourceManager.GetString("dish_yuki_yuki_0_text5_4_0", resourceCulture);

	internal static string dish_yuki_yuki_0_text6_5_0 => ResourceManager.GetString("dish_yuki_yuki_0_text6_5_0", resourceCulture);

	internal static string dish_yuki_yuki_2_text1_0_0 => ResourceManager.GetString("dish_yuki_yuki_2_text1_0_0", resourceCulture);

	internal static string dish_yuki_yuki_2_text2_1_0 => ResourceManager.GetString("dish_yuki_yuki_2_text2_1_0", resourceCulture);

	internal static string dish_yuki_yuki_2_text3_2_0 => ResourceManager.GetString("dish_yuki_yuki_2_text3_2_0", resourceCulture);

	internal static string dish_yuki_yuki_2_text3_2_1 => ResourceManager.GetString("dish_yuki_yuki_2_text3_2_1", resourceCulture);

	internal static string dish_yuki_yuki_2_text4_3_0 => ResourceManager.GetString("dish_yuki_yuki_2_text4_3_0", resourceCulture);

	internal static string dish_yuki_yuki_2_text4_3_1 => ResourceManager.GetString("dish_yuki_yuki_2_text4_3_1", resourceCulture);

	internal static string dish_yuki_yuki_2_text5_4_0 => ResourceManager.GetString("dish_yuki_yuki_2_text5_4_0", resourceCulture);

	internal static string dish_yuki_yuki_2_text5_4_1 => ResourceManager.GetString("dish_yuki_yuki_2_text5_4_1", resourceCulture);

	internal static string dishChallenge => ResourceManager.GetString("dishChallenge", resourceCulture);

	internal static string dishChallengeDesc => ResourceManager.GetString("dishChallengeDesc", resourceCulture);

	internal static string dishisdead_chef_1_text1_0_0 => ResourceManager.GetString("dishisdead_chef_1_text1_0_0", resourceCulture);

	internal static string dishisdead_chef_1_text2_1_0 => ResourceManager.GetString("dishisdead_chef_1_text2_1_0", resourceCulture);

	internal static string dishisdead_chef_1_text3_2_0 => ResourceManager.GetString("dishisdead_chef_1_text3_2_0", resourceCulture);

	internal static string dishisdead_chef_3_text1_0_0 => ResourceManager.GetString("dishisdead_chef_3_text1_0_0", resourceCulture);

	internal static string dishisdead_chef_3_text1_0_1 => ResourceManager.GetString("dishisdead_chef_3_text1_0_1", resourceCulture);

	internal static string dishisdead_chef_3_text2_1_0 => ResourceManager.GetString("dishisdead_chef_3_text2_1_0", resourceCulture);

	internal static string dishisdead_chef_3_text2_1_1 => ResourceManager.GetString("dishisdead_chef_3_text2_1_1", resourceCulture);

	internal static string dishisdead_chef_3_text3_2_0 => ResourceManager.GetString("dishisdead_chef_3_text3_2_0", resourceCulture);

	internal static string dishisdead_chef_3_text3_2_1 => ResourceManager.GetString("dishisdead_chef_3_text3_2_1", resourceCulture);

	internal static string dishisdead_chef_3_text4_3_0 => ResourceManager.GetString("dishisdead_chef_3_text4_3_0", resourceCulture);

	internal static string dishisdead_chef_3_text5_4_0 => ResourceManager.GetString("dishisdead_chef_3_text5_4_0", resourceCulture);

	internal static string dishisdead_chef_5_text1_0_0 => ResourceManager.GetString("dishisdead_chef_5_text1_0_0", resourceCulture);

	internal static string dishisdead_chef_5_text2_1_0 => ResourceManager.GetString("dishisdead_chef_5_text2_1_0", resourceCulture);

	internal static string dishisdead_chef_5_text2_1_1 => ResourceManager.GetString("dishisdead_chef_5_text2_1_1", resourceCulture);

	internal static string dishisdead_chef_5_text3_2_0 => ResourceManager.GetString("dishisdead_chef_5_text3_2_0", resourceCulture);

	internal static string dishisdead_chef_5_text4_3_0 => ResourceManager.GetString("dishisdead_chef_5_text4_3_0", resourceCulture);

	internal static string dishisdead_chef_5_text4_3_1 => ResourceManager.GetString("dishisdead_chef_5_text4_3_1", resourceCulture);

	internal static string dishisdead_chef_5_text5_4_0 => ResourceManager.GetString("dishisdead_chef_5_text5_4_0", resourceCulture);

	internal static string dishisdead_chef_5_text6_5_0 => ResourceManager.GetString("dishisdead_chef_5_text6_5_0", resourceCulture);

	internal static string dishisdead_chef_5_text6_5_1 => ResourceManager.GetString("dishisdead_chef_5_text6_5_1", resourceCulture);

	internal static string dishisdead_chef_5_text7_6_0 => ResourceManager.GetString("dishisdead_chef_5_text7_6_0", resourceCulture);

	internal static string dishisdead_chef_5_text7_6_1 => ResourceManager.GetString("dishisdead_chef_5_text7_6_1", resourceCulture);

	internal static string dishisdead_chef_5_text8_7_0 => ResourceManager.GetString("dishisdead_chef_5_text8_7_0", resourceCulture);

	internal static string dishisdead_yuki_0_talk1_4_0 => ResourceManager.GetString("dishisdead_yuki_0_talk1_4_0", resourceCulture);

	internal static string dishisdead_yuki_0_text1_0_0 => ResourceManager.GetString("dishisdead_yuki_0_text1_0_0", resourceCulture);

	internal static string dishisdead_yuki_0_text2_1_0 => ResourceManager.GetString("dishisdead_yuki_0_text2_1_0", resourceCulture);

	internal static string dishisdead_yuki_0_text3_2_0 => ResourceManager.GetString("dishisdead_yuki_0_text3_2_0", resourceCulture);

	internal static string dishisdead_yuki_0_text4_3_0 => ResourceManager.GetString("dishisdead_yuki_0_text4_3_0", resourceCulture);

	internal static string dishisdead_yuki_2_text1_0_0 => ResourceManager.GetString("dishisdead_yuki_2_text1_0_0", resourceCulture);

	internal static string dishisdead_yuki_2_text2_1_0 => ResourceManager.GetString("dishisdead_yuki_2_text2_1_0", resourceCulture);

	internal static string dishisdead_yuki_2_text2_1_1 => ResourceManager.GetString("dishisdead_yuki_2_text2_1_1", resourceCulture);

	internal static string dishisdead_yuki_2_text3_2_0 => ResourceManager.GetString("dishisdead_yuki_2_text3_2_0", resourceCulture);

	internal static string dishisdead_yuki_2_text3_2_1 => ResourceManager.GetString("dishisdead_yuki_2_text3_2_1", resourceCulture);

	internal static string dishisdead_yuki_2_text4_3_0 => ResourceManager.GetString("dishisdead_yuki_2_text4_3_0", resourceCulture);

	internal static string dishisdead_yuki_2_text5_4_0 => ResourceManager.GetString("dishisdead_yuki_2_text5_4_0", resourceCulture);

	internal static string dishisdead_yuki_2_text5_4_1 => ResourceManager.GetString("dishisdead_yuki_2_text5_4_1", resourceCulture);

	internal static string dishisdead_yuki_4_text1_0_0 => ResourceManager.GetString("dishisdead_yuki_4_text1_0_0", resourceCulture);

	internal static string dishisdead_yuki_4_text1_0_1 => ResourceManager.GetString("dishisdead_yuki_4_text1_0_1", resourceCulture);

	internal static string dishisdead_yuki_4_text2_1_0 => ResourceManager.GetString("dishisdead_yuki_4_text2_1_0", resourceCulture);

	internal static string dishisdead_yuki_4_text3_2_0 => ResourceManager.GetString("dishisdead_yuki_4_text3_2_0", resourceCulture);

	internal static string dishisdead_yuki_6_text1_0_0 => ResourceManager.GetString("dishisdead_yuki_6_text1_0_0", resourceCulture);

	internal static string dishisdead_yuki_6_text2_1_0 => ResourceManager.GetString("dishisdead_yuki_6_text2_1_0", resourceCulture);

	internal static string dishisdead_yuki_6_text3_2_0 => ResourceManager.GetString("dishisdead_yuki_6_text3_2_0", resourceCulture);

	internal static string dishisdead_yuki_6_text4_3_0 => ResourceManager.GetString("dishisdead_yuki_6_text4_3_0", resourceCulture);

	internal static string e_damage => ResourceManager.GetString("e_damage", resourceCulture);

	internal static string e_kills => ResourceManager.GetString("e_kills", resourceCulture);

	internal static string e_levelComplete => ResourceManager.GetString("e_levelComplete", resourceCulture);

	internal static string e_maxCombo => ResourceManager.GetString("e_maxCombo", resourceCulture);

	internal static string e_score => ResourceManager.GetString("e_score", resourceCulture);

	internal static string e_time => ResourceManager.GetString("e_time", resourceCulture);

	internal static string easy => ResourceManager.GetString("easy", resourceCulture);

	internal static string eb_1_Attack => ResourceManager.GetString("eb_1_Attack", resourceCulture);

	internal static string eb_1_Continue => ResourceManager.GetString("eb_1_Continue", resourceCulture);

	internal static string eb_1_Grab => ResourceManager.GetString("eb_1_Grab", resourceCulture);

	internal static string eb_2_Attack => ResourceManager.GetString("eb_2_Attack", resourceCulture);

	internal static string eb_2_Dodge => ResourceManager.GetString("eb_2_Dodge", resourceCulture);

	internal static string eb_3_UseDishMagic => ResourceManager.GetString("eb_3_UseDishMagic", resourceCulture);

	internal static string eb_attacked1 => ResourceManager.GetString("eb_attacked1", resourceCulture);

	internal static string eb_attacked2 => ResourceManager.GetString("eb_attacked2", resourceCulture);

	internal static string eb_attacked3 => ResourceManager.GetString("eb_attacked3", resourceCulture);

	internal static string eb_baddodged1 => ResourceManager.GetString("eb_baddodged1", resourceCulture);

	internal static string eb_baddodged2 => ResourceManager.GetString("eb_baddodged2", resourceCulture);

	internal static string eb_dodged1 => ResourceManager.GetString("eb_dodged1", resourceCulture);

	internal static string eb_dodged2 => ResourceManager.GetString("eb_dodged2", resourceCulture);

	internal static string eb_dodged3 => ResourceManager.GetString("eb_dodged3", resourceCulture);

	internal static string eb_goodattack1 => ResourceManager.GetString("eb_goodattack1", resourceCulture);

	internal static string eb_goodattack2 => ResourceManager.GetString("eb_goodattack2", resourceCulture);

	internal static string eb_grabbed1 => ResourceManager.GetString("eb_grabbed1", resourceCulture);

	internal static string eb_grabbed2 => ResourceManager.GetString("eb_grabbed2", resourceCulture);

	internal static string eb_grabbed3 => ResourceManager.GetString("eb_grabbed3", resourceCulture);

	internal static string eb_magicked1 => ResourceManager.GetString("eb_magicked1", resourceCulture);

	internal static string eb_magicked2 => ResourceManager.GetString("eb_magicked2", resourceCulture);

	internal static string eb_magicked3 => ResourceManager.GetString("eb_magicked3", resourceCulture);

	internal static string eb_stunattack1 => ResourceManager.GetString("eb_stunattack1", resourceCulture);

	internal static string eb_stunattack2 => ResourceManager.GetString("eb_stunattack2", resourceCulture);

	internal static string eb_stunattack3 => ResourceManager.GetString("eb_stunattack3", resourceCulture);

	internal static string eb_victory1 => ResourceManager.GetString("eb_victory1", resourceCulture);

	internal static string eb_viking1 => ResourceManager.GetString("eb_viking1", resourceCulture);

	internal static string eb_viking2 => ResourceManager.GetString("eb_viking2", resourceCulture);

	internal static string eb_viking3 => ResourceManager.GetString("eb_viking3", resourceCulture);

	internal static string electricBloodMagic => ResourceManager.GetString("electricBloodMagic", resourceCulture);

	internal static string electricBloodMagicTut1 => ResourceManager.GetString("electricBloodMagicTut1", resourceCulture);

	internal static string electricBloodMagicTut2 => ResourceManager.GetString("electricBloodMagicTut2", resourceCulture);

	internal static string electricBloodMagicTut3 => ResourceManager.GetString("electricBloodMagicTut3", resourceCulture);

	internal static string electricBloodMagicTut4 => ResourceManager.GetString("electricBloodMagicTut4", resourceCulture);

	internal static string electricBloodMagicTut5 => ResourceManager.GetString("electricBloodMagicTut5", resourceCulture);

	internal static string electricBloodMagicTut6 => ResourceManager.GetString("electricBloodMagicTut6", resourceCulture);

	internal static string electricBloodMagicTut7 => ResourceManager.GetString("electricBloodMagicTut7", resourceCulture);

	internal static string electricBloodMagicTut8 => ResourceManager.GetString("electricBloodMagicTut8", resourceCulture);

	internal static string electricDishMagic => ResourceManager.GetString("electricDishMagic", resourceCulture);

	internal static string electricDishMagicTut1 => ResourceManager.GetString("electricDishMagicTut1", resourceCulture);

	internal static string electricDishMagicTut2 => ResourceManager.GetString("electricDishMagicTut2", resourceCulture);

	internal static string electricDishMagicTut3 => ResourceManager.GetString("electricDishMagicTut3", resourceCulture);

	internal static string electricDishMagicTut4 => ResourceManager.GetString("electricDishMagicTut4", resourceCulture);

	internal static string electricDishMagicTut5 => ResourceManager.GetString("electricDishMagicTut5", resourceCulture);

	internal static string electricDishMagicTut6 => ResourceManager.GetString("electricDishMagicTut6", resourceCulture);

	internal static string electricDishMagicTut7 => ResourceManager.GetString("electricDishMagicTut7", resourceCulture);

	internal static string electricDishMagicTut8 => ResourceManager.GetString("electricDishMagicTut8", resourceCulture);

	internal static string endCurrentGame => ResourceManager.GetString("endCurrentGame", resourceCulture);

	internal static string endGame => ResourceManager.GetString("endGame", resourceCulture);

	internal static string engiehand_engie_0_text1_0_0 => ResourceManager.GetString("engiehand_engie_0_text1_0_0", resourceCulture);

	internal static string engiehand_engie_0_text2_1_0 => ResourceManager.GetString("engiehand_engie_0_text2_1_0", resourceCulture);

	internal static string engiehand_engie_0_text3_2_0 => ResourceManager.GetString("engiehand_engie_0_text3_2_0", resourceCulture);

	internal static string engiehand_engie_0_text4_3_0 => ResourceManager.GetString("engiehand_engie_0_text4_3_0", resourceCulture);

	internal static string engiehand_engie_0_text5_4_0 => ResourceManager.GetString("engiehand_engie_0_text5_4_0", resourceCulture);

	internal static string engiehand_engie_0_text6_5_0 => ResourceManager.GetString("engiehand_engie_0_text6_5_0", resourceCulture);

	internal static string epicDataFailure => ResourceManager.GetString("epicDataFailure", resourceCulture);

	internal static string epicFail => ResourceManager.GetString("epicFail", resourceCulture);

	internal static string exit => ResourceManager.GetString("exit", resourceCulture);

	internal static string exitGame => ResourceManager.GetString("exitGame", resourceCulture);

	internal static string exitGameSession => ResourceManager.GetString("exitGameSession", resourceCulture);

	internal static string eyeBead => ResourceManager.GetString("eyeBead", resourceCulture);

	internal static string eyeBeadDesc1 => ResourceManager.GetString("eyeBeadDesc1", resourceCulture);

	internal static string filterAll => ResourceManager.GetString("filterAll", resourceCulture);

	internal static string filterFriends => ResourceManager.GetString("filterFriends", resourceCulture);

	internal static string filterMe => ResourceManager.GetString("filterMe", resourceCulture);

	internal static string filterMyScore => ResourceManager.GetString("filterMyScore", resourceCulture);

	internal static string filterOverall => ResourceManager.GetString("filterOverall", resourceCulture);

	internal static string flipped => ResourceManager.GetString("flipped", resourceCulture);

	internal static string floor_floor_0_talk1_0_0 => ResourceManager.GetString("floor_floor_0_talk1_0_0", resourceCulture);

	internal static string floor_floor_0_talk2_1_0 => ResourceManager.GetString("floor_floor_0_talk2_1_0", resourceCulture);

	internal static string floor_floor_0_talk3_2_0 => ResourceManager.GetString("floor_floor_0_talk3_2_0", resourceCulture);

	internal static string floor_floor_0_talk3_2_1 => ResourceManager.GetString("floor_floor_0_talk3_2_1", resourceCulture);

	internal static string floor_floor_0_talk4_3_0 => ResourceManager.GetString("floor_floor_0_talk4_3_0", resourceCulture);

	internal static string floor_talk_2_talk1_0_0 => ResourceManager.GetString("floor_talk_2_talk1_0_0", resourceCulture);

	internal static string floor_talk_2_talk2_1_0 => ResourceManager.GetString("floor_talk_2_talk2_1_0", resourceCulture);

	internal static string floor_talk_2_talk3_2_0 => ResourceManager.GetString("floor_talk_2_talk3_2_0", resourceCulture);

	internal static string floor_talk_2_talk3_2_1 => ResourceManager.GetString("floor_talk_2_talk3_2_1", resourceCulture);

	internal static string floor_talk_2_talk4_3_0 => ResourceManager.GetString("floor_talk_2_talk4_3_0", resourceCulture);

	internal static string floor_talk_2_talk5_4_0 => ResourceManager.GetString("floor_talk_2_talk5_4_0", resourceCulture);

	internal static string floor_wakeup_1_talk1_0_0 => ResourceManager.GetString("floor_wakeup_1_talk1_0_0", resourceCulture);

	internal static string floor_wakeup_1_talk2_1_0 => ResourceManager.GetString("floor_wakeup_1_talk2_1_0", resourceCulture);

	internal static string floor_wakeup_1_talk3_2_0 => ResourceManager.GetString("floor_wakeup_1_talk3_2_0", resourceCulture);

	internal static string floor_wakeup_1_talk4_3_0 => ResourceManager.GetString("floor_wakeup_1_talk4_3_0", resourceCulture);

	internal static string floor2_floor_0_talk1_0_0 => ResourceManager.GetString("floor2_floor_0_talk1_0_0", resourceCulture);

	internal static string floor2_floor_0_talk2_1_0 => ResourceManager.GetString("floor2_floor_0_talk2_1_0", resourceCulture);

	internal static string floor2_floor_0_talk3_2_0 => ResourceManager.GetString("floor2_floor_0_talk3_2_0", resourceCulture);

	internal static string floor2_floor_0_talk3_2_1 => ResourceManager.GetString("floor2_floor_0_talk3_2_1", resourceCulture);

	internal static string floor2_floor_0_talk4_3_0 => ResourceManager.GetString("floor2_floor_0_talk4_3_0", resourceCulture);

	internal static string floor2_talk_2_talk1_0_0 => ResourceManager.GetString("floor2_talk_2_talk1_0_0", resourceCulture);

	internal static string floor2_talk_2_talk2_1_0 => ResourceManager.GetString("floor2_talk_2_talk2_1_0", resourceCulture);

	internal static string floor2_talk_2_talk3_2_0 => ResourceManager.GetString("floor2_talk_2_talk3_2_0", resourceCulture);

	internal static string floor2_talk_2_talk3_2_1 => ResourceManager.GetString("floor2_talk_2_talk3_2_1", resourceCulture);

	internal static string floor2_talk_2_talk4_3_0 => ResourceManager.GetString("floor2_talk_2_talk4_3_0", resourceCulture);

	internal static string floor2_talk_2_talk5_4_0 => ResourceManager.GetString("floor2_talk_2_talk5_4_0", resourceCulture);

	internal static string floor2_wakeup_1_talk1_0_0 => ResourceManager.GetString("floor2_wakeup_1_talk1_0_0", resourceCulture);

	internal static string floor2_wakeup_1_talk2_1_0 => ResourceManager.GetString("floor2_wakeup_1_talk2_1_0", resourceCulture);

	internal static string floor2_wakeup_1_talk3_2_0 => ResourceManager.GetString("floor2_wakeup_1_talk3_2_0", resourceCulture);

	internal static string floor2_wakeup_1_talk4_3_0 => ResourceManager.GetString("floor2_wakeup_1_talk4_3_0", resourceCulture);

	internal static string flowerBead => ResourceManager.GetString("flowerBead", resourceCulture);

	internal static string flowerBeadDesc1 => ResourceManager.GetString("flowerBeadDesc1", resourceCulture);

	internal static string flowerBeadDesc2 => ResourceManager.GetString("flowerBeadDesc2", resourceCulture);

	internal static string forstadtLobby => ResourceManager.GetString("forstadtLobby", resourceCulture);

	internal static string gameEnded => ResourceManager.GetString("gameEnded", resourceCulture);

	internal static string gamerpicFailed1 => ResourceManager.GetString("gamerpicFailed1", resourceCulture);

	internal static string general_general_0_text1_0_0 => ResourceManager.GetString("general_general_0_text1_0_0", resourceCulture);

	internal static string general_general_0_text2_1_0 => ResourceManager.GetString("general_general_0_text2_1_0", resourceCulture);

	internal static string general_general_0_text2_1_1 => ResourceManager.GetString("general_general_0_text2_1_1", resourceCulture);

	internal static string general_general_0_text3_2_0 => ResourceManager.GetString("general_general_0_text3_2_0", resourceCulture);

	internal static string general_general_0_text3_2_1 => ResourceManager.GetString("general_general_0_text3_2_1", resourceCulture);

	internal static string general_general_0_text4_3_0 => ResourceManager.GetString("general_general_0_text4_3_0", resourceCulture);

	internal static string general_general_0_text5_4_0 => ResourceManager.GetString("general_general_0_text5_4_0", resourceCulture);

	internal static string general_general_0_text6_5_0 => ResourceManager.GetString("general_general_0_text6_5_0", resourceCulture);

	internal static string general_general_0_text7_6_0 => ResourceManager.GetString("general_general_0_text7_6_0", resourceCulture);

	internal static string generalkill_general_0_text1_0_0 => ResourceManager.GetString("generalkill_general_0_text1_0_0", resourceCulture);

	internal static string generalkill_general_0_text1_0_1 => ResourceManager.GetString("generalkill_general_0_text1_0_1", resourceCulture);

	internal static string generalkill_general_0_text2_1_0 => ResourceManager.GetString("generalkill_general_0_text2_1_0", resourceCulture);

	internal static string generalkill_general_0_text2_1_1 => ResourceManager.GetString("generalkill_general_0_text2_1_1", resourceCulture);

	internal static string generalkill_general_0_text3_2_0 => ResourceManager.GetString("generalkill_general_0_text3_2_0", resourceCulture);

	internal static string generalkill_general_0_text4_3_0 => ResourceManager.GetString("generalkill_general_0_text4_3_0", resourceCulture);

	internal static string generalkill_general_0_text5_4_0 => ResourceManager.GetString("generalkill_general_0_text5_4_0", resourceCulture);

	internal static string generalkill_general_0_text5_4_1 => ResourceManager.GetString("generalkill_general_0_text5_4_1", resourceCulture);

	internal static string generalkill_general_0_text6_5_0 => ResourceManager.GetString("generalkill_general_0_text6_5_0", resourceCulture);

	internal static string generalkill_general_0_text7_6_0 => ResourceManager.GetString("generalkill_general_0_text7_6_0", resourceCulture);

	internal static string generalkill_general_0_text7_6_1 => ResourceManager.GetString("generalkill_general_0_text7_6_1", resourceCulture);

	internal static string go => ResourceManager.GetString("go", resourceCulture);

	internal static string goatBead => ResourceManager.GetString("goatBead", resourceCulture);

	internal static string goatBeadDesc1 => ResourceManager.GetString("goatBeadDesc1", resourceCulture);

	internal static string goatBeadDesc2 => ResourceManager.GetString("goatBeadDesc2", resourceCulture);

	internal static string got => ResourceManager.GetString("got", resourceCulture);

	internal static string grabCancel => ResourceManager.GetString("grabCancel", resourceCulture);

	internal static string grate_grate_0_yuki1_0_0 => ResourceManager.GetString("grate_grate_0_yuki1_0_0", resourceCulture);

	internal static string grate_grate_0_yuki2_1_0 => ResourceManager.GetString("grate_grate_0_yuki2_1_0", resourceCulture);

	internal static string grate_grate_0_yuki2_1_1 => ResourceManager.GetString("grate_grate_0_yuki2_1_1", resourceCulture);

	internal static string grate_grate_0_yuki3_2_0 => ResourceManager.GetString("grate_grate_0_yuki3_2_0", resourceCulture);

	internal static string grate_grate_0_yuki4_3_0 => ResourceManager.GetString("grate_grate_0_yuki4_3_0", resourceCulture);

	internal static string grate_grate_0_yuki4_3_1 => ResourceManager.GetString("grate_grate_0_yuki4_3_1", resourceCulture);

	internal static string grate_grate_0_yuki5_4_0 => ResourceManager.GetString("grate_grate_0_yuki5_4_0", resourceCulture);

	internal static string grimTower => ResourceManager.GetString("grimTower", resourceCulture);

	internal static string guestProfilesNotAllowed1 => ResourceManager.GetString("guestProfilesNotAllowed1", resourceCulture);

	internal static string guestProfilesNotAllowed2 => ResourceManager.GetString("guestProfilesNotAllowed2", resourceCulture);

	internal static string guillotineUpgradeDesc1 => ResourceManager.GetString("guillotineUpgradeDesc1", resourceCulture);

	internal static string gun => ResourceManager.GetString("gun", resourceCulture);

	internal static string gun_firingSquad => ResourceManager.GetString("gun_firingSquad", resourceCulture);

	internal static string gun_machineGun => ResourceManager.GetString("gun_machineGun", resourceCulture);

	internal static string gunArmUpgrade => ResourceManager.GetString("gunArmUpgrade", resourceCulture);

	internal static string gunArmUpgradeDesc1 => ResourceManager.GetString("gunArmUpgradeDesc1", resourceCulture);

	internal static string gunBead => ResourceManager.GetString("gunBead", resourceCulture);

	internal static string gunBeadDesc1 => ResourceManager.GetString("gunBeadDesc1", resourceCulture);

	internal static string gunTut1 => ResourceManager.GetString("gunTut1", resourceCulture);

	internal static string gunTut2 => ResourceManager.GetString("gunTut2", resourceCulture);

	internal static string gunTut3 => ResourceManager.GetString("gunTut3", resourceCulture);

	internal static string gunTut4 => ResourceManager.GetString("gunTut4", resourceCulture);

	internal static string gunTut5 => ResourceManager.GetString("gunTut5", resourceCulture);

	internal static string hacksaw => ResourceManager.GetString("hacksaw", resourceCulture);

	internal static string hacksawDesc1 => ResourceManager.GetString("hacksawDesc1", resourceCulture);

	internal static string hammer_brainsmash => ResourceManager.GetString("hammer_brainsmash", resourceCulture);

	internal static string hammer_carcassLaunch => ResourceManager.GetString("hammer_carcassLaunch", resourceCulture);

	internal static string hammer_clawHammer => ResourceManager.GetString("hammer_clawHammer", resourceCulture);

	internal static string hammer_facePummel => ResourceManager.GetString("hammer_facePummel", resourceCulture);

	internal static string hammer_fracasCrash => ResourceManager.GetString("hammer_fracasCrash", resourceCulture);

	internal static string hammer_mayhemLaunch => ResourceManager.GetString("hammer_mayhemLaunch", resourceCulture);

	internal static string hammer_meatapult => ResourceManager.GetString("hammer_meatapult", resourceCulture);

	internal static string hammer_meatPummel => ResourceManager.GetString("hammer_meatPummel", resourceCulture);

	internal static string hammer_pulverize => ResourceManager.GetString("hammer_pulverize", resourceCulture);

	internal static string hammer_scatterCrash => ResourceManager.GetString("hammer_scatterCrash", resourceCulture);

	internal static string hammer_skyHammer => ResourceManager.GetString("hammer_skyHammer", resourceCulture);

	internal static string hammer_skySmasher => ResourceManager.GetString("hammer_skySmasher", resourceCulture);

	internal static string hammer_smashingPummel => ResourceManager.GetString("hammer_smashingPummel", resourceCulture);

	internal static string hammer_ultimateDoom => ResourceManager.GetString("hammer_ultimateDoom", resourceCulture);

	internal static string hammer_violenceDrop => ResourceManager.GetString("hammer_violenceDrop", resourceCulture);

	internal static string hammerTut1 => ResourceManager.GetString("hammerTut1", resourceCulture);

	internal static string hammerTut10 => ResourceManager.GetString("hammerTut10", resourceCulture);

	internal static string hammerTut11 => ResourceManager.GetString("hammerTut11", resourceCulture);

	internal static string hammerTut12 => ResourceManager.GetString("hammerTut12", resourceCulture);

	internal static string hammerTut2 => ResourceManager.GetString("hammerTut2", resourceCulture);

	internal static string hammerTut3 => ResourceManager.GetString("hammerTut3", resourceCulture);

	internal static string hammerTut4 => ResourceManager.GetString("hammerTut4", resourceCulture);

	internal static string hammerTut5 => ResourceManager.GetString("hammerTut5", resourceCulture);

	internal static string hammerTut6 => ResourceManager.GetString("hammerTut6", resourceCulture);

	internal static string hammerTut7 => ResourceManager.GetString("hammerTut7", resourceCulture);

	internal static string hammerTut8 => ResourceManager.GetString("hammerTut8", resourceCulture);

	internal static string hammerTut9 => ResourceManager.GetString("hammerTut9", resourceCulture);

	internal static string hammeryTut1 => ResourceManager.GetString("hammeryTut1", resourceCulture);

	internal static string hammeryTut2 => ResourceManager.GetString("hammeryTut2", resourceCulture);

	internal static string hammeryTut3 => ResourceManager.GetString("hammeryTut3", resourceCulture);

	internal static string hammeryTut4 => ResourceManager.GetString("hammeryTut4", resourceCulture);

	internal static string hammeryTut5 => ResourceManager.GetString("hammeryTut5", resourceCulture);

	internal static string health => ResourceManager.GetString("health", resourceCulture);

	internal static string healthUpgradeDesc1 => ResourceManager.GetString("healthUpgradeDesc1", resourceCulture);

	internal static string heartBead => ResourceManager.GetString("heartBead", resourceCulture);

	internal static string heartBeadDesc1 => ResourceManager.GetString("heartBeadDesc1", resourceCulture);

	internal static string heartBeadDesc2 => ResourceManager.GetString("heartBeadDesc2", resourceCulture);

	internal static string hellChambers => ResourceManager.GetString("hellChambers", resourceCulture);

	internal static string helpAndOptions => ResourceManager.GetString("helpAndOptions", resourceCulture);

	internal static string hits => ResourceManager.GetString("hits", resourceCulture);

	internal static string holyBloodMagicTut1 => ResourceManager.GetString("holyBloodMagicTut1", resourceCulture);

	internal static string holyBloodMagicTut2 => ResourceManager.GetString("holyBloodMagicTut2", resourceCulture);

	internal static string holyBloodMagicTut3 => ResourceManager.GetString("holyBloodMagicTut3", resourceCulture);

	internal static string holyBloodMagicTut4 => ResourceManager.GetString("holyBloodMagicTut4", resourceCulture);

	internal static string holyBloodMagicTut5 => ResourceManager.GetString("holyBloodMagicTut5", resourceCulture);

	internal static string holyBloodMagicTut6 => ResourceManager.GetString("holyBloodMagicTut6", resourceCulture);

	internal static string holyBloodMagicTut7 => ResourceManager.GetString("holyBloodMagicTut7", resourceCulture);

	internal static string holyBloodMagicTut8 => ResourceManager.GetString("holyBloodMagicTut8", resourceCulture);

	internal static string holyDishMagicTut1 => ResourceManager.GetString("holyDishMagicTut1", resourceCulture);

	internal static string holyDishMagicTut2 => ResourceManager.GetString("holyDishMagicTut2", resourceCulture);

	internal static string holyDishMagicTut3 => ResourceManager.GetString("holyDishMagicTut3", resourceCulture);

	internal static string holyDishMagicTut4 => ResourceManager.GetString("holyDishMagicTut4", resourceCulture);

	internal static string holyDishMagicTut5 => ResourceManager.GetString("holyDishMagicTut5", resourceCulture);

	internal static string holyDishMagicTut6 => ResourceManager.GetString("holyDishMagicTut6", resourceCulture);

	internal static string holyDishMagicTut7 => ResourceManager.GetString("holyDishMagicTut7", resourceCulture);

	internal static string holyDishMagicTut8 => ResourceManager.GetString("holyDishMagicTut8", resourceCulture);

	internal static string hostLeft1 => ResourceManager.GetString("hostLeft1", resourceCulture);

	internal static string hostLeft2 => ResourceManager.GetString("hostLeft2", resourceCulture);

	internal static string hotPotato => ResourceManager.GetString("hotPotato", resourceCulture);

	internal static string hotPotato_desc1 => ResourceManager.GetString("hotPotato_desc1", resourceCulture);

	internal static string hotPotato_desc2 => ResourceManager.GetString("hotPotato_desc2", resourceCulture);

	internal static string hotPotato_desc3 => ResourceManager.GetString("hotPotato_desc3", resourceCulture);

	internal static string howToPlay => ResourceManager.GetString("howToPlay", resourceCulture);

	internal static string howToPlay1 => ResourceManager.GetString("howToPlay1", resourceCulture);

	internal static string howToPlay2 => ResourceManager.GetString("howToPlay2", resourceCulture);

	internal static string howToPlay3 => ResourceManager.GetString("howToPlay3", resourceCulture);

	internal static string howToPlay4 => ResourceManager.GetString("howToPlay4", resourceCulture);

	internal static string howToPlay5 => ResourceManager.GetString("howToPlay5", resourceCulture);

	internal static string howToPlay6 => ResourceManager.GetString("howToPlay6", resourceCulture);

	internal static string iceBead => ResourceManager.GetString("iceBead", resourceCulture);

	internal static string iceBeadDesc1 => ResourceManager.GetString("iceBeadDesc1", resourceCulture);

	internal static string iffenhauseSpacePrison => ResourceManager.GetString("iffenhauseSpacePrison", resourceCulture);

	internal static string instakill => ResourceManager.GetString("instakill", resourceCulture);

	internal static string instakill_desc1 => ResourceManager.GetString("instakill_desc1", resourceCulture);

	internal static string instakill_desc2 => ResourceManager.GetString("instakill_desc2", resourceCulture);

	internal static string instakill_desc3 => ResourceManager.GetString("instakill_desc3", resourceCulture);

	internal static string insufficientSpace => ResourceManager.GetString("insufficientSpace", resourceCulture);

	internal static string intro_cell_1_died1_0_0 => ResourceManager.GetString("intro_cell_1_died1_0_0", resourceCulture);

	internal static string intro_cell_1_died1_0_1 => ResourceManager.GetString("intro_cell_1_died1_0_1", resourceCulture);

	internal static string intro_cell_1_died2_1_0 => ResourceManager.GetString("intro_cell_1_died2_1_0", resourceCulture);

	internal static string intro_cell_1_died3_2_0 => ResourceManager.GetString("intro_cell_1_died3_2_0", resourceCulture);

	internal static string intro_cell_1_died3_2_1 => ResourceManager.GetString("intro_cell_1_died3_2_1", resourceCulture);

	internal static string intro_cell_1_died4_3_0 => ResourceManager.GetString("intro_cell_1_died4_3_0", resourceCulture);

	internal static string intro_cell_1_died4_3_1 => ResourceManager.GetString("intro_cell_1_died4_3_1", resourceCulture);

	internal static string intro_prison2_2_prison1_0_0 => ResourceManager.GetString("intro_prison2_2_prison1_0_0", resourceCulture);

	internal static string intro_prison2_2_prison1_0_1 => ResourceManager.GetString("intro_prison2_2_prison1_0_1", resourceCulture);

	internal static string intro_prison2_2_prison2_1_0 => ResourceManager.GetString("intro_prison2_2_prison2_1_0", resourceCulture);

	internal static string intro_prison2_2_prison3_2_0 => ResourceManager.GetString("intro_prison2_2_prison3_2_0", resourceCulture);

	internal static string intro_prison2_2_prison4_3_0 => ResourceManager.GetString("intro_prison2_2_prison4_3_0", resourceCulture);

	internal static string intro_prison2_2_prison5_4_0 => ResourceManager.GetString("intro_prison2_2_prison5_4_0", resourceCulture);

	internal static string intro_prison2_2_prison6_5_0 => ResourceManager.GetString("intro_prison2_2_prison6_5_0", resourceCulture);

	internal static string intro_prison3_3_hi1_0_0 => ResourceManager.GetString("intro_prison3_3_hi1_0_0", resourceCulture);

	internal static string intro_prison3_3_hi2_1_0 => ResourceManager.GetString("intro_prison3_3_hi2_1_0", resourceCulture);

	internal static string intro_prison3_3_switch_2_0 => ResourceManager.GetString("intro_prison3_3_switch_2_0", resourceCulture);

	internal static string intro_ship_0_yuki1_0_0 => ResourceManager.GetString("intro_ship_0_yuki1_0_0", resourceCulture);

	internal static string intro_ship_0_yuki2_1_0 => ResourceManager.GetString("intro_ship_0_yuki2_1_0", resourceCulture);

	internal static string intro_ship_0_yuki3_2_0 => ResourceManager.GetString("intro_ship_0_yuki3_2_0", resourceCulture);

	internal static string intro_ship_0_yuki4_3_0 => ResourceManager.GetString("intro_ship_0_yuki4_3_0", resourceCulture);

	internal static string intro_ship_0_yuki5_4_0 => ResourceManager.GetString("intro_ship_0_yuki5_4_0", resourceCulture);

	internal static string intro_ship_0_yuki6_5_0 => ResourceManager.GetString("intro_ship_0_yuki6_5_0", resourceCulture);

	internal static string inv_nobeads => ResourceManager.GetString("inv_nobeads", resourceCulture);

	internal static string inv_nofood => ResourceManager.GetString("inv_nofood", resourceCulture);

	internal static string inv_nokeys => ResourceManager.GetString("inv_nokeys", resourceCulture);

	internal static string inv_noweapons => ResourceManager.GetString("inv_noweapons", resourceCulture);

	internal static string inventory => ResourceManager.GetString("inventory", resourceCulture);

	internal static string inviteFriends => ResourceManager.GetString("inviteFriends", resourceCulture);

	internal static string inviteXboxLiveParty => ResourceManager.GetString("inviteXboxLiveParty", resourceCulture);

	internal static string isabella1 => ResourceManager.GetString("isabella1", resourceCulture);

	internal static string isabella2 => ResourceManager.GetString("isabella2", resourceCulture);

	internal static string isabella3 => ResourceManager.GetString("isabella3", resourceCulture);

	internal static string joinFail => ResourceManager.GetString("joinFail", resourceCulture);

	internal static string judge_judge_0_text1_0_0 => ResourceManager.GetString("judge_judge_0_text1_0_0", resourceCulture);

	internal static string judge_judge_0_text2_1_0 => ResourceManager.GetString("judge_judge_0_text2_1_0", resourceCulture);

	internal static string judge_judge_0_text3_2_0 => ResourceManager.GetString("judge_judge_0_text3_2_0", resourceCulture);

	internal static string judge_judge_0_text3_2_1 => ResourceManager.GetString("judge_judge_0_text3_2_1", resourceCulture);

	internal static string judge_judge_0_text4_3_0 => ResourceManager.GetString("judge_judge_0_text4_3_0", resourceCulture);

	internal static string judge_judge_0_text4_3_1 => ResourceManager.GetString("judge_judge_0_text4_3_1", resourceCulture);

	internal static string judge_judge_0_text5_4_0 => ResourceManager.GetString("judge_judge_0_text5_4_0", resourceCulture);

	internal static string judge_judge_0_text6_5_0 => ResourceManager.GetString("judge_judge_0_text6_5_0", resourceCulture);

	internal static string judgekill_judge_0_text1_0_0 => ResourceManager.GetString("judgekill_judge_0_text1_0_0", resourceCulture);

	internal static string judgekill_judge_0_text1_0_1 => ResourceManager.GetString("judgekill_judge_0_text1_0_1", resourceCulture);

	internal static string judgekill_judge_0_text2_1_0 => ResourceManager.GetString("judgekill_judge_0_text2_1_0", resourceCulture);

	internal static string judgekill_judge_0_text2_1_1 => ResourceManager.GetString("judgekill_judge_0_text2_1_1", resourceCulture);

	internal static string judgekill_judge_0_text3_2_0 => ResourceManager.GetString("judgekill_judge_0_text3_2_0", resourceCulture);

	internal static string judgekill_judge_0_text4_3_0 => ResourceManager.GetString("judgekill_judge_0_text4_3_0", resourceCulture);

	internal static string judgekill_judge_0_text5_4_0 => ResourceManager.GetString("judgekill_judge_0_text5_4_0", resourceCulture);

	internal static string judgekill_judge_0_text6_5_0 => ResourceManager.GetString("judgekill_judge_0_text6_5_0", resourceCulture);

	internal static string judgekill_judge_0_text7_6_0 => ResourceManager.GetString("judgekill_judge_0_text7_6_0", resourceCulture);

	internal static string judgerise_engie_0_text1_0_0 => ResourceManager.GetString("judgerise_engie_0_text1_0_0", resourceCulture);

	internal static string judgerise_engie_0_text2_1_0 => ResourceManager.GetString("judgerise_engie_0_text2_1_0", resourceCulture);

	internal static string judgerise_engie_0_text3_2_0 => ResourceManager.GetString("judgerise_engie_0_text3_2_0", resourceCulture);

	internal static string judgerise_engie_0_text4_3_0 => ResourceManager.GetString("judgerise_engie_0_text4_3_0", resourceCulture);

	internal static string judgerise_engie_0_text4_3_1 => ResourceManager.GetString("judgerise_engie_0_text4_3_1", resourceCulture);

	internal static string judgerise_engie_0_text5_4_0 => ResourceManager.GetString("judgerise_engie_0_text5_4_0", resourceCulture);

	internal static string judgerise_engie_0_text5_4_1 => ResourceManager.GetString("judgerise_engie_0_text5_4_1", resourceCulture);

	internal static string judgerise_engie_0_text6_5_0 => ResourceManager.GetString("judgerise_engie_0_text6_5_0", resourceCulture);

	internal static string judgerise_engie_0_text6_5_1 => ResourceManager.GetString("judgerise_engie_0_text6_5_1", resourceCulture);

	internal static string judgerise_engie_0_text7_6_0 => ResourceManager.GetString("judgerise_engie_0_text7_6_0", resourceCulture);

	internal static string jumpAccept => ResourceManager.GetString("jumpAccept", resourceCulture);

	internal static string justiceSummit => ResourceManager.GetString("justiceSummit", resourceCulture);

	internal static string kama_danceOfFangs => ResourceManager.GetString("kama_danceOfFangs", resourceCulture);

	internal static string kama_flyingBoaStrangle => ResourceManager.GetString("kama_flyingBoaStrangle", resourceCulture);

	internal static string kama_flyingCobraSlam => ResourceManager.GetString("kama_flyingCobraSlam", resourceCulture);

	internal static string kama_flyingViperBarrage => ResourceManager.GetString("kama_flyingViperBarrage", resourceCulture);

	internal static string kama_homicideTrap => ResourceManager.GetString("kama_homicideTrap", resourceCulture);

	internal static string kama_ironFlurry => ResourceManager.GetString("kama_ironFlurry", resourceCulture);

	internal static string kama_mulcherClaw => ResourceManager.GetString("kama_mulcherClaw", resourceCulture);

	internal static string kama_ourobouros => ResourceManager.GetString("kama_ourobouros", resourceCulture);

	internal static string kama_serpentKick => ResourceManager.GetString("kama_serpentKick", resourceCulture);

	internal static string kama_serpentsFang => ResourceManager.GetString("kama_serpentsFang", resourceCulture);

	internal static string kama_serpentSlash => ResourceManager.GetString("kama_serpentSlash", resourceCulture);

	internal static string kama_serpentStrangle => ResourceManager.GetString("kama_serpentStrangle", resourceCulture);

	internal static string kama_suicideTrap => ResourceManager.GetString("kama_suicideTrap", resourceCulture);

	internal static string kama_venomFlurry => ResourceManager.GetString("kama_venomFlurry", resourceCulture);

	internal static string kama_viperChop => ResourceManager.GetString("kama_viperChop", resourceCulture);

	internal static string kamakazi => ResourceManager.GetString("kamakazi", resourceCulture);

	internal static string kamakaziUpgradeDesc1 => ResourceManager.GetString("kamakaziUpgradeDesc1", resourceCulture);

	internal static string kamaTut1 => ResourceManager.GetString("kamaTut1", resourceCulture);

	internal static string kamaTut10 => ResourceManager.GetString("kamaTut10", resourceCulture);

	internal static string kamaTut11 => ResourceManager.GetString("kamaTut11", resourceCulture);

	internal static string kamaTut12 => ResourceManager.GetString("kamaTut12", resourceCulture);

	internal static string kamaTut2 => ResourceManager.GetString("kamaTut2", resourceCulture);

	internal static string kamaTut3 => ResourceManager.GetString("kamaTut3", resourceCulture);

	internal static string kamaTut4 => ResourceManager.GetString("kamaTut4", resourceCulture);

	internal static string kamaTut5 => ResourceManager.GetString("kamaTut5", resourceCulture);

	internal static string kamaTut6 => ResourceManager.GetString("kamaTut6", resourceCulture);

	internal static string kamaTut7 => ResourceManager.GetString("kamaTut7", resourceCulture);

	internal static string kamaTut8 => ResourceManager.GetString("kamaTut8", resourceCulture);

	internal static string kamaTut9 => ResourceManager.GetString("kamaTut9", resourceCulture);

	internal static string kills => ResourceManager.GetString("kills", resourceCulture);

	internal static string kittenVitamins => ResourceManager.GetString("kittenVitamins", resourceCulture);

	internal static string kittenVitaminsDesc1 => ResourceManager.GetString("kittenVitaminsDesc1", resourceCulture);

	internal static string kittenVitaminsDesc2 => ResourceManager.GetString("kittenVitaminsDesc2", resourceCulture);

	internal static string landcruiserStadium => ResourceManager.GetString("landcruiserStadium", resourceCulture);

	internal static string launch => ResourceManager.GetString("launch", resourceCulture);

	internal static string leaderboards => ResourceManager.GetString("leaderboards", resourceCulture);

	internal static string lobbyFullOrUnavailable => ResourceManager.GetString("lobbyFullOrUnavailable", resourceCulture);

	internal static string local => ResourceManager.GetString("local", resourceCulture);

	internal static string lunarWastes => ResourceManager.GetString("lunarWastes", resourceCulture);

	internal static string machineArmGun => ResourceManager.GetString("machineArmGun", resourceCulture);

	internal static string machineArmSaw => ResourceManager.GetString("machineArmSaw", resourceCulture);

	internal static string magic => ResourceManager.GetString("magic", resourceCulture);

	internal static string magicUpgradeDesc1 => ResourceManager.GetString("magicUpgradeDesc1", resourceCulture);

	internal static string mainMenu => ResourceManager.GetString("mainMenu", resourceCulture);

	internal static string marinaKey => ResourceManager.GetString("marinaKey", resourceCulture);

	internal static string mask_mask_0_text1_0_0 => ResourceManager.GetString("mask_mask_0_text1_0_0", resourceCulture);

	internal static string mask_mask_0_text1_0_1 => ResourceManager.GetString("mask_mask_0_text1_0_1", resourceCulture);

	internal static string mask_mask_0_text2_1_0 => ResourceManager.GetString("mask_mask_0_text2_1_0", resourceCulture);

	internal static string mask_mask_0_text2_1_1 => ResourceManager.GetString("mask_mask_0_text2_1_1", resourceCulture);

	internal static string mask_mask_0_text3_2_0 => ResourceManager.GetString("mask_mask_0_text3_2_0", resourceCulture);

	internal static string mask_mask_0_text4_3_0 => ResourceManager.GetString("mask_mask_0_text4_3_0", resourceCulture);

	internal static string mask_yuki_1_text1_0_0 => ResourceManager.GetString("mask_yuki_1_text1_0_0", resourceCulture);

	internal static string mask_yuki_1_text1_0_1 => ResourceManager.GetString("mask_yuki_1_text1_0_1", resourceCulture);

	internal static string mask_yuki_1_text2_1_0 => ResourceManager.GetString("mask_yuki_1_text2_1_0", resourceCulture);

	internal static string mask_yuki_1_text3_2_0 => ResourceManager.GetString("mask_yuki_1_text3_2_0", resourceCulture);

	internal static string mask_yuki_1_text3_2_1 => ResourceManager.GetString("mask_yuki_1_text3_2_1", resourceCulture);

	internal static string mask_yuki_1_text4_3_0 => ResourceManager.GetString("mask_yuki_1_text4_3_0", resourceCulture);

	internal static string mask_yuki_1_text5_4_0 => ResourceManager.GetString("mask_yuki_1_text5_4_0", resourceCulture);

	internal static string mathBead => ResourceManager.GetString("mathBead", resourceCulture);

	internal static string mathBeadDesc1 => ResourceManager.GetString("mathBeadDesc1", resourceCulture);

	internal static string mathBeadDesc2 => ResourceManager.GetString("mathBeadDesc2", resourceCulture);

	internal static string meatCleavers => ResourceManager.GetString("meatCleavers", resourceCulture);

	internal static string meatCleaversUpgradeDesc1 => ResourceManager.GetString("meatCleaversUpgradeDesc1", resourceCulture);

	internal static string memory_memory_0_text1_0_0 => ResourceManager.GetString("memory_memory_0_text1_0_0", resourceCulture);

	internal static string memory_memory_0_text2_1_0 => ResourceManager.GetString("memory_memory_0_text2_1_0", resourceCulture);

	internal static string memory_memory_0_text3_2_0 => ResourceManager.GetString("memory_memory_0_text3_2_0", resourceCulture);

	internal static string memory_memory_0_text4_3_0 => ResourceManager.GetString("memory_memory_0_text4_3_0", resourceCulture);

	internal static string memory_memory_0_text5_4_0 => ResourceManager.GetString("memory_memory_0_text5_4_0", resourceCulture);

	internal static string memory_memory_0_text5_4_1 => ResourceManager.GetString("memory_memory_0_text5_4_1", resourceCulture);

	internal static string memory_memory_0_text6_5_0 => ResourceManager.GetString("memory_memory_0_text6_5_0", resourceCulture);

	internal static string memory_memory_0_text7_6_0 => ResourceManager.GetString("memory_memory_0_text7_6_0", resourceCulture);

	internal static string memory_memory_0_text8_7_0 => ResourceManager.GetString("memory_memory_0_text8_7_0", resourceCulture);

	internal static string memory_memory_0_text9_8_0 => ResourceManager.GetString("memory_memory_0_text9_8_0", resourceCulture);

	internal static string mirrorBead => ResourceManager.GetString("mirrorBead", resourceCulture);

	internal static string mirrorBeadDesc1 => ResourceManager.GetString("mirrorBeadDesc1", resourceCulture);

	internal static string mirrorBeadDesc2 => ResourceManager.GetString("mirrorBeadDesc2", resourceCulture);

	internal static string mode => ResourceManager.GetString("mode", resourceCulture);

	internal static string moneyBead => ResourceManager.GetString("moneyBead", resourceCulture);

	internal static string moneyBeadDesc1 => ResourceManager.GetString("moneyBeadDesc1", resourceCulture);

	internal static string moneyBeadDesc2 => ResourceManager.GetString("moneyBeadDesc2", resourceCulture);

	internal static string moonBread => ResourceManager.GetString("moonBread", resourceCulture);

	internal static string moonBreadDesc1 => ResourceManager.GetString("moonBreadDesc1", resourceCulture);

	internal static string moonFish => ResourceManager.GetString("moonFish", resourceCulture);

	internal static string moonFishDesc1 => ResourceManager.GetString("moonFishDesc1", resourceCulture);

	internal static string move => ResourceManager.GetString("move", resourceCulture);

	internal static string movesList => ResourceManager.GetString("movesList", resourceCulture);

	internal static string movesListHold => ResourceManager.GetString("movesListHold", resourceCulture);

	internal static string movesListHoldYRelease => ResourceManager.GetString("movesListHoldYRelease", resourceCulture);

	internal static string movesListOr => ResourceManager.GetString("movesListOr", resourceCulture);

	internal static string movesListRelease => ResourceManager.GetString("movesListRelease", resourceCulture);

	internal static string movesListTap => ResourceManager.GetString("movesListTap", resourceCulture);

	internal static string movesListTapY => ResourceManager.GetString("movesListTapY", resourceCulture);

	internal static string movesListTapYOnLanding => ResourceManager.GetString("movesListTapYOnLanding", resourceCulture);

	internal static string moveTut1 => ResourceManager.GetString("moveTut1", resourceCulture);

	internal static string moveTut2 => ResourceManager.GetString("moveTut2", resourceCulture);

	internal static string multiplayer => ResourceManager.GetString("multiplayer", resourceCulture);

	internal static string mustBeSignedIn1 => ResourceManager.GetString("mustBeSignedIn1", resourceCulture);

	internal static string mustBeSignedIn2 => ResourceManager.GetString("mustBeSignedIn2", resourceCulture);

	internal static string MustBeSignedInToSubmit1 => ResourceManager.GetString("MustBeSignedInToSubmit1", resourceCulture);

	internal static string MustBeSignedInToSubmit2 => ResourceManager.GetString("MustBeSignedInToSubmit2", resourceCulture);

	internal static string MustBeSignedInToSubmit3 => ResourceManager.GetString("MustBeSignedInToSubmit3", resourceCulture);

	internal static string needToBeSignedInXBL1 => ResourceManager.GetString("needToBeSignedInXBL1", resourceCulture);

	internal static string needToBeSignedInXBL2 => ResourceManager.GetString("needToBeSignedInXBL2", resourceCulture);

	internal static string needToBeSignedInXBL3 => ResourceManager.GetString("needToBeSignedInXBL3", resourceCulture);

	internal static string nextWeapon => ResourceManager.GetString("nextWeapon", resourceCulture);

	internal static string ninja => ResourceManager.GetString("ninja", resourceCulture);

	internal static string noFriends => ResourceManager.GetString("noFriends", resourceCulture);

	internal static string noMovesAvailable => ResourceManager.GetString("noMovesAvailable", resourceCulture);

	internal static string noRankings => ResourceManager.GetString("noRankings", resourceCulture);

	internal static string normal => ResourceManager.GetString("normal", resourceCulture);

	internal static string noStorageDeviceSelected => ResourceManager.GetString("noStorageDeviceSelected", resourceCulture);

	internal static string notConnectToXboxLive => ResourceManager.GetString("notConnectToXboxLive", resourceCulture);

	internal static string notRanked => ResourceManager.GetString("notRanked", resourceCulture);

	internal static string ok => ResourceManager.GetString("ok", resourceCulture);

	internal static string oke => ResourceManager.GetString("oke", resourceCulture);

	internal static string omNomNom => ResourceManager.GetString("omNomNom", resourceCulture);

	internal static string omNomNom_desc1 => ResourceManager.GetString("omNomNom_desc1", resourceCulture);

	internal static string omNomNom_desc2 => ResourceManager.GetString("omNomNom_desc2", resourceCulture);

	internal static string omNomNom_desc3 => ResourceManager.GetString("omNomNom_desc3", resourceCulture);

	internal static string omodoCrash => ResourceManager.GetString("omodoCrash", resourceCulture);

	internal static string omodoKey => ResourceManager.GetString("omodoKey", resourceCulture);

	internal static string omodosExecution => ResourceManager.GetString("omodosExecution", resourceCulture);

	internal static string onoes => ResourceManager.GetString("onoes", resourceCulture);

	internal static string original => ResourceManager.GetString("original", resourceCulture);

	internal static string pageDown => ResourceManager.GetString("pageDown", resourceCulture);

	internal static string pageUp => ResourceManager.GetString("pageUp", resourceCulture);

	internal static string painkiller => ResourceManager.GetString("painkiller", resourceCulture);

	internal static string painKillerTut1 => ResourceManager.GetString("painKillerTut1", resourceCulture);

	internal static string painKillerTut2 => ResourceManager.GetString("painKillerTut2", resourceCulture);

	internal static string painKillerTut3 => ResourceManager.GetString("painKillerTut3", resourceCulture);

	internal static string painkillerUpgradeDesc1 => ResourceManager.GetString("painkillerUpgradeDesc1", resourceCulture);

	internal static string pause => ResourceManager.GetString("pause", resourceCulture);

	internal static string paused => ResourceManager.GetString("paused", resourceCulture);

	internal static string pigBead => ResourceManager.GetString("pigBead", resourceCulture);

	internal static string pigBeadDesc1 => ResourceManager.GetString("pigBeadDesc1", resourceCulture);

	internal static string plateBead => ResourceManager.GetString("plateBead", resourceCulture);

	internal static string plateBeadDesc1 => ResourceManager.GetString("plateBeadDesc1", resourceCulture);

	internal static string plateBeadDesc2 => ResourceManager.GetString("plateBeadDesc2", resourceCulture);

	internal static string playWithParty => ResourceManager.GetString("playWithParty", resourceCulture);

	internal static string pleaseConnect1 => ResourceManager.GetString("pleaseConnect1", resourceCulture);

	internal static string pleaseConnect2 => ResourceManager.GetString("pleaseConnect2", resourceCulture);

	internal static string pleaseConnect3 => ResourceManager.GetString("pleaseConnect3", resourceCulture);

	internal static string powerPlayer => ResourceManager.GetString("powerPlayer", resourceCulture);

	internal static string powerPlayer_desc1 => ResourceManager.GetString("powerPlayer_desc1", resourceCulture);

	internal static string powerPlayer_desc2 => ResourceManager.GetString("powerPlayer_desc2", resourceCulture);

	internal static string powerPlayer_desc3 => ResourceManager.GetString("powerPlayer_desc3", resourceCulture);

	internal static string powerPlayer_desc4 => ResourceManager.GetString("powerPlayer_desc4", resourceCulture);

	internal static string practiceRoom => ResourceManager.GetString("practiceRoom", resourceCulture);

	internal static string pressStart => ResourceManager.GetString("pressStart", resourceCulture);

	internal static string prettyPrincess => ResourceManager.GetString("prettyPrincess", resourceCulture);

	internal static string previousWeapon => ResourceManager.GetString("previousWeapon", resourceCulture);

	internal static string prisonend_yuki_0_talk1_0_0 => ResourceManager.GetString("prisonend_yuki_0_talk1_0_0", resourceCulture);

	internal static string prisonend_yuki_0_talk2_1_0 => ResourceManager.GetString("prisonend_yuki_0_talk2_1_0", resourceCulture);

	internal static string prisonend_yuki_0_talk3_2_0 => ResourceManager.GetString("prisonend_yuki_0_talk3_2_0", resourceCulture);

	internal static string prisonend_yuki_0_talk3_2_1 => ResourceManager.GetString("prisonend_yuki_0_talk3_2_1", resourceCulture);

	internal static string prisonend_yuki_0_talk4_3_0 => ResourceManager.GetString("prisonend_yuki_0_talk4_3_0", resourceCulture);

	internal static string prisonend_yuki2_2_yuki1_0_0 => ResourceManager.GetString("prisonend_yuki2_2_yuki1_0_0", resourceCulture);

	internal static string prisonend_yuki2_2_yuki2_1_0 => ResourceManager.GetString("prisonend_yuki2_2_yuki2_1_0", resourceCulture);

	internal static string progressWillNotBeSaved1 => ResourceManager.GetString("progressWillNotBeSaved1", resourceCulture);

	internal static string progressWillNotBeSaved2 => ResourceManager.GetString("progressWillNotBeSaved2", resourceCulture);

	internal static string qqq => ResourceManager.GetString("qqq", resourceCulture);

	internal static string quickFindFailed => ResourceManager.GetString("quickFindFailed", resourceCulture);

	internal static string quickMatch => ResourceManager.GetString("quickMatch", resourceCulture);

	internal static string raven_raven_0_text1_0_0 => ResourceManager.GetString("raven_raven_0_text1_0_0", resourceCulture);

	internal static string raven_raven_0_text2_1_0 => ResourceManager.GetString("raven_raven_0_text2_1_0", resourceCulture);

	internal static string raven_raven_0_text3_2_0 => ResourceManager.GetString("raven_raven_0_text3_2_0", resourceCulture);

	internal static string raven_raven_0_text4_3_0 => ResourceManager.GetString("raven_raven_0_text4_3_0", resourceCulture);

	internal static string raven_raven_0_text5_4_0 => ResourceManager.GetString("raven_raven_0_text5_4_0", resourceCulture);

	internal static string raven_raven_0_text6_5_0 => ResourceManager.GetString("raven_raven_0_text6_5_0", resourceCulture);

	internal static string raven_raven_0_text7_6_0 => ResourceManager.GetString("raven_raven_0_text7_6_0", resourceCulture);

	internal static string raven_raven_0_text8_7_0 => ResourceManager.GetString("raven_raven_0_text8_7_0", resourceCulture);

	internal static string raven_yuki_1_text1_0_0 => ResourceManager.GetString("raven_yuki_1_text1_0_0", resourceCulture);

	internal static string raven_yuki_1_text2_1_0 => ResourceManager.GetString("raven_yuki_1_text2_1_0", resourceCulture);

	internal static string raven_yuki_1_text3_2_0 => ResourceManager.GetString("raven_yuki_1_text3_2_0", resourceCulture);

	internal static string raven_yuki_1_text4_3_0 => ResourceManager.GetString("raven_yuki_1_text4_3_0", resourceCulture);

	internal static string readFail => ResourceManager.GetString("readFail", resourceCulture);

	internal static string remoteConnectionLost1 => ResourceManager.GetString("remoteConnectionLost1", resourceCulture);

	internal static string remoteConnectionLost2 => ResourceManager.GetString("remoteConnectionLost2", resourceCulture);

	internal static string remotelyPaused => ResourceManager.GetString("remotelyPaused", resourceCulture);

	internal static string removedStorage1 => ResourceManager.GetString("removedStorage1", resourceCulture);

	internal static string removedStorage2 => ResourceManager.GetString("removedStorage2", resourceCulture);

	internal static string removedStorage3 => ResourceManager.GetString("removedStorage3", resourceCulture);

	internal static string removedStorage4 => ResourceManager.GetString("removedStorage4", resourceCulture);

	internal static string resetDefaults => ResourceManager.GetString("resetDefaults", resourceCulture);

	internal static string resetDefaultsMsg1 => ResourceManager.GetString("resetDefaultsMsg1", resourceCulture);

	internal static string resetDefaultsMsg2 => ResourceManager.GetString("resetDefaultsMsg2", resourceCulture);

	internal static string restartLevel => ResourceManager.GetString("restartLevel", resourceCulture);

	internal static string resubmit => ResourceManager.GetString("resubmit", resourceCulture);

	internal static string resumeGame => ResourceManager.GetString("resumeGame", resourceCulture);

	internal static string retry => ResourceManager.GetString("retry", resourceCulture);

	internal static string returningToMain1 => ResourceManager.GetString("returningToMain1", resourceCulture);

	internal static string returningToMain2 => ResourceManager.GetString("returningToMain2", resourceCulture);

	internal static string returningToMultiplayer1 => ResourceManager.GetString("returningToMultiplayer1", resourceCulture);

	internal static string returningToMultiplayer2 => ResourceManager.GetString("returningToMultiplayer2", resourceCulture);

	internal static string returningtoPause1 => ResourceManager.GetString("returningtoPause1", resourceCulture);

	internal static string returningtoPause2 => ResourceManager.GetString("returningtoPause2", resourceCulture);

	internal static string returningYouToLobby => ResourceManager.GetString("returningYouToLobby", resourceCulture);

	internal static string returnToGame => ResourceManager.GetString("returnToGame", resourceCulture);

	internal static string returnToGameLibrary => ResourceManager.GetString("returnToGameLibrary", resourceCulture);

	internal static string returnToGameLibraryQ => ResourceManager.GetString("returnToGameLibraryQ", resourceCulture);

	internal static string returnToTitle1 => ResourceManager.GetString("returnToTitle1", resourceCulture);

	internal static string returnToTitle2 => ResourceManager.GetString("returnToTitle2", resourceCulture);

	internal static string robotBead => ResourceManager.GetString("robotBead", resourceCulture);

	internal static string robotBeadDesc1 => ResourceManager.GetString("robotBeadDesc1", resourceCulture);

	internal static string robotBeadDesc2 => ResourceManager.GetString("robotBeadDesc2", resourceCulture);

	internal static string rocketBead => ResourceManager.GetString("rocketBead", resourceCulture);

	internal static string rocketBeadDesc1 => ResourceManager.GetString("rocketBeadDesc1", resourceCulture);

	internal static string rocketBeadDesc2 => ResourceManager.GetString("rocketBeadDesc2", resourceCulture);

	internal static string roofKey => ResourceManager.GetString("roofKey", resourceCulture);

	internal static string samurai => ResourceManager.GetString("samurai", resourceCulture);

	internal static string saveDataWrongVersion1 => ResourceManager.GetString("saveDataWrongVersion1", resourceCulture);

	internal static string saveDataWrongVersion2 => ResourceManager.GetString("saveDataWrongVersion2", resourceCulture);

	internal static string saw_machineAssault => ResourceManager.GetString("saw_machineAssault", resourceCulture);

	internal static string saw_machineBarrage => ResourceManager.GetString("saw_machineBarrage", resourceCulture);

	internal static string saw_machineDestroyer => ResourceManager.GetString("saw_machineDestroyer", resourceCulture);

	internal static string saw_machineExecution => ResourceManager.GetString("saw_machineExecution", resourceCulture);

	internal static string saw_machineGrindhaus => ResourceManager.GetString("saw_machineGrindhaus", resourceCulture);

	internal static string saw_machineSplitter => ResourceManager.GetString("saw_machineSplitter", resourceCulture);

	internal static string sawArmUpgradeDesc1 => ResourceManager.GetString("sawArmUpgradeDesc1", resourceCulture);

	internal static string scissor_bastille => ResourceManager.GetString("scissor_bastille", resourceCulture);

	internal static string scissor_ciseux => ResourceManager.GetString("scissor_ciseux", resourceCulture);

	internal static string scissor_clouDeCercueil => ResourceManager.GetString("scissor_clouDeCercueil", resourceCulture);

	internal static string scissor_cutCut => ResourceManager.GetString("scissor_cutCut", resourceCulture);

	internal static string scissor_deathRazor => ResourceManager.GetString("scissor_deathRazor", resourceCulture);

	internal static string scissor_deathSpike => ResourceManager.GetString("scissor_deathSpike", resourceCulture);

	internal static string scissor_deathSquare => ResourceManager.GetString("scissor_deathSquare", resourceCulture);

	internal static string scissor_decapitator => ResourceManager.GetString("scissor_decapitator", resourceCulture);

	internal static string scissor_laRevolution => ResourceManager.GetString("scissor_laRevolution", resourceCulture);

	internal static string scissor_masterImpaler => ResourceManager.GetString("scissor_masterImpaler", resourceCulture);

	internal static string scissor_reignOfTerror => ResourceManager.GetString("scissor_reignOfTerror", resourceCulture);

	internal static string scissor_rollingPiercer => ResourceManager.GetString("scissor_rollingPiercer", resourceCulture);

	internal static string scissor_rollingSpike => ResourceManager.GetString("scissor_rollingSpike", resourceCulture);

	internal static string scissor_skymower => ResourceManager.GetString("scissor_skymower", resourceCulture);

	internal static string scissor_straightRazor => ResourceManager.GetString("scissor_straightRazor", resourceCulture);

	internal static string scissor_voiesDeFait => ResourceManager.GetString("scissor_voiesDeFait", resourceCulture);

	internal static string scissorTut1 => ResourceManager.GetString("scissorTut1", resourceCulture);

	internal static string scissorTut2 => ResourceManager.GetString("scissorTut2", resourceCulture);

	internal static string scissorTut3 => ResourceManager.GetString("scissorTut3", resourceCulture);

	internal static string scissorTut4 => ResourceManager.GetString("scissorTut4", resourceCulture);

	internal static string scissorTut5 => ResourceManager.GetString("scissorTut5", resourceCulture);

	internal static string scissorTut6 => ResourceManager.GetString("scissorTut6", resourceCulture);

	internal static string scoreUpdated => ResourceManager.GetString("scoreUpdated", resourceCulture);

	internal static string searching => ResourceManager.GetString("searching", resourceCulture);

	internal static string selectCampaign => ResourceManager.GetString("selectCampaign", resourceCulture);

	internal static string selectDifficulty => ResourceManager.GetString("selectDifficulty", resourceCulture);

	internal static string selectHero => ResourceManager.GetString("selectHero", resourceCulture);

	internal static string selectLevel => ResourceManager.GetString("selectLevel", resourceCulture);

	internal static string selectPlayer => ResourceManager.GetString("selectPlayer", resourceCulture);

	internal static string selectPlayers => ResourceManager.GetString("selectPlayers", resourceCulture);

	internal static string selectStorageDevice => ResourceManager.GetString("selectStorageDevice", resourceCulture);

	internal static string selectWeapons => ResourceManager.GetString("selectWeapons", resourceCulture);

	internal static string sendingScore => ResourceManager.GetString("sendingScore", resourceCulture);

	internal static string settings => ResourceManager.GetString("settings", resourceCulture);

	internal static string settingsDataWrongVersion1 => ResourceManager.GetString("settingsDataWrongVersion1", resourceCulture);

	internal static string settingsDataWrongVersion2 => ResourceManager.GetString("settingsDataWrongVersion2", resourceCulture);

	internal static string sfx => ResourceManager.GetString("sfx", resourceCulture);

	internal static string sfx0 => ResourceManager.GetString("sfx0", resourceCulture);

	internal static string sfx10 => ResourceManager.GetString("sfx10", resourceCulture);

	internal static string sfx100 => ResourceManager.GetString("sfx100", resourceCulture);

	internal static string sfx20 => ResourceManager.GetString("sfx20", resourceCulture);

	internal static string sfx30 => ResourceManager.GetString("sfx30", resourceCulture);

	internal static string sfx40 => ResourceManager.GetString("sfx40", resourceCulture);

	internal static string sfx50 => ResourceManager.GetString("sfx50", resourceCulture);

	internal static string sfx60 => ResourceManager.GetString("sfx60", resourceCulture);

	internal static string sfx70 => ResourceManager.GetString("sfx70", resourceCulture);

	internal static string sfx80 => ResourceManager.GetString("sfx80", resourceCulture);

	internal static string sfx90 => ResourceManager.GetString("sfx90", resourceCulture);

	internal static string shieldBead => ResourceManager.GetString("shieldBead", resourceCulture);

	internal static string shieldBeadDesc1 => ResourceManager.GetString("shieldBeadDesc1", resourceCulture);

	internal static string shift_acroDrop => ResourceManager.GetString("shift_acroDrop", resourceCulture);

	internal static string shift_airShadowLift => ResourceManager.GetString("shift_airShadowLift", resourceCulture);

	internal static string shift_airShadowSlash => ResourceManager.GetString("shift_airShadowSlash", resourceCulture);

	internal static string shift_bladeSmash => ResourceManager.GetString("shift_bladeSmash", resourceCulture);

	internal static string shift_cleanSplitter => ResourceManager.GetString("shift_cleanSplitter", resourceCulture);

	internal static string shift_defierLaunch => ResourceManager.GetString("shift_defierLaunch", resourceCulture);

	internal static string shift_defierSlam => ResourceManager.GetString("shift_defierSlam", resourceCulture);

	internal static string shift_dishKick => ResourceManager.GetString("shift_dishKick", resourceCulture);

	internal static string shift_messySever => ResourceManager.GetString("shift_messySever", resourceCulture);

	internal static string shift_predatorDrop => ResourceManager.GetString("shift_predatorDrop", resourceCulture);

	internal static string shift_rapidLaunch => ResourceManager.GetString("shift_rapidLaunch", resourceCulture);

	internal static string shift_shadowLift => ResourceManager.GetString("shift_shadowLift", resourceCulture);

	internal static string shift_shadowSlash => ResourceManager.GetString("shift_shadowSlash", resourceCulture);

	internal static string shift_shiftLifter => ResourceManager.GetString("shift_shiftLifter", resourceCulture);

	internal static string shift_splitterDrop => ResourceManager.GetString("shift_splitterDrop", resourceCulture);

	internal static string shift_splitterSlash => ResourceManager.GetString("shift_splitterSlash", resourceCulture);

	internal static string shiftBlade => ResourceManager.GetString("shiftBlade", resourceCulture);

	internal static string shiftBladeUpgradeDesc1 => ResourceManager.GetString("shiftBladeUpgradeDesc1", resourceCulture);

	internal static string shopBuy => ResourceManager.GetString("shopBuy", resourceCulture);

	internal static string shopDone => ResourceManager.GetString("shopDone", resourceCulture);

	internal static string shopTut1 => ResourceManager.GetString("shopTut1", resourceCulture);

	internal static string shopTut2 => ResourceManager.GetString("shopTut2", resourceCulture);

	internal static string shopTut3 => ResourceManager.GetString("shopTut3", resourceCulture);

	internal static string shotgun => ResourceManager.GetString("shotgun", resourceCulture);

	internal static string shottyArmTut1 => ResourceManager.GetString("shottyArmTut1", resourceCulture);

	internal static string shottyArmTut2 => ResourceManager.GetString("shottyArmTut2", resourceCulture);

	internal static string shottyArmTut3 => ResourceManager.GetString("shottyArmTut3", resourceCulture);

	internal static string shottyTut1 => ResourceManager.GetString("shottyTut1", resourceCulture);

	internal static string shottyTut2 => ResourceManager.GetString("shottyTut2", resourceCulture);

	internal static string shottyTut3 => ResourceManager.GetString("shottyTut3", resourceCulture);

	internal static string shottyUpgrade => ResourceManager.GetString("shottyUpgrade", resourceCulture);

	internal static string showGamercard => ResourceManager.GetString("showGamercard", resourceCulture);

	internal static string SHOWGAMERCARDCAPS => ResourceManager.GetString("SHOWGAMERCARDCAPS", resourceCulture);

	internal static string showScore => ResourceManager.GetString("showScore", resourceCulture);

	internal static string showTime => ResourceManager.GetString("showTime", resourceCulture);

	internal static string signedInFail => ResourceManager.GetString("signedInFail", resourceCulture);

	internal static string signedOutOrSwitched1 => ResourceManager.GetString("signedOutOrSwitched1", resourceCulture);

	internal static string signedOutOrSwitched2 => ResourceManager.GetString("signedOutOrSwitched2", resourceCulture);

	internal static string signedOutOrSwitched3 => ResourceManager.GetString("signedOutOrSwitched3", resourceCulture);

	internal static string signedOutOrSwitched4 => ResourceManager.GetString("signedOutOrSwitched4", resourceCulture);

	internal static string sin_sin_0_text1_0_0 => ResourceManager.GetString("sin_sin_0_text1_0_0", resourceCulture);

	internal static string sin_sin_0_text1_0_1 => ResourceManager.GetString("sin_sin_0_text1_0_1", resourceCulture);

	internal static string sin_sin_0_text2_1_0 => ResourceManager.GetString("sin_sin_0_text2_1_0", resourceCulture);

	internal static string sin_sin_0_text3_2_0 => ResourceManager.GetString("sin_sin_0_text3_2_0", resourceCulture);

	internal static string sin_sin_0_text3_2_1 => ResourceManager.GetString("sin_sin_0_text3_2_1", resourceCulture);

	internal static string sin_sin_0_text4_3_0 => ResourceManager.GetString("sin_sin_0_text4_3_0", resourceCulture);

	internal static string sin_sin_0_text5_4_0 => ResourceManager.GetString("sin_sin_0_text5_4_0", resourceCulture);

	internal static string sin_sin_0_text5_4_1 => ResourceManager.GetString("sin_sin_0_text5_4_1", resourceCulture);

	internal static string sin_sin_0_text6_5_0 => ResourceManager.GetString("sin_sin_0_text6_5_0", resourceCulture);

	internal static string sin_sin_0_text7_6_0 => ResourceManager.GetString("sin_sin_0_text7_6_0", resourceCulture);

	internal static string singlePlayer => ResourceManager.GetString("singlePlayer", resourceCulture);

	internal static string skip => ResourceManager.GetString("skip", resourceCulture);

	internal static string skullBead => ResourceManager.GetString("skullBead", resourceCulture);

	internal static string skullBeadDesc1 => ResourceManager.GetString("skullBeadDesc1", resourceCulture);

	internal static string skullBeadDesc2 => ResourceManager.GetString("skullBeadDesc2", resourceCulture);

	internal static string slava_hurt_slava_0_text1_0_0 => ResourceManager.GetString("slava_hurt_slava_0_text1_0_0", resourceCulture);

	internal static string slava_hurt_slava_0_text2_1_0 => ResourceManager.GetString("slava_hurt_slava_0_text2_1_0", resourceCulture);

	internal static string slava_hurt_slava_0_text3_2_0 => ResourceManager.GetString("slava_hurt_slava_0_text3_2_0", resourceCulture);

	internal static string slava_hurt_slava_0_text3_2_1 => ResourceManager.GetString("slava_hurt_slava_0_text3_2_1", resourceCulture);

	internal static string slava_hurt_slava_0_text4_3_0 => ResourceManager.GetString("slava_hurt_slava_0_text4_3_0", resourceCulture);

	internal static string slava_hurt_slava_0_text5_4_0 => ResourceManager.GetString("slava_hurt_slava_0_text5_4_0", resourceCulture);

	internal static string slava_hurt_slava_0_text6_5_0 => ResourceManager.GetString("slava_hurt_slava_0_text6_5_0", resourceCulture);

	internal static string slava_kill_slava_0_text1_0_0 => ResourceManager.GetString("slava_kill_slava_0_text1_0_0", resourceCulture);

	internal static string slava_kill_slava_0_text2_1_0 => ResourceManager.GetString("slava_kill_slava_0_text2_1_0", resourceCulture);

	internal static string slava_kill_slava_0_text2_1_1 => ResourceManager.GetString("slava_kill_slava_0_text2_1_1", resourceCulture);

	internal static string slava_kill_slava_0_text3_2_0 => ResourceManager.GetString("slava_kill_slava_0_text3_2_0", resourceCulture);

	internal static string slava_kill_slava_0_text4_3_0 => ResourceManager.GetString("slava_kill_slava_0_text4_3_0", resourceCulture);

	internal static string slava_kill_slava_0_text4_3_1 => ResourceManager.GetString("slava_kill_slava_0_text4_3_1", resourceCulture);

	internal static string smg => ResourceManager.GetString("smg", resourceCulture);

	internal static string smgUpgradeDesc1 => ResourceManager.GetString("smgUpgradeDesc1", resourceCulture);

	internal static string solo_heavyMental => ResourceManager.GetString("solo_heavyMental", resourceCulture);

	internal static string solo_ninjaRiffer => ResourceManager.GetString("solo_ninjaRiffer", resourceCulture);

	internal static string solo_perfect => ResourceManager.GetString("solo_perfect", resourceCulture);

	internal static string solo_poisonousPotential => ResourceManager.GetString("solo_poisonousPotential", resourceCulture);

	internal static string solo_rockFail => ResourceManager.GetString("solo_rockFail", resourceCulture);

	internal static string solo_skillDeficient => ResourceManager.GetString("solo_skillDeficient", resourceCulture);

	internal static string solo_sonicSamurai => ResourceManager.GetString("solo_sonicSamurai", resourceCulture);

	internal static string solo_spuriousStrings => ResourceManager.GetString("solo_spuriousStrings", resourceCulture);

	internal static string speedRun => ResourceManager.GetString("speedRun", resourceCulture);

	internal static string speedRunDishwasher => ResourceManager.GetString("speedRunDishwasher", resourceCulture);

	internal static string speedRunYuki => ResourceManager.GetString("speedRunYuki", resourceCulture);

	internal static string spiderBead => ResourceManager.GetString("spiderBead", resourceCulture);

	internal static string spiderBeadDesc1 => ResourceManager.GetString("spiderBeadDesc1", resourceCulture);

	internal static string spiderBeadDesc2 => ResourceManager.GetString("spiderBeadDesc2", resourceCulture);

	internal static string spiritBloodMagic => ResourceManager.GetString("spiritBloodMagic", resourceCulture);

	internal static string spiritDishMagic => ResourceManager.GetString("spiritDishMagic", resourceCulture);

	internal static string splitAerials => ResourceManager.GetString("splitAerials", resourceCulture);

	internal static string splitAerials_desc1 => ResourceManager.GetString("splitAerials_desc1", resourceCulture);

	internal static string splitAerials_desc2 => ResourceManager.GetString("splitAerials_desc2", resourceCulture);

	internal static string splitAerials_desc3 => ResourceManager.GetString("splitAerials_desc3", resourceCulture);

	internal static string splitAerials_desc4 => ResourceManager.GetString("splitAerials_desc4", resourceCulture);

	internal static string squidBead => ResourceManager.GetString("squidBead", resourceCulture);

	internal static string squidBeadDesc1 => ResourceManager.GetString("squidBeadDesc1", resourceCulture);

	internal static string squidBeadDesc2 => ResourceManager.GetString("squidBeadDesc2", resourceCulture);

	internal static string squidChips => ResourceManager.GetString("squidChips", resourceCulture);

	internal static string squidChipsDesc1 => ResourceManager.GetString("squidChipsDesc1", resourceCulture);

	internal static string squidChipsDesc2 => ResourceManager.GetString("squidChipsDesc2", resourceCulture);

	internal static string stadiumKey => ResourceManager.GetString("stadiumKey", resourceCulture);

	internal static string start_1_0_text_0_0 => ResourceManager.GetString("start_1_0_text_0_0", resourceCulture);

	internal static string steelBloodMagic => ResourceManager.GetString("steelBloodMagic", resourceCulture);

	internal static string steelBloodMagicTut1 => ResourceManager.GetString("steelBloodMagicTut1", resourceCulture);

	internal static string steelBloodMagicTut2 => ResourceManager.GetString("steelBloodMagicTut2", resourceCulture);

	internal static string steelBloodMagicTut3 => ResourceManager.GetString("steelBloodMagicTut3", resourceCulture);

	internal static string steelBloodMagicTut4 => ResourceManager.GetString("steelBloodMagicTut4", resourceCulture);

	internal static string steelBloodMagicTut5 => ResourceManager.GetString("steelBloodMagicTut5", resourceCulture);

	internal static string steelBloodMagicTut6 => ResourceManager.GetString("steelBloodMagicTut6", resourceCulture);

	internal static string steelBloodMagicTut7 => ResourceManager.GetString("steelBloodMagicTut7", resourceCulture);

	internal static string steelBloodMagicTut8 => ResourceManager.GetString("steelBloodMagicTut8", resourceCulture);

	internal static string steelDishMagic => ResourceManager.GetString("steelDishMagic", resourceCulture);

	internal static string steelDishMagicTut1 => ResourceManager.GetString("steelDishMagicTut1", resourceCulture);

	internal static string steelDishMagicTut2 => ResourceManager.GetString("steelDishMagicTut2", resourceCulture);

	internal static string steelDishMagicTut3 => ResourceManager.GetString("steelDishMagicTut3", resourceCulture);

	internal static string steelDishMagicTut4 => ResourceManager.GetString("steelDishMagicTut4", resourceCulture);

	internal static string steelDishMagicTut5 => ResourceManager.GetString("steelDishMagicTut5", resourceCulture);

	internal static string steelDishMagicTut6 => ResourceManager.GetString("steelDishMagicTut6", resourceCulture);

	internal static string steelDishMagicTut7 => ResourceManager.GetString("steelDishMagicTut7", resourceCulture);

	internal static string steelDishMagicTut8 => ResourceManager.GetString("steelDishMagicTut8", resourceCulture);

	internal static string storageDeviceChanged1 => ResourceManager.GetString("storageDeviceChanged1", resourceCulture);

	internal static string storageDeviceChanged2 => ResourceManager.GetString("storageDeviceChanged2", resourceCulture);

	internal static string storyMode => ResourceManager.GetString("storyMode", resourceCulture);

	internal static string strongSaw => ResourceManager.GetString("strongSaw", resourceCulture);

	internal static string stunnedTut1 => ResourceManager.GetString("stunnedTut1", resourceCulture);

	internal static string stunnedTut2 => ResourceManager.GetString("stunnedTut2", resourceCulture);

	internal static string stunnedTut3 => ResourceManager.GetString("stunnedTut3", resourceCulture);

	internal static string summitKey => ResourceManager.GetString("summitKey", resourceCulture);

	internal static string sunkenArmory => ResourceManager.GetString("sunkenArmory", resourceCulture);

	internal static string switchLoadouts => ResourceManager.GetString("switchLoadouts", resourceCulture);

	internal static string switchWeapons => ResourceManager.GetString("switchWeapons", resourceCulture);

	internal static string syringe_addictsImpaler => ResourceManager.GetString("syringe_addictsImpaler", resourceCulture);

	internal static string syringe_airPunch => ResourceManager.GetString("syringe_airPunch", resourceCulture);

	internal static string syringe_bloodCocktail => ResourceManager.GetString("syringe_bloodCocktail", resourceCulture);

	internal static string syringe_bonePunch => ResourceManager.GetString("syringe_bonePunch", resourceCulture);

	internal static string syringe_clinicalShot => ResourceManager.GetString("syringe_clinicalShot", resourceCulture);

	internal static string syringe_eyestabber => ResourceManager.GetString("syringe_eyestabber", resourceCulture);

	internal static string syringe_finalDrain => ResourceManager.GetString("syringe_finalDrain", resourceCulture);

	internal static string syringe_hypodermicRain => ResourceManager.GetString("syringe_hypodermicRain", resourceCulture);

	internal static string syringe_hypodermicStorm => ResourceManager.GetString("syringe_hypodermicStorm", resourceCulture);

	internal static string syringe_immunoUppercut => ResourceManager.GetString("syringe_immunoUppercut", resourceCulture);

	internal static string syringe_morbidDrain => ResourceManager.GetString("syringe_morbidDrain", resourceCulture);

	internal static string syringe_numbingDrain => ResourceManager.GetString("syringe_numbingDrain", resourceCulture);

	internal static string syringe_plasticDevour => ResourceManager.GetString("syringe_plasticDevour", resourceCulture);

	internal static string syringe_plungerDrop => ResourceManager.GetString("syringe_plungerDrop", resourceCulture);

	internal static string syringe_quickShot => ResourceManager.GetString("syringe_quickShot", resourceCulture);

	internal static string syringe_skyPlunger => ResourceManager.GetString("syringe_skyPlunger", resourceCulture);

	internal static string syringe_sterilShot => ResourceManager.GetString("syringe_sterilShot", resourceCulture);

	internal static string syringe_sterilUppercut => ResourceManager.GetString("syringe_sterilUppercut", resourceCulture);

	internal static string syringe_sterlize => ResourceManager.GetString("syringe_sterlize", resourceCulture);

	internal static string syringe_straightShot => ResourceManager.GetString("syringe_straightShot", resourceCulture);

	internal static string syringe_viciousStab => ResourceManager.GetString("syringe_viciousStab", resourceCulture);

	internal static string syringe_wallPlunger => ResourceManager.GetString("syringe_wallPlunger", resourceCulture);

	internal static string theDishwasher => ResourceManager.GetString("theDishwasher", resourceCulture);

	internal static string theGuillotine => ResourceManager.GetString("theGuillotine", resourceCulture);

	internal static string thePit => ResourceManager.GetString("thePit", resourceCulture);

	internal static string theprisoner => ResourceManager.GetString("theprisoner", resourceCulture);

	internal static string theStagnantNightmare => ResourceManager.GetString("theStagnantNightmare", resourceCulture);

	internal static string threedee => ResourceManager.GetString("threedee", resourceCulture);

	internal static string threedeeBead => ResourceManager.GetString("threedeeBead", resourceCulture);

	internal static string threedeeBeadDesc1 => ResourceManager.GetString("threedeeBeadDesc1", resourceCulture);

	internal static string threedeetvoff => ResourceManager.GetString("threedeetvoff", resourceCulture);

	internal static string threedeetvon => ResourceManager.GetString("threedeetvon", resourceCulture);

	internal static string timebridge_1_0_text1_0_0 => ResourceManager.GetString("timebridge_1_0_text1_0_0", resourceCulture);

	internal static string timebridge_2_2_text1_0_0 => ResourceManager.GetString("timebridge_2_2_text1_0_0", resourceCulture);

	internal static string timebridge_3_4_text1_0_0 => ResourceManager.GetString("timebridge_3_4_text1_0_0", resourceCulture);

	internal static string timebridge_3_4_text1_0_1 => ResourceManager.GetString("timebridge_3_4_text1_0_1", resourceCulture);

	internal static string timebridge_3_4_text2_1_0 => ResourceManager.GetString("timebridge_3_4_text2_1_0", resourceCulture);

	internal static string timebridge_4_6_text1_0_0 => ResourceManager.GetString("timebridge_4_6_text1_0_0", resourceCulture);

	internal static string timebridge_5_8_text1_0_0 => ResourceManager.GetString("timebridge_5_8_text1_0_0", resourceCulture);

	internal static string timebridge_5_8_text2_1_0 => ResourceManager.GetString("timebridge_5_8_text2_1_0", resourceCulture);

	internal static string timebridge_board_3_text1_0_0 => ResourceManager.GetString("timebridge_board_3_text1_0_0", resourceCulture);

	internal static string timebridge_board_3_text2_1_0 => ResourceManager.GetString("timebridge_board_3_text2_1_0", resourceCulture);

	internal static string timebridge_board_3_text3_2_0 => ResourceManager.GetString("timebridge_board_3_text3_2_0", resourceCulture);

	internal static string timebridge_board_3_text3_2_1 => ResourceManager.GetString("timebridge_board_3_text3_2_1", resourceCulture);

	internal static string timebridge_board_3_text4_3_0 => ResourceManager.GetString("timebridge_board_3_text4_3_0", resourceCulture);

	internal static string timebridge_church_1_text1_0_0 => ResourceManager.GetString("timebridge_church_1_text1_0_0", resourceCulture);

	internal static string timebridge_church_1_text2_1_0 => ResourceManager.GetString("timebridge_church_1_text2_1_0", resourceCulture);

	internal static string timebridge_church_1_text3_2_0 => ResourceManager.GetString("timebridge_church_1_text3_2_0", resourceCulture);

	internal static string timebridge_in_9_text1_0_0 => ResourceManager.GetString("timebridge_in_9_text1_0_0", resourceCulture);

	internal static string timebridge_in_9_text2_1_0 => ResourceManager.GetString("timebridge_in_9_text2_1_0", resourceCulture);

	internal static string timebridge_news_5_text1_0_0 => ResourceManager.GetString("timebridge_news_5_text1_0_0", resourceCulture);

	internal static string timebridge_news_5_text2_1_0 => ResourceManager.GetString("timebridge_news_5_text2_1_0", resourceCulture);

	internal static string timebridge_news_5_text3_2_0 => ResourceManager.GetString("timebridge_news_5_text3_2_0", resourceCulture);

	internal static string timebridge_news_5_text4_3_0 => ResourceManager.GetString("timebridge_news_5_text4_3_0", resourceCulture);

	internal static string timebridge_news_5_text5_4_0 => ResourceManager.GetString("timebridge_news_5_text5_4_0", resourceCulture);

	internal static string timebridge_prison_7_text1_0_0 => ResourceManager.GetString("timebridge_prison_7_text1_0_0", resourceCulture);

	internal static string timebridge_prison_7_text2_1_0 => ResourceManager.GetString("timebridge_prison_7_text2_1_0", resourceCulture);

	internal static string timebridge_prison_7_text3_2_0 => ResourceManager.GetString("timebridge_prison_7_text3_2_0", resourceCulture);

	internal static string timebridge_prison_7_text4_3_0 => ResourceManager.GetString("timebridge_prison_7_text4_3_0", resourceCulture);

	internal static string timebridge_prison_7_text5_4_0 => ResourceManager.GetString("timebridge_prison_7_text5_4_0", resourceCulture);

	internal static string toaster_aerialAppliance => ResourceManager.GetString("toaster_aerialAppliance", resourceCulture);

	internal static string toaster_airpliance => ResourceManager.GetString("toaster_airpliance", resourceCulture);

	internal static string toaster_breakfastBash => ResourceManager.GetString("toaster_breakfastBash", resourceCulture);

	internal static string toaster_clobber => ResourceManager.GetString("toaster_clobber", resourceCulture);

	internal static string toaster_electricUppercut => ResourceManager.GetString("toaster_electricUppercut", resourceCulture);

	internal static string toaster_flyingSoak => ResourceManager.GetString("toaster_flyingSoak", resourceCulture);

	internal static string toaster_kitchenCombo => ResourceManager.GetString("toaster_kitchenCombo", resourceCulture);

	internal static string toaster_razorCord => ResourceManager.GetString("toaster_razorCord", resourceCulture);

	internal static string toaster_superSoak => ResourceManager.GetString("toaster_superSoak", resourceCulture);

	internal static string toaster_toasterInTheTub => ResourceManager.GetString("toaster_toasterInTheTub", resourceCulture);

	internal static string toasterTut1 => ResourceManager.GetString("toasterTut1", resourceCulture);

	internal static string toasterTut2 => ResourceManager.GetString("toasterTut2", resourceCulture);

	internal static string toasterTut3 => ResourceManager.GetString("toasterTut3", resourceCulture);

	internal static string totalentries => ResourceManager.GetString("totalentries", resourceCulture);

	internal static string totalPlayers => ResourceManager.GetString("totalPlayers", resourceCulture);

	internal static string tourney => ResourceManager.GetString("tourney", resourceCulture);

	internal static string towerKey => ResourceManager.GetString("towerKey", resourceCulture);

	internal static string unlockedDishwasherCampaign => ResourceManager.GetString("unlockedDishwasherCampaign", resourceCulture);

	internal static string unlockedsamuraiDiff1 => ResourceManager.GetString("unlockedsamuraiDiff1", resourceCulture);

	internal static string unlockedsamuraiDiff2 => ResourceManager.GetString("unlockedsamuraiDiff2", resourceCulture);

	internal static string unlockFullGame => ResourceManager.GetString("unlockFullGame", resourceCulture);

	internal static string updating => ResourceManager.GetString("updating", resourceCulture);

	internal static string use => ResourceManager.GetString("use", resourceCulture);

	internal static string used => ResourceManager.GetString("used", resourceCulture);

	internal static string uziTut1 => ResourceManager.GetString("uziTut1", resourceCulture);

	internal static string uziTut2 => ResourceManager.GetString("uziTut2", resourceCulture);

	internal static string uziTut3 => ResourceManager.GetString("uziTut3", resourceCulture);

	internal static string uziTut4 => ResourceManager.GetString("uziTut4", resourceCulture);

	internal static string uziTut5 => ResourceManager.GetString("uziTut5", resourceCulture);

	internal static string vampire => ResourceManager.GetString("vampire", resourceCulture);

	internal static string vampire_desc1 => ResourceManager.GetString("vampire_desc1", resourceCulture);

	internal static string vampire_desc2 => ResourceManager.GetString("vampire_desc2", resourceCulture);

	internal static string vampire_desc3 => ResourceManager.GetString("vampire_desc3", resourceCulture);

	internal static string vampire_desc4 => ResourceManager.GetString("vampire_desc4", resourceCulture);

	internal static string vaultKey => ResourceManager.GetString("vaultKey", resourceCulture);

	internal static string vibration => ResourceManager.GetString("vibration", resourceCulture);

	internal static string vibrationoff => ResourceManager.GetString("vibrationoff", resourceCulture);

	internal static string vibrationon => ResourceManager.GetString("vibrationon", resourceCulture);

	internal static string viewGamercard => ResourceManager.GetString("viewGamercard", resourceCulture);

	internal static string viewLeaderboards => ResourceManager.GetString("viewLeaderboards", resourceCulture);

	internal static string violenceHammer => ResourceManager.GetString("violenceHammer", resourceCulture);

	internal static string violenceHammerUpgradeDesc1 => ResourceManager.GetString("violenceHammerUpgradeDesc1", resourceCulture);

	internal static string waiting => ResourceManager.GetString("waiting", resourceCulture);

	internal static string waitingForHost => ResourceManager.GetString("waitingForHost", resourceCulture);

	internal static string warpRoll => ResourceManager.GetString("warpRoll", resourceCulture);

	internal static string warpTut1 => ResourceManager.GetString("warpTut1", resourceCulture);

	internal static string warpTut2 => ResourceManager.GetString("warpTut2", resourceCulture);

	internal static string warpTut3 => ResourceManager.GetString("warpTut3", resourceCulture);

	internal static string warpTut4 => ResourceManager.GetString("warpTut4", resourceCulture);

	internal static string warpTut5 => ResourceManager.GetString("warpTut5", resourceCulture);

	internal static string weeklyRush => ResourceManager.GetString("weeklyRush", resourceCulture);

	internal static string Welcome => ResourceManager.GetString("Welcome", resourceCulture);

	internal static string whoContinues => ResourceManager.GetString("whoContinues", resourceCulture);

	internal static string wineBead => ResourceManager.GetString("wineBead", resourceCulture);

	internal static string wineBeadDesc1 => ResourceManager.GetString("wineBeadDesc1", resourceCulture);

	internal static string wineBeadDesc2 => ResourceManager.GetString("wineBeadDesc2", resourceCulture);

	internal static string writeFail => ResourceManager.GetString("writeFail", resourceCulture);

	internal static string writeFailed => ResourceManager.GetString("writeFailed", resourceCulture);

	internal static string xboxLive => ResourceManager.GetString("xboxLive", resourceCulture);

	internal static string xboxLiveArcade => ResourceManager.GetString("xboxLiveArcade", resourceCulture);

	internal static string xboxLiveMultiplayer => ResourceManager.GetString("xboxLiveMultiplayer", resourceCulture);

	internal static string youAreDead => ResourceManager.GetString("youAreDead", resourceCulture);

	internal static string youMustBeSignedInLive1 => ResourceManager.GetString("youMustBeSignedInLive1", resourceCulture);

	internal static string youMustBeSignedInLive2 => ResourceManager.GetString("youMustBeSignedInLive2", resourceCulture);

	internal static string youMustBeSignedInLive3 => ResourceManager.GetString("youMustBeSignedInLive3", resourceCulture);

	internal static string youWillLose1 => ResourceManager.GetString("youWillLose1", resourceCulture);

	internal static string youWillLose2 => ResourceManager.GetString("youWillLose2", resourceCulture);

	internal static string yuki => ResourceManager.GetString("yuki", resourceCulture);

	internal static string yuki_aqua_yuki_0_text_0_0 => ResourceManager.GetString("yuki_aqua_yuki_0_text_0_0", resourceCulture);

	internal static string yuki_aqua_yuki_0_text_1_0 => ResourceManager.GetString("yuki_aqua_yuki_0_text_1_0", resourceCulture);

	internal static string yuki_aqua_yuki_0_text_2_0 => ResourceManager.GetString("yuki_aqua_yuki_0_text_2_0", resourceCulture);

	internal static string yuki_aqua_yuki_0_text_2_1 => ResourceManager.GetString("yuki_aqua_yuki_0_text_2_1", resourceCulture);

	internal static string yuki_aqua_yuki_0_text_3_0 => ResourceManager.GetString("yuki_aqua_yuki_0_text_3_0", resourceCulture);

	internal static string yuki_aqua_yuki_0_text_4_0 => ResourceManager.GetString("yuki_aqua_yuki_0_text_4_0", resourceCulture);

	internal static string yuki_cafe_yuki_0_text1_0_0 => ResourceManager.GetString("yuki_cafe_yuki_0_text1_0_0", resourceCulture);

	internal static string yuki_cafe_yuki_0_text2_1_0 => ResourceManager.GetString("yuki_cafe_yuki_0_text2_1_0", resourceCulture);

	internal static string yuki_cafe_yuki_0_text3_2_0 => ResourceManager.GetString("yuki_cafe_yuki_0_text3_2_0", resourceCulture);

	internal static string yuki_cafe_yuki_0_text4_3_0 => ResourceManager.GetString("yuki_cafe_yuki_0_text4_3_0", resourceCulture);

	internal static string yuki_cafe_yuki_0_text5_4_0 => ResourceManager.GetString("yuki_cafe_yuki_0_text5_4_0", resourceCulture);

	internal static string yuki_closet_yuki_0_text1_0_0 => ResourceManager.GetString("yuki_closet_yuki_0_text1_0_0", resourceCulture);

	internal static string yuki_closet_yuki_0_text2_1_0 => ResourceManager.GetString("yuki_closet_yuki_0_text2_1_0", resourceCulture);

	internal static string yuki_closet_yuki_0_text2_1_1 => ResourceManager.GetString("yuki_closet_yuki_0_text2_1_1", resourceCulture);

	internal static string yuki_closet_yuki_0_text3_2_0 => ResourceManager.GetString("yuki_closet_yuki_0_text3_2_0", resourceCulture);

	internal static string yuki_closet_yuki_0_text3_2_1 => ResourceManager.GetString("yuki_closet_yuki_0_text3_2_1", resourceCulture);

	internal static string yuki_closet_yuki_0_text4_3_0 => ResourceManager.GetString("yuki_closet_yuki_0_text4_3_0", resourceCulture);

	internal static string yuki_crypt_yuki_0_text1_0_0 => ResourceManager.GetString("yuki_crypt_yuki_0_text1_0_0", resourceCulture);

	internal static string yuki_crypt_yuki_0_text2_1_0 => ResourceManager.GetString("yuki_crypt_yuki_0_text2_1_0", resourceCulture);

	internal static string yuki_crypt_yuki_0_text2_1_1 => ResourceManager.GetString("yuki_crypt_yuki_0_text2_1_1", resourceCulture);

	internal static string yuki_crypt_yuki_0_text3_2_0 => ResourceManager.GetString("yuki_crypt_yuki_0_text3_2_0", resourceCulture);

	internal static string yuki_crypt_yuki_0_text4_3_0 => ResourceManager.GetString("yuki_crypt_yuki_0_text4_3_0", resourceCulture);

	internal static string yuki_crypt_yuki_0_text5_4_0 => ResourceManager.GetString("yuki_crypt_yuki_0_text5_4_0", resourceCulture);

	internal static string yuki_crypt_yuki_0_text6_5_0 => ResourceManager.GetString("yuki_crypt_yuki_0_text6_5_0", resourceCulture);

	internal static string yuki_crypt_yuki_0_text6_5_1 => ResourceManager.GetString("yuki_crypt_yuki_0_text6_5_1", resourceCulture);

	internal static string yuki_gross_gross_0_text1_0_0 => ResourceManager.GetString("yuki_gross_gross_0_text1_0_0", resourceCulture);

	internal static string yuki_gross_gross_0_text2_1_0 => ResourceManager.GetString("yuki_gross_gross_0_text2_1_0", resourceCulture);

	internal static string yuki_gross_gross_0_text2_1_1 => ResourceManager.GetString("yuki_gross_gross_0_text2_1_1", resourceCulture);

	internal static string yuki_gross_gross_0_text3_2_0 => ResourceManager.GetString("yuki_gross_gross_0_text3_2_0", resourceCulture);

	internal static string yuki_gross_gross_0_text4_3_0 => ResourceManager.GetString("yuki_gross_gross_0_text4_3_0", resourceCulture);

	internal static string yuki_gross_gross_0_text5_4_0 => ResourceManager.GetString("yuki_gross_gross_0_text5_4_0", resourceCulture);

	internal static string yuki_gross_gross_0_text6_5_0 => ResourceManager.GetString("yuki_gross_gross_0_text6_5_0", resourceCulture);

	internal static string yuki_gross_gross_0_text7_6_0 => ResourceManager.GetString("yuki_gross_gross_0_text7_6_0", resourceCulture);

	internal static string yuki_gross_gross_0_text8_7_0 => ResourceManager.GetString("yuki_gross_gross_0_text8_7_0", resourceCulture);

	internal static string yuki_gross_gross_0_text9_8_0 => ResourceManager.GetString("yuki_gross_gross_0_text9_8_0", resourceCulture);

	internal static string yuki_ohno_dish_0_text1_0_0 => ResourceManager.GetString("yuki_ohno_dish_0_text1_0_0", resourceCulture);

	internal static string yuki_ohno_dish_0_text2_1_0 => ResourceManager.GetString("yuki_ohno_dish_0_text2_1_0", resourceCulture);

	internal static string yuki_ohno_dish_0_text2_1_1 => ResourceManager.GetString("yuki_ohno_dish_0_text2_1_1", resourceCulture);

	internal static string yuki_ohno_dish_0_text3_2_0 => ResourceManager.GetString("yuki_ohno_dish_0_text3_2_0", resourceCulture);

	internal static string yuki_ohno_dish_0_text3_2_1 => ResourceManager.GetString("yuki_ohno_dish_0_text3_2_1", resourceCulture);

	internal static string yuki_ohno_dish_2_text1_0_0 => ResourceManager.GetString("yuki_ohno_dish_2_text1_0_0", resourceCulture);

	internal static string yuki_ohno_dish_2_text1_0_1 => ResourceManager.GetString("yuki_ohno_dish_2_text1_0_1", resourceCulture);

	internal static string yuki_ohno_dish_2_text2_1_0 => ResourceManager.GetString("yuki_ohno_dish_2_text2_1_0", resourceCulture);

	internal static string yuki_ohno_dish_2_text2_1_1 => ResourceManager.GetString("yuki_ohno_dish_2_text2_1_1", resourceCulture);

	internal static string yuki_ohno_dish_2_text2_1_2 => ResourceManager.GetString("yuki_ohno_dish_2_text2_1_2", resourceCulture);

	internal static string yuki_ohno_dish_2_text3_2_0 => ResourceManager.GetString("yuki_ohno_dish_2_text3_2_0", resourceCulture);

	internal static string yuki_ohno_dish_2_text3_2_1 => ResourceManager.GetString("yuki_ohno_dish_2_text3_2_1", resourceCulture);

	internal static string yuki_ohno_yuki_1_text1_0_0 => ResourceManager.GetString("yuki_ohno_yuki_1_text1_0_0", resourceCulture);

	internal static string yuki_ohno_yuki_1_text2_1_0 => ResourceManager.GetString("yuki_ohno_yuki_1_text2_1_0", resourceCulture);

	internal static string yuki_ohno_yuki_1_text3_2_0 => ResourceManager.GetString("yuki_ohno_yuki_1_text3_2_0", resourceCulture);

	internal static string yuki_ohno_yuki_1_text3_2_1 => ResourceManager.GetString("yuki_ohno_yuki_1_text3_2_1", resourceCulture);

	internal static string yuki_prison_hockey_0_text_0_0 => ResourceManager.GetString("yuki_prison_hockey_0_text_0_0", resourceCulture);

	internal static string yuki_prison_hockey_0_text_1_0 => ResourceManager.GetString("yuki_prison_hockey_0_text_1_0", resourceCulture);

	internal static string yuki_prison_hockey_0_text_2_0 => ResourceManager.GetString("yuki_prison_hockey_0_text_2_0", resourceCulture);

	internal static string yuki_prison_hockey_0_text_3_0 => ResourceManager.GetString("yuki_prison_hockey_0_text_3_0", resourceCulture);

	internal static string yuki_prison_hockey_0_text_3_1 => ResourceManager.GetString("yuki_prison_hockey_0_text_3_1", resourceCulture);

	internal static string yuki_prison_hockey_0_text_4_0 => ResourceManager.GetString("yuki_prison_hockey_0_text_4_0", resourceCulture);

	internal static string yuki_prison_hockey_0_text_5_0 => ResourceManager.GetString("yuki_prison_hockey_0_text_5_0", resourceCulture);

	internal static string yuki_prison_prison_1_text1_0_0 => ResourceManager.GetString("yuki_prison_prison_1_text1_0_0", resourceCulture);

	internal static string yuki_prison_prison_1_text2_1_0 => ResourceManager.GetString("yuki_prison_prison_1_text2_1_0", resourceCulture);

	internal static string yuki_prison_prison_1_text3_2_0 => ResourceManager.GetString("yuki_prison_prison_1_text3_2_0", resourceCulture);

	internal static string yuki_prison_prison_1_text4_3_0 => ResourceManager.GetString("yuki_prison_prison_1_text4_3_0", resourceCulture);

	internal static string yuki_prison_prison_1_text5_4_0 => ResourceManager.GetString("yuki_prison_prison_1_text5_4_0", resourceCulture);

	internal static string yuki_prison_prison_1_text6_5_0 => ResourceManager.GetString("yuki_prison_prison_1_text6_5_0", resourceCulture);

	internal static string yuki_prison_prison_1_text6_5_1 => ResourceManager.GetString("yuki_prison_prison_1_text6_5_1", resourceCulture);

	internal static string yuki_prison_prison_1_text7_6_0 => ResourceManager.GetString("yuki_prison_prison_1_text7_6_0", resourceCulture);

	internal static string yuki_prison_prison_1_text7_6_1 => ResourceManager.GetString("yuki_prison_prison_1_text7_6_1", resourceCulture);

	internal static string yuki_prison_prison_1_text8_7_0 => ResourceManager.GetString("yuki_prison_prison_1_text8_7_0", resourceCulture);

	internal static string yuki_prison_prison_1_text8_7_1 => ResourceManager.GetString("yuki_prison_prison_1_text8_7_1", resourceCulture);

	internal static string yuki_prison_prison_1_text9_8_0 => ResourceManager.GetString("yuki_prison_prison_1_text9_8_0", resourceCulture);

	internal static string yuki_prison_prison_1_text9_8_1 => ResourceManager.GetString("yuki_prison_prison_1_text9_8_1", resourceCulture);

	internal static string yuki_puppets_puppet_0_text1_0_0 => ResourceManager.GetString("yuki_puppets_puppet_0_text1_0_0", resourceCulture);

	internal static string yuki_puppets_puppet_0_text2_1_0 => ResourceManager.GetString("yuki_puppets_puppet_0_text2_1_0", resourceCulture);

	internal static string yuki_puppets_puppet_0_text3_2_0 => ResourceManager.GetString("yuki_puppets_puppet_0_text3_2_0", resourceCulture);

	internal static string yuki_puppets_puppet_0_text4_3_0 => ResourceManager.GetString("yuki_puppets_puppet_0_text4_3_0", resourceCulture);

	internal static string yuki_rgb_dish_0_text1_0_0 => ResourceManager.GetString("yuki_rgb_dish_0_text1_0_0", resourceCulture);

	internal static string yuki_rgb_dish_0_text2_1_0 => ResourceManager.GetString("yuki_rgb_dish_0_text2_1_0", resourceCulture);

	internal static string yuki_rgb_dish_0_text3_2_0 => ResourceManager.GetString("yuki_rgb_dish_0_text3_2_0", resourceCulture);

	internal static string yuki_rgb_dish_0_text4_3_0 => ResourceManager.GetString("yuki_rgb_dish_0_text4_3_0", resourceCulture);

	internal static string yuki_rgb_dish_0_text5_4_0 => ResourceManager.GetString("yuki_rgb_dish_0_text5_4_0", resourceCulture);

	internal static string yuki_rgb_dish_0_text5_4_1 => ResourceManager.GetString("yuki_rgb_dish_0_text5_4_1", resourceCulture);

	internal static string yuki_window_yukiwindow_0_text_1_0 => ResourceManager.GetString("yuki_window_yukiwindow_0_text_1_0", resourceCulture);

	internal static string yuki_window_yukiwindow_0_text_2_0 => ResourceManager.GetString("yuki_window_yukiwindow_0_text_2_0", resourceCulture);

	internal static string yuki_window_yukiwindow_0_text_3_0 => ResourceManager.GetString("yuki_window_yukiwindow_0_text_3_0", resourceCulture);

	internal static string yuki_window_yukiwindow_0_text_4_0 => ResourceManager.GetString("yuki_window_yukiwindow_0_text_4_0", resourceCulture);

	internal static string zap_zap_0_box1_2_0 => ResourceManager.GetString("zap_zap_0_box1_2_0", resourceCulture);

	internal static string zap_zap_0_box2_3_0 => ResourceManager.GetString("zap_zap_0_box2_3_0", resourceCulture);

	internal static string zap_zap_0_box3_4_0 => ResourceManager.GetString("zap_zap_0_box3_4_0", resourceCulture);

	internal static string zap_zap_0_box4_5_0 => ResourceManager.GetString("zap_zap_0_box4_5_0", resourceCulture);

	internal static string pc_mousecontrols => ResourceManager.GetString("pc_mousecontrols", resourceCulture);

	internal static string pc_leftmb => ResourceManager.GetString("pc_leftmb", resourceCulture);

	internal static string pc_rightmb => ResourceManager.GetString("pc_rightmb", resourceCulture);

	internal static string pc_middlemb => ResourceManager.GetString("pc_middlemb", resourceCulture);

	internal static string pc_pauseconfirm => ResourceManager.GetString("pc_pauseconfirm", resourceCulture);

	internal static string pc_moveup => ResourceManager.GetString("pc_moveup", resourceCulture);

	internal static string pc_movedown => ResourceManager.GetString("pc_movedown", resourceCulture);

	internal static string pc_moveleft => ResourceManager.GetString("pc_moveleft", resourceCulture);

	internal static string pc_moveright => ResourceManager.GetString("pc_moveright", resourceCulture);

	internal static string pc_resettodefaults => ResourceManager.GetString("pc_resettodefaults", resourceCulture);

	internal static string pc_fullscreen => ResourceManager.GetString("pc_fullscreen", resourceCulture);

	internal static string pc_windowed => ResourceManager.GetString("pc_windowed", resourceCulture);

	internal static string pc_borderlesswindowed => ResourceManager.GetString("pc_borderlesswindowed", resourceCulture);

	internal static string pc_vsyncon => ResourceManager.GetString("pc_vsyncon", resourceCulture);

	internal static string pc_vsyncoff => ResourceManager.GetString("pc_vsyncoff", resourceCulture);

	internal static string pc_pauseonlostfocuson => ResourceManager.GetString("pc_pauseonlostfocuson", resourceCulture);

	internal static string pc_pauseonlostfocusoff => ResourceManager.GetString("pc_pauseonlostfocusoff", resourceCulture);

	internal static string pc_swapgunrollon => ResourceManager.GetString("pc_swapgunroll");

	internal static string pc_swapgunrolloff => ResourceManager.GetString("pc_swapgunrolloff");

	internal static string pc_quitQ => ResourceManager.GetString("pc_quitQ");

	internal YukiText()
	{
	}
}
