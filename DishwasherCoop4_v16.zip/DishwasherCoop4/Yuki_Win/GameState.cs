namespace Yuki_Win;

public class GameState
{
	public enum State
	{
		Menu,
		Playing,
		DrawWorldMode,
		Credits,
		Upsell
	}

	public static State state;

	public static float flowerFrame;

	public static bool paxDemoMode = false;

	public static bool longDemoMode = false;

	public static int paxLevel;
}
