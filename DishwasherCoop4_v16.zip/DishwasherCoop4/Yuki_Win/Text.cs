using System;
using System.Linq;
using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win;

public class Text
{
	public const int JUSTIFY_LEFT = 0;

	public const int JUSTIFY_MIDDLE = 1;

	public const int JUSTIFY_RIGHT = 2;

	public const int LANGUAGE_ENGLISH = 0;

	public const int LANGUAGE_PIGS = 1;

	public const int LANGUAGE_FRANCE = 2;

	public const int LANGUAGE_JAPAN = 3;

	public const int LANGUAGE_CHINA = 4;

	private const float JPN_CHAR_BLOCK = 24f;

	private const float CHT_CHAR_BLOCK = 26f;

	private const float JPN_SCALE = 0.51f;

	private const float CHT_SCALE = 0.51f;

	public const int REGION_US = 0;

	public const int REGION_WW = 1;

	public static int language;

	public static int region;

	public static float GetStringSpace(StringBuilder text)
	{
		float num = 0f;
		if (text == null)
		{
			return 0f;
		}
		try
		{
			for (int i = 0; i < text.Length; i++)
			{
				if (text[i] == '[')
				{
					num += 32f;
					i += 2;
				}
				else if (text[i] < '⻠')
				{
					num += getCTextSpace(text[i]);
				}
				else
				{
					num = ((language != 4) ? (num + 24f) : (num + 26f));
				}
			}
		}
		catch
		{
		}
		return num;
	}

	public static void DrawBlockString(SpriteBatch sprite, Vector2 loc, StringBuilder text, float size, Color c)
	{
		float num = 0f;
		for (int i = 0; i < text.Length; i++)
		{
			int num2 = -1;
			int num3 = text[i];
			if (num3 >= 97 && num3 <= 122)
			{
				num2 = num3 - 97;
			}
			else if (num3 >= 48 && num3 <= 57)
			{
				num2 = 26 + (num3 - 48);
			}
			else
			{
				switch (text[i])
				{
				case 'A':
					num2 = 37;
					break;
				case 'O':
					num2 = 36;
					break;
				case '\'':
					num2 = 38;
					break;
				case '!':
					num2 = 39;
					break;
				case '"':
					num2 = 40;
					break;
				}
			}
			sprite.Draw(Game1.blockText, new Vector2(num, 0f) + loc, new Rectangle(num2 % 8 * 64, num2 / 8 * 64, 64, 64), c, 0f, default, size, SpriteEffects.None, 1f);
			num += GetBlockCharSize(text[i]) * size;
		}
	}

	public static float GetBlockStringLength(StringBuilder s)
	{
		float num = 0f;
		for (int i = 0; i < s.Length; i++)
		{
			num += GetBlockCharSize(s[i]);
		}
		return num;
	}

	public static void DrawBlockyTwoLines(SpriteBatch sprite, Vector2 loc, float maxSize, StringBuilder line1, StringBuilder line2, float alpha)
	{
		for (int i = 0; i < 2; i++)
		{
			if (i == 0)
			{
				SpriteTools.BeginAlpha();
			}
			else
			{
				SpriteTools.BeginAdditive();
			}
			if (i == 0)
			{
				sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, 0.1f));
			}
			float num = ((i == 0) ? 2000f : maxSize);
			float blockStringLength = GetBlockStringLength(line1);
			float num2 = num / blockStringLength;
			float num3 = ((i == 0) ? 0f : 1f);
			float alpha2 = ((i == 0) ? 0.2f : alpha);
			Vector2 vector = ((i == 0) ? new Vector2(-500f, -500f) : default(Vector2));
			DrawBlockString(sprite, loc + vector, line1, num2, new Color(num3, num3, num3, alpha2));
			blockStringLength = GetBlockStringLength(line2);
			DrawBlockString(sprite, loc + new Vector2(0f, num2 * 62f) + vector, line2, num / blockStringLength, new Color(num3, num3, num3, alpha2));
			sprite.End();
		}
	}

	private static float GetBlockCharSize(char c)
	{
		switch (c)
		{
		case '!':
			return 8f;
		case '\'':
			return 9f;
		case '"':
		case 'i':
			return 12f;
		case '1':
			return 20f;
		case 'v':
		case 'y':
			return 22f;
		case '4':
			return 24f;
		case 'j':
		case 'l':
		case 'u':
			return 26f;
		case 'k':
		case 'p':
		case 'r':
		case 's':
			return 29f;
		case 'm':
			return 35f;
		case 'd':
			return 36f;
		case 'A':
			return 36f;
		default:
			return 32f;
		}
	}

	public static void DrawCText(SpriteBatch sprite, Vector2 location, StringBuilder text, Color color, float scale, int justification)
	{
		DrawCText(sprite, location, text, color, scale, justification, blur: false, -1f);
	}

	public static void DrawCText(SpriteBatch sprite, Vector2 location, StringBuilder text, Color color, float scale, int justification, bool blur)
	{
		DrawCText(sprite, location, text, color, scale, justification, blur, -1f);
	}

	public static bool IsAsian()
	{
		if (language != 3)
		{
			return language == 4;
		}
		return true;
	}

	public static void DrawCText(SpriteBatch sprite, Vector2 location, StringBuilder text, Color color, float scale, int justification, bool blur, float maxWidth)
	{
		if (text == null)
		{
			return;
		}
		float num = location.X;
		if (text.ToString().Contains('['))
		{
			text.Replace("[A]", flibitPort.GetButtonIcon(flibitPort.InputAction.JumpAccept, "[A]"));
			text.Replace("[B]", flibitPort.GetButtonIcon(flibitPort.InputAction.GrabCancel, "[B]"));
			text.Replace("[b]", flibitPort.GetButtonIcon(flibitPort.InputAction.GrabCancel, "[b]"));
			text.Replace("[X]", flibitPort.GetButtonIcon(flibitPort.InputAction.Attack, "[X]"));
			text.Replace("[x]", flibitPort.GetButtonIcon(flibitPort.InputAction.Attack, "[x]"));
			text.Replace("[Y]", flibitPort.GetButtonIcon(flibitPort.InputAction.StrongSaw, "[Y]"));
			text.Replace("[y]", flibitPort.GetButtonIcon(flibitPort.InputAction.StrongSaw, "[y]"));
			text.Replace("[r]", flibitPort.GetButtonIcon(flibitPort.InputAction.SwitchWeapons, "[r]"));
			text.Replace("[l]", flibitPort.GetButtonIcon(flibitPort.InputAction.SwitchLoadouts, "[l]"));
			text.Replace("[R]", flibitPort.GetButtonIcon(flibitPort.InputAction.Gun, "[R]"));
			text.Replace("[L]", flibitPort.GetButtonIcon(flibitPort.InputAction.Magic, "[L]"));
			text.Replace("[f]", flibitPort.GetButtonIcon(flibitPort.InputAction.Inventory, "[f]"));
			text.Replace("[g]", flibitPort.GetButtonIcon(flibitPort.InputAction.PauseConfirm, "[g]"));
			text.Replace("[s]", flibitPort.GetButtonIcon(flibitPort.InputAction.WarpRoll, "[s]"));
		}
		float num2 = 1f;
		if (maxWidth > -1f)
		{
			float num3 = GetStringSpace(text) * scale;
			if (num3 > maxWidth)
			{
				num2 = maxWidth / num3;
			}
		}
		if (justification == 1)
		{
			num -= GetStringSpace(text) * scale * 0.5f * num2;
		}
		if (justification == 2)
		{
			num -= GetStringSpace(text) * scale;
		}
		for (int i = 0; i < text.Length; i++)
		{
			char c = text[i];
			int cTextIndex = getCTextIndex(c);
			Rectangle value = default;
			if (c == '[')
			{
				c = text[i + 1];
				flibitPort.DrawButtonAttrib(c, new Vector2(num, location.Y), color, 0f, Vector2.Zero, scale * 0.55f, SpriteEffects.None, 1f);
				i += 2;
				num += 32f * scale * num2;
				continue;
			}
			float num4 = (float)(int)color.A / 256f;
			if (IsAsian() && text[i] >= '⻠')
			{
				switch (language)
				{
				case 3:
					if (Game1.jpTextTex != null)
					{
						sprite.DrawString(Game1.jpTextTex, text[i].ToString(), new Vector2(num, location.Y), color, 0f, default, 0.51f * scale, SpriteEffects.None, 1f);
					}
					num += 24f * scale * num2;
					break;
				case 4:
					if (Game1.chTextTex != null)
					{
						sprite.DrawString(Game1.chTextTex, text[i].ToString(), new Vector2(num, location.Y), color, 0f, default, 0.51f * scale, SpriteEffects.None, 1f);
					}
					num += 26f * scale * num2;
					break;
				}
				continue;
			}
			if (num4 < 1f && blur)
			{
				value.X = cTextIndex % 112 % 8 * 64 + cTextIndex / 112 * 512;
				value.Y = cTextIndex % 112 / 8 * 64;
				value.Width = 64;
				value.Height = 64;
				float num5 = 1f;
				num5 = ((!(num4 > 0.5f)) ? (num4 * 2f) : ((1f - num4) * 2f));
				float num6 = 1f;
				num6 = ((!(num4 > 0.5f)) ? 0f : ((num4 - 0.5f) * 2f));
				float rotation = (float)(cTextIndex % 50 - 20) * (1f - num4) * 0.01f;
				if (num5 <= 1f && num5 > 0f)
				{
					float num7 = (1f - num4) * 2f;
					sprite.Draw(Game1.comicTextBlur, new Vector2(num - num7 * scale * 15f, location.Y), value, new Color(color.R, color.G, color.B, (byte)(num5 * 255f)), rotation, new Vector2(3f, 1f), scale * 0.55f * new Vector2(num7 + 1f, 1f) * new Vector2(num2, 1f), SpriteEffects.None, 1f);
				}
				if (num6 > 0f)
				{
					if (num6 > 1f)
					{
						num6 = 1f;
					}
					sprite.Draw(Game1.comicText, new Vector2(num, location.Y), value, new Color(color.R, color.G, color.B, (byte)(num6 * 256f)), rotation, default, scale * 0.55f * new Vector2(num2, 1f), SpriteEffects.None, 1f);
				}
			}
			else
			{
				value.X = cTextIndex % 112 % 8 * 64 + cTextIndex / 112 * 512;
				value.Y = cTextIndex % 112 / 8 * 64;
				value.Width = 64;
				value.Height = 64;
				sprite.Draw(Game1.comicText, new Vector2(num, location.Y), value, color, 0f, default, scale * 0.55f * new Vector2(num2, 1f), SpriteEffects.None, 1f);
			}
			num += getCTextSpace(c) * scale * num2;
		}
	}

	public static string[] SplitString(string sIn)
	{
		int num = 60;
		if (sIn.Length < num)
		{
			return new string[1] { sIn };
		}
		string[] array = new string[sIn.Length / num + 1];
		int num2 = 0;
		while (sIn.Length > num)
		{
			array[num2] = sIn.Substring(0, num);
			sIn = sIn.Substring(num);
			num2++;
		}
		array[num2] = sIn;
		return array;
	}

	public static void DrawLCText(SpriteBatch sprite, Vector2 location, StringBuilder text, Color color, float scale, int justification)
	{
		DrawLCText(sprite, location, text, color, scale, justification, blur: false);
	}

	public static void DrawLCText(SpriteBatch sprite, Vector2 location, StringBuilder text, Color color, float scale, int justification, bool blur)
	{
		if (text == null)
		{
			return;
		}
		float num = location.X;
		if (justification == 1)
		{
			num -= GetStringSpace(text) * scale * 0.5f;
		}
		if (justification == 2)
		{
			num -= GetStringSpace(text) * scale;
		}
		for (int i = 0; i < text.Length; i++)
		{
			char c = text[i];
			int lCTextIndex = getLCTextIndex(c);
			Rectangle value = default;
			float num2 = (float)(int)color.A / 256f;
			if (num2 < 1f && blur)
			{
				value.X = lCTextIndex % 112 % 8 * 64 + lCTextIndex / 112 * 512;
				value.Y = lCTextIndex % 112 / 8 * 64;
				value.Width = 64;
				value.Height = 64;
				float num3 = 1f;
				num3 = ((!(num2 > 0.5f)) ? (num2 * 2f) : ((1f - num2) * 2f));
				float num4 = 1f;
				num4 = ((!(num2 > 0.5f)) ? 0f : ((num2 - 0.5f) * 2f));
				float rotation = (float)(lCTextIndex % 50 - 20) * (1f - num2) * 0.01f;
				if (num3 <= 1f && num3 > 0f)
				{
					float num5 = (1f - num2) * 2f;
					sprite.Draw(Game1.comicTextBlur, new Vector2(num - num5 * scale * 15f, location.Y), value, new Color(color.R, color.G, color.B, (byte)(num3 * 255f)), rotation, new Vector2(3f, 1f), scale * 0.55f * new Vector2(num5 + 1f, 1f), SpriteEffects.None, 1f);
				}
				if (num4 > 0f)
				{
					if (num4 > 1f)
					{
						num4 = 1f;
					}
					sprite.Draw(Game1.comicText, new Vector2(num, location.Y), value, new Color(color.R, color.G, color.B, (byte)(num4 * 256f)), rotation, default, scale * 0.55f, SpriteEffects.None, 1f);
				}
			}
			else
			{
				value.X = lCTextIndex % 112 % 8 * 64 + lCTextIndex / 112 * 512;
				value.Y = lCTextIndex % 112 / 8 * 64;
				value.Width = 64;
				value.Height = 64;
				sprite.Draw(Game1.comicText, new Vector2(num, location.Y), value, color, 0f, default, scale * 0.55f, SpriteEffects.None, 1f);
			}
			num += getLCTextSpace(c) * scale;
		}
	}

	public static void DrawCText(SpriteBatch sprite, Vector2 location, StringBuilder text, Color color, float scale, int justification, float angle)
	{
		Vector2 position = location;
		Vector2 vector = new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle));
		if (justification == 1)
		{
			position -= GetStringSpace(text) * scale * 0.5f * vector;
		}
		if (justification == 2)
		{
			position -= GetStringSpace(text) * scale * vector;
		}
		for (int i = 0; i < text.Length; i++)
		{
			char c = text[i];
			int cTextIndex = getCTextIndex(c);
			Rectangle value = default;
			if (c == '[')
			{
				try
				{
					c = text[i + 1];
				}
				catch (Exception)
				{
				}
				flibitPort.DrawButtonAttrib(c, position, color, angle, Vector2.Zero, scale * 0.55f, SpriteEffects.None, 1f);
				i += 2;
				position += 32f * scale * vector;
			}
			else if (IsAsian() && text[i] >= '⻠')
			{
				switch (language)
				{
				case 3:
					if (Game1.jpTextTex != null)
					{
						sprite.DrawString(Game1.jpTextTex, text[i].ToString(), position, color, angle, default, scale * 0.51f, SpriteEffects.None, 1f);
					}
					position += 24f * scale * vector;
					break;
				case 4:
					if (Game1.chTextTex != null)
					{
						sprite.DrawString(Game1.chTextTex, text[i].ToString(), position, color, angle, default, scale * 0.51f, SpriteEffects.None, 1f);
					}
					position += 26f * scale * vector;
					break;
				}
			}
			else
			{
				value.X = cTextIndex % 112 % 8 * 64 + cTextIndex / 112 * 512;
				value.Y = cTextIndex % 112 / 8 * 64;
				value.Width = 64;
				value.Height = 64;
				sprite.Draw(Game1.comicText, position, value, color, angle, default, scale * 0.55f, SpriteEffects.None, 1f);
				position += getCTextSpace(c) * scale * vector;
			}
		}
	}

	public static float GetJStringSpace(StringBuilder text, float scale)
	{
		float num = 0f;
		for (int i = 0; i < text.Length; i++)
		{
			num += getJTextSpace(text[i]) * scale;
		}
		return num;
	}

	public static void DrawJText(SpriteBatch sprite, Vector2 location, StringBuilder text, Color color, float scale, int justification)
	{
		float num = location.X;
		if (justification == 1)
		{
			for (int i = 0; i < text.Length; i++)
			{
				num -= getJTextSpace(text[i]) * scale * 0.5f;
			}
		}
		if (justification == 2)
		{
			for (int j = 0; j < text.Length; j++)
			{
				num -= getJTextSpace(text[j]) * scale;
			}
		}
		for (int k = 0; k < text.Length; k++)
		{
			char c = text[k];
			int jTextIndex = getJTextIndex(c);
			Rectangle value = default;
			value.X = jTextIndex % 8 * 64;
			value.Y = jTextIndex / 8 * 64;
			value.X = jTextIndex % 64 % 8 * 64 + jTextIndex / 64 * 512;
			value.Y = jTextIndex % 64 / 8 * 64;
			value.Width = 64;
			value.Height = 64;
			if (IsAsian() && text[k] >= '⻠')
			{
				switch (language)
				{
				case 3:
					if (Game1.jpTextTex != null)
					{
						sprite.DrawString(Game1.jpTextTex, text[k].ToString(), new Vector2(num, location.Y), color, 0f, default, 0.51f * scale, SpriteEffects.None, 1f);
					}
					num += 24f * scale;
					break;
				case 4:
					if (Game1.chTextTex != null)
					{
						sprite.DrawString(Game1.chTextTex, text[k].ToString(), new Vector2(num, location.Y), color, 0f, default, 0.51f * scale, SpriteEffects.None, 1f);
					}
					num += 26f * scale;
					break;
				}
			}
			else
			{
				sprite.Draw(Game1.spookyText, new Vector2(num, location.Y), value, color, 0f, default, scale * 0.55f, SpriteEffects.None, 1f);
				num += getJTextSpace(c) * scale;
			}
		}
	}

	public static void DrawScore(int x, int y, long c, Color color, SpriteBatch sprite, bool flip, float frame, float size)
	{
		DrawScore(x, y, c, color, sprite, flip, frame, dashZero: false, size);
	}

	public static void DrawScore(int x, int y, long c, Color color, SpriteBatch sprite, bool flip, float frame, bool dashZero, float Size)
	{
		DrawScore(x, y, c, color, sprite, flip, frame, dashZero, Size, blur: false);
	}

	public static void DrawScore(int x, int y, long c, Color color, SpriteBatch sprite, bool flip, float frame, bool dashZero, float Size, bool blur)
	{
		long num = c;
		float num2 = 0f;
		int num3 = 0;
		if (flip)
		{
			while (num > 0)
			{
				num3++;
				if (num3 % 3 == 0)
				{
					num2 += (float)(int)(getCTextSpace(',') * Size);
				}
				long num4 = num % 10;
				char c2 = (char)(48 + num4);
				num /= 10;
				num2 += (float)(int)(getCTextSpace(c2) * Size);
			}
			x += (int)num2;
			num = c;
		}
		Rectangle value = default;
		Rectangle destinationRectangle = default;
		num3 = 0;
		if (num == 0 && dashZero)
		{
			int cTextIndex = getCTextIndex('-');
			value.X = cTextIndex % 8 * 64;
			value.Y = cTextIndex / 8 * 64;
			value.Width = 64;
			value.Height = 64;
			for (int i = 0; i < 2; i++)
			{
				x -= (int)(getCTextSpace('-') * Size);
				destinationRectangle.X = x;
				destinationRectangle.Y = y;
				destinationRectangle.Width = (int)(32f * Size);
				destinationRectangle.Height = (int)(36f * Size);
				sprite.Draw(Game1.comicText, destinationRectangle, value, color);
			}
			return;
		}
		if (num == 0)
		{
			int cTextIndex2 = getCTextIndex('0');
			value.X = cTextIndex2 % 8 * 64;
			value.Y = cTextIndex2 / 8 * 64;
			value.Width = 64;
			value.Height = 64;
			if (!flip)
			{
				x -= (int)(getCTextSpace('0') * Size);
			}
			destinationRectangle.X = x;
			destinationRectangle.Y = y;
			destinationRectangle.Width = (int)(32f * Size);
			destinationRectangle.Height = (int)(36f * Size);
			sprite.Draw(Game1.comicText, destinationRectangle, value, color);
			return;
		}
		while (num > 0)
		{
			num3++;
			int cTextIndex3;
			if (num3 % 4 == 0)
			{
				switch (language)
				{
				case 2:
					cTextIndex3 = getCTextIndex(' ');
					x -= (int)(getCTextSpace(' ') * Size);
					break;
				case 1:
					cTextIndex3 = getCTextIndex('.');
					x -= (int)(getCTextSpace('.') * Size);
					break;
				default:
					cTextIndex3 = getCTextIndex(',');
					x -= (int)(getCTextSpace(',') * Size);
					break;
				}
			}
			else
			{
				long num5 = num % 10;
				num /= 10;
				char c3 = (char)(48 + num5);
				x -= (int)(getCTextSpace(c3) * Size);
				cTextIndex3 = getCTextIndex(c3);
			}
			value.X = cTextIndex3 % 8 * 64;
			value.Y = cTextIndex3 / 8 * 64;
			value.Width = 64;
			value.Height = 64;
			float num6 = (float)(int)color.A / 256f;
			if (num6 < 1f && blur)
			{
				float num7 = 1f;
				num7 = ((!(num6 > 0.5f)) ? (num6 * 2f) : ((1f - num6) * 2f));
				float num8 = 1f;
				num8 = ((!(num6 > 0.5f)) ? 0f : ((num6 - 0.5f) * 2f));
				float rotation = (float)(cTextIndex3 % 50 - 20) * (1f - num6) * 0.01f;
				if (num7 <= 1f && num7 > 0f)
				{
					float num9 = (1f - num6) * 2f;
					sprite.Draw(Game1.comicTextBlur, new Vector2((float)x - num9 * Size * 15f, y), value, new Color(color.R, color.G, color.B, (byte)(num7 * 255f)), rotation, new Vector2(3f, 1f), Size * 0.55f * new Vector2(num9 + 1f, 1f), SpriteEffects.None, 1f);
				}
				if (num8 > 0f)
				{
					if (num8 > 1f)
					{
						num8 = 1f;
					}
					sprite.Draw(Game1.comicText, new Vector2(x, y), value, new Color(color.R, color.G, color.B, (byte)(num8 * 256f)), rotation, default, Size * 0.55f, SpriteEffects.None, 1f);
				}
			}
			else
			{
				destinationRectangle.X = x;
				destinationRectangle.Y = y;
				destinationRectangle.Width = (int)(32f * Size);
				destinationRectangle.Height = (int)(36f * Size);
				sprite.Draw(Game1.comicText, destinationRectangle, value, color);
			}
			if (frame > 0f)
			{
				for (int j = 0; j < 4; j++)
				{
					destinationRectangle.X -= (int)(frame * 5f);
					destinationRectangle.Y -= (int)(frame * 10f);
					destinationRectangle.Width += (int)(frame * 10f);
					destinationRectangle.Height += (int)(frame * 20f);
					sprite.Draw(Game1.comicText, destinationRectangle, value, new Color(new Vector4(1f, 1f, 1f, frame * 0.15f)));
				}
			}
		}
	}

	private static int getCTextIndex(char c)
	{
		switch (c)
		{
		case 'A':
		case 'a':
			return 0;
		case 'B':
		case 'b':
			return 1;
		case 'C':
		case 'c':
			return 2;
		case 'D':
		case 'd':
			return 3;
		case 'E':
		case 'e':
			return 4;
		case 'F':
		case 'f':
			return 5;
		case 'G':
		case 'g':
			return 6;
		case 'H':
		case 'h':
			return 7;
		case 'I':
		case 'i':
			return 8;
		case 'J':
		case 'j':
			return 9;
		case 'K':
		case 'k':
			return 10;
		case 'L':
		case 'l':
			return 11;
		case 'M':
		case 'm':
			return 12;
		case 'N':
		case 'n':
			return 13;
		case 'O':
		case 'o':
			return 14;
		case 'P':
		case 'p':
			return 15;
		case 'Q':
		case 'q':
			return 16;
		case 'R':
		case 'r':
			return 17;
		case 'S':
		case 's':
			return 18;
		case 'T':
		case 't':
			return 19;
		case 'U':
		case 'u':
			return 20;
		case 'V':
		case 'v':
			return 21;
		case 'W':
		case 'w':
			return 22;
		case 'X':
		case 'x':
			return 23;
		case 'Y':
		case 'y':
			return 24;
		case 'Z':
		case 'z':
			return 25;
		case '0':
			return 26;
		case '1':
			return 27;
		case '2':
			return 28;
		case '3':
			return 29;
		case '4':
			return 30;
		case '5':
			return 31;
		case '6':
			return 32;
		case '7':
			return 33;
		case '8':
			return 34;
		case '9':
			return 35;
		case '!':
			return 36;
		case '@':
			return 37;
		case '#':
			return 38;
		case '$':
			return 39;
		case '%':
			return 40;
		case '/':
		case '\\':
			return 41;
		case '&':
			return 63;
		case '*':
			return 43;
		case '(':
			return 44;
		case ')':
			return 45;
		case '-':
			return 46;
		case '+':
			return 47;
		case '=':
			return 48;
		case ',':
			return 49;
		case '.':
			return 50;
		case ';':
			return 51;
		case ':':
			return 52;
		case '"':
			return 53;
		case '\'':
			return 54;
		case '?':
			return 55;
		case '_':
			return 56;
		case '~':
			return 57;
		case '}':
			return 58;
		case '[':
			return 59;
		case ']':
			return 60;
		case '|':
			return 61;
		case '{':
			return 62;
		case 'Æ':
		case 'æ':
			return 90;
		case 'Œ':
		case 'œ':
			return 91;
		case '¡':
			return 92;
		case '«':
			return 94;
		case '»':
			return 95;
		case 'Ё':
		case 'ё':
			return 112;
		case 'Ђ':
		case 'ђ':
			return 113;
		case 'Ѓ':
		case 'ѓ':
			return 114;
		case 'Є':
		case 'є':
			return 115;
		case 'Ѕ':
		case 'ѕ':
			return 116;
		case 'І':
		case 'і':
			return 117;
		case 'Ї':
		case 'ї':
			return 118;
		case 'Ј':
		case 'ј':
			return 119;
		case 'Љ':
		case 'љ':
			return 120;
		case 'Њ':
		case 'њ':
			return 121;
		case 'Ћ':
		case 'ћ':
			return 122;
		case 'Ќ':
		case 'ќ':
			return 123;
		case 'Ў':
		case 'ў':
			return 124;
		case 'Џ':
		case 'џ':
			return 125;
		case 'А':
		case 'а':
			return 126;
		case 'Б':
		case 'б':
			return 127;
		case 'В':
		case 'в':
			return 128;
		case 'Г':
		case 'г':
			return 129;
		case 'Д':
		case 'д':
			return 130;
		case 'Е':
		case 'е':
			return 131;
		case 'Ж':
		case 'ж':
			return 132;
		case 'З':
		case 'з':
			return 133;
		case 'И':
		case 'и':
			return 134;
		case 'Й':
		case 'й':
			return 135;
		case 'К':
		case 'к':
			return 136;
		case 'Л':
		case 'л':
			return 137;
		case 'М':
		case 'м':
			return 138;
		case 'Н':
		case 'н':
			return 139;
		case 'О':
		case 'о':
			return 140;
		case 'П':
		case 'п':
			return 141;
		case 'Р':
		case 'р':
			return 142;
		case 'С':
		case 'с':
			return 143;
		case 'Т':
		case 'т':
			return 144;
		case 'У':
		case 'у':
			return 145;
		case 'Ф':
		case 'ф':
			return 146;
		case 'Х':
		case 'х':
			return 147;
		case 'Ц':
		case 'ц':
			return 148;
		case 'Ч':
		case 'ч':
			return 149;
		case 'Ш':
		case 'ш':
			return 150;
		case 'Щ':
		case 'щ':
			return 151;
		case 'Ъ':
		case 'ъ':
			return 152;
		case 'Ы':
		case 'ы':
			return 153;
		case 'Ь':
		case 'ь':
			return 154;
		case 'Э':
		case 'э':
			return 155;
		case 'Ю':
		case 'ю':
			return 156;
		case 'Я':
		case 'я':
			return 157;
		case 'º':
			return 158;
		case '…':
			return 159;
		case 'À':
		case 'à':
			return 160;
		case 'Á':
		case 'á':
			return 161;
		case 'Ã':
		case 'ã':
			return 162;
		case 'Ä':
		case 'ä':
			return 163;
		case 'È':
		case 'è':
			return 164;
		case 'É':
		case 'é':
			return 165;
		case 'Ë':
		case 'ë':
			return 167;
		case 'ì':
			return 168;
		case 'í':
			return 169;
		case 'ï':
			return 171;
		case 'ò':
			return 172;
		case 'ó':
			return 173;
		case 'õ':
			return 174;
		case 'ö':
			return 175;
		case 'ù':
			return 176;
		case 'ú':
			return 177;
		case 'ü':
			return 179;
		case 'ý':
			return 180;
		case 'ÿ':
			return 181;
		case 'ç':
			return 182;
		case 'ñ':
			return 183;
		case 'â':
			return 184;
		case 'ê':
			return 185;
		case 'î':
			return 186;
		case 'ô':
			return 187;
		case 'û':
			return 188;
		case '¿':
			return 189;
		case 'ß':
			return 190;
		case 'Ą':
		case 'ą':
			return 192;
		case 'Ę':
		case 'ę':
			return 193;
		case 'Ó':
			return 194;
		case 'Ć':
		case 'ć':
			return 195;
		case 'Ł':
		case 'ł':
			return 196;
		case 'Ń':
		case 'ń':
			return 197;
		case 'Ś':
		case 'ś':
			return 198;
		case 'Ź':
		case 'ź':
			return 199;
		case 'Ż':
		case 'ż':
			return 191;
		default:
			return -1;
		}
	}

	private static int getLCTextIndex(char c)
	{
		switch (c)
		{
		case 'A':
			return 0;
		case 'B':
			return 1;
		case 'C':
			return 2;
		case 'D':
			return 3;
		case 'E':
			return 4;
		case 'F':
			return 5;
		case 'G':
			return 6;
		case 'H':
			return 7;
		case 'I':
			return 8;
		case 'J':
			return 9;
		case 'K':
			return 10;
		case 'L':
			return 11;
		case 'M':
			return 12;
		case 'N':
			return 13;
		case 'O':
			return 14;
		case 'P':
			return 15;
		case 'Q':
			return 16;
		case 'R':
			return 17;
		case 'S':
			return 18;
		case 'T':
			return 19;
		case 'U':
			return 20;
		case 'V':
			return 21;
		case 'W':
			return 22;
		case 'X':
			return 23;
		case 'Y':
			return 24;
		case 'Z':
			return 25;
		case '«':
			return 94;
		case '»':
			return 95;
		case '0':
			return 26;
		case '1':
			return 27;
		case '2':
			return 28;
		case '3':
			return 29;
		case '4':
			return 30;
		case '5':
			return 31;
		case '6':
			return 32;
		case '7':
			return 33;
		case '8':
			return 34;
		case '9':
			return 35;
		case '!':
			return 36;
		case '@':
			return 37;
		case '#':
			return 38;
		case '$':
			return 39;
		case '%':
			return 40;
		case '/':
		case '\\':
			return 41;
		case '&':
			return 63;
		case '*':
			return 43;
		case '(':
			return 44;
		case ')':
			return 45;
		case '-':
			return 46;
		case '+':
			return 47;
		case '=':
			return 48;
		case ',':
			return 49;
		case '.':
			return 50;
		case ';':
			return 51;
		case ':':
			return 52;
		case '"':
			return 53;
		case '\'':
			return 54;
		case '?':
			return 55;
		case '_':
			return 56;
		case '~':
			return 57;
		case '}':
			return 58;
		case '[':
			return 59;
		case ']':
			return 60;
		case '|':
			return 61;
		case '{':
			return 62;
		case 'ç':
			return 94;
		case 'ã':
			return 95;
		case 'a':
			return 64;
		case 'b':
			return 65;
		case 'c':
			return 66;
		case 'd':
			return 67;
		case 'e':
			return 68;
		case 'f':
			return 69;
		case 'g':
			return 70;
		case 'h':
			return 71;
		case 'i':
			return 72;
		case 'j':
			return 73;
		case 'k':
			return 74;
		case 'l':
			return 75;
		case 'm':
			return 76;
		case 'n':
			return 77;
		case 'o':
			return 78;
		case 'p':
			return 79;
		case 'q':
			return 80;
		case 'r':
			return 81;
		case 's':
			return 82;
		case 't':
			return 83;
		case 'u':
			return 84;
		case 'v':
			return 85;
		case 'w':
			return 86;
		case 'x':
			return 87;
		case 'y':
			return 88;
		case 'z':
			return 89;
		default:
			return -1;
		}
	}

	private static float getCTextSpace(char c)
	{
		switch (c)
		{
		case ' ':
			return 8f;
		case '\'':
			return 3f;
		case 'i':
			return 7f;
		case ',':
		case '.':
		case ':':
			return 8f;
		case '!':
		case '1':
		case 'I':
		case '¡':
		case 'ì':
		case 'í':
		case 'î':
		case 'ï':
		case 'І':
		case 'Ї':
		case 'і':
		case 'ї':
			return 10f;
		case 'w':
			return 24f;
		case 'm':
			return 20f;
		case 'O':
		case 'o':
		case 'Æ':
		case 'æ':
		case 'ò':
		case 'ó':
		case 'ô':
		case 'õ':
		case 'ö':
		case 'Œ':
		case 'œ':
		case 'Ђ':
		case 'Њ':
		case 'Ћ':
		case 'Д':
		case 'Ж':
		case 'Л':
		case 'О':
		case 'Ш':
		case 'Щ':
		case 'Ю':
		case 'д':
		case 'ж':
		case 'л':
		case 'о':
		case 'ш':
		case 'щ':
		case 'ю':
		case 'ђ':
		case 'њ':
		case 'ћ':
			return 22f;
		case 'Љ':
		case 'љ':
			return 25f;
		case 'q':
			return 20f;
		case 'y':
			return 12f;
		case 'u':
		case 'v':
			return 15f;
		case 'h':
			return 18f;
		case '_':
			return 28f;
		case '~':
			return 28f;
		case '}':
			return 25f;
		case '(':
			return 9f;
		case 'g':
			return 20f;
		default:
			return 17f;
		}
	}

	private static float getLCTextSpace(char c)
	{
		switch (c)
		{
		case ' ':
			return 8f;
		case '\'':
			return 3f;
		case 'I':
			return 7f;
		case ',':
		case '.':
		case ':':
			return 8f;
		case '!':
		case '1':
			return 10f;
		case 'W':
			return 24f;
		case 'M':
			return 20f;
		case 'O':
			return 22f;
		case 'Q':
			return 20f;
		case 'Y':
			return 12f;
		case 'U':
		case 'V':
			return 15f;
		case 'H':
			return 18f;
		case '_':
			return 28f;
		case '~':
			return 28f;
		case '}':
			return 25f;
		case '[':
		case ']':
		case '{':
		case '|':
			return 36f;
		case '<':
		case '>':
			return 32f;
		case 'i':
		case 'l':
			return 10f;
		case 'r':
		case 's':
			return 14f;
		case 'm':
			return 20f;
		case 'ã':
		case 'ç':
			return 16f;
		default:
			return 17f;
		}
	}

	private static int getJTextIndex(char c)
	{
		switch (c)
		{
		case 'A':
		case 'a':
			return 0;
		case 'B':
		case 'b':
			return 1;
		case 'C':
		case 'c':
			return 2;
		case 'D':
		case 'd':
			return 3;
		case 'e':
			return 4;
		case 'E':
			return 47;
		case 'F':
		case 'f':
			return 5;
		case 'G':
		case 'g':
			return 6;
		case 'H':
		case 'h':
			return 7;
		case 'i':
			return 8;
		case 'I':
			return 27;
		case 'J':
		case 'j':
			return 9;
		case 'K':
		case 'k':
			return 10;
		case 'L':
		case 'l':
			return 11;
		case 'M':
		case 'm':
			return 12;
		case 'N':
		case 'n':
			return 13;
		case 'O':
		case 'o':
			return 14;
		case 'P':
		case 'p':
			return 15;
		case 'Q':
		case 'q':
			return 16;
		case 'R':
		case 'r':
			return 17;
		case 'S':
		case 's':
			return 18;
		case 'T':
		case 't':
			return 19;
		case 'U':
		case 'u':
			return 20;
		case 'V':
		case 'v':
			return 21;
		case 'W':
		case 'w':
			return 22;
		case 'X':
		case 'x':
			return 23;
		case 'Y':
		case 'y':
			return 24;
		case 'Z':
		case 'z':
			return 25;
		case '0':
			return 26;
		case '1':
			return 27;
		case '2':
			return 28;
		case '3':
			return 29;
		case '4':
			return 30;
		case '5':
			return 31;
		case '6':
			return 32;
		case '7':
			return 33;
		case '8':
			return 34;
		case '9':
			return 35;
		case '.':
			return 36;
		case ',':
			return 37;
		case '!':
			return 38;
		case ':':
			return 39;
		case '-':
			return 40;
		case '+':
			return 41;
		case '\'':
			return 42;
		case '%':
			return 43;
		case '}':
			return 44;
		case '(':
			return 45;
		case ')':
			return 46;
		case '?':
			return 48;
		case '&':
			return 49;
		case 'Æ':
		case 'æ':
			return 92;
		case 'Œ':
		case 'œ':
			return 91;
		case '¡':
			return 90;
		case 'à':
			return 50;
		case 'á':
			return 51;
		case 'ã':
			return 52;
		case 'ä':
			return 54;
		case 'â':
			return 53;
		case 'è':
			return 55;
		case 'é':
			return 56;
		case 'ë':
			return 59;
		case 'ê':
			return 58;
		case 'ì':
			return 60;
		case 'í':
			return 61;
		case 'î':
			return 63;
		case 'ï':
			return 64;
		case 'ò':
			return 65;
		case 'ó':
			return 66;
		case 'õ':
			return 67;
		case 'ô':
			return 68;
		case 'ö':
			return 69;
		case 'ù':
			return 70;
		case 'ú':
			return 71;
		case 'û':
			return 73;
		case 'ü':
			return 74;
		case 'ý':
			return 75;
		case 'ÿ':
			return 76;
		case 'ç':
			return 77;
		case 'ñ':
			return 78;
		case '¿':
			return 79;
		case 'ß':
			return 80;
		case 'Ą':
		case 'ą':
			return 81;
		case 'Ę':
		case 'ę':
			return 82;
		case 'Ó':
			return 83;
		case 'Ć':
		case 'ć':
			return 84;
		case 'Ł':
		case 'ł':
			return 85;
		case 'Ń':
		case 'ń':
			return 86;
		case 'Ś':
		case 'ś':
			return 87;
		case 'Ź':
		case 'ź':
			return 88;
		case 'Ż':
		case 'ż':
			return 89;
		default:
			return -1;
		}
	}

	private static float getJTextSpace(char c)
	{
		switch (c)
		{
		case '\'':
		case ',':
		case '.':
		case ':':
			return 8f;
		case '!':
		case '(':
		case ')':
		case '1':
		case 'i':
			return 10f;
		case '%':
		case 'o':
			return 14f;
		case 'm':
			return 22f;
		case 'u':
			return 20f;
		case 'r':
			return 14f;
		case '}':
			return 32f;
		case '^':
			return 32f;
		default:
			return 17f;
		}
	}
}
