using Microsoft.Xna.Framework;
using Yuki_Win.director;

namespace Yuki_Win;

internal class FMan
{
	public const float MAX_FRAME_TIME = 1f / 30f;

	public static float frameTime;

	public static float realTime;

	public static float slowFrame;

	public static float freakoutFreeTime;

	public static void Slow(float val)
	{
		if (val > slowFrame)
		{
			slowFrame = val;
		}
	}

	public static float AdjustedFrame(int owner)
	{
		if (owner > -1 && owner < Game1.character.Length && Game1.character[owner].charUpdate.slow > 0f)
		{
			return frameTime / 10f;
		}
		return frameTime;
	}

	internal static void Update(GameTime gameTime)
	{
		float num = (realTime = (float)gameTime.ElapsedGameTime.Milliseconds / 1000f);
		if (num < 1f / 60f)
		{
			num = 1f / 60f;
		}
		switch (GameState.state)
		{
		case GameState.State.Menu:
			if (num > 1f / 60f)
			{
				num = 1f / 60f;
			}
			break;
		case GameState.State.Playing:
			if (num > 1f / 30f)
			{
				num = 1f / 30f;
			}
			break;
		}
		bool flag = false;
		for (int i = 0; i < 2; i++)
		{
			if (Game1.character[i].exists && Game1.character[i].charUpdate.magic > 0.9f && Game1.character[i].charUpdate.magic < 1f)
			{
				flag = true;
			}
		}
		if (GameState.state == GameState.State.Playing)
		{
			if (flag)
			{
				num /= 16f;
			}
			else if (Game1.gameMap.trapWarpFrame > 0f)
			{
				num /= 20f;
			}
			else if (QuakeManager.quirkFrame > 0f)
			{
				num /= 16f;
			}
			else if (MainPlayer.uberDyingFrame >= 1f)
			{
				MainPlayer.uberDyingFrame += num;
				num /= 10f;
			}
			else if (slowFrame > 0f)
			{
				num /= 10f;
				slowFrame -= num;
			}
		}
		if (Game1.gameMap.lichFreakoutMode)
		{
			freakoutFreeTime = num;
			Game1.gameMap.lichFreakoutSpeedyFrame -= num;
			if (Game1.gameMap.lichFreakoutSpeedyFrame < 0f)
			{
				Game1.gameMap.lichFreakoutSpeedyMode = 1 - Game1.gameMap.lichFreakoutSpeedyMode;
				if (Game1.gameMap.lichFreakoutSpeedyMode == 0)
				{
					Game1.gameMap.lichFreakoutSpeedyFrame = Rand.GetRandomFloat(0.1f, 2f);
				}
				else
				{
					Game1.gameMap.lichFreakoutSpeedyFrame = Rand.GetRandomFloat(0.05f, 0.5f);
				}
			}
			if (Game1.gameMap.lichFreakoutSpeedyMode == 0)
			{
				num *= Rand.GetRandomFloat(0.4f, 0.7f);
			}
			else
			{
				num *= Rand.GetRandomFloat(2f, 3f);
				QuakeManager.SetBright(Rand.GetRandomFloat(0.1f, 0.3f));
			}
		}
		frameTime = num;
	}
}
