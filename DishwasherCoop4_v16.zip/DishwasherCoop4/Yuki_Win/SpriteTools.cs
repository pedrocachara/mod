using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win;

public class SpriteTools
{
	public static SpriteBatch sprite;

	private static BlendState blendSubtract;

	public static void Init(GraphicsDevice dev)
	{
		sprite = new SpriteBatch(dev);
		blendSubtract = new BlendState();
		blendSubtract.ColorSourceBlend = Blend.SourceAlpha;
		blendSubtract.ColorDestinationBlend = Blend.One;
		blendSubtract.ColorBlendFunction = BlendFunction.ReverseSubtract;
		blendSubtract.AlphaSourceBlend = Blend.SourceAlpha;
		blendSubtract.AlphaDestinationBlend = Blend.One;
		blendSubtract.AlphaBlendFunction = BlendFunction.ReverseSubtract;
	}

	public static void BeginOpaque()
	{
		sprite.Begin(SpriteSortMode.Deferred, BlendState.Opaque);
	}

	public static void BeginOpaqueSmooth()
	{
		sprite.Begin(SpriteSortMode.Deferred, BlendState.Opaque, SamplerState.AnisotropicClamp, null, null);
	}

	public static void BeginAlpha()
	{
		sprite.Begin(SpriteSortMode.Deferred, BlendState.NonPremultiplied);
	}

	public static void BeginPMAlpha()
	{
		sprite.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend);
	}

	public static void BeginAdditive()
	{
		sprite.Begin(SpriteSortMode.Deferred, BlendState.Additive);
	}

	public static void BeginSubtractive()
	{
		sprite.Begin(SpriteSortMode.Deferred, blendSubtract);
	}

	public static void BeginAlpha(Effect effect)
	{
		sprite.Begin(SpriteSortMode.Deferred, BlendState.NonPremultiplied, null, null, null, effect);
	}

	public static void BeginAdditive(Effect effect)
	{
		sprite.Begin(SpriteSortMode.Deferred, BlendState.Additive, null, null, null, effect);
	}

	public static void BeginOpaque(Effect effect)
	{
		sprite.Begin(SpriteSortMode.Deferred, BlendState.Opaque, null, null, null, effect);
	}

	public static void End()
	{
		sprite.End();
	}
}
