using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;

namespace Yuki_Win;

internal static class Program
{
	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool SetDllDirectory(string lpPathName);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool SetProcessDPIAware();

	[STAThread]
	private static void Main(string[] args)
	{
		if (Environment.OSVersion.Platform == PlatformID.Win32NT)
		{
			SetProcessDPIAware();
			SetDllDirectory(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Environment.Is64BitProcess ? "x64" : "x86"));
		}
		for (int i = 0; i < args.Length; i++)
		{
			if (args[i] == "-lang")
			{
				i++;
				if (i < args.Length)
				{
					YukiText.Culture = new CultureInfo(args[i]);
				}
			}
			else if (args[i] == "-dsound" && Environment.OSVersion.Platform == PlatformID.Win32NT)
			{
				Environment.SetEnvironmentVariable("SDL_AUDIODRIVER", "directsound");
			}
		}
		try
		{
			using Game1 game = new Game1();
			game.Run();
		}
		catch (Exception e)
		{
			flibitPort.Crash(e);
		}
	}
}
