using System;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using SceneEdit.scene;
using xCharEdit;
using yMapEdit.segdef;
using Yuki_Win.achievements;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.credits;
using Yuki_Win.debug;
using Yuki_Win.director;
using Yuki_Win.eightbit;
using Yuki_Win.gameRender;
using Yuki_Win.guidestuff;
using Yuki_Win.hud;
using Yuki_Win.hud.practice;
using Yuki_Win.leaderboards;
using Yuki_Win.levels;
using Yuki_Win.loader;
using Yuki_Win.localization;
using Yuki_Win.maps;
using Yuki_Win.menu;
using Yuki_Win.menu.levels.moveslist;
using Yuki_Win.netplay;
using Yuki_Win.pet;
using Yuki_Win.physics;
using Yuki_Win.player;
using Yuki_Win.player.beads;
using Yuki_Win.solo;
using Yuki_Win.sprites;
using Yuki_Win.storage;
using Yuki_Win.world;
using Yuki_Win.worldmap;
using Yuki_XBLA.presence;

namespace Yuki_Win;

public class Game1 : Game
{
	public static GraphicsDeviceManager graphics;

	public static CharDef[] charDef;

	public static Character[] character;

	public static CharMeta[] charMeta;

	public static SpriteManager spriteMan;

	public static GameMap gameMap;

	public static Arcade arcade;

	public static Texture2D[] mapsTex;

	public static Texture2D colTex;

	public static Texture2D spritesTex;

	public static Texture2D nullTex;

	public static Texture2D hGradTex;

	public static Texture2D vGradTex;

	public static Texture2D[] bgTex;

	public static Texture2D waterTex;

	public static Texture2D magicTex;

	public static Texture2D controllerTex;

	public static Practice practice;

	public static CharBloodStains charBloodStains;

	public static LeaderBoard leaderBoard;

	public static RumbleManager rumbleManager;

	public static Texture2D comicText;

	public static Texture2D comicTextBlur;

	public static SpriteFont jpTextTex;

	public static SpriteFont chTextTex;

	public static bool active;

	public static Texture2D spookyText;

	public static Texture2D hatchText;

	public static Texture2D environText;

	public static NeighborManager neighborMgr;

	public static SignedInGamerMgr signedInGamerMgr;

	public static PetPlayerMgr petPlayerMgr;

	public static CharTexture[] headTexMeta;

	public static CharTexture[] legsTexMeta;

	public static CharTexture[] torsoTexMeta;

	public static CharTexture[] weaponTexMeta;

	public static CharTexture[] auxTexMeta;

	public static Texture2D[] headTex;

	public static Texture2D[] legsTex;

	public static Texture2D[] torsoTex;

	public static Texture2D[] weaponTex;

	public static Texture2D itemsTex;

	public static Texture2D buyTex;

	public static Credits credits;

	public static Texture2D bubbleTex;

	public static Texture2D blockText;

	public static Texture2D eightBitTex;

	public static LevelManager levelMgr;

	public static TransitionManager transMgr;

	public static SpawnManager spawnMgr;

	public static RenderTarget2D bgRefractTarg;

	public static RenderTarget2D waterTarg;

	public static Texture2D waterTargTex;

	public static bool waterReady;

	public static RenderTarget2D fogTarg;

	public static Texture2D fogTex;

	public static bool fogReady;

	public static RenderTarget2D mainTarg;

	public static RenderTarget2D mapTarg;

	public static RenderTarget2D auxTarg;

	public static RenderTarget2D threshTarg;

	public static RenderTarget2D mapBackTarg;

	public static RenderTarget2D menuTarg;

	public static RenderTarget2D refractTarg;

	public static RenderTarget2D postGlowTarg;

	public static Texture2D postGlowTex;

	public static bool postGlowReady;

	public static RenderTarget2D[] feedbackTarg;

	public static RenderTarget2D[] threeDeeTarg;

	public static Texture2D releaseTex;

	public static Texture2D xblaTex;

	public static Texture2D skaTex;

	public static Texture2D loadingTex;

	public static Texture2D worldMapTex;

	public static Texture2D worldSpritesTex;

	public static KillManager killManager;

	public static SegDefManager segDefMgr;

	public static Texture2D portraitsTex;

	public static SpriteFont font;

	public static MainPlayer player;

	public static StorageMgr storageMgr;

	public static AchievementMgr achievementMgr;

	public static EightBitGame eightBitGame;

	public static MenuManager menuMgr;

	public static GamePlayerManager gamePlayerMgr;

	public static BeadMgr beadMgr;

	public static PresenceMgr presenceMgr;

	public static HUD hud;

	public static MovesListCatalog movesListCatalog;

	public static SceneMgr sceneMgr;

	public static int curWorld;

	private float loadTime;

	private GamePadState pgs;

	public static bool playMode = true;

	public static bool mustExit = false;

	public static CamManager camMgr;

	public static Texture2D[] upgradeTex;

	private Rope rope;

	public static int[] mainPlayer = new int[4] { 0, 1, -1, -1 };

	public static int coopPlayers = 2;

	// Coop/arcade 4P: personagem de cada slot (0=Yuki, 1=Dishwasher, 2=Mara, 3=Hargreaves)
	public static int[] slotChar = new int[4] { 0, 1, 3, 2 };

	public static readonly string[] slotCharName = new string[4] { "YUKI", "DISHWASHER", "MARA", "HARGREAVES" };

	// PvP: jogadores se machucam entre si
	// Parry (R1): janela em segundos, recarga em segundos e multiplicador do dano devolvido
	public static bool parryEnabled = false;

	public static float parryWindow = 0.3f;

	public static float parryCooldown = 0.9f;

	public static float parryMultiplier = 2f;

	// Esquiva (rolamento): toque duplo no botao de trocar loadout (L1). Trocar loadout: segurar para baixo + L1.
	public static bool dodgeEnabled = false;

	public static float dodgeDoubleTap = 0.25f;

	public static float dodgeCooldown = 0.6f;

	public static float dodgeIFrames = 0.35f;

	public static float dodgeBorrowTime = 0.7f;

	// Personagens que nao sao Dishwasher emprestam o modelo/animacoes do Dishwasher (charDef 3, charMeta 5 = ShiftBlade/katana)
	// durante o parry e o rolamento
	public static int borrowDishDef = 3;

	public static int borrowDishMeta = 5;

	public static bool pvpMode = false;

	// PvP arena: partida em rodadas (melhor de 3)
	public static bool pvpMatch = false;

	public static int pvpState = 0; // 0 lutando, 1 fim de rodada, 2 fim de partida, 3 saindo

	public static int pvpRound = 1;

	public static int pvpRoundsToWin = 2;

	public static int[] pvpWins = new int[4];

	public static int pvpWinner = -1;

	public static float pvpFrame = 0f;

	public static void PvpStart()
	{
		pvpMatch = true;
		pvpMode = true;
		pvpState = 0;
		pvpRound = 1;
		pvpWinner = -1;
		pvpFrame = 0f;
		for (int pi = 0; pi < 4; pi++)
		{
			pvpWins[pi] = 0;
		}
	}

	public static void PvpStop()
	{
		pvpMatch = false;
		pvpMode = false;
	}

	// Indice do retrato em portraitsTex
	public static int PortraitIndex(int pick)
	{
		switch (pick)
		{
		case 0: return 1;
		case 1: return 0;
		case 2: return 3;
		default: return 4;
		}
	}

	// Tipo usado por Arcade.player (0=Yuki, 1=Dish, 3=Hargreaves, 4=Mara)
	public static int ArcadeTypeFromPick(int pick)
	{
		switch (pick)
		{
		case 0: return 0;
		case 1: return 1;
		case 2: return 4;
		default: return 3;
		}
	}

	public static bool IsPlayerChar(int id)
	{
		return id >= 0 && (id < 2 || (id < 4 && id < GetPlayers()));
	}

	public static int LocalPlayerCount()
	{
		int n = 0;
		for (int i = 0; i < mainPlayer.Length; i++)
		{
			if (mainPlayer[i] > -1)
			{
				n++;
			}
		}
		return (n < 2) ? 2 : n;
	}

	public static bool CoopSplitState()
	{
		int n = GetPlayers();
		int d = 0;
		int a = 0;
		for (int i = 0; i < n && i < 4; i++)
		{
			if (character[i].charUpdate.dyingFrame > 0f)
			{
				d++;
			}
			else
			{
				a++;
			}
		}
		return d > 0 && a > 0;
	}

	public static bool AnyCoopJump()
	{
		int n = GetPlayers();
		for (int i = 0; i < n && i < 4; i++)
		{
			if (character[i].charKeys != null && character[i].charKeys.keyJump)
			{
				return true;
			}
		}
		return false;
	}

	public static InvCatalog invCatalog;

	public static WorldMapMgr worldMapMgr;

	public static Loader loader;

	public static SoloMgr soloMgr;

	public static NetSession netSession;

	private bool pTrialMode;

	public static LocString locs;

	private bool inviteHandled;

	public static float handlingInvite;

	public static InviteAcceptedEventArgs ie;

	public void HandleInvite(object sender, EventArgs e)
	{
		handlingInvite = 2f;
		ie = (InviteAcceptedEventArgs)e;
	}

	public void SignedIn(object sender, SignedInEventArgs e)
	{
		signedInGamerMgr.ProcessSignIn(e.Gamer);
	}

	public void SignedOut(object sender, SignedOutEventArgs e)
	{
		signedInGamerMgr.ProcessSignOut(e.Gamer);
	}

	public Game1()
	{
		graphics = new GraphicsDeviceManager(this);
		Content.RootDirectory = "Content";
		Components.Add(new GamerServicesComponent(this));
		IsFixedTimeStep = true;
	}

	protected override void Dispose(bool disposing)
	{
		base.Dispose(disposing);
		Sound.Dispose();
		if (leaderBoard != null && leaderBoard.writerThread != null && leaderBoard.writerThread.IsAlive)
		{
			leaderBoard.writerThread.Join(5000);
			if (leaderBoard.writerThread.IsAlive)
			{
				leaderBoard.writerThread.Abort();
			}
		}
	}

	protected override void Initialize()
	{
		rope = new Rope(20, 20f);
		graphics.PreferMultiSampling = false;
		flibitPort.InitVideo(this, graphics);
		graphics.ApplyChanges();
		base.Initialize();
	}

	public static int GetPlayers()
	{
		return GetPlayers(local: false);
	}

	public static int GetPlayers(bool local)
	{
		int result = 1;
		if (GameState.state == GameState.State.Menu)
		{
			result = menuMgr.GetPlayers();
		}
		if (arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
		{
			result = arcade.players;
		}
		else if (arcade.arcadeMode == Arcade.ArcadeMode.DishChallenge)
		{
			result = 1;
		}
		else if (levelMgr.currentTrack == 2)
		{
			result = coopPlayers;
		}
		if (local && (netSession.IsClient() || netSession.IsHost()))
		{
			result = 1;
		}
		return result;
	}

	protected override void LoadContent()
	{
		SpriteTools.Init(GraphicsDevice);
		Rand.rand = new Random();
		waterTarg = new RenderTarget2D(graphics.GraphicsDevice, 256, 256);
		fogTarg = new RenderTarget2D(graphics.GraphicsDevice, 256, 256);
		sceneMgr = new SceneMgr(Content);
		CreateTargs();
		GameRender.Init(graphics, Content);
		sceneMgr.addMgr = new AddMgr(graphics.GraphicsDevice);
		worldMapMgr = new WorldMapMgr(graphics.GraphicsDevice);
		skaTex = Content.Load<Texture2D>("gfx/skastudios");
		releaseTex = Content.Load<Texture2D>("gfx/esrb");
		xblaTex = Content.Load<Texture2D>("gfx/xbla");
		loadingTex = Content.Load<Texture2D>("gfx/loading");
		nullTex = Content.Load<Texture2D>("gfx/1x1");
		magicTex = Content.Load<Texture2D>("gfx/magic");
		loader = new Loader(Content);
		loader.SynchronousLoad();
	}

	protected override void UnloadContent()
	{
	}

	protected override void Update(GameTime gameTime)
	{
		flibitPort.UpdateInput(IsActive);
		GameUpdate(gameTime);
		base.Update(gameTime);
	}

	protected override void Draw(GameTime gameTime)
	{
		ScrollManager.UpdateCannedValues();
		GameDraw(gameTime);
		base.Draw(gameTime);
		flibitPort.DrawMouse();
	}

	private void GameUpdate(GameTime gameTime)
	{
		if (mustExit)
		{
			Exit();
		}
		active = IsActive;
		if (loader == null)
		{
			base.Update(gameTime);
			return;
		}
		GuideStuff.Update();
		if (!loader.okToContinue)
		{
			FMan.frameTime = (float)gameTime.ElapsedGameTime.Milliseconds / 1000f;
			loader.Update();
			Printf.Update();
			if (loader.musicLoaded)
			{
				Sound.Update();
			}
			base.Update(gameTime);
			return;
		}
		if (!loader.complete)
		{
			sceneMgr.loaderFrame += FMan.frameTime;
		}
		if (menuMgr.SavingActive())
		{
			menuMgr.UpdateSaving();
		}
		if (loader.complete)
		{
			if (!inviteHandled)
			{
				NetworkSession.InviteAccepted += HandleInvite;
				inviteHandled = true;
				SignedInGamer.SignedIn += SignedIn;
				SignedInGamer.SignedOut += SignedOut;
			}
			if (handlingInvite > 0f)
			{
				handlingInvite -= FMan.realTime;
				if (handlingInvite <= 0f)
				{
					handlingInvite = 0.1f;
					if (!Guide.IsVisible)
					{
						if (GameState.state == GameState.State.Playing)
						{
							GameState.state = GameState.State.Menu;
							menuMgr.pauseMode = true;
							menuMgr.SetLevel(MenuManager.LevelTitle.EndGameJoinInvitedYouSure);
						}
						else if (menuMgr.pauseMode)
						{
							if (!menuMgr.levels[51].active)
							{
								menuMgr.SetLevel(MenuManager.LevelTitle.EndGameJoinInvitedYouSure);
							}
						}
						else
						{
							handlingInvite = 0f;
							try
							{
								FinishHandleInvite();
							}
							catch
							{
							}
						}
					}
				}
			}
		}
		bool trial = GuideStuff.GetTrial();
		if (!trial && pTrialMode)
		{
			Unlock();
		}
		pTrialMode = trial;
		if (DebugManager.ropeTest)
		{
			rope.fac = 1f;
			rope.SetOrig(new Vector2(Mouse.GetState().X, Mouse.GetState().Y));
			rope.Update();
			if (Mouse.GetState().LeftButton == ButtonState.Pressed)
			{
				rope = new Rope(6, 7f);
			}
		}
		if (DebugManager.unlockAll)
		{
			player.yukiPhase = 12;
			player.dishPhase = 7;
			character[0].charUpdate.mp = character[0].charUpdate.mmp;
		}
		FMan.Update(gameTime);
		if (arcade.arcadeMode == Arcade.ArcadeMode.Arcade && GameState.state == GameState.State.Playing && !hud.arcadeIn.IsActive())
		{
			arcade.Update();
		}
		DebugManager.Update();
		if (DebugManager.playMode == DebugManager.PlayMode.Step)
		{
			if (DebugManager.canStep)
			{
				DebugManager.canStep = false;
			}
			else
			{
				FMan.frameTime = 0f;
			}
		}
		if (loadTime < 1f)
		{
			loadTime += FMan.frameTime;
		}
		gameMap.updating = false;
		Sound.Update();
		presenceMgr.Update();
		leaderBoard.Update();
		achievementMgr.Update();
		netSession.Update();
		if (menuMgr.achievable.frame > 0f)
		{
			menuMgr.achievable.Update();
		}
		rumbleManager.Update();
		signedInGamerMgr.Update();
		GuideStuff.toast = 0;
		if (menuMgr.GetMessageActive())
		{
			menuMgr.UpdateMessages();
		}
		else
		{
			if (GameState.state != GameState.State.Playing)
			{
				spriteMan.spriteThreadFrame = 0f;
			}
			switch (GameState.state)
			{
			case GameState.State.Credits:
				credits.Update();
				break;
			case GameState.State.Menu:
				menuMgr.Update();
				break;
			case GameState.State.Playing:
			{
				if (!IsActive && !menuMgr.pauseMode && MainPlayer.uberDyingFrame <= 0f && flibitPort.PauseOnLostFocus == 0)
				{
					menuMgr.Pause(0);
				}
				if (EightBitGame.enabled)
				{
					eightBitGame.Update();
					break;
				}
				if (loader.loadingStuff)
				{
					sceneMgr.loaderFrame += FMan.frameTime;
					break;
				}
				if (MainPlayer.uberDyingFrame > 1f)
				{
					menuMgr.Update();
				}
				else
				{
					levelMgr.Update();
				}
				hud.Update();
				gamePlayerMgr.Update();
				killManager.Update();
				QuakeManager.Update();
				petPlayerMgr.Update();
				for (int i = 0; i < 4; i++)
				{
					if (IsPlayerChar(i) && character[i].charKeys != null)
					{
						character[i].charKeys.idx = mainPlayer[i];
					}
				}
				if (!hud.PickupsActive() && !hud.invMgr.IsActive())
				{
					camMgr.Update(character, gameMap, levelMgr, killManager);
				}
				if (sceneMgr.playing || hud.GetIsTutActive() || hud.PickupsActive())
				{
					for (int j = 0; j < 4; j++)
					{
						if (character[j].exists && character[j].charKeys.idx > -1)
						{
							character[j].charKeys.Update(character[j].ai, character, character[j]);
						}
					}
					if (sceneMgr.playing && !hud.IsEndLevel())
					{
						sceneMgr.Update();
					}
					if (sceneMgr.overlay || hud.GetIsTutActive())
					{
						gameMap.Update();
					}
				}
				else if (!hud.invMgr.IsActive())
				{
					gameMap.Update();
				}
				if ((!sceneMgr.playing || sceneMgr.overlay) && !hud.invMgr.IsActive() && !camMgr.bossToast.IsActive() && !hud.PickupsActive() && !hud.GetIsTutActive())
				{
					if (soloMgr.active)
					{
						soloMgr.Update();
					}
					bool flag = false;
					if (!character[0].exists)
					{
						levelMgr.Continue();
					}
					for (int k = 0; k < character.Length; k++)
					{
						if (!character[k].exists)
						{
							continue;
						}
						if (character[k].team == Character.Team.BadGuys)
						{
							flag = true;
						}
						character[k].Update(gameMap.CurMap(), spriteMan, character);
						if (!(character[k].charUpdate.dyingFrame > 2f))
						{
							continue;
						}
						if (k < 4)
						{
							character[k].charUpdate.dyingFrame = 2f;
							continue;
						}
						character[k].exists = false;
						if (character[k].charUpdate.lastHitBy > -1 && character[k].charUpdate.lastHitBy < gamePlayerMgr.gamePlayer.Length && gamePlayerMgr.gamePlayer[character[k].charUpdate.lastHitBy].active)
						{
							gamePlayerMgr.gamePlayer[character[k].charUpdate.lastHitBy].DoKill();
						}
						if (killManager.victim == k)
						{
							killManager.victim = -1;
						}
					}
					if (!flag)
					{
						ReviveChars();
					}
				}
				if (camMgr.bossToast.IsActive() || hud.PickupsActive() || hud.invMgr.IsActive())
				{
					spriteMan.spriteThreadFrame = 0f;
				}
				else
				{
					spriteMan.Update(character, gameMap.CurMap());
				}
				gameMap.CurMap().UpdateLayerZoom();
				transMgr.Update(gameMap, neighborMgr);
				break;
			}
			}
		}
		Printf.Update();
	}

	private void FinishHandleInvite()
	{
		if (!ie.IsCurrentSession)
		{
			SignedInGamer gamer = ie.Gamer;
			SignedInGamer signedInGamerAtIndex = GuideStuff.GetSignedInGamerAtIndex((int)gamer.PlayerIndex);
			if (gamer != null && signedInGamerAtIndex != null && gamer.Gamertag == signedInGamerAtIndex.Gamertag)
			{
				_ = mainPlayer[0];
				mainPlayer[0] = (int)ie.Gamer.PlayerIndex;
				menuMgr.MenuReset();
				menuMgr.SetLevel(MenuManager.LevelTitle.Lobby);
				netSession.JoinInvite(ie);
			}
		}
		handlingInvite = 0f;
	}

	private void Unlock()
	{
		achievementMgr.PurchaseUnlock();
	}

	public static void ReviveChars()
	{
		if (MainPlayer.uberDyingFrame > 0f || arcade.arcadeMode == Arcade.ArcadeMode.DishChallenge)
		{
			return;
		}
		float num = 1f;
		switch (GameSettings.difficulty)
		{
		case 0:
		case 1:
			num = 1f;
			break;
		case 2:
			num = 0.66f;
			break;
		case 3:
			num = 0.33f;
			break;
		case 4:
			num = 0.25f;
			break;
		case 5:
			num = 0.5f;
			break;
		}
		for (int i = 0; i < 4; i++)
		{
			if (character[i].exists && character[i].charUpdate.hp < character[i].charUpdate.mhp * num)
			{
				character[i].charUpdate.hp = character[i].charUpdate.mhp * num;
			}
		}
		for (int j = 0; j < gamePlayerMgr.gamePlayer.Length; j++)
		{
			if (gamePlayerMgr.gamePlayer[j].active)
			{
				gamePlayerMgr.gamePlayer[j].PushCombo();
			}
		}
	}

	private void GameDraw(GameTime gameTime)
	{
		if (DebugManager.showFPS != DebugManager.StatMode.Off)
		{
			DebugManager.framesRendered++;
		}
		if (loader == null)
		{
			graphics.GraphicsDevice.Clear(Color.Black);
			base.Draw(gameTime);
			return;
		}
		if (!loader.okToContinue)
		{
			graphics.GraphicsDevice.Clear(Color.Black);
			loader.Draw();
			Printf.Draw(SpriteTools.sprite, font);
			base.Draw(gameTime);
			return;
		}
		graphics.GraphicsDevice.Clear(Color.Black);
		switch (GameState.state)
		{
		case GameState.State.Credits:
			credits.Draw(graphics, SpriteTools.sprite);
			break;
		case GameState.State.Menu:
			menuMgr.Draw(graphics, SpriteTools.sprite);
			if (!loader.complete)
			{
				sceneMgr.DrawLoader(SpriteTools.sprite);
			}
			break;
		case GameState.State.Playing:
			if (EightBitGame.enabled)
			{
				eightBitGame.Draw(SpriteTools.sprite, eightBitTex, graphics.GraphicsDevice, mainTarg);
			}
			else if (sceneMgr.playing && !sceneMgr.overlay)
			{
				sceneMgr.Draw(graphics, SpriteTools.sprite, overlay: true);
			}
			else
			{
				GameRender.Draw(graphics, character, gameMap, SpriteTools.sprite, spriteMan, spritesTex, graphics);
			}
			break;
		case GameState.State.DrawWorldMode:
			WorldManager.DrawWorld(SpriteTools.sprite, "main", 0, 0, 50, 50);
			SpriteTools.BeginAlpha();
			SpriteTools.sprite.Draw(nullTex, new Rectangle(0, 0, 100, 100), Color.Red);
			SpriteTools.End();
			break;
		}
		if (DebugManager.ropeTest)
		{
			rope.Draw(SpriteTools.sprite);
		}
		if (menuMgr.achievable.frame > 0f)
		{
			SpriteTools.BeginAlpha();
			menuMgr.DrawAchievable(SpriteTools.sprite);
			SpriteTools.End();
		}
		if (menuMgr.GetMessageActive())
		{
			SpriteTools.BeginAlpha();
			menuMgr.DrawMessages(SpriteTools.sprite);
			SpriteTools.End();
		}
		if (menuMgr.SavingActive())
		{
			menuMgr.DrawSaving(SpriteTools.sprite);
		}
		Printf.Draw(SpriteTools.sprite, font);
	}

	internal static void DitchInvite()
	{
		handlingInvite = 0f;
	}

	public static void CreateTargs()
	{
		refractTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		mainTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		mapTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		auxTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		threshTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		mapBackTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X / 4, (int)ScrollManager.screenSize.Y / 4);
		menuTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		postGlowTarg = new RenderTarget2D(graphics.GraphicsDevice, 64, 64);
		bgRefractTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		feedbackTarg = new RenderTarget2D[2]
		{
			new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y),
			new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y)
		};
		threeDeeTarg = new RenderTarget2D[2]
		{
			new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y),
			new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y)
		};
		sceneMgr.comicTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		sceneMgr.maskTarg = new RenderTarget2D(graphics.GraphicsDevice, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y);
		if (GameRender.bloomComponent != null)
		{
			GameRender.bloomComponent.CreateTargs(graphics.GraphicsDevice);
		}
	}
}
