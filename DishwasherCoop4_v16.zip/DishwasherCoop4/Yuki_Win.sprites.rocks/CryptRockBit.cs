using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.rocks;

public class CryptRockBit : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		p.flags = flags;
		p.owner = owner;
		p.frame = Rand.GetRandomFloat(0.2f, 0.5f);
		p.wallFree = false;
		p.r = Rand.GetRandomFloat(0f, 6.28f);
		p.rDir = Rand.GetRandomFloat(-5f, 5f);
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.r += p.rDir * FMan.frameTime;
		p.traj.Y += FMan.frameTime * 500f;
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640, 32, 64, 64), new Color(0.2f, 0.2f, 0.2f, p.frame * 3f), p.r, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * p.size, SpriteEffects.None, 1f);
	}
}
