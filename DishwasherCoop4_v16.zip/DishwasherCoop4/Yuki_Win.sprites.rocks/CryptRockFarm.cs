using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.audio;
using Yuki_Win.director;

namespace Yuki_Win.sprites.rocks;

public class CryptRockFarm : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		p.flags = flags;
		p.owner = owner;
		p.frame = 2f;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		float frame = p.frame;
		base.Update(p, spriteMan);
		if ((int)(p.frame * 5f) != (int)(frame * 5f))
		{
			QuakeManager.SetQuake(0.2f);
			Sound.PlaySnd(Sound.Category.FX, "bass");
			Vector2 realLoc = ScrollManager.GetRealLoc(default, 1f);
			Vector2 realLoc2 = ScrollManager.GetRealLoc(new Vector2(ScrollManager.screenSize.X, 0f), 1f);
			spriteMan.AddSprite(94, Rand.GetRandomVec2(realLoc.X, realLoc2.X, realLoc.Y - 100f, realLoc2.Y - 100f), Rand.GetRandomVec2(-100f, 100f, 200f, 300f), 1f, 0, p.owner);
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		base.Draw(p, sprite, spritesTex);
	}
}
