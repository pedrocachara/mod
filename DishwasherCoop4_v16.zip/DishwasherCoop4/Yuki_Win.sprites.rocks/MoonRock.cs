using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.director;

namespace Yuki_Win.sprites.rocks;

public class MoonRock : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.size = size;
		p.flags = flags;
		p.owner = owner;
		p.frame = 3f;
		p.wallFree = false;
		p.r = Rand.GetRandomFloat(0f, 6.28f);
		p.rDir = Rand.GetRandomFloat(-5f, 5f);
		p.hitter = true;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		p.traj.Y += FMan.frameTime * 500f;
		p.r += p.rDir * FMan.frameTime;
		QuakeManager.SetQuake(0.25f);
		if (p.wallFree)
		{
			if (Game1.gameMap.CurMap().TestCol(p.loc))
			{
				p.exists = false;
			}
		}
		else if (!Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.wallFree = true;
		}
		base.Update(p, spriteMan);
		if (!p.exists || p.frame <= 0f)
		{
			for (int i = 0; i < 3; i++)
			{
				spriteMan.AddSprite(18, p.loc, Rand.GetRandomVec2(-200f, 200f, -200f, 200f), Rand.GetRandomFloat(2f, 3f), 0, p.owner);
			}
			for (int j = 0; j < 5; j++)
			{
				Vector2 randomVec = Rand.GetRandomVec2(-600f, 600f, -600f, 600f);
				spriteMan.AddSprite(92, p.loc + randomVec * 0.1f, randomVec, Rand.GetRandomFloat(0.5f, 0.9f), 0, p.owner);
			}
		}
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(640, 32, 64, 64), new Color(0.6f, 0.6f, 0.6f, 1f), p.r, new Vector2(32f, 32f), ScrollManager.cannedDepth[0] * 1.15f, SpriteEffects.None, 1f);
	}
}
