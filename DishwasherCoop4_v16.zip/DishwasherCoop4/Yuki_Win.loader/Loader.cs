using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit;
using yMapEdit.segdef;
using Yuki_Win.achievements;
using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.chars.charMeta;
using Yuki_Win.chars.script;
using Yuki_Win.credits;
using Yuki_Win.debug;
using Yuki_Win.director;
using Yuki_Win.eightbit;
using Yuki_Win.gameRender;
using Yuki_Win.guidestuff;
using Yuki_Win.hud;
using Yuki_Win.hud.practice;
using Yuki_Win.leaderboards;
using Yuki_Win.levels;
using Yuki_Win.localization;
using Yuki_Win.maps;
using Yuki_Win.menu;
using Yuki_Win.menu.levels.moveslist;
using Yuki_Win.netplay;
using Yuki_Win.pet;
using Yuki_Win.player;
using Yuki_Win.player.beads;
using Yuki_Win.solo;
using Yuki_Win.sprites;
using Yuki_Win.storage;
using Yuki_Win.world;
using Yuki_XBLA.presence;

namespace Yuki_Win.loader;

public class Loader
{
	public const int LOAD_XBLA = 0;

	public const int LOAD_SKA_STUDIOS = 1;

	public const int LOAD_DBP = 2;

	public const int LOAD_AUTOSAVE = 3;

	public const int LOAD_LOADING = 4;

	public const int LOAD_FINAL = 5;

	private const float SCREENLEN = 4f;

	public const int FAT_CHAR = 0;

	public const int FAT_TEXTURE = 1;

	public const int FAT_CHARMETA = 2;

	public const int FAT_END = 3;

	private const int TEX_NOT_LOADED = 0;

	private const int TEX_FLAGGED_FOR_LOAD = 1;

	private const int TEX_LOADED = 2;

	private const int TOTAL_MAP_TEX = 17;

	private ContentManager Content;

	public float screenFrame;

	public int screen;

	private float uberFrame;

	private bool loadStart;

	public bool complete;

	public bool fat;

	private int[] mapsTexLoaded;

	public bool loadingStuff;

	public bool halfLoaded;

	public bool okToContinue;

	public bool musicLoaded;

	private StringBuilder[] autoSave = new StringBuilder[3]
	{
		new StringBuilder(YukiText.autosave1),
		new StringBuilder(YukiText.autosave2),
		new StringBuilder(YukiText.autosave3)
	};

	public Loader(ContentManager Content)
	{
		this.Content = Content;
		screen = 1;
	}

	public void SynchronousLoad()
	{
		loadStart = true;
		Load();
	}

	public void Update()
	{
		screenFrame += FMan.frameTime;
		uberFrame += FMan.frameTime;
		if (screen == 4 && screenFrame > 1f)
		{
			screenFrame = 1f;
		}
		if (screen == 3 && Game1.menuMgr != null)
		{
			lock (Game1.menuMgr)
			{
				Game1.menuMgr.UpdateSaving();
			}
		}
		if (screenFrame > 4f)
		{
			switch (screen)
			{
			case 0:
				screen = 1;
				break;
			case 2:
				if (Game1.menuMgr == null)
				{
					screenFrame = 4f;
				}
				else
				{
					screen = 3;
				}
				break;
			case 3:
				screen = 4;
				Game1.menuMgr.KillSaving();
				GuideStuff.CheckDemo();
				break;
			case 1:
				screen = 3;
				break;
			case 4:
				screen = 5;
				break;
			}
			screenFrame = 0f;
		}
		if (screen == 4 && halfLoaded)
		{
			okToContinue = true;
		}
	}

	public void Draw()
	{
		float num = 1f;
		if (screenFrame < 0.5f)
		{
			num = screenFrame * 2f;
		}
		if (screenFrame > 3.5f)
		{
			num = (4f - screenFrame) * 2f;
		}
		SpriteTools.BeginAlpha();
		Texture2D texture2D = null;
		switch (screen)
		{
		case 1:
			texture2D = Game1.skaTex;
			break;
		case 0:
			texture2D = Game1.xblaTex;
			break;
		case 2:
			texture2D = Game1.releaseTex;
			break;
		case 3:
		{
			SpriteTools.sprite.End();
			if (Game1.menuMgr != null)
			{
				lock (Game1.menuMgr)
				{
					Game1.menuMgr.DrawSaving(SpriteTools.sprite, center: true, num, 10f - screenFrame);
				}
			}
			SpriteTools.BeginAlpha();
			for (int k = 0; k < autoSave.Length; k++)
			{
				Text.DrawCText(SpriteTools.sprite, ScrollManager.screenSize / 2f + new Vector2(0f, 60f + (float)k * 30f + ((k > 0) ? 10f : 0f)), autoSave[k], new Color(1f, 1f, 1f, num), 1f, 1, blur: true);
			}
			break;
		}
		case 4:
		{
			texture2D = Game1.loadingTex;
			SpriteTools.sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0f, 0f, 0f, num));
			for (int i = 0; i < 2; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					SpriteTools.sprite.Draw(Game1.magicTex, ScrollManager.screenSize / 2f, new Rectangle(j * 320, 0, 320, 320), new Color(1f, 1f, 1f, num * 0.85f), (float)(j + 1) * uberFrame * (((j + i * 3) % 2 == 0) ? (-1f) : 1f) * 0.25f, new Vector2(160f, 160f), ((i == 0) ? 0.32f : 0.7f) * 5f, SpriteEffects.None, 1f);
				}
			}
			break;
		}
		}
		if (texture2D != null)
		{
			SpriteTools.sprite.Draw(texture2D, ScrollManager.screenSize / 2f, new Rectangle(0, 0, texture2D.Width, texture2D.Height), new Color(1f, 1f, 1f, num), 0f, new Vector2(texture2D.Width, texture2D.Height) / 2f, 1f, SpriteEffects.None, 1f);
		}
		SpriteTools.sprite.End();
	}

	public void DebugPrint(string s)
	{
	}

	private void Load()
	{
		Game1.locs = new LocString();
		DebugManager.Init();
		Game1.spawnMgr = new SpawnManager();
		Game1.beadMgr = new BeadMgr();
		HUDStrings.Init();
		DebugPrint("Hud strings inited");
		Game1.font = Content.Load<SpriteFont>("Arial");
		Printf.Init();
		Game1.spritesTex = Content.Load<Texture2D>("gfx/sprites");
		Game1.comicText = Content.Load<Texture2D>("gfx/ctext");
		Game1.comicTextBlur = Content.Load<Texture2D>("gfx/ctext_blur");
		Game1.signedInGamerMgr = new SignedInGamerMgr();
		Game1.petPlayerMgr = new PetPlayerMgr();
		Game1.leaderBoard = new LeaderBoard();
		Game1.killManager = new KillManager();
		Game1.levelMgr = new LevelManager();
		Game1.movesListCatalog = new MovesListCatalog();
		Game1.camMgr = new CamManager();
		Sound.Init();
		Game1.practice = new Practice();
		MainPlayer.InitPlayer();
		Game1.gamePlayerMgr = new GamePlayerManager();
		Game1.hud = new HUD();
		Game1.storageMgr = new StorageMgr();
		Game1.achievementMgr = new AchievementMgr();
		Game1.soloMgr = new SoloMgr();
		Game1.credits = new Credits();
		Game1.player = new MainPlayer();
		Game1.invCatalog = new InvCatalog();
		Game1.presenceMgr = new PresenceMgr();
		Game1.netSession = new NetSession();
		Game1.charDef = new CharDef[64];
		ScriptCommandParser.Init();
		Game1.rumbleManager = new RumbleManager();
		DebugPrint("Rumble!");
		Game1.arcade = new Arcade();
		Game1.menuMgr = new MenuManager(Content);
		DebugPrint("menu manager loaded");
		CultureInfo cultureInfo = YukiText.Culture ?? CultureInfo.CurrentUICulture;
		switch (cultureInfo.TwoLetterISOLanguageName)
		{
		case "fr":
			Text.language = 2;
			break;
		case "pt":
		case "it":
		case "es":
		case "de":
			Text.language = 1;
			break;
		case "ja":
			Game1.jpTextTex = Content.Load<SpriteFont>("SpriteFont1_JPN");
			Text.language = 3;
			break;
		}
		DebugPrint("Font loaded");
		CharSwishes.Init();
		DateTime utcNow = DateTime.UtcNow;
		Game1.headTexMeta = new CharTexture[59];
		Game1.torsoTexMeta = new CharTexture[48];
		Game1.legsTexMeta = new CharTexture[38];
		Game1.weaponTexMeta = new CharTexture[20];
		CharMetaCommands.Init();
		Game1.charMeta = new CharMeta[128];
		BottomRightMessage.Init();
		DebugPrint("stuff2 inited");
		fat = true;
		fat = false;
		_ = DateTime.UtcNow - utcNow;
		WorldManager.Init();
		WorldManager.LoadWorld("asylum");
		WorldManager.LoadWorld("prison");
		WorldManager.LoadWorld("escape");
		WorldManager.LoadWorld("main");
		WorldManager.LoadWorld("dish");
		utcNow = DateTime.UtcNow;
		_ = DateTime.UtcNow - utcNow;
		ScrollManager.zoom = 1f;
		ScrollManager.scroll = default;
		Game1.spriteMan = new SpriteManager();
		PostGlowMgr.Init();
		Game1.transMgr = new TransitionManager();
		Game1.gameMap = new GameMap();
		musicLoaded = true;
		Game1.neighborMgr = new NeighborManager();
		DebugPrint("stuff3 inited");
		Game1.segDefMgr = new SegDefManager();
		Game1.segDefMgr.Read("maps/data/segdef.zdx");
		DebugPrint("segments loaded");
		Game1.sceneMgr.comicEffect = Content.Load<Effect>("fx/comic");
		Game1.sceneMgr.creepEffect = Content.Load<Effect>("fx/creep");
		Game1.sceneMgr.creepTVEffect = Content.Load<Effect>("fx/creeptv");
		mapsTexLoaded = new int[17];
		Game1.mapsTex = new Texture2D[17];
		Game1.legsTex = new Texture2D[Game1.legsTexMeta.Length];
		Game1.torsoTex = new Texture2D[Game1.torsoTexMeta.Length];
		Game1.headTex = new Texture2D[Game1.headTexMeta.Length];
		Game1.weaponTex = new Texture2D[Game1.weaponTexMeta.Length];
		Game1.bubbleTex = Content.Load<Texture2D>("gfx/bubbles");
		Game1.worldMapTex = Content.Load<Texture2D>("gfx/worldmap/worldmap");
		Game1.worldSpritesTex = Content.Load<Texture2D>("gfx/worldmap/worldsprites");
		utcNow = DateTime.UtcNow;
		_ = DateTime.UtcNow - utcNow;
		Game1.eightBitGame = new EightBitGame();
		Game1.character = new Character[32];
		for (int i = 0; i < Game1.character.Length; i++)
		{
			Game1.character[i] = new Character(i);
		}
		Game1.portraitsTex = Content.Load<Texture2D>("gfx/portraits");
		Game1.blockText = Content.Load<Texture2D>("gfx/blocktext");
		Game1.spookyText = Content.Load<Texture2D>("gfx/jtext");
		halfLoaded = true;
		DebugPrint("Half loaded");
		if (fat)
		{
			BinaryReader binaryReader = new BinaryReader(File.Open("chars/fat/fat.dw2", FileMode.Open, FileAccess.Read));
			bool flag = false;
			while (!flag)
			{
				switch (binaryReader.ReadInt32())
				{
				case 0:
				{
					string text3 = binaryReader.ReadString();
					switch (text3)
					{
					case "bigengie":
						Game1.charDef[28] = new CharDef(binaryReader);
						break;
					case "blade":
						Game1.charDef[4] = new CharDef(binaryReader);
						break;
					case "box":
						Game1.charDef[17] = new CharDef(binaryReader);
						break;
					case "cretin":
						Game1.charDef[10] = new CharDef(binaryReader);
						break;
					case "crow":
						Game1.charDef[9] = new CharDef(binaryReader);
						break;
					case "dish":
						Game1.charDef[3] = new CharDef(binaryReader);
						break;
					case "dragon":
						Game1.charDef[20] = new CharDef(binaryReader);
						break;
					case "engineer":
						Game1.charDef[26] = new CharDef(binaryReader);
						break;
					case "force":
						Game1.charDef[16] = new CharDef(binaryReader);
						break;
					case "goreface":
						Game1.charDef[13] = new CharDef(binaryReader);
						break;
					case "gown":
						Game1.charDef[6] = new CharDef(binaryReader);
						break;
					case "hockey":
						Game1.charDef[19] = new CharDef(binaryReader);
						break;
					case "horse":
						Game1.charDef[29] = new CharDef(binaryReader);
						break;
					case "swat":
						Game1.charDef[1] = new CharDef(binaryReader);
						break;
					case "invalid":
						Game1.charDef[21] = new CharDef(binaryReader);
						break;
					case "lich":
						Game1.charDef[11] = new CharDef(binaryReader);
						break;
					case "midengie":
						Game1.charDef[30] = new CharDef(binaryReader);
						break;
					case "murderfly":
						Game1.charDef[18] = new CharDef(binaryReader);
						break;
					case "neko":
						Game1.charDef[5] = new CharDef(binaryReader);
						break;
					case "pod":
						Game1.charDef[8] = new CharDef(binaryReader);
						break;
					case "prison":
						Game1.charDef[7] = new CharDef(binaryReader);
						break;
					case "puppet":
						Game1.charDef[27] = new CharDef(binaryReader);
						break;
					case "samurai":
						Game1.charDef[23] = new CharDef(binaryReader);
						break;
					case "shark":
						Game1.charDef[24] = new CharDef(binaryReader);
						break;
					case "shop":
						Game1.charDef[22] = new CharDef(binaryReader);
						break;
					case "skeletank":
						Game1.charDef[15] = new CharDef(binaryReader);
						break;
					case "slava":
						Game1.charDef[14] = new CharDef(binaryReader);
						break;
					case "squid":
						Game1.charDef[25] = new CharDef(binaryReader);
						break;
					case "swordsman":
						Game1.charDef[31] = new CharDef(binaryReader);
						break;
					case "tank":
						Game1.charDef[2] = new CharDef(binaryReader);
						break;
					case "warden":
						Game1.charDef[12] = new CharDef(binaryReader);
						break;
					case "yuki":
						Game1.charDef[0] = new CharDef(binaryReader);
						break;
					case "chef":
						Game1.charDef[32] = new CharDef(binaryReader);
						break;
					case "raven":
						Game1.charDef[33] = new CharDef(binaryReader);
						break;
					case "transmara":
						Game1.charDef[34] = new CharDef(binaryReader);
						break;
					case "hypno":
						Game1.charDef[35] = new CharDef(binaryReader);
						break;
					case "assassin":
						Game1.charDef[36] = new CharDef(binaryReader);
						break;
					default:
						Printf.WriteLine("Fatal load error: " + text3 + " not found.");
						break;
					}
					break;
				}
				case 2:
				{
					string text2 = binaryReader.ReadString();
					switch (text2)
					{
					case "inmate":
						Game1.charMeta[99] = new CharMeta(binaryReader);
						break;
					case "yukif":
						Game1.charMeta[78] = new CharMeta(binaryReader);
						break;
					case "yuki":
						Game1.charMeta[0] = new CharMeta(binaryReader);
						break;
					case "yukic":
						Game1.charMeta[25] = new CharMeta(binaryReader);
						break;
					case "yukik":
						Game1.charMeta[2] = new CharMeta(binaryReader);
						break;
					case "yukis":
						Game1.charMeta[46] = new CharMeta(binaryReader);
						break;
					case "maraf":
						Game1.charMeta[79] = new CharMeta(binaryReader);
						break;
					case "mara":
						Game1.charMeta[37] = new CharMeta(binaryReader);
						break;
					case "marac":
						Game1.charMeta[39] = new CharMeta(binaryReader);
						break;
					case "marak":
						Game1.charMeta[38] = new CharMeta(binaryReader);
						break;
					case "maras":
						Game1.charMeta[76] = new CharMeta(binaryReader);
						break;
					case "apple2":
						Game1.charMeta[40] = new CharMeta(binaryReader);
						break;
					case "banker":
						Game1.charMeta[45] = new CharMeta(binaryReader);
						break;
					case "bigengie":
						Game1.charMeta[71] = new CharMeta(binaryReader);
						break;
					case "blade":
						Game1.charMeta[6] = new CharMeta(binaryReader);
						break;
					case "box":
						Game1.charMeta[48] = new CharMeta(binaryReader);
						break;
					case "chaironly":
						Game1.charMeta[12] = new CharMeta(binaryReader);
						break;
					case "corpse":
						Game1.charMeta[66] = new CharMeta(binaryReader);
						break;
					case "cretin":
						Game1.charMeta[19] = new CharMeta(binaryReader);
						break;
					case "crow":
						Game1.charMeta[18] = new CharMeta(binaryReader);
						break;
					case "dish":
						Game1.charMeta[5] = new CharMeta(binaryReader);
						break;
					case "dishc":
						Game1.charMeta[16] = new CharMeta(binaryReader);
						break;
					case "dishh":
						Game1.charMeta[15] = new CharMeta(binaryReader);
						break;
					case "dishs":
						Game1.charMeta[24] = new CharMeta(binaryReader);
						break;
					case "disht":
						Game1.charMeta[26] = new CharMeta(binaryReader);
						break;
					case "dragon":
						Game1.charMeta[59] = new CharMeta(binaryReader);
						break;
					case "dragonclaw":
						Game1.charMeta[60] = new CharMeta(binaryReader);
						break;
					case "engie2":
						Game1.charMeta[73] = new CharMeta(binaryReader);
						break;
					case "engineer":
						Game1.charMeta[68] = new CharMeta(binaryReader);
						break;
					case "force":
						Game1.charMeta[47] = new CharMeta(binaryReader);
						break;
					case "freak":
						Game1.charMeta[54] = new CharMeta(binaryReader);
						break;
					case "general":
						Game1.charMeta[52] = new CharMeta(binaryReader);
						break;
					case "ghost":
						Game1.charMeta[56] = new CharMeta(binaryReader);
						break;
					case "ghoul":
						Game1.charMeta[77] = new CharMeta(binaryReader);
						break;
					case "goon":
						Game1.charMeta[53] = new CharMeta(binaryReader);
						break;
					case "goonpuppet":
						Game1.charMeta[69] = new CharMeta(binaryReader);
						break;
					case "goreface":
						Game1.charMeta[23] = new CharMeta(binaryReader);
						break;
					case "gown_arm":
						Game1.charMeta[22] = new CharMeta(binaryReader);
						break;
					case "gown_chair":
						Game1.charMeta[9] = new CharMeta(binaryReader);
						break;
					case "gown_crawl":
						Game1.charMeta[8] = new CharMeta(binaryReader);
						break;
					case "gown_walk":
						Game1.charMeta[10] = new CharMeta(binaryReader);
						break;
					case "guard":
						Game1.charMeta[1] = new CharMeta(binaryReader);
						break;
					case "hackbot":
						Game1.charMeta[82] = new CharMeta(binaryReader);
						break;
					case "hargreavesc":
						Game1.charMeta[34] = new CharMeta(binaryReader);
						break;
					case "hargreavesh":
						Game1.charMeta[33] = new CharMeta(binaryReader);
						break;
					case "hargreaves":
						Game1.charMeta[32] = new CharMeta(binaryReader);
						break;
					case "hargreavess":
						Game1.charMeta[35] = new CharMeta(binaryReader);
						break;
					case "hargreavest":
						Game1.charMeta[36] = new CharMeta(binaryReader);
						break;
					case "hockey":
						Game1.charMeta[55] = new CharMeta(binaryReader);
						break;
					case "horse":
						Game1.charMeta[72] = new CharMeta(binaryReader);
						break;
					case "invalid":
						Game1.charMeta[62] = new CharMeta(binaryReader);
						break;
					case "judge":
						Game1.charMeta[67] = new CharMeta(binaryReader);
						break;
					case "lich":
						Game1.charMeta[21] = new CharMeta(binaryReader);
						break;
					case "loicc":
						Game1.charMeta[29] = new CharMeta(binaryReader);
						break;
					case "loich":
						Game1.charMeta[28] = new CharMeta(binaryReader);
						break;
					case "loic":
						Game1.charMeta[27] = new CharMeta(binaryReader);
						break;
					case "loics":
						Game1.charMeta[30] = new CharMeta(binaryReader);
						break;
					case "loict":
						Game1.charMeta[31] = new CharMeta(binaryReader);
						break;
					case "midengie":
						Game1.charMeta[74] = new CharMeta(binaryReader);
						break;
					case "mook":
						Game1.charMeta[57] = new CharMeta(binaryReader);
						break;
					case "murderbug":
						Game1.charMeta[75] = new CharMeta(binaryReader);
						break;
					case "murderfly":
						Game1.charMeta[49] = new CharMeta(binaryReader);
						break;
					case "neko":
						Game1.charMeta[7] = new CharMeta(binaryReader);
						break;
					case "ninja":
						Game1.charMeta[14] = new CharMeta(binaryReader);
						break;
					case "pod":
						Game1.charMeta[13] = new CharMeta(binaryReader);
						break;
					case "podbot":
						Game1.charMeta[41] = new CharMeta(binaryReader);
						break;
					case "prison":
						Game1.charMeta[11] = new CharMeta(binaryReader);
						break;
					case "pumpkin":
						Game1.charMeta[43] = new CharMeta(binaryReader);
						break;
					case "pyro":
						Game1.charMeta[51] = new CharMeta(binaryReader);
						break;
					case "sackboy":
						Game1.charMeta[61] = new CharMeta(binaryReader);
						break;
					case "samurai":
						Game1.charMeta[64] = new CharMeta(binaryReader);
						break;
					case "shark":
						Game1.charMeta[58] = new CharMeta(binaryReader);
						break;
					case "shop":
						Game1.charMeta[63] = new CharMeta(binaryReader);
						break;
					case "predator":
						Game1.charMeta[97] = new CharMeta(binaryReader);
						break;
					case "raptor":
						Game1.charMeta[98] = new CharMeta(binaryReader);
						break;
					case "skeletank":
						Game1.charMeta[44] = new CharMeta(binaryReader);
						break;
					case "slava":
						Game1.charMeta[42] = new CharMeta(binaryReader);
						break;
					case "squid":
						Game1.charMeta[65] = new CharMeta(binaryReader);
						break;
					case "swat":
						Game1.charMeta[3] = new CharMeta(binaryReader);
						break;
					case "swatpuppet":
						Game1.charMeta[70] = new CharMeta(binaryReader);
						break;
					case "swordsman":
						Game1.charMeta[80] = new CharMeta(binaryReader);
						break;
					case "tank":
						Game1.charMeta[4] = new CharMeta(binaryReader);
						break;
					case "thug":
						Game1.charMeta[81] = new CharMeta(binaryReader);
						break;
					case "warclone":
						Game1.charMeta[50] = new CharMeta(binaryReader);
						break;
					case "warden":
						Game1.charMeta[20] = new CharMeta(binaryReader);
						break;
					case "zom":
						Game1.charMeta[17] = new CharMeta(binaryReader);
						break;
					case "chef":
						Game1.charMeta[83] = new CharMeta(binaryReader);
						break;
					case "knifeonly":
						Game1.charMeta[84] = new CharMeta(binaryReader);
						break;
					case "gown_knife":
						Game1.charMeta[86] = new CharMeta(binaryReader);
						break;
					case "gown_hobble":
						Game1.charMeta[85] = new CharMeta(binaryReader);
						break;
					case "uslava":
						Game1.charMeta[87] = new CharMeta(binaryReader);
						break;
					case "raven":
						Game1.charMeta[88] = new CharMeta(binaryReader);
						break;
					case "transmara":
						Game1.charMeta[89] = new CharMeta(binaryReader);
						break;
					case "hypno":
						Game1.charMeta[90] = new CharMeta(binaryReader);
						break;
					case "yukinpc":
						Game1.charMeta[91] = new CharMeta(binaryReader);
						break;
					case "dish_hatless":
						Game1.charMeta[92] = new CharMeta(binaryReader);
						break;
					case "dishc_hatless":
						Game1.charMeta[93] = new CharMeta(binaryReader);
						break;
					case "assassin":
						Game1.charMeta[94] = new CharMeta(binaryReader);
						break;
					case "guitar":
						Game1.charMeta[95] = new CharMeta(binaryReader);
						break;
					case "violin":
						Game1.charMeta[96] = new CharMeta(binaryReader);
						break;
					default:
						Printf.WriteLine("Fatal load error: " + text2 + " not found.");
						break;
					}
					break;
				}
				case 1:
				{
					string text = binaryReader.ReadString();
					if (text.Substring(0, 4) == "weap")
					{
						Game1.weaponTexMeta[Convert.ToInt32(text.Substring("weapon".Length))] = new CharTexture(binaryReader);
					}
					else if (text.Substring(0, 4) == "tors")
					{
						Game1.torsoTexMeta[Convert.ToInt32(text.Substring("torso".Length))] = new CharTexture(binaryReader);
					}
					else if (text.Substring(0, 4) == "legs")
					{
						Game1.legsTexMeta[Convert.ToInt32(text.Substring("legs".Length))] = new CharTexture(binaryReader);
					}
					else if (text.Substring(0, 4) == "head")
					{
						Game1.headTexMeta[Convert.ToInt32(text.Substring("head".Length))] = new CharTexture(binaryReader);
					}
					else
					{
						Printf.WriteLine("Fatal load error: " + text);
					}
					break;
				}
				case 3:
					flag = true;
					break;
				}
			}
			binaryReader.Close();
		}
		else
		{
			Game1.charDef[0] = new CharDef("chars/data/yuki.zsx");
			Game1.charDef[1] = new CharDef("chars/data/swat.zsx");
			Game1.charDef[2] = new CharDef("chars/data/tank.zsx");
			Game1.charDef[3] = new CharDef("chars/data/dish.zsx");
			Game1.charDef[4] = new CharDef("chars/data/blade.zsx");
			Game1.charDef[5] = new CharDef("chars/data/neko.zsx");
			Game1.charDef[6] = new CharDef("chars/data/gown.zsx");
			Game1.charDef[7] = new CharDef("chars/data/prison.zsx");
			Game1.charDef[8] = new CharDef("chars/data/pod.zsx");
			Game1.charDef[9] = new CharDef("chars/data/crow.zsx");
			Game1.charDef[10] = new CharDef("chars/data/cretin.zsx");
			Game1.charDef[11] = new CharDef("chars/data/lich.zsx");
			Game1.charDef[12] = new CharDef("chars/data/warden.zsx");
			Game1.charDef[13] = new CharDef("chars/data/goreface.zsx");
			Game1.charDef[14] = new CharDef("chars/data/slava.zsx");
			Game1.charDef[15] = new CharDef("chars/data/skeletank.zsx");
			Game1.charDef[16] = new CharDef("chars/data/force.zsx");
			Game1.charDef[17] = new CharDef("chars/data/box.zsx");
			Game1.charDef[18] = new CharDef("chars/data/murderfly.zsx");
			Game1.charDef[19] = new CharDef("chars/data/hockey.zsx");
			Game1.charDef[20] = new CharDef("chars/data/dragon.zsx");
			Game1.charDef[21] = new CharDef("chars/data/invalid.zsx");
			Game1.charDef[22] = new CharDef("chars/data/shop.zsx");
			Game1.charDef[23] = new CharDef("chars/data/samurai.zsx");
			Game1.charDef[24] = new CharDef("chars/data/shark.zsx");
			Game1.charDef[25] = new CharDef("chars/data/squid.zsx");
			Game1.charDef[26] = new CharDef("chars/data/engineer.zsx");
			Game1.charDef[27] = new CharDef("chars/data/puppet.zsx");
			Game1.charDef[28] = new CharDef("chars/data/bigengie.zsx");
			Game1.charDef[29] = new CharDef("chars/data/horse.zsx");
			Game1.charDef[30] = new CharDef("chars/data/midengie.zsx");
			Game1.charDef[31] = new CharDef("chars/data/swordsman.zsx");
			Game1.charDef[32] = new CharDef("chars/data/chef.zsx");
			Game1.charDef[33] = new CharDef("chars/data/raven.zsx");
			Game1.charDef[34] = new CharDef("chars/data/transmara.zsx");
			Game1.charDef[35] = new CharDef("chars/data/hypno.zsx");
			Game1.charDef[36] = new CharDef("chars/data/assassin.zsx");
			DebugPrint("defs read");
			Game1.charMeta[78] = new CharMeta("yukif");
			Game1.charMeta[0] = new CharMeta("yuki");
			Game1.charMeta[2] = new CharMeta("yukik");
			Game1.charMeta[25] = new CharMeta("yukic");
			Game1.charMeta[46] = new CharMeta("yukis");
			Game1.charMeta[1] = new CharMeta("guard");
			Game1.charMeta[3] = new CharMeta("swat");
			Game1.charMeta[4] = new CharMeta("tank");
			Game1.charMeta[6] = new CharMeta("blade");
			Game1.charMeta[7] = new CharMeta("neko");
			Game1.charMeta[8] = new CharMeta("gown_crawl");
			Game1.charMeta[9] = new CharMeta("gown_chair");
			Game1.charMeta[10] = new CharMeta("gown_walk");
			Game1.charMeta[11] = new CharMeta("prison");
			Game1.charMeta[12] = new CharMeta("chaironly");
			Game1.charMeta[13] = new CharMeta("pod");
			Game1.charMeta[40] = new CharMeta("apple2");
			Game1.charMeta[41] = new CharMeta("podbot");
			Game1.charMeta[14] = new CharMeta("ninja");
			Game1.charMeta[17] = new CharMeta("zom");
			Game1.charMeta[18] = new CharMeta("crow");
			Game1.charMeta[19] = new CharMeta("cretin");
			Game1.charMeta[20] = new CharMeta("warden");
			Game1.charMeta[21] = new CharMeta("lich");
			Game1.charMeta[22] = new CharMeta("gown_arm");
			Game1.charMeta[23] = new CharMeta("goreface");
			Game1.charMeta[5] = new CharMeta("dish");
			Game1.charMeta[15] = new CharMeta("dishh");
			Game1.charMeta[16] = new CharMeta("dishc");
			Game1.charMeta[24] = new CharMeta("dishs");
			Game1.charMeta[26] = new CharMeta("disht");
			Game1.charMeta[79] = new CharMeta("maraf");
			Game1.charMeta[37] = new CharMeta("mara");
			Game1.charMeta[38] = new CharMeta("marak");
			Game1.charMeta[39] = new CharMeta("marac");
			Game1.charMeta[76] = new CharMeta("maras");
			Game1.charMeta[27] = new CharMeta("loic");
			Game1.charMeta[28] = new CharMeta("loich");
			Game1.charMeta[29] = new CharMeta("loicc");
			Game1.charMeta[30] = new CharMeta("loics");
			Game1.charMeta[31] = new CharMeta("loict");
			Game1.charMeta[32] = new CharMeta("hargreaves");
			Game1.charMeta[33] = new CharMeta("hargreavesh");
			Game1.charMeta[34] = new CharMeta("hargreavesc");
			Game1.charMeta[35] = new CharMeta("hargreavess");
			Game1.charMeta[36] = new CharMeta("hargreavest");
			Game1.charMeta[42] = new CharMeta("slava");
			Game1.charMeta[43] = new CharMeta("pumpkin");
			Game1.charMeta[44] = new CharMeta("skeletank");
			Game1.charMeta[45] = new CharMeta("banker");
			Game1.charMeta[47] = new CharMeta("force");
			Game1.charMeta[48] = new CharMeta("box");
			Game1.charMeta[49] = new CharMeta("murderfly");
			Game1.charMeta[75] = new CharMeta("murderbug");
			Game1.charMeta[50] = new CharMeta("warclone");
			Game1.charMeta[51] = new CharMeta("pyro");
			Game1.charMeta[52] = new CharMeta("general");
			Game1.charMeta[53] = new CharMeta("goon");
			Game1.charMeta[54] = new CharMeta("freak");
			Game1.charMeta[55] = new CharMeta("hockey");
			Game1.charMeta[56] = new CharMeta("ghost");
			Game1.charMeta[57] = new CharMeta("mook");
			Game1.charMeta[58] = new CharMeta("shark");
			Game1.charMeta[59] = new CharMeta("dragon");
			Game1.charMeta[60] = new CharMeta("dragonclaw");
			Game1.charMeta[61] = new CharMeta("sackboy");
			Game1.charMeta[62] = new CharMeta("invalid");
			Game1.charMeta[63] = new CharMeta("shop");
			Game1.charMeta[64] = new CharMeta("samurai");
			Game1.charMeta[65] = new CharMeta("squid");
			Game1.charMeta[66] = new CharMeta("corpse");
			Game1.charMeta[67] = new CharMeta("judge");
			Game1.charMeta[68] = new CharMeta("engineer");
			Game1.charMeta[69] = new CharMeta("goonpuppet");
			Game1.charMeta[70] = new CharMeta("swatpuppet");
			Game1.charMeta[71] = new CharMeta("bigengie");
			Game1.charMeta[72] = new CharMeta("horse");
			Game1.charMeta[73] = new CharMeta("engie2");
			Game1.charMeta[74] = new CharMeta("midengie");
			Game1.charMeta[77] = new CharMeta("ghoul");
			Game1.charMeta[80] = new CharMeta("swordsman");
			Game1.charMeta[81] = new CharMeta("thug");
			Game1.charMeta[82] = new CharMeta("hackbot");
			Game1.charMeta[83] = new CharMeta("chef");
			Game1.charMeta[84] = new CharMeta("knifeonly");
			Game1.charMeta[85] = new CharMeta("gown_hobble");
			Game1.charMeta[86] = new CharMeta("gown_knife");
			Game1.charMeta[87] = new CharMeta("uslava");
			Game1.charMeta[88] = new CharMeta("raven");
			Game1.charMeta[89] = new CharMeta("transmara");
			Game1.charMeta[90] = new CharMeta("hypno");
			Game1.charMeta[91] = new CharMeta("yukinpc");
			Game1.charMeta[92] = new CharMeta("dish_hatless");
			Game1.charMeta[93] = new CharMeta("dishc_hatless");
			Game1.charMeta[94] = new CharMeta("assassin");
			Game1.charMeta[96] = new CharMeta("violin");
			Game1.charMeta[95] = new CharMeta("guitar");
			Game1.charMeta[97] = new CharMeta("predator");
			Game1.charMeta[98] = new CharMeta("raptor");
			Game1.charMeta[99] = new CharMeta("inmate");
		}
		for (int j = 0; j < Game1.legsTexMeta.Length; j++)
		{
			if (!fat)
			{
				Game1.legsTexMeta[j] = new CharTexture("legs", j, Content, game: true);
			}
			Game1.legsTex[j] = Content.Load<Texture2D>("gfx/chars/legs" + j);
		}
		for (int k = 0; k < Game1.torsoTexMeta.Length; k++)
		{
			if (!fat)
			{
				Game1.torsoTexMeta[k] = new CharTexture("torso", k, Content, game: true);
			}
			Game1.torsoTex[k] = Content.Load<Texture2D>("gfx/chars/torso" + k);
		}
		for (int l = 0; l < Game1.headTexMeta.Length; l++)
		{
			if (!fat)
			{
				Game1.headTexMeta[l] = new CharTexture("head", l, Content, game: true);
			}
			Game1.headTex[l] = Content.Load<Texture2D>("gfx/chars/head" + l);
		}
		for (int m = 0; m < Game1.weaponTexMeta.Length; m++)
		{
			if (!fat)
			{
				Game1.weaponTexMeta[m] = new CharTexture("weapon", m, Content, game: true);
			}
			Game1.weaponTex[m] = Content.Load<Texture2D>("gfx/chars/weapon" + m);
		}
		DebugPrint("character textures loaded");
		Game1.eightBitTex = Content.Load<Texture2D>("gfx/8bit");
		Game1.eightBitGame.eightBitEffect = Content.Load<Effect>("fx/eightbit");
		Game1.colTex = Content.Load<Texture2D>("gfx/col");
		Game1.charBloodStains = new CharBloodStains();
		Game1.charBloodStains.Init(Content);
		Game1.controllerTex = Content.Load<Texture2D>("gfx/controller");
		Game1.hGradTex = Content.Load<Texture2D>("gfx/hgrad");
		Game1.vGradTex = Content.Load<Texture2D>("gfx/vgrad");
		Game1.hatchText = Content.Load<Texture2D>("gfx/hatch");
		Game1.environText = Content.Load<Texture2D>("gfx/environ");
		Game1.bgTex = new Texture2D[4];
		Game1.bgTex[0] = Content.Load<Texture2D>("gfx/maps/bg0");
		Game1.bgTex[1] = Content.Load<Texture2D>("gfx/maps/bg1");
		Game1.bgTex[2] = Content.Load<Texture2D>("gfx/maps/bg2");
		Game1.bgTex[3] = Content.Load<Texture2D>("gfx/maps/bg3");
		Game1.upgradeTex = new Texture2D[4];
		Game1.upgradeTex[0] = Content.Load<Texture2D>("gfx/chars/upgrade0");
		Game1.upgradeTex[1] = Content.Load<Texture2D>("gfx/chars/upgrade1");
		Game1.upgradeTex[2] = Content.Load<Texture2D>("gfx/chars/upgrade2");
		Game1.upgradeTex[3] = Content.Load<Texture2D>("gfx/chars/upgrade3");
		DebugPrint("upgrade textures loaded");
		Game1.waterTex = Content.Load<Texture2D>("gfx/water");
		Game1.itemsTex = Content.Load<Texture2D>("gfx/items");
		Game1.buyTex = Content.Load<Texture2D>("gfx/buy");
		DebugPrint("portraits loaded");
		complete = true;
	}

	public bool LoadMapTextures(Map map)
	{
		bool flag = false;
		for (int i = 0; i < 5; i++)
		{
			Layer layer = map.layer[i];
			for (int j = 0; j < layer.segment.Length; j++)
			{
				Segment segment = layer.segment[j];
				if (segment == null || segment.idx <= -1)
				{
					continue;
				}
				int texIdx = Game1.segDefMgr.segDef[segment.idx].texIdx;
				if (mapsTexLoaded[texIdx] != 2)
				{
					mapsTexLoaded[texIdx] = 1;
					flag = true;
				}
				switch (Game1.segDefMgr.segDef[segment.idx].flags)
				{
				case 25:
				case 26:
				case 27:
				case 28:
				case 29:
				case 30:
				case 31:
				case 32:
				case 33:
				case 34:
					if (mapsTexLoaded[8] != 2)
					{
						mapsTexLoaded[8] = 1;
						flag = true;
					}
					if (mapsTexLoaded[10] != 2)
					{
						mapsTexLoaded[10] = 1;
						flag = true;
					}
					if (mapsTexLoaded[12] != 2)
					{
						mapsTexLoaded[12] = 1;
						flag = true;
					}
					break;
				case 22:
					if (mapsTexLoaded[7] != 2)
					{
						mapsTexLoaded[7] = 1;
						flag = true;
					}
					break;
				case 61:
				case 62:
					if (mapsTexLoaded[16] != 2)
					{
						mapsTexLoaded[16] = 1;
						flag = true;
					}
					break;
				}
			}
		}
		if (flag)
		{
			loadingStuff = true;
			Thread thread = new Thread(LoadMapTextures);
			thread.Start();
		}
		return flag;
	}

	private void LoadMapTextures()
	{
		for (int i = 0; i < mapsTexLoaded.Length; i++)
		{
			int num = mapsTexLoaded[i];
			if (num == 1)
			{
				try
				{
					Game1.mapsTex[i] = Content.Load<Texture2D>("gfx/maps/hires/maps" + (i + 1));
				}
				catch (Exception ex)
				{
					Printf.WriteLine(ex.StackTrace);
				}
				mapsTexLoaded[i] = 2;
			}
		}
		loadingStuff = false;
	}
}
