using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Yuki_Win.sprites.bombs;

internal class Grenade : SpriteDef
{
	public override void Init(Sprite p, Vector2 loc, Vector2 traj, float size, int flags, int owner)
	{
		p.loc = loc;
		p.traj = traj;
		p.frame = 2f;
		p.owner = owner;
		base.Init(p, loc, traj, size, flags, owner);
	}

	public override void Update(Sprite p, SpriteManager spriteMan)
	{
		if (Game1.gameMap.CurMap().TestCol(p.loc))
		{
			p.exists = false;
			spriteMan.MakeExplosion(p.loc - p.traj * 0.05f, p.owner, 5f, splash: true);
		}
		else
		{
			p.traj.Y += FMan.frameTime * 2500f;
			if (p.traj.Y > 2000f)
			{
				p.traj.Y = 2000f;
			}
		}
		base.Update(p, spriteMan);
	}

	public override void Draw(Sprite p, SpriteBatch sprite, Texture2D spritesTex)
	{
		sprite.Draw(spritesTex, ScrollManager.GetScreenLoc(p.loc, 1f), new Rectangle(576, 32, 64, 32), new Color(new Vector4(1f, 1f, 1f, 1f)), p.frame * 2f, new Vector2(32f, 16f), ScrollManager.cannedDepth[0] * 0.4f, SpriteEffects.None, 1f);
	}
}
