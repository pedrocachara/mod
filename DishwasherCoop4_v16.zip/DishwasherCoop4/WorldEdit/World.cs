using System.IO;
using WorldEdit.world;

namespace WorldEdit;

public class World
{
	public string path;

	public Cell[,] cell;

	public int width;

	public int height;

	public string name;

	public string desc;

	public World()
	{
		cell = new Cell[128, 128];
		width = 10;
		height = 10;
		name = "New";
		desc = "New world.";
	}

	public void Read()
	{
		BinaryReader binaryReader = new BinaryReader(File.Open(path, FileMode.Open, FileAccess.Read));
		name = binaryReader.ReadString();
		desc = binaryReader.ReadString();
		width = binaryReader.ReadInt32();
		height = binaryReader.ReadInt32();
		for (int i = 0; i < 128; i++)
		{
			for (int j = 0; j < 128; j++)
			{
				cell[i, j] = null;
			}
		}
		for (int k = 0; k < width; k++)
		{
			for (int l = 0; l < height; l++)
			{
				if (binaryReader.ReadBoolean())
				{
					cell[k, l] = new Cell(binaryReader);
				}
			}
		}
		binaryReader.Close();
	}

	public void Write()
	{
		BinaryWriter binaryWriter = new BinaryWriter(File.Open(path, FileMode.OpenOrCreate, FileAccess.Write));
		binaryWriter.Write(name);
		binaryWriter.Write(desc);
		binaryWriter.Write(width);
		binaryWriter.Write(height);
		for (int i = 0; i < width; i++)
		{
			for (int j = 0; j < height; j++)
			{
				if (cell[i, j] == null)
				{
					binaryWriter.Write(value: false);
				}
				else
				{
					cell[i, j].Write(binaryWriter);
				}
			}
		}
		binaryWriter.Close();
	}

	public string GetPath(int x, int y)
	{
		if (x < 0 || y < 0 || x >= width || y >= height)
		{
			return "";
		}
		if (cell[x, y] != null)
		{
			if (cell[x, y].orig)
			{
				return cell[x, y].path;
			}
			return cell[cell[x, y].origX, cell[x, y].origY].path;
		}
		return "";
	}

	public int GetOrigX(int x, int y)
	{
		if (cell[x, y].orig)
		{
			return x;
		}
		return cell[x, y].origX;
	}

	public int GetOrigY(int x, int y)
	{
		if (cell[x, y].orig)
		{
			return y;
		}
		return cell[x, y].origY;
	}
}
