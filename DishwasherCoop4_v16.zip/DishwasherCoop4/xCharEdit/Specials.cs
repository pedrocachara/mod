namespace xCharEdit;

public class Specials
{
	public const int MACHINE_NONE = 0;

	public const int MACHINE_SAW = 1;

	public const int MACHINE_GUN = 2;

	public const int MACHINE_DEFAULT = 3;

	public const int MELEE_NONE = 0;

	public const int MELEE_KATANA = 1;

	public const int MELEE_KAMA = 2;

	public const int MELEE_CLOUD = 3;

	public const int MELEE_OTHER = 4;

	public const int MELEE_FISTS = 5;

	public static string[] machine = new string[4] { "no machine", "machine saw", "machine gun", "machine default" };

	public static string[] melee = new string[3] { "no melee", "melee katana", "melee kama" };
}
