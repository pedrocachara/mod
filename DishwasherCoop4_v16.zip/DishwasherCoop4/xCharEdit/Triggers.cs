namespace xCharEdit;

public class Triggers
{
	public const int TRIGGER_LIGHT_SLASH = 0;

	public const int TRIGGER_MEDIUM_SLASH = 1;

	public const int TRIGGER_SLASH_UPPERCUT = 2;

	public const int TRIGGER_SLASH_SLAM = 3;

	public const int TRIGGER_STRONG_SLASH = 4;

	public const int TRIGGER_PUNCH = 5;

	public const int TRIGGER_KICK = 6;

	public const int TRIGGER_BLOOD_SPRAY = 7;

	public const int TRIGGER_BLOOD_MIST = 8;

	public const int TRIGGER_SAW_DIG = 9;

	public const int TRIGGER_SAW_SMOKE = 10;

	public const int TRIGGER_GRAB = 11;

	public const int TRIGGER_HEAD = 12;

	public const int TRIGGER_TOPHALF = 13;

	public const int TRIGGER_BOTTOMHALF = 14;

	public const int TRIGGER_BLOOD_ARC = 15;

	public const int TRIGGER_SAW_KILL_GRAB = 16;

	public const int TRIGGER_VULCAN_BULLET = 17;

	public const int TRIGGER_SAW_SPLIT_BIT = 18;

	public const int TRIGGER_SAW_SPLITTER = 19;

	public const int TRIGGER_SAW_SPLIT_DIG = 20;

	public const int TRIGGER_PUNCH_UPPER = 21;

	public const int TRIGGER_KAMGRAB = 22;

	public const int TRIGGER_CHAINUPPER = 23;

	public const int TRIGGER_QUAKE = 24;

	public const int TRIGGER_SAW_KILL_GRAB2 = 25;

	public const int TRIGGER_SPLIT_LEGS = 26;

	public const int TRIGGER_L_ARM = 27;

	public const int TRIGGER_R_ARM = 28;

	public const int TRIGGER_GRAPPLESHOT = 29;

	public const int TRIGGER_GRAPPLELINE = 30;

	public const int TRIGGER_PISTOL = 31;

	public const int TRIGGER_GRENADE = 32;

	public const int TRIGGER_SMG = 33;

	public const int TRIGGER_HOMER = 34;

	public const int TRIGGER_ROCKET = 35;

	public const int TRIGGER_EXPLODE_TINY = 36;

	public const int TRIGGER_EXPLODE_SMALL = 37;

	public const int TRIGGER_EXPLODE_MED = 38;

	public const int TRIGGER_EXPLODE_LARGE = 39;

	public const int TRIGGER_STOMP = 40;

	public const int TRIGGER_SLASH_BIT = 41;

	public const int TRIGGER_SLASH_END = 42;

	public const int TRIGGER_SPARKS = 43;

	public const int TRIGGER_BLOODSTREAM = 44;

	public const int TRIGGER_SPINBODY = 45;

	public const int TRIGGER_SILEN = 46;

	public const int TRIGGER_DISH_BLADEGRAB = 47;

	public const int TRIGGER_DISH_KAMAGRAB = 48;

	public const int TRIGGER_DISH_SCISSOR = 49;

	public const int TRIGGER_DISH_HAMMERGRAB = 50;

	public const int TRIGGER_DISH_TOASTERGRAB = 51;

	public const int TRIGGER_HAMMERSWING = 52;

	public const int TRIGGER_HAMMERSMASH = 53;

	public const int TRIGGER_HAMMERUPPER = 54;

	public const int TRIGGER_PUKE = 55;

	public const int TRIGGER_BRASS = 56;

	public const int TRIGGER_SHELL = 57;

	public const int TRIGGER_UZI_MAG = 58;

	public const int TRIGGER_DRUM_MAG = 59;

	public const int TRIGGER_SHOTTY = 60;

	public const int TRIGGER_UZI = 61;

	public const int TRIGGER_SLASH_SMACKDOWN = 62;

	public const int TRIGGER_MINIJET = 63;

	public const int TRIGGER_WARDEN_GRAB = 64;

	public const int TRIGGER_ZGRAB = 65;

	public const int TRIGGER_LICHGRAB = 66;

	public const int TRIGGER_MEGASLASHUPPER = 67;

	public const int TRIGGER_SAWUPPER = 68;

	public const int TRIGGER_HAMMERKICK = 69;

	public const int TRIGGER_ZOMBIE_HEAD = 70;

	public const int TRIGGER_ZOMBIE_ARM = 71;

	public const int TRIGGER_SPAWN_ZOMBIE = 72;

	public const int TRIGGER_BLOODSPLOSION = 73;

	public const int TRIGGER_CLOUDGRAB = 74;

	public const int TRIGGER_SPAWN_APPLE2 = 75;

	public const int TRIGGER_EXPLODE_MIST = 76;

	public const int TRIGGER_SLAM_GRAB = 77;

	public const int TRIGGER_KICK_SMACKDOWN = 78;

	public const int TRIGGER_PUNCH_UP = 79;

	public const int TRIGGER_SAW_THROW = 80;

	public const int TRIGGER_SHOTTY_THROW = 81;

	public const int TRIGGER_SLAVA_GRAB = 82;

	public const int TRIGGER_SPLIT_TORSO = 83;

	public const int TRIGGER_SLASH_SUPPER = 84;

	public const int TRIGGER_WEAP_SQUIRT = 85;

	public const int TRIGGER_FLAME_SPRAY = 86;

	public const int TRIGGER_NULLFLAME_SPRAY = 87;

	public const int TRIGGER_HAMMERSTUFF = 88;

	public const int TRIGGER_STAB = 89;

	public const int TRIGGER_MEGASTAB = 90;

	public const int TRIGGER_STAB_SPLITTER = 91;

	public const int TRIGGER_STAB_UPPER = 92;

	public const int TRIGGER_SYRINGE_GRAB = 93;

	public const int TRIGGER_STAB_SLAM = 94;

	public const int TRIGGER_CONFETTI = 95;

	public const int TRIGGER_HOCKEY_ICE = 96;

	public const int TRIGGER_HOCKEY_BIG_ICE = 97;

	public const int TRIGGER_HOCKEY_GRENADE = 98;

	public const int TRIGGER_BLADE_FARM = 99;

	public const int TRIGGER_SCYTHE = 100;

	public const int TRIGGER_FREAKOUT = 101;

	public const int TRIGGER_DRAGON_BITE = 102;

	public const int TRIGGER_DRAGON_WING = 103;

	public const int TRIGGER_MAGIC = 104;

	public const int TRIGGER_SHOP_MAGIC = 105;

	public const int TRIGGER_MINIGORESPLODE = 106;

	public const int TRIGGER_SPAWNENGIE = 107;

	public const int TRIGGER_PUPPETGRAB = 108;

	public const int TRIGGER_DEGRABLOC = 109;

	public const int TRIGGER_GRABBEDLOC = 110;

	public const int TRIGGER_PUPPETLOC = 111;

	public const int TRIGGER_QUIETROCKET = 112;

	public const int TRIGGER_ELEC_SRC = 113;

	public const int TRIGGER_ELECBALL = 114;

	public const int TRIGGER_ELECTWAVE = 115;

	public const int TRIGGER_ELECSMASH = 116;

	public const int TRIGGER_DUMMYGRAB = 117;

	public const int TRIGGER_SQUIRTGUN = 118;

	public const int TRIGGER_LIGHT_TOAST = 119;

	public const int TRIGGER_HEAVY_TOAST = 120;

	public const int TRIGGER_UPPER_TOAST = 121;

	public const int TRIGGER_DAGGER = 122;

	public const int TRIGGER_CLAW_GRAB = 123;

	public const int TRIGGER_KAMIKAZE = 124;

	public const int TRIGGER_BLADE_SCRAPE = 125;

	public const int TRIGGER_CHEF_GRAB = 126;

	public const int TRIGGER_SLASH_BIT_NOMOV = 127;

	public const int TRIGGER_MARA_CHOP = 128;

	public const int TRIGGER_HYPNOSTAB = 129;

	public const int TRIGGER_SPAWNHACK = 130;

	public const int TRIGGER_CHOW = 131;

	public const int TRIGGER_PETPUKE = 132;

	public const int TRIGGER_DIRTWALK = 133;

	public const int TRIGGER_STAB_EXER_BIT = 134;

	public const int TRIGGER_SLASH_SCISSORSLAM = 135;

	public static string[] names = new string[136]
	{
		"light slash", "medium slash", "slash uppercut", "slash slam", "strong slash", "punch", "kick", "blood spray", "blood mist", "saw dig",
		"saw smoke", "grab", "head", "top half", "bottom half", "blood arc", "saw kill grab", "vulcan bullet", "saw split bit", "saw splitter",
		"saw split dig", "punch upper", "kam grab", "chain upper", "quake", "saw kill grab2", "split legs", "l arm", "r arm", "grappleshot",
		"grappleline", "pistol", "grenade", "smg", "homer", "rocket", "explode tiny", "explode small", "explode mid", "explode large",
		"stomp", "slash bit", "slash end", "sparks", "bloodstream", "spinbody", "silen", "dish blade grab", "dish kama grab", "dish scissor grab",
		"dish hammer grab", "dish toaster grab", "hammer swing", "hammer smash", "hammer upper", "puke", "brass", "shell", "uzi mag", "drum mag",
		"shotty", "uzi", "slash smackdown", "miniblood", "warden grab", "zgrab", "lich grab", "mega slash upper", "chain upper", "hammer kick",
		"zombie head", "zombie arm", "spawn zombie", "bloodsplosion", "cloud grab", "spawn apple2", "explode mist", "slam grab", "kick smackdown", "punch up",
		"saw throw", "shotty throw", "slava grab", "split torso", "slash supper", "weap squirt", "flame spray", "nullflame spray", "hammerstuff", "stab",
		"megastab", "stab splitter", "stab upper", "syringe grab", "stab slam", "confetti", "hockey ice", "hockey big ice", "hockey grenade", "blade farm",
		"scythe", "freakout", "dragon bite", "dragon wing", "MAGIC", "shopmagic", "minigoresplode", "spawn engie", "puppet grab", "degrabloc",
		"grabbed loc", "puppetloc", "quietrocket", "elec src", "elec ball", "elec wave", "elec smash", "dummy grab", "squirt gun", "light toast",
		"heavy toast", "upper toast", "dagger", "claw grab", "kamikaze", "blade scrape", "chef grab", "slash bit nomov", "mara chop", "hypnostab",
		"spawnhack", "chow", "petpuke", "dirtwalk", "stab exer bit", "slash scissorslam"
	};
}
