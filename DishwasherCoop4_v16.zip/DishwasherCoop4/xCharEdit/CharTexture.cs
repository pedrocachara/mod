using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace xCharEdit;

public class CharTexture
{
	public int xSize;

	public int ySize;

	public int cols;

	public string[] rowName;

	public string textureName;

	public Texture2D tex;

	public Rectangle GetRect(int idx)
	{
		return new Rectangle(idx % cols * xSize, idx / cols * ySize, xSize, ySize);
	}

	public string GetLineName(int idx)
	{
		int num = idx / cols;
		if (num < rowName.Length && rowName[num] != null)
		{
			return rowName[num] + idx;
		}
		return "";
	}

	public CharTexture(string file, int idx, ContentManager Content)
	{
		Init(file, idx, Content, game: false);
	}

	public CharTexture(string file, int idx, ContentManager Content, bool game)
	{
		Init(file, idx, Content, game);
	}

	public CharTexture(BinaryReader reader)
	{
		Init(reader);
	}

	public void Init(BinaryReader reader)
	{
		xSize = reader.ReadInt32();
		ySize = reader.ReadInt32();
		cols = reader.ReadInt32();
	}

	public void Init(string file, int idx, ContentManager Content, bool game)
	{
		rowName = new string[16];
		StreamReader streamReader = ((!game) ? new StreamReader("meta/" + file + idx + ".zdx") : new StreamReader("chars/textureMeta/" + file + idx + ".zdx"));
		textureName = streamReader.ReadLine();
		xSize = Convert.ToInt32(streamReader.ReadLine());
		ySize = Convert.ToInt32(streamReader.ReadLine());
		cols = Convert.ToInt32(streamReader.ReadLine());
		rowName = new string[16];
		int num = 0;
		while (!streamReader.EndOfStream)
		{
			rowName[num] = streamReader.ReadLine();
			num++;
			if (num > rowName.Length - 1)
			{
				break;
			}
		}
		streamReader.Close();
		if (!game)
		{
			tex = Content.Load<Texture2D>("gfx/chars/" + file + idx);
		}
	}
}
