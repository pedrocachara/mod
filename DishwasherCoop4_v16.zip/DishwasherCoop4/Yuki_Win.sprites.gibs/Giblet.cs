using Microsoft.Xna.Framework;

namespace Yuki_Win.sprites.gibs;

public class Giblet
{
	public Vector2 loc;

	public Vector2 traj;

	public float frame;

	public float rotation;

	public void Snap(Vector2 loc, Vector2 traj)
	{
		this.loc = loc;
		this.traj = traj;
		frame = 0.8f;
		rotation = -1f;
	}

	internal void Update(float y, int owner, Vector2 next)
	{
		Update(y, owner, 1f, next);
	}

	internal void Update(float y, int owner, float frameFac, Vector2 next)
	{
		frame -= FMan.AdjustedFrame(owner) * frameFac;
		if (frame > 0.4f)
		{
			loc += traj * FMan.AdjustedFrame(owner) * 1.4f;
		}
		else
		{
			loc += traj * FMan.AdjustedFrame(owner) * 0.2f;
		}
		traj.Y += FMan.AdjustedFrame(owner) * y;
		if (next.X > -1000f)
		{
			rotation = Trig.GetAngle(loc, next);
		}
	}

	public Giblet()
	{
		frame = -1f;
	}
}
