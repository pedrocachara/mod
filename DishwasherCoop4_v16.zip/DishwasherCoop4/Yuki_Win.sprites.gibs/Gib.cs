using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using xCharEdit.Character;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.director;
using Yuki_Win.gameRender;
using Yuki_Win.maps;
using Yuki_Win.player;
using Yuki_Win.sprites.goreInstance;

namespace Yuki_Win.sprites.gibs;

public class Gib
{
	public const int GIBTYPE_HEAD = 0;

	public const int GIBTYPE_TORSO = 1;

	public const int GIBTYPE_LEGS = 2;

	public const int GIBTYPE_BODY = 3;

	public const int GIBTYPE_NULL = 4;

	public const int GIBTYPE_SMOKE = 5;

	public const int GIBTYPE_DARKSMOKE = 6;

	public bool exists;

	public int type;

	public Vector2 loc;

	public Vector2 traj;

	public Vector2 scaling;

	public float rotation;

	public float frame;

	public float size;

	public float r;

	public float g;

	public float b;

	public bool alpha;

	public bool thresh;

	public int flags;

	public int owner = -1;

	public bool hitter;

	private int headTex;

	private int torsoTex;

	private int legsTex;

	private int weaponTex;

	private int charDef;

	private int flyAnim;

	private int landAnim;

	private float animFrame;

	private int anim;

	private int key;

	private int face;

	private Map map;

	public bool grounded;

	private bool wallFree;

	private bool noAnim;

	private bool isRobot;

	private bool isCyborg;

	private Giblet[] giblet;

	private Giblet[] riblet;

	private int gibletCount;

	private int curGiblet;

	public bool gooey;

	public bool isDragon;

	public bool isMask;

	public int hitOwner;

	private float hitGrace;

	public int ID;

	public int gibType;

	public Gib(int ID)
	{
		exists = false;
		giblet = new Giblet[16];
		for (int i = 0; i < giblet.Length; i++)
		{
			giblet[i] = new Giblet();
		}
		riblet = new Giblet[16];
		for (int j = 0; j < riblet.Length; j++)
		{
			riblet[j] = new Giblet();
		}
		this.ID = ID;
	}

	public void Reset()
	{
		key = 0;
		anim = 0;
		animFrame = 0f;
		isRobot = false;
	}

	public GoreInstance.GibInstance GetInstance()
	{
		GoreInstance.GibInstance result = default;
		result.charDef = charDef;
		result.face = face;
		result.headTex = headTex;
		result.key = key;
		result.landAnim = landAnim;
		result.legsTex = legsTex;
		result.loc = loc;
		result.owner = owner;
		result.size = size;
		result.torsoTex = torsoTex;
		result.weaponTex = weaponTex;
		return result;
	}

	public void SetFromInstance(GoreInstance.GibInstance g, Map map)
	{
		Init(g.loc, g.face, g.headTex, g.torsoTex, g.legsTex, g.weaponTex, g.charDef, Game1.charDef[g.charDef].GetAnimation(g.landAnim).name, g.key, g.size, map, g.owner);
	}

	public void Init(Vector2 loc, Vector2 traj, int face, int headTex, int torsoTex, int legsTex, int weaponTex, int charDef, string flyAnim, string landAnim, float size, Map map, int gibType, int sparks, int owner, int hitOwner)
	{
		Reset();
		this.hitOwner = hitOwner;
		this.loc = loc;
		this.traj = traj;
		this.size = size;
		this.face = face;
		this.map = map;
		isDragon = false;
		isMask = false;
		wallFree = false;
		this.owner = owner;
		this.gibType = gibType;
		isRobot = false;
		isCyborg = false;
		switch (sparks)
		{
		case 2:
			isRobot = true;
			break;
		case 1:
			isCyborg = true;
			break;
		}
		this.headTex = headTex;
		this.legsTex = legsTex;
		this.weaponTex = weaponTex;
		this.torsoTex = torsoTex;
		hitGrace = 0.05f;
		this.charDef = charDef;
		noAnim = false;
		if (gibType == 4 || gibType == 5 || gibType == 6)
		{
			noAnim = true;
		}
		else
		{
			Animation[] animationArray = Game1.charDef[this.charDef].GetAnimationArray();
			for (int i = 0; i < animationArray.Length; i++)
			{
				if (animationArray[i] != null)
				{
					if (animationArray[i].name == flyAnim)
					{
						this.flyAnim = i;
					}
					if (animationArray[i].name == landAnim)
					{
						this.landAnim = i;
					}
				}
			}
		}
		grounded = false;
		anim = this.flyAnim;
		frame = 60f;
		exists = true;
		gibletCount = 0;
		AddGiblet();
		gooey = true;
	}

	private void AddGiblet()
	{
		if (!isRobot)
		{
			Vector2 vector = loc;
			Vector2 randomVec = Rand.GetRandomVec2(-60f, 60f, -60f, 60f);
			switch (gibType)
			{
			default:
				randomVec *= 2f;
				break;
			case 4:
			case 6:
				break;
			}
			switch (gibType)
			{
			case 0:
				vector += new Vector2(0f, -21f);
				break;
			case 5:
			case 6:
				randomVec += Rand.GetRandomVec2(-300f, -100f, -100f, 0f);
				break;
			default:
				vector += new Vector2(0f, -30f);
				break;
			}
			switch (gibType)
			{
			case 0:
			case 1:
			case 2:
			case 3:
				Game1.spriteMan.AddSprite(8, loc, randomVec * 0.1f, 1f, -1, owner);
				break;
			}
			curGiblet = (curGiblet + 1) % giblet.Length;
			giblet[curGiblet].Snap(vector, randomVec);
			riblet[curGiblet].Snap(vector, Rand.GetRandomVec2(-260f, 260f, -60f, 60f));
			if (gibletCount < giblet.Length)
			{
				gibletCount++;
			}
		}
	}

	public void Init(Vector2 loc, int face, int headTex, int torsoTex, int legsTex, int weaponTex, int charDef, string landAnim, int key, float size, Map map, int owner)
	{
		Reset();
		gibletCount = 0;
		this.loc = loc;
		this.size = size;
		this.face = face;
		this.map = map;
		this.key = key;
		gibType = 3;
		isDragon = false;
		isMask = false;
		this.owner = owner;
		this.headTex = headTex;
		this.legsTex = legsTex;
		this.weaponTex = weaponTex;
		this.torsoTex = torsoTex;
		this.charDef = charDef;
		wallFree = false;
		Animation[] animationArray = Game1.charDef[this.charDef].GetAnimationArray();
		for (int i = 0; i < animationArray.Length; i++)
		{
			if (animationArray[i] != null && animationArray[i].name == landAnim)
			{
				this.landAnim = i;
			}
		}
		grounded = true;
		anim = this.landAnim;
		noAnim = true;
		frame = 60f;
		exists = true;
	}

	public void Update(SpriteManager spriteMan)
	{
		if (loc.X < 0f || loc.Y < 0f || loc.X > (float)Game1.gameMap.CurMap().xSize * 64f || loc.Y > (float)Game1.gameMap.CurMap().ySize * 64f)
		{
			exists = false;
		}
		if (!grounded)
		{
			traj.Y += FMan.AdjustedFrame(owner) * 1200f;
			if (hitGrace > 0f)
			{
				hitGrace -= FMan.frameTime;
			}
			else if (hitOwner > -1 && hitOwner < 4)
			{
				switch (gibType)
				{
				case 0:
				case 1:
				case 2:
				case 3:
					spriteMan.AddSprite(98, loc, traj, 0f, ID, hitOwner);
					break;
				}
			}
			if (wallFree)
			{
				Vector2 vector = loc;
				loc.X += traj.X * FMan.AdjustedFrame(owner);
				if (map.TestCol(loc))
				{
					loc = vector;
					traj.X *= 0f - Rand.GetRandomFloat(0.1f, 0.9f);
				}
				vector = loc;
				loc.Y += traj.Y * FMan.AdjustedFrame(owner);
				if (isMask)
				{
					FMan.Slow(0.1f);
					if (owner > -1 && owner < 2 && Game1.character[owner].charUpdate.slow > 0f)
					{
						Game1.character[owner].charUpdate.slow = 0f;
					}
				}
				if (map.TestCol(loc))
				{
					if (traj.Y > 0f)
					{
						if (traj.Y > 1000f)
						{
							if (gibType != 4 && gibType != 5 && gibType != 6)
							{
								Sound.PlaySnd(Sound.Category.FX, "wetdrop");
							}
							traj.Y = -500f;
							loc.Y = vector.Y;
							WallSplat(isRobot, loc + new Vector2(0f, -21f), spriteMan);
						}
						else
						{
							grounded = true;
							loc.Y = map.GetMinY(loc);
							anim = landAnim;
							key = 0;
							animFrame = 0f;
							if (isDragon)
							{
								QuakeManager.SetQuake(0.5f);
								FMan.Slow(0.01f);
								Sound.PlaySnd(Sound.Category.FX, "bass");
								Sound.PlaySnd(Sound.Category.FX, "crush");
								Sound.PlaySnd(Sound.Category.FX, "crunch");
								for (int i = 0; i < 5; i++)
								{
									spriteMan.AddSprite(18, loc + Rand.GetRandomVec2(-100f, 100f, 0f, 0f), Rand.GetRandomVec2(-50f, 50f, -100f, 0f), Rand.GetRandomFloat(1f, 2f), 0, 0);
								}
							}
							if (isRobot)
							{
								exists = false;
								spriteMan.MakeExplosion(loc, owner, 1f, splash: false);
							}
							else if (gibType != 4 && gibType != 5 && gibType != 6)
							{
								Sound.PlaySnd(Sound.Category.FX, "wetdrop");
							}
							if (Game1.gameMap.beadTheme == GameMap.BeadTheme.ThreeDee)
							{
								exists = false;
							}
						}
					}
					else
					{
						loc = vector;
						traj.Y = 0f;
					}
				}
			}
			else
			{
				loc.X += traj.X * FMan.AdjustedFrame(owner);
				loc.Y += traj.Y * FMan.AdjustedFrame(owner);
				if (!map.TestCol(loc))
				{
					wallFree = true;
				}
			}
		}
		else
		{
			if ((gibType == 5 || gibType == 6) && gibletCount <= 0)
			{
				exists = false;
			}
			if (!Game1.gameMap.CurMap().TestCol(loc + new Vector2(0f, 24f), ceils: false, shadow: false, ledge: true))
			{
				exists = false;
			}
			if (Game1.gameMap.goryoAlpha > 0f)
			{
				exists = false;
			}
		}
		float num = frame;
		frame -= FMan.AdjustedFrame(owner);
		if (frame > 10f && frame < 20f)
		{
			frame = 30f;
		}
		if (!grounded && isCyborg && (int)(num * 20f) != (int)(frame * 20f))
		{
			spriteMan.AddSprite(0, loc, Rand.GetRandomVec2(-400f, 400f, -400f, 400f), 1f, 0, owner);
		}
		int num2 = 3;
		if (spriteMan.totalSprites > 300)
		{
			num2 = 2;
		}
		if (spriteMan.totalSprites > 600)
		{
			num2 = 1;
		}
		if (spriteMan.totalSprites > 900)
		{
			num2 = (Rand.CointToss(0.5f) ? 1 : 0);
		}
		if (spriteMan.totalSprites > 1200)
		{
			num2 = (Rand.CointToss(0.25f) ? 1 : 0);
		}
		if (gibletCount > 0)
		{
			for (int j = 0; j < giblet.Length; j++)
			{
				if (giblet[j].frame > 0f)
				{
					giblet[j].Update((gibType == 5 || gibType == 6) ? (-300f) : 700f, owner, 1.5f, GetNext(giblet, j));
				}
				if (riblet[j].frame > 0f)
				{
					riblet[j].Update((gibType == 5 || gibType == 6) ? (-300f) : 700f, owner, 1.5f, GetNextRiblet(riblet, j));
				}
			}
		}
		if (isDragon && (int)(frame * 20f) != (int)(num * 20f))
		{
			spriteMan.AddSprite(43, loc + Rand.GetRandomVec2(-20f, 20f, -20f, 20f), Rand.GetRandomVec2(-50f, 50f, -50f, 50f), Rand.GetRandomFloat(1f, 2f), 0, 0);
		}
		if (gibType == 4 && frame < 56f)
		{
			exists = false;
		}
		if (!grounded && num2 > 0)
		{
			switch (gibType)
			{
			case 5:
			case 6:
				if ((int)(num * 6f) != (int)(frame * 6f) && (gibType != 4 || frame > 58f))
				{
					AddGiblet();
				}
				break;
			default:
				if ((int)(num * 10f) != (int)(frame * 10f) && (gibType != 4 || frame > 58f))
				{
					AddGiblet();
				}
				break;
			}
			switch (gibType)
			{
			default:
				if ((int)(num * 30f) != (int)(frame * 30f) && (isRobot || Rand.CointToss(0.1f)))
				{
					switch (gibType)
					{
					case 0:
						WallSplat(isRobot, loc + new Vector2(0f, -21f), spriteMan);
						break;
					case 1:
						WallSplat(isRobot, loc + new Vector2(0f, -30f), spriteMan);
						break;
					case 2:
						WallSplat(isRobot, loc + new Vector2(0f, -30f), spriteMan);
						break;
					}
				}
				break;
			case 5:
			case 6:
				break;
			}
		}
		if (!noAnim)
		{
			animFrame += FMan.AdjustedFrame(owner) * 30f;
			Animation animation = Game1.charDef[charDef].GetAnimation(anim);
			if (animation == null)
			{
				return;
			}
			KeyFrame[] keyFrameArray = animation.getKeyFrameArray();
			if (key < 0)
			{
				key = 0;
			}
			if (animFrame > (float)keyFrameArray[key].duration)
			{
				key++;
				animFrame = 0f;
				if (keyFrameArray[key] == null)
				{
					if (anim == landAnim)
					{
						key--;
						if (isDragon)
						{
							isDragon = false;
						}
						if (isMask)
						{
							Game1.gameMap.CurMap().scriptMgr.SetFlag("mask");
							if (Game1.gameMap.CurMap().scriptMgr.wait > 0f)
							{
								Game1.gameMap.CurMap().scriptMgr.wait = 0f;
							}
						}
					}
					else
					{
						key = 0;
					}
				}
			}
		}
		if (frame < 0f)
		{
			exists = false;
		}
	}

	private Vector2 GetNext(Giblet[] giblet, int i)
	{
		if (i == curGiblet)
		{
			return loc;
		}
		return giblet[(i + 1) % giblet.Length].loc;
	}

	private Vector2 GetNextRiblet(Giblet[] riblet, int i)
	{
		if (i == curGiblet)
		{
			return loc;
		}
		return riblet[(i + 1) % riblet.Length].loc;
	}

	private void WallSplat(bool isRobot, Vector2 loc, SpriteManager spriteMan)
	{
		if (!isRobot)
		{
			spriteMan.AddWallblood(loc);
		}
	}

	public void DrawAlphaTrail(SpriteBatch sprite, Texture2D spritesTex)
	{
		if (gibletCount <= 0 || gibType == 5 || gibType == 6 || isRobot)
		{
			return;
		}
		int num = curGiblet;
		Vector2 vector = loc;
		if (gibType == 0)
		{
			vector += new Vector2(0f, -21f);
		}
		else
		{
			vector += new Vector2(0f, -30f);
		}
		Vector2 vector2 = ScrollManager.GetScreenLoc(vector, 1f);
		Vector2 vector3 = vector2;
		int num2 = 0;
		float num3 = 0.5f;
		if (gibType == 4)
		{
			num3 = 0.2f;
		}
		for (int i = 0; i < gibletCount; i++)
		{
			if (!(giblet[num].frame > 0f))
			{
				break;
			}
			num2++;
			vector3 = ScrollManager.GetScreenLoc(giblet[num].loc, 1f);
			sprite.Draw(spritesTex, (vector2 + vector3) / 2f, new Rectangle(num % 4 * 128, 960, 128, 64), new Color(0.1f, 0f, 0f, giblet[num].frame * 6f), giblet[num].rotation, new Vector2(64f, 32f), new Vector2((vector2 - vector3).Length() / 120f, num3 * ScrollManager.cannedDepth[0] * 1.5f), SpriteEffects.None, 1f);
			num = (num + (giblet.Length - 1)) % giblet.Length;
			vector2 = vector3;
		}
		if (num2 == 0)
		{
			gibletCount = 0;
		}
	}

	public void DrawSubTrail(SpriteBatch sprite, Texture2D spritesTex)
	{
		if (gibletCount <= 0 || gibType == 5 || gibType == 6 || isRobot)
		{
			return;
		}
		int num = curGiblet;
		Vector2 vector = loc;
		if (gibType == 0)
		{
			vector += new Vector2(0f, -21f);
		}
		else
		{
			vector += new Vector2(0f, -30f);
		}
		Vector2 vector2 = ScrollManager.GetScreenLoc(vector, 1f);
		Vector2 vector3 = vector2;
		int num2 = 0;
		float num3 = 0.5f;
		if (gibType == 4)
		{
			num3 = 0.2f;
		}
		for (int i = 0; i < gibletCount; i++)
		{
			if (!(riblet[num].frame > 0f))
			{
				break;
			}
			num2++;
			vector3 = ScrollManager.GetScreenLoc(riblet[num].loc, 1f);
			sprite.Draw(spritesTex, (vector2 + vector3) / 2f, new Rectangle(num % 4 * 128, 960, 128, 64), new Color(0f, 1f, 1f, riblet[num].frame * 10f), riblet[num].rotation, new Vector2(64f, 32f), new Vector2((vector2 - vector3).Length() / 120f, num3 * ScrollManager.cannedDepth[0] * 1.5f), SpriteEffects.None, 1f);
			num = (num + (riblet.Length - 1)) % riblet.Length;
			vector2 = vector3;
		}
		if (num2 == 0)
		{
			gibletCount = 0;
		}
	}

	public void DrawTrail(SpriteBatch sprite, Texture2D spritesTex)
	{
		if (!gooey || gibletCount <= 0 || gibType == 5 || gibType == 6 || isRobot || isMask)
		{
			return;
		}
		int num = curGiblet;
		Vector2 vector = loc;
		if (gibType == 0)
		{
			vector += new Vector2(0f, -21f);
		}
		else
		{
			vector += new Vector2(0f, -30f);
		}
		Vector2 vector2 = ScrollManager.GetScreenLoc(vector, 1f);
		Vector2 vector3 = vector2;
		int num2 = 0;
		float num3 = 0.5f;
		if (gibType == 4)
		{
			num3 = 0.2f;
		}
		float num4 = 1f;
		num3 *= 1.5f;
		for (int i = 0; i < gibletCount; i++)
		{
			if (!(giblet[num].frame > 0f))
			{
				break;
			}
			num2++;
			vector3 = ScrollManager.GetScreenLoc(giblet[num].loc, 1f);
			GameRender.threshRender.AddPoint(vector3, 10f);
			if (GameSettings.difficulty == 0)
			{
				sprite.Draw(Game1.spritesTex, (vector2 + vector3) / (num4 * 2f), new Rectangle(1025, 961 - num % 3 * 32, 62, 30), new Color(1f, 1f, 1f, giblet[num].frame * 0.8f), giblet[num].rotation, new Vector2(31f, 15f), new Vector2((vector2 - vector3).Length() / 50f, num3 * ScrollManager.cannedDepth[0]) / num4, SpriteEffects.None, 1f);
			}
			else if (Game1.gameMap.goryoAlpha > 0f)
			{
				sprite.Draw(Game1.spritesTex, (vector2 + vector3) / (num4 * 2f), new Rectangle(512, 960, 128, 64), new Color(1f, 1f, 1f, giblet[num].frame * 0.8f), giblet[num].rotation, new Vector2(64f, 32f), new Vector2((vector2 - vector3).Length() / 110f, num3 * ScrollManager.cannedDepth[0] * 0.85f) / num4, SpriteEffects.None, 1f);
			}
			else
			{
				sprite.Draw(spritesTex, (vector2 + vector3) / (num4 * 2f), new Rectangle(num % 4 * 96, 960, 96, 64), new Color(0.5f, 0f, 0f, giblet[num].frame * ((gibType == 4) ? 1f : 1f)), giblet[num].rotation, new Vector2(48f, 32f), new Vector2((vector2 - vector3).Length() / 80f, num3 * ScrollManager.cannedDepth[0]) / num4, SpriteEffects.None, 1f);
			}
			num = (num + (giblet.Length - 1)) % giblet.Length;
			vector2 = vector3;
		}
		if (num2 == 0)
		{
			gibletCount = 0;
		}
	}

	public void DrawSmokeTrail(SpriteBatch sprite, Texture2D spritesTex)
	{
		if (gibletCount <= 0)
		{
			return;
		}
		int num = curGiblet;
		Vector2 vector = loc;
		Vector2 vector2 = ScrollManager.GetScreenLoc(vector, 1f);
		Vector2 vector3 = vector2;
		int num2 = 0;
		for (int i = 0; i < gibletCount; i++)
		{
			if (!(giblet[num].frame > 0f))
			{
				break;
			}
			num2++;
			vector3 = ScrollManager.GetScreenLoc(giblet[num].loc, 1f);
			sprite.Draw(spritesTex, (vector2 + vector3) / 2f, new Rectangle(512 + num % 4 * 128, 960, 128, 64), new Color(0f, 0f, 0f, giblet[num].frame * 2f), giblet[num].rotation, new Vector2(64f, 32f), new Vector2((vector2 - vector3).Length() / 120f, (0.4f + (1f - giblet[num].frame)) * ScrollManager.cannedDepth[0]) * 1f, SpriteEffects.None, 1f);
			num = (num + (giblet.Length - 1)) % giblet.Length;
			vector2 = vector3;
		}
		if (num2 == 0)
		{
			gibletCount = 0;
		}
	}

	public void Draw(SpriteBatch sprite, Texture2D spritesTex)
	{
		if (key < 0 || gibType == 4)
		{
			return;
		}
		if (gibType == 5)
		{
			float num = 1f;
			if (this.frame < 1f)
			{
				num = this.frame;
			}
			PostGlowMgr.AddGlow(ScrollManager.GetScreenLoc(loc, 1f), 1f, 0.4f, 1f, Rand.GetRandomFloat(0.5f, 2f) * num, Rand.GetRandomFloat(0.05f, 0.25f) * num, 1f);
			DrawSmokeTrail(sprite, spritesTex);
			return;
		}
		if (gibType == 6)
		{
			DrawSmokeTrail(sprite, spritesTex);
			return;
		}
		if (isRobot)
		{
			DrawSmokeTrail(sprite, spritesTex);
		}
		else if (!gooey)
		{
			DrawAlphaTrail(sprite, spritesTex);
		}
		Vector2 screenLoc = ScrollManager.GetScreenLoc(loc, 1f);
		float num2 = ScrollManager.cannedDepth[0] * size;
		Animation animation = Game1.charDef[charDef].GetAnimation(anim);
		KeyFrame[] keyFrameArray = animation.getKeyFrameArray();
		if (keyFrameArray[key] == null)
		{
			key = 0;
		}
		Frame frame = Game1.charDef[charDef].GetFrame(keyFrameArray[key].frameRef);
		Rectangle value = default;
		for (int i = 0; i < frame.GetPartArray().Length; i++)
		{
			Frame.Part part = frame.GetPart(i);
			if (part.idx <= -1)
			{
				continue;
			}
			float num3 = part.rotation;
			Vector2 position = part.location * num2 + screenLoc;
			Vector2 scale = part.scaling * num2;
			if (face == 0)
			{
				num3 = 0f - num3;
				position.X -= part.location.X * num2 * 2f;
			}
			if (part.idx >= 2000 || part.idx >= 1000)
			{
				continue;
			}
			int num4 = -1;
			if (Game1.gameMap.goryoAlpha > 0.5f && Game1.gameMap.goryoAlpha > 0.5f)
			{
				num4 = (int)(Game1.gameMap.tvFrame * 800f) % 3;
			}
			Texture2D texture2D;
			switch (part.idx / 64)
			{
			case 0:
				texture2D = Game1.headTex[headTex];
				value = Game1.headTexMeta[headTex].GetRect(part.idx);
				if (num4 > -1)
				{
					texture2D = Game1.headTex[55 + num4];
					value = Game1.headTexMeta[55 + num4].GetRect(part.idx);
					value.Y = 0;
				}
				break;
			case 1:
				texture2D = Game1.torsoTex[torsoTex];
				value = Game1.torsoTexMeta[torsoTex].GetRect(part.idx - 64);
				if (num4 > -1)
				{
					texture2D = Game1.torsoTex[44 + num4];
					value = Game1.torsoTexMeta[44 + num4].GetRect(part.idx - 64);
				}
				break;
			case 2:
				texture2D = Game1.legsTex[legsTex];
				value = Game1.legsTexMeta[legsTex].GetRect(part.idx - 128);
				if (num4 > -1)
				{
					texture2D = Game1.legsTex[34 + num4];
					value = Game1.legsTexMeta[34 + num4].GetRect(part.idx - 128);
				}
				break;
			case 3:
				texture2D = Game1.weaponTex[weaponTex];
				value = Game1.weaponTexMeta[weaponTex].GetRect(part.idx - 192);
				break;
			default:
				texture2D = null;
				break;
			}
			Color color = new Color(0.6f, 0.6f, 0.6f, 1f);
			if (grounded)
			{
				color = new Color(0.6f, 0.6f, 0.6f, 0.99f);
			}
			if (this.frame < 1f)
			{
				color = new Color(0.6f, 0.6f, 0.6f, 0.7f * this.frame);
			}
			bool flag = false;
			if ((face == 1 && part.flip == 0) || (face == 0 && part.flip == 1))
			{
				flag = true;
			}
			if (texture2D != null)
			{
				sprite.Draw(texture2D, position, value, color, num3, new Vector2((float)value.Width / 2f, (float)value.Height / 2f), scale, (!flag) ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 1f);
			}
		}
	}
}
