using System.IO;
using System.Text;

namespace Yuki_Win.player.inventory;

public class InvTab
{
	public InvEntry[] items;

	public int totalItems;

	public int scroll;

	public int cursor;

	public int hCursor;

	public StringBuilder emptyString;

	public InvTab(string emptyString)
	{
		items = new InvEntry[30];
		for (int i = 0; i < items.Length; i++)
		{
			items[i] = new InvEntry();
		}
		this.emptyString = new StringBuilder(emptyString);
		totalItems = 0;
	}

	internal void Reset()
	{
		totalItems = 0;
		scroll = 0;
	}

	internal void AddItem(InvCatalog.InvItemName name, int count)
	{
		for (int i = 0; i < totalItems; i++)
		{
			if (items[i].name == name)
			{
				items[i].count += count;
				if (items[i].count > Game1.invCatalog.catalog[(int)name].max)
				{
					items[i].count = Game1.invCatalog.catalog[(int)name].max;
				}
				return;
			}
		}
		items[totalItems].name = name;
		items[totalItems].count = count;
		if (items[totalItems].count > Game1.invCatalog.catalog[(int)name].max)
		{
			items[totalItems].count = Game1.invCatalog.catalog[(int)name].max;
		}
		totalItems++;
	}

	internal bool UseItem(InvCatalog.InvItemName name)
	{
		for (int i = 0; i < totalItems; i++)
		{
			if (items[i].name != name)
			{
				continue;
			}
			items[i].count--;
			if (items[i].count <= 0)
			{
				for (int j = i; j < totalItems - 1; j++)
				{
					items[j].name = items[j + 1].name;
					items[j].count = items[j + 1].count;
				}
				totalItems--;
				return true;
			}
		}
		return false;
	}

	public void Write(BinaryWriter writer)
	{
		writer.Write(totalItems);
		for (int i = 0; i < totalItems; i++)
		{
			writer.Write(Game1.invCatalog.catalog[(int)items[i].name].friendlyName);
			writer.Write(items[i].count);
		}
	}

	public void Read(BinaryReader reader)
	{
		totalItems = reader.ReadInt32();
		for (int i = 0; i < totalItems; i++)
		{
			items[i].name = Game1.invCatalog.GetNameFromName(reader.ReadString());
			items[i].count = reader.ReadInt32();
		}
	}

	internal bool HasItem(InvCatalog.InvItemName invItemName)
	{
		for (int i = 0; i < totalItems; i++)
		{
			if (items[i].name == invItemName)
			{
				return true;
			}
		}
		return false;
	}
}
