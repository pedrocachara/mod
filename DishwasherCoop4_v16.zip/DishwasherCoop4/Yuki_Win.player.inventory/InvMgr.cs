using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Yuki_Win.director;

namespace Yuki_Win.player.inventory;

public class InvMgr
{
	public Inv[] inv;

	public InvMgr()
	{
		inv = new Inv[4];
		for (int i = 0; i < inv.Length; i++)
		{
			inv[i] = new Inv(i);
		}
	}

	public void Update()
	{
		for (int i = 0; i < inv.Length; i++)
		{
			inv[i].Update();
		}
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		float alpha = inv[0].alpha;
		if (inv[1].alpha > alpha)
		{
			alpha = inv[1].alpha;
		}
		if (alpha > 0f)
		{
			sprite.Draw(Game1.nullTex, new Rectangle(0, 0, (int)ScrollManager.screenSize.X, (int)ScrollManager.screenSize.Y), new Color(0.3f, 0.28f, 0.2f, 0.75f * alpha));
			QuakeManager.bright = 0.5f * alpha;
		}
		for (int i = 0; i < inv.Length; i++)
		{
			if (inv[i].alpha > 0f)
			{
				inv[i].Draw(sprite, threedee);
			}
		}
	}

	public bool IsActive()
	{
		for (int i = 0; i < inv.Length; i++)
		{
			if (inv[i].alpha > 0f)
			{
				return true;
			}
		}
		return false;
	}

	public void AddItem(int idx, InvCatalog.InvItemName name, int count)
	{
		inv[idx].AddItem(name, Game1.invCatalog.catalog[(int)name].section, count);
	}

	public bool UseItem(int idx, InvCatalog.InvItemName name)
	{
		return inv[idx].UseItem(name, Game1.invCatalog.catalog[(int)name].section);
	}

	public void Init(int i)
	{
		Inv inv = this.inv[i];
		if (inv.active)
		{
			inv.active = false;
			return;
		}
		inv.alpha = 0f;
		inv.active = true;
		inv.tab[1].Reset();
		if (Game1.character[i].GetMeta().isDish)
		{
			int num = Game1.player.dishPhase;
			if (Game1.gamePlayerMgr.gamePlayer[i].highestDishPhase > num)
			{
				num = Game1.gamePlayerMgr.gamePlayer[i].highestDishPhase;
			}
			switch (num)
			{
			case 0:
				inv.tab[1].AddItem(InvCatalog.InvItemName.ShiftBlade, 1);
				break;
			case 1:
				inv.tab[1].AddItem(InvCatalog.InvItemName.ShiftBlade, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.MeatCleavers, 1);
				break;
			case 2:
			case 3:
			case 4:
				inv.tab[1].AddItem(InvCatalog.InvItemName.ShiftBlade, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.MeatCleavers, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.ViolenceHammer, 1);
				break;
			case 5:
			case 6:
				inv.tab[1].AddItem(InvCatalog.InvItemName.ShiftBlade, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.MeatCleavers, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.ViolenceHammer, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.TheGuillotine, 1);
				break;
			case 7:
			case 8:
			case 9:
			case 10:
				inv.tab[1].AddItem(InvCatalog.InvItemName.ShiftBlade, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.MeatCleavers, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.ViolenceHammer, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.TheGuillotine, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.Dekkentozter, 1);
				break;
			}
		}
		else
		{
			int num2 = Game1.player.yukiPhase;
			if (Game1.player.yukiPhase >= 6 && Game1.gamePlayerMgr.gamePlayer[i].highestYukiPhase > num2)
			{
				num2 = Game1.gamePlayerMgr.gamePlayer[i].highestYukiPhase;
			}
			switch (num2)
			{
			case 4:
			case 5:
			case 6:
				inv.tab[1].AddItem(InvCatalog.InvItemName.Conviction, 1);
				break;
			case 7:
			case 8:
			case 9:
				inv.tab[1].AddItem(InvCatalog.InvItemName.Conviction, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.CloudSword, 1);
				break;
			case 10:
			case 11:
				inv.tab[1].AddItem(InvCatalog.InvItemName.Conviction, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.CloudSword, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.Kamakazi, 1);
				break;
			case 12:
			case 13:
			case 14:
			case 15:
				inv.tab[1].AddItem(InvCatalog.InvItemName.Conviction, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.CloudSword, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.Kamakazi, 1);
				inv.tab[1].AddItem(InvCatalog.InvItemName.Painkiller, 1);
				break;
			case 1:
			case 2:
			case 3:
				break;
			}
		}
	}
}
