using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using director;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Net;
using Yuki_Win.audio;
using Yuki_Win.chars;
using Yuki_Win.netplay;

namespace Yuki_Win.player.inventory;

public class Inv
{
	public enum InvTabSection
	{
		Food,
		LoadOut,
		Beads,
		Keys,
		Progression,
		Upgrade
	}

	public Dictionary<int, InvTab> tab;

	public InvTabSection currentTab;

	public Vector2 loc;

	public float frame;

	public bool active;

	public float alpha;

	public int ID;

	private int lines = 5;

	private bool pKeyUp;

	private bool pKeyDown;

	private bool pKeyLeft;

	private bool pKeyRight;

	private float tabTransFrame;

	private int tabTransDir;

	private bool slotMode;

	private StringBuilder slashString = new StringBuilder("/");

	public void Write(BinaryWriter writer)
	{
		tab[0].Write(writer);
		tab[2].Write(writer);
	}

	public void Read(BinaryReader reader)
	{
		tab[0].Read(reader);
		tab[2].Read(reader);
		tab[3].Reset();
		tab[1].Reset();
	}

	public void Update()
	{
		if (active)
		{
			if (alpha < 1f)
			{
				alpha += FMan.frameTime * 16f;
			}
			if (alpha >= 1f)
			{
				alpha = 1f;
			}
			if (alpha >= 1f)
			{
				Game1.character[ID].charKeys.Update(Game1.character[ID].ai, Game1.character, Game1.character[ID]);
				CharKeys charKeys = Game1.character[ID].charKeys;
				bool flag = charKeys.keyUp || charKeys.keyDUp;
				bool flag2 = charKeys.keyDown || charKeys.keyDDown;
				bool flag3 = charKeys.keyLeft || charKeys.keyDLeft;
				bool flag4 = charKeys.keyRight || charKeys.keyDRight;
				if (slotMode)
				{
					if (flag3 && !pKeyLeft)
					{
						Sound.PlaySnd(Sound.Category.FX, "swing");
						tab[(int)currentTab].hCursor = (tab[(int)currentTab].hCursor + 3) % 4;
					}
					if (flag4 && !pKeyRight)
					{
						Sound.PlaySnd(Sound.Category.FX, "throw");
						tab[(int)currentTab].hCursor = (tab[(int)currentTab].hCursor + 1) % 4;
					}
					if (charKeys.keyGrab)
					{
						slotMode = false;
					}
					if (charKeys.keyJump)
					{
						if (currentTab == InvTabSection.LoadOut)
						{
							Game1.gamePlayerMgr.gamePlayer[ID].SetLoadout(tab[(int)currentTab].hCursor / 2, tab[(int)currentTab].hCursor % 2, tab[(int)currentTab].items[tab[(int)currentTab].cursor].name, ID);
							Sound.PlaySnd(Sound.Category.FX, "block");
							if (Game1.character[ID].loadOut == tab[(int)currentTab].hCursor / 2 && Game1.character[ID].weapIdx == tab[(int)currentTab].hCursor % 2)
							{
								Game1.character[ID].charKeys.SwitchCheck(Game1.character[ID].GetMeta(), ID, Game1.character[ID], force: true);
							}
						}
						else if (currentTab == InvTabSection.Beads)
						{
							Game1.beadMgr.beads[ID].bead[tab[(int)currentTab].hCursor] = tab[(int)currentTab].items[tab[(int)currentTab].cursor].name;
							Game1.beadMgr.UpdateMapTheme();
							Sound.PlaySnd(Sound.Category.FX, "block");
							Sound.PlaySnd(Sound.Category.FX, "pickup");
						}
						slotMode = false;
					}
				}
				else
				{
					if (flag && !pKeyUp && tab[(int)currentTab].totalItems > 0)
					{
						Sound.PlaySnd(Sound.Category.FX, "swing");
						tab[(int)currentTab].cursor--;
						if (tab[(int)currentTab].cursor < 0)
						{
							tab[(int)currentTab].cursor = tab[(int)currentTab].totalItems - 1;
						}
					}
					if (flag2 && !pKeyDown && tab[(int)currentTab].totalItems > 0)
					{
						Sound.PlaySnd(Sound.Category.FX, "throw");
						tab[(int)currentTab].cursor = (tab[(int)currentTab].cursor + 1) % tab[(int)currentTab].totalItems;
					}
					if (flag3 && !pKeyLeft)
					{
						Sound.PlaySnd(Sound.Category.FX, "swing");
						tabTransDir = -1;
						tabTransFrame = 1f;
					}
					if (flag4 && !pKeyRight)
					{
						Sound.PlaySnd(Sound.Category.FX, "throw");
						tabTransDir = 1;
						tabTransFrame = 1f;
					}
					if (tab[(int)currentTab].cursor < tab[(int)currentTab].scroll)
					{
						tab[(int)currentTab].scroll--;
					}
					if (tab[(int)currentTab].cursor >= tab[(int)currentTab].scroll + lines)
					{
						tab[(int)currentTab].scroll++;
					}
					if (charKeys.keyGrab)
					{
						active = false;
					}
					if (charKeys.keyJump)
					{
						bool flag5 = false;
						if (currentTab == InvTabSection.LoadOut || currentTab == InvTabSection.Beads)
						{
							slotMode = true;
							if (currentTab == InvTabSection.Beads && Game1.beadMgr.beads[ID].HasBead(tab[(int)currentTab].items[tab[(int)currentTab].cursor].name))
							{
								slotMode = false;
								for (int i = 0; i < Game1.beadMgr.beads[ID].bead.Length; i++)
								{
									if (Game1.beadMgr.beads[ID].bead[i] == tab[(int)currentTab].items[tab[(int)currentTab].cursor].name)
									{
										Game1.beadMgr.beads[ID].bead[i] = InvCatalog.InvItemName.None;
										Game1.beadMgr.UpdateMapTheme();
										Sound.PlaySnd(Sound.Category.FX, "thud");
										Sound.PlaySnd(Sound.Category.FX, "pickup");
									}
								}
							}
						}
						else
						{
							float num = 1f;
							if (Game1.beadMgr.beads[ID].HasBead(InvCatalog.InvItemName.PigBead))
							{
								num = 1.5f;
							}
							switch (tab[(int)currentTab].items[tab[(int)currentTab].cursor].name)
							{
							case InvCatalog.InvItemName.MoonBread:
								if (tab[(int)currentTab].items[tab[(int)currentTab].cursor].count > 0 && Game1.character[ID].charUpdate.hp < Game1.character[ID].charUpdate.mhp)
								{
									flag5 = true;
									Game1.character[ID].charUpdate.hp += 50f * num;
									if (Game1.character[ID].charUpdate.hp > Game1.character[ID].charUpdate.mhp)
									{
										Game1.character[ID].charUpdate.hp = Game1.character[ID].charUpdate.mhp;
									}
								}
								break;
							case InvCatalog.InvItemName.MoonFish:
								if (tab[(int)currentTab].items[tab[(int)currentTab].cursor].count > 0 && Game1.character[ID].charUpdate.hp < Game1.character[ID].charUpdate.mhp)
								{
									flag5 = true;
									Game1.character[ID].charUpdate.hp += 200f * num;
									if (Game1.character[ID].charUpdate.hp > Game1.character[ID].charUpdate.mhp)
									{
										Game1.character[ID].charUpdate.hp = Game1.character[ID].charUpdate.mhp;
									}
								}
								break;
							case InvCatalog.InvItemName.SquidChips:
								if (tab[(int)currentTab].items[tab[(int)currentTab].cursor].count > 0 && Game1.character[ID].charUpdate.mp < Game1.character[ID].charUpdate.mmp)
								{
									flag5 = true;
									Game1.character[ID].charUpdate.mp++;
								}
								break;
							case InvCatalog.InvItemName.KittenVitamins:
								if (tab[(int)currentTab].items[tab[(int)currentTab].cursor].count > 0 && Game1.character[ID].charUpdate.healthRegen < 10f)
								{
									Game1.character[ID].charUpdate.healthRegen = 10f;
									flag5 = true;
								}
								break;
							}
							if (flag5)
							{
								Sound.PlaySnd(Sound.Category.FX, "pickup");
								UseItem(tab[(int)currentTab].items[tab[(int)currentTab].cursor].name, currentTab);
							}
						}
					}
				}
				pKeyDown = flag2;
				pKeyUp = flag;
				pKeyLeft = flag3;
				pKeyRight = flag4;
			}
		}
		else
		{
			alpha -= FMan.frameTime * 16f;
			if (alpha < 0f)
			{
				alpha = 0f;
			}
		}
		if (!(alpha > 0f))
		{
			return;
		}
		frame += FMan.frameTime;
		if (frame > 12.56f)
		{
			frame -= 12.56f;
		}
		if (tabTransFrame > 0f)
		{
			float num2 = tabTransFrame;
			tabTransFrame -= FMan.frameTime * 11f;
			if (tabTransFrame < 0.5f && num2 >= 0.5f)
			{
				int num3 = 4;
				if (tabTransDir > 0)
				{
					currentTab = (InvTabSection)((int)(currentTab + 1) % num3);
				}
				else
				{
					currentTab = (InvTabSection)((int)(currentTab + (num3 - 1)) % num3);
				}
			}
			_ = tabTransFrame;
			_ = 0f;
		}
		for (int j = 0; j < tab[(int)currentTab].totalItems; j++)
		{
			if (j == tab[(int)currentTab].cursor && !slotMode)
			{
				if (tab[(int)currentTab].items[j].alpha < 1f)
				{
					tab[(int)currentTab].items[j].alpha += FMan.frameTime * 5f;
					if (tab[(int)currentTab].items[j].alpha > 1f)
					{
						tab[(int)currentTab].items[j].alpha = 1f;
					}
				}
				continue;
			}
			if (tab[(int)currentTab].items[j].alpha > 0f)
			{
				tab[(int)currentTab].items[j].alpha -= FMan.frameTime * 5f;
				if (tab[(int)currentTab].items[j].alpha < 0f)
				{
					tab[(int)currentTab].items[j].alpha = 0f;
				}
			}
			if (slotMode && j == tab[(int)currentTab].cursor && tab[(int)currentTab].items[j].alpha < 0.5f)
			{
				tab[(int)currentTab].items[j].alpha = 0.5f;
			}
		}
	}

	public Inv(int ID)
	{
		tab = new Dictionary<int, InvTab>();
		tab.Add(0, new InvTab(YukiText.inv_nofood));
		tab.Add(3, new InvTab(YukiText.inv_nokeys));
		tab.Add(2, new InvTab(YukiText.inv_nobeads));
		tab.Add(1, new InvTab(YukiText.inv_noweapons));
		this.ID = ID;
	}

	public void Reset()
	{
		tab[0].Reset();
		tab[3].Reset();
		tab[2].Reset();
		tab[1].Reset();
	}

	public int GetItemCount(InvCatalog.InvItemName name)
	{
		for (int i = 0; i < tab[0].totalItems; i++)
		{
			if (tab[0].items[i].name == name)
			{
				return tab[0].items[i].count;
			}
		}
		for (int j = 0; j < tab[2].totalItems; j++)
		{
			if (tab[2].items[j].name == name)
			{
				return 1;
			}
		}
		return 0;
	}

	public void AddBead(InvCatalog.InvItemName name)
	{
		if (!tab[2].HasItem(name))
		{
			tab[2].AddItem(name, 1);
		}
	}

	public void AddItem(InvCatalog.InvItemName name, InvTabSection section, int count)
	{
		if (section == InvTabSection.Beads)
		{
			Game1.levelMgr.SetGlobalFlag("netbead" + Game1.invCatalog.catalog[(int)name].friendlyName.ToLower());
			AddBead(name);
			AllBeadsCheck();
		}
		else
		{
			tab[(int)section].AddItem(name, count);
		}
	}

	private void AllBeadsCheck()
	{
		if (tab[2].HasItem(InvCatalog.InvItemName.AchievablesBead) && tab[2].HasItem(InvCatalog.InvItemName.BatBead) && tab[2].HasItem(InvCatalog.InvItemName.BellBead) && tab[2].HasItem(InvCatalog.InvItemName.BoneBead) && tab[2].HasItem(InvCatalog.InvItemName.BrainBead) && tab[2].HasItem(InvCatalog.InvItemName.CatBead) && tab[2].HasItem(InvCatalog.InvItemName.CloudBead) && tab[2].HasItem(InvCatalog.InvItemName.ContrastBead) && tab[2].HasItem(InvCatalog.InvItemName.CrossBead) && tab[2].HasItem(InvCatalog.InvItemName.CrownBead) && tab[2].HasItem(InvCatalog.InvItemName.EyeBead) && tab[2].HasItem(InvCatalog.InvItemName.FlowerBead) && tab[2].HasItem(InvCatalog.InvItemName.GoatBead) && tab[2].HasItem(InvCatalog.InvItemName.GunBead) && tab[2].HasItem(InvCatalog.InvItemName.HacksawBead) && tab[2].HasItem(InvCatalog.InvItemName.HeartBead) && tab[2].HasItem(InvCatalog.InvItemName.IceBead) && tab[2].HasItem(InvCatalog.InvItemName.MathBead) && tab[2].HasItem(InvCatalog.InvItemName.MirrorBead) && tab[2].HasItem(InvCatalog.InvItemName.MoneyBead) && tab[2].HasItem(InvCatalog.InvItemName.PigBead) && tab[2].HasItem(InvCatalog.InvItemName.PlateBead) && tab[2].HasItem(InvCatalog.InvItemName.RobotBead) && tab[2].HasItem(InvCatalog.InvItemName.RocketBead) && tab[2].HasItem(InvCatalog.InvItemName.ShieldBead) && tab[2].HasItem(InvCatalog.InvItemName.SkullBead) && tab[2].HasItem(InvCatalog.InvItemName.SpiderBead) && tab[2].HasItem(InvCatalog.InvItemName.SquidBead) && tab[2].HasItem(InvCatalog.InvItemName.ThreeDeeBead) && tab[2].HasItem(InvCatalog.InvItemName.WineBead))
		{
			Game1.achievementMgr.playerAchievements[ID].achievementList[7].Unlock(overRide: false);
		}
	}

	public bool UseItem(InvCatalog.InvItemName name, InvTabSection section)
	{
		return tab[(int)section].UseItem(name);
	}

	public static void DrawRect(SpriteBatch sprite, Rectangle dRect, float alpha, float frame)
	{
		Rectangle destinationRectangle = dRect;
		destinationRectangle.X -= 15;
		destinationRectangle.Y -= 15;
		destinationRectangle.Width += 30;
		destinationRectangle.Height += 30;
		sprite.Draw(Game1.spritesTex, destinationRectangle, new Rectangle(640, 388, 256, 54), new Color(0f, 0f, 0f, 0.5f * alpha));
		sprite.Draw(Game1.spritesTex, new Rectangle(destinationRectangle.X + destinationRectangle.Width, destinationRectangle.Y, destinationRectangle.Height, destinationRectangle.Width), new Rectangle(640, 388, 256, 54), new Color(0f, 0f, 0f, 0.5f * alpha), 1.57f, default, SpriteEffects.None, 1f);
		int num = 0;
		for (int i = dRect.Left; i < dRect.Right; i += 15)
		{
			num++;
			DrawBob(sprite, new Vector2(i, dRect.Y), num, frame);
			DrawBob(sprite, new Vector2(dRect.Right - (i - dRect.Left), dRect.Bottom), num, frame);
		}
		num = 0;
		for (int j = dRect.Top; j < dRect.Bottom; j += 15)
		{
			num++;
			DrawBob(sprite, new Vector2(dRect.X, j), num, frame);
			DrawBob(sprite, new Vector2(dRect.Right, dRect.Bottom - (j - dRect.Top)), num, frame);
		}
	}

	public static void DrawBob(SpriteBatch sprite, Vector2 loc, int idx, float frame)
	{
		Rectangle rectangle = default;
		if (idx % 3 == 0)
		{
			rectangle = new Rectangle(640 + idx / 2 % 6 * 32, 608, 32, 32);
		}
		else
		{
			rectangle = new Rectangle(896 + idx / 2 % 4 * 32, 864, 32, 32);
			if (idx % 4 == 1)
			{
				rectangle.Y -= 32;
			}
		}
		Color white = Color.White;
		white = new Color(0.01f, 0f, 0f, 0.5f);
		rectangle.X = 896 + Rand.GetRandomInt(0, 4) * 32;
		rectangle.Y = 896;
		sprite.Draw(sourceRectangle: new Rectangle(384 + idx % 4 * 64, 320, 64, 64), texture: Game1.spritesTex, position: loc + new Vector2((float)Math.Cos(frame * 3f + (float)idx), (float)Math.Sin(frame * 3f + (float)idx)) * 2f, color: white, rotation: frame * ((float)(idx % 2) - 0.5f) + (float)idx, origin: new Vector2(32f, 32f), scale: 0.8f, effects: SpriteEffects.None, layerDepth: 1f);
	}

	public void Draw(SpriteBatch sprite, int threedee)
	{
		float num = 271f * alpha;
		float num2 = 211f * alpha;
		loc = new Vector2(380f, ScrollManager.screenSize.Y * 0.58f);
		if (ID == 1)
		{
			loc.X += ScrollManager.screenSize.X - loc.X * 2f;
		}
		switch (threedee)
		{
		case 0:
			loc.X++;
			break;
		case 1:
			loc.X--;
			break;
		}
		if (tabTransFrame > 0f)
		{
			if (tabTransFrame < 0.5f)
			{
				loc.X -= tabTransFrame * (float)tabTransDir * -1f * 10f;
			}
			else
			{
				loc.X -= (1f - tabTransFrame) * (float)tabTransDir * -1f * 10f;
			}
		}
		DrawRect(sprite, new Rectangle((int)(loc.X - num), (int)(loc.Y - num2), (int)(num * 2f), (int)(num2 * 2f)), alpha, frame);
		if (!(alpha >= 1f))
		{
			return;
		}
		sprite.Draw(Game1.spritesTex, new Vector2(loc.X - num - 5f, loc.Y), new Rectangle(0, 768, 64, 64), new Color(1f, 1f, 1f, alpha), 0f, new Vector2(32f, 32f), 0.6f, SpriteEffects.None, 1f);
		sprite.Draw(Game1.spritesTex, new Vector2(loc.X + num + 5f, loc.Y), new Rectangle(64, 768, 64, 64), new Color(1f, 1f, 1f, alpha), 0f, new Vector2(32f, 32f), 0.6f, SpriteEffects.None, 1f);
		float num3 = 1f;
		if (tabTransFrame > 0f)
		{
			if (tabTransFrame < 0.5f)
			{
				loc.X -= tabTransFrame * (float)tabTransDir * -1f * 100f;
				num3 *= (0.5f - tabTransFrame) * 2f;
			}
			else
			{
				loc.X += (1f - tabTransFrame) * (float)tabTransDir * -1f * 100f;
				num3 *= (tabTransFrame - 0.5f) * 2f;
			}
		}
		Vector2 position = loc + new Vector2(-250f, 170f);
		sprite.Draw(Game1.spritesTex, position, new Rectangle(640, 576, 32, 32), new Color(1f, 1f, 1f, num3), 0f, default, 1f, SpriteEffects.None, 1f);
		Text.DrawScore((int)position.X + 28, (int)position.Y, (long)Game1.gamePlayerMgr.gamePlayer[ID].gold, new Color(1f, 1f, 1f, num3), sprite, flip: true, 0f, 0.8f);
		for (int i = 0; i < 2; i++)
		{
			sprite.Draw(Game1.spritesTex, loc + new Vector2(0f, 157f) + new Vector2(80f - (float)i * 160f, 0f), new Rectangle(128, 32 * i, 128, 32), new Color(1f, 1f, 1f, 0.4f), 0f, new Vector2(64f, 16f), new Vector2(2f, 0.5f), SpriteEffects.None, 1f);
		}
		loc.Y -= 20f;
		int num4 = 0;
		float num5 = 15f;
		if (tab[(int)currentTab].totalItems == 0)
		{
			Text.DrawCText(sprite, loc + new Vector2(0f, -10f), tab[(int)currentTab].emptyString, new Color(1f, 1f, 1f, num3), 0.7f, 1);
			return;
		}
		switch (currentTab)
		{
		case InvTabSection.Food:
		case InvTabSection.Beads:
		{
			for (int j = 0; j < 2; j++)
			{
				for (int k = 0; k < 2; k++)
				{
					sprite.Draw(Game1.spritesTex, loc + new Vector2(0f, (k == 0) ? (-42f) : 8f) + new Vector2(80f - (float)j * 160f, 0f), new Rectangle(128, 32 * j, 128, 32), new Color(1f, 1f, 1f, 0.3f), 0f, new Vector2(64f, 16f), new Vector2(2f, 0.5f), SpriteEffects.None, 1f);
				}
			}
			break;
		}
		}
		if (currentTab == InvTabSection.LoadOut)
		{
			for (int l = 0; l < 2; l++)
			{
				for (int m = 0; m < 2; m++)
				{
					Vector2 vector = new Vector2(0f - num + 80f + (float)l * 280f + (float)m * 100f, 0f - num2 + 140f + (float)l * 15f + (float)m * ((l == 0) ? 15f : (-15f)));
					Color color = Color.White;
					switch (l)
					{
					case 0:
						color = new Color(1f, 0.4f, 0.4f, alpha * 0.5f);
						if (slotMode && tab[(int)currentTab].hCursor == l * 2 + m)
						{
							color = new Color(1f, 0.8f, 0.9f, alpha);
						}
						break;
					case 1:
						color = new Color(0.4f, 0.4f, 1f, alpha * 0.5f);
						if (slotMode && tab[(int)currentTab].hCursor == l * 2 + m)
						{
							color = new Color(0.8f, 0.9f, 1f, alpha);
						}
						break;
					}
					sprite.Draw(Game1.spritesTex, loc + vector, new Rectangle(832, 192, 64, 64), color, frame + (float)l + (float)m, new Vector2(32f, 32f), 2.5f, SpriteEffects.None, 1f);
					color.A /= 2;
					sprite.Draw(Game1.spritesTex, loc + vector, new Rectangle(832, 192, 64, 64), color, 0f - frame + (float)l + (float)m, new Vector2(32f, 32f), 3f, SpriteEffects.FlipHorizontally, 1f);
					if (Game1.gamePlayerMgr.gamePlayer[ID].loadOut[l].weapon[m] != InvCatalog.InvItemName.None)
					{
						int item = (int)Game1.gamePlayerMgr.gamePlayer[ID].loadOut[l].weapon[m];
						sprite.Draw(Game1.itemsTex, loc + vector, Game1.invCatalog.GetInvitemRect((InvCatalog.InvItemName)item), Color.White, 0f, new Vector2(64f, 64f) * 2f, 0.5f, SpriteEffects.None, 1f);
					}
				}
			}
		}
		else if (currentTab == InvTabSection.Beads)
		{
			for (int n = 0; n < 4; n++)
			{
				Vector2 vector2 = new Vector2(0f - num + 80f + (float)n * 120f, 0f - num2 + 110f);
				if (n == 1 || n == 2)
				{
					vector2.Y -= 40f;
				}
				Color color2 = new Color(0.5f, 0.5f, 0.5f, 1f);
				if (slotMode && tab[(int)currentTab].hCursor == n)
				{
					color2 = Color.White;
				}
				sprite.Draw(Game1.spritesTex, loc + vector2, new Rectangle(832, 192, 64, 64), color2, frame + (float)n, new Vector2(32f, 32f), 2.5f, SpriteEffects.None, 1f);
				color2.A /= 2;
				sprite.Draw(Game1.spritesTex, loc + vector2, new Rectangle(832, 192, 64, 64), color2, 0f - frame + (float)n, new Vector2(32f, 32f), 3f, SpriteEffects.FlipHorizontally, 1f);
				if (Game1.beadMgr.beads[ID].bead[n] != InvCatalog.InvItemName.None)
				{
					int item2 = (int)Game1.beadMgr.beads[ID].bead[n];
					sprite.Draw(Game1.itemsTex, loc + vector2, Game1.invCatalog.GetInvitemRect((InvCatalog.InvItemName)item2), Color.White, 0f, new Vector2(64f, 64f) * 2f, 0.3f, SpriteEffects.None, 1f);
				}
			}
		}
		for (int num6 = tab[(int)currentTab].scroll; num6 < tab[(int)currentTab].scroll + lines; num6++)
		{
			if (num6 < tab[(int)currentTab].totalItems)
			{
				float num7 = num3;
				if (currentTab == InvTabSection.Beads && Game1.beadMgr.beads[ID].HasBead(tab[(int)currentTab].items[num6].name))
				{
					num7 /= 2f;
				}
				Text.DrawCText(sprite, loc + new Vector2(0f - num + 50f + tab[(int)currentTab].items[num6].alpha * 10f, num5 + (float)num4 * 30f), Game1.invCatalog.catalog[(int)tab[(int)currentTab].items[num6].name].name, new Color(1f, 1f - tab[(int)currentTab].items[num6].alpha, 1f - tab[(int)currentTab].items[num6].alpha, 1f * num7), 0.75f, 0);
				sprite.Draw(Game1.itemsTex, loc + new Vector2(0f - num + 20f + tab[(int)currentTab].items[num6].alpha * 10f, num5 + (float)num4 * 30f), Game1.invCatalog.GetInvitemRect(tab[(int)currentTab].items[num6].name), new Color(1f, 1f, 1f, 1f * num7), 0f, default, 0.125f, SpriteEffects.None, 1f);
				if (tab[(int)currentTab].items[num6].alpha > 0f)
				{
					if (currentTab != InvTabSection.LoadOut && currentTab != InvTabSection.Beads)
					{
						sprite.Draw(Game1.itemsTex, loc + new Vector2(0f, -130f), Game1.invCatalog.GetInvitemRect(tab[(int)currentTab].items[num6].name), new Color(1f, 1f, 1f, tab[(int)currentTab].items[num6].alpha * num3), 0f, new Vector2(64f, 64f) * 2f, 1.6f * (0.5f + 0.5f * tab[(int)currentTab].items[num6].alpha) / 2f, SpriteEffects.None, 1f);
					}
					if (Game1.invCatalog.catalog[(int)tab[(int)currentTab].items[num6].name].desc2 == null)
					{
						Text.DrawCText(sprite, loc + new Vector2(0f, -30f), Game1.invCatalog.catalog[(int)tab[(int)currentTab].items[num6].name].desc, new Color(1f, 1f, 1f, tab[(int)currentTab].items[num6].alpha * num3), 0.75f, 1, blur: false, 490f);
					}
					else
					{
						Text.DrawCText(sprite, loc + new Vector2(0f, -40f), Game1.invCatalog.catalog[(int)tab[(int)currentTab].items[num6].name].desc, new Color(1f, 1f, 1f, tab[(int)currentTab].items[num6].alpha * num3), 0.75f, 1, blur: false, 490f);
						Text.DrawCText(sprite, loc + new Vector2(0f, -20f), Game1.invCatalog.catalog[(int)tab[(int)currentTab].items[num6].name].desc2, new Color(1f, 1f, 1f, tab[(int)currentTab].items[num6].alpha * num3), 0.75f, 1, blur: false, 490f);
					}
				}
				if (tab[(int)currentTab].items[num6].count > 1 || Game1.invCatalog.catalog[(int)tab[(int)currentTab].items[num6].name].max > 0)
				{
					Text.DrawScore((int)(loc.X + 140f), (int)(loc.Y + num5 + (float)num4 * 30f), tab[(int)currentTab].items[num6].count, new Color(1f, 1f - tab[(int)currentTab].items[num6].alpha, 1f - tab[(int)currentTab].items[num6].alpha, 1f * num3), sprite, flip: true, 0f, 0.75f);
					if (Game1.invCatalog.catalog[(int)tab[(int)currentTab].items[num6].name].max > 0)
					{
						Text.DrawCText(sprite, loc + new Vector2(164f, num5 + (float)num4 * 30f), slashString, new Color(1f, 1f - tab[(int)currentTab].items[num6].alpha, 1f - tab[(int)currentTab].items[num6].alpha, 1f * num3), 0.75f, 1);
						Text.DrawScore((int)(loc.X + 180f), (int)(loc.Y + num5 + (float)num4 * 30f), Game1.invCatalog.catalog[(int)tab[(int)currentTab].items[num6].name].max, new Color(1f, 1f - tab[(int)currentTab].items[num6].alpha, 1f - tab[(int)currentTab].items[num6].alpha, 1f * num3), sprite, flip: true, 0f, 0.75f);
					}
				}
			}
			num4++;
		}
	}

	internal void Copy(Inv src)
	{
		foreach (KeyValuePair<int, InvTab> item in src.tab)
		{
			tab[item.Key].totalItems = src.tab[item.Key].totalItems;
			for (int i = 0; i < item.Value.totalItems; i++)
			{
				tab[item.Key].items[i].name = src.tab[item.Key].items[i].name;
				tab[item.Key].items[i].count = src.tab[item.Key].items[i].count;
			}
		}
	}

	internal void NetWrite(PacketWriter writer)
	{
		InvTab invTab = tab[(int)currentTab];
		NetPacker.WriteByte(writer, (int)currentTab);
		NetPacker.WriteByte(writer, invTab.cursor);
		NetPacker.WriteByte(writer, invTab.totalItems);
		for (int i = 0; i < invTab.totalItems; i++)
		{
			NetPacker.WriteByte(writer, (int)invTab.items[i].name);
			NetPacker.WriteByte(writer, invTab.items[i].count);
		}
		switch (currentTab)
		{
		case InvTabSection.Beads:
		{
			for (int l = 0; l < 4; l++)
			{
				NetPacker.WriteByte(writer, (int)Game1.beadMgr.beads[ID].bead[l]);
			}
			break;
		}
		case InvTabSection.LoadOut:
		{
			for (int j = 0; j < 2; j++)
			{
				for (int k = 0; k < 2; k++)
				{
					NetPacker.WriteByte(writer, (int)Game1.gamePlayerMgr.gamePlayer[ID].loadOut[j].weapon[k]);
				}
			}
			break;
		}
		}
	}

	internal void NetRead(PacketReader reader)
	{
		currentTab = (InvTabSection)NetPacker.ReadByte(reader);
		InvTab invTab = tab[(int)currentTab];
		invTab.cursor = NetPacker.ReadByte(reader);
		invTab.totalItems = NetPacker.ReadByte(reader);
		for (int i = 0; i < invTab.totalItems; i++)
		{
			invTab.items[i].name = (InvCatalog.InvItemName)NetPacker.ReadByte(reader);
			invTab.items[i].count = NetPacker.ReadByte(reader);
		}
		switch (currentTab)
		{
		case InvTabSection.Beads:
		{
			for (int l = 0; l < 4; l++)
			{
				Game1.beadMgr.beads[ID].bead[l] = (InvCatalog.InvItemName)NetPacker.ReadByte(reader);
			}
			break;
		}
		case InvTabSection.LoadOut:
		{
			for (int j = 0; j < 2; j++)
			{
				for (int k = 0; k < 2; k++)
				{
					Game1.gamePlayerMgr.gamePlayer[ID].loadOut[j].weapon[k] = (InvCatalog.InvItemName)NetPacker.ReadByte(reader);
				}
			}
			break;
		}
		}
	}
}
