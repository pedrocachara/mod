namespace Yuki_Win.player.inventory;

public class InvEntry
{
	public InvCatalog.InvItemName name;

	public int count;

	public float alpha;
}
