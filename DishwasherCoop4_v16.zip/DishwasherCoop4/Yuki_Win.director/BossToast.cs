using System.Text;
using director;
using Microsoft.Xna.Framework;
using Yuki_Win.audio;
using Yuki_Win.chars;

namespace Yuki_Win.director;

public class BossToast
{
	public float frame = -1f;

	public StringBuilder s1;

	public StringBuilder s2;

	public bool needsImprint;

	public void Init(string s1, string s2, int m)
	{
		Init(s1, s2, m, netInduced: false);
	}

	public void Init(string s1, string s2, int m, bool netInduced)
	{
		if (Game1.netSession.IsHost())
		{
			Game1.netSession.netGame.SendActivate(Game1.netSession.session, m, Game1.character[m].charMeta);
		}
		if (!Game1.netSession.IsClient() || netInduced)
		{
			this.s1 = new StringBuilder(s1);
			this.s2 = new StringBuilder(s2);
			frame = 0f;
		}
	}

	public void Clear()
	{
		frame = -1f;
	}

	public void Update()
	{
		if (float.IsNaN(ScrollManager.zoom))
		{
			ScrollManager.zoom = 1f;
		}
		if (frame < 0f)
		{
			return;
		}
		float num = frame;
		frame += FMan.frameTime * 0.7f;
		if (frame >= 4.8f)
		{
			frame = -1f;
			return;
		}
		if (frame >= 0.8f && num < 0.8f)
		{
			needsImprint = true;
			Sound.PlaySnd(Sound.Category.FX, "jail");
			Sound.PlaySnd(Sound.Category.FX, "bass");
		}
		float num2 = 0f;
		num2 = ((!(frame < 0.8f)) ? 1f : (frame / 0.8f));
		Vector2 vector = default;
		Vector2 vector2 = default;
		for (int i = 0; i < Game1.character.Length; i++)
		{
			Character character = Game1.character[i];
			if (!character.exists || character.team != Character.Team.BadGuys)
			{
				continue;
			}
			vector = character.charUpdate.loc + new Vector2(-50f, -120f);
			vector2 = character.charUpdate.loc + new Vector2(50f, 20f);
			if (character.GetMeta().introyadd > 0f)
			{
				vector.Y += character.GetMeta().introyadd;
				vector2.Y += character.GetMeta().introyadd;
			}
			if (character.GetMeta().isGiant)
			{
				for (int j = 0; j < character.charRect.hitRect.Length; j++)
				{
					Rectangle rectangle = character.charRect.hitRect[j];
					if (rectangle.Width > 0)
					{
						if (rectangle.X < (int)vector.X)
						{
							vector.X = rectangle.X;
						}
						if (rectangle.Y < (int)vector.Y - 40)
						{
							vector.Y = (float)rectangle.Y - 40f;
						}
						if (rectangle.Right > (int)vector2.X)
						{
							vector2.X = rectangle.Right;
						}
						if (rectangle.Bottom > (int)vector2.Y)
						{
							vector2.Y = rectangle.Bottom;
						}
					}
				}
			}
			if (character.GetMeta().isDragon)
			{
				vector = character.charUpdate.loc + new Vector2(-500f, -500f);
				vector2 = character.charUpdate.loc + new Vector2(500f, 100f);
			}
		}
		Vector2 vector3 = (vector + vector2) / 2f;
		float num3 = ScrollManager.screenSize.Y / (vector2.Y - vector.Y);
		num3 = -5f + num3 * 0.2f;
		vector3.X += 100f / num3;
		ScrollManager.scroll += (vector3 - ScrollManager.scroll) * num2;
		ScrollManager.zoom += (num3 - ScrollManager.zoom) * num2;
	}

	internal bool IsActive()
	{
		if (frame >= 0.8f && frame < 4.9f)
		{
			return true;
		}
		return false;
	}
}
