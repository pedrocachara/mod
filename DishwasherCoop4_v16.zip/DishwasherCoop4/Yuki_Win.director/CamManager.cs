using director;
using GuitarEdit.guitar;
using Microsoft.Xna.Framework;
using Yuki_Win.chars;
using Yuki_Win.debug;
using Yuki_Win.gameRender;
using Yuki_Win.levels;
using Yuki_Win.maps;
using Yuki_Win.sprites.gibs;

namespace Yuki_Win.director;

public class CamManager
{
	public bool twoPlayers;

	private Vector2 monsterOffset;

	private float monsterZoom;

	private float monsterOffsetFrame;

	public Vector2 grabVec;

	public float grabFrame;

	public BossToast bossToast;

	private Vector2 offsetGoalVec;

	private Vector2 offsetVec;

	private float offsetFrame;

	public CamManager()
	{
		bossToast = new BossToast();
	}

	public void SetGrabVec(Vector2 vec)
	{
		grabVec = vec;
		grabFrame = 1f;
	}

	public bool CanSlowAll()
	{
		if (Game1.netSession.IsHost())
		{
			return false;
		}
		if (Game1.netSession.IsClient())
		{
			return false;
		}
		return !twoPlayers;
	}

	public void Update(Character[] character, GameMap gameMap, LevelManager levelMgr, KillManager killManager)
	{
		Vector2 scroll = ScrollManager.scroll;
		float num = 1f / 60f;
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Asylum)
		{
			num *= 2f;
		}
		if (DebugManager.hideChars)
		{
			ScrollManager.scroll += flibitPort.GetInputStick(0, flibitPort.InputAction.Move) * num * new Vector2(1f, -1f) * 200f;
			float num2 = flibitPort.GetInputStick(0, flibitPort.InputAction.WarpRoll).Y * 0.3f;
			num2 = num2 * num + 1f;
			ScrollManager.zoom *= num2;
			if (ScrollManager.zoom < 0.2f)
			{
				ScrollManager.zoom = 0.2f;
			}
			if (flibitPort.GetInputDigital(0, flibitPort.InputAction.Inventory))
			{
				DebugManager.hideChars = false;
			}
			Vector2 offset = ScrollManager.scroll - scroll;
			if (gameMap.liftOn)
			{
				offset.Y -= gameMap.liftSpeed * num * 50f;
			}
			GameRender.fogRender.Update(offset);
			return;
		}
		bool flag = false;
		Vector2 vector = default;
		if (grabFrame > 0f)
		{
			grabFrame -= num;
		}
		twoPlayers = false;
		float num3 = 1.6f;
		if (gameMap.theme.theme == Themes.ThemeType.Dish && Game1.gameMap.goryoAlpha <= 0f)
		{
			num3 = 2.2f;
		}
		Vector2 vector2 = default;
		Vector2 vector3 = default;
		if (Game1.gameMap.CurMap().xSize == 10)
		{
			num3 = 1.7f;
		}
		if (Game1.levelMgr.currentTrack == 5 || Game1.levelMgr.currentTrack == 6)
		{
			num3 = 1.8f;
		}
		int num4 = 0;
		int camNP = Game1.GetPlayers();
		int camAlive = 0;
		if (camNP >= 2)
		{
			twoPlayers = true;
			int camFirst = 0;
			for (int a = 0; a < camNP && a < 4; a++)
			{
				if (!(Game1.character[a].charUpdate.dyingFrame > 0f))
				{
					if (camAlive == 0)
					{
						camFirst = a;
					}
					camAlive++;
				}
			}
			if (camAlive == 1)
			{
				twoPlayers = false;
				num4 = camFirst;
			}
		}
		if (Game1.netSession.IsHost())
		{
			twoPlayers = false;
			num4 = 0;
		}
		if (Game1.netSession.IsClient())
		{
			twoPlayers = false;
			num4 = 1;
		}
		Vector2 vector4 = character[num4].GetCharUpdate().loc - new Vector2(0f, 40f);
		float num5 = 14f;
		float num6 = 2f;
		if (gameMap.theme.theme == Themes.ThemeType.Asylum || gameMap.theme.theme == Themes.ThemeType.Escape || gameMap.theme.theme == Themes.ThemeType.PrisonOut || gameMap.lichFreakoutMode || Game1.gameMap.theme.theme == Themes.ThemeType.EscapeOut)
		{
			ScrollManager.camOffsetFrame -= num;
			if (ScrollManager.camOffsetFrame <= 0f)
			{
				ScrollManager.camOffsetFrame = Rand.GetRandomFloat(0.2f, 0.5f);
				ScrollManager.camOffset = Rand.GetRandomVec2(-30f, 30f, -30f, 30f);
			}
			ScrollManager.camZoomFrame -= num;
			if (ScrollManager.camZoomFrame <= 0f)
			{
				ScrollManager.camZoomFrame = Rand.GetRandomFloat(0.2f, 0.5f);
				ScrollManager.camZoom = Rand.GetRandomFloat(-0.1f, 0.3f);
			}
			vector4 += ScrollManager.camOffset;
			num3 = 2f + ScrollManager.camZoom;
			num5 = 0.8f;
			num6 = 0.3f;
			if (gameMap.theme.theme == Themes.ThemeType.EscapeOut)
			{
				num3 -= 0.8f;
			}
		}
		if (gameMap.theme.theme == Themes.ThemeType.Lobby || gameMap.theme.theme == Themes.ThemeType.EliteLobby)
		{
			num3 = 1.4f;
		}
		if (gameMap.theme.theme == Themes.ThemeType.BigCloset)
		{
			num3 = 1.1f;
		}
		if (gameMap.theme.theme == Themes.ThemeType.PrisonOut)
		{
			num3 = 1.2f;
			vector4.X += Rand.GetRandomFloat(-8f, 8f);
		}
		Vector2 vector5 = vector4 - new Vector2(100f, 150f);
		Vector2 vector6 = vector4 + new Vector2(100f, 120f);
		int num7 = 0;
		if (twoPlayers)
		{
			Vector2 camSum = default(Vector2);
			int camCnt = 0;
			for (int a2 = 0; a2 < camNP && a2 < 4; a2++)
			{
				if (camAlive > 0 && character[a2].charUpdate.dyingFrame > 0f)
				{
					continue;
				}
				camSum += character[a2].GetCharUpdate().netLoc;
				camCnt++;
			}
			vector4 = camSum / (float)((camCnt < 1) ? 1 : camCnt) - new Vector2(0f, 40f);
			for (int i = 0; i < camNP && i < 4; i++)
			{
				int num8 = i;
				if (camAlive > 0 && character[num8].charUpdate.dyingFrame > 0f)
				{
					continue;
				}
				if (character[num8].charUpdate.loc.X < vector5.X)
				{
					vector5.X = character[num8].charUpdate.netLoc.X;
				}
				if (character[num8].charUpdate.loc.Y < vector5.Y)
				{
					vector5.Y = character[num8].charUpdate.netLoc.Y;
				}
				if (character[num8].charUpdate.loc.X > vector6.X)
				{
					vector6.X = character[num8].charUpdate.netLoc.X;
				}
				if (character[num8].charUpdate.loc.Y > vector6.Y)
				{
					vector6.Y = character[num8].charUpdate.netLoc.Y;
				}
			}
			vector5 -= new Vector2(250f, 50f);
			vector6 += new Vector2(250f, 50f);
			_ = (vector5 + vector6) / 2f;
			Vector2 vector7 = vector6 - vector5;
			vector7.Y *= 1.7777778f;
			float num9 = vector7.X;
			if (vector7.Y > vector7.X)
			{
				num9 = vector7.Y;
			}
			float num10 = 1280f / num9;
			if (num10 < num3)
			{
				num3 = num10;
			}
		}
		if (Game1.gameMap.yukiDeathFocus)
		{
			for (int j = 0; j < character.Length; j++)
			{
				if (character[j].charMeta == 94)
				{
					vector4 = character[j].charUpdate.loc;
					num3 += Game1.gameMap.yukiDeathFrame;
				}
			}
		}
		bool flag2 = false;
		for (int k = 0; k < character.Length; k++)
		{
			if (!character[k].exists || character[k].team != Character.Team.BadGuys || character[k].charAnim.animName == character[k].GetMeta().spawn_anim || character[k].charUpdate.inactive)
			{
				continue;
			}
			if (character[k].charUpdate.zapCharged > 0f)
			{
				flag = true;
				vector = character[k].charUpdate.loc + new Vector2(0f, -50f);
			}
			if (!character[k].charUpdate.locked)
			{
				continue;
			}
			flag2 = true;
			num7++;
			if (character[k].charUpdate.loc.X < vector5.X)
			{
				vector5.X = character[k].charUpdate.loc.X;
			}
			if (character[k].charUpdate.loc.Y < vector5.Y)
			{
				vector5.Y = character[k].charUpdate.loc.Y;
			}
			if (character[k].charUpdate.loc.X > vector6.X)
			{
				vector6.X = character[k].charUpdate.loc.X;
			}
			if (character[k].charUpdate.loc.Y > vector6.Y)
			{
				vector6.Y = character[k].charUpdate.loc.Y;
			}
			if (!character[k].GetMeta().isGiant)
			{
				continue;
			}
			for (int l = 0; l < character[k].charRect.hitRect.Length; l++)
			{
				Rectangle rectangle = character[k].charRect.hitRect[l];
				if (rectangle.Width > 0)
				{
					int num11 = rectangle.Y + character[k].GetMeta().heightMinus;
					if (num11 < (int)vector5.Y)
					{
						vector5.Y = num11;
					}
				}
			}
			if (character[k].GetMeta().fakeTop > 0f && character[k].charUpdate.loc.Y - character[k].GetMeta().fakeTop < vector5.Y)
			{
				vector5.Y = character[k].charUpdate.loc.Y - character[k].GetMeta().fakeTop;
			}
		}
		if (num7 <= 0 && !twoPlayers && !Game1.gameMap.slavachase)
		{
			Vector2 vector8 = default;
			float num12 = 0f;
			for (int m = 0; m < character.Length; m++)
			{
				if (character[m].exists && character[m].team == Character.Team.BadGuys && !(character[m].charAnim.animName == character[m].GetMeta().spawn_anim) && !character[m].charUpdate.inactive && !character[m].GetMeta().isBox && ((character[m].charUpdate.loc.X > ScrollManager.scroll.X - 400f && character[m].charUpdate.loc.X < ScrollManager.scroll.X + 400f && character[m].charUpdate.loc.Y > ScrollManager.scroll.Y - 300f && character[m].charUpdate.loc.Y < ScrollManager.scroll.Y + 300f) || character[m].GetMeta().isBoss))
				{
					num12++;
					vector8 += character[m].charUpdate.loc + new Vector2(0f, -80f);
					if (character[m].charUpdate.loc.X < vector5.X)
					{
						vector5.X = character[m].charUpdate.loc.X;
					}
					if (character[m].charUpdate.loc.X > vector6.X)
					{
						vector6.X = character[m].charUpdate.loc.X;
					}
					if (character[m].charUpdate.loc.Y < vector5.Y)
					{
						vector5.Y = character[m].charUpdate.loc.Y;
					}
					if (character[m].charUpdate.loc.Y > vector6.Y)
					{
						vector6.Y = character[m].charUpdate.loc.Y;
					}
					if (character[m].GetMeta().isDragon)
					{
						num3 -= 0.4f;
					}
				}
			}
			for (int n = 0; n < Game1.spriteMan.gib.Length; n++)
			{
				Gib gib = Game1.spriteMan.gib[n];
				if (gib.exists && !gib.grounded && gib.gibType != 4 && gib.gibType != 5 && gib.gibType != 6 && gib.gibType != 3)
				{
					num12++;
					vector8 += gib.loc;
					if (gib.loc.X < vector5.X)
					{
						vector5.X = gib.loc.X;
					}
					if (gib.loc.X > vector6.X)
					{
						vector6.X = gib.loc.X;
					}
					if (gib.loc.Y < vector5.Y)
					{
						vector5.Y = gib.loc.Y;
					}
					if (gib.loc.Y > vector6.Y)
					{
						vector6.Y = gib.loc.Y;
					}
				}
			}
			if (num12 > 0f)
			{
				vector8 /= num12;
				num3 += 0.2f;
				float num13 = 160f;
				float num14 = 100f;
				vector8 -= vector4;
				vector8 *= 0.6f;
				if (vector8.X < 0f - num13)
				{
					vector8.X = 0f - num13;
				}
				if (vector8.X > num13)
				{
					vector8.X = num13;
				}
				if (vector8.Y < 0f - num14)
				{
					vector8.Y = 0f - num14;
				}
				if (vector8.Y > num14)
				{
					vector8.Y = num14;
				}
				monsterOffset += (vector8 - monsterOffset) * num * 5f;
				vector4 += monsterOffset * monsterOffsetFrame;
				Vector2 vector9 = vector6 - vector5;
				vector9.Y *= 1.7777778f;
				float num15 = ((vector9.Y > vector9.X) ? vector9.Y : vector9.X);
				if (num15 > 300f)
				{
					num15 = (num15 - 300f) / 800f;
					if (num15 > 0.5f)
					{
						num15 = 0.5f;
					}
					num15 = 0.5f - num15;
				}
				num3 += monsterOffsetFrame * num15;
				if (monsterOffsetFrame < 1f)
				{
					monsterOffsetFrame += num;
				}
			}
			else
			{
				monsterOffset = default;
				if (monsterOffsetFrame > 0f)
				{
					monsterOffsetFrame -= num;
				}
			}
		}
		if (num7 > 0)
		{
			vector5 -= new Vector2(90f, 50f);
			vector6 += new Vector2(90f, 50f);
			Vector2 vector10 = (vector5 + vector6) / 2f;
			Vector2 vector11 = vector6 - vector5;
			vector11.Y *= 1.7777778f;
			float num16 = vector11.X;
			if (vector11.Y > vector11.X)
			{
				num16 = vector11.Y;
			}
			num3 = 1280f / num16;
			vector4 = vector10;
		}
		if (character[0].charAnim.animName == "lie")
		{
			num3 = 2.4f;
		}
		if (!twoPlayers)
		{
			if (!Game1.netSession.IsHost() && !Game1.netSession.IsClient())
			{
				for (int num17 = 0; num17 < character.Length; num17++)
				{
					if (character[num17].exists && character[num17].charAnim.animName == "groundsawed")
					{
						vector4 = character[num17].charUpdate.loc - new Vector2(0f, 30f);
						num3 = 2.4f;
					}
				}
				if (character[num4].charUpdate.airJuggleFrame > 0f && num7 > 0 && !flag2)
				{
					num3 = 2.4f;
					vector4 = character[num4].GetCharUpdate().loc - new Vector2(0f, 40f);
				}
			}
			if (killManager.killFrame > 0f)
			{
				num5 = 12f;
				if (killManager.victim >= 0)
				{
					vector4 = (vector4 + character[killManager.victim].GetCharUpdate().loc - new Vector2(0f, 40f)) / 2f + Rand.GetRandomVec2(-30f, 30f, -30f, 30f) * killManager.killFrame;
					if (character[killManager.victim].GetMeta().isGiant)
					{
						for (int num18 = 0; num18 < character.Length; num18++)
						{
							if (character[num18].team == Character.Team.GoodGuys)
							{
								character[num18].charUpdate.etherealFrame = 1f;
							}
						}
						int num19 = (int)character[killManager.victim].charUpdate.loc.Y;
						for (int num20 = 0; num20 < character[killManager.victim].charRect.hitRect.Length; num20++)
						{
							Rectangle rectangle2 = character[killManager.victim].charRect.hitRect[num20];
							if (rectangle2.Width > 0 && rectangle2.Bottom < num19)
							{
								num19 = rectangle2.Bottom;
							}
						}
						vector4.Y = num19;
					}
					if (Rand.CointToss(0.1f))
					{
						QuakeManager.SetBright(0.1f);
						if (num > 0f && ScrollManager.zoom < 3f)
						{
							ScrollManager.zoom += 0.1f;
						}
					}
				}
				num3 = Rand.GetRandomFloat(3f, 3.8f);
				if (gameMap.invalidPhase != GameMap.InvalidPhase.None && gameMap.psychoTVFrame > 0f && gameMap.psychoTVFrame < 3f)
				{
					num3 = Rand.GetRandomFloat(4.6f, 5.5f);
					vector4.Y += 30f;
					QuakeManager.SetBright(Rand.GetRandomFloat(0f, 0.4f));
				}
			}
			if (character[num4].charUpdate.charGrab.grabbing)
			{
				num5 = 12f;
				num3 = 2.4f;
				bool flag3 = false;
				for (int num21 = 0; num21 < character.Length; num21++)
				{
					if (!character[num21].exists || character[num21].charUpdate.charGrab.grabbedByChar != num4)
					{
						continue;
					}
					if (Game1.charMeta[character[num21].charMeta].isGiant)
					{
						vector4 = ((character[num21].charAnim.charTrigs.grabberLoc - new Vector2(0f, 40f)) * 3f + character[num21].charUpdate.loc - new Vector2(0f, 40f)) / 4f;
						flag3 = true;
					}
					else
					{
						vector4 = character[num21].charUpdate.loc - new Vector2(0f, 40f);
					}
					if (killManager.killFrame > 0f)
					{
						if (killManager.victim > -1 && !Game1.charMeta[character[num21].charMeta].isGiant)
						{
							vector4 = (vector4 + character[killManager.victim].GetCharUpdate().loc - new Vector2(0f, 40f)) / 2f;
						}
						vector4 += Rand.GetRandomVec2(-40f, 40f, -40f, 40f) * killManager.killFrame;
					}
				}
				if (!flag3)
				{
					num3 = 4f;
				}
			}
			else if (character[num4].charUpdate.charGrab.grabbedByChar > -1 && grabFrame > 0f)
			{
				vector4 = grabVec + new Vector2(0f, -40f);
			}
			for (int num22 = 0; num22 < 2; num22++)
			{
				if (character[num22].exists && character[num22].charUpdate.magic > 0f)
				{
					vector4 = character[num22].charUpdate.loc - new Vector2(0f, 40f);
					num3 = 4f;
					if (character[num22].charUpdate.magicOut > 0f)
					{
						num3 = Rand.GetRandomFloat(3f, 4f);
						vector4.X += ((float)character[num22].charUpdate.face - 0.5f) * 200f;
						vector4 += Rand.GetRandomVec2(-50f, 50f, -50f, 50f);
					}
				}
			}
		}
		if (flag)
		{
			vector4 = vector;
			num5 = 20f;
			num3 = Rand.GetRandomFloat(2f, 3f);
		}
		for (int num23 = 0; num23 < Game1.spriteMan.gib.Length; num23++)
		{
			if (Game1.spriteMan.gib[num23].exists)
			{
				if (Game1.spriteMan.gib[num23].isDragon)
				{
					vector4 = Game1.spriteMan.gib[num23].loc + Rand.GetRandomVec2(-50f, 50f, -100f, 0f);
					num6 *= 2f;
					num3 = Rand.GetRandomFloat(1.5f, 2.5f);
				}
				else if (Game1.spriteMan.gib[num23].isMask)
				{
					vector4 = Game1.spriteMan.gib[num23].loc + new Vector2(0f, -20f);
					num6 *= 2f;
					num3 = Rand.GetRandomFloat(3.5f, 4.5f);
				}
			}
		}
		if (gameMap.theme.theme == Themes.ThemeType.Dish)
		{
			num6 *= 0.3f;
			num5 *= 0.3f;
		}
		if (gameMap.theme.theme == Themes.ThemeType.Asylum && Game1.gameMap.slavachase)
		{
			num3 = Rand.GetRandomFloat(2.5f, 4.5f);
		}
		if (Game1.hud.shopMgr.shop[0].alpha > 0f && Game1.hud.shopMgr.shop[1].alpha <= 0f)
		{
			vector4.X -= Game1.hud.shopMgr.shop[0].alpha * 150f;
		}
		if (Game1.hud.shopMgr.shop[1].alpha > 0f && Game1.hud.shopMgr.shop[0].alpha <= 0f)
		{
			vector4.X += Game1.hud.shopMgr.shop[1].alpha * 150f;
		}
		if (gameMap.DoorFocus() > -1)
		{
			Rectangle rect = gameMap.CurMap().layer[2].segment[gameMap.DoorFocus()].rect;
			vector4 = new Vector2(rect.Center.X, rect.Center.Y);
			num3 = 1.9f;
			num5 = 10f;
		}
		vector4 += QuakeManager.QuakeVec();
		if (Game1.soloMgr.active)
		{
			num3 += 0.95f;
			switch (Game1.soloMgr.currentLights)
			{
			case Node.Event.WhiteLights:
			case Node.Event.RedLights:
			case Node.Event.BlueLights:
				num3 += 0.2f;
				break;
			case Node.Event.BlueSparks:
			case Node.Event.StrobeLights:
				num3 += 0.4f;
				vector4 += Rand.GetRandomVec2(-4f, 4f, -4f, 4f);
				break;
			case Node.Event.Fire:
				vector4 += Rand.GetRandomVec2(-10f, 10f, -10f, 10f);
				num3 += 0.4f;
				break;
			}
		}
		if (num3 < ScrollManager.zoom)
		{
			num6 *= 2f;
		}
		num3 = -6f + num3 * 0.2f + ((num3 < 1f) ? ((1f - num3) * -10f) : 0f);
		if (num3 < -6f)
		{
			num3 += (num3 - -6f) * 2f;
		}
		if (gameMap.theme.theme == Themes.ThemeType.Final && gameMap.CrazyTransitionInFrame > 0f)
		{
			if (ScrollManager.zoom < num3)
			{
				ScrollManager.zoom *= 1f + 0.7f * num;
			}
			else
			{
				gameMap.CrazyTransitionInFrame = 0f;
				QuakeManager.SetBright(0.8f);
			}
			vector4 += Rand.GetRandomVec2(-100f, 100f, -100f, 100f);
		}
		else
		{
			ScrollManager.zoom += (num3 - ScrollManager.zoom) * num * num6;
			if (Game1.transMgr.inFrame > 0f)
			{
				ScrollManager.zoom = num3;
			}
		}
		_ = ScrollManager.scroll;
		if (!twoPlayers)
		{
			vector2 = ScrollManager.GetScreenLoc(default(Vector2), 1f);
			vector3 = ScrollManager.GetScreenLoc(new Vector2((float)gameMap.CurMap().xSize * 64f, (float)gameMap.CurMap().ySize * 64f), 1f);
			if (vector2.X > 0f)
			{
				vector4.X += vector2.X;
			}
			if (vector3.X < ScrollManager.screenSize.X)
			{
				vector4.X += vector3.X - ScrollManager.screenSize.X;
			}
			if (vector2.Y > 0f)
			{
				vector4.Y += vector2.Y;
			}
			if (vector3.Y < ScrollManager.screenSize.Y - 100f)
			{
				vector4.Y += vector3.Y - (ScrollManager.screenSize.Y - 100f);
			}
		}
		ScrollManager.scroll += (vector4 - ScrollManager.scroll) * num * num5;
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Dish)
		{
			offsetFrame -= num;
			if (offsetFrame < 0f)
			{
				offsetFrame += Rand.GetRandomFloat(0.2f, 0.5f);
				offsetGoalVec = Rand.GetRandomVec2(-10f, 10f, -10f, 10f);
			}
			offsetVec += (offsetGoalVec - offsetVec) * num;
			ScrollManager.scroll += offsetVec * num * 20f;
		}
		if (Game1.gameMap.theme.theme == Themes.ThemeType.Final)
		{
			offsetFrame -= num;
			if (offsetFrame < 0f)
			{
				offsetFrame += Rand.GetRandomFloat(0.2f, 0.5f);
				offsetGoalVec = Rand.GetRandomVec2(-10f, 10f, -10f, 10f);
			}
			offsetVec += (offsetGoalVec - offsetVec) * num;
			ScrollManager.scroll += offsetVec * num * 20f;
		}
		if (twoPlayers)
		{
			vector2 = ScrollManager.GetScreenLoc(default(Vector2), 1f);
			vector3 = ScrollManager.GetScreenLoc(new Vector2((float)gameMap.CurMap().xSize * 64f, (float)gameMap.CurMap().ySize * 64f), 1f);
			float num24 = 100f;
			if (vector2.X > num24)
			{
				ScrollManager.scroll.X += (vector2.X - num24) / ScrollManager.zoom * num * 10f;
			}
			if (vector3.X < 1280f - num24)
			{
				ScrollManager.scroll.X -= (1280f - num24 - vector3.X) / ScrollManager.zoom * num * 10f;
			}
		}
		bossToast.Update();
		if (gameMap.fog && Game1.gameMap.beadTheme != GameMap.BeadTheme.ThreeDee)
		{
			Vector2 offset2 = ScrollManager.scroll - scroll;
			if (gameMap.liftOn)
			{
				offset2.Y -= gameMap.liftSpeed * num * 50f;
			}
			GameRender.fogRender.Update(offset2);
		}
		if (gameMap.water)
		{
			GameRender.waterRender.Update(ScrollManager.scroll - scroll);
		}
	}
}
