using Yuki_Win.arcade;
using Yuki_Win.audio;
using Yuki_Win.menu;

namespace Yuki_Win.director;

public class KillManager
{
	public float killFrame;

	public float killVal;

	public float brightSpike;

	public int victim;

	public float bits;

	public float GetAdjustedKillBrite()
	{
		if (killVal < 0f)
		{
			return 1f;
		}
		if (killVal < 0.5f)
		{
			return (0.5f - killVal) * 0.5f + 0.75f;
		}
		return 0.75f;
	}

	public void Update()
	{
		if (killFrame > 0f)
		{
			killFrame -= FMan.frameTime * 2f;
			if (killVal < 1f)
			{
				killVal += FMan.frameTime * 3f;
			}
		}
		else if (killVal > 0f)
		{
			killVal -= FMan.frameTime * 2f;
		}
		else if (killVal < 0f)
		{
			killVal = 0f;
		}
		if (bits > 0f)
		{
			bits -= FMan.frameTime * 4f;
		}
		if (killVal > bits)
		{
			bits = killVal;
		}
		if (killVal < 0f)
		{
			killVal = 0f;
		}
	}

	public void DoKill(int victim)
	{
		if (Game1.GetPlayers() > 1 && !Game1.CoopSplitState())
		{
			return;
		}
		if (killFrame < 1f)
		{
			if (killFrame < 0.8f)
			{
				Sound.PlaySnd(Sound.Category.FX, "bass");
			}
			killFrame = 1f;
			if (victim > -1 && Game1.character[victim].charUpdate.charGrab.grabbedByChar < 0)
			{
				QuakeManager.SetFlashBack();
			}
		}
		QuakeManager.SetBright(0.1f);
		QuakeManager.SetContrast(0.1f);
		this.victim = victim;
	}

	public void doBits(float frame)
	{
		if (Game1.GetPlayers() <= 1 && frame > bits)
		{
			bits = frame;
		}
	}

	public void DoUberDeath()
	{
		DoUberDeath(netInduced: false);
	}

	public void DoUberDeath(bool netInduced)
	{
		if (Game1.pvpMatch)
		{
			return;
		}
		if (Game1.netSession.IsClient() && !netInduced)
		{
			return;
		}
		if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.DishChallenge)
		{
			Game1.hud.EndLevel();
		}
		else
		{
			if (!(MainPlayer.uberDyingFrame < 1f))
			{
				return;
			}
			MainPlayer.uberDyingFrame = 1f;
			Game1.hud.PickupDeath();
			if (Game1.arcade.arcadeMode == Arcade.ArcadeMode.Arcade)
			{
				Game1.menuMgr.SetLevel(MenuManager.LevelTitle.ArcadeYouAreDead);
				Game1.menuMgr.levels[16].alpha = 0f;
			}
			else
			{
				if (Game1.GetPlayers() == 1)
				{
					Game1.gamePlayerMgr.gamePlayer[0].AddDeath(0);
				}
				Game1.menuMgr.SetLevel(MenuManager.LevelTitle.YouAreDead);
				Game1.menuMgr.levels[7].alpha = 0f;
			}
			if (Game1.netSession.IsHost())
			{
				Game1.netSession.netGame.SendUberDead(Game1.netSession.session);
			}
		}
	}
}
