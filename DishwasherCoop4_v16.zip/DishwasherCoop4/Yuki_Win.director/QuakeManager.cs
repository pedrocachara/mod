using System;
using director;
using Microsoft.Xna.Framework;
using Yuki_Win.audio;

namespace Yuki_Win.director;

public class QuakeManager
{
	public static float quake;

	public static float bright;

	public static float contrast;

	public static float worldStatic;

	public static bool flashBack;

	private static float flashFrame;

	public static float burst;

	public static Vector2 burstVec;

	public static float quirkFrame;

	public static float quirkMax;

	public static void SetQuirk(float val)
	{
		quirkFrame = val;
		quirkMax = val;
		Sound.PlaySnd(Sound.Category.FX, "fizz");
	}

	public static void SetBurst(float val, Vector2 vec)
	{
		burst = val;
		burstVec = vec;
		burstVec.X /= ScrollManager.screenSize.X;
		burstVec.Y /= ScrollManager.screenSize.Y;
	}

	public static void SetContrast(float val)
	{
		val /= 10f;
		if (val > contrast)
		{
			contrast = val;
		}
		if (contrast > 1f)
		{
			contrast = 1f;
		}
	}

	public static void SetQuake(float val)
	{
		if (val > quake)
		{
			quake = val;
		}
		if (quake > 1f)
		{
			quake = 1f;
		}
		Game1.rumbleManager.SetRumble(0, val);
		if (Game1.GetPlayers() >= 2)
		{
			Game1.rumbleManager.SetRumble(1, val);
		}
	}

	public static void SetBright(float val)
	{
		if (val > bright)
		{
			bright = val;
		}
		if (bright > 1f)
		{
			bright = 1f;
		}
	}

	public static void Update()
	{
		if (flashFrame > 0f)
		{
			flashFrame -= FMan.realTime;
		}
		if (worldStatic > 0f)
		{
			worldStatic -= FMan.frameTime;
		}
		if (quake > 0f)
		{
			quake -= FMan.frameTime;
		}
		if (bright > 0f)
		{
			bright -= FMan.frameTime;
		}
		if (contrast > 0f)
		{
			contrast -= FMan.frameTime;
		}
		if (burst > 0f)
		{
			burst -= FMan.realTime;
		}
		if (quirkFrame > 0f)
		{
			float num = quirkFrame;
			float num2 = quirkFrame / quirkMax * 3.14f;
			burst = (float)Math.Sin(num2) * quirkMax * 3f;
			quirkFrame -= FMan.realTime / 16f;
			burstVec = (Rand.GetRandomVec2(-700f, 700f, -500f, 500f) + ScrollManager.screenSize / 2f) / ScrollManager.screenSize;
			bright = burst * 0.2f;
			if (quirkFrame > 0.03f && (int)(num * 30f) != (int)(quirkFrame * 30f))
			{
				Sound.PlaySnd(Sound.Category.FX, "fizz");
			}
		}
	}

	public static float Bright()
	{
		if (bright > 0f)
		{
			return bright;
		}
		return 0f;
	}

	public static float Contrast()
	{
		if (contrast > 0f)
		{
			return contrast;
		}
		return 0f;
	}

	public static Vector2 QuakeVec()
	{
		if (quake > 0f)
		{
			return Rand.GetRandomVec2(-1f, 1f, -1f, 1f) * quake * 150f;
		}
		return default;
	}

	internal static void SetFlashBack()
	{
		if (flashFrame <= 0f)
		{
			flashBack = true;
			flashFrame = 1f;
		}
	}
}
