namespace Yuki_Win.director;

public class RumbleManager
{
	private float[] val = new float[4];

	public void Update()
	{
		if (GameState.state == GameState.State.Menu || (GameState.state == GameState.State.Playing && MainPlayer.uberDyingFrame > 1.1f))
		{
			for (int i = 0; i < 4; i++)
			{
				flibitPort.SetUserVibration(i, 0f);
			}
			return;
		}
		for (int j = 0; j < val.Length; j++)
		{
			if (val[j] > 0f)
			{
				val[j] -= FMan.frameTime;
				if (val[j] < 0f)
				{
					val[j] = 0f;
				}
			}
			if (Game1.mainPlayer[j] > -1)
			{
				flibitPort.SetUserVibration(Game1.mainPlayer[j], val[j]);
			}
		}
	}

	public void SetRumble(int idx, float val)
	{
		if (Game1.netSession.IsClient())
		{
			if (idx != 1)
			{
				return;
			}
			idx = 0;
		}
		if ((!Game1.netSession.IsHost() || idx != 1) && val > this.val[idx])
		{
			this.val[idx] = val;
		}
	}
}
